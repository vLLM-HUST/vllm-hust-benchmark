"""Retain failed admission; freeze a fresh B1 attempt after a new port check."""
import hashlib
import json
from pathlib import Path
import socket
import time

TASK=Path(__file__).resolve().parent
prior=json.loads((TASK/'continuous-b1-r1/receipt.json').read_text())
assert prior['status']=='failed' and not prior['model_run_started'] and not prior['children']
rows=[]
for file in ('/proc/net/tcp','/proc/net/tcp6'):
    for line in Path(file).read_text().splitlines()[1:]:
        fields=line.split()
        if int(fields[1].split(':')[1],16)==18390:
            rows.append(dict(table=file,state_hex=fields[3],inode=fields[9]))
assert not any(row['state_hex']=='0A' for row in rows),'Active listener; do not preempt'
with socket.socket() as sock:
    sock.bind(('127.0.0.1',18390))
source=(TASK/'run_continuous.py').read_text()
old="plan_path=TASK/f'continuous-{role}-plan-r1.json'"
assert source.count(old)==1
source=source.replace(old,"plan_path=TASK/f'continuous-{role}-plan-r2.json'")
path=TASK/'run_continuous_r2.py'
with path.open('x') as f:f.write(source)
plan=json.loads((TASK/'continuous-b1-plan-r1.json').read_text())
plan.update(output=str(TASK/'continuous-b1-r2'),cache=str(TASK/'continuous-b1-cache-r2'),
            recovery=dict(prior='continuous-b1-r1',cause='Pre-model port bind failed; no listener now and fresh ordinary bind succeeds. Historical TCP state was not captured; do not assert TIME_WAIT as proven.',
                          checked_at=time.time(),port_rows=rows,inputs_runtime_and_client_unchanged=True))
for path in (path,Path(__file__)):
    plan['source_sha256'][str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
with (TASK/'continuous-b1-plan-r2.json').open('x') as f:
    json.dump(plan,f,indent=2);f.write('\n')
print('FROZEN_FRESH_B1_ADMISSION',rows)
