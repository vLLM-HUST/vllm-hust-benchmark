"""Own one new service and both continuous phases; preserve every attempt."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time

from run_retrieval_b0_r2 import save,check_owners,stop_group,OPENER,BASE,TASK


def main(role):
    assert role in ('b0','b1')
    plan_path=TASK/f'continuous-{role}-plan-r1.json'
    plan=json.loads(plan_path.read_text())
    assert plan['role']==role.upper() and plan['physical_cards']==[5,6]
    for path,digest in plan['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
    out,cache=Path(plan['output']),Path(plan['cache'])
    assert out.parent==cache.parent==TASK and not out.exists() and not cache.exists()
    out.mkdir(mode=0o700)
    save(out/'plan.json',plan)
    record=dict(status='admitting',started=time.time(),reserved_physical_cards=[5,6],children=[],model_run_started=False)
    locks=[];children=[];handles=[]
    try:
        for path in ('/tmp/inference-project-container-model.lock','/tmp/gennova-device-leases/device-5.lock','/tmp/gennova-device-leases/device-6.lock'):
            lock=open(path,'a+b');locks.append(lock)
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        raw=subprocess.check_output(['npu-smi','info'],text=True,timeout=20)
        assert all(f'No running processes found in NPU {i}' in raw for i in (5,6))
        (out/'npu-before.txt').write_text(raw)
        assert shutil.disk_usage(TASK).free>4*2**30
        with socket.socket() as sock:sock.bind(('127.0.0.1',18390))
        cache.mkdir(mode=0o700)
        save(out/'cache-initialization.json',dict(path=str(cache),initial_entries=[],os_page_cache_globally_flushed=False))
        if role=='b0':
            sys.path.insert(0,str(BASE))
            from runtime_environment_r2 import environment
            env=environment(cache,out)
            env['PYTHONPATH']=str(TASK)+':'+env['PYTHONPATH']
            for key in ('HOME','TMPDIR','XDG_CACHE_HOME','VLLM_CACHE_ROOT','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','ASCEND_CACHE_PATH'):
                Path(env[key]).mkdir(parents=True,exist_ok=True)
            command=[str(BASE/'runtime/unpacked/rootfs/usr/local/python3.11.14/bin/python3.11'),'-S',str(TASK/'bootstrap_b0.py'),str(TASK/'serve_b0_r2.py'),str(plan_path)]
        else:
            env=dict(os.environ,KVMAT_RUN_DIR=str(out))
            command=['bash','/root/m01-storage-timing-runtime-20261024/runtime_boundary_b1.sh',str(TASK/'serve_b1.py'),str(plan_path)]
        for name in ('service.log','client.log','device-samples.jsonl'):
            handles.append((out/name).open('x'))
        service_log,client_log,samples=handles
        server=subprocess.Popen(command,env=env,stdout=service_log,stderr=subprocess.STDOUT,start_new_session=True)
        server.owned_start_ticks=Path(f'/proc/{server.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
        children.append(server)
        record.update(status='starting',service_pid=server.pid,model_run_started=True)
        save(out/'receipt.json',record)
        deadline=time.monotonic()+2400;client=None;failures=0
        while True:
            assert server.poll() is None,f'Service exited {server.returncode}'
            assert time.monotonic()<deadline,'Prospective deadline reached'
            assert shutil.disk_usage(TASK).free>2*2**30,'Disk floor reached'
            mono,wall=time.monotonic(),time.time()
            try:
                raw=subprocess.check_output(['npu-smi','info'],text=True,timeout=20)
            except (subprocess.TimeoutExpired,subprocess.CalledProcessError) as error:
                failures+=1
                samples.write(json.dumps(dict(monotonic=mono,wall=wall,error=str(type(error))))+'\n');samples.flush()
                if failures>=3:raise RuntimeError('Three consecutive sampling failures') from error
                continue
            failures=0
            samples.write(json.dumps(dict(monotonic_start=mono,wall_start=wall,monotonic_end=time.monotonic(),wall_end=time.time(),phase=record['status'],raw=raw))+'\n');samples.flush()
            check_owners(raw,{p.pid for p in children})
            if client is None:
                try:
                    with OPENER.open('http://127.0.0.1:18390/health',timeout=2) as response:ready=response.status==200
                except (OSError,TimeoutError):ready=False
                if ready:
                    client=subprocess.Popen(['/root/agentx-bench/.venv/bin/python',str(TASK/'continuous_client.py'),str(out)],stdout=client_log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(cache/'tmp')})
                    client.owned_start_ticks=Path(f'/proc/{client.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
                    children.append(client);record.update(status='continuous_running',client_pid=client.pid)
                    save(out/'receipt.json',record);print('CLIENT_STARTED',client.pid,flush=True)
            elif client.poll() is not None:
                record['client_exit']=client.returncode
                assert client.returncode==0,'Client failed; retained, do not retry automatically'
                assert json.loads((out/'continuous.json').read_text())['status']=='completed'
                record['status']='completed';break
            time.sleep(2)
    except BaseException as error:
        record.update(status='failed',error=f'{type(error).__name__}: {error}')
        raise
    finally:
        for child in reversed(children):record['children'].append(dict(pid=child.pid,exit_code=stop_group(child)))
        for handle in handles:handle.close()
        released=False
        for attempt in range(3):
            try:
                raw=subprocess.check_output(['npu-smi','info'],text=True,timeout=20)
                (out/f'npu-after-{attempt}.txt').write_text(raw)
                released=all(f'No running processes found in NPU {i}' in raw for i in (5,6))
                if released:break
            except (subprocess.TimeoutExpired,subprocess.CalledProcessError):pass
            time.sleep(2)
        record.update(ended=time.time(),all_reserved_devices_released=released)
        save(out/'receipt.json',record)
        for lock in locks:lock.close()
        if released:
            (out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
        print(json.dumps(record),flush=True)


if __name__=='__main__':main(sys.argv[1])
