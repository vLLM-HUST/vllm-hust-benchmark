import asyncio
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from continuous_client import request


class Response:
    status=200
    def __init__(self,finish='length',done=True,cached=0):
        self.events=[dict(choices=[dict(delta=dict(reasoning='x'),finish_reason=None)]),
                     dict(choices=[dict(delta=dict(content='x'),finish_reason=finish)]),
                     dict(usage=dict(prompt_tokens=4096,completion_tokens=256,prompt_tokens_details=dict(cached_tokens=cached)),choices=[])]
        self.done=done
        self.content=self
    async def __aenter__(self):return self
    async def __aexit__(self,*args):return False
    def __aiter__(self):
        async def lines():
            for value in self.events:yield b'data: '+json.dumps(value).encode()+b'\n'
            if self.done:yield b'data: [DONE]\n'
        return lines()


class Session:
    def __init__(self,response):self.response=response
    def post(self,*args,**kwargs):
        assert kwargs['json']['cache_salt']=='case'
        return self.response


def run(tmp_path,response):
    return asyncio.run(request(Session(response),tmp_path,dict(input_tokens=4096,request={}), 'case','formal'))


def test_complete(tmp_path):
    result=run(tmp_path,Response())
    assert result['success'] and result['first_token']['monotonic']<=result['end']['monotonic']
    assert (tmp_path/'case.sse.jsonl.gz').is_file()


def test_missing_done(tmp_path):
    assert not run(tmp_path,Response(done=False))['success']


def test_early_end(tmp_path):
    assert not run(tmp_path,Response(finish='stop'))['success']


def test_cache_reuse(tmp_path):
    assert not run(tmp_path,Response(cached=3))['success']
