"""Frozen C8 HTTP stress supplement; not dataset quality or M02 acceptance."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

import aiohttp

TASK = Path(__file__).resolve().parent
URL = 'http://127.0.0.1:18390'


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def clock():
    a = time.monotonic()
    wall = time.time()
    return dict(monotonic=a, wall=wall, monotonic_after=time.monotonic())


async def request(session, out, case, request_id, phase):
    row = dict(id=request_id, phase=phase, input_tokens=case['input_tokens'],
               start=clock(), success=False, first_token=None, finish_reason=None)
    payload = dict(case['request'], cache_salt=request_id)
    done = False
    try:
        async with session.post(URL+'/v1/chat/completions', json=payload) as response:
            row['http_status'] = response.status
            with gzip.open(out/(request_id+'.sse.jsonl.gz'), 'wt') as stream:
                async for line in response.content:
                    stamp = clock()
                    stream.write(json.dumps(dict(clock=stamp, raw=line.decode()))+'\n')
                    if not line.startswith(b'data:'):
                        continue
                    data = line[5:].strip()
                    if data == b'[DONE]':
                        done = True
                        continue
                    event = json.loads(data)
                    if event.get('error'):
                        raise ValueError('SSE error')
                    if event.get('usage'):
                        row['usage'] = event['usage']
                    for choice in event.get('choices', []):
                        delta = choice.get('delta', {})
                        if any(delta.get(k) for k in ('content','reasoning','reasoning_content')):
                            if row['first_token'] is None:
                                row['first_token'] = stamp
                            row['last_token'] = stamp
                        row['finish_reason'] = choice.get('finish_reason') or row['finish_reason']
            assert response.status == 200 and done and row['first_token']
            assert row['finish_reason']=='length'
            assert row['usage']['prompt_tokens']==case['input_tokens']
            assert row['usage']['completion_tokens']==256
            assert row['usage'].get('prompt_tokens_details',{}).get('cached_tokens') in (None,0)
            row['success'] = True
    except Exception as error:
        row['error'] = f'{type(error).__name__}: {error}'
    row['end'] = clock()
    save(out/(request_id+'.json'), row)
    return row


async def phase(session, out, cases, name, seconds):
    start = clock()
    end = start['monotonic']+seconds
    rows = []
    failed = asyncio.Event()
    async def lane(i):
        sequence = 0
        while time.monotonic() < end and not failed.is_set():
            request_id = f'{out.name}-{name}-lane{i}-{sequence:05d}'
            row = await request(session, out, cases[i], request_id, name)
            rows.append(row)
            sequence += 1
            if not row['success']:
                failed.set()
                raise RuntimeError('Request failure retained; stop this prospective arm')
    tasks = [asyncio.create_task(lane(i)) for i in range(8)]
    values = await asyncio.gather(*tasks, return_exceptions=True)
    result = dict(name=name, start=start, submission_deadline_monotonic=end,
                  end=clock(), seconds=seconds, requests=len(rows),
                  failed=sum(not r['success'] for r in rows))
    save(out/(name+'-phase.json'), result)
    print(json.dumps(result), flush=True)
    for value in values:
        if isinstance(value, BaseException):
            raise value
    return result


async def main(out):
    plan = json.loads((out/'plan.json').read_text())
    raw = (TASK/'continuous-inputs-r1.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==plan['input_sha256']
    inputs = json.loads(raw)
    save(out/'request-plan.json', inputs)
    phases = []
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=180),trust_env=False) as session:
        checked = []
        for cases in inputs.values():
            for case in cases:
                async with session.post(URL+'/tokenize',json=dict(model='qwen3.5-35b',messages=case['request']['messages'],add_generation_prompt=True)) as response:
                    assert response.status == 200
                    value=await response.json()
                digest=hashlib.sha256(json.dumps(value['tokens']).encode()).hexdigest()
                assert (value['count'],digest)==(case['input_tokens'],case['token_ids_sha256'])
                checked.append(dict(input_tokens=value['count'],token_ids_sha256=digest))
        save(out/'tokenize-preflight.json',checked)
        for name,cases in inputs.items():
            phases.append(await phase(session,out,cases,name+'-warmup',60))
            phases.append(await phase(session,out,cases,name+'-formal',300))
    save(out/'continuous.json',dict(status='completed',phases=phases,
        scope='C8 closed-loop synthetic stress, separate from dataset quality, fixed-arrival latency and M06 business acceptance'))


if __name__=='__main__':
    asyncio.run(main(Path(sys.argv[1])))
