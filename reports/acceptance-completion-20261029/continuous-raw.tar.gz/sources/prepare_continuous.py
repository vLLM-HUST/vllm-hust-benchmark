"""Freeze inputs, runtime pins and stop conditions before starting either arm."""
import hashlib
import json
from pathlib import Path
from transformers import AutoTokenizer

TASK=Path(__file__).resolve().parent
tokenizer=AutoTokenizer.from_pretrained('/models/Qwen3.5-35B-A3B',local_files_only=True)
inputs={}
for target in (4096,16384):
    cases=[]
    for lane in range(8):
        head=f'Internal synthetic engineering record {lane}.\n'
        filler=' This is a synthetic engineering log. No production data is included.\n'
        tail='\nSummarize the engineering log in detail.\n'
        repeats=target//len(tokenizer.encode(filler,add_special_tokens=False))
        while True:
            messages=[dict(role='user',content=head+filler*repeats+tail)]
            encoded=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True)
            ids=encoded if isinstance(encoded,list) else encoded['input_ids']
            assert isinstance(ids,list) and all(isinstance(n,int) for n in ids)
            if len(ids)>=target:
                break
            repeats+=1
        request=dict(model='qwen3.5-35b',messages=messages,stream=True,
                     stream_options=dict(include_usage=True),temperature=0,seed=17,
                     max_tokens=256,ignore_eos=True)
        cases.append(dict(input_tokens=len(ids),token_ids_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest(),request=request))
    inputs[str(target)]=cases
path=TASK/'continuous-inputs-r1.json'
with path.open('x') as f:
    json.dump(inputs,f,indent=2);f.write('\n')
for role,old in [('B0','retrieval-b0-plan-r2.json'),('B1','retrieval-b1-plan-r1.json')]:
    plan=json.loads((TASK/old).read_text())
    plan.update(schema='fixed018-continuous-supplement/v1',
        output=str(TASK/f'continuous-{role.lower()}-r1'),
        cache=str(TASK/f'continuous-{role.lower()}-cache-r1'),
        input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        inputs='Frozen eight synthetic engineering logs per length; server token hashes must match. Same token sequences and output256/seed17/temperature0.',
        criterion='C8 closed loop,4K then16K,each60s warmup plus300s formal and full drain. Report all 60s windows, nearest-rank P95/P99; no invented numeric stability/SLO pass threshold.',
        qualification='Tokenize all16 exact frozen inputs; retain all errors. No performance-driven config changes.',
        stop='Stop on any failed request, service exit, foreign NPU owner,3 consecutive sampling failures,2GiB disk floor or2400s total deadline; no automatic retries.',
        comparison='Synthetic continuous-stress supplement only. Does not replace five-dataset stability or business quality/SLO acceptance.',
        cache_policy='Fresh independent service/cache per arm; unique salt per request. No prefix-result reuse across requests; read-only weights and OS page cache shared.')
    plan.pop('recovery',None)
    for name in ('continuous_client.py','run_continuous.py','prepare_continuous.py','run_retrieval_b0_r2.py'):
        p=TASK/name
        plan['source_sha256'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
    with (TASK/f'continuous-{role.lower()}-plan-r1.json').open('x') as f:
        json.dump(plan,f,indent=2);f.write('\n')
print('FROZEN_NOT_STARTED', {k:[c['input_tokens'] for c in v] for k,v in inputs.items()})
