"""Rank-local copy execution. Commands share native execution RPC ordering;
receipts use a separate local wakeup channel and never wait for another wave.
"""

from concurrent.futures import ThreadPoolExecutor
import json
import socket

import torch

from betterscale.live.runtime.page_state import PageStateStore
from betterscale.live.runtime.host_state import (
    HostStateDomainSelection,
    HostStateKey,
    HostStateSelection,
    TorchHostStateBackend,
)


class CacheWorker:
    def __init__(self, runner, host_bytes):
        from vllm.distributed import get_tensor_model_parallel_rank

        self.runner = runner
        self.rank = get_tensor_model_parallel_rank()
        self.backend = TorchHostStateBackend(memory_budget_bytes=host_bytes)
        self.page_backend = None
        self.streams = {
            kind: torch.npu.Stream(device=runner.device) for kind in ("store", "load")
        }
        self.waiters = ThreadPoolExecutor(
            max_workers=2, thread_name_prefix="state-cache"
        )
        self.verify = {}
        self.states = tuple(
            (name, state)
            for name, state in runner._live_state_root.named_states()
            if state is not runner._live_state_root.continuation.resident_epoch
        )
        self.inflight = set()

    def submit(self, command):
        root = self.runner._live_state_root
        kind, seat, epoch = (command[k] for k in ("kind", "seat", "epoch"))
        key = HostStateKey(command["key"], 1)
        incremental = "pages" in command
        if incremental and self.page_backend is None:
            self.page_backend = PageStateStore(
                memory_budget_bytes=self.backend.memory_budget_bytes
            )
        if kind == "drop":
            (self.page_backend if incremental else self.backend).release(key)
            self.verify.pop(key, None)
            self._send(command)
            return
        sealed = kind == "seal"
        page_only = kind in ("seal", "reload")
        if not sealed and seat in self.inflight:
            raise RuntimeError("rank already has I/O on this seat")
        if not sealed:
            self.inflight.add(seat)
        stream = self.streams[
            "store" if sealed else "load" if kind == "reload" else kind
        ]
        # execute_model RPC is sequenced behind all already-submitted native
        # frames. Include the separate APC writer, not just forward's stream.
        apc = getattr(self.runner, "_mtp_apc_done", None)
        if apc is not None:
            stream.wait_event(apc)
        producer = torch.npu.Event()
        producer.record(torch.npu.current_stream(self.runner.device))
        stream.wait_event(producer)
        span = command["block_size"] // root.capacity.page_tokens
        if not span or command["block_size"] % root.capacity.page_tokens:
            raise ValueError("scheduler/kernel page ratio is not integral")
        was_verify = False
        if kind == "store":
            was_verify = seat in self.runner._live_previous_verify
        elif kind == "load":
            was_verify = self.verify[key]
        if kind == "load":
            # This write precedes the restore completion event on the same stream.
            with torch.npu.stream(stream):
                root.continuation.resident_epoch.tensor[seat] = epoch
        if incremental:
            objects = {}
            if not page_only:
                objects["resident:" + command["key"]] = HostStateSelection(
                    (HostStateDomainSelection(root.residents, (seat,)),)
                )
            selected = (
                range(len(command["blocks"]))
                if kind in ("store", "seal")
                else command["missing"]
            )
            for i in selected:
                first = command["blocks"][i] * span
                objects[command["pages"][i]] = HostStateSelection(
                    (
                        HostStateDomainSelection(
                            root.pages, tuple(range(first, first + span))
                        ),
                    )
                )
            transfer = self.page_backend.transfer(
                key,
                self.states,
                objects,
                store=kind in ("store", "seal"),
                stream=stream,
                expected_new=(
                    (set() if sealed else {"resident:" + command["key"]})
                    | {command["pages"][i] for i in command["copy_pages"]}
                    if "copy_pages" in command
                    else None
                ),
            )
        else:
            pages = tuple(b * span + k for b in command["blocks"] for k in range(span))
            selection = HostStateSelection(
                (
                    HostStateDomainSelection(root.residents, (seat,)),
                    HostStateDomainSelection(root.pages, pages),
                )
            )
            method = self.backend.offload if kind == "store" else self.backend.restore
            transfer = method(self.states, key, selection, stream=stream)

        def finish(producer=producer):
            try:
                torch.npu.set_device(self.runner.device)
                transfer.result()
                command["_transfer_bytes"] = transfer.byte_length
                if kind == "store":
                    self.verify[key] = was_verify
                elif kind == "load":
                    self.runner._live_resident_epochs[seat] = epoch
                    if was_verify:
                        self.runner._live_previous_verify.add(seat)
                    else:
                        self.runner._live_previous_verify.discard(seat)
                if not sealed:
                    self.inflight.remove(seat)
                self._send(command)
            except BaseException as error:
                self._send(command, repr(error))

        self.waiters.submit(finish)

    def _send(self, command, error=None):
        receipt = {key: command[key] for key in ("operation", "seat", "epoch")}
        receipt.update(rank=self.rank, error=error)
        if "_transfer_bytes" in command:
            receipt["transfer_bytes"] = command["_transfer_bytes"]
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as channel:
            channel.settimeout(30)
            channel.sendto(json.dumps(receipt).encode(), command["endpoint"])


@torch.inference_mode()
def execute_actions(runner, commands):
    if not commands:
        return
    worker = getattr(runner, "_state_cache_worker", None)
    if worker is None:
        worker = runner._state_cache_worker = CacheWorker(
            runner, commands[0]["host_bytes"]
        )
    for command in commands:
        try:
            worker.submit(command)
        except BaseException as error:
            # Never turn an uncertain copy failure into a successful rank ack.
            worker._send(command, repr(error))
            raise
