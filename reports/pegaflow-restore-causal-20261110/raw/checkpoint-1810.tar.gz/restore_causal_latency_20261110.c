#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char **argv){
 int device=argc>1?atoi(argv[1]):1;size_t maximum=128UL*1024*1024;void *host=NULL,*dest=NULL;aclrtStream stream=NULL;aclrtEvent event=NULL;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtMallocHost(&host,maximum));memset(host,0x5a,maximum);CHECK(aclrtMalloc(&dest,maximum,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));CHECK(aclrtCreateEvent(&event));
 CHECK(aclrtMemcpyAsync(dest,maximum,host,maximum,ACL_MEMCPY_HOST_TO_DEVICE,stream));CHECK(aclrtSynchronizeStream(stream));
 size_t amounts[7]={64,65536,1048576,134217728,64,0,0};
 for(int repeat=0;repeat<8;repeat++)for(int step=0;step<7;step++){
  int kind=(step*3+repeat*2)%7;uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  if(kind<4)CHECK(aclrtMemcpyAsync(dest,maximum,host,amounts[kind],ACL_MEMCPY_HOST_TO_DEVICE,stream));
  else if(kind==4)CHECK(aclrtMemsetAsync(dest,maximum,0x5a,64,stream));
  else if(kind==5)CHECK(aclrtRecordEvent(event,stream));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC),endcpu=ns(CLOCK_THREAD_CPUTIME_ID);
  printf("{\"repeat\":%d,\"kind\":%d,\"bytes\":%zu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",repeat,kind,amounts[kind],(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(endcpu-cpu));fflush(stdout);
 }
 unsigned char sample[64];CHECK(aclrtMemcpy(sample,sizeof(sample),dest,sizeof(sample),ACL_MEMCPY_DEVICE_TO_HOST));for(int i=0;i<64;i++)if(sample[i]!=0x5a)return 2;
 CHECK(aclrtDestroyEvent(event));CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(dest));CHECK(aclrtFreeHost(host));CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
