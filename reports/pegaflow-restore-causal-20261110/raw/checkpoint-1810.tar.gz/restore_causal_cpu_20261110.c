#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sys/resource.h>
static volatile uint64_t sink;
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
int main(){
 size_t bytes=128UL*1024*1024;char *src=malloc(bytes),*dst=malloc(bytes);if(!src||!dst)return 1;memset(src,42,bytes);memset(dst,0,bytes);
 pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
 for(int repeat=0;repeat<5;repeat++)for(int kind=0;kind<3;kind++){
  uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);uint64_t x=1234567;
  if(kind==0){for(size_t i=0;i<50000000;i++){x^=x<<13;x^=x>>7;x^=x<<17;}sink=x;}
  else if(kind==1){for(size_t i=0;i<10000000;i++){pthread_mutex_lock(&lock);sink++;pthread_mutex_unlock(&lock);}}
  else{for(int i=0;i<8;i++){memcpy(dst,src,bytes);sink+=(unsigned char)dst[i];}}
  uint64_t end=ns(CLOCK_MONOTONIC),endcpu=ns(CLOCK_THREAD_CPUTIME_ID);
  printf("{\"kind\":%d,\"repeat\":%d,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"sink\":%llu}\n",kind,repeat,(unsigned long long)(end-start),(unsigned long long)(endcpu-cpu),(unsigned long long)sink);fflush(stdout);
 }
 free(src);free(dst);return 0;
}
