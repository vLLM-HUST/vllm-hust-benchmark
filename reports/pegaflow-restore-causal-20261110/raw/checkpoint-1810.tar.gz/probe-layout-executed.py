"""Finite fixed-buffer native IPC restoration crossover on one allocated NPU."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import pickle
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.request

BASE=Path('/data/shared_upload/hust-zsx/restore-causal-20261110')
SOURCE='/data/shared_upload/hust-zsx/long-pd-20261109/source/python'
BINARY='/data/shared_upload/hust-zsx/issue23-scaled-20261014/runtime/bin/pegaflow-server'
PLANES=96
BLOCK_BYTES=262144


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));return sock.getsockname()[1]


def resources():
    return {n:(Path('/sys/fs/cgroup')/n).read_text()
            for n in ['cpu.stat','cpu.pressure','memory.current','memory.events']}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--host',required=True)
    parser.add_argument('--device',type=int,required=True)
    parser.add_argument('--numa',type=int,required=True)
    parser.add_argument('--name',default='initial')
    parser.add_argument('--register',choices=['v1','v2'],default='v1')
    parser.add_argument('--layouts',default='contiguous')
    args=parser.parse_args()
    root=BASE/args.host/f'{args.name}-device{args.device}';root.mkdir(parents=True,exist_ok=False)
    live=Path('/tmp/restore-causal-20261110')/f'{args.name}-device{args.device}';live.mkdir(parents=True,exist_ok=True)
    os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
    os.environ.pop('ASCEND_RT_VISIBLE_DEVICES',None)
    sys.path.insert(0,SOURCE)
    stop=threading.Event();server=None

    def emit(name,row):
        with (root/name).open('a') as stream:stream.write(json.dumps(row)+'\n')

    def monitor():
        while not stop.is_set():
            emit('resources.jsonl',dict(epoch_ns=time.time_ns(),**resources()));stop.wait(1)

    def watchdog():
        if not stop.wait(900):
            (root/'watchdog.json').write_text(json.dumps(dict(epoch=time.time())))
            if server is not None:
                try:os.killpg(server.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            os._exit(124)

    threading.Thread(target=monitor,daemon=True).start()
    threading.Thread(target=watchdog,daemon=True).start()
    try:
        import torch
        import torch_npu
        from pegaflow.npu_ipc_wrapper import NpuIPCWrapper
        from pegaflow.pegaflow import EngineRpcClient,PyLoadState
        torch.set_num_threads(1);torch.npu.set_device(args.device)
        # Fixed real-model geometry: 96 planes, 512 pages each, 256KiB/page.
        planes=[torch.full((512,BLOCK_BYTES//2),.25,dtype=torch.bfloat16,device=f'npu:{args.device}') for _ in range(PLANES)]
        for i,tensor in enumerate(planes):
            tensor.view(torch.int16)[:,0]=((torch.arange(512,device=f'npu:{args.device}',dtype=torch.int32)+i*521+1000)%30000).to(torch.int16)
        torch.npu.synchronize()
        wrappers=[pickle.dumps(NpuIPCWrapper(tensor)) for tensor in planes]
        names=[f'plane-{i}' for i in range(PLANES)]
        instance=f'causal-{args.host}-{args.name}-{args.device}'
        port,http=free_port(),free_port();policy=root/'policy.bin';policy.write_bytes(struct.pack('i',0))
        env=dict(os.environ,PEGAFLOW_SYNC_SAVE='1',TOKIO_WORKER_THREADS='2',PYTHONPATH=SOURCE,
                 LD_LIBRARY_PATH='/usr/local/python3.12.13/lib:'+os.environ.get('LD_LIBRARY_PATH',''),
                 LD_PRELOAD=str(BASE/'memory-policy.so')+':'+str(BASE/'cpu-observer.so')+':'+str(BASE/'register-control.so'),
                 CAUSAL_REGISTER_MODE=args.register,
                 NATIVE_COPY_POLICY=str(policy),NATIVE_COPY_TRACE_LOG=str(live/'api.jsonl'))
        command=['/usr/bin/numactl',f'--membind={args.numa}',BINARY,'--devices',str(args.device),
                 '--pool-size',f'{5*2**30}b','--disable-numa-affinity','--addr',f'127.0.0.1:{port}',
                 '--http-addr',f'127.0.0.1:{http}','--enable-prometheus']
        config=dict(host=args.host,device=args.device,numa=args.numa,command=command,source=SOURCE,
                    planes=PLANES,capacity=512,block_bytes_per_plane=BLOCK_BYTES,pool_bytes=5*2**30,
                    source_blocks=161,counts=[64,161],stage_policies=[0,2,0,2],register=args.register,layouts=args.layouts,
                    torch=torch.__version__,torch_npu=torch_npu.__version__,resources=resources(),
                    pointers=[tensor.data_ptr() for tensor in planes],start_epoch_ns=time.time_ns())
        (root/'config.json').write_text(json.dumps(config,indent=2))
        log=(live/'native.log').open('w')
        server=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        (root/'native-process.json').write_text(json.dumps(dict(pid=server.pid,command=command)))
        deadline=time.monotonic()+90
        while True:
            if server.poll() is not None:raise RuntimeError('Native process exited')
            try:urllib.request.urlopen(f'http://127.0.0.1:{http}/health',timeout=1).read();break
            except OSError:
                if time.monotonic()>deadline:raise TimeoutError('Native startup')
                time.sleep(.2)
        client=EngineRpcClient(f'http://127.0.0.1:{port}')
        ok,message=client.register_context_batch(instance,instance,0,0,1,1,args.device,names,wrappers,
            [512]*PLANES,[BLOCK_BYTES]*PLANES,[0]*PLANES,[1]*PLANES,'ascend_direct',False)
        if not ok:raise RuntimeError(message)
        hashes=[hashlib.sha256(f'{instance}:block:{i}'.encode()).digest() for i in range(161)]
        start=time.monotonic()
        ok,message=client.save(instance,0,0,args.device,[(name,list(range(161)),hashes) for name in names])
        if not ok:raise RuntimeError(message)
        emit('operations.jsonl',dict(event='seed',elapsed_s=time.monotonic()-start,epoch_ns=time.time_ns()))
        counter=0

        def restore(count,phase,mode,layout='contiguous'):
            nonlocal counter
            counter+=1;policy.write_bytes(struct.pack('i',mode))
            destinations=list(range(256,256+count))
            if layout=='reversed':destinations=destinations[::-1]
            elif layout=='random':
                import random
                destinations=random.Random(17).sample(list(range(256,512)),count)
            checks=[0,count//2,count-1]
            for plane in [0,95]:planes[plane].view(torch.int16)[[destinations[i] for i in checks],0]=0
            torch.npu.synchronize()
            query=client.query_prefetch(instance,hashes[:count],f'{instance}-{counter}')
            deadline=time.monotonic()+30
            while not hasattr(query,'num_hit_blocks'):
                if time.monotonic()>deadline:raise TimeoutError('Prefix visibility')
                time.sleep(.005);query=client.query_prefetch(instance,hashes[:count],f'{instance}-{counter}')
            if query.num_hit_blocks!=count:raise RuntimeError(f'Incomplete prefix {query.num_hit_blocks}/{count}')
            state=PyLoadState();before=resources();epoch=time.time_ns();start=time.monotonic()
            ok,message=client.load(instance,0,args.device,state.shm_name(),[names],[(query.lease,[destinations])])
            submitted=time.monotonic()
            if not ok:raise RuntimeError(message)
            deadline=time.monotonic()+180
            while not state.is_ready():
                if time.monotonic()>deadline:raise TimeoutError('Restore exceeds 180s; stop this process before changing policy')
                time.sleep(.001)
            end=time.monotonic()
            if state.get_state()<0:raise RuntimeError('Native restore state error')
            observed=[]
            for plane in [0,95]:
                values=planes[plane].view(torch.int16)[[destinations[i] for i in checks],0].cpu().tolist()
                expected=[(i+plane*521+1000)%30000 for i in checks]
                if values!=expected:raise RuntimeError(f'Copy tags differ: {values} vs {expected}')
                observed.append(values)
            row=dict(event='restore',sequence=counter,phase=phase,policy=mode,layout=layout,blocks=count,
                     bytes=count*PLANES*BLOCK_BYTES,descriptors=count*PLANES,
                     start_epoch_ns=epoch,end_epoch_ns=time.time_ns(),complete_s=end-start,
                     submit_s=submitted-start,verified_tags=observed,resources_before=before,resources_after=resources())
            emit('operations.jsonl',row);print(json.dumps({k:row[k] for k in ['phase','policy','blocks','complete_s']}),flush=True)
        restore(64,'warm-original',0)
        restore(64,'warm-shadow',2)
        for stage,mode in enumerate([0,2,0,2]):
            for count in ([64,161] if stage%2==0 else [161,64]):
                for layout in args.layouts.split(','):restore(count,f'stage-{stage}',mode,layout)
        client.unregister_context(instance)
        (root/'done.json').write_text(json.dumps(dict(epoch=time.time(),restores=counter)))
    except BaseException as error:
        (root/'failure.json').write_text(json.dumps(dict(error=repr(error),traceback=traceback.format_exc(),epoch=time.time())))
        raise
    finally:
        stop.set()
        if server is not None and server.poll() is None:
            os.killpg(server.pid,signal.SIGTERM)
            try:server.wait(10)
            except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
        if live.exists():
            import shutil
            shutil.copytree(live,root/'raw',dirs_exist_ok=True)


if __name__=='__main__':main()
