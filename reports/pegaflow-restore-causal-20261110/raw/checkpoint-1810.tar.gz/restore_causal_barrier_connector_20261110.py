import os
import time
import urllib.request
from pegaflow.connector import PegaKVConnector as Base

class PegaKVConnector(Base):
    def __init__(self,*args,**kwargs):
        deadline=time.monotonic()+180
        while True:
            try:
                urllib.request.urlopen(os.environ['CAUSAL_NATIVE_READY_URL'],timeout=1).read();break
            except OSError:
                if time.monotonic()>deadline:raise TimeoutError('Native CPU pool startup')
                time.sleep(.2)
        super().__init__(*args,**kwargs)
