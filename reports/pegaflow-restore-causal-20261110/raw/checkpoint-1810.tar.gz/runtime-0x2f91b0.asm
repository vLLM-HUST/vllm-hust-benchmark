
/usr/local/Ascend/cann-9.1.0/aarch64-linux/lib64/libruntime_v100.so:     file format elf64-littleaarch64


Disassembly of section .text:

00000000002f91b0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4978>:
  2f91b0:	b9409265 	ldr	w5, [x19, #144]
  2f91b4:	aa2503e1 	mvn	x1, x5
  2f91b8:	f240783f 	tst	x1, #0x7fffffff
  2f91bc:	540009a0 	b.eq	2f92f0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4ab8>  // b.none
  2f91c0:	f9410463 	ldr	x3, [x3, #520]
  2f91c4:	b0fff441 	adrp	x1, 182000 <_ZNSt10_HashtableI12rtMemcpyKindSt4pairIKS0_15tagRtMemcpyKindESaIS4_ENSt8__detail10_Select1stESt8equal_toIS0_ESt4hashIS0_ENS6_18_Mod_range_hashingENS6_20_Default_ranged_hashENS6_20_Prime_rehash_policyENS6_17_Hashtable_traitsILb0ELb0ELb1EEEE21_M_insert_unique_nodeEmmPNS6_10_Hash_nodeIS4_Lb0EEE@@Base+0x1bfa8>
  2f91c8:	9118c021 	add	x1, x1, #0x630
  2f91cc:	eb01007f 	cmp	x3, x1
  2f91d0:	54001881 	b.ne	2f94e0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4ca8>  // b.any
  2f91d4:	9118c000 	add	x0, x0, #0x630
  2f91d8:	39402000 	ldrb	w0, [x0, #8]
  2f91dc:	35000260 	cbnz	w0, 2f9228 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x49f0>
  2f91e0:	2a1703e3 	mov	w3, w23
  2f91e4:	aa1303e1 	mov	x1, x19
  2f91e8:	aa1503e0 	mov	x0, x21
  2f91ec:	97fffe69 	bl	2f8b90 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4358>
  2f91f0:	2a0003f6 	mov	w22, w0
  2f91f4:	f9434694 	ldr	x20, [x20, #1672]
  2f91f8:	2a1603e0 	mov	w0, w22
  2f91fc:	f9403fa2 	ldr	x2, [x29, #120]
  2f9200:	f9400281 	ldr	x1, [x20]
  2f9204:	ca010041 	eor	x1, x2, x1
  2f9208:	b50024e1 	cbnz	x1, 2f96a4 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4e6c>
  2f920c:	a94353f3 	ldp	x19, x20, [sp, #48]
  2f9210:	a9445bf5 	ldp	x21, x22, [sp, #64]
  2f9214:	a9427bfd 	ldp	x29, x30, [sp, #32]
  2f9218:	f9402bf7 	ldr	x23, [sp, #80]
  2f921c:	910283ff 	add	sp, sp, #0xa0
  2f9220:	d65f03c0 	ret
  2f9224:	d503201f 	nop
  2f9228:	f90023b9 	str	x25, [x29, #64]
  2f922c:	aa1303e1 	mov	x1, x19
  2f9230:	aa1503e0 	mov	x0, x21
  2f9234:	97fff201 	bl	2f5a38 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1200>
  2f9238:	794092b9 	ldrh	w25, [x21, #72]
  2f923c:	2a0003f6 	mov	w22, w0
  2f9240:	35001300 	cbnz	w0, 2f94a0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4c68>
  2f9244:	f9001fb8 	str	x24, [x29, #56]
  2f9248:	f9404660 	ldr	x0, [x19, #136]
  2f924c:	f940d018 	ldr	x24, [x0, #416]
  2f9250:	9100d300 	add	x0, x24, #0x34
  2f9254:	885ffc01 	ldaxr	w1, [x0]
  2f9258:	11000421 	add	w1, w1, #0x1
  2f925c:	8802fc01 	stlxr	w2, w1, [x0]
  2f9260:	35ffffa2 	cbnz	w2, 2f9254 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4a1c>
  2f9264:	912d5260 	add	x0, x19, #0xb54
  2f9268:	08dffc00 	ldarb	w0, [x0]
  2f926c:	72001c1f 	tst	w0, #0xff
  2f9270:	54000f01 	b.ne	2f9450 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4c18>  // b.any
  2f9274:	39413aa0 	ldrb	w0, [x21, #78]
  2f9278:	36280a00 	tbz	w0, #5, 2f93b8 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x4b80>
  2f927c:	aa1303e0 	mov	x0, x19
