#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
    int device=argc>1?atoi(argv[1]):1, mapped=argc>2&&!strcmp(argv[2],"mapped");
    size_t bytes=1024UL*1024*1024; void *host=NULL,*dest=NULL,*alias=NULL; aclrtStream stream=NULL;
    CHECK(aclInit(NULL)); CHECK(aclrtSetDevice(device));
    if(mapped) { host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0); if(host==MAP_FAILED)return 2; memset(host,0x5a,bytes); CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias)); }
    else { CHECK(aclrtMallocHost(&host,bytes)); memset(host,0x5a,bytes); }
    CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST)); CHECK(aclrtCreateStream(&stream));
    CHECK(aclrtMemcpyAsync(dest,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream)); CHECK(aclrtSynchronizeStream(stream));
    void *sources[512],*targets[512]; size_t sizes[512],maximum[512];
    int counts[5]={8,64,512,4096,16384};
    for(int repeat=0;repeat<3;repeat++)for(int step=0;step<10;step++) {
        int v=(step*3+repeat*4)%10, direction=v%2, n=counts[v/2]; size_t piece=bytes/n;
        aclrtMemcpyBatchAttr attr={0}; attr.srcLoc.type=direction?ACL_MEM_LOCATION_TYPE_DEVICE:ACL_MEM_LOCATION_TYPE_HOST;
        attr.srcLoc.id=device; attr.dstLoc.type=direction?ACL_MEM_LOCATION_TYPE_HOST:ACL_MEM_LOCATION_TYPE_DEVICE; attr.dstLoc.id=device;
        size_t index=0,failed=0; uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
        for(int offset=0;offset<n;offset+=512) {
            int batch=n-offset; if(batch>512)batch=512;
            for(int j=0;j<batch;j++) { size_t pos=(size_t)(offset+j)*piece; sources[j]=(char*)(direction?dest:host)+pos; targets[j]=(char*)(direction?host:dest)+pos; sizes[j]=maximum[j]=piece; }
            CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,batch,&attr,&index,1,&failed,stream));
        }
        uint64_t submitted=ns(CLOCK_MONOTONIC); CHECK(aclrtSynchronizeStream(stream));
        uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
        printf("{\"repeat\":%d,\"direction\":%d,\"descriptors\":%d,\"bytes\":%zu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",repeat,direction,n,bytes,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu)); fflush(stdout);
        unsigned char sample[64]; CHECK(aclrtMemcpy(sample,64,dest,64,ACL_MEMCPY_DEVICE_TO_HOST)); for(int j=0;j<64;j++)if(sample[j]!=0x5a)return 3;
        for(int j=0;j<64;j++)if(((unsigned char*)host)[j]!=0x5a)return 3;
    }
    CHECK(aclrtDestroyStream(stream)); CHECK(aclrtFree(dest));
    if(mapped) { CHECK(aclrtHostUnregister(host)); munmap(host,bytes); } else CHECK(aclrtFreeHost(host));
    CHECK(aclrtResetDevice(device)); CHECK(aclFinalize()); return 0;
}
