#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
static uint64_t ns(clockid_t id){struct timespec t;clock_gettime(id,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(expr) do{int code=(expr);if(code){fprintf(stderr,"%s=%d\n",#expr,code);return 1;}}while(0)
int main(int argc,char **argv){
 int device=argc>1?atoi(argv[1]):1;int mapped=argc>2&&!strcmp(argv[2],"mapped");size_t bytes=128UL*1024*1024;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));void *host=NULL,*alias=NULL,*dest=NULL;
 if(mapped){host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(host==MAP_FAILED)return 2;memset(host,0x5a,bytes);CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));}
 else{CHECK(aclrtMallocHost(&host,bytes));memset(host,0x5a,bytes);}
 CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));
 uint32_t flags[4]={0,ACL_STREAM_FAST_SYNC,ACL_STREAM_FAST_LAUNCH,ACL_STREAM_FAST_SYNC|ACL_STREAM_FAST_LAUNCH};aclrtStream streams[4]={0};
 for(int i=0;i<4;i++){if(i)CHECK(aclrtCreateStreamWithConfig(&streams[i],0,flags[i]));else CHECK(aclrtCreateStream(&streams[i]));}
 void *src[512],*dst[512];size_t sizes[512],maximum[512];
 for(size_t i=0;i<512;i++){src[i]=(char*)host+i*bytes/512;dst[i]=(char*)dest+i*bytes/512;sizes[i]=maximum[i]=bytes/512;}
 aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;size_t index=0,failed=0;
 for(int repeat=0;repeat<6;repeat++)for(int step=0;step<8;step++){
  int permutation[8]={0,5,2,7,4,1,6,3};int v=permutation[(step+repeat*3)%8],kind=v/2,method=v%2;
  uint64_t epoch=ns(CLOCK_REALTIME),start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  if(method)CHECK(aclrtMemcpyBatchAsync(dst,maximum,src,sizes,512,&attr,&index,1,&failed,streams[kind]));
  else CHECK(aclrtMemcpyAsync(dest,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,streams[kind]));
  uint64_t submit=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(streams[kind]));uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
  unsigned char sample[64];CHECK(aclrtMemcpy(sample,sizeof(sample),dest,sizeof(sample),ACL_MEMCPY_DEVICE_TO_HOST));for(int i=0;i<64;i++)if(sample[i]!=0x5a)return 3;
  printf("{\"device\":%d,\"host\":\"%s\",\"repeat\":%d,\"flags\":%u,\"method\":\"%s\",\"bytes\":%zu,\"start_epoch_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",device,mapped?"mapped":"pinned",repeat,flags[kind],method?"batch512":"bulk",bytes,(unsigned long long)epoch,(unsigned long long)(submit-start),(unsigned long long)(end-submit),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu));fflush(stdout);
 }
 for(int i=0;i<4;i++)CHECK(aclrtDestroyStream(streams[i]));CHECK(aclrtFree(dest));if(mapped){CHECK(aclrtHostUnregister(host));munmap(host,bytes);}else CHECK(aclrtFreeHost(host));CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
