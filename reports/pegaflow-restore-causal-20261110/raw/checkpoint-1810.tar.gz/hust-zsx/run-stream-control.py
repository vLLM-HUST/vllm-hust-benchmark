import subprocess,pathlib,json,time
r=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110/hust-zsx');binary='/data/shared_upload/hust-zsx/restore-causal-20261110/stream-control'
for mode in ['pinned','mapped']:
 with (r/f'stream-control-{mode}.jsonl').open('w') as out,(r/f'stream-control-{mode}.stderr').open('w') as err:
  p=subprocess.run(['/usr/bin/numactl','--membind=2',binary,'1',mode],stdout=out,stderr=err,timeout=120);print(mode,p.returncode,flush=True)
(r/'stream-control-done.json').write_text(json.dumps({'epoch':time.time()}))
