import subprocess,pathlib,json,time,os,signal
b=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110');root=b/'hust-zsx'
out=[]
for memory in ['pinned','mapped']:
 name='layout-direct-v1-'+memory;start=time.time()
 with (root/(name+'.jsonl')).open('w') as f,(root/(name+'.stderr')).open('w') as e:
  p=subprocess.Popen(['/usr/bin/numactl','--membind=2',str(b/'layout-control'),'1',memory],stdout=f,stderr=e,start_new_session=True)
  try:status=p.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();status=124
 out.append(dict(name=name,pid=p.pid,status=status,start=start,end=time.time()))
 (root/'layout-direct-progress.json').write_text(json.dumps(out,indent=2))
