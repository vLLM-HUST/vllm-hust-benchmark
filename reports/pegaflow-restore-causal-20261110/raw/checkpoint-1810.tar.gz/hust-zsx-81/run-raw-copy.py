import pathlib,subprocess,json,time
r=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110/hust-zsx-81')
binary='/data/shared_upload/hust-zsx/restore-card-diag-20261110/bulk-matrix-copy'
for mode in ['mapped','pinned']:
 with (r/f'raw-copy-{mode}.jsonl').open('w') as out,(r/f'raw-copy-{mode}.stderr').open('w') as err:
  p=subprocess.run(['/usr/bin/numactl','--membind=2',binary,'1',mode],stdout=out,stderr=err,timeout=90);print(mode,p.returncode,flush=True)
command=['/usr/local/Ascend/cann-9.1.0/bin/msprof','--task-time=on','--runtime-api=on','--output='+str(r/'raw-copy-profile'),'--application=/usr/bin/numactl --membind=2 '+binary+' 1 pinned']
with (r/'raw-copy-profile.log').open('w') as stream:p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=150)
(r/'raw-copy-profile-done.json').write_text(json.dumps({'returncode':p.returncode,'epoch':time.time()}))
