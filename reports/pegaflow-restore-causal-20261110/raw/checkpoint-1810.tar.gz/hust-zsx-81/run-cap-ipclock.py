import subprocess,pathlib,json,time
r=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110/hust-zsx-81');binary='/data/shared_upload/hust-zsx/restore-card-diag-20261110/bulk-matrix-copy'
for i,drop in enumerate([False,True,False,True]):
 name=f'cap-ipclock-{i}-'+('drop' if drop else 'normal')
 code=f"import pathlib,os;pathlib.Path({str(r)!r},'{name}-status.txt').write_text(pathlib.Path('/proc/self/status').read_text());os.execv({binary!r},[{binary!r},'1','pinned'])"
 command=['/usr/local/python3.12.13/bin/python3','-c',code]
 if drop:command=['/usr/bin/setpriv','--bounding-set=-ipc_lock',*command]
 with (r/(name+'.jsonl')).open('w') as out,(r/(name+'.stderr')).open('w') as err:
  p=subprocess.run(['/usr/bin/numactl','--membind=2',*command],stdout=out,stderr=err,timeout=90)
 print(name,p.returncode,flush=True)
(r/'cap-ipclock-done.json').write_text(json.dumps({'epoch':time.time()}))
