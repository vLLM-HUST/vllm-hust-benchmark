import pathlib,subprocess,json,time,os
b=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110');root=b/'hust-zsx-81'
out=[]
for kind in ['sequence','descriptor']:
 for memory in ['pinned','mapped']:
  start=time.time();name=kind+'-v1-'+memory
  with (root/(name+'.jsonl')).open('w') as f,(root/(name+'.stderr')).open('w') as err:
   p=subprocess.Popen(['/usr/bin/numactl','--membind=2',str(b/(kind+'-control')),'1',memory],stdout=f,stderr=err,start_new_session=True)
   try:code=p.wait(timeout=600)
   except subprocess.TimeoutExpired:
    import signal;os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
  out.append(dict(name=name,pid=p.pid,code=code,start=start,end=time.time()))
  (root/'sequence-descriptor-progress.json').write_text(json.dumps(out,indent=2))
(root/'sequence-descriptor-done.json').write_text(json.dumps(out,indent=2))
