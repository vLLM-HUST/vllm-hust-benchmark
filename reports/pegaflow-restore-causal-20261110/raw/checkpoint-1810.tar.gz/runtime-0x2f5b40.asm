
/usr/local/Ascend/cann-9.1.0/aarch64-linux/lib64/libruntime_v100.so:     file format elf64-littleaarch64


Disassembly of section .text:

00000000002f5b40 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1308>:
  2f5b40:	eb02003f 	cmp	x1, x2
  2f5b44:	54002b21 	b.ne	2f60a8 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1870>  // b.any
  2f5b48:	f941041a 	ldr	x26, [x0, #520]
  2f5b4c:	f947a261 	ldr	x1, [x19, #3904]
  2f5b50:	aa1303e0 	mov	x0, x19
  2f5b54:	79402839 	ldrh	w25, [x1, #20]
  2f5b58:	940210ce 	bl	379e90 <_ZNSt8_Rb_treeIjSt4pairIKjSt5mutexESt10_Select1stIS3_ESt4lessIjESaIS3_EE5eraseERS1_@@Base+0x4b58>
  2f5b5c:	b9504a74 	ldr	w20, [x19, #4168]
  2f5b60:	350027d4 	cbnz	w20, 2f6058 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1820>
  2f5b64:	a90573bb 	stp	x27, x28, [x29, #80]
  2f5b68:	529fffe1 	mov	w1, #0xffff                	// #65535
  2f5b6c:	b94a7a60 	ldr	w0, [x19, #2680]
  2f5b70:	6b20203f 	cmp	w1, w0, uxth
  2f5b74:	54002920 	b.eq	2f6098 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1860>  // b.none
  2f5b78:	0a010000 	and	w0, w0, w1
  2f5b7c:	52900021 	mov	w1, #0x8001                	// #32769
  2f5b80:	11000400 	add	w0, w0, #0x1
  2f5b84:	72b00001 	movk	w1, #0x8000, lsl #16
  2f5b88:	9ba17c01 	umull	x1, w0, w1
  2f5b8c:	d360fc21 	lsr	x1, x1, #32
  2f5b90:	530f7c21 	lsr	w1, w1, #15
  2f5b94:	53103c25 	lsl	w5, w1, #16
  2f5b98:	4b0100a5 	sub	w5, w5, w1
  2f5b9c:	4b050000 	sub	w0, w0, w5
  2f5ba0:	12003c1c 	and	w28, w0, #0xffff
  2f5ba4:	1ad90b94 	udiv	w20, w28, w25
  2f5ba8:	1b19f294 	msub	w20, w20, w25, w28
  2f5bac:	12003e94 	and	w20, w20, #0xffff
  2f5bb0:	2a1403e2 	mov	w2, w20
  2f5bb4:	b94012a4 	ldr	w4, [x21, #16]
  2f5bb8:	2a1c03e3 	mov	w3, w28
  2f5bbc:	f947a260 	ldr	x0, [x19, #3904]
  2f5bc0:	aa1303e1 	mov	x1, x19
  2f5bc4:	94001331 	bl	2fa888 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6050>
  2f5bc8:	79014fbf 	strh	wzr, [x29, #166]
  2f5bcc:	a90affbf 	stp	xzr, xzr, [x29, #168]
  2f5bd0:	aa0003f7 	mov	x23, x0
  2f5bd4:	b50006e0 	cbnz	x0, 2f5cb0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1478>
  2f5bd8:	91029ba0 	add	x0, x29, #0xa6
  2f5bdc:	912d527b 	add	x27, x19, #0xb54
  2f5be0:	f9004fa0 	str	x0, [x29, #152]
  2f5be4:	9102c3a0 	add	x0, x29, #0xb0
  2f5be8:	f9004ba0 	str	x0, [x29, #144]
  2f5bec:	9102a3a0 	add	x0, x29, #0xa8
  2f5bf0:	f90047a0 	str	x0, [x29, #136]
  2f5bf4:	08dfff60 	ldarb	w0, [x27]
  2f5bf8:	72001c1f 	tst	w0, #0xff
  2f5bfc:	aa1303e0 	mov	x0, x19
  2f5c00:	54002701 	b.ne	2f60e0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x18a8>  // b.any
  2f5c04:	940210af 	bl	379ec0 <_ZNSt8_Rb_treeIjSt4pairIKjSt5mutexESt10_Select1stIS3_ESt4lessIjESaIS3_EE5eraseERS1_@@Base+0x4b88>
  2f5c08:	a9488ba1 	ldp	x1, x2, [x29, #136]
  2f5c0c:	aa1303e0 	mov	x0, x19
  2f5c10:	f9404fa3 	ldr	x3, [x29, #152]
  2f5c14:	9402152b 	bl	37b0c0 <_ZNSt8_Rb_treeIjSt4pairIKjSt5mutexESt10_Select1stIS3_ESt4lessIjESaIS3_EE5eraseERS1_@@Base+0x5d88>
  2f5c18:	aa1303e1 	mov	x1, x19
  2f5c1c:	aa1a03e0 	mov	x0, x26
  2f5c20:	97fff576 	bl	2f31f8 <_ZNSt6vectorImSaImEE12emplace_backIJRmEEES3_DpOT_@@Base+0xcf8>
  2f5c24:	aa1503e1 	mov	x1, x21
  2f5c28:	aa1303e0 	mov	x0, x19
  2f5c2c:	940241c1 	bl	386330 <_ZNSt8_Rb_treeIjSt4pairIKjSt5mutexESt10_Select1stIS3_ESt4lessIjESaIS3_EE5eraseERS1_@@Base+0x10ff8>
  2f5c30:	2a0003f4 	mov	w20, w0
  2f5c34:	35003c60 	cbnz	w0, 2f63c0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1b88>
  2f5c38:	aa1303e0 	mov	x0, x19
  2f5c3c:	94021095 	bl	379e90 <_ZNSt8_Rb_treeIjSt4pairIKjSt5mutexESt10_Select1stIS3_ESt4lessIjESaIS3_EE5eraseERS1_@@Base+0x4b58>
  2f5c40:	b9504a74 	ldr	w20, [x19, #4168]
  2f5c44:	35003db4 	cbnz	w20, 2f63f8 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1bc0>
  2f5c48:	b94a7a60 	ldr	w0, [x19, #2680]
  2f5c4c:	529fffe1 	mov	w1, #0xffff                	// #65535
  2f5c50:	6b20203f 	cmp	w1, w0, uxth
  2f5c54:	54001760 	b.eq	2f5f40 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1708>  // b.none
  2f5c58:	0a010005 	and	w5, w0, w1
  2f5c5c:	52900022 	mov	w2, #0x8001                	// #32769
  2f5c60:	110004a5 	add	w5, w5, #0x1
  2f5c64:	72b00002 	movk	w2, #0x8000, lsl #16
  2f5c68:	b94012a4 	ldr	w4, [x21, #16]
  2f5c6c:	aa1303e1 	mov	x1, x19
  2f5c70:	f947a260 	ldr	x0, [x19, #3904]
  2f5c74:	9ba27ca2 	umull	x2, w5, w2
  2f5c78:	d360fc42 	lsr	x2, x2, #32
  2f5c7c:	530f7c42 	lsr	w2, w2, #15
  2f5c80:	53103c43 	lsl	w3, w2, #16
  2f5c84:	4b020062 	sub	w2, w3, w2
  2f5c88:	4b0200a5 	sub	w5, w5, w2
  2f5c8c:	12003cbc 	and	w28, w5, #0xffff
  2f5c90:	2a1c03e3 	mov	w3, w28
  2f5c94:	1ad90b94 	udiv	w20, w28, w25
  2f5c98:	1b19f294 	msub	w20, w20, w25, w28
  2f5c9c:	12003e94 	and	w20, w20, #0xffff
  2f5ca0:	2a1403e2 	mov	w2, w20
  2f5ca4:	940012f9 	bl	2fa888 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6050>
  2f5ca8:	aa0003f7 	mov	x23, x0
  2f5cac:	b4fffa40 	cbz	x0, 2f5bf4 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x13bc>
  2f5cb0:	397d2260 	ldrb	w0, [x19, #3912]
  2f5cb4:	35004060 	cbnz	w0, 2f64c0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x1c88>
  2f5cb8:	d0001c42 	adrp	x2, 67f000 <_ZN3cce7runtime23GetConfigIniValueDoubleERKSsS2_Rd@Base>
  2f5cbc:	790092bc 	strh	w28, [x21, #72]
  2f5cc0:	52800021 	mov	w1, #0x1                   	// #1
  2f5cc4:	aa1503e0 	mov	x0, x21
  2f5cc8:	f946fc42 	ldr	x2, [x2, #3576]
  2f5ccc:	f9400042 	ldr	x2, [x2]
  2f5cd0:	91400842 	add	x2, x2, #0x2, lsl #12
  2f5cd4:	3975a442 	ldrb	w2, [x2, #3433]
  2f5cd8:	390132a2 	strb	w2, [x21, #76]
  2f5cdc:	94001c31 	bl	2fcda0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x8568>
  2f5ce0:	aa1503e1 	mov	x1, x21
  2f5ce4:	aa1703e0 	mov	x0, x23
  2f5ce8:	94001e82 	bl	2fd6f0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x8eb8>
  2f5cec:	f94043b4 	ldr	x20, [x29, #128]
  2f5cf0:	b40000b4 	cbz	x20, 2f5d04 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x14cc>
  2f5cf4:	794096e1 	ldrh	w1, [x23, #74]
  2f5cf8:	794092e0 	ldrh	w0, [x23, #72]
  2f5cfc:	94001ce1 	bl	2fd080 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x8848>
