#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
    int device=argc>1?atoi(argv[1]):1, mapped=argc>2&&!strcmp(argv[2],"mapped");
    size_t bytes=128UL*1024*1024; void *host=NULL,*dest=NULL,*alias=NULL; aclrtStream stream=NULL; aclrtEvent event=NULL;
    CHECK(aclInit(NULL)); CHECK(aclrtSetDevice(device));
    if(mapped) { host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0); if(host==MAP_FAILED)return 2; memset(host,0x5a,bytes); CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias)); }
    else { CHECK(aclrtMallocHost(&host,bytes)); memset(host,0x5a,bytes); }
    CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST)); CHECK(aclrtCreateStream(&stream));
    for(int stage=0;stage<7;stage++) {
        if(stage==3)CHECK(aclrtCreateEvent(&event));
        if(stage==6) { CHECK(aclrtDestroyEvent(event)); event=NULL; }
        for(int repeat=0;repeat<12;repeat++) {
            uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
            CHECK(aclrtMemcpyAsync(dest,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream));
            uint64_t submitted=ns(CLOCK_MONOTONIC); CHECK(aclrtSynchronizeStream(stream));
            uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
            if(stage==1) { unsigned char sample[64]; CHECK(aclrtMemcpy(sample,64,dest,64,ACL_MEMCPY_DEVICE_TO_HOST)); for(int i=0;i<64;i++)if(sample[i]!=0x5a)return 3; }
            if(stage==4) { CHECK(aclrtRecordEvent(event,stream)); CHECK(aclrtSynchronizeStream(stream)); }
            printf("{\"stage\":%d,\"repeat\":%d,\"bytes\":%zu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",stage,repeat,bytes,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu)); fflush(stdout);
        }
    }
    unsigned char sample[64]; CHECK(aclrtMemcpy(sample,64,dest,64,ACL_MEMCPY_DEVICE_TO_HOST)); for(int i=0;i<64;i++)if(sample[i]!=0x5a)return 3;
    CHECK(aclrtDestroyStream(stream)); CHECK(aclrtFree(dest));
    if(mapped) { CHECK(aclrtHostUnregister(host)); munmap(host,bytes); } else CHECK(aclrtFreeHost(host));
    CHECK(aclrtResetDevice(device)); CHECK(aclFinalize()); return 0;
}
