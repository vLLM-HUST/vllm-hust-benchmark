#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

aclError aclrtHostRegister(void *ptr,uint64_t size,aclrtHostRegisterType type,void **alias){
 const char *mode=getenv("CAUSAL_REGISTER_MODE");
 if(mode&&!strcmp(mode,"v2")){
  typedef aclError(*Register)(void *,uint64_t,uint32_t);
  typedef aclError(*Pointer)(void *,void **,uint32_t);
  Register reg=(Register)dlsym(RTLD_NEXT,"aclrtHostRegisterV2");
  Pointer get=(Pointer)dlsym(RTLD_NEXT,"aclrtHostGetDevicePointer");
  if(!reg||!get)return 100000;
  aclError result=reg(ptr,size,ACL_HOST_REG_PINNED|ACL_HOST_REG_MAPPED);
  if(!result)result=get(ptr,alias,0);
  fprintf(stderr,"CAUSAL HostRegisterV2 PINNED|MAPPED bytes=%lu result=%d host=%p alias=%p\n",(unsigned long)size,result,ptr,result?NULL:*alias);
  return result;
 }
 typedef aclError(*Original)(void *,uint64_t,aclrtHostRegisterType,void **);
 Original fn=(Original)dlsym(RTLD_NEXT,"aclrtHostRegister");
 aclError result=fn(ptr,size,type,alias);
 fprintf(stderr,"CAUSAL HostRegisterV1 MAPPED bytes=%lu result=%d host=%p alias=%p\n",(unsigned long)size,result,ptr,result?NULL:*alias);
 return result;
}
