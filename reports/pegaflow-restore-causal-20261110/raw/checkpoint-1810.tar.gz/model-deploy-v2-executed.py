"""Deploy one exact real-model restore instance per host for causal confirmation."""
import argparse
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import time
import urllib.request

BASE=Path('/data/shared_upload/hust-zsx/restore-causal-20261110')
OLD=Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
SOURCE='/data/shared_upload/hust-zsx/long-pd-20261109/source/python'
MODEL='/data/shared_upload/Qwen2.5-14B-Instruct-1M-plainrope'
BINARY='/data/shared_upload/hust-zsx/issue23-scaled-20261014/runtime/bin/pegaflow-server'
PY='/usr/local/python3.12.13/bin/python3'


def port():
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));return sock.getsockname()[1]


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--host',required=True);parser.add_argument('--numa',required=True)
    parser.add_argument('--name',default='model-device0')
    args=parser.parse_args();root=BASE/args.host/args.name;root.mkdir(parents=True,exist_ok=False)
    live=Path('/tmp/restore-causal-20261110')/args.name;live.mkdir(parents=True,exist_ok=True)
    http,grpc,native_http=port(),port(),port();policy=root/'policy.bin';policy.write_bytes(struct.pack('i',0))
    env=dict(os.environ,PYTHONPATH=f'{BASE}:{OLD}:{SOURCE}:'+os.environ.get('PYTHONPATH',''),LD_LIBRARY_PATH='/usr/local/python3.12.13/lib:'+os.environ.get('LD_LIBRARY_PATH',''),
             OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKIO_WORKER_THREADS='2',HF_HUB_OFFLINE='1',
             TOKENIZERS_PARALLELISM='false',VLLM_WORKER_MULTIPROC_METHOD='spawn',VLLM_SERVER_DEV_MODE='1',
             PEGAFLOW_SYNC_SAVE='1',PEGAFLOW_SYNC_SAVE_ON_FINISH='1',PEGAFLOW_ISSUE23_DEFAULT_SCHEDULER='1')
    modelenv=dict(env,ASCEND_RT_VISIBLE_DEVICES='0',SCHEDULING_TRACE_DIR=str(live/'traces'),
                  PEGAFLOW_TELEMETRY_DIR=str(live/'telemetry'),PEGAFLOW_SAVE_ACK_DIR=str(live/'visibility'),
                  PEGAFLOW_TELEMETRY_ROLE='D')
    kv={'kv_connector':'PegaKVConnector','kv_connector_module_path':'pegaflow.connector','kv_role':'kv_both',
        'engine_id':f'causal-model-{args.host}', 'kv_connector_extra_config':{
        'pegaflow.model_revision':'qwen25-14b-1m-plainrope-20261109','pegaflow.transfer_backend':'ascend_direct',
        'pegaflow.mode':'read_write','pegaflow.host':'http://127.0.0.1','pegaflow.port':grpc}}
    command=[PY,'-m','vllm.entrypoints.cli.main','serve',MODEL,'--host','127.0.0.1','--port',str(http),
             '--served-model-name','qwen14','--dtype','bfloat16','--tensor-parallel-size','1','--max-model-len','98304',
             '--max-num-seqs','16','--max-num-batched-tokens','8192','--gpu-memory-utilization','.90',
             '--enable-prefix-caching','--block-size','128','--generation-config','vllm','--no-async-scheduling',
             '--seed','17','--safetensors-load-strategy','eager','--scheduler-cls','restore_card_trace_20261110.TraceScheduler',
             '--compilation-config',json.dumps({'mode':3,'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[1,2,4,8,16]}),
             '--kv-transfer-config',json.dumps(kv)]
    config=dict(host=args.host,device=0,numa=args.numa,http=http,grpc=grpc,native_http=native_http,
                root=str(root),live=str(live),model_command=command,policy=str(policy),epoch=time.time())
    (root/'config.json').write_text(json.dumps(config,indent=2))
    model=subprocess.Popen(command,env=modelenv,stdout=(live/'model.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
    (root/'model-process.json').write_text(json.dumps(dict(pid=model.pid,command=command)))
    native=None;deadline=time.monotonic()+1200
    while time.monotonic()<deadline:
        text=(live/'model.log').read_text(errors='replace')
        if native is None and ('Loading model weights took' in text or 'Creating v1 connector' in text):
            nativeenv=dict(env,LD_PRELOAD=str(BASE/'memory-policy-bounded.so')+':'+str(BASE/'model-observer.so'),
                           NATIVE_COPY_POLICY=str(policy),NATIVE_COPY_TRACE_LOG=str(live/'policy-api.jsonl'),
                           RESTORE_CARD_API_LOG=str(live/'api.jsonl'),RESTORE_CARD_PC_LOG=str(live/'pc.bin'))
            nativecommand=['/usr/bin/numactl',f'--membind={args.numa}',BINARY,'--devices','0',
                           '--pool-size',f'{24*2**30}b','--disable-numa-affinity','--addr',f'127.0.0.1:{grpc}',
                           '--http-addr',f'127.0.0.1:{native_http}','--enable-prometheus']
            native=subprocess.Popen(nativecommand,env=nativeenv,stdout=(live/'native.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
            (root/'native-process.json').write_text(json.dumps(dict(pid=native.pid,command=nativecommand)))
        if model.poll() is not None:raise RuntimeError('Model exited during startup')
        if native is not None and native.poll() is not None:raise RuntimeError('Native exited during startup')
        try:
            if urllib.request.urlopen(f'http://127.0.0.1:{http}/health',timeout=.5).status==200:
                (root/'ready.json').write_text(json.dumps(dict(epoch=time.time())));print('ready',flush=True);return
        except OSError:pass
        time.sleep(2)
    raise TimeoutError('Model startup exceeds 20 minutes')


if __name__=='__main__':
    try:main()
    except BaseException as error:
        import traceback
        print(traceback.format_exc(),flush=True)
        raise
