#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
    int device=argc>1?atoi(argv[1]):1, mapped=argc>2&&!strcmp(argv[2],"mapped");
    size_t block=262144,planes=96,count=161,capacity=512,bytes=block*planes*count,gbytes=block*planes*capacity;
    void *host=NULL,*dest=NULL,*alias=NULL; aclrtStream stream=NULL;
    CHECK(aclInit(NULL)); CHECK(aclrtSetDevice(device));
    if(mapped) { host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0); if(host==MAP_FAILED)return 2; memset(host,0x5a,bytes); CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias)); }
    else { CHECK(aclrtMallocHost(&host,bytes)); memset(host,0x5a,bytes); }
    CHECK(aclrtMalloc(&dest,gbytes,ACL_MEM_MALLOC_HUGE_FIRST)); CHECK(aclrtCreateStream(&stream));
    void *sources[512],*targets[512]; size_t sizes[512],maximum[512];
    for(int repeat=0;repeat<6;repeat++) {
        int direction=repeat%2; aclrtMemcpyBatchAttr attr={0}; attr.srcLoc.type=direction?ACL_MEM_LOCATION_TYPE_DEVICE:ACL_MEM_LOCATION_TYPE_HOST;
        attr.srcLoc.id=device; attr.dstLoc.type=direction?ACL_MEM_LOCATION_TYPE_HOST:ACL_MEM_LOCATION_TYPE_DEVICE; attr.dstLoc.id=device;
        size_t index=0,failed=0; uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
        for(size_t offset=0;offset<count*planes;offset+=512) {
            size_t batch=count*planes-offset; if(batch>512)batch=512;
            for(size_t j=0;j<batch;j++) {
                size_t i=(offset+j)/planes,p=(offset+j)%planes;
                void *h=(char*)host+(i*planes+p)*block;
                void *d=(char*)dest+(p*capacity+256+count-1-i)*block;
                sources[j]=direction?d:h; targets[j]=direction?h:d; sizes[j]=maximum[j]=block;
            }
            uint64_t a=ns(CLOCK_MONOTONIC); CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,batch,&attr,&index,1,&failed,stream));
            printf("{\"event\":\"batch\",\"repeat\":%d,\"offset\":%zu,\"ns\":%llu}\n",repeat,offset,(unsigned long long)(ns(CLOCK_MONOTONIC)-a));fflush(stdout);
        }
        uint64_t submitted=ns(CLOCK_MONOTONIC); CHECK(aclrtSynchronizeStream(stream));
        uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
        printf("{\"event\":\"request\",\"repeat\":%d,\"direction\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",repeat,direction,count*planes,bytes,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu)); fflush(stdout);
        unsigned char sample[64]; CHECK(aclrtMemcpy(sample,64,(char*)dest+256*block,64,ACL_MEMCPY_DEVICE_TO_HOST)); for(int j=0;j<64;j++)if(sample[j]!=0x5a)return 3;
        for(int j=0;j<64;j++)if(((unsigned char*)host)[j]!=0x5a)return 3;
    }
    CHECK(aclrtDestroyStream(stream)); CHECK(aclrtFree(dest));
    if(mapped) { CHECK(aclrtHostUnregister(host)); munmap(host,bytes); } else CHECK(aclrtFreeHost(host));
    CHECK(aclrtResetDevice(device)); CHECK(aclFinalize()); return 0;
}
