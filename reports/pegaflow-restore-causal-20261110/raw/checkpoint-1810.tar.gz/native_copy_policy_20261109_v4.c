#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static int fd = -1;

static uint64_t counter = 0;
__attribute__((constructor)) static void bind_memory_policy(void){
 const char *value=getenv("NATIVE_PROCESS_BIND_NODE");if(!value)return;
 int node=atoi(value);unsigned long mask=1UL<<node;
 long result=syscall(SYS_set_mempolicy,2,&mask,64);
 fprintf(stderr,"Native process MPOL_BIND node=%d result=%ld errno=%d\n",node,result,errno);
 if(result)_exit(126);
}

static uintptr_t host_begin=0,host_end=0;
static void *pinned_shadow=NULL;

static uint64_t stamp(clockid_t kind) {
    struct timespec t;
    clock_gettime(kind, &t);
    return (uint64_t)t.tv_sec * 1000000000ULL + t.tv_nsec;
}

static void *resolve(const char *name) {
    void *fn = dlsym(RTLD_NEXT, name);
    if (!fn) {
        void *lib = dlopen("libascendcl.so", RTLD_NOW | RTLD_LOCAL);
        if (lib) fn = dlsym(lib, name);
    }
    if (!fn) { fprintf(stderr, "copy trace: unresolved %s\n", name); _exit(125); }
    return fn;
}

static uint64_t next_id(void) {
    pthread_mutex_lock(&lock);
    uint64_t id = ++counter;
    pthread_mutex_unlock(&lock);
    return id;
}

static void emit(char *line, size_t size) {
    pthread_mutex_lock(&lock);
    if (fd < 0) {
        const char *path = getenv("NATIVE_COPY_TRACE_LOG");
        if (path) fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
    }
    if (fd >= 0) {
        size_t at = 0;
        while (at < size) {
            ssize_t n = write(fd, line + at, size - at);
            if (n <= 0) break;
            at += n;
        }
    }
    pthread_mutex_unlock(&lock);
    free(line);
}

aclError aclrtHostRegister(void *ptr, uint64_t size, aclrtHostRegisterType type, void **dev) {
    typedef aclError (*Fn)(void *, uint64_t, aclrtHostRegisterType, void **);
    Fn fn = (Fn)resolve("aclrtHostRegister");
    uint64_t start = stamp(CLOCK_MONOTONIC);

    const char *node_value=getenv("NATIVE_POOL_BIND_NODE");
    if(node_value){int node=atoi(node_value);unsigned long mask=1UL<<node;long code=syscall(SYS_mbind,ptr,size,2,&mask,64,2);fprintf(stderr,"Native pool MPOL_BIND node=%d result=%ld errno=%d\n",node,code,errno);if(code)_exit(126);}
    aclError result = fn(ptr,size,type,dev);

    if(!result && size>host_end-host_begin){host_begin=(uintptr_t)ptr;host_end=host_begin+size;}
    char *line = NULL; size_t length = 0; FILE *out = open_memstream(&line, &length);
    fprintf(out, "{\"event\":\"host_register\",\"start_ns\":%llu,\"end_ns\":%llu,\"host\":%llu,\"bytes\":%llu,\"type\":%d,\"device_alias\":%llu,\"result\":%d}\n",
        (unsigned long long)start, (unsigned long long)stamp(CLOCK_MONOTONIC),
        (unsigned long long)(uintptr_t)ptr, (unsigned long long)size, (int)type,
        (unsigned long long)(uintptr_t)(result == 0 && dev ? *dev : NULL), result);
    fclose(out); emit(line, length);
    return result;
}

aclError aclrtMemcpyBatchAsync(void **dst, size_t *max, void **src, size_t *sizes, size_t count,
    aclrtMemcpyBatchAttr *attrs, size_t *indices, size_t attr_count, size_t *fail, aclrtStream stream) {
    typedef aclError (*Fn)(void **,size_t *,void **,size_t *,size_t,aclrtMemcpyBatchAttr *,size_t *,size_t,size_t *,aclrtStream);
    Fn fn = (Fn)resolve("aclrtMemcpyBatchAsync");

    uint64_t id=next_id();int policy=0;const char *file=getenv("NATIVE_COPY_POLICY");
    if(file){int p=open(file,O_RDONLY);if(p>=0){read(p,&policy,sizeof(policy));close(p);}}
    int h2d=1;size_t bytes=0;
    for(size_t i=0;i<count;i++){bytes+=sizes[i];if((uintptr_t)src[i]<host_begin||(uintptr_t)src[i]+sizes[i]>host_end)h2d=0;}
    if(!h2d)policy=0;
    if(policy<0||policy>3)_exit(127);
    void **ss=malloc(count*sizeof(void*)),**dd=malloc(count*sizeof(void*));size_t *sz=malloc(count*sizeof(size_t)),*mx=malloc(count*sizeof(size_t));
    uint64_t start=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID);aclError result=0;
    if(policy>=2 && !pinned_shadow){typedef aclError(*Alloc)(void **,size_t);Alloc alloc=resolve("aclrtMallocHost");result=alloc(&pinned_shadow,host_end-host_begin);}
    if(result){fprintf(stderr,"shadow allocation failed %d\n",result);_exit(127);}
    size_t nout=0;
    for(size_t i=0;i<count;i++){
        void *source=src[i];if(policy>=2){source=(char*)pinned_shadow+((uintptr_t)src[i]-host_begin);memcpy(source,src[i],sizes[i]);}
        if((policy==1||policy==3) && nout && (char*)ss[nout-1]+sz[nout-1]==source && (char*)dd[nout-1]+sz[nout-1]==dst[i]){sz[nout-1]+=sizes[i];mx[nout-1]=sz[nout-1];}
        else{ss[nout]=source;dd[nout]=dst[i];sz[nout]=mx[nout]=sizes[i];nout++;}
    }
    uint64_t prepared=stamp(CLOCK_MONOTONIC),prep_cpu=stamp(CLOCK_THREAD_CPUTIME_ID)-cpu;
    result=fn(dd,mx,ss,sz,nout,attrs,indices,attr_count,fail,stream);
    uint64_t end=stamp(CLOCK_MONOTONIC),cpuend=stamp(CLOCK_THREAD_CPUTIME_ID);
    char *line=NULL;size_t length=0;FILE*out=open_memstream(&line,&length);
    fprintf(out,"{\"event\":\"copy_policy_batch\",\"id\":%llu,\"tid\":%ld,\"stream\":%llu,\"policy\":%d,\"h2d\":%d,\"bytes\":%zu,\"input_count\":%zu,\"output_count\":%zu,\"start_ns\":%llu,\"prepared_ns\":%llu,\"end_ns\":%llu,\"cpu_ns\":%llu,\"prepare_cpu_ns\":%llu,\"result\":%d}\n",(unsigned long long)id,syscall(SYS_gettid),(unsigned long long)(uintptr_t)stream,policy,h2d,bytes,count,nout,(unsigned long long)start,(unsigned long long)prepared,(unsigned long long)end,(unsigned long long)(cpuend-cpu),(unsigned long long)prep_cpu,result);
    fclose(out);emit(line,length);free(ss);free(dd);free(sz);free(mx);return result;
}

aclError aclrtSynchronizeStream(aclrtStream stream) {
    typedef aclError (*Fn)(aclrtStream);
    Fn fn = (Fn)resolve("aclrtSynchronizeStream");
    uint64_t cpu = stamp(CLOCK_THREAD_CPUTIME_ID), start = stamp(CLOCK_MONOTONIC);
    aclError result = fn(stream);
    uint64_t end = stamp(CLOCK_MONOTONIC), cpu_end = stamp(CLOCK_THREAD_CPUTIME_ID);
    char *line = NULL; size_t length = 0; FILE *out = open_memstream(&line, &length);
    fprintf(out, "{\"event\":\"stream_sync\",\"tid\":%ld,\"stream\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"cpu_ns\":%llu,\"result\":%d}\n",
        syscall(SYS_gettid), (unsigned long long)(uintptr_t)stream,
        (unsigned long long)start, (unsigned long long)end, (unsigned long long)(cpu_end-cpu), result);
    fclose(out); emit(line, length);
    return result;
}
