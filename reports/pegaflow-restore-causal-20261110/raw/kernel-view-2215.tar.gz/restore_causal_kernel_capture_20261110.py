from pathlib import Path
import subprocess,os,json,time,threading,signal
base=Path('/data/shared_upload/hust-zsx/restore-causal-20261110');out=base/'hust-zsx-81/kernel-queue-calibration-device0';out.mkdir(exist_ok=False)
procroot=Path('/proc/trs_core/proc');chanroot=Path('/proc/trs_chan/dev5-ts0');core=Path('/proc/trs_core/ts_inst/dev5-ts0')
beforeproc={p.name for p in procroot.iterdir()};beforechan={p.name for p in chanroot.iterdir()};(out/'before.json').write_text(json.dumps({'proc':sorted(beforeproc),'channels':sorted(beforechan)}))
env=os.environ.copy();env.pop('ASCEND_RT_VISIBLE_DEVICES',None);env['LD_PRELOAD']=str(base/'hal-send.so');env['NATIVE_COPY_TRACE_LOG']=str(out/'api.jsonl')
p=subprocess.Popen([str(base/'sq-kernel-calibration'),'0'],env=env,stdout=subprocess.PIPE,stderr=(out/'stderr.log').open('w'),text=True,bufsize=1,start_new_session=True)
(out/'process.json').write_text(json.dumps({'pid':p.pid,'epoch':time.time()}))
ready=threading.Event()
def reader():
 with (out/'stdout.jsonl').open('w') as f:
  for line in p.stdout:
   f.write(line);f.flush()
   if 'ready_for_kernel_observer' in line:ready.set()
t=threading.Thread(target=reader,daemon=True);t.start()
if not ready.wait(20):
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
 raise RuntimeError('No ready marker')
ownedproc=sorted(set(f.name for f in procroot.iterdir())-beforeproc);ownedchan=sorted(set(f.name for f in chanroot.iterdir())-beforechan)
(out/'observed-resources.json').write_text(json.dumps({'proc':ownedproc,'channels':ownedchan}))
paths=[core/'summary',core/'hw_sq']+[chanroot/n for n in ownedchan]
for n in ownedproc:
 d=procroot/n
 if d.exists():
  paths.extend(f for f in d.iterdir() if f.is_file() and f.name in ['summary','hw_sq','stream'])
# Two snapshots before submission, then four during the finite known backlog.
for delay in [0,2.7,.4,.4,.4,.4]:
 time.sleep(delay)
 frame={'epoch_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'pid_live':p.poll() is None,'files':{}}
 for f in paths:
  a=time.monotonic_ns()
  try:frame['files'][str(f)]={'text':f.read_text(),'begin_ns':a,'end_ns':time.monotonic_ns()}
  except OSError as e:frame['files'][str(f)]={'error':repr(e),'begin_ns':a,'end_ns':time.monotonic_ns()}
 with (out/'kernel.jsonl').open('a') as stream:stream.write(json.dumps(frame)+'\n')
try:code=p.wait(20)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);code=p.wait(5)
t.join(2);(out/'done.json').write_text(json.dumps({'returncode':code,'epoch':time.time()}));print('done',code)
