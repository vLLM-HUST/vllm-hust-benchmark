/* Calibrate SQ head/tail against a finite, known in-order DMA backlog. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <ascend_hal.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t k){struct timespec t;clock_gettime(k,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{if(trace_initial){fprintf(stderr,"calling %s\n",#x);fflush(stderr);}int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
static int trace_initial=1;
int main(int argc,char **argv){
 alarm(45);int device=argc>1?atoi(argv[1]):1;const size_t piece=262144,n=512,bytes=piece*n;
 void *host=NULL,*bulk=NULL,*dest=NULL,*readback=malloc(bytes);aclrtStream stream=NULL;
 if(!readback)return 2;CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtMallocHost(&host,bytes));
 memset(host,0x5a,bytes);for(size_t i=0;i<n;i++)*(uint64_t*)((char*)host+i*piece)=i+17;
 CHECK(aclrtMalloc(&bulk,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 void *sources[512],*targets[512];size_t maximum[512],sizes[512];
 for(size_t i=0;i<n;i++){sources[i]=(char*)host+i*piece;targets[i]=(char*)dest+i*piece;maximum[i]=sizes[i]=piece;}
 typedef int(*GetId)(void*,int32_t*);typedef drvError_t(*Details)(uint32_t,struct halResourceIdInputInfo*,struct halResourceDetailInfo*);typedef drvError_t(*Query)(uint32_t,struct halSqCqQueryInfo*);
 GetId getid=(GetId)dlsym(RTLD_DEFAULT,"rtGetStreamId");Details details=(Details)dlsym(RTLD_DEFAULT,"halResourceDetailQuery");Query query=(Query)dlsym(RTLD_DEFAULT,"halSqCqQuery");
 if(!getid||!details||!query){fprintf(stderr,"No query symbols\n");return 4;}
 int32_t id=-1;CHECK(getid(stream,&id));struct halResourceIdInputInfo input={0};input.type=DRV_STREAM_ID;input.tsId=0;input.resourceId=(uint32_t)id;
 struct halResourceDetailInfo detail={0};detail.type=DRV_RES_QUERY_SQID;int detail_error=details(device,&input,&detail);
 printf("{\"event\":\"stream_mapping\",\"runtime_id\":%d,\"error\":%d,\"value0\":%u,\"value1\":%u}\n",id,detail_error,detail.value0,detail.value1);fflush(stdout);if(detail_error)return 5;
 printf("{\"event\":\"ready_for_kernel_observer\",\"pid\":%ld}\n",(long)getpid());fflush(stdout);usleep(3000000);
 trace_initial=0;uint64_t epoch=ns(CLOCK_REALTIME),start=ns(CLOCK_MONOTONIC);
 for(int i=0;i<256;i++)CHECK(aclrtMemcpyAsync(bulk,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream));
 uint64_t bulk_submitted=ns(CLOCK_MONOTONIC);aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;size_t index=0,failed=0;
 CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,n,&attr,&index,1,&failed,stream));uint64_t submitted=ns(CLOCK_MONOTONIC);
 for(int i=0;i<30;i++){
  struct halSqCqQueryInfo info={0};info.type=DRV_NORMAL_TYPE;info.sqId=detail.value0;info.tsId=0;info.prop=DRV_SQCQ_PROP_SQ_HEAD;
  int he=query(device,&info);uint32_t head=info.value[0];memset(info.value,0,sizeof(info.value));info.prop=DRV_SQCQ_PROP_SQ_TAIL;int te=query(device,&info);
  printf("{\"event\":\"known_backlog\",\"monotonic_ns\":%llu,\"sq\":%u,\"head\":%u,\"tail\":%u,\"errors\":[%d,%d]}\n",(unsigned long long)ns(CLOCK_MONOTONIC),detail.value0,head,info.value[0],he,te);fflush(stdout);usleep(20000);
 }
 CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC);
 CHECK(aclrtMemcpy(readback,bytes,dest,bytes,ACL_MEMCPY_DEVICE_TO_HOST));
 for(size_t i=0;i<n;i++)if(*(uint64_t*)((char*)readback+i*piece)!=i+17)return 3;
 printf("{\"epoch_ns\":%llu,\"bulk_tasks\":256,\"small_tasks\":512,\"bulk_bytes\":%zu,\"small_bytes\":%zu,\"bulk_submit_ns\":%llu,\"small_submit_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"verified_tags\":512}\n",(unsigned long long)epoch,256*bytes,bytes,(unsigned long long)(bulk_submitted-start),(unsigned long long)(submitted-bulk_submitted),(unsigned long long)(end-submitted),(unsigned long long)(end-start));fflush(stdout);
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(bulk));CHECK(aclrtFree(dest));CHECK(aclrtFreeHost(host));CHECK(aclrtResetDevice(device));CHECK(aclFinalize());free(readback);return 0;
}
