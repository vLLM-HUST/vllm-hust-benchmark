import pathlib,subprocess,json,time
r=pathlib.Path(__file__).parent
p=subprocess.run(['/usr/bin/ib_read_bw', '-d', 'mlx5_2', '-x', '5', '--report_gbits', '-s', '4096', '-n', '100', '-p', '39898'],capture_output=True,text=True,timeout=45)
(r/"server.json").write_text(json.dumps(dict(exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,epoch=time.time())))
