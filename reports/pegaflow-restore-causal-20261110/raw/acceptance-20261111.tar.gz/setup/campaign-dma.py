"""Replay the earlier four complete sessions with DMA-ready mutable staging."""

import json
import subprocess
import sys
import time
import traceback
import urllib.request
from pathlib import Path

ROOT = Path('/data/shared_upload/hust-zsx/long-pd-dma-20261111')


def record(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2))


def reset(cfg):
    for instance in cfg['instances']:
        host = cfg['hosts'][instance['role']]
        for endpoint in [f"http://{host}:{instance['model_port']}/reset_prefix_cache",
                         f"http://{host}:{instance['http_port']}/cache/memory/cleanup"]:
            with urllib.request.urlopen(urllib.request.Request(endpoint, method='POST'), timeout=30) as response:
                if response.status != 200:
                    raise RuntimeError(f'Cache reset failed: {endpoint}')


def main():
    cfg = json.loads((ROOT / 'config.json').read_text())
    deadline = time.monotonic() + 1500
    while True:
        ready = {}
        for instance in cfg['instances']:
            try:
                endpoint = f"http://{cfg['hosts'][instance['role']]}:{instance['model_port']}/health"
                with urllib.request.urlopen(endpoint, timeout=1) as response:
                    ready[instance['id']] = response.status == 200
            except OSError:
                ready[instance['id']] = False
        record('readiness.json', dict(epoch=time.time(), models=ready))
        if all(ready.values()):
            break
        if time.monotonic() > deadline:
            raise TimeoutError('Four model startup exceeded25min')
        time.sleep(2)
    command = [sys.executable, str(ROOT / 'run.py')]
    reset(cfg)
    subprocess.run(command + ['--smoke', '--label', 'smoke-dma-stage-s17', '--rate', '100'],
                   check=True, timeout=600)
    for routing in ['random', 'sticky']:
        reset(cfg)
        label = f'{routing}-dma-stage-4sessions-rps3-s17'
        record('campaign-current.json', dict(label=label, epoch=time.time(), requests=191))
        subprocess.run(command + ['--label', label, '--routing', routing, '--rate', '3',
                                  '--seed', '17', '--sessions', '4', '--d-pending-budget-gib', '24'],
                       check=True, timeout=1200)
    record('campaign-done.json', dict(epoch=time.time(), formal_requests=382, smoke_requests=4))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        record('campaign-failure.json', dict(epoch=time.time(), error=repr(error),
                                             traceback=traceback.format_exc()))
        raise
