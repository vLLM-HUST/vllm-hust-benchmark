"""Sample owned processes, NIC counters, NPU use and native/model metrics."""
import argparse,concurrent.futures,json,os,subprocess,threading,time,urllib.request
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

ROOT=Path('/data/shared_upload/hust-zsx/long-pd-dma-20261111')

def read(path):
    try:return Path(path).read_text().strip()
    except OSError:return None

def fetch(url):
    try:
        with urllib.request.urlopen(url,timeout=.7) as r:return chr(10).join(line for line in r.read().decode().splitlines() if '_bucket' not in line and not line.startswith('#'))
    except Exception as e:return {'error':str(e)}

class Clock(BaseHTTPRequestHandler):
    def do_GET(self):
        raw=json.dumps({'epoch_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns()}).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(raw)
    def log_message(self,*args):pass

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--node',required=True);args=parser.parse_args()
    cfg=json.loads((ROOT/'config.json').read_text());node=args.node
    endpoints={}
    for i in cfg['instances']:
        if i['role']!=node:continue
        for kind in ['model','engine']:
            port=i['model_port' if kind=='model' else 'http_port']
            endpoints[i['id']+'-'+kind]=f"http://{cfg['hosts'][node]}:{port}/metrics"
    server=ThreadingHTTPServer(('0.0.0.0',38698 if node=='P' else 38699),Clock)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    start=time.monotonic();index=0
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool,(ROOT/'resources'/f'{node}.jsonl').open('a',buffering=65536) as out:
        while time.monotonic()-start<7200 and not (ROOT/'resources'/f'stop-{node}').exists():
            begin=time.monotonic();record={'epoch_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),
                'node':node,'phase':read(ROOT/'phase.json'),'cgroup':{},'processes':[],'rdma':{},'metrics':{}}
            for f in ['cpu.stat','cpu.max','cpu.pressure','memory.current','memory.max','memory.events','memory.pressure','io.pressure']:
                record['cgroup'][f]=read(Path('/sys/fs/cgroup')/f)
            groups=set()
            for p in (ROOT/'services').glob('*.json'):
                j=json.loads(p.read_text())
                if p.stem.startswith(node) and 'pid' in j:groups.add(j['pid'])
            for p in Path('/proc').iterdir():
                if not p.name.isdigit():continue
                try:
                    s=(p/'stat').read_text();fields=s.rsplit(')',1)[1].split()
                    if int(fields[2]) not in groups:continue
                    record['processes'].append({'pid':int(p.name),'stat':s,'status':read(p/'status'),
                                                'schedstat':read(p/'schedstat'),'wchan':read(p/'wchan')})
                except (OSError,ValueError):pass
            for family in ['counters','hw_counters']:
                for p in Path(f'/sys/class/infiniband/mlx5_2/ports/1/{family}').glob('*'):
                    record['rdma'][family+'/'+p.name]=read(p)
            futures={k:pool.submit(fetch,u) for k,u in endpoints.items()}
            if index%2==0:
                try:record['npu_smi']=subprocess.run(['/usr/local/sbin/npu-smi','info'],capture_output=True,text=True,timeout=3).stdout
                except Exception as e:record['npu_error']=str(e)
            record['metrics']={k:f.result() for k,f in futures.items()}
            record['collector_ms']=1000*(time.monotonic()-begin)
            out.write(json.dumps(record)+'\n');out.flush();index+=1
            time.sleep(max(.1,1-(time.monotonic()-begin)))
    server.shutdown()

if __name__=='__main__':main()
