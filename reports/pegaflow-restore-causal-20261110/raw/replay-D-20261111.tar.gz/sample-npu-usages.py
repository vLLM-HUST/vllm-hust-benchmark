"""Finite, read-only accelerator telemetry during the additional real replays."""

import argparse
import json
import subprocess
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--role", choices=("P", "D"), required=True)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    devices = (0, 1) if args.role == "P" else (2, 7)
    deadline = time.monotonic() + 2400
    output = args.root / "resources" / (args.role + "-npu-usages.jsonl")
    with output.open("a") as out:
        while time.monotonic() < deadline:
            if (args.root / "resources/stop-npu-usages").exists():
                break
            if (args.root / "extra-done.json").exists() or (args.root / "extra-failure.json").exists():
                break
            begin = time.monotonic()
            row = dict(epoch_ns=time.time_ns(), monotonic_ns=time.monotonic_ns(), role=args.role, devices={})
            for device in devices:
                try:
                    result = subprocess.run(
                        ["/usr/local/sbin/npu-smi", "info", "-t", "usages", "-i", str(device)],
                        capture_output=True, text=True, timeout=3,
                    )
                    row["devices"][str(device)] = dict(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
                except Exception as error:
                    row["devices"][str(device)] = dict(error=repr(error))
            out.write(json.dumps(row) + "\n")
            out.flush()
            time.sleep(max(0.1, 5 - (time.monotonic() - begin)))


if __name__ == "__main__":
    main()
