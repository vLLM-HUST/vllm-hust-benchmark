import os,time,urllib.request
from pegaflow.connector import PegaKVConnector as Base
class PegaKVConnector(Base):
 def __init__(self,*args,**kwargs):
  deadline=time.monotonic()+120
  while True:
   try:
    if urllib.request.urlopen('http://127.0.0.1:38891/health',timeout=.5).status==200:break
   except OSError:pass
   if time.monotonic()>deadline:raise TimeoutError('Native startup barrier')
   time.sleep(.2)
  super().__init__(*args,**kwargs)
