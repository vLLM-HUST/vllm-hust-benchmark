"""Paired real-model restore and decode-overlap diagnostics on two NPUs."""
import asyncio
import gzip
import json
import pathlib
import statistics
import time

import httpx

ROOT=pathlib.Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
LIVE=pathlib.Path('/tmp/restore-card-diag-20261110')
DATA=pathlib.Path('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz')


def append(path,row):
    with path.open('a') as output:output.write(json.dumps(row)+'\n')


async def main():
    deadline=time.monotonic()+1200
    while not (ROOT/'ready.json').exists():
        if (ROOT/'startup-failure.json').exists():raise RuntimeError('Model startup failed')
        if time.monotonic()>deadline:raise TimeoutError('Services readiness')
        await asyncio.sleep(1)
    with gzip.open(DATA,'rt') as stream:data=[json.loads(line) for line in stream]
    fixtures=[min(data,key=lambda row:abs(row['prompt_tokens']-n)) for n in [8244,14784,44470,61278]]
    (ROOT/'fixtures.json').write_text(json.dumps([{k:v for k,v in row.items() if k!='prompt_token_ids'} for row in fixtures],indent=2))
    cards=json.loads((ROOT/'inventory.json').read_text())['cards'];records=[];counter=0
    async with httpx.AsyncClient(timeout=180,trust_env=False,limits=httpx.Limits(max_connections=24)) as client:
        def url(card):return f'http://127.0.0.1:{38880+card["logical"]}'
        async def reset(card):
            response=await client.post(url(card)+'/reset_prefix_cache');response.raise_for_status()
            (ROOT/'phase.json').write_text(json.dumps({'epoch':time.time(),'phase':'reset','card':card['physical']}))
        async def request(card,index,phase,output=1,first=None,prefix=None):
            nonlocal counter
            counter+=1;physical=card['physical'];key=f'card{physical}-{phase}-{counter:04d}'
            tokens=fixtures[index]['prompt_token_ids']
            if prefix is not None:tokens=tokens[:prefix]
            result={'id':key,'card':physical,'fixture':index,'phase':phase,'prompt_tokens':len(tokens),
                    'output_target':output,'start_epoch_ns':time.time_ns(),'status':'running','token_times_s':[]}
            (ROOT/'phase.json').write_text(json.dumps({'epoch':time.time(),'phase':phase,'card':physical,'id':key}))
            payload={'model':'qwen14','prompt':tokens,'max_tokens':output,'temperature':0,'ignore_eos':True,
                     'seed':17,'request_id':key,'cache_salt':f'card-diag-fixture-{index}',
                     'stream':True,'return_token_ids':True,'stream_options':{'include_usage':True}}
            begin=time.monotonic()
            try:
                async with client.stream('POST',url(card)+'/v1/completions',json=payload) as response:
                    response.raise_for_status();done=False
                    async for line in response.aiter_lines():
                        if not line.startswith('data: '):continue
                        raw=line[6:]
                        if raw=='[DONE]':done=True;break
                        chunk=json.loads(raw)
                        if chunk.get('error'):raise RuntimeError(str(chunk['error']))
                        if chunk.get('usage'):result['usage']=chunk['usage']
                        for choice in chunk.get('choices',[]):
                            if choice.get('token_ids') or choice.get('text'):
                                now=time.monotonic()-begin;result['token_times_s'].append(now)
                                if 'TTFT_s' not in result:
                                    result['TTFT_s']=now
                                    if first:first.set()
                if not done or 'TTFT_s' not in result:raise RuntimeError('No output before stream completed')
                if result.get('usage',{}).get('completion_tokens')!=output:raise RuntimeError('Output budget not completed')
                result['status']='ok'
            except Exception as error:result.update(status='error',error=repr(error))
            finally:
                result['elapsed_s']=time.monotonic()-begin;result['end_epoch_ns']=time.time_ns()
                if first:first.set()
                append(ROOT/'requests.jsonl',result);records.append(result)
                print(json.dumps({k:v for k,v in result.items() if k!='token_times_s'}),flush=True)
            return result
        async def publication(card,result):
            marker=LIVE/f'card{card["physical"]}'/'visibility'/f'{result["id"]}.tp0.visible'
            deadline=time.monotonic()+60
            while not marker.exists():
                if time.monotonic()>deadline:raise TimeoutError('CPU cache publication')
                await asyncio.sleep(.01)
        async def seed(card):
            for i in range(4):
                result=await request(card,i,'seed')
                if result['status']!='ok':raise RuntimeError('Fixture production failed')
                await publication(card,result)
        async def quiet(card,phase,indices):
            for index in indices:
                await reset(card);result=await request(card,index,phase)
                if result['status']!='ok':return False
            return True
        async def drain(card,limit=180):
            deadline=time.monotonic()+limit
            while time.monotonic()<deadline:
                receipt=ROOT/'services'/f'card{card["physical"]}-native.json';pid=json.loads(receipt.read_text())['pid']
                waits=[]
                for path in pathlib.Path(f'/proc/{pid}/task').iterdir():
                    try:
                        if '-load' in (path/'comm').read_text():waits.append((path/'wchan').read_text().strip())
                    except OSError:pass
                if waits and all('futex' in value for value in waits):return True
                await asyncio.sleep(1)
            return False
        # Both cards see the same input and output plans. Cold fixture production
        # is recorded separately from recovery. No unrelated device work runs.
        for card in cards:await seed(card)
        for repeat in range(2):
            for card in (cards if repeat==0 else list(reversed(cards))):
                if not await quiet(card,f'before-{repeat}',[0,2,3]):raise RuntimeError('Baseline failed')
        for card in cards:
            physical=card['physical']
            for repeat,length in enumerate([512,1528]):
                await reset(card)
                prefix=await request(card,2,f'prefix-{repeat}',prefix=23809)
                if prefix['status']!='ok':break
                first=asyncio.Event();decode=asyncio.create_task(request(card,1,f'overlap-decode-{repeat}',output=length,first=first))
                await asyncio.wait_for(first.wait(),timeout=150)
                if decode.done() and decode.result()['status']!='ok':break
                restores=await asyncio.gather(request(card,2,f'overlap-restore-{repeat}'),request(card,0,f'overlap-short-{repeat}'))
                decoded=await decode
                if not await drain(card):
                    (ROOT/f'card{physical}-drain-failure.json').write_text(json.dumps({'epoch':time.time()}));break
                if any(x['status']!='ok' for x in restores+[decoded]):break
            if await drain(card):await quiet(card,'after-overlap',[0,2,0])
        for card in reversed(cards):
            if await drain(card):await quiet(card,'final-crosscheck',[0])
    summary={}
    for card in cards:
        physical=card['physical'];good=[x for x in records if x['card']==physical and x['status']=='ok']
        summary[str(physical)]={'completed':len(good),'failed':sum(x['card']==physical and x['status']!='ok' for x in records),
            'max_TTFT_s':max(x['TTFT_s'] for x in good),'phases':{}}
        for phase in sorted({x['phase'] for x in good}):
            values=[x['TTFT_s'] for x in good if x['phase']==phase]
            summary[str(physical)]['phases'][phase]={'n':len(values),'median':statistics.median(values),'max':max(values)}
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2));(ROOT/'done.json').write_text(json.dumps({'epoch':time.time(),'requests':len(records)}));print(json.dumps(summary),flush=True)


if __name__=='__main__':
    try:asyncio.run(main())
    except BaseException as error:
        import traceback
        (ROOT/'campaign-failure.json').write_text(json.dumps({'epoch':time.time(),'error':repr(error),'traceback':traceback.format_exc()}));raise
