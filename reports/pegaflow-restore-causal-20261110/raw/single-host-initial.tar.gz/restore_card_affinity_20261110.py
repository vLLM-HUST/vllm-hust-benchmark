"""Within-process crossover of CANN submission/recycle CPU placement."""
import gzip
import json
import os
from pathlib import Path
import time

import httpx

ROOT = Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
LIVE = Path('/tmp/restore-card-diag-20261110')


def main():
    pid = json.loads((ROOT/'services/card7-native.json').read_text())['pid']
    tasks = Path(f'/proc/{pid}/task')
    selected = {}
    for task in tasks.iterdir():
        name = (task/'comm').read_text().strip()
        if '-load' in name or name.startswith('RT_RECYCLE'):
            selected[name] = int(task.name)
    original = {tid: os.sched_getaffinity(tid) for tid in selected.values()}
    deadline = time.monotonic()+180
    while time.monotonic()<deadline:
        if all('futex' in (tasks/str(tid)/'wchan').read_text()
               for name, tid in selected.items() if '-load' in name):
            break
        time.sleep(.5)
    else:
        raise TimeoutError('Prior native operation has not drained')
    with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as stream:
        rows = [json.loads(line) for line in stream]
    case = min(rows,key=lambda row:abs(row['prompt_tokens']-8244))
    (LIVE/'card7-order.txt').write_text('original')
    config = dict(native_pid=pid,threads=selected,
                  original_affinity={str(k):sorted(v) for k,v in original.items()},
                  same_numa_node=2,local_cpus=[48,49],remote_cpus=[144,145])
    (ROOT/'affinity-config.json').write_text(json.dumps(config,indent=2))
    try:
        with httpx.Client(timeout=160,trust_env=False) as client:
            for phase in ['unbound','numa-local','numa-remote','unbound-return','numa-local-return']:
                for name,tid in selected.items():
                    if phase.startswith('numa-local'):
                        os.sched_setaffinity(tid,{48 if '-load' in name else 49})
                    elif phase=='numa-remote':
                        os.sched_setaffinity(tid,{144 if '-load' in name else 145})
                    else:
                        os.sched_setaffinity(tid,original[tid])
                for repeat in range(2):
                    key=f'card7-affinity-{phase}-{repeat}'
                    client.post('http://127.0.0.1:38881/reset_prefix_cache').raise_for_status()
                    stat_before=Path('/sys/fs/cgroup/cpu.stat').read_text()
                    epoch=time.time_ns();start=time.monotonic()
                    response=client.post('http://127.0.0.1:38881/v1/completions',json={
                        'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,
                        'ignore_eos':True,'temperature':0,'request_id':key,'cache_salt':'card-diag-fixture-0'})
                    response.raise_for_status();data=response.json()
                    row=dict(id=key,phase=phase,repeat=repeat,start_epoch_ns=epoch,
                             elapsed_s=time.monotonic()-start,end_epoch_ns=time.time_ns(),
                             usage=data.get('usage'),text=data.get('choices',[{}])[0].get('text'),
                             cpu_before=stat_before,cpu_after=Path('/sys/fs/cgroup/cpu.stat').read_text())
                    with (ROOT/'affinity-requests.jsonl').open('a') as stream:
                        stream.write(json.dumps(row)+'\n')
                    print(json.dumps(row),flush=True)
                    if data.get('usage',{}).get('completion_tokens')!=1:
                        raise RuntimeError('Affinity probe incomplete')
    finally:
        for tid,mask in original.items():
            try:os.sched_setaffinity(tid,mask)
            except ProcessLookupError:pass
    (ROOT/'affinity-done.json').write_text(json.dumps(dict(epoch=time.time())))


if __name__=='__main__':
    try:main()
    except BaseException as error:
        import traceback
        (ROOT/'affinity-failure.json').write_text(json.dumps(dict(error=repr(error),traceback=traceback.format_exc())))
        raise
