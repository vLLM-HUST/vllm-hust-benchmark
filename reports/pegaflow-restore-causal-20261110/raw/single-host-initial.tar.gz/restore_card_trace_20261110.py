"""Observe real vLLM steps with bounded idle tracing and optional block layouts."""
import atexit
import json
import os
import time
from pathlib import Path
from vllm.v1.core.sched.scheduler import Scheduler

_file=None

def emit(event,**fields):
    global _file
    if _file is None:
        root=Path(os.environ['SCHEDULING_TRACE_DIR']);root.mkdir(parents=True,exist_ok=True)
        _file=(root/f'{os.getpid()}.jsonl').open('w',buffering=65536);atexit.register(_file.close)
    _file.write(json.dumps({'event':event,'epoch_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**fields},default=str)+'\n')

class TraceScheduler(Scheduler):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.index=0;self.last_idle=time.monotonic();self.empty=0;self.active=set();self.seen=set()
        emit('config',scheduler=repr(self.scheduler_config),kv=repr(self.kv_cache_config))
    def schedule(self):
        self.index+=1;t=time.perf_counter_ns();c=time.thread_time_ns();out=super().schedule()
        if out.num_scheduled_tokens:
            self.active.add(self.index);states={}
            for key,n in out.num_scheduled_tokens.items():
                r=self.requests[key];states[key]={'prompt':r.num_prompt_tokens,'computed':r.num_computed_tokens,'outputs':len(r.output_token_ids)}
                if key not in self.seen:
                    self.seen.add(key)
                    try:states[key]['block_ids']=self.kv_cache_manager.get_block_ids(key)
                    except Exception as error:states[key]['layout_error']=repr(error)
            emit('schedule',step=self.index,wall_ns=time.perf_counter_ns()-t,cpu_ns=time.thread_time_ns()-c,
                 scheduled=out.num_scheduled_tokens,requests=states,waiting=len(self.waiting),running=len(self.running))
        else:
            self.empty+=1
            if time.monotonic()-self.last_idle>=1:
                emit('idle',polls=self.empty,waiting=len(self.waiting),running=len(self.running));self.empty=0;self.last_idle=time.monotonic()
        return out
    def update_from_output(self,scheduled,outputs):
        t=time.perf_counter_ns();result=super().update_from_output(scheduled,outputs)
        if self.index in self.active:
            emit('update',step=self.index,wall_ns=time.perf_counter_ns()-t);self.active.discard(self.index)
        if not self.requests and _file is not None:_file.flush()
        return result
