#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>

static uint64_t ns(clockid_t id){struct timespec t;clock_gettime(id,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(expr) do{aclError code=(expr);if(code){fprintf(stderr,"%s: %d\n",#expr,code);return 1;}}while(0)

int main(int argc,char **argv){
 int device=argc>1?atoi(argv[1]):0;size_t bytes=128UL*1024*1024;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));
 void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*dest=NULL;
 if(host==MAP_FAILED)return 2;
 memset(host,0x5a,bytes);
 CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
 CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));
 aclrtStream stream=NULL;CHECK(aclrtCreateStream(&stream));
 void *src[512],*dst[512];size_t sizes[512],maximum[512];
 for(size_t i=0;i<512;i++){src[i]=(char*)host+i*(bytes/512);dst[i]=(char*)dest+i*(bytes/512);sizes[i]=maximum[i]=bytes/512;}
 aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.srcLoc.id=0;
 attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;
 size_t attr_index=0,failed=0;
 for(int repeat=0;repeat<5;repeat++)for(int mode=0;mode<2;mode++){
  uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  if(mode)CHECK(aclrtMemcpyBatchAsync(dst,maximum,src,sizes,512,&attr,&attr_index,1,&failed,stream));
  else CHECK(aclrtMemcpyAsync(dest,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));
  uint64_t end=ns(CLOCK_MONOTONIC),cpu_end=ns(CLOCK_THREAD_CPUTIME_ID);
  unsigned char check[64];CHECK(aclrtMemcpy(check,sizeof(check),dest,sizeof(check),ACL_MEMCPY_DEVICE_TO_HOST));
  for(int i=0;i<64;i++)if(check[i]!=0x5a)return 3;
  printf("{\"device\":%d,\"mode\":\"%s\",\"repeat\":%d,\"bytes\":%zu,\"api_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"verified\":true}\n",device,mode?"batch512":"bulk",repeat,bytes,(unsigned long long)(submitted-start),(unsigned long long)(end-start),(unsigned long long)(cpu_end-cpu));fflush(stdout);
 }
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);
 CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
