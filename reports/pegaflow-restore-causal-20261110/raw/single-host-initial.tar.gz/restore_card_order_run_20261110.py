"""Reversible same-process descriptor-order experiments and CPU PC sampling."""
import asyncio
import ctypes
import gzip
import json
import pathlib
import signal
import threading
import time

import httpx

ROOT=pathlib.Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
LIVE=pathlib.Path('/tmp/restore-card-diag-20261110')


def append(name,row):
    with (ROOT/name).open('a') as stream:stream.write(json.dumps(row)+'\n')


def sampler(stop):
    receipt=json.loads((ROOT/'services/card7-native.json').read_text());pid=receipt['pid']
    libc=ctypes.CDLL(None);send=libc.tgkill;send.argtypes=[ctypes.c_int]*3;send.restype=ctypes.c_int
    if not (LIVE/'card7-pc.bin').exists():return
    (ROOT/'card7-profile-maps.txt').write_text(pathlib.Path(f'/proc/{pid}/maps').read_text())
    while not stop.is_set():
        for path in pathlib.Path(f'/proc/{pid}/task').iterdir():
            try:
                if '-load' in (path/'comm').read_text():send(pid,int(path.name),signal.SIGUSR2)
            except OSError:pass
        stop.wait(.01)


async def main():
    deadline=time.monotonic()+1200
    while not (ROOT/'order-ready.json').exists():
        if time.monotonic()>deadline:raise TimeoutError('Ordered test model startup')
        await asyncio.sleep(1)
    with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as stream:
        data=[json.loads(line) for line in stream]
    fixtures=[min(data,key=lambda row:abs(row['prompt_tokens']-n)) for n in [8244,14784,44470,61278]]
    url='http://127.0.0.1:38881';counter=0
    async with httpx.AsyncClient(timeout=160,trust_env=False) as client:
        async def request(index,mode,phase,outputs=32,profile=False,reset=True):
            nonlocal counter
            counter+=1;key=f'card7-order-{phase}-{counter:03d}';stop=threading.Event();thread=None
            (LIVE/'card7-order.txt').write_text(mode)
            if reset:
                response=await client.post(url+'/reset_prefix_cache');response.raise_for_status()
            if profile:
                thread=threading.Thread(target=sampler,args=(stop,),daemon=True);thread.start()
            start=time.monotonic();result={'id':key,'phase':phase,'mode':mode,'profiled':profile,
                'fixture':index,'prompt_tokens':fixtures[index]['prompt_tokens'],'start_epoch_ns':time.time_ns(),
                'text':'','token_ids':[],'status':'running'}
            payload={'model':'qwen14','prompt':fixtures[index]['prompt_token_ids'],'max_tokens':outputs,'temperature':0,
                'ignore_eos':True,'seed':17,'cache_salt':f'card-diag-fixture-{index}','request_id':key,
                'stream':True,'return_token_ids':True,'stream_options':{'include_usage':True}}
            try:
                async with client.stream('POST',url+'/v1/completions',json=payload) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if not line.startswith('data: '):continue
                        raw=line[6:]
                        if raw=='[DONE]':break
                        chunk=json.loads(raw)
                        if chunk.get('error'):raise RuntimeError(str(chunk['error']))
                        if chunk.get('usage'):result['usage']=chunk['usage']
                        for choice in chunk.get('choices',[]):
                            result['text']+=choice.get('text') or ''
                            result['token_ids']+=choice.get('token_ids') or []
                            if (choice.get('text') or choice.get('token_ids')) and 'TTFT_s' not in result:result['TTFT_s']=time.monotonic()-start
                if result.get('usage',{}).get('completion_tokens')!=outputs:raise RuntimeError('Output incomplete')
                result['status']='ok'
            except Exception as error:result.update(status='error',error=repr(error))
            finally:
                stop.set()
                if thread:thread.join(2)
                result['elapsed_s']=time.monotonic()-start;result['end_epoch_ns']=time.time_ns()
                append('order-requests.jsonl',result);print(json.dumps(result),flush=True)
            return result
        for index in range(4):
            record=await request(index,'original','seed',outputs=1,reset=False)
            if record['status']!='ok':raise RuntimeError('Ordering fixtures failed')
        plan=[('original',False),('dst',False),('original',True),('dst',False),('src',False),('dst',False),('original',False)]
        for mode,profile in plan:
            record=await request(0,mode,'compare',profile=profile)
            if record['status']!='ok':raise RuntimeError('Ordering probe failed')
        for index in [2,3]:
            record=await request(index,'dst','large')
            if record['status']!='ok':break
        (LIVE/'card7-order.txt').write_text('original')
        (ROOT/'order-done.json').write_text(json.dumps({'epoch':time.time()}))


if __name__=='__main__':
    try:asyncio.run(main())
    except BaseException as error:
        import traceback
        (ROOT/'order-failure.json').write_text(json.dumps({'epoch':time.time(),'error':repr(error),'traceback':traceback.format_exc()}));raise
