"""Plot measured restore stages and the final host-memory allocation controls."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parent.parent/'experiment-results/restore-card-diag-20261110'
data=json.loads((ROOT/'analysis-summary.json').read_text(encoding='utf-8'))
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'axes.unicode_minus':False,
                     'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
rows=data['per_request_native_windows']
selected=[next(r for r in rows if r['id']==key) for key in ['card2-before-0-0010','card7-order-large-012']]
fig,ax=plt.subplots(figsize=(9,4.6),layout='constrained')
labels=['2号卡：原顺序','7号卡：每512条按目标地址排序']
bottom=np.zeros(2)
for name,values,color in [
    ('CANN 拷贝 API 内部',[r['h2d_api_wall_s'] for r in selected],'#377bd4'),
    ('等待 stream 完成',[r['load_sync_wall_s'] for r in selected],'#f49b40'),
    ('其余首 token 路径',[r['TTFT_s']-r['h2d_api_wall_s']-r['load_sync_wall_s'] for r in selected],'#bac7d6')]:
    ax.barh(labels,values,left=bottom,label=name,color=color,height=.5)
    for i,v in enumerate(values):
        if v>2:ax.text(bottom[i]+v/2,i,f'{v:.2f}',ha='center',va='center',color='white',fontweight='bold',fontsize=10)
    bottom+=values
for i,v in enumerate(bottom):ax.text(v+2,i,f'{v:.2f}s',va='center')
ax.set_xlim(0,126);ax.set_xlabel('秒');ax.set_title('44,470-token 完整恢复：耗时主要落在 CANN API 内部',loc='left',pad=18)
ax.legend(loc='center left',bbox_to_anchor=(1.01,.5),frameon=False);ax.invert_yaxis()
fig.text(.01,-.02,'各为一次诊断观测，提交顺序和运行历史不同；此图用于定位阶段，不用于给两张卡排名。',fontsize=10,color='#536175')
fig.savefig(ROOT/'restore-stage-breakdown.png',dpi=180,bbox_inches='tight');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(12,4.7),sharey=True,layout='constrained')
conditions=[('mapped','unbound'),('mapped','local'),('pinned','unbound'),('pinned','local')]
labels=['注册内存\nCPU不绑定','注册内存\nCPU本地','MallocHost\nCPU不绑定','MallocHost\nCPU本地']
colors={2:'#377bd4',7:'#e99a36'}
for ax,mode,title in zip(axes,['bulk','batch512'],['单次大块异步拷贝','512条 × 256KiB 批量拷贝']):
    for card,offset in [(2,-.18),(7,.18)]:
        selected=[next(r for r in data['bulk_matrix'] if r['physical_card']==card and (r['host_allocation'],r['cpu_placement'])==cond)[mode+'_wall_ms'] for cond in conditions]
        median=np.array([r['median'] for r in selected]);lo=np.array([r['min'] for r in selected]);hi=np.array([r['max'] for r in selected])
        xx=np.arange(4)+offset
        ax.bar(xx,median,width=.34,label=f'{card}号卡',color=colors[card],alpha=.9)
        ax.errorbar(xx,median,yerr=[median-lo,hi-median],fmt='none',ecolor='#485264',capsize=3,lw=1)
        for x,v in zip(xx,median):ax.text(x,v+5,f'{v:.0f}',ha='center',fontsize=9)
    ax.set_xticks(range(4),labels);ax.set_title(title,loc='left');ax.set_ylim(0,365);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
axes[0].set_ylabel('128MiB 完成耗时（毫秒）');axes[1].legend(frameon=False)
fig.suptitle('独立拷贝进程：主机内存分配方式对速度有明显影响',ha='left',x=.01,fontsize=15)
fig.text(.01,-.03,'每组4次，首轮预热排除；柱为余下3次的中位数，误差线为最小值至最大值。模型服务已停止。',fontsize=10,color='#536175')
fig.savefig(ROOT/'host-memory-control.png',dpi=180,bbox_inches='tight');plt.close(fig)
print(ROOT)
