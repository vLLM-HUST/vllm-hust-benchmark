"""Summarize bounded native CPU program-counter samples against process maps."""
import collections
import json
import pathlib
import struct
import subprocess

ROOT = pathlib.Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
LIVE = pathlib.Path('/tmp/restore-card-diag-20261110')


def main():
    path = LIVE / 'card7-pc.bin'
    if not path.exists() or not path.stat().st_size:
        print('No samples yet')
        return
    maps = []
    for line in (ROOT / 'card7-profile-maps.txt').read_text().splitlines():
        parts = line.split(maxsplit=5)
        start, end = (int(value, 16) for value in parts[0].split('-'))
        maps.append((start, end, int(parts[2], 16), parts[5] if len(parts) == 6 else 'anonymous'))
    counts = collections.Counter()
    phase_counts = collections.Counter()
    raw = path.read_bytes()
    for stamp, pc, tid, phase in struct.iter_unpack('=QQQQ', raw[:len(raw)//32*32]):
        phase_counts[phase] += 1
        for start, end, offset, name in maps:
            if start <= pc < end:
                counts[name, pc - start + offset, phase] += 1
                break
        else:
            counts['unmapped', pc, phase] += 1
    top = []
    for (name, offset, phase), count in counts.most_common(25):
        symbol = ''
        if pathlib.Path(name).is_file():
            symbol = subprocess.run(['addr2line', '-C', '-f', '-e', name, hex(offset)],
                                    capture_output=True, text=True).stdout.strip()
        top.append(dict(library=name, offset=hex(offset), phase=phase, samples=count, symbol=symbol))
    result = dict(samples=sum(counts.values()), phases=dict(phase_counts), hotspots=top)
    (ROOT / 'pc-summary.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
