"""Query and lease coordination for node-local TP shards."""

from dataclasses import dataclass

from pegaflow.connector.common import RecurrentLoadHold, logger
from pegaflow.pegaflow import EngineRpcClient, QueryLoading, QueryReady


@dataclass(frozen=True, slots=True)
class ShardedQueryReady:
    num_hit_blocks: int
    leases: tuple[bytes, ...]
    # HMA only: per recurrent group, per shard membership leases and their
    # hit positions (see RecurrentLoadHold for the wire/load contract).
    recurrent_hold: RecurrentLoadHold | None = None
    # HMA only: sorted query positions the hit may legally end at (every
    # recurrent group holds a checkpoint there on every shard, below the
    # attention prefix). Drives boundary re-derivation under token clamps.
    usable_positions: tuple[int, ...] = ()
    attention_lease_blocks: int = 0


class TpShardQueryClient:
    def __init__(self, clients: tuple[EngineRpcClient, ...]):
        self._clients = clients
        self._pending: dict[tuple[str, str], tuple[tuple[bytes, ...], list[QueryReady | None]]] = {}
        self._membership_pending: dict[
            tuple[str, str, int], tuple[tuple[bytes, ...], bool, list[QueryReady | None]]
        ] = {}

    def cancel_membership(self, instance_id: str, req_id: str, group_id: int) -> bool:
        pending = self._membership_pending.pop((instance_id, req_id, group_id), None)
        if pending is None:
            return True
        released = True
        for client, result in zip(self._clients, pending[2], strict=True):
            if result is not None:
                released = self._release_one(client, result.lease, req_id) and released
        return released

    def cancel_pending(self, instance_id: str, req_id: str) -> bool:
        pending = self._pending.pop((instance_id, req_id), None)
        if pending is None:
            return True
        released = True
        for client, result in zip(self._clients, pending[1], strict=True):
            if result is not None and not self._release_one(client, result.lease, req_id):
                released = False
        return released

    def query(
        self,
        instance_id: str,
        block_hashes: list[bytes],
        req_id: str,
        wait_for_full_prefix: bool,
    ) -> ShardedQueryReady | None:
        key = (instance_id, req_id)
        identity = tuple(block_hashes)
        previous = self._pending.get(key)
        if previous is not None and previous[0] != identity:
            self.cancel_pending(instance_id, req_id)
            previous = None
        cached = previous[1] if previous is not None else [None] * len(self._clients)
        self._pending[key] = (identity, cached)
        results: list[QueryReady] = []
        try:
            for index, client in enumerate(self._clients):
                result = cached[index]
                if result is None:
                    result = client.query_prefetch(
                        instance_id,
                        block_hashes,
                        req_id=req_id,
                        wait_for_full_prefix=wait_for_full_prefix,
                    )
                if isinstance(result, QueryLoading):
                    # Retain completed shard leases while another shard is
                    # loading. An experiment deliberately bypasses host cache;
                    # releasing Ready here would fetch that shard again.
                    return None
                if not isinstance(result, QueryReady):
                    raise TypeError(f"query_prefetch returned unexpected outcome {type(result)!r}")
                results.append(result)
                cached[index] = result
                self._validate_ready(result, len(block_hashes), len(results) - 1)
        except Exception:
            self.cancel_pending(instance_id, req_id)
            raise

        self._pending.pop(key, None)

        common_blocks = min(result.num_hit_blocks for result in results)
        leases = [result.lease for result in results]
        if common_blocks == 0:
            self.release(tuple(leases), req_id)
            return ShardedQueryReady(0, tuple(b"" for _ in results))

        exact_hashes = block_hashes[:common_blocks]
        try:
            for index, (client, result) in enumerate(zip(self._clients, results, strict=True)):
                if result.num_hit_blocks == common_blocks:
                    continue
                exact = client.query_prefetch(
                    instance_id,
                    exact_hashes,
                    req_id=f"{req_id}:tp-common-{common_blocks}",
                    wait_for_full_prefix=False,
                )
                if not isinstance(exact, QueryReady):
                    raise RuntimeError(
                        f"TP shard {index} could not lease the common {common_blocks}-block prefix"
                    )
                try:
                    self._validate_ready(exact, common_blocks, index)
                    if exact.num_hit_blocks != common_blocks:
                        raise RuntimeError(
                            f"TP shard {index} could not lease the common "
                            f"{common_blocks}-block prefix"
                        )
                except Exception:
                    self._release_one(client, exact.lease, req_id)
                    raise
                old_lease = leases[index]
                leases[index] = exact.lease
                self._release_one(client, old_lease, req_id)
        except Exception:
            self.release(tuple(leases), req_id)
            raise

        return ShardedQueryReady(common_blocks, tuple(leases))

    def query_group_membership(
        self,
        instance_id: str,
        block_hashes: list[bytes],
        req_id: str,
        group_id: int,
        *,
        prefetch: bool = False,
    ) -> list[tuple[tuple[int, ...], bytes]] | None:
        """Per-shard membership query over one hybrid storage group.

        Returns ``(hit_positions, lease)`` per shard; the lease pins exactly
        the hit blocks in positions order. A single-checkpoint remote probe
        retains completed shard leases while its siblings are Loading.
        """
        if prefetch and len(block_hashes) != 1:
            raise ValueError("remote membership prefetch requires one checkpoint hash")
        key = (instance_id, req_id, group_id)
        identity = tuple(block_hashes)
        pending = self._membership_pending.get(key)
        if pending is not None and (pending[0] != identity or pending[1] != prefetch):
            self.cancel_membership(instance_id, req_id, group_id)
            pending = None
        cached = pending[2] if pending is not None else [None] * len(self._clients)
        self._membership_pending[key] = (identity, prefetch, cached)
        try:
            for shard_index, client in enumerate(self._clients):
                result = cached[shard_index]
                if result is None:
                    result = client.query_prefetch(
                        instance_id,
                        block_hashes,
                        req_id=req_id,
                        group_id=group_id,
                        wait_for_full_prefix=prefetch,
                    )
                if isinstance(result, QueryLoading):
                    if prefetch:
                        return None
                    raise RuntimeError("local membership query returned Loading")
                if not isinstance(result, QueryReady):
                    raise TypeError(f"query_prefetch returned unexpected outcome {type(result)!r}")
                cached[shard_index] = result
                positions = tuple(result.hit_positions)
                if len(positions) != result.num_hit_blocks:
                    raise RuntimeError(
                        f"TP shard {shard_index} reported {result.num_hit_blocks} hits "
                        f"but returned {len(positions)} positions"
                    )
                if any(position < 0 or position >= len(block_hashes) for position in positions):
                    raise RuntimeError(
                        f"TP shard {shard_index} returned hit positions outside "
                        f"a {len(block_hashes)}-hash query"
                    )
                if positions and not result.lease:
                    raise RuntimeError(
                        f"TP shard {shard_index} returned {len(positions)} hits without a lease"
                    )
                if positions != tuple(sorted(set(positions))):
                    raise RuntimeError("membership hit positions must be unique and sorted")
                if not positions and result.lease:
                    raise RuntimeError("membership miss must not return a lease")
        except Exception:
            self.cancel_membership(instance_id, req_id, group_id)
            raise
        self._membership_pending.pop(key, None)
        return [
            (tuple(result.hit_positions), result.lease) for result in cached if result is not None
        ]

    def release(self, leases: tuple[bytes, ...], req_id: str) -> bool:
        released = True
        for client, lease in zip(self._clients, leases, strict=False):
            released = self._release_one(client, lease, req_id) and released
        return released

    @staticmethod
    def _validate_ready(result: QueryReady, queried_blocks: int, shard_index: int) -> None:
        if result.num_hit_blocks > queried_blocks:
            raise RuntimeError(
                f"TP shard {shard_index} reported {result.num_hit_blocks} hits for "
                f"a {queried_blocks}-block query"
            )
        if result.num_hit_blocks and not result.lease:
            raise RuntimeError(
                f"TP shard {shard_index} returned {result.num_hit_blocks} hits without a lease"
            )

    @staticmethod
    def _release_one(client: EngineRpcClient, lease: bytes, req_id: str) -> bool:
        if not lease:
            return True
        try:
            client.release(lease)
        except Exception:
            logger.exception(
                "[PegaKVConnector] query lease release exception: req=%s",
                req_id,
            )
            return False
        return True


__all__ = ["ShardedQueryReady", "TpShardQueryClient"]
