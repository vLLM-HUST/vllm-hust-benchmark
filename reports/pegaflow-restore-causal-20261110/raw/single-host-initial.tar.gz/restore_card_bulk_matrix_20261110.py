"""Final finite empty-device CPU placement / host allocation crossover."""
import itertools
import json
import os
from pathlib import Path
import random
import subprocess
import time

ROOT=Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')


def cpu():
    return {name:(Path('/sys/fs/cgroup')/name).read_text()
            for name in ['cpu.stat','cpu.pressure','memory.current','memory.events']}


def main():
    source=(ROOT/'restore_card_bulk_20261110.c').read_text()
    source=source.replace('int device=argc>1?atoi(argv[1]):0;size_t bytes=',
                          'int device=argc>1?atoi(argv[1]):0;int pinned=argc>2&&!strcmp(argv[2],"pinned");size_t bytes=')
    source=source.replace('void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*dest=NULL;',
                          'void *host=NULL,*alias=NULL,*dest=NULL; if(pinned){CHECK(aclrtMallocHost(&host,bytes));}else{host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);}')
    source=source.replace('CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));',
                          'if(!pinned){CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));}')
    source=source.replace('repeat<5','repeat<4')
    source=source.replace('CHECK(aclrtHostUnregister(host));munmap(host,bytes);',
                          'if(pinned){CHECK(aclrtFreeHost(host));}else{CHECK(aclrtHostUnregister(host));munmap(host,bytes);}')
    path=ROOT/'restore_card_bulk_matrix_20261110.c';path.write_text(source)
    command=['gcc','-O2',str(path),'-I/usr/local/Ascend/cann-9.1.0/include',
             '-L/usr/local/Ascend/cann-9.1.0/aarch64-linux/lib64',
             '-Wl,-rpath,/usr/local/Ascend/cann-9.1.0/aarch64-linux/lib64',
             '-lascendcl','-o',str(ROOT/'bulk-matrix-copy')]
    subprocess.run(command,check=True,capture_output=True,text=True)
    plan=list(itertools.product([0,1],['mapped','pinned'],['unbound','local']))
    random.Random(17).shuffle(plan)
    out=ROOT/'bulk-matrix';out.mkdir(exist_ok=True)
    for index,(device,host,placement) in enumerate(plan):
        node=6 if device==0 else 2;name=f'{index:02d}-device{device}-{host}-{placement}'
        cmd=['/usr/bin/numactl',f'--membind={node}']
        if placement=='local':cmd.append(f'--cpunodebind={node}')
        cmd.extend([str(ROOT/'bulk-matrix-copy'),str(device),host])
        record=dict(name=name,device=device,physical_card=2 if device==0 else 7,
                    host_allocation=host,cpu_placement=placement,numa_node=node,command=cmd,
                    start_epoch_ns=time.time_ns(),resources_before=cpu())
        start=time.monotonic()
        with (out/f'{name}.jsonl').open('w') as stdout,(out/f'{name}.stderr').open('w') as stderr:
            result=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=90)
        record.update(returncode=result.returncode,elapsed_s=time.monotonic()-start,
                      end_epoch_ns=time.time_ns(),resources_after=cpu())
        with (ROOT/'bulk-matrix-cases.jsonl').open('a') as stream:stream.write(json.dumps(record)+'\n')
        print(name,result.returncode,record['elapsed_s'],flush=True)
        if result.returncode:raise RuntimeError(f'Matrix case {name} failed')
    (ROOT/'bulk-matrix-done.json').write_text(json.dumps(dict(epoch=time.time())))


if __name__=='__main__':
    try:main()
    except BaseException as error:
        import traceback
        (ROOT/'bulk-matrix-failure.json').write_text(json.dumps(dict(error=repr(error),traceback=traceback.format_exc())))
        raise
