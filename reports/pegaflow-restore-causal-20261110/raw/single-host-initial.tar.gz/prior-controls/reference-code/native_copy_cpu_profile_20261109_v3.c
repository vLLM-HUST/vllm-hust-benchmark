#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <errno.h>
#include <link.h>

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static int fd = -1;
static uint64_t counter = 0;
static uintptr_t registered_begin = 0, registered_end = 0;
static int replay_count = 0, fast_sampled = 0, slow_sampled = 0;
static __thread int replaying = 0, in_batch = 0;
struct Capture {
    void **src, **dst;
    size_t *sizes, *maxs;
    size_t count, capacity;
    uint64_t first_submit_ns;
    aclrtStream stream;
    aclrtMemcpyBatchAttr attrs;
};
static __thread struct Capture capture = {0};
static void run_replays(struct Capture *c);


static uint64_t stamp(clockid_t kind) {
    struct timespec t;
    clock_gettime(kind, &t);
    return (uint64_t)t.tv_sec * 1000000000ULL + t.tv_nsec;
}

static void *resolve(const char *name) {
    void *fn = dlsym(RTLD_NEXT, name);
    if (!fn) {
        void *lib = dlopen("libascendcl.so", RTLD_NOW | RTLD_LOCAL);
        if (lib) fn = dlsym(lib, name);
    }
    if (!fn) { fprintf(stderr, "copy trace: unresolved %s\n", name); _exit(125); }
    return fn;
}


static void emit(char *line,size_t size);
#define PROFILE_LIMIT 1024
static __thread volatile sig_atomic_t profile_on=0, profile_count=0;
static __thread uintptr_t profile_pc[PROFILE_LIMIT],profile_lr[PROFILE_LIMIT];
static __thread uintptr_t profile_frames[PROFILE_LIMIT][8];
static __thread unsigned short queue_head[PROFILE_LIMIT],queue_tail[PROFILE_LIMIT],queue_cap[PROFILE_LIMIT];
static __thread int queue_valid[PROFILE_LIMIT];
static __thread uintptr_t stack_low=0,stack_high=0;
static __thread uintptr_t readable_begin[4096],readable_end[4096];
static __thread int readable_count=0,profile_calls=0;
static uintptr_t runtime_base=0;
static int queue_layout_verified=0;
static pthread_once_t runtime_once=PTHREAD_ONCE_INIT;
static int module_callback(struct dl_phdr_info *info,size_t size,void *data) {
    (void)size;(void)data;
    if(strstr(info->dlpi_name,"libruntime_v100.so"))runtime_base=info->dlpi_addr;
    return 0;
}
static void find_runtime(void) {
    dl_iterate_phdr(module_callback,NULL);
    if(runtime_base) {
        queue_layout_verified=(*(uint32_t *)(runtime_base+0x2fa8a0)==0xaa0003faU &&
          *(uint32_t *)(runtime_base+0x2fa8dc)==0x79402740U &&
          *(uint32_t *)(runtime_base+0x2fa8e0)==0x79402b41U &&
          *(uint32_t *)(runtime_base+0x2fa8e8)==0x79402353U);
    }
}
static void refresh_ranges(void) {
    readable_count=0;
    FILE *maps=fopen("/proc/self/maps","r");if(!maps)return;
    char line[1024],permissions[8];unsigned long lo,hi;
    while(fgets(line,sizeof(line),maps) && readable_count<4096) {
        if(sscanf(line,"%lx-%lx %7s",&lo,&hi,permissions)==3 && permissions[0]=='r') {
            readable_begin[readable_count]=lo;readable_end[readable_count]=hi;readable_count++;
        }
    }
    fclose(maps);
}
static int can_read(uintptr_t p,size_t size) {
    if(p%8 || p+size<p)return 0;
    for(int i=0;i<readable_count;i++)if(p>=readable_begin[i] && p+size<=readable_end[i])return 1;
    return 0;
}
struct ProfileToken { timer_t timer; int active; int error; };
static void profile_signal(int signal, siginfo_t *info, void *context) {
    (void)signal;
    if(!profile_on || info->si_code!=SI_TIMER || profile_count>=PROFILE_LIMIT)return;
    ucontext_t *u=(ucontext_t *)context;
    int index=profile_count;
    profile_pc[index]=(uintptr_t)u->uc_mcontext.pc;
    profile_lr[index]=(uintptr_t)u->uc_mcontext.regs[30];
    uintptr_t fp=(uintptr_t)u->uc_mcontext.regs[29],sp=(uintptr_t)u->uc_mcontext.sp;
    for(int frame=0;frame<8;frame++) {
        profile_frames[index][frame]=0;
        if(fp<sp || fp<stack_low || fp+16>stack_high || fp%16)break;
        uintptr_t next=*(volatile uintptr_t *)fp;
        profile_frames[index][frame]=*(volatile uintptr_t *)(fp+8);
        if(next<=fp)break;
        fp=next;
    }
    queue_valid[index]=0;
    uintptr_t pc=profile_pc[index],lr=profile_lr[index];
    if(queue_layout_verified &&
      ((pc>=runtime_base+0x2fa8a4 && pc<runtime_base+0x2facb0) || lr==runtime_base+0x2fa8d8)) {
        uintptr_t object=(uintptr_t)u->uc_mcontext.regs[26];
        if(can_read(object,24)) {
            uint32_t both=__atomic_load_n((uint32_t *)(object+16),__ATOMIC_RELAXED);
            unsigned short cap=__atomic_load_n((unsigned short *)(object+20),__ATOMIC_RELAXED);
            unsigned short head=both&0xffff,tail=both>>16;
            if(cap>=2 && head<cap && tail<cap) {
                queue_head[index]=head;queue_tail[index]=tail;queue_cap[index]=cap;queue_valid[index]=1;
            }
        }
    }
    profile_count=index+1;
}
__attribute__((constructor)) static void install_profiler(void) {
    struct sigaction previous,action={0};
    sigaction(SIGPROF,NULL,&previous);
    if(previous.sa_handler!=SIG_DFL && previous.sa_handler!=SIG_IGN)return;
    action.sa_sigaction=profile_signal;
    action.sa_flags=SA_SIGINFO|SA_RESTART;
    sigemptyset(&action.sa_mask);
    sigaction(SIGPROF,&action,NULL);
}
static struct ProfileToken profile_begin(void) {
    struct ProfileToken token={0};
    pthread_once(&runtime_once,find_runtime);
    if(!stack_high) {
        pthread_attr_t attr;void *base=NULL;size_t size=0;
        if(!pthread_getattr_np(pthread_self(),&attr)) {
            pthread_attr_getstack(&attr,&base,&size);pthread_attr_destroy(&attr);
            stack_low=(uintptr_t)base;stack_high=stack_low+size;
        }
    }
    if((profile_calls++%64)==0)refresh_ranges();
    struct sigaction current;
    sigaction(SIGPROF,NULL,&current);
    if(current.sa_sigaction!=profile_signal) { token.error=-1;return token; }
    struct sigevent event={0};
    event.sigev_notify=SIGEV_THREAD_ID;
    event.sigev_signo=SIGPROF;
    event._sigev_un._tid=syscall(SYS_gettid);
    profile_count=0;
    if(timer_create(CLOCK_THREAD_CPUTIME_ID,&event,&token.timer)) { token.error=errno;return token; }
    struct itimerspec interval={{0,20000000},{0,20000000}};
    profile_on=1;
    if(timer_settime(token.timer,0,&interval,NULL)) {
        token.error=errno;profile_on=0;timer_delete(token.timer);return token;
    }
    token.active=1;
    return token;
}
static void profile_end(struct ProfileToken token,const char *scope,uint64_t tag) {
    profile_on=0;
    if(token.active) { struct itimerspec off={0};timer_settime(token.timer,0,&off,NULL);timer_delete(token.timer); }
    int n=profile_count;
    char *line=NULL;size_t length=0;FILE *out=open_memstream(&line,&length);
    fprintf(out,"{\"event\":\"cpu_profile\",\"scope\":\"%s\",\"tag\":%llu,\"tid\":%ld,\"error\":%d,\"samples\":[",scope,(unsigned long long)tag,syscall(SYS_gettid),token.error);
    for(int i=0;i<n;i++) {
        Dl_info pc={0},lr={0};dladdr((void *)profile_pc[i],&pc);dladdr((void *)profile_lr[i],&lr);
        fprintf(out,"%s{\"pc\":%llu,\"module\":\"%s\",\"symbol\":\"%s\",\"offset\":%llu,\"lr\":%llu,\"lr_module\":\"%s\",\"lr_symbol\":\"%s\",\"lr_offset\":%llu}",i?",":"",(unsigned long long)profile_pc[i],pc.dli_fname?pc.dli_fname:"",pc.dli_sname?pc.dli_sname:"",(unsigned long long)(profile_pc[i]-(uintptr_t)pc.dli_fbase),(unsigned long long)profile_lr[i],lr.dli_fname?lr.dli_fname:"",lr.dli_sname?lr.dli_sname:"",(unsigned long long)(profile_lr[i]-(uintptr_t)lr.dli_fbase));
        // Replace the sample's closing brace with additional diagnostic fields.
        fseek(out,-1,SEEK_CUR);
        fprintf(out,",\"queue_layout_verified\":%d,\"queue_valid\":%d,\"queue_head\":%u,\"queue_tail\":%u,\"queue_capacity\":%u,\"stack\":[",queue_layout_verified,queue_valid[i],queue_valid[i]?queue_head[i]:0,queue_valid[i]?queue_tail[i]:0,queue_valid[i]?queue_cap[i]:0);
        int emitted=0;
        for(int j=0;j<8 && profile_frames[i][j];j++) {
            Dl_info frame={0};dladdr((void *)profile_frames[i][j],&frame);
            fprintf(out,"%s{\"module\":\"%s\",\"symbol\":\"%s\",\"offset\":%llu}",emitted++?",":"",frame.dli_fname?frame.dli_fname:"",frame.dli_sname?frame.dli_sname:"",(unsigned long long)(profile_frames[i][j]-(uintptr_t)frame.dli_fbase));
        }
        fprintf(out,"]}");
    }
    fprintf(out,"]}\n");fclose(out);emit(line,length);
}

static uint64_t next_id(void) {
    pthread_mutex_lock(&lock);
    uint64_t id = ++counter;
    pthread_mutex_unlock(&lock);
    return id;
}

static void emit(char *line, size_t size) {
    pthread_mutex_lock(&lock);
    if (fd < 0) {
        const char *path = getenv("NATIVE_COPY_TRACE_LOG");
        if (path) fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
    }
    if (fd >= 0) {
        size_t at = 0;
        while (at < size) {
            ssize_t n = write(fd, line + at, size - at);
            if (n <= 0) break;
            at += n;
        }
    }
    pthread_mutex_unlock(&lock);
    free(line);
}

aclError aclrtHostRegister(void *ptr, uint64_t size, aclrtHostRegisterType type, void **dev) {
    typedef aclError (*Fn)(void *, uint64_t, aclrtHostRegisterType, void **);
    Fn fn = (Fn)resolve("aclrtHostRegister");
    uint64_t start = stamp(CLOCK_MONOTONIC);
    aclError result = fn(ptr, size, type, dev);
    if (result == 0 && size > registered_end - registered_begin) {
        registered_begin = (uintptr_t)ptr;
        registered_end = registered_begin + size;
    }
    char *line = NULL; size_t length = 0; FILE *out = open_memstream(&line, &length);
    fprintf(out, "{\"event\":\"host_register\",\"start_ns\":%llu,\"end_ns\":%llu,\"host\":%llu,\"bytes\":%llu,\"type\":%d,\"device_alias\":%llu,\"result\":%d}\n",
        (unsigned long long)start, (unsigned long long)stamp(CLOCK_MONOTONIC),
        (unsigned long long)(uintptr_t)ptr, (unsigned long long)size, (int)type,
        (unsigned long long)(uintptr_t)(result == 0 && dev ? *dev : NULL), result);
    fclose(out); emit(line, length);
    return result;
}

aclError aclrtMemcpyBatchAsync(void **dst, size_t *max, void **src, size_t *sizes, size_t count,
    aclrtMemcpyBatchAttr *attrs, size_t *indices, size_t attr_count, size_t *fail, aclrtStream stream) {
    typedef aclError (*Fn)(void **,size_t *,void **,size_t *,size_t,aclrtMemcpyBatchAttr *,size_t *,size_t,size_t *,aclrtStream);
    Fn fn = (Fn)resolve("aclrtMemcpyBatchAsync");
    if (!replaying && attr_count == 1) {
        int h2d = 1;
        for (size_t i=0;i<count;i++) {
            uintptr_t source = (uintptr_t)src[i], target = (uintptr_t)dst[i];
            if (source < registered_begin || source + sizes[i] > registered_end ||
                (target >= registered_begin && target < registered_end)) h2d = 0;
        }
        if (h2d) {
            if (capture.count && capture.stream != stream) capture.count = 0;
            if (!capture.count) capture.first_submit_ns=stamp(CLOCK_MONOTONIC);
            size_t needed = capture.count + count;
            if (needed > capture.capacity) {
                capture.capacity = needed + 4096;
                capture.src = realloc(capture.src, capture.capacity * sizeof(void *));
                capture.dst = realloc(capture.dst, capture.capacity * sizeof(void *));
                capture.sizes = realloc(capture.sizes, capture.capacity * sizeof(size_t));
                capture.maxs = realloc(capture.maxs, capture.capacity * sizeof(size_t));
                if (!capture.src || !capture.dst || !capture.sizes || !capture.maxs) _exit(126);
            }
            for (size_t i=0;i<count;i++) {
                size_t j = capture.count+i;
                capture.src[j]=src[i]; capture.dst[j]=dst[i];
                capture.sizes[j]=sizes[i]; capture.maxs[j]=max[i];
            }
            capture.count=needed; capture.stream=stream; capture.attrs=attrs[0];
        }
    }
    uint64_t id = next_id();
    char *line = NULL; size_t length = 0; FILE *out = open_memstream(&line, &length);
    fprintf(out, "{\"event\":\"batch_descriptors\",\"id\":%llu,\"tid\":%ld,\"stream\":%llu,\"descriptors\":[",
            (unsigned long long)id, syscall(SYS_gettid), (unsigned long long)(uintptr_t)stream);
    for (size_t i=0;i<count;i++) fprintf(out, "%s[%llu,%llu,%zu]", i ? "," : "",
        (unsigned long long)(uintptr_t)src[i], (unsigned long long)(uintptr_t)dst[i], sizes[i]);
    fprintf(out, "]}\n"); fclose(out); emit(line, length);
    struct rusage before, after;
    getrusage(RUSAGE_THREAD, &before);
    uint64_t cpu = stamp(CLOCK_THREAD_CPUTIME_ID), start = stamp(CLOCK_MONOTONIC);
    struct ProfileToken profile=profile_begin();
    ++in_batch;
    aclError result = fn(dst,max,src,sizes,count,attrs,indices,attr_count,fail,stream);
    --in_batch;
    uint64_t end = stamp(CLOCK_MONOTONIC), cpu_end = stamp(CLOCK_THREAD_CPUTIME_ID);
    getrusage(RUSAGE_THREAD, &after);
    profile_end(profile,"batch",id);
    line = NULL; length = 0; out = open_memstream(&line, &length);
    fprintf(out, "{\"event\":\"batch_complete\",\"id\":%llu,\"tid\":%ld,\"stream\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"cpu_ns\":%llu,\"minor_faults\":%ld,\"major_faults\":%ld,\"voluntary_switches\":%ld,\"involuntary_switches\":%ld,\"count\":%zu,\"result\":%d}\n",
        (unsigned long long)id, syscall(SYS_gettid), (unsigned long long)(uintptr_t)stream,
        (unsigned long long)start, (unsigned long long)end, (unsigned long long)(cpu_end-cpu),
        after.ru_minflt-before.ru_minflt, after.ru_majflt-before.ru_majflt,
        after.ru_nvcsw-before.ru_nvcsw, after.ru_nivcsw-before.ru_nivcsw, count, result);
    fclose(out); emit(line, length);
    return result;
}

aclError aclrtSynchronizeStream(aclrtStream stream) {
    typedef aclError (*Fn)(aclrtStream);
    Fn fn = (Fn)resolve("aclrtSynchronizeStream");
    uint64_t cpu = stamp(CLOCK_THREAD_CPUTIME_ID), start = stamp(CLOCK_MONOTONIC);
    aclError result = fn(stream);
    uint64_t end = stamp(CLOCK_MONOTONIC), cpu_end = stamp(CLOCK_THREAD_CPUTIME_ID);
    char *line = NULL; size_t length = 0; FILE *out = open_memstream(&line, &length);
    fprintf(out, "{\"event\":\"stream_sync\",\"tid\":%ld,\"stream\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"cpu_ns\":%llu,\"result\":%d}\n",
        syscall(SYS_gettid), (unsigned long long)(uintptr_t)stream,
        (unsigned long long)start, (unsigned long long)end, (unsigned long long)(cpu_end-cpu), result);
    fclose(out); emit(line, length);
    if (!replaying && !in_batch && result == 0 && capture.count && capture.stream == stream) {
        run_replays(&capture);
        capture.count=0;
    }
    return result;
}

static void run_replays(struct Capture *c) {
    size_t bytes=0;
    for (size_t i=0;i<c->count;i++) bytes+=c->sizes[i];
    // The finite protocol samples exactly two complete 128-block H2D cohorts.
    const char *armed = getenv("NATIVE_REPLAY_ARM");
    if (!armed || access(armed,F_OK) != 0 || bytes != 939524096ULL) return;
    uint64_t original_ns=stamp(CLOCK_MONOTONIC)-c->first_submit_ns;
    int kind=original_ns<600000000ULL ? 1 : (original_ns>2000000000ULL ? 2 : 0);
    pthread_mutex_lock(&lock);
    int allowed = kind && replay_count < 2 && !(kind==1 ? fast_sampled : slow_sampled);
    int cohort = allowed ? ++replay_count : 0;
    if(allowed) { if(kind==1)fast_sampled=1;else slow_sampled=1; }
    pthread_mutex_unlock(&lock);
    if (!allowed) return;
    typedef aclError (*Batch)(void **,size_t *,void **,size_t *,size_t,aclrtMemcpyBatchAttr *,size_t *,size_t,size_t *,aclrtStream);
    typedef aclError (*Copy)(void *,size_t,const void *,size_t,aclrtMemcpyKind,aclrtStream);
    typedef aclError (*Sync)(aclrtStream);
    Batch batch=(Batch)resolve("aclrtMemcpyBatchAsync");
    Copy copy=(Copy)resolve("aclrtMemcpyAsync");
    Sync sync=(Sync)resolve("aclrtSynchronizeStream");
    typedef aclError (*CopySync)(void *,size_t,const void *,size_t,aclrtMemcpyKind);
    CopySync copy_sync=(CopySync)resolve("aclrtMemcpy");
    uint64_t fingerprint=1469598103934665603ULL;
    for (size_t i=0;i<c->count;i++) {
        fingerprint=(fingerprint ^ (uintptr_t)c->src[i])*1099511628211ULL;
        fingerprint=(fingerprint ^ (uintptr_t)c->dst[i])*1099511628211ULL;
        fingerprint=(fingerprint ^ c->sizes[i])*1099511628211ULL;
    }
    const char *names[]={"batch512_sync_end","batch512_sync_each","async_sync512"};
    int order[6]={1,0,2,2,0,1};
    uint64_t deadline=stamp(CLOCK_MONOTONIC)+180000000000ULL;
    replaying=1;
    for (int trial=0;trial<6 && stamp(CLOCK_MONOTONIC)<deadline;trial++) {
        struct timespec pause={0,200000000}; nanosleep(&pause,NULL);
        int mode=order[(trial+(cohort-1)*3)%6];
        size_t indices[512]={0}, failed=0;
        uint64_t api_wall=0,api_cpu=0,sync_wall=0,sync_cpu=0;
        uint64_t started=stamp(CLOCK_MONOTONIC);
        struct ProfileToken profile=profile_begin();
        aclError result=0;
        for (size_t i=0;i<c->count && !result;i+=512) {
            size_t n=c->count-i; if(n>512)n=512;
            uint64_t wall=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID);
            if(mode==2) {
                for(size_t j=0;j<n && !result;j++)
                    result=copy(c->dst[i+j],c->maxs[i+j],c->src[i+j],c->sizes[i+j],ACL_MEMCPY_HOST_TO_DEVICE,c->stream);
            } else {
                result=batch(c->dst+i,c->maxs+i,c->src+i,c->sizes+i,n,&c->attrs,indices,1,&failed,c->stream);
            }
            api_wall+=stamp(CLOCK_MONOTONIC)-wall;
            api_cpu+=stamp(CLOCK_THREAD_CPUTIME_ID)-cpu;
            if(mode!=0 && !result) {
                wall=stamp(CLOCK_MONOTONIC);cpu=stamp(CLOCK_THREAD_CPUTIME_ID);
                result=sync(c->stream);
                sync_wall+=stamp(CLOCK_MONOTONIC)-wall;
                sync_cpu+=stamp(CLOCK_THREAD_CPUTIME_ID)-cpu;
            }
        }
        uint64_t wall=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID);
        aclError final_result=sync(c->stream);
        sync_wall+=stamp(CLOCK_MONOTONIC)-wall;
        sync_cpu+=stamp(CLOCK_THREAD_CPUTIME_ID)-cpu;
        if(!result)result=final_result;
        if(!result) {
            unsigned char sample[32];
            size_t positions[2]={0,c->count-1};
            for(int check=0;check<2 && !result;check++) {
                size_t pos=positions[check];
                size_t offset=check ? c->sizes[pos]-sizeof(sample) : 0;
                result=copy_sync(sample,sizeof(sample),(char *)c->dst[pos]+offset,sizeof(sample),ACL_MEMCPY_DEVICE_TO_HOST);
                if(!result && memcmp(sample,(char *)c->src[pos]+offset,sizeof(sample))) result=199999;
            }
        }
        uint64_t ended=stamp(CLOCK_MONOTONIC);
        profile_end(profile,"replay",(uint64_t)cohort*100+trial);
        char *line=NULL;size_t length=0;FILE *out=open_memstream(&line,&length);
        fprintf(out,"{\"event\":\"cohort_replay\",\"cohort\":%d,\"original_ns\":%llu,\"trial\":%d,\"method\":\"%s\",\"fingerprint\":%llu,\"count\":%zu,\"bytes\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"api_wall_ns\":%llu,\"api_cpu_ns\":%llu,\"sync_wall_ns\":%llu,\"sync_cpu_ns\":%llu,\"result\":%d}\n",
            cohort,(unsigned long long)original_ns,trial,names[mode],(unsigned long long)fingerprint,c->count,bytes,
            (unsigned long long)started,(unsigned long long)ended,
            (unsigned long long)api_wall,(unsigned long long)api_cpu,
            (unsigned long long)sync_wall,(unsigned long long)sync_cpu,result);
        fclose(out);emit(line,length);
        if(result) { fprintf(stderr,"copy replay failed: %d\n",result);_exit(127); }
    }
    replaying=0;
}
