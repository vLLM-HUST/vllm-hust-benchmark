"""Controlled local restoration through the original PegaFlow native backend."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import random
import signal
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import uuid


ROOT = Path(__file__).resolve().parent
SOURCE = "/data/shared_upload/hust-zsx/pr37-verification-20261015/source/python"
BINARY = "/data/shared_upload/hust-zsx/issue23-scaled-20261014/runtime/bin/pegaflow-server"
PLANES = 96
PLANE_BLOCK_BYTES = 262144


def read_resource():
    row = {"epoch_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}
    for name in ["cpu.stat", "memory.current", "memory.events", "cpu.pressure", "memory.pressure"]:
        p = Path("/sys/fs/cgroup") / name
        if p.exists():
            row[name] = p.read_text().strip()
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="native-matrix")
    parser.add_argument("--repeats", type=int, default=8)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--source-layouts", action="store_true")
    parser.add_argument("--randomized-overlap", action="store_true")
    args = parser.parse_args()
    out = ROOT / args.name
    out.mkdir(exist_ok=False)
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ.pop("ASCEND_RT_VISIBLE_DEVICES", None)
    sys.path.insert(0, SOURCE)
    server = None
    server_log = None
    monitor_stop = threading.Event()
    compute_stop = threading.Event()
    compute_thread = None
    compute_progress = {"groups": 0, "error": None}
    compute_active = threading.Event()
    compute_idle = threading.Event()

    def monitor():
        with (out / "resources.jsonl").open("w") as f:
            while not monitor_stop.is_set():
                f.write(json.dumps(read_resource()) + "\n")
                f.flush()
                monitor_stop.wait(.5)

    def monitor_npu():
        with (out / "npu.jsonl").open("w") as f:
            while not monitor_stop.is_set():
                try:
                    p = subprocess.run(["npu-smi", "info"], capture_output=True, text=True, timeout=5)
                    f.write(json.dumps({"epoch_ns": time.time_ns(), "returncode": p.returncode,
                                        "stdout": p.stdout, "stderr": p.stderr}) + "\n")
                    f.flush()
                except Exception as error:
                    f.write(json.dumps({"epoch_ns": time.time_ns(), "error": str(error)}) + "\n")
                monitor_stop.wait(3)

    def watchdog():
        if not monitor_stop.wait(1000):
            (out / "watchdog.json").write_text(json.dumps(read_resource()))
            if server is not None and server.poll() is None:
                os.killpg(server.pid, signal.SIGTERM)
            os.kill(os.getpid(), signal.SIGTERM)

    threading.Thread(target=monitor, daemon=True).start()
    threading.Thread(target=monitor_npu, daemon=True).start()
    threading.Thread(target=watchdog, daemon=True).start()
    try:
        import torch
        import torch_npu
        import pegaflow
        from pegaflow.pegaflow import EngineRpcClient, PyLoadState
        from pegaflow.npu_ipc_wrapper import NpuIPCWrapper

        torch.set_num_threads(1)
        torch.npu.set_device(0)
        config = {
            "scope": "Local PegaFlow RPC, shared pinned CPU cache and imported NPU KV planes",
            "torch": torch.__version__, "torch_npu": torch_npu.__version__,
            "pegaflow": pegaflow.__version__, "source": SOURCE, "binary": BINARY,
            "planes": PLANES, "block_bytes_per_plane": PLANE_BLOCK_BYTES,
            "repeats": args.repeats, "seed": 20261028,
            "hostname": Path("/etc/hostname").read_text().strip(),
            "CANN": os.environ.get("ASCEND_HOME_PATH"),
            "initial_resources": read_resource(), "initial_npu_memory": torch.npu.mem_get_info(),
        }
        (out / "environment.json").write_text(json.dumps(config, indent=2))
        # The exported buffers and saved CPU cache objects remain fixed across layouts.
        planes = [torch.full((512, 128, 8, 128), .25, dtype=torch.bfloat16, device="npu:0") for _ in range(PLANES)]
        torch.npu.synchronize()
        wrappers = [pickle.dumps(NpuIPCWrapper(t)) for t in planes]
        names = [f"layer-{i // 2}-{'K' if i % 2 == 0 else 'V'}" for i in range(PLANES)]
        instance = "restore-diagnosis-" + uuid.uuid4().hex[:10]
        env = dict(os.environ, PEGAFLOW_SYNC_SAVE="1", PYTHONPATH=SOURCE,
                   LD_LIBRARY_PATH="/usr/local/python3.12.13/lib:" + os.environ.get("LD_LIBRARY_PATH", ""))
        command = [BINARY, "--devices", "0", "--pool-size", "4gb", "--disable-numa-affinity",
                   "--addr", "127.0.0.1:38150", "--http-addr", "127.0.0.1:38190", "--enable-prometheus"]
        server_log = (out / "native-server.log").open("w")
        server = subprocess.Popen(command, stdout=server_log, stderr=subprocess.STDOUT,
                                  env=env, start_new_session=True, cwd=out)
        (out / "server-process.json").write_text(json.dumps({"pid": server.pid, "command": command}))
        deadline = time.monotonic() + 40
        while True:
            if server.poll() is not None:
                raise RuntimeError("Owned native server exited during startup")
            try:
                urllib.request.urlopen("http://127.0.0.1:38190/health", timeout=1).read()
                break
            except Exception:
                if time.monotonic() > deadline:
                    raise TimeoutError("Native startup deadline")
                time.sleep(.2)
        client = EngineRpcClient("http://127.0.0.1:38150")
        ok, message = client.register_context_batch(
            instance, "restore-qwen25-geometry", 0, 0, 1, 1, 0,
            names, wrappers, [512] * PLANES, [PLANE_BLOCK_BYTES] * PLANES,
            [0] * PLANES, [1] * PLANES, "ascend_direct", False,
        )
        if not ok:
            raise RuntimeError(message)
        hashes = [hashlib.sha256(f"fixed-native-object-{i}".encode()).digest() for i in range(128)]
        source_hashes = {"bulk128": hashes}
        began = time.monotonic()
        ok, message = client.save(instance, 0, 0, 0, [(n, list(range(128)), hashes) for n in names])
        if not ok:
            raise RuntimeError(message)
        print(json.dumps({"event": "saved", "seconds": time.monotonic() - began}), flush=True)
        if args.source_layouts:
            for group, chunk, shuffled in [("chunk16", 16, False), ("per-block", 1, False), ("shuffled-block", 1, True)]:
                group_hashes = [hashlib.sha256(f"{group}-{i}".encode()).digest() for i in range(128)]
                source_hashes[group] = group_hashes
                order = list(range(128))
                if shuffled:
                    random.Random(41).shuffle(order)
                began = time.monotonic()
                for offset in range(0, 128, chunk):
                    indices = order[offset:offset + chunk]
                    ok, message = client.save(instance, 0, 0, 0,
                        [(n, indices, [group_hashes[i] for i in indices]) for n in names])
                    if not ok:
                        raise RuntimeError(message)
                print(json.dumps({"event": "saved", "source_group": group, "save_group_size": chunk,
                                  "shuffled_insertion": shuffled, "seconds": time.monotonic() - began}), flush=True)
        sequence = 0
        result_file = (out / "operations.jsonl").open("w")

        def restore(count, layout, phase, repeat, source_group="bulk128"):
            nonlocal sequence
            sequence += 1
            if layout == "contiguous":
                destinations = list(range(256, 256 + count))
            elif layout == "strided":
                destinations = list(range(256, 256 + 2 * count, 2))
            elif layout == "reversed":
                destinations = list(range(256, 256 + count))[::-1]
            else:
                destinations = random.Random(17).sample(list(range(256, 512)), count)
            # Corrupt one destination to establish that completion restores saved data.
            planes[0][destinations[0]].zero_()
            torch.npu.synchronize()
            query_start = time.monotonic_ns()
            query_hashes = source_hashes[source_group][:count]
            q = client.query_prefetch(instance, query_hashes, f"diagnostic-{sequence}")
            deadline = time.monotonic() + 15
            while not hasattr(q, "num_hit_blocks"):
                if time.monotonic() > deadline:
                    raise TimeoutError("Local prefix lookup deadline")
                time.sleep(.001)
                q = client.query_prefetch(instance, query_hashes, f"diagnostic-{sequence}")
            if q.num_hit_blocks != count:
                raise RuntimeError(f"Incomplete hit {q.num_hit_blocks}/{count}")
            state = PyLoadState()
            start_ns = time.time_ns()
            began = time.monotonic_ns()
            cpu = time.process_time_ns()
            ok, message = client.load(instance, 0, 0, state.shm_name(), [names], [(q.lease, [destinations])])
            submitted = time.monotonic_ns()
            if not ok:
                raise RuntimeError(message)
            deadline = time.monotonic() + 30
            polls = 0
            while not state.is_ready():
                if time.monotonic() > deadline:
                    raise TimeoutError("Native completion deadline")
                polls += 1
                time.sleep(.0005)
            ended = time.monotonic_ns()
            if state.get_state() < 0:
                raise RuntimeError("Native load state error")
            observed = float(planes[0][destinations[0]].reshape(-1)[0].item())
            if observed != .25:
                raise ValueError(f"Native copy pattern differs: {observed}")
            row = {"sequence": sequence, "phase": phase, "repeat": repeat,
                   "source_group": source_group,
                   "blocks": count, "layout": layout, "start_epoch_ns": start_ns,
                   "end_epoch_ns": time.time_ns(), "bytes": count * PLANES * PLANE_BLOCK_BYTES,
                   "query_s": (began - query_start) / 1e9,
                   "submit_s": (submitted - began) / 1e9, "complete_s": (ended - began) / 1e9,
                   "CPU_s": (time.process_time_ns() - cpu) / 1e9, "polls": polls,
                   "destination_runs": 1 + sum(b != a + 1 for a, b in zip(destinations, destinations[1:])),
                   "compute_groups": compute_progress["groups"], "sample_value": observed}
            result_file.write(json.dumps(row) + "\n")
            result_file.flush()
            print(json.dumps(row), flush=True)

        counts = [25, 128]
        layouts = ["contiguous", "random"]
        for count in counts:
            restore(count, "contiguous", "warmup", -1)
        phases = ["idle-before"]
        a = b = c = None
        for phase in phases:
            if phase in ["compute-overlap", "randomized-onoff"]:
                a = torch.randn((4096, 4096), dtype=torch.bfloat16, device="npu:0")
                b = torch.randn_like(a)
                c = torch.empty_like(a)
                torch.mm(a, b, out=c)
                torch.npu.synchronize()

                def compute():
                    try:
                        torch.npu.set_device(0)
                        stream = torch.npu.Stream()
                        with torch.npu.stream(stream):
                            while not compute_stop.is_set():
                                if args.randomized_overlap and not compute_active.wait(.01):
                                    compute_idle.set()
                                    continue
                                compute_idle.clear()
                                for _ in range(8):
                                    torch.mm(a, b, out=c)
                                stream.synchronize()
                                compute_progress["groups"] += 1
                    except BaseException:
                        compute_progress["error"] = traceback.format_exc()

                compute_thread = threading.Thread(target=compute)
                compute_thread.start()
                time.sleep(2)
            elif phase == "idle-after":
                compute_stop.set()
                compute_thread.join(20)
                if compute_thread.is_alive() or compute_progress["error"]:
                    raise RuntimeError(str(compute_progress))
                torch.npu.synchronize()
            plan = [(count, layout, repeat, group, active) for repeat in range(args.repeats)
                    for count in counts for layout in layouts for group in source_hashes
                    for active in ([False, True] if args.randomized_overlap else [False])]
            random.Random(20261028).shuffle(plan)
            for count, layout, repeat, group, active in plan:
                measured_phase = phase
                if args.randomized_overlap:
                    if active:
                        compute_active.set()
                        time.sleep(.08)
                    else:
                        compute_active.clear()
                        if not compute_idle.wait(3):
                            raise TimeoutError("Compute did not become idle")
                    measured_phase = "randomized-compute" if active else "randomized-idle"
                restore(count, layout, measured_phase, repeat, group)
        result_file.close()
        client.unregister_context(instance)
        (out / "done.json").write_text(json.dumps({"operations": sequence, "compute": compute_progress,
                                                   "final_resources": read_resource()}, indent=2))
    except BaseException as error:
        (out / "failure.json").write_text(json.dumps({"error": str(error), "traceback": traceback.format_exc()}, indent=2))
        raise
    finally:
        compute_stop.set()
        if compute_thread is not None:
            compute_thread.join(15)
        if server is not None and server.poll() is None:
            os.killpg(server.pid, signal.SIGTERM)
            try:
                server.wait(8)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL)
                server.wait()
        if server_log is not None:
            server_log.close()
        monitor_stop.set()


if __name__ == "__main__":
    main()
