
import pathlib,json,os,signal,subprocess,time,urllib.request
import restore_card_deploy_20261110 as base
r=base.ROOT;live=base.LIVE;card=json.loads((r/'inventory.json').read_text())['cards'][1]
(live/'card7-order.txt').write_text('original')
original_start=base.start
def start(name,cmd,e):
 if name.endswith('-native'):
  e['LD_PRELOAD']=str(r/'librestore-card-sorted-api.so')+':'+os.environ.get('LD_PRELOAD','')
  e['RESTORE_CARD_API_LOG']=str(live/'card7-order-api.jsonl')
  e['RESTORE_CARD_ORDER_FILE']=str(live/'card7-order.txt')
  e['RESTORE_CARD_PC_LOG']=str(live/'card7-pc.bin')
 else:
  cmd[cmd.index('--safetensors-load-strategy')+1]='eager'
  i=cmd.index('--kv-transfer-config')+1;kv=json.loads(cmd[i]);kv['kv_connector_module_path']='restore_card_barrier_connector_20261110';cmd[i]=json.dumps(kv)
 return original_start(name,cmd,e)
base.start=start
model=base.model(card);native=None;deadline=time.monotonic()+900
while time.monotonic()<deadline:
 text=(live/'card7-model.log').read_text(errors='replace')
 if native is None and ('Loading model weights took' in text or 'Creating v1 connector' in text):native=base.native(card)
 if model.poll() is not None:raise RuntimeError('Restarted model exited')
 if native is not None and native.poll() is not None:raise RuntimeError('Restarted native exited')
 try:
  if urllib.request.urlopen('http://127.0.0.1:38881/health',timeout=.5).status==200:
   (r/'order-ready.json').write_text(json.dumps({'epoch':time.time(),'model':model.pid,'native':native.pid}));print('ordered path ready',flush=True);break
 except OSError:pass
 time.sleep(1)
else:raise TimeoutError('Restart readiness')
