# PegaFlow Ascend 缓存恢复异常：单机双卡实验与交接报告

日期：2026-11-10，北京时间。实测采集约为 15:05–16:19，随后整理、导出证据。

## 1. 接手者先读这几段

我们正在研究 P/D 分离推理中的缓存传输与性能，并建设模拟器。但近期真实实验出现了一个必须先解释的异常：**KV 已经通过 RDMA 到达 D 的 CPU 内存，随后从 CPU 恢复到 NPU 的阶段，有时不到一秒，有时几十秒甚至超过 120 秒。** 这会污染网络瓶颈研究，也会使模拟器严重低估 TTFT。

本轮用户提供一机双卡，要求先复现、比较两张卡，再进行详细遥测归因。当前这一轮已经结束：完成了 40 个模型请求和 104 次独立拷贝计时；实验服务已停止，原始数据已保存到共享目录和本机。**底层唯一根因尚未闭环，尚未得到可交付的恢复性能修复。**

当前最可靠的结论如下：

1. **单机、不经过 RDMA，也能复现严重慢恢复，两张卡都出现过。** 44,470-token 请求的首 token 分别等了 93.37 秒和 112.11 秒，其中 85.09 秒和 104.69 秒在原始 CANN 批拷贝调用内部。
2. **慢窗口中的 CPU 配额没有用尽。** 检查了两段慢恢复窗口及 10 个逐请求窗口，限流计数均未增加；不能把本次慢恢复解释为容器用完 CPU 时间片而被暂停。不过，一个恢复线程确实可以在 CANN 内部持续消耗单核 CPU，这与“容器全部 8 核配额耗尽”是两回事。
3. **提交阶段存在大量活跃 CPU 消耗，采样指向锁／重试；同步阶段则主要是主动等待。** 尚未拿到足以唯一识别内部锁、任务池或驱动资源的完整调用栈。
4. **每个 512 条描述符批次内排序，没有稳定改善；只给恢复／回收线程绑 CPU，也没有稳定改善。** 两者都不能当作已经验证的修复。
5. **最后一个独立对照发现了重要线索：主机内存分配／注册方式会影响拷贝速度。** 在模型服务已停止的情况下，`aclrtMallocHost` 的 128MiB 大块拷贝中位数约 24–36ms；`mmap + aclrtHostRegister` 为约 86–152ms。这是独立、小缓冲测试，**尚未证明换分配方式能修复完整模型恢复，也未验证其 RDMA 注册兼容性**。
6. **机器／卡因素还没有完全排除，但“就是某张坏卡”得不到当前证据支持。** 同一张卡会随运行状态、内存方式而变化；没有第二台机器的同条件对照，无法判断是否只发生在这一台宿主机或这套 CANN／驱动组合上。

优先继续调查“注册主机内存 → IPC 导入的 NPU KV 缓冲 → CANN 提交／回收”的路径。暂时不要继续完整跨节点性能实验，也不要给模拟器统一加上一个巨大的恢复常数来掩盖这项未解释机制。

## 2. 研究背景与本轮问题

原课题关注：P、D 两侧 CPU 内存作为缓存空间，跨节点远端读取、回填或迁移流量是否会产生排队、争用并恶化 TTFT、TPOT。用户要求使用请求自身产生的真实缓存流量，后续不再加入无关背景流量制造瓶颈。

之前使用 Qwen2.5-7B、较短输入时，较难形成明显网络压力。后来筛选了更长的真实代理轨迹，并切换到 BF16 的 Qwen2.5-14B 长上下文变体，使每 token 的 KV 从原来的约 56KiB 增至 192KiB。当前异常来自这一阶段，不是本轮新增加的网络限速。

2026-11-09 的真实跨节点实验中，一次失败请求的关键数据是：

| 项目 | 观测 |
|---|---:|
| 输入长度 | 44,470 tokens |
| 新增远端读取 | 1.125GiB |
| 远端读取耗时 | 约 111ms |
| 随后 CPU→NPU 恢复 | 161 块，约 3.77GiB |
| 恢复描述符数量 | 15,456 |
| 原生恢复服务耗时 | 约 95.24s |
| 其中 API 提交 | 约 86.94s |
| 其中 stream 同步 | 约 8.30s |

该请求还存在原生任务排队，客户端在 120 秒加载超时。由此，本轮优先回答四个问题：现象能否脱离 RDMA 复现；是否只跟某一张卡有关；是否是 CPU 配额／NUMA／地址顺序导致；慢时间究竟落在哪里。

历史实验的完整记录位于本机相邻目录 `../long-pd-20261109/README.md`，以及共享目录 `/data/shared_upload/hust-zsx/long-pd-20261109`。

## 3. 实验环境

### 3.1 资源与卡的对应关系

连接入口：`ssh main.hust-zsx.user.coder`。平台工作区为 `hust-zsx`，本轮不是分别连接 81、91 的双节点实验。

| 项目 | 本轮实际环境 |
|---|---|
| 容器主机名 | `coder-user-hust-zsx-55c4878b48-rm2dx` |
| 平台截图中的物理宿主机 | `host-192-168-0-2` |
| 宿主机 boot ID | `cb2563e8-fa4c-427c-b588-038fc6e46439` |
| NPU | 两张 Ascend 910B2，每张 64GiB HBM |
| 容器 CPU 配额 | `cpu.max = 800000 100000`，即每 100ms 可使用合计 800ms CPU，约等于 8 核配额 |
| CPU affinity 可见范围 | `0-191`；可见 192 个 CPU 不代表有 192 核配额 |
| 容器内存上限 | 64GiB |
| memlock soft / hard | 均为 65,536 bytes |
| 实时调度 | 使用默认调度，没有启用 SCHED_FIFO |
| RDMA | 当前容器没有 `/dev/infiniband`；可见 mlx5 的 GID 为零，本轮未经过 RDMA |

| 容器逻辑设备 | npu-smi 物理卡号 | PCI 地址 | PCI NUMA 节点 | 对应 CPU |
|---|---:|---|---:|---|
| 0 | 2 | `0000:c2:00.0` | 6 | 144–167 |
| 1 | 7 | `0000:42:00.0` | 2 | 48–71 |

两张卡的 `npu-smi` 健康状态均为 OK。观察到 PCIe 当前为 16GT/s ×16，最大能力为 32GT/s ×16；这一事实本身不能证明链路故障。7 号卡的 PCI 地址与此前慢 D1 的记录相同。

`ASCEND_RT_VISIBLE_DEVICES=0/1`、容器逻辑序号、物理卡号是三个需要区分的概念。后续换容器时，首先重新读实际映射，不能沿用本表卡号。

### 3.2 软件与实际运行文件

| 项目 | 版本／路径 |
|---|---|
| Python | 3.12.13，aarch64 / openEuler |
| CANN | `/usr/local/Ascend/cann-9.1.0` |
| npu-smi / 驱动工具显示 | `26.0.rc1` |
| vLLM | `0.23.0+empty` |
| vLLM Ascend | `0.23.0` |
| torch | 包版本标识 `2.10.0+cpu`，实际通过 torch-npu 使用 NPU |
| torch-npu | `2.10.0.post4` |
| Transformers | `5.5.4` |
| 模型目录 | `/data/shared_upload/Qwen2.5-14B-Instruct-1M-plainrope` |
| 原生服务二进制 | `/data/shared_upload/hust-zsx/issue23-scaled-20261014/runtime/bin/pegaflow-server` |
| 冻结 Python 连接器和 FFI | `/data/shared_upload/hust-zsx/long-pd-20261109/source/python` |

原生二进制虽然放在名称含 `20261014` 的目录中，但已经包含后来的设备作用域相关修复，**不能仅根据目录日期认定它是旧版本**。本轮也直接记录了 HostRegister 所用设备：卡 2 使用逻辑设备 0，卡 7 使用逻辑设备 1，未发现注册到了错误设备的证据。

用于确认实际执行文件的身份记录保存在 `raw/runtime-identities.json`。原生二进制 SHA256 为 `f2d3856a3e14a65e4267e58e26224298da733f8f18d08d51e7f8ff8dcae771a8`；Python 扩展为 `pegaflow.cpython-312-aarch64-linux-gnu.so`，SHA256 为 `c384924ad9fac9eb22c44f8aa3b9dd5f8f8d83e6e8baabe73462237cf0a66476`。

证据包包含连接器 Python 源码和模型配置快照；模型权重及上述运行二进制仍使用共享路径。

### 3.3 模型服务配置

两张卡各运行一个独立的模型实例和原生缓存服务。它们用于比较本地恢复，**不是本轮运行 1P1D 或 2P2D 的完整链路**。

| 参数 | 值 |
|---|---|
| 模型 | Qwen2.5-14B-Instruct-1M-plainrope，BF16，TP=1 |
| 最大上下文 | 98,304 tokens |
| 最大序列数 | 16 |
| 每步 token budget | 8,192 |
| 图模式 | `FULL_DECODE_ONLY`，capture sizes `[1,2,4,8,16]` |
| APC | 开启 |
| block size | 128 tokens |
| GPU memory utilization | 0.90 |
| 实际 NPU KV 容量 | 约 25.8GiB；不同启动实例约 1,100／1,101 块，以日志为准 |
| CPU 缓存池 | 每个原生实例 24GiB，共两个实例 |
| CPU 池内存位置 | 分别使用 `numactl --membind=6/2` |
| 连接器 | `PegaKVConnector`，`ascend_direct`，`read_write` |
| 保存 | 同步 save / finish ACK 开启，避免尚未保存完成就开始恢复 |
| 异步调度 | CLI 使用 `--no-async-scheduling` |
| 输出 | 初始／绑核探针 1 token；顺序对照 32 tokens，`temperature=0`、`ignore_eos=True` |

模型有 48 层、8 个 KV heads、head dimension 128；BF16 的 KV 大小为：

```text
2（K/V）× 48 × 8 × 128 × 2 bytes = 196,608 bytes/token = 192KiB/token
128 tokens/block → 24MiB/block
每个完整 KV block 对应 96 个 K/V plane 的搬运项
每项 256KiB，底层通常每 512 项调用一次 aclrtMemcpyBatchAsync
```

首次启动使用 safetensors `lazy` 加载，卡 7 重启后使用 safetensors `eager` 加载以改善共享 NFS 权重读取。**这里的 eager 只指权重文件读取策略，推理仍保留上述 graph 配置，并非 `--enforce-eager`。** 两次启动的状态、地址、可用 KV 块数不完全相同，不能把重启前后差异单独归因给一个因素。

模型权重约 27.5GiB，启动阶段 NFS 读取和主机内存注册相当耗时。报告中的请求 TTFT 均在服务 ready 后测量，不包含模型启动时间。

## 4. 输入、测量方法与遥测

### 4.1 输入

数据来自真实代理会话的连续历史快照：`TIGER-Lab/SWE-Next-SFT-Trajectories`，固定 revision `e378a60ddd7050fe9519a31a4d41d4872eeec6ac`。本轮从此前准备的完整会话数据中挑选四个固定请求作恢复探针；这不是原来的 Terminal-Bench 95 请求实验。

完整输入文件：

```text
/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz
```

| fixture | 会话／turn | 输入 tokens | 完整 CPU KV 块 | 恢复字节数 |
|---:|---|---:|---:|---:|
| 0 | swenext-3627 / 7 | 8,244 | 64 | 1.500GiB |
| 1 | swenext-3517 / 22 | 14,784 | 115 | 2.695GiB |
| 2 | swenext-1566 / 42 | 44,470 | 347 | 8.133GiB |
| 3 | swenext-2695 / 40 | 61,278 | 478 | 11.203GiB |

四份完整块工作集合计 1,004 块、23.531GiB，放在每实例 24GiB 的 CPU 池内。请求末尾不足 128 tokens 的部分仍需计算；本轮主测的是已存在的完整块恢复。

**四个请求的精确 prompt token IDs 已另存为 `raw/fixtures-token-ids.json.gz`。** 接手者不必重新下载整份数据来复现这轮探针。`raw/fixtures.json` 是来源元数据；模型和 tokenizer 配置在 `raw/source-snapshot/model-config/`。

### 4.2 如何强制走真正恢复路径

先在每张卡上执行四个请求，让模型生成并保存 CPU KV。之后每次恢复探针前调用该模型服务的 `/reset_prefix_cache`，清掉 NPU 的本地前缀复用机会，再提交相同 token IDs 与相同 `cache_salt`。因此，命中的 CPU 完整块需要实际恢复到 NPU，不能直接被 NPU APC 命中掩盖。

这一操作也会影响之后的 NPU block 分配顺序。我们记录了实际 block IDs，但没有将每次目的地址完全固定。因此，顺序／绑核实验是同实例近邻对照，尚不是源和目的物理布局完全相同的严格 replay。

### 4.3 新增遥测

| 层级 | 内容 |
|---|---|
| HTTP 请求 | 请求 ID、输入长度、策略、开始／结束、TTFT、完成时间、输出 token IDs、成功／失败 |
| vLLM scheduler | 非空计算步、每请求 scheduled/computed tokens、初次 block IDs、运行／等待数；空轮询每秒汇总 |
| 连接器 | prefetch / cache hit / load / save ACK 等原有详细事件 |
| 原生 CANN | HostRegister 设备，BatchAsync／StreamSync 的墙钟、线程 CPU、字节数、项数、源／目的连续段数量、缺页、上下文切换 |
| CPU 容器 | `cpu.max`、`cpu.stat` 增量、CPU PSI；逐绑核请求也记录配额统计 |
| CPU 热点 | 一个 8K 探针和一段大请求中的 SIGUSR2 采样，区分 batch 内部与 sync 内部 |
| 系统现场 | PCI／NUMA、进程 maps、numa_maps、status、最终 NPU 状态 |

高频日志先写 `/tmp/restore-card-diag-20261110`，减少 NFS 日志开销，结束后复制到证据中的 `raw/live-final/`。

## 5. 已完成的实验与结果

### 5.1 第一轮：双卡生产 CPU 缓存并复现

两卡均成功生成四份 CPU 缓存。较大的冷请求时间很接近：44K 为 10.99／10.89 秒，61K 为 18.70／18.64 秒。这是“没有明显的普遍模型计算失速”的线索，不等同于完整硬件健康验收。

随后卡 2 的恢复结果为：

| 请求 | 输入 | 结果 |
|---|---:|---|
| `card2-before-0-0009` | 8,244 | TTFT 0.491s |
| `card2-before-0-0010` | 44,470 | TTFT 93.371s |
| `card2-before-0-0011` | 61,278 | 约 120.058s 后未生成输出，加载超时 |

44K 成功慢请求的分解是：66 次 H2D batch，合计 8.133GiB；API 墙钟 **85.091s**、同一线程 CPU **85.036s**；stream 同步 **8.078s**；其余 TTFT 路径约 **0.202s**。

**这已经否定“只有物理 7 号卡才会慢”这一简单解释。** 原计划后续还有真实 decode 与恢复重叠实验；初始 campaign 在 61K 失败后 fail-fast 退出，因此本轮没有完成这一重叠对照。

### 5.2 排空后，比较相同 8K 请求

等待原生 load worker 回到空闲后，在卡 7 连续执行四次，在卡 2 执行两次。每次清 NPU APC，输出 1 token。

| 卡 | 完整请求完成时间，秒 |
|---|---|
| 物理 7 | 14.592、11.230、9.372、13.183 |
| 物理 2 | 1.429、0.819 |

这些是非流式 1-token 请求的完成时间，接近但不严格等于流式 TTFT。两卡此时确实差异明显；然而卡 2 也已经复现过 93 秒的大恢复，且两卡运行历史不同，尚不能据此判定硬件“体质”。

### 5.3 卡 7 同实例：改变搬运条目的提交顺序

为卡 7 重启模型与原生服务，加载可切换的诊断 hook。排序只在原生的每个 512 项 chunk 内进行，始终保留一项的源、目的、长度对应关系；目标范围重叠时不排序。模式可切换为原顺序、按目的地址、按源地址。

8K 请求输出 32 tokens，对照顺序为 original → dst → original（带 profiler）→ dst → src → dst → original。

| 模式 | TTFT，秒 | 数量 |
|---|---|---:|
| original，未带 profiler | 4.415、6.023 | 2 |
| dst | 6.858、6.090、7.762 | 3 |
| src | 5.976 | 1 |
| original，带 profiler | 6.704 | 1，单独记录 |

这些请求的 **32 个输出 token IDs 全部相同**；没有观察到排序改变了这组探针的数据语义。排序 hook 的 H2D 生效记录显示 `applied=1`、目标范围无重叠。

结果没有显示排序能稳定加速。按目的地址排序的 44K 请求仍然 TTFT **112.112s**：H2D API **104.687s**、线程 CPU **104.678s**、同步 **7.185s**；61K 请求再次在约 120 秒后无输出。

这里不能推出“所有地址布局都与问题无关”：只测了每 chunk 内排序，没有改变整体分配或全局描述符顺序。

![恢复阶段分解](restore-stage-breakdown.png)

**控制器的一个边界问题需要交接：** 排序 campaign 的 61K 请求超时后，脚本将全局策略文件恢复为 original，但原生任务可能还没有结束，因此这个失败请求尾部的一部分调用实际变回 original。它不能作为一个干净的完整 dst 条件样本。之后的绑核实验显式等待 load worker 排空，避免把这个未完成任务混入下一组。后续控制器应统一规定“超时后先 drain，再改策略或进入下一组”。

### 5.4 CPU 配额假说：直接核查限流计数

用户提出：容器是否用完了 CPU 时间片，剩下的恢复一直在等 CPU。

这个机制在 Linux cgroup 下确实存在。但本次现场数据不支持它是慢恢复的主因：

| 观测窗口 | CPU 使用／配额情况 |
|---|---|
| 第一段 5s 慢恢复窗口 | 约 14.814 CPU-s，即平均约 2.96 核；8 核配额；`nr_throttled` 313→313，`throttled_usec` 不变 |
| 第二段约 5s 大恢复窗口 | 约 15.949 CPU-s，平均约 3.2 核；限流计数仍未增加 |
| 后续 10 个 8K 逐请求窗口 | 平均约 1.09–1.36 核；每次限流周期增量均为 0、限流时间增量均为 0 |
| 最后 8 个独立拷贝条件 | 每条件限流周期增量均为 0 |

第一段窗口 CPU PSI `avg10` 约 0.14%→0.09%。容器生命周期内限流计数并非零，启动等其他阶段可能发生过限流；本结论只针对已观测的慢窗口。

44K 请求中 API 的 CPU／墙钟几乎 1:1，说明恢复线程主要持续占用 CPU。**“一个线程在内部反复尝试、耗尽单核处理能力”仍有可能；“整个容器因用完 8 核配额被挂起”在这些窗口里没有发生。** 单纯增加容器核数不一定能加速这条串行路径。

### 5.5 CANN 内部热点采样

合计得到 953 个样本：538 个落在 batch 调用中，415 个落在同步调用中。

- batch 样本中，至少 345 个落在解析为 `pthread_mutex_lock`／`pthread_mutex_trylock` 的位置，另外也有信号量、runtime 重试相关位置。
- sync 样本中，399/415 落在 `clock_nanosleep`，与主动轮询／睡眠等待完成相符。
- 大量慢 batch 的线程 CPU 几乎等于墙钟，普通缺页及主动上下文切换很少。

因此，“提交调用只是快速发起 DMA，时间都在网络／设备 DMA 本身”不符合本次观测。提交端本身会长时间滞留，且存在明显的同步原语活动。

**证据边界：** 当前采样只有 PC，没有本轮慢请求的完整调用栈和锁对象；CANN 库中的若干名字只是 stripped ELF 附近的导出符号，不可把报告里的某个 C++ 模板符号当作真实内部函数名。尚不能声称已经证明某个特定任务队列耗尽、特定锁死锁，或者驱动存在某个唯一缺陷。采样还可能轻微扰动时序，带 profiler 的请求不用于排序收益统计。

原始采样为 `raw/live-final/card7-pc.bin`，每条 32 字节，格式为四个 little-endian uint64：`monotonic_ns, pc, tid, phase`，其中 phase 1=batch、2=sync。映射文件为 `raw/card7-profile-maps.txt`，解析结果为 `raw/pc-summary.json`。

### 5.6 只改变恢复／回收线程 CPU 位置

同一实例、相同 8K 输入和 1-token 输出，保持 CPU 池位于 NUMA 2；改变 `gpu1-load` 与 `RT_RECYCLE_1` 两个线程的位置。每阶段两次，最终恢复原 affinity。

| 阶段 | 处理方式 | 请求完成时间，秒 |
|---|---|---|
| unbound | 原来可在 0–191 上运行 | 7.064、6.833 |
| numa-local | load→48，recycle→49，均在 NUMA 2 | 6.747、6.479 |
| numa-remote | load→144，recycle→145，均在 NUMA 6 | 5.240、6.744 |
| unbound-return | 回到原 affinity | 6.069、5.584 |
| numa-local-return | 再次本地绑定 | 5.819、5.185 |

后面的 unbound 自身也变快，没有稳定“本地绑定优于其他组”的顺序。因此，**只给这两个线程绑核没有解释或消除问题**。这不能排除整体 NUMA 布局、其他 runtime 线程位置、内存注册状态的影响。

### 5.7 独立拷贝：绕开模型和 PegaFlow 的缓存逻辑

编写一个独立 C 程序，用 CANN 直接分配 NPU 缓冲与 stream：先 `mmap + aclrtHostRegister` 注册 128MiB CPU 内存，随后比较一次 128MiB 的 `aclrtMemcpyAsync` 与 512×256KiB 的 `aclrtMemcpyBatchAsync`。每次等 stream 完成，读取目标前 64 字节验证为预先写入的 `0x5a`。

该程序绕开了模型执行、IPC 导入和 PegaFlow 的缓存查找。因此它有助于判断异常是否只存在于上层服务，但其内存规模和布局不同于完整恢复。

先在模型服务仍驻留但没有模型请求执行时测量，再保存现场、停止本轮模型和原生服务，运行相同程序。每种方法 5 次，下表排除首轮，列余下 4 次中位数。

| 状态 | 卡 2 大块 | 卡 7 大块 | 卡 2 batch512 | 卡 7 batch512 |
|---|---:|---:|---:|---:|
| 模型服务驻留 | 703ms | 217ms | 179ms | 136ms |
| 停止服务后的第一轮 | 15ms | 98ms | 21ms | 109ms |

但下一组新进程中的 mapped 内存测量，卡 2 大块又回到了约 97／152ms。因此，**停止模型后某一轮变快，不足以证明“模型驻留就是唯一原因”或“清理服务就能修复”。** 分配状态、进程上下文、测试时间也一起变化，存在尚未解释的状态依赖。

### 5.8 最后一组：内存分配方式 × CPU 放置 × 两张卡

这是本轮最后完成的实测。模型服务已停止，随机顺序执行 8 个条件：两张卡 × 两种主机内存方式 × CPU 不绑定／绑定到本地 NUMA。所有主机内存按对应卡的本地 NUMA 分配。每个条件是新独立进程，4 次重复，每次均测 bulk 和 batch512；首轮排除，保留每组 3 次。

两种内存方式：

- **mapped：** `mmap` 后 `aclrtHostRegister(..., ACL_HOST_REGISTER_MAPPED, ...)`，接近当前原生 CPU 池的注册方式。
- **pinned：** `aclrtMallocHost`，作为主机分配 API 的控制组。

下表单位均为毫秒，数字为 3 次的中位数；范围见 JSON 与图。

| CPU 主机内存方式 | CPU 位置 | 卡 2 bulk | 卡 7 bulk | 卡 2 batch512 | 卡 7 batch512 |
|---|---|---:|---:|---:|---:|
| mmap + HostRegister | 不绑定 | 96.93 | 133.15 | 286.93 | 97.22 |
| mmap + HostRegister | 本地 NUMA | 152.48 | 86.07 | 109.59 | 75.37 |
| MallocHost | 不绑定 | 30.59 | 29.67 | 30.65 | 38.41 |
| MallocHost | 本地 NUMA | 24.39 | 35.56 | 43.91 | 69.85 |

![主机内存方式对照](host-memory-control.png)

这组结果提示：

1. 内存分配／注册路径是值得优先继续的变量；同卡、相同 128MiB 数据量，差异仍然存在。
2. 卡 7 不是在所有条件下都比卡 2 慢；MallocHost、不绑 CPU 时两者 bulk 几乎相同，约 30ms。
3. CPU 本地绑定不是单调有效，不能简单开个绑核开关就宣布修复。
4. 独立拷贝测试也会波动，且没有得到稳定的链路峰值带宽。这些端到端 API 计时包含 runtime 等待／开销，不能把 `128MiB / 耗时` 当作裸 PCIe 硬件带宽。
5. MallocHost 只是线索：本轮没有用它替换完整原生 24GiB 池，没有验证 96-plane IPC 恢复，也没有 RDMA MR 注册验收。直接替换生产池可能改变兼容性、NUMA、页类型和内存占用，需下一步实测。

## 6. 综合判断与仍然未知的部分

| 假说 | 当前判断 | 理由／保留条件 |
|---|---|---|
| 必须有 RDMA 才会慢 | 本轮已否定 | 无 RDMA 也出现 93–112s 恢复 |
| 只有 7 号卡有问题 | 本轮已否定这一简单版本 | 2 号卡也出现 93s 和超时；其他路径下两卡可以接近 |
| CPU 容器配额耗尽是慢窗口主因 | 本轮观测不支持 | 慢窗口限流增量为零，CPU 用量小于 8 核 |
| 提交阶段只是正常异步发起，很快返回 | 不成立 | 原始 CANN 调用内部累计约 85／105s |
| 只是普通主存缺页／调度离 CPU | 不能解释所测慢 batch | 线程 CPU≈墙钟，缺页、主动切换少 |
| 512 项内排序可以修复 | 未显示有效 | 同实例交叉对照没有稳定改善 |
| 只绑 load/recycle 线程可以修复 | 未显示有效 | 本地／远端／回原组区间重叠，存在时间趋势 |
| 注册内存路径有影响 | 小缓冲独立测试支持 | MallocHost 在多数组中更快，完整恢复尚未验证 |
| IPC 导入、运行历史、任务回收资源有影响 | 优先验证的候选 | 完整恢复明显恶化；PC 有锁／重试；尚缺固定布局的因果对照 |
| 宿主机／驱动／固件组合特异性 | 尚未排除 | 本轮只有一台宿主机 |

**当前定位到的是一个有结构性线索的恢复路径异常，而非已经证明的纯随机抖动。** 但还不能把所有波动统一解释成一个机制：小缓冲、不同内存方式和完整模型中的慢，可能有共同因素，也可能叠加了不同因素。

## 7. 下一位 AI 的工作顺序

### 第一步：做固定源／目的布局的最小 IPC 对照

先复用本轮已有 C 程序，以及本机 `experiment-prep/kv14_native_restore_probe_20261109.py`，构造与 14B 一致的 96 个 K/V planes、每项 256KiB 的缓冲。该参考脚本也随包保存在 `raw/prior-controls/reference-code/`；它原先的 source、设备、池容量和请求大小写在代码中，需要按当前环境调整。优先选 64 块和 161 块，分别约 1.5GiB、3.77GiB；能稳定复现后再增至 347 块。**保持缓冲地址、数据内容、描述符和源／目的映射固定，重复执行，避免每轮清 APC 引入新的布局变化。**

只改变一个主要变量：同进程 CANN 自有设备内存，或者另一进程通过 NPU IPC 导入相同缓冲。再比较 mapped 主机池与 MallocHost 主机池。这样可以拆开“主机内存方式”和“IPC 导入”两个因素，而非直接重跑全部会话。

还需拆开注册范围大小：本轮独立 C 程序只注册 128MiB，而真实原生池注册 24GiB。可以保持实际搬运数据为 128MiB，分别注册 128MiB／4GiB／24GiB，检查注册范围是否改变延迟。同步记录 `/proc/<pid>/smaps` 的页大小、AnonHugePages、`numa_maps` 以及注册返回的映射别名；内存页／映射结构只是待验证因素，尚不能称为根因。

建议每条件先 3–5 次短重复，交叉／随机化顺序，记录所有失败和超时；不必为了显得样本多跑数小时。

参考探针使用过统一的 `0.25` 填充值；后续应在独立正确性探针中使用逐块可区分的数据，避免错误地交换了两块却因数值相同而漏检。不要把大规模校验操作混入性能计时。

### 第二步：确认卡在哪里等，以及谁持有什么资源

如果最小探针慢，针对慢 case 做有界、低开销遥测：

- 同步记录 `gpu*-load`、`RT_RECYCLE_*` 等线程的 CPU、runnable 等待、affinity 与 cgroup 限流增量。
- 取得 PC + LR／栈回溯，区分普通锁竞争、任务描述符分配重试、驱动调用、完成回收；当前 PC 样本尚缺这一层。
- 如果可行，用 CANN profiler 获取原生进程 SDMA／任务提交到完成的时间，拆开“CPU 发不出去”与“设备已经收到但完成慢”。设备 profiler 与普通计时分轮运行，避免混在一起比较收益。
- 有条件再比较每 512 项同步一次、整批最后同步、不同有界在途项数；这些是需要测量的候选，不是既定修复。

容器没有 gdb、perf、eu-stack，`ptrace_scope=1`。可以继续使用已运行成功的进程内采样方案；如添加 LR／栈采样，应验证可读范围、处理已有信号 handler，并将有 profiler 的样本单列。

恢复期间 AICore 占用低，可以是 CPU 提交／搬运等待的结果；需要结合 SDMA、提交线程和真实模型计算阶段一起判断，不能仅凭 AICore 百分比决定更改模型执行配置。

**不要直接复用带硬编码 CANN 指令地址的实验补丁。** 旧脚本有读取内部结构乃至试验修改重试行为的版本，对版本、布局敏感；只能作研究参考。

### 第三步：用真实恢复验证候选改进

若小探针发现 MallocHost 或某种提交方式稳定有效，再回到相同 14B 模型、相同四个 token IDs，验证：

1. 8K／44K／61K 能否完成并稳定重复；记录实际恢复量、命中块、计算尾块。
2. 输出少量 token，确认没有明确数据语义错误；数值微小差异不作为当前性能研究的主要阻碍。
3. 增加“真实 decode 正在运行时的恢复”这一尚未完成的条件；避免只有空闲状态快。
4. 如改变了 CPU 池分配方式，恢复跨节点前先验证 RDMA MR 注册与稳定读写；必要时比较注册池加 staging 的代价和额外内存占用。

### 第四步：需要时再做跨机器，而非现在就申请完整多节点实验

首先在本机建立能便宜复现的最小探针。如果另一台机器有一张卡，运行相同小探针／相同内存方式矩阵，就能判断是否存在宿主机或软件栈特异性。根因阶段通常一张卡即可；两张卡方便同机交叉，不必先申请两台各两卡。

只有恢复路径在持续运行中稳定后，才恢复完整 P/D 性能实验，避免又把恢复异常当成网络拥塞。

### 第五步：回到模拟器

本轮没有修改模拟器。后续应把恢复的队列、CPU 提交服务、实际 H2D 完成、与计算的资源竞争分开，而不是把所有等待压成一个“恢复带宽”。

在根因未明确前，模拟结果需要对异常恢复状态给出适用范围或敏感性分析。不能用这几次 93／112 秒直接训练一个按卡号、请求 ID 或机器名称拟合的补丁，也不能用慢样本统一放大所有恢复延迟。

## 8. 旧实验中已有的相关工作，避免重复

共享目录 `/data/shared_upload/hust-zsx/operator-resource-20261109` 保存了此前围绕 7B 的细粒度实验，本轮复制了其中两个控制实验的证据到 `raw/prior-controls/`：

- `native-cpu-profile-probe-v2`：24 次、56 planes 的 CPU 采样及注册上下文对照；某 128-block 请求出现 3.02s 慢样本，其他重复约 0.24s。不是当前 14B 的 96-plane 形状。
- `native-yield-control-v1`：64 次、任务分配重试中的协作等待试验。128-block baseline 中位约 0.279s、最大 9.736s；50us yield 中位约 5.156s，回到零 yield 也未恢复原先快状态，随后再开 yield 仍约 4.269s。**这不是 yield 有效的证据，反而表明顺序／状态依赖会误导简单前后对比。**

其他已有方向还包括 coalescing、内存方式、描述符粒度、上下文数量和 CPU profile。优先读 `operator-resource-20261109` 的实际 operations／api-trace 与本机 `experiment-prep/native_*20261109*`，不要只根据文件名判断结果。旧实验与本轮形状、软件现场不同，不能混成同条件统计。

## 9. 文件、脚本与接手方法

### 9.1 数据位置

共享服务器：

```text
/data/shared_upload/hust-zsx/restore-card-diag-20261110
```

本机 Windows：

```text
C:/Users/Zhangsx/Desktop/tailguard/experiment-results/restore-card-diag-20261110
C:/Users/Zhangsx/Desktop/tailguard/experiment-prep
```

交接所需文件：

| 文件／目录 | 用途 |
|---|---|
| `README.md` | 本报告；转交给另一位 AI 的入口 |
| `analysis-summary.json` | 条件统计、逐请求 native 时间关联、配额窗口、内存矩阵 |
| `restore-card-evidence-20261110.tar.gz` | 原始数据、运行脚本、配置、现场快照、四份精确输入与相关旧证据 |
| `raw/requests.jsonl` | 初始双卡生产及卡 2 慢恢复／超时 |
| `raw/same8k.jsonl` | 排空后两卡相同 8K 复测 |
| `raw/order-requests.jsonl` | 重启卡 7 后的顺序对照、输出 token IDs 与大恢复 |
| `raw/affinity-requests.jsonl` | CPU 位置对照及每请求限流计数 |
| `raw/bulk-resident-device*.jsonl` | 模型服务驻留时的小缓冲拷贝 |
| `raw/bulk-empty-device*.jsonl` | 停止模型服务后的第一轮小缓冲拷贝 |
| `raw/bulk-matrix/` | 最后 8 条件小缓冲矩阵的每次原始计时 |
| `raw/bulk-matrix-cases.jsonl` | 随机执行顺序、命令、每条件资源计数和返回码 |
| `raw/live-final/` | CANN API、模型、scheduler、连接器遥测最终快照 |
| `raw/generation1-card7/` | 卡 7 重启前的服务日志与 API 日志 |
| `raw/pre-stop/` | 停服务前的 maps／numa_maps／status |
| `raw/cpu-quota*-window.json` | 两个现场 CPU 配额测量窗口 |
| `raw/source-snapshot/` | 实际 Python 连接器与模型配置 |
| `raw/fixtures-token-ids.json.gz` | 四个精确输入，gzip JSON 数组 |
| `raw/prior-controls/` | 两项相关旧控制实验，单独保留 |

`analysis-summary.json` 的 native 时间通过事件开始时间与 HTTP 请求窗口关联。对于超时请求，原生调用可能在请求结束后仍执行，分段和不一定等于请求等待时长；字段 `native_calls_finishing_after_request_end` 会提示这一点。失败请求没有 TTFT，120 秒是超时等待时间，不是成功 TTFT。非流式 1-token 探针仅记录 `elapsed_s`。

### 9.2 本轮脚本

下表列出本轮代码。实际运行的远程脚本已归档，本机工具位于 `experiment-prep/`，并随交接包保存源码：

| 脚本 | 用途 |
|---|---|
| `restore_card_deploy_20261110.py` | 初始双卡模型和原生服务部署 |
| `restore_card_run_20261110.py` | 初始生产、恢复、原计划重叠 campaign；本轮在 baseline 失败后提前结束 |
| `same8k.py` | 排空后两卡 8K 复测；本轮生成在服务器，证据包包含 |
| `restore_card_trace_20261110.py` | vLLM scheduler 观察器 |
| `restore_card_api_20261110.c` | 基本 CANN 时间和资源 observer |
| `restore_card_sorted_api_20261110.c` | 分块排序与 PC 采样 hook |
| `restore_card_order_run_20261110.py` | 卡 7 顺序与大输入对照 |
| `restart_card7_order_v2.py` | 本轮实际成功使用的卡 7 重启协调器 |
| `restore_card_barrier_connector_20261110.py` | 权重加载后等待原生服务就绪的连接器启动屏障 |
| `restore_card_pc_summary_20261110.py` | 按进程 maps 解析 PC 样本 |
| `restore_card_affinity_20261110.py` | 原位置／本地／远端／回原的短对照，结束时恢复 affinity |
| `restore_card_bulk_20261110.c` | 独立 CANN bulk／batch512 拷贝 |
| `restore_card_bulk_matrix_20261110.py` | 生成另一内存分配版本并运行 8 条件矩阵 |
| `restore_card_package_20261110.py` | 汇总并导出证据 |
| `restore_card_download_20261110.py` | 用本机现有 Coder CLI 下载与解压证据 |
| `restore_card_figures_20261110.py` | 本机绘图，可重建报告两张图 |

独立 C 程序的编译方式：

```bash
gcc -O2 restore_card_bulk_20261110.c \
  -I/usr/local/Ascend/cann-9.1.0/include \
  -L/usr/local/Ascend/cann-9.1.0/aarch64-linux/lib64 \
  -Wl,-rpath,/usr/local/Ascend/cann-9.1.0/aarch64-linux/lib64 \
  -lascendcl -o bulk-copy
numactl --membind=6 ./bulk-copy 0
numactl --membind=2 ./bulk-copy 1
```

程序会创建并销毁自己的 stream、内存和设备上下文；运行时应确认设备序号与 NUMA 映射。参数中的 0／1 是逻辑设备。

本机控制辅助函数为 `experiment-prep/long_pd_control_20261109.py` 的 `remote(host, code, timeout)`，通过已配置的 Coder CLI 执行远程 Python：

```python
from long_pd_control_20261109 import remote
print(remote('hust-zsx', "import pathlib; print(pathlib.Path('/sys/fs/cgroup/cpu.max').read_text())"))
```

本机 Python：`C:/Users/Zhangsx/Desktop/tailguard/vllm-hust-benchmark/.venv/Scripts/python.exe`。Windows 控制命令优先用 PowerShell 7，设置 `PYTHONUTF8=1` 可避免中文输出编码问题。

### 9.3 结束时状态与重新启动注意点

- 本轮 HTTP／模型／原生服务均已停止，独立拷贝进程全部完成；最终 `npu-smi` 显示两卡无运行进程、约 3.44GiB 基础占用。原工作区容器本身未关闭，也没有设置任何定时保活。
- 原 HTTP 端口为 38880／38881，原生 gRPC 为 38850／38851，原生 HTTP 为 38890／38891。结束后不应假定这些端口仍有服务。
- `ready.json`、`order-ready.json`、`services/*.json` 是已结束的历史记录，**不是活进程凭据**。现有启动脚本也会拒绝覆盖服务 receipt。后续使用新的实验目录、引擎 ID 和就绪标记，保留本轮数据。
- 原模型配置／脚本里写死了路径、设备映射和端口，换机器时应按实际环境调整；不要直接把本轮脚本启动两遍。
- 原生任务超时不等于原生工作立即取消。进入下一条件前，必须确认 load 队列排空或显式结束归属清楚的实验进程。
- 临时日志目录与共享目录跨文件系统，归档应复制后核对；不能用依赖同文件系统的 `rename` 直接移动。
- 本轮新增内容在实验准备与结果目录，未提交 GitHub，未改生产连接器或模拟器行为。后续如需要提交，应再按项目当前的代码／benchmark 证据组织规则整理。
- 用户要求实验高效、避免过量防御性检查；接受轻微浮点输出差异，重点是性能及明确的系统语义错误。用户禁止定时空计算规避资源释放；只运行实际实验任务。

## 10. 成果、限制与验收目标

本轮完成了单机复现、两卡比较、CPU 配额核查、CANN 分段计时与 PC 热点、排序／绑核短对照、独立拷贝及内存方式矩阵，给出了可重复使用的输入和证据。40 个模型请求中 38 成功、2 个失败；其中包括 12 个生产 CPU 缓存的请求与 28 个恢复探针。104 次独立拷贝包含预热；排除每条件／方法的首次后，共保留 80 次，最终矩阵保留其中 48 次。

限制是：只有一台宿主机；小缓冲最终矩阵每组只有 3 个保留样本；不同阶段的地址、进程历史不完全相同；没有完成真实 decode 重叠和多节点复核；PC 尚不能唯一识别锁或驱动资源。当前数据适合定位候选机制，不适合发布精确 p99 或笼统的优化收益。

下一阶段合理的完成标准是：找到一个固定布局、可快速重复的慢恢复探针；证明一个可解释的因素会改变它；将候选改进放回完整模型恢复和真实计算重叠条件，确认速度稳定、语义正常，随后再验证 RDMA 兼容性并恢复课题性能实验。
