import subprocess,pathlib,json,time
r=pathlib.Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
for device,node in [(0,6),(1,2)]:
 with (r/f'bulk-device{device}.jsonl').open('w') as out,(r/f'bulk-device{device}.stderr').open('w') as err:
  x=subprocess.run(['/usr/bin/numactl',f'--membind={node}',str(r/'bulk-copy'),str(device)],stdout=out,stderr=err,timeout=90);print(device,x.returncode,flush=True)
(r/'bulk-done.json').write_text(json.dumps({'epoch':time.time()}))
