
import pathlib,time,json,gzip,httpx
r=pathlib.Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as f:rows=[json.loads(x) for x in f]
case=min(rows,key=lambda x:abs(x['prompt_tokens']-8244))
with httpx.Client(timeout=160,trust_env=False) as c:
 for physical,logical,count in [(7,1,4),(2,0,2)]:
  pid=json.loads((r/'services'/f'card{physical}-native.json').read_text())['pid'];deadline=time.monotonic()+180
  while time.monotonic()<deadline:
   waits=[(p/'wchan').read_text() for p in pathlib.Path(f'/proc/{pid}/task').iterdir() if '-load' in (p/'comm').read_text()]
   if waits and all('futex' in w for w in waits):break
   time.sleep(1)
  else:raise TimeoutError('Previous native work not drained')
  for repeat in range(count):
   url=f'http://127.0.0.1:{38880+logical}';c.post(url+'/reset_prefix_cache').raise_for_status()
   key=f'card{physical}-same8k-{repeat}';begin=time.monotonic();epoch=time.time_ns()
   response=c.post(url+'/v1/completions',json={'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,'temperature':0,'ignore_eos':True,'request_id':key,'cache_salt':'card-diag-fixture-0'});response.raise_for_status();data=response.json()
   row={'id':key,'card':physical,'repeat':repeat,'start_epoch_ns':epoch,'elapsed_s':time.monotonic()-begin,'usage':data.get('usage'),'text':data.get('choices',[{}])[0].get('text')}
   with (r/'same8k.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(json.dumps(row),flush=True)
   if data.get('usage',{}).get('completion_tokens')!=1:break
(r/'same8k-done.json').write_text(json.dumps({'epoch':time.time()}))
