"""Transport for the allocated 81/91 long-context real P/D experiment."""

import subprocess

CODER = 'C:/Users/Zhangsx/AppData/Roaming/Code/User/globalStorage/coder.coder-remote/coder.sage.org.ai/bin/coder-windows-amd64.exe'
REMOTE = '/data/shared_upload/hust-zsx/long-pd-20261109'


def remote(host, code, timeout=45):
    args = [CODER, '--url', 'https://coder.sage.org.ai:9450', '--use-keyring=true',
            'ssh', '--disable-autostart', host, '--', 'python3', '-']
    result = subprocess.run(args, input=code, capture_output=True, text=True,
                            encoding='utf-8', timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr + result.stdout[-3000:])
    return result.stdout
