"""Download the finished evidence bundle through the existing Coder SSH session."""
import json
from pathlib import Path
import subprocess
import sys
import tarfile

sys.path.insert(0,str(Path(__file__).parent))
from long_pd_control_20261109 import CODER,remote

ROOT='/data/shared_upload/hust-zsx/restore-card-diag-20261110'
OUT=Path(__file__).resolve().parent.parent/'experiment-results/restore-card-diag-20261110'
OUT.mkdir(parents=True,exist_ok=True)
metadata=json.loads(remote('hust-zsx',f"import pathlib,json\nr=pathlib.Path({ROOT!r});print(json.dumps({{name:(r/name).read_text() for name in ['analysis-summary.json','environment-final.json','inventory.json','fixtures.json','evidence-receipt.json','npu-final.txt']}}))",60))
for name,content in metadata.items():(OUT/name).write_text(content,encoding='utf-8')
archive=OUT/'restore-card-evidence-20261110.tar.gz'
command=[CODER,'--url','https://coder.sage.org.ai:9450','--use-keyring=true',
         'ssh','--disable-autostart','hust-zsx','--','python3','-']
code=f"import pathlib,sys;sys.stdout.buffer.write(pathlib.Path({(ROOT+'/'+archive.name)!r}).read_bytes())"
with archive.open('wb') as stream:
    completed=subprocess.run(command,input=code.encode(),stdout=stream,stderr=subprocess.PIPE,timeout=120)
if completed.returncode:raise RuntimeError(completed.stderr.decode(errors='replace'))
expected=json.loads(metadata['evidence-receipt.json'])['bytes']
if archive.stat().st_size!=expected:raise RuntimeError('Evidence transfer was incomplete')
stale_receipt=OUT/'raw/evidence-receipt.json'
if stale_receipt.exists():stale_receipt.unlink()
with tarfile.open(archive) as tar:tar.extractall(OUT/'raw',filter='data')
print(json.dumps(dict(directory=str(OUT),archive_bytes=expected,raw_files=len(list((OUT/'raw').rglob('*'))))))
