"""Finish the finite restore attribution acquisition and preserve its evidence."""
from collections import Counter,defaultdict
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import tarfile
import time

ROOT=Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
LIVE=Path('/tmp/restore-card-diag-20261110')


def read_rows(path):
    if not path.exists():return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def stat(text):
    return {k:int(v) for k,v in (line.split() for line in text.splitlines())}


def distribution(values):
    return dict(n=len(values),median=statistics.median(values),min=min(values),max=max(values)) if values else dict(n=0)


def main():
    assert (ROOT/'affinity-done.json').exists() and (ROOT/'bulk-matrix-done.json').exists()
    # Copy tmpfs evidence after all request work has ended.
    shutil.copytree(LIVE,ROOT/'live-final',dirs_exist_ok=True)
    if (ROOT/'pc-summary.json').exists():
        pc=json.loads((ROOT/'pc-summary.json').read_text())
    else:pc={}
    final={}
    counts={}
    for filename in ['requests.jsonl','same8k.jsonl','order-requests.jsonl','affinity-requests.jsonl']:
        rows=read_rows(ROOT/filename);counts[filename]=dict(n=len(rows),status=dict(Counter(r.get('status','ok') for r in rows)))
    final['request_counts']=counts
    comparisons=defaultdict(list)
    for r in read_rows(ROOT/'order-requests.jsonl'):
        if r['phase']=='compare' and not r['profiled']:comparisons[r['mode']].append(r['TTFT_s'])
    final['order_TTFT_s']={k:distribution(v) for k,v in comparisons.items()}
    final['order_output_token_ids_identical']=len({tuple(r['token_ids']) for r in read_rows(ROOT/'order-requests.jsonl') if r['phase']=='compare'})==1
    affinities=defaultdict(list);quota=[]
    for r in read_rows(ROOT/'affinity-requests.jsonl'):
        affinities[r['phase']].append(r['elapsed_s'])
        before,after=stat(r['cpu_before']),stat(r['cpu_after'])
        quota.append(dict(request=r['id'],wall_s=r['elapsed_s'],usage_cores=(after['usage_usec']-before['usage_usec'])/1e6/r['elapsed_s'],
                          throttled_periods=after['nr_throttled']-before['nr_throttled'],
                          throttled_usec=after['throttled_usec']-before['throttled_usec']))
    final['affinity_elapsed_s']={k:distribution(v) for k,v in affinities.items()}
    final['affinity_cpu_quota_windows']=quota
    matrix=[]
    for r in read_rows(ROOT/'bulk-matrix-cases.jsonl'):
        x={k:r[k] for k in ['name','physical_card','host_allocation','cpu_placement','numa_node','returncode']}
        rows=read_rows(ROOT/'bulk-matrix'/f'{r["name"]}.jsonl')
        for mode in ['bulk','batch512']:
            a=[v for v in rows if v['mode']==mode and v['repeat']>0]
            x[mode+'_wall_ms']=distribution([v['wall_ns']/1e6 for v in a])
            x[mode+'_api_ms']=distribution([v['api_ns']/1e6 for v in a])
        before,after=stat(r['resources_before']['cpu.stat']),stat(r['resources_after']['cpu.stat'])
        x['throttled_periods']=after['nr_throttled']-before['nr_throttled'];matrix.append(x)
    final['bulk_matrix']=matrix
    bulk=[]
    for condition in ['resident','empty']:
        for device in [0,1]:
            rows=read_rows(ROOT/f'bulk-{condition}-device{device}.jsonl')
            for mode in ['bulk','batch512']:
                a=[r['wall_ns']/1e6 for r in rows if r['repeat']>0 and r['mode']==mode]
                bulk.append(dict(condition=condition,physical_card=2 if device==0 else 7,mode=mode,wall_ms=distribution(a)))
    final['bulk_before_after']=bulk
    api_files=[ROOT/'live-final/card2-api.jsonl',ROOT/'generation1-card7/card7-api.jsonl',ROOT/'live-final/card7-order-api.jsonl']
    events=[]
    for p in api_files:
        for row in read_rows(p):events.append(dict(source_file=str(p.relative_to(ROOT)),**row))
    load_tids={(r['pid'],r['tid']) for r in events if r['event']=='batch' and int(r.get('src_first','0'),16)>2**47}
    requests=[]
    for name in ['requests.jsonl','same8k.jsonl','order-requests.jsonl','affinity-requests.jsonl']:
        for r in read_rows(ROOT/name):
            if 'start_epoch_ns' not in r:continue
            start=r['start_epoch_ns'];end=r.get('end_epoch_ns',start+int(r['elapsed_s']*1e9))
            chosen=[x for x in events if x['event'] in ['batch','sync'] and start<=x.get('epoch_ns',0)<=end and (x['pid'],x['tid']) in load_tids]
            batches=[x for x in chosen if x['event']=='batch'];syncs=[x for x in chosen if x['event']=='sync']
            api=sum((x['end_ns']-x['start_ns'])/1e9 for x in batches)
            cpu=sum(x['thread_cpu_ns']/1e9 for x in batches)
            requests.append(dict(file=name,id=r['id'],phase=r.get('phase'),mode=r.get('mode'),card=r.get('card',7 if name in ['order-requests.jsonl','affinity-requests.jsonl'] else None),
                                 status=r.get('status','ok'),TTFT_s=r.get('TTFT_s'),elapsed_s=r['elapsed_s'],
                                 h2d_batch_calls=len(batches),h2d_bytes=sum(x['bytes'] for x in batches),
                                 h2d_api_wall_s=api,h2d_api_thread_cpu_s=cpu,
                                 h2d_api_CPU_wall_ratio=cpu/api if api else None,
                                 native_calls_finishing_after_request_end=sum(x['epoch_ns']+x['end_ns']-x['start_ns']>end for x in chosen),
                                 load_sync_wall_s=sum((x['end_ns']-x['start_ns'])/1e9 for x in syncs),
                                 note='API calls are associated by start time inside request wall window; timed-out native work can extend beyond it. Nonstreamed one-token probes have elapsed_s but no directly measured TTFT_s.'))
    final['per_request_native_windows']=requests
    final['pc_sampling']=dict(samples=pc.get('samples'),phases=pc.get('phases'),
                              symbol_warning='Stripped CANN internal symbols are nearest exported names, not verified function identities; libc lock/sleep names are stronger evidence.')
    old=Path('/data/shared_upload/hust-zsx/operator-resource-20261109')
    prior={}
    for name in ['native-cpu-profile-probe-v2','native-yield-control-v1']:
        groups=defaultdict(list)
        for x in read_rows(old/name/'operations.jsonl'):
            groups[f'{x.get("stage")}:{x.get("blocks")}'].append(x['service_s'])
        prior[name]={k:distribution(v) for k,v in groups.items()}
        dest=ROOT/'prior-controls'/name;dest.mkdir(parents=True,exist_ok=True)
        for file in ['config.json','operations.jsonl','done.json','api-trace.jsonl']:
            src=old/name/file
            if src.exists():shutil.copy2(src,dest/file)
    final['prior_20261109_controls']=prior
    final['collected_epoch_ns']=time.time_ns()
    (ROOT/'analysis-summary.json').write_text(json.dumps(final,indent=2))
    (ROOT/'npu-final.txt').write_text(subprocess.run(['npu-smi','info'],capture_output=True,text=True).stdout)
    files=[p for p in ROOT.rglob('*') if p.is_file() and (p.suffix not in ['.gz','.so'] or p.name=='fixtures-token-ids.json.gz') and '__pycache__' not in p.parts and p.name not in ['bulk-copy','bulk-matrix-copy','evidence-receipt.json']]
    archive=ROOT/'restore-card-evidence-20261110.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
        for p in files:tar.add(p,arcname=p.relative_to(ROOT),recursive=False)
    receipt=dict(archive=str(archive),bytes=archive.stat().st_size,members=len(files),created_epoch=time.time())
    (ROOT/'evidence-receipt.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt))


if __name__=='__main__':main()
