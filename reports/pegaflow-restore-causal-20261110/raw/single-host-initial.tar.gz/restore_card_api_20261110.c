#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

typedef aclError (*batch_fn)(void **,size_t *,void **,size_t *,size_t,aclrtMemcpyBatchAttr *,size_t *,size_t,size_t *,aclrtStream);
typedef aclError (*sync_fn)(aclrtStream);
static batch_fn batch;
static sync_fn sync_stream;
static pthread_once_t once=PTHREAD_ONCE_INIT;
static int fd=-1;
static int (*get_device)(int32_t *);
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
static uint64_t stamp(clockid_t clock){struct timespec ts;clock_gettime(clock,&ts);return (uint64_t)ts.tv_sec*1000000000ULL+ts.tv_nsec;}
static void init(void){
 batch=(batch_fn)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");sync_stream=(sync_fn)dlsym(RTLD_NEXT,"aclrtSynchronizeStream");
 get_device=(int (*)(int32_t *))dlsym(RTLD_NEXT,"aclrtGetDevice");
 const char *path=getenv("RESTORE_CARD_API_LOG");if(path)fd=open(path,O_WRONLY|O_CREAT|O_APPEND,0600);
}
static void save(const char *event,uint64_t start,uint64_t end,uint64_t cpu,uint64_t wall_epoch,aclrtStream stream,
 size_t count,size_t bytes,size_t src_runs,size_t dst_runs,struct rusage *before,struct rusage *after,int result,
 uintptr_t src_first,uintptr_t dst_first){
 if(fd<0)return;int32_t device=-99;if(get_device)get_device(&device);char line[1024];int n=snprintf(line,sizeof(line),
 "{\"event\":\"%s\",\"epoch_ns\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"thread_cpu_ns\":%llu,\"pid\":%d,\"tid\":%ld,\"cpu\":%d,\"device\":%d,\"stream\":\"%p\",\"copies\":%zu,\"bytes\":%zu,\"src_runs\":%zu,\"dst_runs\":%zu,\"minor_faults\":%ld,\"major_faults\":%ld,\"voluntary_switches\":%ld,\"involuntary_switches\":%ld,\"src_first\":\"0x%lx\",\"dst_first\":\"0x%lx\",\"result\":%d}\n",
 event,(unsigned long long)wall_epoch,(unsigned long long)start,(unsigned long long)end,(unsigned long long)cpu,
 getpid(),syscall(SYS_gettid),sched_getcpu(),device,stream,count,bytes,src_runs,dst_runs,
 after->ru_minflt-before->ru_minflt,after->ru_majflt-before->ru_majflt,after->ru_nvcsw-before->ru_nvcsw,
 after->ru_nivcsw-before->ru_nivcsw,(unsigned long)src_first,(unsigned long)dst_first,result);
 if(n>0&&n<(int)sizeof(line)){pthread_mutex_lock(&mutex);(void)write(fd,line,n);pthread_mutex_unlock(&mutex);}
}
aclError aclrtHostRegister(void *ptr,uint64_t size,aclrtHostRegisterType type,void **dev){
 typedef aclError (*fn_t)(void *,uint64_t,aclrtHostRegisterType,void **);pthread_once(&once,init);
 fn_t fn=(fn_t)dlsym(RTLD_NEXT,"aclrtHostRegister");if(!fn)return 100000;
 struct rusage before,after;getrusage(RUSAGE_THREAD,&before);uint64_t ep=stamp(CLOCK_REALTIME),c=stamp(CLOCK_THREAD_CPUTIME_ID),t=stamp(CLOCK_MONOTONIC);
 aclError result=fn(ptr,size,type,dev);uint64_t end=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID)-c;getrusage(RUSAGE_THREAD,&after);
 save("host_register",t,end,cpu,ep,NULL,0,size,0,0,&before,&after,result,(uintptr_t)ptr,(result==0&&dev)?(uintptr_t)*dev:0);return result;
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
 aclrtMemcpyBatchAttr *attrs,size_t *indices,size_t attr_count,size_t *fail_index,aclrtStream stream){
 pthread_once(&once,init);if(!batch)return 100000;
 size_t bytes=0,sr=count?1:0,dr=count?1:0;
 for(size_t i=0;i<count;i++){bytes+=sizes[i];if(i){sr+=(uintptr_t)src[i-1]+sizes[i-1]!=(uintptr_t)src[i];dr+=(uintptr_t)dst[i-1]+sizes[i-1]!=(uintptr_t)dst[i];}}
 struct rusage before,after;getrusage(RUSAGE_THREAD,&before);uint64_t ep=stamp(CLOCK_REALTIME),c=stamp(CLOCK_THREAD_CPUTIME_ID),t=stamp(CLOCK_MONOTONIC);
 aclError result=batch(dst,maximum,src,sizes,count,attrs,indices,attr_count,fail_index,stream);
 uint64_t end=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID)-c;getrusage(RUSAGE_THREAD,&after);
 save("batch",t,end,cpu,ep,stream,count,bytes,sr,dr,&before,&after,result,count?(uintptr_t)src[0]:0,count?(uintptr_t)dst[0]:0);return result;
}
aclError aclrtSynchronizeStream(aclrtStream stream){
 pthread_once(&once,init);if(!sync_stream)return 100000;
 struct rusage before,after;getrusage(RUSAGE_THREAD,&before);uint64_t ep=stamp(CLOCK_REALTIME),c=stamp(CLOCK_THREAD_CPUTIME_ID),t=stamp(CLOCK_MONOTONIC);
 aclError result=sync_stream(stream);uint64_t end=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID)-c;getrusage(RUSAGE_THREAD,&after);
 save("sync",t,end,cpu,ep,stream,0,0,0,0,&before,&after,result,0,0);return result;
}
