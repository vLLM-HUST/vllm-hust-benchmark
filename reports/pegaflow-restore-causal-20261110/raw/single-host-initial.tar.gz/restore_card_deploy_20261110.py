"""Launch two identical real-model local restore instances on allocated NPUs."""
import json
import os
import pathlib
import subprocess
import sys
import time
import urllib.request

ROOT=pathlib.Path('/data/shared_upload/hust-zsx/restore-card-diag-20261110')
LIVE=pathlib.Path('/tmp/restore-card-diag-20261110')
OLD=pathlib.Path('/data/shared_upload/hust-zsx/long-pd-20261109')
PY='/usr/local/python3.12.13/bin/python3'
BINARY='/data/shared_upload/hust-zsx/issue23-scaled-20261014/runtime/bin/pegaflow-server'
MODEL='/data/shared_upload/Qwen2.5-14B-Instruct-1M-plainrope'


def env():
    return dict(os.environ,PATH='/usr/local/python3.12.13/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:'+os.environ.get('PATH',''),
        LD_LIBRARY_PATH='/usr/local/python3.12.13/lib:'+os.environ.get('LD_LIBRARY_PATH',''),
        PYTHONPATH=f'{ROOT}:{OLD}/source/python:'+os.environ.get('PYTHONPATH',''),
        OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKIO_WORKER_THREADS='2',HF_HUB_OFFLINE='1',
        TOKENIZERS_PARALLELISM='false',PYTHONHASHSEED='17',VLLM_WORKER_MULTIPROC_METHOD='spawn',
        PEGAFLOW_SYNC_SAVE='1',PEGAFLOW_SYNC_SAVE_ON_FINISH='1',PEGAFLOW_ISSUE23_DEFAULT_SCHEDULER='1',
        VLLM_SERVER_DEV_MODE='1')


def start(name,cmd,e):
    receipt=ROOT/'services'/f'{name}.json'
    if receipt.exists():raise FileExistsError(receipt)
    p=subprocess.Popen(cmd,env=e,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=(LIVE/f'{name}.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True)
    receipt.write_text(json.dumps({'pid':p.pid,'command':cmd,'epoch':time.time()},indent=2));print(name,p.pid,flush=True)
    return p


def native(card):
    logical=card['logical'];physical=card['physical'];node=card['numa_node']
    e=env();e['LD_PRELOAD']=str(ROOT/'librestore-card-api.so')+':'+e.get('LD_PRELOAD','')
    e['RESTORE_CARD_API_LOG']=str(LIVE/f'card{physical}-api.jsonl')
    return start(f'card{physical}-native',['/usr/bin/numactl',f'--membind={node}',BINARY,
        '--addr',f'127.0.0.1:{38850+logical}','--http-addr',f'127.0.0.1:{38890+logical}',
        '--devices',str(logical),'--pool-size',str(24*2**30)+'b','--disable-numa-affinity','--enable-prometheus'],e)


def model(card):
    logical=card['logical'];physical=card['physical'];dest=LIVE/f'card{physical}'
    e=env();e.update(ASCEND_RT_VISIBLE_DEVICES=str(logical),SCHEDULING_TRACE_DIR=str(dest/'traces'),
        PEGAFLOW_TELEMETRY_DIR=str(dest/'telemetry'),PEGAFLOW_TELEMETRY_ROLE=f'card{physical}',
        PEGAFLOW_SAVE_ACK_DIR=str(dest/'visibility'))
    kv={'kv_connector':'PegaKVConnector','kv_connector_module_path':'pegaflow.connector','kv_role':'kv_both',
        'engine_id':f'card-diag-20261110-{physical}','kv_connector_extra_config':{
        'pegaflow.model_revision':'qwen25-14b-1m-plainrope-20261109','pegaflow.transfer_backend':'ascend_direct',
        'pegaflow.mode':'read_write','pegaflow.host':'http://127.0.0.1','pegaflow.port':38850+logical}}
    return start(f'card{physical}-model',[PY,'-m','vllm.entrypoints.cli.main','serve',MODEL,
        '--host','0.0.0.0','--port',str(38880+logical),'--served-model-name','qwen14','--dtype','bfloat16',
        '--tensor-parallel-size','1','--max-model-len','98304','--max-num-seqs','16','--max-num-batched-tokens','8192',
        '--gpu-memory-utilization','0.90','--enable-prefix-caching','--block-size','128','--generation-config','vllm',
        '--no-async-scheduling','--seed','17','--safetensors-load-strategy','lazy','--compilation-config',
        json.dumps({'mode':3,'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[1,2,4,8,16]}),
        '--scheduler-cls','restore_card_trace_20261110.TraceScheduler','--kv-transfer-config',json.dumps(kv)],e)


def main():
    for p in [ROOT/'services',LIVE]:p.mkdir(parents=True,exist_ok=True)
    cards=json.loads((ROOT/'inventory.json').read_text())['cards']
    models={c['physical']:model(c) for c in cards};natives={};deadline=time.monotonic()+900
    while time.monotonic()<deadline:
        ready={}
        for c in cards:
            n=c['physical'];log=(LIVE/f'card{n}-model.log').read_text(errors='replace')
            if n not in natives and ('Loading model weights took' in log or 'Creating v1 connector' in log):natives[n]=native(c)
            if models[n].poll() is not None:raise RuntimeError(f'card{n} model exited; see local log')
            if n in natives and natives[n].poll() is not None:raise RuntimeError(f'card{n} native exited')
            try:ready[n]=urllib.request.urlopen(f'http://127.0.0.1:{38880+c["logical"]}/health',timeout=.5).status==200
            except OSError:ready[n]=False
        (ROOT/'readiness.json').write_text(json.dumps({'epoch':time.time(),'cards':ready,'native_started':list(natives)}))
        if all(ready.values()):
            (ROOT/'ready.json').write_text(json.dumps({'epoch':time.time(),'cards':cards}));print('Both cards ready',flush=True);return
        time.sleep(1)
    raise TimeoutError('Model readiness exceeded 15 minutes')


if __name__=='__main__':
    try:main()
    except BaseException as error:
        import traceback
        (ROOT/'startup-failure.json').write_text(json.dumps({'epoch':time.time(),'error':repr(error),'traceback':traceback.format_exc()}));raise
