/* Finite immutable-source diagnosis: compare CANN batching with prepared
 * synchronous HAL submissions at identical shadow source and NPU addresses.
 * Mode32 owns descriptor lifetime; other modes release it before continuing.
 * Each direct batch synchronizes its CANN stream before bypassing the queue. */
#define aclrtMemcpyBatchAsync causal_base_batch
#include "shadow-v2.c"
#undef aclrtMemcpyBatchAsync

struct PreparedBatch {
    size_t count, initialized;
    void **source, **destination;
    size_t *sizes;
    struct DMA_ADDR *dma;
    struct PreparedBatch *next;
};
static struct PreparedBatch *prepared;
typedef DVresult (*ConvertDMA)(DVdeviceptr, DVdeviceptr, UINT32, struct DMA_ADDR *);
typedef DVresult (*DestroyDMA)(struct DMA_ADDR *);
typedef DVresult (*SubmitDMA)(struct DMA_ADDR *, int);

static int clear_prepared(void)
{
    if (!prepared) return 0;
    uint64_t begin = stamp();
    DestroyDMA destroy = (DestroyDMA)symbol("drvMemDestroyAddr");
    while (prepared) {
        struct PreparedBatch *item = prepared;
        for (size_t i = 0; i < item->initialized; i++) {
            int result = destroy(&item->dma[i]);
            if (result) { emit("direct_cache_destroy", begin, stamp(), result); return result; }
        }
        prepared = item->next;
        free(item->source); free(item->destination); free(item->sizes); free(item->dma); free(item);
    }
    emit("direct_cache_destroy", begin, stamp(), 0);
    return 0;
}

static struct PreparedBatch *lookup(void **src, void **dst, size_t *sizes, size_t count)
{
    for (struct PreparedBatch *item = prepared; item; item = item->next) {
        if (item->count != count) continue;
        size_t i = 0;
        for (; i < count; i++)
            if (item->source[i] != src[i] || item->destination[i] != dst[i] || item->sizes[i] != sizes[i]) break;
        if (i == count) return item;
    }
    return NULL;
}

aclError aclrtMemcpyBatchAsync(void **dst, size_t *maximum, void **src, size_t *sizes,
    size_t count, aclrtMemcpyBatchAttr *attr, size_t *indices, size_t nattr,
    size_t *failed, aclrtStream stream)
{
    int h2d = attr && indices && nattr == 1 && indices[0] == 0 &&
        attr[0].srcLoc.type == ACL_MEM_LOCATION_TYPE_HOST &&
        attr[0].dstLoc.type == ACL_MEM_LOCATION_TYPE_DEVICE;
    if (!h2d) return causal_base_batch(dst, maximum, src, sizes, count, attr, indices, nattr, failed, stream);
    int mode = 0;
    const char *policy = getenv("NATIVE_COPY_POLICY");
    if (policy) { int f = open(policy, O_RDONLY); if (f >= 0) { read(f, &mode, sizeof(mode)); close(f); } }
    pthread_mutex_lock(&mutex);
    if (mode != 32) {
        int error = clear_prepared(); pthread_mutex_unlock(&mutex);
        if (error) return error;
        return causal_base_batch(dst, maximum, src, sizes, count, attr, indices, nattr, failed, stream);
    }
    int error = activate(1);
    if (error) { pthread_mutex_unlock(&mutex); return error; }
    void **redirect = malloc(count * sizeof(*redirect));
    if (!redirect) { pthread_mutex_unlock(&mutex); return 100000; }
    for (size_t i = 0; i < count; i++) {
        uintptr_t address = (uintptr_t)src[i];
        if (address < source_base || sizes[i] > source_bytes ||
            address - source_base > source_bytes - sizes[i] || sizes[i] > UINT32_MAX) {
            free(redirect); pthread_mutex_unlock(&mutex); return 100000;
        }
        redirect[i] = (char *)shadow + address - source_base;
    }
    typedef aclError (*Sync)(aclrtStream);
    uint64_t begin = stamp();
    error = ((Sync)symbol("aclrtSynchronizeStream"))(stream);
    emit("direct_stream_fence", begin, stamp(), error);
    if (error) { free(redirect); pthread_mutex_unlock(&mutex); return error; }
    struct PreparedBatch *item = lookup(redirect, dst, sizes, count);
    if (!item) {
        begin = stamp();
        item = calloc(1, sizeof(*item));
        if (!item) { free(redirect); pthread_mutex_unlock(&mutex); return 100000; }
        item->source = redirect; redirect = NULL;
        item->destination = malloc(count * sizeof(*dst));
        item->sizes = malloc(count * sizeof(*sizes)); item->dma = calloc(count, sizeof(*item->dma));
        if (!item->destination || !item->sizes || !item->dma) _Exit(125);
        memcpy(item->destination, dst, count * sizeof(*dst)); memcpy(item->sizes, sizes, count * sizeof(*sizes));
        item->count = count; item->next = prepared; prepared = item;
        ConvertDMA convert = (ConvertDMA)symbol("drvMemConvertAddr");
        for (size_t i = 0; i < count; i++) {
            item->dma[i].offsetAddr.devid = device;
            error = convert((DVdeviceptr)(uintptr_t)item->source[i], (DVdeviceptr)(uintptr_t)dst[i], sizes[i], &item->dma[i]);
            if (error || item->dma[i].fixed_size != sizes[i]) {
                if (!error) error = 100000;
                if (failed) *failed = i;
                emit("direct_cache_prepare", begin, stamp(), error);
                free(redirect); pthread_mutex_unlock(&mutex); return error;
            }
            item->initialized++;
        }
        emit("direct_cache_prepare", begin, stamp(), 0);
    }
    free(redirect);
    SubmitDMA submit = (SubmitDMA)symbol("halMemcpySumbit");
    begin = stamp(); uint64_t bytes = 0;
    for (size_t i = 0; i < count; i++) {
        error = submit(&item->dma[i], MEMCPY_SUMBIT_SYNC);
        if (error) { if (failed) *failed = i; break; }
        bytes += sizes[i];
    }
    uint64_t end = stamp();
    if (fd >= 0) {
        char line[600];
        int n = snprintf(line, sizeof(line), "{\"event\":\"direct_cached_copy\",\"start_ns\":%llu,\"end_ns\":%llu,\"copies\":%zu,\"bytes\":%llu,\"error\":%d,\"src_first\":\"%p\",\"dst_first\":\"%p\"}\n",
            (unsigned long long)begin, (unsigned long long)end, count, (unsigned long long)bytes, error, item->source[0], dst[0]);
        write(fd, line, n);
    }
    pthread_mutex_unlock(&mutex);
    return error;
}
