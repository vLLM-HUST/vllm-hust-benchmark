"""Finite, capacity-controlled native D2H save crossover with versioned data tags."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pickle
import shutil
import signal
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.request

from restore_causal_probe_20261110 import BASE, BINARY, BLOCK_BYTES, PLANES, SOURCE, free_port, resources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True)
    parser.add_argument('--device', type=int, required=True)
    parser.add_argument('--numa', type=int, required=True)
    parser.add_argument('--name', default='save-stripe')
    args = parser.parse_args()
    root = BASE / args.host / f'{args.name}-device{args.device}'
    root.mkdir(parents=True, exist_ok=False)
    live = Path('/tmp/restore-causal-20261110') / f'{args.name}-device{args.device}'
    live.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, root / 'executed-probe.py')
    stop = threading.Event()
    server = None

    def watchdog():
        if not stop.wait(900):
            (root / 'watchdog.json').write_text(json.dumps({'epoch': time.time()}))
            if server is not None:
                try:
                    os.killpg(server.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            os._exit(124)

    threading.Thread(target=watchdog, daemon=True).start()
    try:
        sys.path.insert(0, SOURCE)
        import torch
        import torch_npu
        from pegaflow.npu_ipc_wrapper import NpuIPCWrapper
        from pegaflow.pegaflow import EngineRpcClient, PyLoadState
        torch.set_num_threads(1)
        torch.npu.set_device(args.device)
        planes = [torch.full((512, BLOCK_BYTES // 2), .25, dtype=torch.bfloat16,
                             device=f'npu:{args.device}') for _ in range(PLANES)]
        wrappers = [pickle.dumps(NpuIPCWrapper(tensor)) for tensor in planes]
        names = [f'plane-{i}' for i in range(PLANES)]
        count, pool_bytes = 161, 24 * 2**30
        modes = [0, 0, 12, 0, 13]
        assert len(modes) * count * PLANES * BLOCK_BYTES < pool_bytes
        instance = f'save-causal-{args.host}-{args.name}-{args.device}'
        port, http = free_port(), free_port()
        policy = root / 'policy.bin'
        policy.write_bytes(struct.pack('i', 0))
        env = dict(os.environ, PEGAFLOW_SYNC_SAVE='1', TOKIO_WORKER_THREADS='2',
                   PYTHONPATH=SOURCE + ':' + os.environ.get('PYTHONPATH', ''),
                   LD_LIBRARY_PATH='/usr/local/python3.12.13/lib:' + os.environ.get('LD_LIBRARY_PATH', ''),
                   LD_PRELOAD=str(BASE / 'memory-policy-stripe-v2.so') + ':' + str(BASE / 'model-observer.so') + ':' + str(BASE / 'register-control.so'),
                   CAUSAL_REGISTER_MODE='v1', NATIVE_COPY_POLICY=str(policy),
                   RESTORE_CARD_API_LOG=str(live / 'api.jsonl'))
        command = ['/usr/bin/numactl', f'--membind={args.numa}', BINARY, '--devices', str(args.device),
                   '--pool-size', f'{pool_bytes}b', '--disable-numa-affinity', '--addr', f'127.0.0.1:{port}',
                   '--http-addr', f'127.0.0.1:{http}', '--enable-prometheus']
        config = dict(host=args.host, device=args.device, numa=args.numa, command=command,
                      planes=PLANES, capacity=512, blocks=count, pool_bytes=pool_bytes,
                      modes=modes, torch=torch.__version__, torch_npu=torch_npu.__version__,
                      preload=env['LD_PRELOAD'], epoch=time.time())
        (root / 'config.json').write_text(json.dumps(config, indent=2))
        log = (live / 'native.log').open('w')
        server = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (root / 'native-process.json').write_text(json.dumps(dict(pid=server.pid, command=command)))
        until = time.monotonic() + 100
        while True:
            if server.poll() is not None:
                raise RuntimeError('Native exited during startup')
            try:
                urllib.request.urlopen(f'http://127.0.0.1:{http}/health', timeout=1).read()
                break
            except OSError:
                if time.monotonic() > until:
                    raise TimeoutError('Native readiness')
                time.sleep(.2)
        client = EngineRpcClient(f'http://127.0.0.1:{port}')
        ok, message = client.register_context_batch(instance, instance, 0, 0, 1, 1, args.device,
            names, wrappers, [512] * PLANES, [BLOCK_BYTES] * PLANES, [0] * PLANES, [1] * PLANES,
            'ascend_direct', False)
        if not ok:
            raise RuntimeError(message)
        for stage, mode in enumerate(modes):
            for plane, tensor in enumerate(planes):
                tags = ((torch.arange(count, device=f'npu:{args.device}', dtype=torch.int32)
                         + plane * 521 + 1000 + stage * 100) % 30000).to(torch.int16)
                tensor.view(torch.int16)[:count, 0] = tags
            torch.npu.synchronize()
            hashes = [hashlib.sha256(f'{instance}:stage:{stage}:block:{i}'.encode()).digest() for i in range(count)]
            policy.write_bytes(struct.pack('i', mode))
            before = resources()
            epoch, start = time.time_ns(), time.monotonic()
            ok, message = client.save(instance, 0, 0, args.device,
                                      [(name, list(range(count)), hashes) for name in names])
            ack = time.monotonic()
            if not ok:
                raise RuntimeError(message)
            until = time.monotonic() + 180
            while True:
                query = client.query_prefetch(instance, hashes, f'{instance}:{stage}')
                if hasattr(query, 'num_hit_blocks') and query.num_hit_blocks == count:
                    break
                if time.monotonic() > until:
                    raise TimeoutError('Saved prefix visibility')
                time.sleep(.002)
            visible = time.monotonic()
            row = dict(stage=stage, policy=mode, warmup=stage == 0, bytes=count * PLANES * BLOCK_BYTES,
                       descriptors=count * PLANES, start_epoch_ns=epoch, end_epoch_ns=time.time_ns(),
                       save_ack_s=ack - start, save_visible_s=visible - start,
                       resources_before=before, resources_after=resources())
            policy.write_bytes(struct.pack('i', 0))
            destinations = list(range(256, 256 + count))[::-1]
            checks = [0, count // 2, count - 1]
            for plane in [0, 95]:
                planes[plane].view(torch.int16)[[destinations[i] for i in checks], 0] = 0
            torch.npu.synchronize()
            state = PyLoadState()
            ok, message = client.load(instance, 0, args.device, state.shm_name(), [names],
                                      [(query.lease, [destinations])])
            if not ok:
                raise RuntimeError(message)
            until = time.monotonic() + 180
            while not state.is_ready():
                if time.monotonic() > until:
                    raise TimeoutError('Validation restore')
                time.sleep(.001)
            if state.get_state() < 0:
                raise RuntimeError('Validation restore failed')
            observed = []
            for plane in [0, 95]:
                values = planes[plane].view(torch.int16)[[destinations[i] for i in checks], 0].cpu().tolist()
                expected = [(i + plane * 521 + 1000 + stage * 100) % 30000 for i in checks]
                if values != expected:
                    raise RuntimeError(f'Saved version differs: {values} != {expected}')
                observed.append(values)
            row['verified_tags'] = observed
            with (root / 'operations.jsonl').open('a') as output:
                output.write(json.dumps(row) + '\n')
            print(json.dumps({k: row[k] for k in ['stage', 'policy', 'save_ack_s', 'save_visible_s']}), flush=True)
        client.unregister_context(instance)
        (root / 'done.json').write_text(json.dumps(dict(epoch=time.time(),saves=len(modes))))
    except BaseException as error:
        (root / 'failure.json').write_text(json.dumps(dict(error=repr(error), traceback=traceback.format_exc())))
        raise
    finally:
        stop.set()
        if server is not None and server.poll() is None:
            os.killpg(server.pid, signal.SIGTERM)
            try:
                server.wait(10)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL)
                server.wait()
        shutil.copytree(live, root / 'raw', dirs_exist_ok=True)


if __name__ == '__main__':
    main()
