#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef aclError (*batch_fn)(void **, size_t *, void **, size_t *, size_t,
                            aclrtMemcpyBatchAttr *, size_t *, size_t, size_t *, aclrtStream);
typedef aclError (*copy_fn)(void *, size_t, const void *, size_t, aclrtMemcpyKind, aclrtStream);
static batch_fn original_batch;
static copy_fn original_copy;
static pthread_once_t initialized = PTHREAD_ONCE_INIT;
static int trace_fd = -1;

static void initialize(void) {
    original_batch = (batch_fn)dlsym(RTLD_NEXT, "aclrtMemcpyBatchAsync");
    original_copy = (copy_fn)dlsym(RTLD_NEXT, "aclrtMemcpyAsync");
    const char *path = getenv("CAL_COPY_TRACE_FILE");
    if (path) trace_fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
}

static uint64_t nanoseconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

aclError aclrtMemcpyBatchAsync(void **dst, size_t *maximum, void **src, size_t *sizes,
    size_t count, aclrtMemcpyBatchAttr *attrs, size_t *indices, size_t attr_count,
    size_t *fail_index, aclrtStream stream) {
    pthread_once(&initialized, initialize);
    if (!original_batch || !original_copy) return 100000;
    char mode[32] = "batch";
    const char *mode_path = getenv("CAL_COPY_MODE_FILE");
    if (mode_path) {
        int fd = open(mode_path, O_RDONLY);
        if (fd >= 0) {
            ssize_t n = read(fd, mode, sizeof(mode)-1);
            close(fd);
            if (n > 0) {mode[n] = '\0'; mode[strcspn(mode, "\r\n ")] = '\0';}
        }
    }
    int supported = attrs && indices && attr_count == 1 && indices[0] == 0 &&
        ((attrs[0].srcLoc.type == ACL_MEM_LOCATION_TYPE_HOST && attrs[0].dstLoc.type == ACL_MEM_LOCATION_TYPE_DEVICE) ||
         (attrs[0].dstLoc.type == ACL_MEM_LOCATION_TYPE_HOST && attrs[0].srcLoc.type == ACL_MEM_LOCATION_TYPE_DEVICE));
    int serial = supported && (!strcmp(mode, "serial") || !strcmp(mode, "coalesce_serial"));
    int coalesce = supported && (!strcmp(mode, "coalesce") || !strcmp(mode, "coalesce_serial"));
    void **md = NULL, **ms = NULL;
    size_t *mm = NULL, *mz = NULL;
    size_t submitted = count, bytes = 0;
    for (size_t i = 0; i < count; i++) bytes += sizes[i];
    if (coalesce && count) {
        md = malloc(count*sizeof(void *)); ms = malloc(count*sizeof(void *));
        mm = malloc(count*sizeof(size_t)); mz = malloc(count*sizeof(size_t));
        if (md && ms && mm && mz) {
            submitted = 0;
            for (size_t i = 0; i < count; i++) {
                if (submitted && (uintptr_t)md[submitted-1]+mz[submitted-1] == (uintptr_t)dst[i] &&
                    (uintptr_t)ms[submitted-1]+mz[submitted-1] == (uintptr_t)src[i]) {
                    mz[submitted-1] += sizes[i]; mm[submitted-1] += maximum[i];
                } else {
                    md[submitted] = dst[i]; ms[submitted] = src[i];
                    mm[submitted] = maximum[i]; mz[submitted] = sizes[i]; submitted++;
                }
            }
        } else coalesce = 0;
    }
    void **d = coalesce ? md : dst, **s = coalesce ? ms : src;
    size_t *m = coalesce ? mm : maximum, *z = coalesce ? mz : sizes;
    if (!coalesce) submitted = count;
    uint64_t start = nanoseconds();
    aclError result = 0;
    if (serial) {
        aclrtMemcpyKind kind = attrs[0].dstLoc.type == ACL_MEM_LOCATION_TYPE_DEVICE ?
            ACL_MEMCPY_HOST_TO_DEVICE : ACL_MEMCPY_DEVICE_TO_HOST;
        if (fail_index) *fail_index = SIZE_MAX;
        for (size_t i = 0; i < submitted; i++) {
            result = original_copy(d[i], m[i], s[i], z[i], kind, stream);
            if (result) {if (fail_index) *fail_index = i; break;}
        }
    } else {
        result = original_batch(d,m,s,z,submitted,attrs,indices,attr_count,fail_index,stream);
    }
    uint64_t end = nanoseconds();
    if (trace_fd >= 0) {
        char line[384];
        int n = snprintf(line,sizeof(line),"{\"pid\":%d,\"mode\":\"%s\",\"start_ns\":%llu,\"end_ns\":%llu,\"input_copies\":%zu,\"submitted_copies\":%zu,\"bytes\":%zu,\"result\":%d}\n",
            getpid(),mode,(unsigned long long)start,(unsigned long long)end,count,submitted,bytes,result);
        if (n > 0 && n < (int)sizeof(line)) (void)write(trace_fd,line,(size_t)n);
    }
    free(md);free(ms);free(mm);free(mz);
    return result;
}
