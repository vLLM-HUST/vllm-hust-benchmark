
import gzip,json,pathlib,time,httpx
r=pathlib.Path('/data/shared_upload/hust-zsx/long-pd-20261109')
with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as f:rows=[json.loads(l) for l in f]
case=min(rows,key=lambda x:abs(x['prompt_tokens']-8192));payload={'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,'temperature':0,'ignore_eos':True,'cache_salt':'paired-copy-source-8192','request_id':'coalesce-D1-8244'}
try:
 (r/'copy-mode.txt').write_text('coalesce')
 with httpx.Client(timeout=150,trust_env=False) as c:
  c.post('http://192.168.0.2:38683/reset_prefix_cache?reset_running_requests=true').raise_for_status()
  epoch=time.time_ns();begin=time.monotonic();response=c.post('http://192.168.0.2:38683/v1/completions',json=payload);response.raise_for_status();data=response.json()
  result={'id':payload['request_id'],'epoch_ns':epoch,'elapsed_s':time.monotonic()-begin,'usage':data.get('usage'),'choices':data.get('choices')}
  (r/'coalesce-screen.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
finally:(r/'copy-mode.txt').write_text('batch')
