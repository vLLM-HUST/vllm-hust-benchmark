
import asyncio,gzip,json,time,pathlib,httpx
r=pathlib.Path('/data/shared_upload/hust-zsx/long-pd-20261109')
async def main():
 with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as f:rows=[json.loads(l) for l in f]
 cases=[min(rows,key=lambda x:abs(x['prompt_tokens']-n)) for n in [1000,8000,32000,61000]]
 async with httpx.AsyncClient(timeout=120,trust_env=False) as client:
  async def node(i):
   for k,case in enumerate(cases):
    for phase in ['cold','warm']:
     key=f'p-capacity-P{i}-{k}-{phase}'
     begin=time.monotonic();response=await client.post(f'http://192.168.0.4:{38680+i}/v1/completions',json={'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,'temperature':0,'ignore_eos':True,'request_id':key,'cache_salt':f'p-capacity-{i}-{k}'})
     response.raise_for_status();http=time.monotonic()-begin
     marker=r/'visibility'/f'P{i}'/f'{key}.tp0.visible'
     while not marker.exists():
      if time.monotonic()-begin>120:raise TimeoutError('save ACK')
      await asyncio.sleep(.005)
     record={'epoch_ns':time.time_ns(),'P':f'P{i}','condition':phase,'prompt_tokens':case['prompt_tokens'],'http_s':http,'published_s':time.monotonic()-begin,'usage':response.json().get('usage')}
     with (r/'P-capacity.jsonl').open('a') as out:out.write(json.dumps(record)+'\n')
     print(json.dumps(record),flush=True)
  await asyncio.gather(node(0),node(1))
asyncio.run(main())
