
import asyncio,gzip,json,time,pathlib,httpx
r=pathlib.Path('/data/shared_upload/hust-zsx/long-pd-20261109')
async def main():
 with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as f:rows=[json.loads(l) for l in f]
 short=min(rows,key=lambda x:abs(x['prompt_tokens']-8192));long=max(rows,key=lambda x:x['prompt_tokens'])
 (r/'copy-mode.txt').write_text('batch');(r/'phase.json').write_text(json.dumps({'phase':'numa-D0-pool-history'}))
 async with httpx.AsyncClient(timeout=150,trust_env=False) as client:
  async def produce(i,case):
   node=i%2;key=f'numa-history-source-{i}';payload={'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,'temperature':0,'ignore_eos':True,'cache_salt':f'numa-history-{i}'}
   response=await client.post(f'http://192.168.0.4:{38680+node}/v1/completions',json=payload|{'request_id':key});response.raise_for_status()
   deadline=time.monotonic()+60
   while not (r/'visibility'/f'P{node}'/f'{key}.tp0.visible').exists():
    if time.monotonic()>deadline:raise TimeoutError('Producer publication')
    await asyncio.sleep(.005)
   return payload
  payloads={}
  async def sources(node):
   for i in range(node,12,2):payloads[i]=await produce(i,short)
  await asyncio.gather(sources(0),sources(1))
  async def consume(i,round_number,phase):
   await client.post('http://192.168.0.2:38682/reset_prefix_cache?reset_running_requests=true')
   key=f'numa-history-D0-{phase}-{round_number}-{i}';begin=time.monotonic();epoch=time.time_ns()
   response=await client.post('http://192.168.0.2:38682/v1/completions',json=payloads[i]|{'request_id':key});response.raise_for_status();data=response.json()
   record={'id':key,'phase':phase,'round':round_number,'source':f'P{i%2}','prompt_tokens':len(payloads[i]['prompt']),'epoch_ns':epoch,'elapsed_s':time.monotonic()-begin,'usage':data.get('usage'),'choices':data.get('choices')}
   with (r/'numa-history.jsonl').open('a') as out:out.write(json.dumps(record)+'\n')
   print(json.dumps(record),flush=True)
   if data.get('usage',{}).get('completion_tokens')!=1:raise RuntimeError('Restore failed')
  for round_number in range(3):
   for i in range(12):await consume(i,round_number,'8k')
  for i,payload in zip([12,13],await asyncio.gather(produce(12,long),produce(13,long))):payloads[i]=payload
  for i in [12,13]:await consume(i,0,'61k')
 (r/'numa-history-done.json').write_text(json.dumps({'epoch':time.time(),'requests':38}))
try:asyncio.run(main())
except BaseException as e:
 (r/'numa-history-failure.json').write_text(json.dumps({'epoch':time.time(),'error':repr(e)}));raise
