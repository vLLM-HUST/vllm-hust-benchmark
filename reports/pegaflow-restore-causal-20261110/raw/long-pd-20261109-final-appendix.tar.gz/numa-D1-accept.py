
import pathlib,json,gzip,time,httpx
r=pathlib.Path('/data/shared_upload/hust-zsx/long-pd-20261109')
with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as f:rows=[json.loads(l) for l in f]
case=min(rows,key=lambda x:abs(x['prompt_tokens']-8192));payload={'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,'temperature':0,'ignore_eos':True,'cache_salt':'numa-D1-accept'}
with httpx.Client(timeout=150,trust_env=False) as c:
 key='numa-D1-accept-producer';c.post('http://192.168.0.4:38680/v1/completions',json=payload|{'request_id':key}).raise_for_status()
 deadline=time.monotonic()+60
 while not (r/'visibility/P0'/f'{key}.tp0.visible').exists():
  if time.monotonic()>deadline:raise TimeoutError('P publication')
  time.sleep(.005)
 begin=time.monotonic();response=c.post('http://192.168.0.2:38683/v1/completions',json=payload|{'request_id':'numa-D1-accept-consumer'});response.raise_for_status();data=response.json()
 result={'elapsed_s':time.monotonic()-begin,'epoch_ns':time.time_ns(),'prompt_tokens':case['prompt_tokens'],'usage':data.get('usage')}
 (r/'numa-D1-accept.json').write_text(json.dumps(result));print(result,flush=True)
 if data.get('usage',{}).get('completion_tokens')!=1:raise RuntimeError('D1 acceptance failed')
