import json,subprocess,time,urllib.request
from pathlib import Path
p=Path('/data/shared_upload/hust-zsx/long-pd-20261109');deadline=time.monotonic()+900
while True:
 try:
  with urllib.request.urlopen('http://127.0.0.1:38680/health',timeout=1) as r:
   if r.status==200:break
 except OSError:pass
 if time.monotonic()>deadline:raise TimeoutError('P0 readiness deadline')
 time.sleep(2)
for action in ['native','model']:
 subprocess.run(['/usr/local/python3.12.13/bin/python3',str(p/'long_pd_deploy_20261109.py'),'--role','P','--instance','P1','--action',action],check=True)
print('P1 launched after P0 ready',flush=True)
