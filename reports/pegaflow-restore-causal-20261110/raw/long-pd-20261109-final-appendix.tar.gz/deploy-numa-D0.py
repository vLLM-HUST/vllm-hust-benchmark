"""Start owned P/D services for the allocated two-node 14B experiment."""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/data/shared_upload/hust-zsx/long-pd-20261109')

def spawn(name, command, env):
    p = ROOT/'services'/f'{name}.json'
    if p.exists():
        raise FileExistsError(p)
    proc = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=(ROOT/'services'/f'{name}.log').open('w'),
                            stderr=subprocess.STDOUT, env=env, cwd=ROOT, start_new_session=True)
    p.write_text(json.dumps({'pid':proc.pid, 'command':command, 'started':time.time()}))
    print(name, proc.pid, flush=True)

def main():
    a=argparse.ArgumentParser();a.add_argument('--role',choices=['P','D'],required=True)
    a.add_argument('--action',choices=['native','model'],required=True);a.add_argument('--instance')
    args=a.parse_args();cfg=json.loads((ROOT/'config.json').read_text())
    env=dict(os.environ, LD_LIBRARY_PATH='/usr/local/python3.12.13/lib:'+os.environ.get('LD_LIBRARY_PATH',''),
             PYTHONPATH=f'{ROOT}:{ROOT}/source/python:'+os.environ.get('PYTHONPATH',''),
             OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKIO_WORKER_THREADS='2',HF_HUB_OFFLINE='1',
             TOKENIZERS_PARALLELISM='false',PYTHONHASHSEED='17',VLLM_WORKER_MULTIPROC_METHOD='spawn',
             PEGAFLOW_SYNC_SAVE='1',PEGAFLOW_SYNC_SAVE_ON_FINISH='1',PEGAFLOW_ISSUE23_DEFAULT_SCHEDULER='1',
             VLLM_SERVER_DEV_MODE='1',HCCL_IF_IP=cfg['hosts'][args.role],GLOO_SOCKET_IFNAME='bond1')
    if args.role=='D' and args.action=='native':
        env['LD_PRELOAD']=str(ROOT/'libcopy-api-diagnostic.so')+':'+env.get('LD_PRELOAD','')
        env['CAL_COPY_MODE_FILE']=str(ROOT/'copy-mode.txt')
        env['CAL_COPY_TRACE_FILE']=str(ROOT/'copy-api.jsonl')
    binary=cfg['binary']
    if args.action=='native' and args.role=='P' and not (ROOT/'services/meta.json').exists():
        spawn('meta',[binary+'/pegaflow-metaserver','--addr',cfg['hosts']['P']+':38656','--http-addr','0.0.0.0:38692'],env)
    for i in cfg['instances']:
        if i['role']!=args.role or (args.instance and args.instance!=i['id']):continue
        name=i['id'];host=cfg['hosts'][args.role]
        if args.action=='native':
            spawn(name+'-engine',['/usr/bin/numactl','--membind=6',binary+'/pegaflow-server','--addr',f"{host}:{i['engine_port']}",
                 '--http-addr',f"0.0.0.0:{i['http_port']}",'--devices',str(i['device']),
                 '--pool-size',str(24*2**30)+'b','--disable-numa-affinity','--enable-prometheus',
                 '--nics','mlx5_2','--metaserver-addr',f"http://{cfg['hosts']['P']}:38656"],env)
            continue
        current=dict(env,ASCEND_RT_VISIBLE_DEVICES=str(i['device']),
                     SCHEDULING_TRACE_DIR=str(ROOT/'traces'/name),PEGAFLOW_TELEMETRY_DIR=str(ROOT/'telemetry'/name),
                     PEGAFLOW_TELEMETRY_ROLE=name,PEGAFLOW_SAVE_ACK_DIR=str(ROOT/'visibility'/name))
        transfer={'kv_connector':'PegaKVConnector','kv_connector_module_path':'pegaflow.connector','kv_role':'kv_both',
                  'engine_id':'longpd-20261109-'+name,'kv_connector_extra_config':{
                      'pegaflow.model_revision':'qwen25-14b-1m-plainrope-20261109',
                      'pegaflow.transfer_backend':'ascend_direct','pegaflow.mode':'save_only' if args.role=='P' else 'read_write',
                      'pegaflow.host':'http://'+host,'pegaflow.port':i['engine_port'],'pegaflow.wait_for_full_prefix':args.role=='D'}}
        cmd=[sys.executable,'-m','vllm.entrypoints.cli.main','serve',cfg['model'], '--host','0.0.0.0',
             '--port',str(i['model_port']),'--served-model-name','qwen14','--dtype','bfloat16','--tensor-parallel-size','1',
             '--max-model-len','98304','--max-num-seqs','16','--max-num-batched-tokens','8192',
             '--gpu-memory-utilization','0.90','--enable-prefix-caching','--block-size','128',
             '--generation-config','vllm','--no-async-scheduling','--seed','17',
             '--safetensors-load-strategy','lazy','--compilation-config',
             json.dumps({'mode':3,'cudagraph_mode':'FULL_DECODE_ONLY','cudagraph_capture_sizes':[1,2,4,8,16]}),
             '--scheduler-cls','long_pd_trace_20261109.TraceScheduler','--kv-transfer-config',json.dumps(transfer)]
        spawn(name+'-model',cmd,current)

if __name__=='__main__':main()
