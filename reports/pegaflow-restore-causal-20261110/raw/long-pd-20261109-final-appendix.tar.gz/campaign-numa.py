"""Run a route smoke and two complete-session conditions on healthy services."""
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT=Path('/data/shared_upload/hust-zsx/long-pd-20261109')

def main():
    cfg=json.loads((ROOT/'config.json').read_text());deadline=time.monotonic()+1200
    while True:
        ready={}
        for r in cfg['instances']:
            try:
                with urllib.request.urlopen(f"http://{cfg['hosts'][r['role']]}:{r['model_port']}/health",timeout=1) as response:
                    ready[r['id']]=response.status==200
            except OSError:ready[r['id']]=False
        (ROOT/'readiness.json').write_text(json.dumps({'epoch':time.time(),'models':ready}))
        if all(ready.values()):break
        if time.monotonic()>deadline:raise TimeoutError('Model startup exceeded deadline')
        time.sleep(2)
    print('All four models healthy',flush=True)
    cmd=[sys.executable,str(ROOT/'run.py')]
    subprocess.run([sys.executable,str(ROOT/'numa-D1-accept.py')],check=True)
    for routing in ['random','sticky']:
        for r in cfg['instances']:
            host=cfg['hosts'][r['role']]
            for url in [f"http://{host}:{r['model_port']}/reset_prefix_cache",f"http://{host}:{r['http_port']}/cache/memory/cleanup"]:
                request=urllib.request.Request(url,method='POST')
                with urllib.request.urlopen(request,timeout=30) as response:
                    if response.status!=200:raise RuntimeError('Cache reset failed')
        label=f'{routing}-numa-4sessions-rps3-s17'
        subprocess.run(cmd+['--label',label,'--routing',routing,'--rate','3','--seed','17','--sessions','4','--d-pending-budget-gib','24'],check=True,timeout=1200)
    (ROOT/'campaign-numa-done.json').write_text(json.dumps({'epoch':time.time(),'complete':True}))
    for role in ['P','D']:(ROOT/'resources'/f'stop-{role}').touch()

if __name__=='__main__':
    try:main()
    except BaseException as e:
        import traceback
        (ROOT/'campaign-numa-failure.json').write_text(json.dumps({'error':repr(e),'traceback':traceback.format_exc(),'epoch':time.time()}))
        raise
