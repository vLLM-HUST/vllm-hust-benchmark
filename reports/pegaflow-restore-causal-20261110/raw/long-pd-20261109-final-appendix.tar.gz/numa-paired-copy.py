
import asyncio,gzip,json,time,pathlib,httpx,urllib.request
r=pathlib.Path('/data/shared_upload/hust-zsx/long-pd-20261109')
async def main():
 with gzip.open('/data/shared_upload/hust-zsx/kv-candidate-20261109/workload/swe-next-ready/long-sessions-full.jsonl.gz','rt') as f:rows=[json.loads(l) for l in f]
 case=min(rows,key=lambda x:abs(x['prompt_tokens']-8192))
 payload={'model':'qwen14','prompt':case['prompt_token_ids'],'max_tokens':1,'temperature':0,'ignore_eos':True,'cache_salt':'paired-copy-source-8192'}
 async with httpx.AsyncClient(timeout=150,trust_env=False) as client:
  key='numa-paired-copy-producer'
  response=await client.post('http://192.168.0.4:38680/v1/completions',json=payload|{'request_id':key});response.raise_for_status()
  while not (r/'visibility/P0'/f'{key}.tp0.visible').exists():await asyncio.sleep(.005)
  for node in [0,1]:
   for repeat,mode in enumerate(['batch','serial','serial','batch']):
    (r/'copy-mode.txt').write_text(mode)
    url=f'http://192.168.0.2:{38682+node}'
    response=await client.post(url+'/reset_prefix_cache?reset_running_requests=true');response.raise_for_status()
    key=f'numa-paired-copy-D{node}-{repeat}-{mode}';begin=time.monotonic();epoch=time.time_ns()
    response=await client.post(url+'/v1/completions',json=payload|{'request_id':key});response.raise_for_status()
    data=response.json();record={'id':key,'D':f'D{node}','mode':mode,'epoch_ns':epoch,'elapsed_s':time.monotonic()-begin,'prompt_tokens':case['prompt_tokens'],'usage':data.get('usage'),'choices':data.get('choices')}
    with (r/'numa-paired-copy.jsonl').open('a') as output:output.write(json.dumps(record)+'\n')
    print(json.dumps(record),flush=True)
    if data.get('usage',{}).get('completion_tokens')!=1:raise RuntimeError('Probe failed')
 (r/'copy-mode.txt').write_text('serial')
 (r/'numa-paired-copy-done.json').write_text(json.dumps({'epoch':time.time()}))

deadline=time.monotonic()+900
while True:
 try:
  if urllib.request.urlopen('http://192.168.0.2:38682/health',timeout=2).status==200:break
 except OSError:pass
 if time.monotonic()>deadline:raise TimeoutError('D0 NUMA model startup')
 time.sleep(2)
asyncio.run(main())

