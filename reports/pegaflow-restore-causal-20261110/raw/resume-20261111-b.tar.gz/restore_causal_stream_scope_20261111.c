/* Same host pages and H2D descriptors; vary only their preparation history. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char **argv){
 alarm(600);int device=argc>1?atoi(argv[1]):1;size_t piece=262144,n=16384,bytes=n*piece;
 void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*source=NULL,*dest=NULL;aclrtStream stream=NULL;
 if(host==MAP_FAILED)return 2;memset(host,0x5a,bytes);
 for(int j=0;j<8;j++)*(uint64_t*)((char*)host+(size_t)j*(n-1)/7*piece)=7000+(size_t)j*(n-1)/7;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
 CHECK(aclrtMalloc(&source,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 CHECK(aclrtMemcpyAsync(source,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream));CHECK(aclrtSynchronizeStream(stream));
 typedef int(*Nop)(void*);Nop nop=(Nop)dlsym(RTLD_DEFAULT,"rtNopTask");if(!nop)return 3;
 int order[3][3]={{0,1,2},{2,1,0},{1,0,2}};
 for(int repeat=0;repeat<3;repeat++)for(int step=0;step<3;step++){
  int kind=order[repeat][step];uint64_t prep_start=ns(CLOCK_MONOTONIC),expected=kind?7000:9000+repeat;
  if(kind){
   for(size_t i=0;i<n;i++)CHECK(aclrtMemcpyAsync((char*)host+i*piece,piece,(char*)source+i*piece,piece,ACL_MEMCPY_DEVICE_TO_HOST,stream));
   CHECK(aclrtSynchronizeStream(stream));
   if(kind==2)for(size_t off=0;off<bytes;off+=64){volatile uint64_t *word=(volatile uint64_t*)((char*)host+off);uint64_t value=*word;*word=value;}
  }else{
   memset(host,0x5a,bytes);
   for(int j=0;j<8;j++)*(uint64_t*)((char*)host+(size_t)j*(n-1)/7*piece)=expected+(size_t)j*(n-1)/7;
   for(size_t i=0;i<n;i++)CHECK(nop(stream));
   CHECK(aclrtSynchronizeStream(stream));
  }
  for(int j=0;j<8;j++)CHECK(aclrtMemsetAsync((char*)dest+(size_t)j*(n-1)/7*piece,8,0,8,stream));
  CHECK(aclrtSynchronizeStream(stream));uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  for(size_t i=0;i<n;i++)CHECK(aclrtMemcpyAsync((char*)dest+i*piece,piece,(char*)host+i*piece,piece,ACL_MEMCPY_HOST_TO_DEVICE,stream));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC),endcpu=ns(CLOCK_THREAD_CPUTIME_ID);
  for(int j=0;j<8;j++){
   size_t block=(size_t)j*(n-1)/7;uint64_t actual=0;CHECK(aclrtMemcpy(&actual,8,(char*)dest+block*piece,8,ACL_MEMCPY_DEVICE_TO_HOST));
   if(actual!=expected+block){fprintf(stderr,"tag mismatch\n");return 4;}
  }
  printf("{\"repeat\":%d,\"kind\":%d,\"history\":\"%s\",\"descriptors\":%zu,\"bytes\":%zu,\"preparation_ns\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"thread_cpu_ns\":%llu,\"verified_tags\":8}\n",repeat,kind,kind==0?"cpu_write":kind==1?"device_write":"device_write_cpu_touch",n,bytes,(unsigned long long)(start-prep_start),(unsigned long long)start,(unsigned long long)end,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(endcpu-cpu));fflush(stdout);
 }
 aclrtStream fresh=NULL;
 for(int scope=0;scope<4;scope++){
  if(scope==1){CHECK(aclrtCreateStream(&fresh));printf("{\"event\":\"fresh_stream_created\",\"epoch_ns\":%llu}\n",(unsigned long long)ns(CLOCK_REALTIME));fflush(stdout);}
  aclrtStream chosen=(scope==0||scope==2)?stream:fresh;
  for(int j=0;j<8;j++)CHECK(aclrtMemsetAsync((char*)dest+(size_t)j*(n-1)/7*piece,8,0,8,chosen));
  CHECK(aclrtSynchronizeStream(chosen));uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  for(size_t i=0;i<n;i++)CHECK(aclrtMemcpyAsync((char*)dest+i*piece,piece,(char*)host+i*piece,piece,ACL_MEMCPY_HOST_TO_DEVICE,chosen));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(chosen));uint64_t end=ns(CLOCK_MONOTONIC),endcpu=ns(CLOCK_THREAD_CPUTIME_ID);
  for(int j=0;j<8;j++){
   size_t block=(size_t)j*(n-1)/7;uint64_t actual=0;CHECK(aclrtMemcpy(&actual,8,(char*)dest+block*piece,8,ACL_MEMCPY_DEVICE_TO_HOST));
   if(actual!=7000+block){fprintf(stderr,"scope tag mismatch\n");return 5;}
  }
  printf("{\"event\":\"stream_scope\",\"scope\":%d,\"stream_kind\":\"%s\",\"descriptors\":%zu,\"bytes\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"thread_cpu_ns\":%llu,\"verified_tags\":8}\n",scope,(scope==0||scope==2)?"old":"fresh",n,bytes,(unsigned long long)start,(unsigned long long)end,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(endcpu-cpu));fflush(stdout);
 }
 CHECK(aclrtDestroyStream(fresh));
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(source));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());printf("{\"event\":\"completed\",\"cases\":13}\n");fflush(stdout);return 0;
}
