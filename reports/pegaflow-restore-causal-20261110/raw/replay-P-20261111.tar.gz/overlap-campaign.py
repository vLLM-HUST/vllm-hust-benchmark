
import pathlib,json,time,subprocess,sys,traceback,importlib.util
r=pathlib.Path('/root/long-pd-dma-final-20261111')
def write(n,v):(r/n).write_text(json.dumps(v,indent=2))
try:
 deadline=time.monotonic()+4200
 while not (r/'extra-done.json').exists():
  if (r/'extra-failure.json').exists():raise RuntimeError('Prior extra conditions failed')
  if time.monotonic()>deadline:raise TimeoutError('Additional condition wait')
  time.sleep(2)
 spec=importlib.util.spec_from_file_location('extra_campaign',r/'extra-campaign.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 config=json.loads((r/'config.json').read_text());drained=module.reset(config)
 label='random-dma-cap16-4sessions-dinflight1-rps3-s17'
 write('overlap-current.json',dict(epoch=time.time(),label=label,sessions=4,output_cap=16,d_inflight=1,pending_before_reset=drained))
 sampler=(r/'sample-npu-usages.py').read_text().replace('extra-done.json','overlap-done.json').replace('extra-failure.json','overlap-failure.json')
 (r/'sample-npu-usages-overlap.py').write_text(sampler)
 with (r/'resources/P-npu-overlap.log').open('w') as out:
  p=subprocess.Popen([sys.executable,str(r/'sample-npu-usages-overlap.py'),'--role','P','--root',str(r)],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 write('resources/P-npu-overlap-process.json',dict(pid=p.pid,epoch=time.time()))
 subprocess.run([sys.executable,str(r/'run.py'),'--label',label,'--routing','random','--rate','3','--seed','17','--sessions','4','--d-pending-budget-gib','24','--output-cap','16','--d-inflight','1'],check=True,timeout=1800)
 write('overlap-done.json',dict(epoch=time.time(),conditions=1,pending_after=module.drain(config)))
except BaseException as e:
 write('overlap-failure.json',dict(epoch=time.time(),error=repr(e),traceback=traceback.format_exc()));raise
