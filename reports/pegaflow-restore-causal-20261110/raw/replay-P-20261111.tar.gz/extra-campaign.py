"""Repeat the matched workload, then vary output length and session pressure."""

import json
import re
import subprocess
import sys
import time
import traceback
import urllib.request
from pathlib import Path

ROOT = Path("/root/long-pd-dma-final-20261111")


def write(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2))


def drain(config):
    deadline = time.monotonic() + 20
    while True:
        pending = {}
        for instance in config["instances"]:
            host = config["hosts"][instance["role"]]
            with urllib.request.urlopen(
                f"http://{host}:{instance['model_port']}/metrics", timeout=2
            ) as response:
                text = response.read().decode()
            values = [
                float(match[1])
                for line in text.splitlines()
                if (match := re.match(r"vllm:pega_pending_(?:save_requests|prefetches)(?:\{[^}]*\})?\s+(\S+)", line))
            ]
            if not values:
                raise RuntimeError(f"Missing cache drain gauges for {instance['id']}")
            pending[instance["id"]] = sum(values)
        if not any(pending.values()):
            return pending
        if time.monotonic() > deadline:
            raise TimeoutError(f"Cache work did not drain: {pending}")
        time.sleep(1)


def reset(config):
    drained = drain(config)
    for instance in config["instances"]:
        host = config["hosts"][instance["role"]]
        endpoints = [
            f"http://{host}:{instance['model_port']}/reset_prefix_cache",
            f"http://{host}:{instance['http_port']}/cache/memory/cleanup",
        ]
        for endpoint in endpoints:
            with urllib.request.urlopen(
                urllib.request.Request(endpoint, method="POST"), timeout=30
            ) as response:
                if response.status != 200:
                    raise RuntimeError(endpoint)
    return drained


def main():
    config = json.loads((ROOT / "config.json").read_text())
    deadline = time.monotonic() + 1500
    while not (ROOT / "campaign-done.json").exists():
        if (ROOT / "campaign-failure.json").exists():
            raise RuntimeError("Parent campaign failed")
        if time.monotonic() > deadline:
            raise TimeoutError("Parent campaign completion wait")
        time.sleep(2)
    plan = [
        ("random-dma-repeat-4sessions-rps3-s17", 4, 0),
        ("random-dma-cap16-4sessions-rps3-s17", 4, 16),
        ("random-dma-cap16-6sessions-rps3-s17", 6, 16),
    ]
    write("extra-plan.json", dict(epoch=time.time(), conditions=plan, request_timeout_unchanged=True))
    for label, sessions, cap in plan:
        drained = reset(config)
        write("extra-current.json", dict(epoch=time.time(), label=label, sessions=sessions,
              output_cap=cap, cache_pending_before_reset=drained))
        command = [sys.executable, str(ROOT / "run.py"), "--label", label,
                   "--routing", "random", "--rate", "3", "--seed", "17",
                   "--sessions", str(sessions), "--d-pending-budget-gib", "24",
                   "--output-cap", str(cap)]
        subprocess.run(command, check=True, timeout=1800)
    write("extra-done.json", dict(epoch=time.time(), conditions=3, final_cache_pending=drain(config)))


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        write("extra-failure.json", dict(epoch=time.time(), error=repr(error), traceback=traceback.format_exc()))
        raise
