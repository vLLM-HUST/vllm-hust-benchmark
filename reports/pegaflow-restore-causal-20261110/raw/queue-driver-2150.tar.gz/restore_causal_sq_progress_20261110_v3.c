/* Read-only SDK queue observations. Resolve HAL after SDK initialization;
 * do not interpose HAL feature symbols. SQ occupancy is not logical backlog. */
#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <ascend_hal.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
typedef drvError_t(*Query)(uint32_t,struct halSqCqQueryInfo*);
typedef drvError_t(*Details)(uint32_t,struct halResourceIdInputInfo*,struct halResourceDetailInfo*);
typedef aclError(*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static Query query;static Batch batch;static aclError(*synchronize)(aclrtStream);
static int(*resource_latest)(uint64_t[4]);static int resource_fd=-1,fd=-1;
static _Atomic int active,polling;static _Atomic uintptr_t stream_value;
static _Atomic uint32_t device_value,sq_value;static _Atomic uint64_t load_tid,load_start;
static pthread_once_t watcher_once=PTHREAD_ONCE_INIT;
static pthread_mutex_t sample_mutex=PTHREAD_MUTEX_INITIALIZER;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static void emit(const char*line,int n){if(fd>=0&&n>0)write(fd,line,(size_t)n);}
static void sample(int during_copy,const uint64_t *resource){
 if(!query)return;pthread_mutex_lock(&sample_mutex);
 struct halSqCqQueryInfo info={0};info.type=DRV_NORMAL_TYPE;info.sqId=atomic_load(&sq_value);info.tsId=0;
 uint32_t device=atomic_load(&device_value);uint64_t start=ns();
 info.prop=DRV_SQCQ_PROP_SQ_HEAD;int he=query(device,&info);uint32_t head=info.value[0];
 memset(info.value,0,sizeof(info.value));info.prop=DRV_SQCQ_PROP_SQ_TAIL;int te=query(device,&info);uint32_t tail=info.value[0];
 memset(info.value,0,sizeof(info.value));info.prop=DRV_SQCQ_PROP_SQ_HEAD;int re=query(device,&info);uint32_t again=info.value[0];
 uint64_t end=ns();char line[1000];
 int n=snprintf(line,sizeof(line),"{\"event\":\"sq_progress_v3\",\"during_copy\":%d,\"start_ns\":%llu,\"end_ns\":%llu,\"device\":%u,\"sq\":%u,\"head\":%u,\"tail\":%u,\"head_again\":%u,\"errors\":[%d,%d,%d],\"stream\":\"0x%lx\",\"resource_time_ns\":%llu,\"resource_object\":\"0x%llx\",\"resource_tid\":%llu,\"resource_head\":%u,\"resource_tail\":%u,\"resource_cap\":%u,\"oldest_task_id\":%u}\n",during_copy,(unsigned long long)start,(unsigned long long)end,device,info.sqId,head,tail,again,he,te,re,(unsigned long)atomic_load(&stream_value),(unsigned long long)(resource?resource[0]:0),(unsigned long long)(resource?resource[1]:0),(unsigned long long)(resource?resource[2]:0),resource?(unsigned)(resource[3]&65535):0,resource?(unsigned)((resource[3]>>16)&65535):0,resource?(unsigned)((resource[3]>>32)&65535):0,resource?(unsigned)(resource[3]>>48):0);emit(line,n);
 pthread_mutex_unlock(&sample_mutex);
}
static void *watch(void *unused){
 (void)unused;uint64_t end=ns()+900000000000ULL,last=0;
 while(ns()<end){
  if(resource_fd>=0){struct pollfd p={resource_fd,POLLIN,0};poll(&p,1,atomic_load(&active)?20:100);if(p.revents&POLLIN){uint64_t drained;while(read(resource_fd,&drained,sizeof(drained))>0){}}}
  else {struct timespec delay={0,atomic_load(&active)?20000000:100000000};nanosleep(&delay,NULL);}
  if(atomic_load(&active)&&atomic_load(&polling)){
   uint64_t resource[4];int valid=resource_latest&&resource_latest(resource)&&resource[2]==atomic_load(&load_tid)&&resource[0]>=atomic_load(&load_start)&&resource[0]!=last;
   if(valid){last=resource[0];sample(1,resource);}else sample(1,NULL);
  }
 }
 return NULL;
}
static void start_watcher(void){
 int(*getfd)(void)=(int(*)(void))dlsym(RTLD_DEFAULT,"restore_diag_resource_event_fd");
 resource_latest=(int(*)(uint64_t[4]))dlsym(RTLD_DEFAULT,"restore_diag_latest_resource");if(getfd)resource_fd=getfd();
 pthread_t thread;if(pthread_create(&thread,NULL,watch,NULL))_Exit(126);pthread_detach(thread);
}
__attribute__((constructor))static void init(void){
 const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p)fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream){
 if(!batch)batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");if(!batch)_Exit(125);
 int h2d=attr&&indices&&nattr==1&&indices[0]==0&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
 if(h2d){
  if((uintptr_t)stream!=atomic_load(&stream_value)){
   int(*getid)(void*,int32_t*)=(int(*)(void*,int32_t*))dlsym(RTLD_DEFAULT,"rtGetStreamId");
   Details details=(Details)dlsym(RTLD_DEFAULT,"halResourceDetailQuery");query=(Query)dlsym(RTLD_DEFAULT,"halSqCqQuery");
   int32_t id=-1;int result=getid?getid(stream,&id):-1;
   uint32_t device=attr[0].dstLoc.id;struct halResourceIdInputInfo in={0};in.type=DRV_STREAM_ID;in.resourceId=(uint32_t)id;
   struct halResourceDetailInfo out={0};out.type=DRV_RES_QUERY_SQID;int de=(!result&&details)?details(device,&in,&out):-1;
   char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"sq_stream_map_v3\",\"device\":%u,\"stream\":\"%p\",\"runtime_id\":%d,\"getid_error\":%d,\"detail_error\":%d,\"sq\":%u,\"value1\":%u}\n",device,stream,id,result,de,out.value0,out.value1);emit(line,n);
   if(result||de||!query)_Exit(127);
   atomic_store(&device_value,device);atomic_store(&sq_value,out.value0);atomic_store(&stream_value,(uintptr_t)stream);
  }
  if(!atomic_load(&active)){
   int mode=0;const char *path=getenv("NATIVE_COPY_POLICY");if(path){int f=open(path,O_RDONLY);if(f>=0){read(f,&mode,sizeof(mode));close(f);}}
   if(mode<0||mode>1)_Exit(127);atomic_store(&polling,mode);atomic_store(&load_tid,(uint64_t)syscall(SYS_gettid));atomic_store(&load_start,ns());atomic_store(&active,1);pthread_once(&watcher_once,start_watcher);
  }
 }
 aclError result=batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);if(result&&h2d)atomic_store(&active,0);return result;
}
aclError aclrtSynchronizeStream(aclrtStream stream){
 if(!synchronize)synchronize=(aclError(*)(aclrtStream))dlsym(RTLD_NEXT,"aclrtSynchronizeStream");if(!synchronize)_Exit(125);
 aclError result=synchronize(stream);if((uintptr_t)stream==atomic_load(&stream_value)){atomic_store(&active,0);sample(0,NULL);}return result;
}
