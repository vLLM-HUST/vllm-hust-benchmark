/* Causal intervention: bound outstanding H2D descriptors on the original stream.
 * Same sources/destinations, with earlier synchronization at finite boundaries. */
#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
typedef aclError(*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static Batch batch;static aclError(*synchronize)(aclrtStream);static int fd=-1;
static __thread size_t pending=0;static __thread aclrtStream pending_stream;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
__attribute__((constructor))static void init(void){const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p)fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream){
 if(!batch)batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");if(!synchronize)synchronize=(aclError(*)(aclrtStream))dlsym(RTLD_NEXT,"aclrtSynchronizeStream");if(!batch||!synchronize)_Exit(125);
 int h2d=attr&&indices&&nattr==1&&indices[0]==0&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
 int mode=0;const char *path=getenv("NATIVE_COPY_POLICY");if(path){int f=open(path,O_RDONLY);if(f>=0){read(f,&mode,sizeof(mode));close(f);}}
 if(!h2d||!mode)return batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);
 size_t bound=mode==23?512:mode==24?128:mode==25?32:mode==26?1024:0;if(!bound)_Exit(127);
 uint64_t start=ns(),synchronize_ns=0;int result=0;size_t local_failed=0,pieces=0;
 /* Every input batch is <=512; mode26 groups pairs of those batches. */
 if(pending&&pending_stream!=stream)_Exit(127);pending_stream=stream;
 for(size_t offset=0;offset<count;){
  size_t n=count-offset;if(n>bound-pending)n=bound-pending;size_t index=0;
  result=batch(dst+offset,maximum+offset,src+offset,sizes+offset,n,attr,&index,1,&local_failed,stream);pieces++;
  if(result){if(failed)*failed=offset+local_failed;break;}offset+=n;pending+=n;
  if(pending==bound){uint64_t a=ns();result=synchronize(stream);synchronize_ns+=ns()-a;pending=0;if(result)break;}
 }
 if(fd>=0){char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"bounded_copy\",\"mode\":%d,\"bound\":%zu,\"copies\":%zu,\"pieces\":%zu,\"pending\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"sync_ns\":%llu,\"error\":%d,\"tid\":%ld}\n",mode,bound,count,pieces,pending,(unsigned long long)start,(unsigned long long)ns(),(unsigned long long)synchronize_ns,result,syscall(SYS_gettid));write(fd,line,(size_t)n);}
 return result;
}
aclError aclrtSynchronizeStream(aclrtStream stream){
 if(!synchronize)synchronize=(aclError(*)(aclrtStream))dlsym(RTLD_NEXT,"aclrtSynchronizeStream");if(!synchronize)_Exit(125);
 aclError result=synchronize(stream);if(stream==pending_stream&&!result)pending=0;return result;
}
