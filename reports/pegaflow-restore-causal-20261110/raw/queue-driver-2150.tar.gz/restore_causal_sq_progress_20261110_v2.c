#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <ascend_hal.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef drvError_t(*Query)(uint32_t,struct halSqCqQueryInfo*);
typedef drvError_t(*Allocate)(uint32_t,struct halSqCqInputInfo*,struct halSqCqOutputInfo*);
typedef aclError(*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
struct Queue{uint32_t device,ts,sq,cq;drvSqCqType_t type;};
static struct Queue queues[64];static _Atomic size_t queue_count;
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
static Query query_real;static Batch batch;static aclError(*sync_real)(aclrtStream);
static _Atomic int active;static _Atomic int polling;static _Atomic uintptr_t active_stream;
static pthread_once_t watcher_once=PTHREAD_ONCE_INIT;static int fd=-1;
static uint64_t stamp(clockid_t k){struct timespec t;clock_gettime(k,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static void emit(const char *line,int n){if(fd>=0&&n>0)write(fd,line,(size_t)n);}
static void remember(uint32_t device,drvSqCqType_t type,uint32_t ts,uint32_t sq,uint32_t cq){
 if(type!=DRV_NORMAL_TYPE||sq==UINT32_MAX)return;
 size_t count=atomic_load_explicit(&queue_count,memory_order_acquire);
 for(size_t i=0;i<count;i++)if(queues[i].device==device&&queues[i].ts==ts&&queues[i].sq==sq)return;
 pthread_mutex_lock(&mutex);count=atomic_load(&queue_count);
 for(size_t i=0;i<count;i++)if(queues[i].device==device&&queues[i].ts==ts&&queues[i].sq==sq){pthread_mutex_unlock(&mutex);return;}
 if(count<64){queues[count]=(struct Queue){device,ts,sq,cq,type};atomic_store_explicit(&queue_count,count+1,memory_order_release);}
 pthread_mutex_unlock(&mutex);
}
drvError_t halSqCqQuery(uint32_t device,struct halSqCqQueryInfo *info){
 if(!query_real)query_real=(Query)dlsym(RTLD_NEXT,"halSqCqQuery");if(!query_real)_Exit(125);
 drvError_t result=query_real(device,info);if(!result)remember(device,info->type,info->tsId,info->sqId,info->cqId);return result;
}
drvError_t halSqCqAllocate(uint32_t device,struct halSqCqInputInfo *in,struct halSqCqOutputInfo *out){
 Allocate fn=(Allocate)dlsym(RTLD_NEXT,"halSqCqAllocate");if(!fn)_Exit(125);
 drvError_t result=fn(device,in,out);
 if(!result){remember(device,in->type,in->tsId,out->sqId,out->cqId);char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"sq_allocate\",\"device\":%u,\"ts\":%u,\"sq\":%u,\"cq\":%u,\"type\":%d,\"depth_requested\":%u,\"info\":[%u,%u,%u,%u,%u]}\n",device,in->tsId,out->sqId,out->cqId,in->type,in->sqeDepth,in->info[0],in->info[1],in->info[2],in->info[3],in->info[4]);emit(line,n);}
 return result;
}
static void sample_all(int during_copy){
 if(!query_real)return;size_t count=atomic_load_explicit(&queue_count,memory_order_acquire);
 for(size_t i=0;i<count;i++){
  struct Queue q=queues[i];struct halSqCqQueryInfo info={0};info.type=q.type;info.tsId=q.ts;info.sqId=q.sq;info.cqId=q.cq;
  uint64_t epoch=stamp(CLOCK_REALTIME),start=stamp(CLOCK_MONOTONIC);
  info.prop=DRV_SQCQ_PROP_SQ_HEAD;int head_error=query_real(q.device,&info);uint32_t head=info.value[0];
  memset(info.value,0,sizeof(info.value));info.prop=DRV_SQCQ_PROP_SQ_TAIL;int tail_error=query_real(q.device,&info);uint32_t tail=info.value[0];
  memset(info.value,0,sizeof(info.value));info.prop=DRV_SQCQ_PROP_SQ_HEAD;int repeat_error=query_real(q.device,&info);uint32_t again=info.value[0];
  uint64_t stop=stamp(CLOCK_MONOTONIC);char line[640];int n=snprintf(line,sizeof(line),"{\"event\":\"sq_progress\",\"during_copy\":%d,\"epoch_ns\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"device\":%u,\"ts\":%u,\"sq\":%u,\"head\":%u,\"tail\":%u,\"head_again\":%u,\"errors\":[%d,%d,%d],\"stream\":\"0x%lx\"}\n",during_copy,(unsigned long long)epoch,(unsigned long long)start,(unsigned long long)stop,q.device,q.ts,q.sq,head,tail,again,head_error,tail_error,repeat_error,(unsigned long)atomic_load(&active_stream));emit(line,n);
 }
}
static void *watch(void *unused){
 (void)unused;uint64_t end=stamp(CLOCK_MONOTONIC)+900000000000ULL;
 while(stamp(CLOCK_MONOTONIC)<end){
  if(atomic_load(&active)&&atomic_load(&polling))sample_all(1);
  struct timespec delay={0,atomic_load(&active)?20000000:100000000};nanosleep(&delay,NULL);
 }
 return NULL;
}
static void start_watcher(void){pthread_t t;if(pthread_create(&t,NULL,watch,NULL))_Exit(126);pthread_detach(t);}
__attribute__((constructor)) static void init(void){
 batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");sync_real=(aclError(*)(aclrtStream))dlsym(RTLD_NEXT,"aclrtSynchronizeStream");
 const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p)fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);if(!batch||!sync_real)_Exit(125);
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
 aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream){
 int h2d=attr&&indices&&nattr==1&&indices[0]==0&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
 if(h2d){
  int mode=0;const char *path=getenv("NATIVE_COPY_POLICY");if(path){int f=open(path,O_RDONLY);if(f>=0){read(f,&mode,sizeof(mode));close(f);}}if(mode<0||mode>1)_Exit(127);atomic_store(&polling,mode);
  if((uintptr_t)stream!=atomic_load(&active_stream)){
   typedef int(*GetId)(void*,int32_t*);GetId fn=(GetId)dlsym(RTLD_DEFAULT,"rtGetStreamId");int32_t id=-1;int result=fn?fn(stream,&id):-1;
   char line[256];int n=snprintf(line,sizeof(line),"{\"event\":\"sq_stream_map\",\"stream\":\"%p\",\"runtime_id\":%d,\"result\":%d}\n",stream,id,result);emit(line,n);
  }
  atomic_store(&active_stream,(uintptr_t)stream);atomic_store(&active,1);pthread_once(&watcher_once,start_watcher);}
 aclError result=batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);if(result)atomic_store(&active,0);return result;
}
aclError aclrtSynchronizeStream(aclrtStream stream){aclError result=sync_real(stream);if((uintptr_t)stream==atomic_load(&active_stream)){atomic_store(&active,0);sample_all(0);}return result;}
