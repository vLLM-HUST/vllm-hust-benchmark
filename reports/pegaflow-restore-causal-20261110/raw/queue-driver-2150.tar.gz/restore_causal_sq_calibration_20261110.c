/* Calibrate SQ head/tail against a finite, known in-order DMA backlog. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t k){struct timespec t;clock_gettime(k,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char **argv){
 alarm(45);int device=argc>1?atoi(argv[1]):1;const size_t piece=262144,n=512,bytes=piece*n;
 void *host=NULL,*bulk=NULL,*dest=NULL,*readback=malloc(bytes);aclrtStream stream=NULL;
 if(!readback)return 2;CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtMallocHost(&host,bytes));
 memset(host,0x5a,bytes);for(size_t i=0;i<n;i++)*(uint64_t*)((char*)host+i*piece)=i+17;
 CHECK(aclrtMalloc(&bulk,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 void *sources[512],*targets[512];size_t maximum[512],sizes[512];
 for(size_t i=0;i<n;i++){sources[i]=(char*)host+i*piece;targets[i]=(char*)dest+i*piece;maximum[i]=sizes[i]=piece;}
 uint64_t epoch=ns(CLOCK_REALTIME),start=ns(CLOCK_MONOTONIC);
 for(int i=0;i<256;i++)CHECK(aclrtMemcpyAsync(bulk,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream));
 uint64_t bulk_submitted=ns(CLOCK_MONOTONIC);aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;size_t index=0,failed=0;
 CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,n,&attr,&index,1,&failed,stream));uint64_t submitted=ns(CLOCK_MONOTONIC);
 CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC);
 CHECK(aclrtMemcpy(readback,bytes,dest,bytes,ACL_MEMCPY_DEVICE_TO_HOST));
 for(size_t i=0;i<n;i++)if(*(uint64_t*)((char*)readback+i*piece)!=i+17)return 3;
 printf("{\"epoch_ns\":%llu,\"bulk_tasks\":256,\"small_tasks\":512,\"bulk_bytes\":%zu,\"small_bytes\":%zu,\"bulk_submit_ns\":%llu,\"small_submit_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"verified_tags\":512}\n",(unsigned long long)epoch,256*bytes,bytes,(unsigned long long)(bulk_submitted-start),(unsigned long long)(submitted-bulk_submitted),(unsigned long long)(end-submitted),(unsigned long long)(end-start));fflush(stdout);
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(bulk));CHECK(aclrtFree(dest));CHECK(aclrtFreeHost(host));CHECK(aclrtResetDevice(device));CHECK(aclFinalize());free(readback);return 0;
}
