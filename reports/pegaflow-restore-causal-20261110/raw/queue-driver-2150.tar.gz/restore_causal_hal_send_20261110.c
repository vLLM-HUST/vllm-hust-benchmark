/* Transparent timing of the driver's existing SQ submission entry points. */
#define _GNU_SOURCE
#include <ascend_hal.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
static int fd=-1;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static void emit(const char *kind,uint64_t a,uint64_t b,uint32_t device,uint32_t sq,uint32_t count,uint32_t position,int error){
 if(fd<0)return;char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"hal_send\",\"kind\":\"%s\",\"start_ns\":%llu,\"end_ns\":%llu,\"device\":%u,\"sq\":%u,\"count\":%u,\"position\":%u,\"error\":%d,\"tid\":%ld}\n",kind,(unsigned long long)a,(unsigned long long)b,device,sq,count,position,error,syscall(SYS_gettid));write(fd,line,(size_t)n);
}
__attribute__((constructor))static void init(void){const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p)fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);}
drvError_t halSqTaskSend(uint32_t device,struct halTaskSendInfo *info){
 typedef drvError_t(*Fn)(uint32_t,struct halTaskSendInfo*);static Fn fn;
 if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"halSqTaskSend");if(!fn)_Exit(125);
 uint64_t a=ns();drvError_t e=fn(device,info);uint64_t b=ns();emit("task",a,b,device,info->sqId,info->sqe_num,info->pos,e);return e;
}
drvError_t halSqMemGet(uint32_t device,struct halSqMemGetInput *in,struct halSqMemGetOutput *out){
 typedef drvError_t(*Fn)(uint32_t,struct halSqMemGetInput*,struct halSqMemGetOutput*);static Fn fn;
 if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"halSqMemGet");if(!fn)_Exit(125);
 uint64_t a=ns();drvError_t e=fn(device,in,out);uint64_t b=ns();emit("mem",a,b,device,in->sqId,out->cmdCount,out->pos,e);return e;
}
drvError_t halSqMsgSend(uint32_t device,struct halSqMsgInfo *info){
 typedef drvError_t(*Fn)(uint32_t,struct halSqMsgInfo*);static Fn fn;
 if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"halSqMsgSend");if(!fn)_Exit(125);
 uint64_t a=ns();drvError_t e=fn(device,info);uint64_t b=ns();emit("msg",a,b,device,info->sqId,info->cmdCount,0,e);return e;
}
