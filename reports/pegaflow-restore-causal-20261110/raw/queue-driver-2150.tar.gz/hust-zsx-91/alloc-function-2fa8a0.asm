
/usr/local/Ascend/cann-9.1.0/lib64/libruntime_v100.so:     file format elf64-littleaarch64


Disassembly of section .text:

00000000002fa8a0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6068>:
  2fa8a0:	aa0003fa 	mov	x26, x0
  2fa8a4:	f942dac0 	ldr	x0, [x22, #1456]
  2fa8a8:	a90453f3 	stp	x19, x20, [sp, #64]
  2fa8ac:	2a0203f4 	mov	w20, w2
  2fa8b0:	f90037a1 	str	x1, [x29, #104]
  2fa8b4:	12003c61 	and	w1, w3, #0xffff
  2fa8b8:	f90037f8 	str	x24, [sp, #104]
  2fa8bc:	91018358 	add	x24, x26, #0x60
  2fa8c0:	f90047fc 	str	x28, [sp, #136]
  2fa8c4:	2a0403fc 	mov	w28, w4
  2fa8c8:	b90067a1 	str	w1, [x29, #100]
  2fa8cc:	b40013e0 	cbz	x0, 2fab48 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6310>
  2fa8d0:	aa1803e0 	mov	x0, x24
  2fa8d4:	97f51d0f 	bl	41d10 <pthread_mutex_lock@plt>
  2fa8d8:	35001ea0 	cbnz	w0, 2facac <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6474>
  2fa8dc:	79402740 	ldrh	w0, [x26, #18]
  2fa8e0:	79402b41 	ldrh	w1, [x26, #20]
  2fa8e4:	11000403 	add	w3, w0, #0x1
  2fa8e8:	79402353 	ldrh	w19, [x26, #16]
  2fa8ec:	2a0003fb 	mov	w27, w0
  2fa8f0:	1ac10862 	udiv	w2, w3, w1
  2fa8f4:	1b018c42 	msub	w2, w2, w1, w3
  2fa8f8:	6b02027f 	cmp	w19, w2
  2fa8fc:	54001020 	b.eq	2fab00 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62c8>  // b.none
  2fa900:	6b13029f 	cmp	w20, w19
  2fa904:	1a9f37e3 	cset	w3, cs	// cs = hs, nlast
  2fa908:	6b00029f 	cmp	w20, w0
  2fa90c:	1a9f27e4 	cset	w4, cc	// cc = lo, ul, last
  2fa910:	6b00027f 	cmp	w19, w0
  2fa914:	1a9f27e2 	cset	w2, cc	// cc = lo, ul, last
  2fa918:	0a020062 	and	w2, w3, w2
  2fa91c:	6a02009f 	tst	w4, w2
  2fa920:	54000d81 	b.ne	2faad0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6298>  // b.any
  2fa924:	6b00027f 	cmp	w19, w0
  2fa928:	54000d08 	b.hi	2faac8 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6290>  // b.pmore
  2fa92c:	11000695 	add	w21, w20, #0x1
  2fa930:	6b00029f 	cmp	w20, w0
  2fa934:	54000640 	b.eq	2fa9fc <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x61c4>  // b.none
  2fa938:	1ac10aa0 	udiv	w0, w21, w1
  2fa93c:	1b01d401 	msub	w1, w0, w1, w21
  2fa940:	6b13003f 	cmp	w1, w19
  2fa944:	54001260 	b.eq	2fab90 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6358>  // b.none
  2fa948:	f9001bb7 	str	x23, [x29, #48]
  2fa94c:	b0001597 	adrp	x23, 5ab000 <_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE@@Base+0x5ee8>
  2fa950:	911842f7 	add	x23, x23, #0x610
  2fa954:	f90023b9 	str	x25, [x29, #64]
  2fa958:	910182f7 	add	x23, x23, #0x60
  2fa95c:	f00012f9 	adrp	x25, 559000 <_fini@@Base+0x53cbc>
  2fa960:	910f4339 	add	x25, x25, #0x3d0
  2fa964:	14000008 	b	2fa984 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x614c>
  2fa968:	6b1b029f 	cmp	w20, w27
  2fa96c:	54000440 	b.eq	2fa9f4 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x61bc>  // b.none
  2fa970:	79402b41 	ldrh	w1, [x26, #20]
  2fa974:	1ac10aa0 	udiv	w0, w21, w1
  2fa978:	1b01d400 	msub	w0, w0, w1, w21
  2fa97c:	6b13001f 	cmp	w0, w19
  2fa980:	54001040 	b.eq	2fab88 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6350>  // b.none
  2fa984:	f9400745 	ldr	x5, [x26, #8]
  2fa988:	52803702 	mov	w2, #0x1b8                 	// #440
  2fa98c:	12800004 	mov	w4, #0xffffffff            	// #-1
  2fa990:	11000763 	add	w3, w27, #0x1
  2fa994:	52800001 	mov	w1, #0x0                   	// #0
  2fa998:	528000e0 	mov	w0, #0x7                   	// #7
  2fa99c:	9ba21767 	umaddl	x7, w27, w2, x5
  2fa9a0:	394138e2 	ldrb	w2, [x7, #78]
  2fa9a4:	790090e4 	strh	w4, [x7, #72]
  2fa9a8:	32196042 	orr	w2, w2, #0xffffff80
  2fa9ac:	390138e2 	strb	w2, [x7, #78]
  2fa9b0:	79402b47 	ldrh	w7, [x26, #20]
  2fa9b4:	1ac70862 	udiv	w2, w3, w7
  2fa9b8:	1b078c5b 	msub	w27, w2, w7, w3
  2fa9bc:	97f520e5 	bl	42d50 <CheckLogLevel@plt>
  2fa9c0:	7100041f 	cmp	w0, #0x1
  2fa9c4:	54fffd21 	b.ne	2fa968 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6130>  // b.any
  2fa9c8:	79402746 	ldrh	w6, [x26, #18]
  2fa9cc:	d00012e1 	adrp	x1, 558000 <_fini@@Base+0x52cbc>
  2fa9d0:	2a1403e5 	mov	w5, w20
  2fa9d4:	aa1903e4 	mov	x4, x25
  2fa9d8:	aa1703e3 	mov	x3, x23
  2fa9dc:	52803022 	mov	w2, #0x181                 	// #385
  2fa9e0:	9132e021 	add	x1, x1, #0xcb8
  2fa9e4:	52800000 	mov	w0, #0x0                   	// #0
  2fa9e8:	97f51e4e 	bl	42320 <_ZN3cce7runtime9RecordLogEiPKciS2_S2_z@plt>
  2fa9ec:	6b1b029f 	cmp	w20, w27
  2fa9f0:	54fffc01 	b.ne	2fa970 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6138>  // b.any
  2fa9f4:	f9401bb7 	ldr	x23, [x29, #48]
  2fa9f8:	f94023b9 	ldr	x25, [x29, #64]
  2fa9fc:	f9400740 	ldr	x0, [x26, #8]
  2faa00:	52803713 	mov	w19, #0x1b8                 	// #440
  2faa04:	d2803603 	mov	x3, #0x1b0                 	// #432
  2faa08:	52800002 	mov	w2, #0x0                   	// #0
  2faa0c:	aa0303e1 	mov	x1, x3
  2faa10:	9bb30293 	umaddl	x19, w20, w19, x0
  2faa14:	aa1303e0 	mov	x0, x19
  2faa18:	97f51c5a 	bl	41b80 <memset_s@plt>
  2faa1c:	f94037a1 	ldr	x1, [x29, #104]
  2faa20:	aa1303e0 	mov	x0, x19
  2faa24:	b900127c 	str	w28, [x19, #16]
  2faa28:	94000920 	bl	2fcea8 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x8670>
  2faa2c:	7940cba0 	ldrh	w0, [x29, #100]
