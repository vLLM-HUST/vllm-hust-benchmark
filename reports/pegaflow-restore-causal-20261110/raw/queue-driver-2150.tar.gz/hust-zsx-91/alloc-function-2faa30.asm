
/usr/local/Ascend/cann-9.1.0/lib64/libruntime_v100.so:     file format elf64-littleaarch64


Disassembly of section .text:

00000000002faa30 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x61f8>:
  2faa30:	52800001 	mov	w1, #0x0                   	// #0
  2faa34:	79009260 	strh	w0, [x19, #72]
  2faa38:	aa1303e0 	mov	x0, x19
  2faa3c:	940008d9 	bl	2fcda0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x8568>
  2faa40:	d5033bbf 	dmb	ish
  2faa44:	79402b41 	ldrh	w1, [x26, #20]
  2faa48:	1ac10aa0 	udiv	w0, w21, w1
  2faa4c:	1b01d415 	msub	w21, w0, w1, w21
  2faa50:	79002755 	strh	w21, [x26, #18]
  2faa54:	d5033bbf 	dmb	ish
  2faa58:	f942dad6 	ldr	x22, [x22, #1456]
  2faa5c:	b4000076 	cbz	x22, 2faa68 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6230>
  2faa60:	aa1803e0 	mov	x0, x24
  2faa64:	97f51de7 	bl	42200 <pthread_mutex_unlock@plt>
  2faa68:	52800001 	mov	w1, #0x0                   	// #0
  2faa6c:	528000e0 	mov	w0, #0x7                   	// #7
  2faa70:	97f520b8 	bl	42d50 <CheckLogLevel@plt>
  2faa74:	7100041f 	cmp	w0, #0x1
  2faa78:	54000561 	b.ne	2fab24 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62ec>  // b.any
  2faa7c:	29431746 	ldp	w6, w5, [x26, #24]
  2faa80:	b0001583 	adrp	x3, 5ab000 <_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE@@Base+0x5ee8>
  2faa84:	79402b42 	ldrh	w2, [x26, #20]
  2faa88:	91184063 	add	x3, x3, #0x610
  2faa8c:	79402741 	ldrh	w1, [x26, #18]
  2faa90:	f00012e4 	adrp	x4, 559000 <_fini@@Base+0x53cbc>
  2faa94:	79402340 	ldrh	w0, [x26, #16]
  2faa98:	2a1403e7 	mov	w7, w20
  2faa9c:	b90003e0 	str	w0, [sp]
  2faaa0:	91106084 	add	x4, x4, #0x418
  2faaa4:	b9000be1 	str	w1, [sp, #8]
  2faaa8:	91018063 	add	x3, x3, #0x60
  2faaac:	b90013e2 	str	w2, [sp, #16]
  2faab0:	d00012e1 	adrp	x1, 558000 <_fini@@Base+0x52cbc>
  2faab4:	52803222 	mov	w2, #0x191                 	// #401
  2faab8:	9132e021 	add	x1, x1, #0xcb8
  2faabc:	52800000 	mov	w0, #0x0                   	// #0
  2faac0:	97f51e18 	bl	42320 <_ZN3cce7runtime9RecordLogEiPKciS2_S2_z@plt>
  2faac4:	14000018 	b	2fab24 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62ec>
  2faac8:	2a040063 	orr	w3, w3, w4
  2faacc:	34fff303 	cbz	w3, 2fa92c <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x60f4>
  2faad0:	52800041 	mov	w1, #0x2                   	// #2
  2faad4:	528000e0 	mov	w0, #0x7                   	// #7
  2faad8:	97f5209e 	bl	42d50 <CheckLogLevel@plt>
  2faadc:	7100041f 	cmp	w0, #0x1
  2faae0:	54000880 	b.eq	2fabf0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x63b8>  // b.none
  2faae4:	f942dad6 	ldr	x22, [x22, #1456]
  2faae8:	b40001d6 	cbz	x22, 2fab20 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62e8>
  2faaec:	aa1803e0 	mov	x0, x24
  2faaf0:	d2800013 	mov	x19, #0x0                   	// #0
  2faaf4:	97f51dc3 	bl	42200 <pthread_mutex_unlock@plt>
  2faaf8:	1400000b 	b	2fab24 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62ec>
  2faafc:	d503201f 	nop
  2fab00:	aa1803e0 	mov	x0, x24
  2fab04:	97f51dbf 	bl	42200 <pthread_mutex_unlock@plt>
  2fab08:	52800001 	mov	w1, #0x0                   	// #0
  2fab0c:	528000e0 	mov	w0, #0x7                   	// #7
  2fab10:	2a1303f5 	mov	w21, w19
  2fab14:	97f5208f 	bl	42d50 <CheckLogLevel@plt>
  2fab18:	7100041f 	cmp	w0, #0x1
  2fab1c:	54000aa0 	b.eq	2fac70 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6438>  // b.none
  2fab20:	d2800013 	mov	x19, #0x0                   	// #0
  2fab24:	aa1303e0 	mov	x0, x19
  2fab28:	f94037f8 	ldr	x24, [sp, #104]
  2fab2c:	a94453f3 	ldp	x19, x20, [sp, #64]
  2fab30:	a9455bf5 	ldp	x21, x22, [sp, #80]
  2fab34:	a947effa 	ldp	x26, x27, [sp, #120]
  2fab38:	a9437bfd 	ldp	x29, x30, [sp, #48]
  2fab3c:	f94047fc 	ldr	x28, [sp, #136]
  2fab40:	910283ff 	add	sp, sp, #0xa0
  2fab44:	d65f03c0 	ret
  2fab48:	79402740 	ldrh	w0, [x26, #18]
  2fab4c:	79402b41 	ldrh	w1, [x26, #20]
  2fab50:	11000406 	add	w6, w0, #0x1
  2fab54:	79402353 	ldrh	w19, [x26, #16]
  2fab58:	2a0003fb 	mov	w27, w0
  2fab5c:	1ac108d5 	udiv	w21, w6, w1
  2fab60:	1b019ab5 	msub	w21, w21, w1, w6
  2fab64:	6b15027f 	cmp	w19, w21
  2fab68:	54ffecc1 	b.ne	2fa900 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x60c8>  // b.any
  2fab6c:	52800001 	mov	w1, #0x0                   	// #0
  2fab70:	528000e0 	mov	w0, #0x7                   	// #7
  2fab74:	97f52077 	bl	42d50 <CheckLogLevel@plt>
  2fab78:	7100041f 	cmp	w0, #0x1
  2fab7c:	54fffd21 	b.ne	2fab20 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62e8>  // b.any
  2fab80:	1400003c 	b	2fac70 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6438>
  2fab84:	d503201f 	nop
  2fab88:	f9401bb7 	ldr	x23, [x29, #48]
  2fab8c:	f94023b9 	ldr	x25, [x29, #64]
  2fab90:	f942dad6 	ldr	x22, [x22, #1456]
  2fab94:	b4000076 	cbz	x22, 2faba0 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x6368>
  2fab98:	aa1803e0 	mov	x0, x24
  2fab9c:	97f51d99 	bl	42200 <pthread_mutex_unlock@plt>
  2faba0:	52800001 	mov	w1, #0x0                   	// #0
  2faba4:	528000e0 	mov	w0, #0x7                   	// #7
  2faba8:	97f5206a 	bl	42d50 <CheckLogLevel@plt>
  2fabac:	7100041f 	cmp	w0, #0x1
  2fabb0:	54fffb81 	b.ne	2fab20 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62e8>  // b.any
  2fabb4:	b0001583 	adrp	x3, 5ab000 <_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE@@Base+0x5ee8>
  2fabb8:	91184063 	add	x3, x3, #0x610
  2fabbc:	2a1303e6 	mov	w6, w19
  2fabc0:	f00012e4 	adrp	x4, 559000 <_fini@@Base+0x53cbc>
  2fabc4:	d00012e1 	adrp	x1, 558000 <_fini@@Base+0x52cbc>
  2fabc8:	2a1b03e7 	mov	w7, w27
  2fabcc:	2a1403e5 	mov	w5, w20
  2fabd0:	910e6084 	add	x4, x4, #0x398
  2fabd4:	91018063 	add	x3, x3, #0x60
  2fabd8:	52802f02 	mov	w2, #0x178                 	// #376
  2fabdc:	9132e021 	add	x1, x1, #0xcb8
  2fabe0:	52800000 	mov	w0, #0x0                   	// #0
  2fabe4:	d2800013 	mov	x19, #0x0                   	// #0
  2fabe8:	97f51dce 	bl	42320 <_ZN3cce7runtime9RecordLogEiPKciS2_S2_z@plt>
  2fabec:	17ffffce 	b	2fab24 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62ec>
  2fabf0:	d00012e0 	adrp	x0, 558000 <_fini@@Base+0x52cbc>
  2fabf4:	d00012f5 	adrp	x21, 558000 <_fini@@Base+0x52cbc>
  2fabf8:	9132e800 	add	x0, x0, #0xcba
  2fabfc:	9132e2b5 	add	x21, x21, #0xcb8
  2fac00:	14000005 	b	2fac14 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x63dc>
  2fac04:	d503201f 	nop
  2fac08:	7100bc3f 	cmp	w1, #0x2f
  2fac0c:	9a8012b5 	csel	x21, x21, x0, ne	// ne = any
  2fac10:	91000400 	add	x0, x0, #0x1
  2fac14:	385ff001 	ldurb	w1, [x0, #-1]
  2fac18:	35ffff81 	cbnz	w1, 2fac08 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x63d0>
  2fac1c:	97f51f15 	bl	42870 <mmGetTid@plt>
  2fac20:	2a0003e5 	mov	w5, w0
  2fac24:	29431f41 	ldp	w1, w7, [x26, #24]
  2fac28:	b0001586 	adrp	x6, 5ab000 <_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE@@Base+0x5ee8>
  2fac2c:	79402743 	ldrh	w3, [x26, #18]
  2fac30:	911840c6 	add	x6, x6, #0x610
  2fac34:	79402342 	ldrh	w2, [x26, #16]
  2fac38:	910180c6 	add	x6, x6, #0x60
  2fac3c:	b90003e1 	str	w1, [sp]
  2fac40:	52802dc4 	mov	w4, #0x16e                 	// #366
  2fac44:	b9001be2 	str	w2, [sp, #24]
  2fac48:	528000e0 	mov	w0, #0x7                   	// #7
  2fac4c:	b90023e3 	str	w3, [sp, #32]
  2fac50:	f00012e2 	adrp	x2, 559000 <_fini@@Base+0x53cbc>
  2fac54:	b9000bf4 	str	w20, [sp, #8]
  2fac58:	aa1503e3 	mov	x3, x21
  2fac5c:	b90013f3 	str	w19, [sp, #16]
  2fac60:	910c6042 	add	x2, x2, #0x318
  2fac64:	52800041 	mov	w1, #0x2                   	// #2
  2fac68:	97f52356 	bl	439c0 <DlogRecord@plt>
  2fac6c:	17ffff9e 	b	2faae4 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62ac>
  2fac70:	79402747 	ldrh	w7, [x26, #18]
  2fac74:	b0001583 	adrp	x3, 5ab000 <_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE@@Base+0x5ee8>
  2fac78:	91184063 	add	x3, x3, #0x610
  2fac7c:	f00012e4 	adrp	x4, 559000 <_fini@@Base+0x53cbc>
  2fac80:	d00012e1 	adrp	x1, 558000 <_fini@@Base+0x52cbc>
  2fac84:	2a1503e6 	mov	w6, w21
  2fac88:	2a1403e5 	mov	w5, w20
  2fac8c:	910b6084 	add	x4, x4, #0x2d8
  2fac90:	91018063 	add	x3, x3, #0x60
  2fac94:	52802cc2 	mov	w2, #0x166                 	// #358
  2fac98:	9132e021 	add	x1, x1, #0xcb8
  2fac9c:	52800000 	mov	w0, #0x0                   	// #0
  2faca0:	d2800013 	mov	x19, #0x0                   	// #0
  2faca4:	97f51d9f 	bl	42320 <_ZN3cce7runtime9RecordLogEiPKciS2_S2_z@plt>
  2faca8:	17ffff9f 	b	2fab24 <_ZNSt6vectorItSaItEE17_M_realloc_insertIJtEEEvN9__gnu_cxx17__normal_iteratorIPtS1_EEDpOT_@@Base+0x62ec>
  2facac:	f9001bb7 	str	x23, [x29, #48]
  2facb0:	f90023b9 	str	x25, [x29, #64]
  2facb4:	97f51dcf 	bl	423f0 <_ZSt20__throw_system_errori@plt>
  2facb8:	d102c3ff 	sub	sp, sp, #0xb0
  2facbc:	a9027bfd 	stp	x29, x30, [sp, #32]
  2facc0:	910083fd 	add	x29, sp, #0x20
  2facc4:	a90353f3 	stp	x19, x20, [sp, #48]
