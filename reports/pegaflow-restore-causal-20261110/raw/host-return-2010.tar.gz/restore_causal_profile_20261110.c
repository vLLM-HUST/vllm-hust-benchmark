#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <acl/acl_prof.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static Batch batch;
static aclError (*synchronize)(aclrtStream);
static aclprofConfig *config;
static int attempted,started,completed;
static __thread int pending;
__attribute__((constructor)) static void init(void) {
 batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");
 synchronize=(aclError(*)(aclrtStream))dlsym(RTLD_NEXT,"aclrtSynchronizeStream");
 if(!batch||!synchronize)_Exit(125);
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
 aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream) {
 int h2d=attr&&indices&&nattr==1&&indices[0]==0&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
 if(h2d&&!attempted) {
  attempted=1;const char *path=getenv("RESTORE_CAUSAL_PROFILE_DIR");
  if(path) {
   int initial=aclprofInit(path,strlen(path));uint32_t device=(uint32_t)attr[0].dstLoc.id;
   config=initial==0?aclprofCreateConfig(&device,1,ACL_AICORE_NONE,NULL,ACL_PROF_TASK_TIME|ACL_PROF_RUNTIME_API|ACL_PROF_ACL_API):NULL;
   int result=config?aclprofStart(config):-1;started=result==0;
   fprintf(stderr,"{\"event\":\"diagnostic_profiler_start\",\"init\":%d,\"start\":%d,\"device\":%u}\n",initial,result,device);fflush(stderr);
  }
 }
 if(h2d)pending=1;
 return batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);
}
aclError aclrtSynchronizeStream(aclrtStream stream) {
 aclError result=synchronize(stream);
 if(pending&&started) {
  pending=0;completed++;const char *n=getenv("RESTORE_CAUSAL_PROFILE_SYNCS");
  int limit=n?atoi(n):9;
  if(completed>=limit) {
   int stop=aclprofStop(config),destroy=aclprofDestroyConfig(config),final=aclprofFinalize();started=0;config=NULL;
   fprintf(stderr,"{\"event\":\"diagnostic_profiler_stop\",\"restores\":%d,\"stop\":%d,\"destroy\":%d,\"finalize\":%d}\n",completed,stop,destroy,final);fflush(stderr);
  }
 }
 return result;
}
