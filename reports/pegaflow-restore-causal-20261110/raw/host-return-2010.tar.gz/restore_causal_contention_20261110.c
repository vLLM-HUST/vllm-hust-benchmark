#define _GNU_SOURCE
#include <pthread.h>
#include <semaphore.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/resource.h>
#include <errno.h>

static sem_t left,right;
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_rwlock_t rwlock=PTHREAD_RWLOCK_INITIALIZER;
static pthread_barrier_t barrier;
static volatile uint64_t counter;
struct Worker { int index,cpu,kind,n; uint64_t cpu_ns,wall_ns,user_us,system_us,checksum;long voluntary,involuntary; };
static uint64_t stamp(clockid_t c) {struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static uint64_t us(struct timeval t) {return (uint64_t)t.tv_sec*1000000ULL+t.tv_usec;}
static void wait_sem(sem_t *s) {while(sem_wait(s))if(errno!=EINTR)exit(2);}
static void *worker(void *raw) {
    struct Worker *w=raw;cpu_set_t mask;CPU_ZERO(&mask);CPU_SET(w->cpu,&mask);
    int e=pthread_setaffinity_np(pthread_self(),sizeof(mask),&mask);if(e){fprintf(stderr,"affinity=%d\n",e);exit(3);}
    pthread_barrier_wait(&barrier);
    struct rusage before,after;getrusage(RUSAGE_THREAD,&before);
    uint64_t cpu=stamp(CLOCK_THREAD_CPUTIME_ID),start=stamp(CLOCK_MONOTONIC),checksum=0;
    for(int i=0;i<w->n;i++) {
        if(w->kind==0) {
            if(w->index==0) {sem_post(&left);wait_sem(&right);counter++;}
            else {wait_sem(&left);sem_post(&right);}
        } else if(w->kind==1) {pthread_mutex_lock(&mutex);counter++;pthread_mutex_unlock(&mutex);}
        else if(w->index==0) {pthread_rwlock_wrlock(&rwlock);counter++;pthread_rwlock_unlock(&rwlock);}
        else {pthread_rwlock_rdlock(&rwlock);checksum+=counter;pthread_rwlock_unlock(&rwlock);}
    }
    w->wall_ns=stamp(CLOCK_MONOTONIC)-start;w->cpu_ns=stamp(CLOCK_THREAD_CPUTIME_ID)-cpu;
    getrusage(RUSAGE_THREAD,&after);w->user_us=us(after.ru_utime)-us(before.ru_utime);w->system_us=us(after.ru_stime)-us(before.ru_stime);
    w->voluntary=after.ru_nvcsw-before.ru_nvcsw;w->involuntary=after.ru_nivcsw-before.ru_nivcsw;w->checksum=checksum;
    return NULL;
}
int main(void) {
    sem_init(&left,0,0);sem_init(&right,0,0);pthread_barrier_init(&barrier,NULL,3);
    int cpus[3][2]={{48,48},{48,49},{48,144}};
    for(int repeat=0;repeat<3;repeat++)for(int kind=0;kind<3;kind++)for(int step=0;step<3;step++) {
        int place=(step+repeat)%3,n=kind==0?5000:500000;counter=0;
        struct Worker w[2]={{.index=0,.cpu=cpus[place][0],.kind=kind,.n=n},{.index=1,.cpu=cpus[place][1],.kind=kind,.n=n}};
        pthread_t threads[2];for(int i=0;i<2;i++)if(pthread_create(&threads[i],NULL,worker,&w[i]))return 2;
        uint64_t start=stamp(CLOCK_MONOTONIC);pthread_barrier_wait(&barrier);for(int i=0;i<2;i++)pthread_join(threads[i],NULL);uint64_t wall=stamp(CLOCK_MONOTONIC)-start;
        if(counter!=(uint64_t)n*(kind==1?2:1))return 4;
        printf("{\"repeat\":%d,\"kind\":%d,\"placement\":%d,\"n\":%d,\"wall_ns\":%llu,\"threads\":[",repeat,kind,place,n,(unsigned long long)wall);
        for(int i=0;i<2;i++)printf("%s{\"cpu\":%d,\"cpu_ns\":%llu,\"wall_ns\":%llu,\"user_us\":%llu,\"system_us\":%llu,\"voluntary\":%ld,\"involuntary\":%ld}",i?",":"",w[i].cpu,(unsigned long long)w[i].cpu_ns,(unsigned long long)w[i].wall_ns,(unsigned long long)w[i].user_us,(unsigned long long)w[i].system_us,w[i].voluntary,w[i].involuntary);
        printf("]}\n");fflush(stdout);
    }
    pthread_barrier_destroy(&barrier);pthread_rwlock_destroy(&rwlock);pthread_mutex_destroy(&mutex);sem_destroy(&left);sem_destroy(&right);return 0;
}
