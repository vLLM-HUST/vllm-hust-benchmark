import pathlib,subprocess,json,time,os,signal
b=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110');r=b/'hust-zsx-91';rows=[]
for kind in ['chain','multistream']:
 cmd=['/usr/bin/numactl','--membind=6',str(b/(kind+'-control')),'0'];start=time.time()
 with (r/(kind+'.jsonl')).open('w') as f,(r/(kind+'.stderr')).open('w') as e:
  p=subprocess.Popen(cmd,stdout=f,stderr=e,start_new_session=True)
  try:status=p.wait(timeout=400)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();status=124
 rows.append(dict(kind=kind,pid=p.pid,status=status,command=cmd,start=start,end=time.time()))
 (r/'c-controls-progress.json').write_text(json.dumps(rows,indent=2))
name='returned-native-stripe';root=r/(name+'-device1');live=pathlib.Path('/tmp/restore-causal-20261110')/(name+'-device1')
f=(r/'watch.log').open('w');watch=subprocess.Popen(['python3',str(b/'restore_causal_watch_20261110.py'),'--root',str(root),'--live',str(live)],stdout=f,stderr=f)
cmd=['/usr/local/python3.12.13/bin/python3',str(b/'restore_causal_probe_pc_20261110.py'),'--host','hust-zsx-91','--name',name,'--device','1','--numa','2','--counts','161','--layouts','reversed','--policies','0,10,0,11,0,10,0,11','--policy-library','memory-policy-stripe-v2.so','--observer','light']
with (r/'native-stripe.log').open('w') as f:
 result=subprocess.run(cmd,stdout=f,stderr=f,timeout=920)
(r/'native-stripe-return.json').write_text(json.dumps(dict(command=cmd,returncode=result.returncode)))
try:watch.wait(timeout=15)
except subprocess.TimeoutExpired:watch.terminate();watch.wait()
