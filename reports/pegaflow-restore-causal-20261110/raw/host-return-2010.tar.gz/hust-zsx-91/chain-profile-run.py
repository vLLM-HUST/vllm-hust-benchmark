import pathlib,subprocess,time,json,os,signal,shlex
b=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110');root=b/'hust-zsx-91'
if 'hust-zsx-91'=='hust-zsx-91':
 deadline=time.monotonic()+1200
 while not (root/'native-stripe-return.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('Waiting for finite unprofiled campaign to finish')
  time.sleep(1)
 receipt=root/'returned-native-stripe-device1/native-process.json'
 if receipt.exists():
  pid=json.loads(receipt.read_text())['pid']
  while pathlib.Path(f'/proc/{pid}').exists():
   if time.monotonic()>deadline:raise TimeoutError('Native process has not exited')
   time.sleep(.2)
app=['/usr/bin/numactl','--membind=6',str(b/'chain-profile-control'),'0']
cmd=['/usr/local/Ascend/cann-9.1.0/bin/msprof','--task-time=on','--runtime-api=on','--output='+str(root/'chain-profile'),'--application='+shlex.join(app)]
env=os.environ.copy();env.pop('PROFILING_MODE',None);env.pop('PROFILING_OPTIONS',None)
start=time.time()
with (root/'chain-profile.log').open('w') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=f,env=env,start_new_session=True)
 (root/'chain-profile-process.json').write_text(json.dumps(dict(pid=p.pid,command=cmd,start=start,env={k:env.get(k) for k in ['LD_PRELOAD','LD_LIBRARY_PATH']}),indent=2))
 try:status=p.wait(timeout=600)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);time.sleep(3);os.killpg(p.pid,signal.SIGKILL);p.wait();status=124
(root/'chain-profile-done.json').write_text(json.dumps(dict(status=status,start=start,end=time.time())))
