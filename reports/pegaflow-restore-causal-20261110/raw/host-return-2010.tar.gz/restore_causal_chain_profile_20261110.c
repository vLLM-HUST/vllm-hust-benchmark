#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <unistd.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
    alarm(900);
    int device=argc>1?atoi(argv[1]):1;size_t bytes=1024UL*1024*1024,n=16384,piece=bytes/n;
    void *alias=NULL,*dest=NULL; aclrtStream streams[16]={0};aclrtEvent events[32]={0};
    CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));
    void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(host==MAP_FAILED)return 2;
    memset(host,0x5a,bytes);for(size_t i=0;i<n;i++)*(uint64_t*)((char*)host+i*piece)=i;
    CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));
    for(int i=0;i<16;i++)CHECK(aclrtCreateStream(&streams[i]));for(int i=0;i<32;i++)CHECK(aclrtCreateEvent(&events[i]));
    void *sources[512],*targets[512];size_t sizes[512],maximum[512];
    int sequence[6]={0,1,2,2,1,0};
    for(int repeat=0;repeat<6;repeat++) {
        int mode=sequence[repeat],active=mode?16:1;
        aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;
        size_t index=0,failed=0;uint64_t epoch=ns(CLOCK_REALTIME),start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
        for(size_t offset=0;offset<n;offset+=512) {
            size_t batch=offset/512;aclrtStream stream=streams[batch%active];
            if(mode==2&&batch)CHECK(aclrtStreamWaitEvent(stream,events[batch-1]));
            for(size_t j=0;j<512;j++) {size_t pos=(offset+j)*piece;sources[j]=(char*)host+pos;targets[j]=(char*)dest+pos;sizes[j]=maximum[j]=piece;}
            CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,512,&attr,&index,1,&failed,stream));
            if(mode==2)CHECK(aclrtRecordEvent(events[batch],stream));
        }
        uint64_t submitted=ns(CLOCK_MONOTONIC);for(int i=0;i<active;i++)CHECK(aclrtSynchronizeStream(streams[i]));
        uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
        printf("{\"repeat\":%d,\"mode\":%d,\"streams\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"epoch_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",repeat,mode,active,n,bytes,(unsigned long long)epoch,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu));fflush(stdout);
        for(size_t i=0;i<n;i+=8191) {uint64_t sample[8];CHECK(aclrtMemcpy(sample,sizeof(sample),(char*)dest+i*piece,sizeof(sample),ACL_MEMCPY_DEVICE_TO_HOST));if(sample[0]!=i||sample[1]!=0x5a5a5a5a5a5a5a5aULL)return 3;}
    }
    for(int i=0;i<32;i++)CHECK(aclrtDestroyEvent(events[i]));for(int i=0;i<16;i++)CHECK(aclrtDestroyStream(streams[i]));
    CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
