#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static Batch batch;
static int (*unlock_mutex)(pthread_mutex_t*);
static pthread_once_t range_once=PTHREAD_ONCE_INIT;
static uintptr_t range_lo[16],range_hi[16];static int range_count;
static __thread int in_batch,mode;
static __thread uint64_t contended,paused,pause_ns,seen,scoped,kind_counts[4],waiter_seen;
static uint64_t stamp(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static int ranges(struct dl_phdr_info *i,size_t n,void *data) {
    (void)n;(void)data;
    if(!strstr(i->dlpi_name,"libruntime_v100.so")&&!strstr(i->dlpi_name,"libmmpa.so")&&!strstr(i->dlpi_name,"libascend_hal.so")&&!strstr(i->dlpi_name,"libacl_rt_impl.so"))return 0;
    uintptr_t end=0;
    for(int k=0;k<i->dlpi_phnum;k++)if(i->dlpi_phdr[k].p_type==PT_LOAD) {
        uintptr_t z=i->dlpi_phdr[k].p_vaddr+i->dlpi_phdr[k].p_memsz;if(z>end)end=z;
    }
    if(range_count<16) {range_lo[range_count]=i->dlpi_addr;range_hi[range_count++]=i->dlpi_addr+end;}
    return 0;
}
static void init_ranges(void) {dl_iterate_phdr(ranges,NULL);}
__attribute__((constructor)) static void init(void) {
    unlock_mutex=(int(*)(pthread_mutex_t*))dlsym(RTLD_NEXT,"pthread_mutex_unlock");
    batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");
    if(!unlock_mutex||!batch)_exit(125);
}
int pthread_mutex_unlock(pthread_mutex_t *mutex) {
    if(!unlock_mutex) {unlock_mutex=(int(*)(pthread_mutex_t*))dlsym(RTLD_NEXT,"pthread_mutex_unlock");if(!unlock_mutex)_exit(125);}
    int type=mutex->__data.__kind&3;
    int candidate=in_batch&&mutex->__data.__lock>1&&!(mutex->__data.__kind&0x70)&&(type!=1||mutex->__data.__count==1);
    if(in_batch){seen++;kind_counts[type]++;if(mutex->__data.__lock>1)waiter_seen++;}
    uintptr_t caller=(uintptr_t)__builtin_return_address(0);int selected=0;
    if(candidate)for(int i=0;i<range_count;i++)if(caller>=range_lo[i]&&caller<range_hi[i]){selected=1;break;}
    if(in_batch&&selected)scoped++;
    int result=unlock_mutex(mutex);
    if(!result&&selected) {
        contended++;
        if(mode) {
            uint64_t start=stamp();
            if(mode==1)sched_yield();
            else {
                long slack=prctl(PR_GET_TIMERSLACK,0,0,0,0);
                int changed=slack>0&&prctl(PR_SET_TIMERSLACK,1UL,0,0,0)==0;
                struct timespec pause={0,1000};nanosleep(&pause,NULL);
                if(changed)prctl(PR_SET_TIMERSLACK,(unsigned long)slack,0,0,0);
            }
            paused++;pause_ns+=stamp()-start;
        }
    }
    return result;
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
    aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream) {
    pthread_once(&range_once,init_ranges);
    int outer=!in_batch;
    if(outer) {
        mode=0;const char *p=getenv("NATIVE_COPY_POLICY");if(p){int fd=open(p,O_RDONLY);if(fd>=0){if(read(fd,&mode,sizeof(mode))!=sizeof(mode))mode=0;close(fd);}}
        if(mode<0||mode>2)_exit(127);contended=paused=pause_ns=seen=scoped=waiter_seen=0;memset(kind_counts,0,sizeof(kind_counts));
    }
    in_batch++;uint64_t start=stamp();aclError result=batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);uint64_t end=stamp();in_batch--;
    if(outer) {
        const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p){int fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);if(fd>=0){char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"contended_unlock_control\",\"tid\":%ld,\"mode\":%d,\"count\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"contended_unlocks\":%llu,\"pauses\":%llu,\"pause_wall_ns\":%llu,\"seen_unlocks\":%llu,\"waiter_unlocks\":%llu,\"kind_counts\":[%llu,%llu,%llu,%llu]}\n",syscall(SYS_gettid),mode,count,(unsigned long long)start,(unsigned long long)end,(unsigned long long)contended,(unsigned long long)paused,(unsigned long long)pause_ns,(unsigned long long)seen,(unsigned long long)waiter_seen,(unsigned long long)kind_counts[0],(unsigned long long)kind_counts[1],(unsigned long long)kind_counts[2],(unsigned long long)kind_counts[3]);write(fd,line,n);close(fd);}}
    }
    return result;
}
