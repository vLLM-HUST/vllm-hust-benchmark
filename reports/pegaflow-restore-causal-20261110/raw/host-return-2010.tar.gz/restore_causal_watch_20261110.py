"""Bounded read-only slow-call sampling for one task-owned native process."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import signal
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--live', type=Path, required=True)
    args = parser.parse_args()
    end = time.monotonic() + 1200
    receipt = args.root / 'native-process.json'
    while not receipt.exists():
        if time.monotonic() > end:
            raise TimeoutError('No native process was registered')
        time.sleep(.5)
    pid = json.loads(receipt.read_text())['pid']
    proc = Path(f'/proc/{pid}')
    if not proc.exists() or b'pegaflow-server' not in (proc / 'cmdline').read_bytes():
        return
    libc = ctypes.CDLL(None)
    send = libc.tgkill
    send.argtypes = [ctypes.c_int] * 3
    send.restype = ctypes.c_int
    previous = {}
    busy = 0
    bursts = 0

    def threads():
        rows = []
        for p in (proc / 'task').iterdir():
            try:
                name = (p / 'comm').read_text().strip()
                if any(s in name for s in ['-load', '-save', 'RT_RECYCLE']):
                    rows.append(dict(tid=int(p.name), name=name,
                                     runtime_ns=int((p / 'schedstat').read_text().split()[0]),
                                     wchan=(p / 'wchan').read_text().strip()))
            except OSError:
                pass
        return rows

    while proc.exists() and time.monotonic() < end:
        try:
            current = threads()
        except FileNotFoundError:
            break
        activity = any(x['runtime_ns'] - previous.get(x['tid'], x['runtime_ns']) > 100_000_000
                       for x in current if '-load' in x['name'] or '-save' in x['name'])
        previous = {x['tid']: x['runtime_ns'] for x in current}
        busy = busy + 1 if activity else 0
        # This file is opened only when the observer successfully installs its handler.
        trace = args.live / 'pc.bin'
        if busy >= 2 and bursts < 4 and trace.exists():
            mask = int(next(s.split(':', 1)[1].strip() for s in (proc / 'status').read_text().splitlines() if s.startswith('SigCgt:')), 16)
            if not mask & (1 << (signal.SIGUSR2 - 1)):
                raise RuntimeError('Observer signal handler is unavailable')
            bursts += 1
            (args.root / f'watch-{bursts}-maps.txt').write_text((proc / 'maps').read_text())
            row = dict(burst=bursts, pid=pid, start_epoch_ns=time.time_ns(),
                       start_monotonic_ns=time.monotonic_ns(), before=current, signals=0)
            until = time.monotonic() + 8
            while proc.exists() and time.monotonic() < until:
                try:
                    for x in threads():
                        if send(pid, x['tid'], signal.SIGUSR2) == 0:
                            row['signals'] += 1
                except FileNotFoundError:
                    break
                time.sleep(.05)
            row.update(end_epoch_ns=time.time_ns(), end_monotonic_ns=time.monotonic_ns())
            if proc.exists():
                try:
                    row['after'] = threads()
                except FileNotFoundError:
                    pass
            with (args.root / 'watch-windows.jsonl').open('a') as f:
                f.write(json.dumps(row) + '\n')
            busy = 0
            time.sleep(1)
        time.sleep(.5)
    (args.root / 'watch-done.json').write_text(json.dumps(dict(pid=pid, bursts=bursts, epoch=time.time())))


if __name__ == '__main__':
    main()
