#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <unistd.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
 alarm(480);int device=argc>1?atoi(argv[1]):0;
 const size_t piece=262144,n=15456,bytes=n*piece;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));
 void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 void *readback=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(host==MAP_FAILED||readback==MAP_FAILED)return 2;
 memset(host,0x5a,bytes);memset(readback,0,bytes);
 void *alias=NULL,*dest=NULL;aclrtStream stream=NULL;
 CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
 CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 void *sources[512],*targets[512];size_t sizes[512],maximum[512];int slow=0;
 for(int repeat=0;repeat<12;repeat++) {
  for(size_t i=0;i<n;i++)*(uint64_t*)((char*)host+i*piece)=((uint64_t)(repeat+1)<<32)|i;
  aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;
  size_t index=0,failed=0;uint64_t epoch=ns(CLOCK_REALTIME),start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  for(size_t offset=0;offset<n;offset+=512) {
   size_t count=n-offset;if(count>512)count=512;
   for(size_t j=0;j<count;j++){size_t i=offset+j;sources[j]=(char*)host+i*piece;targets[j]=(char*)dest+(n-i-1)*piece;sizes[j]=maximum[j]=piece;}
   CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,count,&attr,&index,1,&failed,stream));
  }
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));
  uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
  CHECK(aclrtMemcpy(readback,bytes,dest,bytes,ACL_MEMCPY_DEVICE_TO_HOST));
  for(size_t i=0;i<n;i++){
   uint64_t *v=(uint64_t*)((char*)readback+(n-i-1)*piece);
   if(v[0]!=(((uint64_t)(repeat+1)<<32)|i)||v[1]!=0x5a5a5a5a5a5a5a5aULL){fprintf(stderr,"data mismatch repeat=%d block=%zu\n",repeat,i);return 3;}
  }
  printf("{\"repeat\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"epoch_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"verified_tags\":%zu}\n",repeat,n,bytes,(unsigned long long)epoch,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu),n);fflush(stdout);
  slow+=(end-start)>10000000000ULL;if(slow>=2)break;
 }
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);munmap(readback,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
