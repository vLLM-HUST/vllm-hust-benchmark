/* Compare registered mmap, OS-locked registered mmap, and CANN MallocHost. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
static void attrs(void *ptr,int mode,int round){
 FILE *f=fopen("/proc/self/smaps","r");if(!f)return;char line[512];unsigned long lo,hi;int active=0;
 while(fgets(line,sizeof(line),f)){
  if(sscanf(line,"%lx-%lx",&lo,&hi)==2){if(active)break;active=(uintptr_t)ptr>=lo&&(uintptr_t)ptr<hi;}
  if(active&&(strstr(line,"Locked:")||strstr(line,"AnonHugePages:")||strstr(line,"KernelPageSize:")||strstr(line,"VmFlags:")))fprintf(stderr,"SOURCE mode%d round%d %s",mode,round,line);
 }fclose(f);fflush(stderr);
}
int main(int argc,char **argv){
 alarm(600);int device=argc>1?atoi(argv[1]):1;size_t bytes=4UL<<30,n=16384,piece=bytes/n;void *src[3]={0},*dest=NULL,*alias=NULL;int available[3]={1,1,1};aclrtStream stream=NULL;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));
 for(int mode=0;mode<3;mode++){
  uint64_t start=ns(CLOCK_MONOTONIC);int result=0,err=0;
  if(mode<2){
   src[mode]=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(src[mode]==MAP_FAILED)return 2;
   memset(src[mode],0x5a,bytes);
   if(mode==1){result=mlock(src[mode],bytes);err=errno;}
   if(!result)result=aclrtHostRegister(src[mode],bytes,ACL_HOST_REGISTER_MAPPED,&alias);
  }else {result=aclrtMallocHost(&src[mode],bytes);if(!result)memset(src[mode],0x5a,bytes);}
  available[mode]=result==0;printf("{\"event\":\"allocation\",\"mode\":%d,\"result\":%d,\"errno\":%d,\"wall_ns\":%llu}\n",mode,result,err,(unsigned long long)(ns(CLOCK_MONOTONIC)-start));fflush(stdout);
 }
 CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 int order[3][3]={{0,1,2},{2,1,0},{1,0,2}};
 for(int repeat=0;repeat<6;repeat++)for(int step=0;step<3;step++){
  int mode=order[repeat%3][step];if(!available[mode])continue;uint64_t tag=4000+repeat*20+mode;
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;*(uint64_t*)((char*)src[mode]+block*piece)=tag+block;CHECK(aclrtMemsetAsync((char*)dest+block*piece,8,0,8,stream));}
  CHECK(aclrtSynchronizeStream(stream));attrs(src[mode],mode,repeat);uint64_t start=ns(CLOCK_MONOTONIC);
  for(size_t i=0;i<n;i++)CHECK(aclrtMemcpyAsync((char*)dest+i*piece,piece,(char*)src[mode]+i*piece,piece,ACL_MEMCPY_HOST_TO_DEVICE,stream));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC);
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;uint64_t actual=0;CHECK(aclrtMemcpy(&actual,8,(char*)dest+block*piece,8,ACL_MEMCPY_DEVICE_TO_HOST));if(actual!=tag+block)return 3;}
  printf("{\"event\":\"copy\",\"mode\":%d,\"repeat\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"verified_tags\":8}\n",mode,repeat,n,bytes,(unsigned long long)start,(unsigned long long)end,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start));fflush(stdout);
 }
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(dest));
 for(int mode=0;mode<3;mode++)if(available[mode]){if(mode==2)CHECK(aclrtFreeHost(src[mode]));else{CHECK(aclrtHostUnregister(src[mode]));if(mode==1)munlock(src[mode],bytes);munmap(src[mode],bytes);}}
 CHECK(aclrtResetDevice(device));CHECK(aclFinalize());printf("{\"event\":\"completed\"}\n");fflush(stdout);return 0;
}
