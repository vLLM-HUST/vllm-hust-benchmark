
import pathlib,json,gzip,time,urllib.request
r=pathlib.Path('/root/long-pd-dma-controller-20261111');deadline=time.monotonic()+1200
while True:
 try:urllib.request.urlopen('http://127.0.0.1:38680/health',timeout=1).read();break
 except OSError:
  if time.monotonic()>deadline:raise TimeoutError('P0 startup')
  time.sleep(2)
with gzip.open(r/'workload.jsonl.gz','rt') as f:row=min((json.loads(x) for x in f),key=lambda x:abs(x['prompt_tokens']-8244))
(r/'phase.json').write_text(json.dumps(dict(label='dma-route-v2-P0-probe',requests=2)))
def call(url,payload):
 with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'}),timeout=180) as response:return json.loads(response.read())
for d in range(2):
 label=f'dma-route-v2-P0D{d}'
 payload=dict(model='qwen14',prompt=row['prompt_token_ids'],temperature=0,ignore_eos=True,seed=17,cache_salt=label,max_tokens=1,stream=False,request_id=label+'-P')
 start=time.time();p=call('http://127.0.0.1:38680/v1/completions',payload);p_end=time.time()
 marker=r/'visibility/P0'/(label+'-P.tp0.visible');limit=time.monotonic()+180
 while not marker.exists():
  if time.monotonic()>limit:raise TimeoutError('P0 visibility marker')
  time.sleep(.01)
 visible=time.time();payload['request_id']=label+'-D';answer=call(f'http://192.168.0.2:{38682+d}/v1/completions',payload)
 record=dict(label=label,prompt_tokens=row['prompt_tokens'],P_response_s=p_end-start,publication_wait_s=visible-p_end,D_complete_s=time.time()-visible,epoch=time.time(),P_usage=p.get('usage'),D_usage=answer.get('usage'),D_choice=answer.get('choices'))
 with (r/'dma-route-v2-P0-probe.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 print(json.dumps(record),flush=True)
(r/'dma-route-v2-P0-probe-done.json').write_text(json.dumps(dict(epoch=time.time(),requests=2)))
