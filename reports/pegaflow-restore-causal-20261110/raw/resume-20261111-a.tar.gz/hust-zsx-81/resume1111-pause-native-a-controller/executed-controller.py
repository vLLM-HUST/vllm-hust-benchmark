"""Finite causal control: pause only our native server while its accepted DMA queue drains."""

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import threading
import time

BASE = Path('/data/shared_upload/hust-zsx/restore-causal-20261110')


def emit(path, row):
    with path.open('a') as stream:
        stream.write(json.dumps(row) + '\n')


def read_jsonl(path):
    if not path.exists():
        return []
    rows = []
    for line in path.read_text().splitlines():
        try:
            rows.append(json.loads(line))
        except ValueError:
            pass
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True)
    parser.add_argument('--device', type=int, required=True)
    parser.add_argument('--physical-device', type=int, required=True)
    parser.add_argument('--numa', type=int, required=True)
    parser.add_argument('--name', required=True)
    args = parser.parse_args()
    root = BASE / args.host / (args.name + '-controller')
    root.mkdir(exist_ok=False)
    shutil.copy2(Path(__file__), root / 'executed-controller.py')
    target = BASE / args.host / (args.name + f'-device{args.device}')
    native_pid = None
    paused = False
    probe = None
    cancel = threading.Event()

    def rescue():
        # Separate watchdog resumes the owned process if the monitor fails.
        if not cancel.wait(600):
            if native_pid is not None:
                try:
                    os.killpg(native_pid, signal.SIGCONT)
                except ProcessLookupError:
                    pass
            if probe is not None and probe.poll() is None:
                os.killpg(probe.pid, signal.SIGTERM)

    threading.Thread(target=rescue, daemon=True).start()
    try:
        env = os.environ.copy()
        env.pop('ASCEND_RT_VISIBLE_0S', None)
        env['PYTHONPATH'] = '/data/shared_upload/hust-zsx/long-pd-20261109/source/python'
        command = [
            '/usr/local/python3.12.13/bin/python3',
            str(BASE / 'restore_causal_probe_kernel_20261110_v3.py'),
            '--host', args.host, '--device', str(args.device),
            '--physical-device', str(args.physical_device), '--numa', str(args.numa),
            '--name', args.name, '--counts', '161', '--policies', '0,0,0,0,0,0',
            '--kernel-stages', '0,0,0,0,0,0',
            '--policy-library', 'memory-policy-bounded.so:' + str(BASE / 'hal-send.so'),
            '--observer', 'light', '--all-tags',
        ]
        probe = subprocess.Popen(command, env=env, start_new_session=True,
                                 stdout=(root / 'probe.log').open('w'),
                                 stderr=subprocess.STDOUT)
        (root / 'process.json').write_text(json.dumps(
            dict(pid=probe.pid, command=command, epoch=time.time())))
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            process = target / 'native-process.json'
            resource = target / 'kernel-resources.json'
            if process.exists() and resource.exists():
                break
            if probe.poll() is not None:
                raise RuntimeError('Probe ended before native resources became ready')
            time.sleep(.1)
        else:
            raise TimeoutError('Native resources not ready')
        native_pid = json.loads(process.read_text())['pid']
        assert os.getpgid(native_pid) == native_pid
        paths = [Path(p) for p in json.loads(resource.read_text())['paths']
                 if p.startswith('/proc/trs_chan/')]
        # Restrict thread inspection to this owned native process.
        load_tid = None
        for task in (Path('/proc') / str(native_pid) / 'task').iterdir():
            if (task / 'comm').read_text().strip().endswith('-load'):
                load_tid = int(task.name)
        if load_tid is None:
            raise RuntimeError('Owned native load thread not found')
        live = Path('/tmp/restore-causal-20261110') / target.name / 'api.jsonl'
        accepted = 0
        load_sq = None
        offset = 0
        residue = ''
        channel_path = None
        intervention_stages = {1, 3, 5}
        done_stages = set()
        stage_since = time.monotonic()
        previous_stage = None
        history = []

        def consume_api():
            nonlocal offset, residue, accepted, load_sq
            if not live.exists():
                return
            with live.open() as stream:
                stream.seek(offset)
                chunk = stream.read()
                offset = stream.tell()
            lines = (residue + chunk).split('\n')
            residue = lines.pop()
            for line in lines:
                if not line:
                    continue
                row = json.loads(line)
                if row.get('event') == 'hal_send' and row.get('tid') == load_tid \
                        and row.get('kind') == 'task' and row.get('error') == 0:
                    accepted += row['count']
                    load_sq = row['sq']

        def snapshot(kind, stage):
            consume_api()
            start = time.monotonic_ns()
            text = channel_path.read_text()
            end = time.monotonic_ns()
            forwarded = int(re.search(r'stat: tx\((\d+)\)', text)[1])
            row = dict(kind=kind, stage=stage, start_ns=start, end_ns=end,
                       accepted_at_read=accepted, forwarded=forwarded, text=text)
            emit(root / 'queue.jsonl', row)
            return row

        while time.monotonic() < deadline:
            if probe.poll() is not None:
                break
            consume_api()
            completed = [r for r in read_jsonl(target / 'operations.jsonl')
                         if r.get('event') == 'restore']
            stage = len(completed) - 1  # warm completed -> stage 0 currently executing
            if stage != previous_stage:
                history = []
                stage_since = time.monotonic()
                previous_stage = stage
            if load_sq is None:
                time.sleep(.05)
                continue
            if channel_path is None:
                for path in paths:
                    if re.search(r'sq: id\(' + str(load_sq) + r'\)', path.read_text()):
                        channel_path = path
                        break
                if channel_path is None:
                    time.sleep(.05)
                    continue
            try:
                row = snapshot('running', stage)
            except FileNotFoundError:
                if probe.poll() is not None or (target / 'done.json').exists():
                    break
                raise
            history.append(row)
            history = history[-6:]
            # Allow a normal running window before each intervention; require
            # a substantial backlog already accepted by the driver.
            if stage in intervention_stages and stage not in done_stages \
                    and time.monotonic() - stage_since >= .25 \
                    and accepted - row['forwarded'] >= 1024:
                begin = time.monotonic_ns()
                os.killpg(native_pid, signal.SIGSTOP)
                paused = True
                try:
                    for _ in range(10):
                        time.sleep(.05)
                        snapshot('native_stopped', stage)
                finally:
                    os.killpg(native_pid, signal.SIGCONT)
                    paused = False
                emit(root / 'interventions.jsonl', dict(
                    stage=stage, signal='SIGSTOP/SIGCONT', pid=native_pid,
                    begin_ns=begin, end_ns=time.monotonic_ns(),
                    running_history=history))
                done_stages.add(stage)
                stage_since = time.monotonic()
            time.sleep(.05)
        if probe.poll() is None:
            raise TimeoutError('Finite pause control exceeded 600s')
        (root / 'done.json').write_text(json.dumps(dict(
            returncode=probe.returncode, interventions=sorted(done_stages), epoch=time.time())))
    except BaseException as error:
        (root / 'failure.json').write_text(json.dumps(dict(error=repr(error), epoch=time.time())))
        raise
    finally:
        cancel.set()
        if paused and native_pid is not None:
            os.killpg(native_pid, signal.SIGCONT)
        if probe is not None and probe.poll() is None:
            if native_pid is not None:
                try:
                    os.killpg(native_pid, signal.SIGCONT)
                    os.killpg(native_pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            os.killpg(probe.pid, signal.SIGTERM)


if __name__ == '__main__':
    main()
