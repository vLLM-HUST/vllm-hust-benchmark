/* Finite opcode / payload control, preserving descriptor count and working set. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char **argv){
 alarm(420);int device=argc>1?atoi(argv[1]):1;size_t stride=262144,n=16384,bytes=stride*n;
 void *host=NULL,*source=NULL,*dest=NULL,*alias=NULL;aclrtStream stream=NULL;
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));
 host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(host==MAP_FAILED)return 2;
 memset(host,0x5a,bytes);CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
 CHECK(aclrtMalloc(&source,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 CHECK(aclrtMemcpyAsync(source,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,stream));CHECK(aclrtSynchronizeStream(stream));
 typedef int(*Nop)(void*);Nop nop=(Nop)dlsym(RTLD_DEFAULT,"rtNopTask");
 int plans[3][5]={{0,1,2,3,4},{4,3,2,1,0},{0,3,4,1,2}};
 for(int repeat=0;repeat<3;repeat++)for(int step=0;step<5;step++){
  int kind=plans[repeat][step];size_t piece=(kind==1||kind==2)?4096:stride;uint64_t tag=1000+repeat*20+step;
  for(int j=0;j<8;j++){
   size_t block=(size_t)j*(n-1)/7,offset=block*stride;
   *(uint64_t*)((char*)host+offset)=tag+block;
   CHECK(aclrtMemcpyAsync((char*)source+offset,8,(char*)host+offset,8,ACL_MEMCPY_HOST_TO_DEVICE,stream));
   CHECK(aclrtMemsetAsync((char*)dest+offset,8,0,8,stream));
  }
  CHECK(aclrtSynchronizeStream(stream));
  uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);int error=0;size_t submitted=0;
  for(size_t i=0;i<n;i++){
   if(kind==0)error=nop?nop(stream):-1;
   else error=aclrtMemcpyAsync((char*)dest+i*stride,piece,(char*)(kind==2||kind==4?source:host)+i*stride,piece,
      (kind==2||kind==4)?ACL_MEMCPY_DEVICE_TO_DEVICE:ACL_MEMCPY_HOST_TO_DEVICE,stream);
   if(error)break;submitted++;
  }
  uint64_t submitted_at=ns(CLOCK_MONOTONIC);int sync_error=aclrtSynchronizeStream(stream);uint64_t end=ns(CLOCK_MONOTONIC),endcpu=ns(CLOCK_THREAD_CPUTIME_ID);
  int verified=0;
  if(kind&&!error&&!sync_error){
   for(int j=0;j<8;j++){
    size_t block=(size_t)j*(n-1)/7;uint64_t actual=0;
    CHECK(aclrtMemcpy(&actual,8,(char*)dest+block*stride,8,ACL_MEMCPY_DEVICE_TO_HOST));
    if(actual!=tag+block){fprintf(stderr,"tag mismatch kind%d block%zu got%llu expected%llu\n",kind,block,(unsigned long long)actual,(unsigned long long)(tag+block));return 3;}verified++;
   }
  }
  printf("{\"repeat\":%d,\"kind\":%d,\"kind_name\":\"%s\",\"piece_bytes\":%zu,\"descriptors\":%zu,\"submitted\":%zu,\"bytes\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"thread_cpu_ns\":%llu,\"error\":%d,\"sync_error\":%d,\"verified_tags\":%d}\n",
   repeat,kind,kind==0?"nop":kind==1?"h2d4k":kind==2?"d2d4k":kind==3?"h2d256k":"d2d256k",kind?piece:0,n,submitted,kind?n*piece:0,
   (unsigned long long)start,(unsigned long long)end,(unsigned long long)(submitted_at-start),(unsigned long long)(end-submitted_at),(unsigned long long)(end-start),(unsigned long long)(endcpu-cpu),error,sync_error,verified);fflush(stdout);
  if(error&&kind) return 4;if(sync_error)return 5;
 }
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(source));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
