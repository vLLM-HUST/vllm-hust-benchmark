from pathlib import Path
import subprocess,json,time
b=Path('/data/shared_upload/hust-zsx/restore-causal-20261110');h='hust-zsx-91';results=[]
plan=[(0,6),(1,2),(0,2),(1,6),(1,6),(0,2),(1,2),(0,6)]
for index,(device,memory) in enumerate(plan):
 cpu=6 if device==0 else 2;name=f'native-numa-{index}-memory{memory}'
 command=['/usr/local/python3.12.13/bin/python3',str(b/'restore_causal_probe_numa_20261110.py'),'--host',h,'--device',str(device),'--numa',str(memory),'--cpu-node',str(cpu),'--name',name,'--counts','161','--layouts','reversed','--policies','0,0','--policy-library','memory-policy-stripe-v2.so','--observer','light','--affinity-plan','local,local']
 with (b/h/(name+'.log')).open('w') as log:
  p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (b/h/(name+'-process.json')).write_text(json.dumps(dict(pid=p.pid,command=command,start=time.time()),indent=2))
  result=p.wait(timeout=940)
 results.append(dict(index=index,device=device,memory=memory,cpu_node=cpu,returncode=result,end=time.time()))
 (b/h/'numa-matrix-progress.json').write_text(json.dumps(results,indent=2))
 if result:break
