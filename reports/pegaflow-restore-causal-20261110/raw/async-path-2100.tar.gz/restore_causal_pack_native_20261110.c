#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
typedef aclError (*Sync)(aclrtStream);
struct Copy {void *src,*dst;size_t bytes;};
static __thread struct Copy *copies;
static __thread size_t length,capacity,host_capacity;
static __thread void *host;
static __thread aclrtStream origin;
static __thread aclrtMemcpyBatchAttr attribute;
static void *symbol(const char *n){void *p=dlsym(RTLD_NEXT,n);if(!p)_Exit(125);return p;}
static uint64_t stamp(clockid_t kind){struct timespec t;clock_gettime(kind,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static int by_destination(const void *a,const void *b){uintptr_t x=(uintptr_t)((const struct Copy*)a)->dst,y=(uintptr_t)((const struct Copy*)b)->dst;return (x>y)-(x<y);}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
 aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream){
 Batch next=(Batch)symbol("aclrtMemcpyBatchAsync");int mode=0;const char *p=getenv("NATIVE_COPY_POLICY");
 if(p){int fd=open(p,O_RDONLY);if(fd>=0){if(read(fd,&mode,sizeof(mode))!=sizeof(mode))mode=0;close(fd);}}
 int h2d=attr&&indices&&nattr==1&&indices[0]==0&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
 if(mode==0||!h2d)return next(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);
 if(mode!=20)_Exit(126);
 if(!length){aclError result=((Sync)symbol("aclrtSynchronizeStream"))(stream);if(result)return result;origin=stream;attribute=attr[0];}
 if(origin!=stream||attribute.dstLoc.id!=attr[0].dstLoc.id)_Exit(127);
 if(length+count>capacity){capacity=length+count+4096;copies=realloc(copies,capacity*sizeof(*copies));if(!copies)_Exit(128);}
 for(size_t i=0;i<count;i++)copies[length++]=(struct Copy){src[i],dst[i],sizes[i]};
 return 0;
}
aclError aclrtSynchronizeStream(aclrtStream stream){
 Sync next=(Sync)symbol("aclrtSynchronizeStream");if(!length||origin!=stream)return next(stream);
 uint64_t epoch=stamp(CLOCK_REALTIME),start=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID);
 qsort(copies,length,sizeof(*copies),by_destination);size_t bytes=0;
 for(size_t i=0;i<length;i++){
  if(i&&(uintptr_t)copies[i-1].dst+copies[i-1].bytes>(uintptr_t)copies[i].dst)_Exit(129);
  bytes+=copies[i].bytes;
 }
 if(bytes>host_capacity){
  if(host){typedef aclError(*Unregister)(void*);aclError result=((Unregister)symbol("aclrtHostUnregister"))(host);if(result)return result;munmap(host,host_capacity);host=NULL;host_capacity=0;}
  host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(host==MAP_FAILED)_Exit(130);
  memset(host,0,bytes);void *alias=NULL;typedef aclError(*Register)(void*,uint64_t,aclrtHostRegisterType,void**);
  aclError result=((Register)symbol("aclrtHostRegister"))(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias);if(result)return result;host_capacity=bytes;
 }
 uint64_t initialized=stamp(CLOCK_MONOTONIC);
 void **sources=malloc(length*sizeof(void*)),**targets=malloc(length*sizeof(void*));
 size_t *sizes=malloc(length*sizeof(size_t)),*maximum=malloc(length*sizeof(size_t));
 if(!sources||!targets||!sizes||!maximum)_Exit(131);
 size_t offset=0,runs=0;
 for(size_t i=0;i<length;i++){
  memcpy((char*)host+offset,copies[i].src,copies[i].bytes);
  if(runs&&(uintptr_t)targets[runs-1]+sizes[runs-1]==(uintptr_t)copies[i].dst){sizes[runs-1]+=copies[i].bytes;maximum[runs-1]=sizes[runs-1];}
  else{sources[runs]=(char*)host+offset;targets[runs]=copies[i].dst;sizes[runs]=maximum[runs]=copies[i].bytes;runs++;}
  offset+=copies[i].bytes;
 }
 uint64_t packed=stamp(CLOCK_MONOTONIC);size_t index=0,failed=0;
 aclError result=((Batch)symbol("aclrtMemcpyBatchAsync"))(targets,maximum,sources,sizes,runs,&attribute,&index,1,&failed,stream);
 uint64_t submitted=stamp(CLOCK_MONOTONIC);if(!result)result=next(stream);
 uint64_t end=stamp(CLOCK_MONOTONIC),cpu_end=stamp(CLOCK_THREAD_CPUTIME_ID);
 const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p){int fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);if(fd>=0){char line[640];int n=snprintf(line,sizeof(line),"{\"event\":\"native_pack\",\"tid\":%ld,\"epoch_ns\":%llu,\"input_descriptors\":%zu,\"output_descriptors\":%zu,\"bytes\":%zu,\"init_ns\":%llu,\"pack_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"result\":%d}\n",syscall(SYS_gettid),(unsigned long long)epoch,length,runs,bytes,(unsigned long long)(initialized-start),(unsigned long long)(packed-initialized),(unsigned long long)(submitted-packed),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpu_end-cpu),result);if(n>0&&(size_t)n<sizeof(line))write(fd,line,n);close(fd);}}
 free(sources);free(targets);free(sizes);free(maximum);length=0;origin=NULL;return result;
}
