from pathlib import Path
import subprocess,json,time
b=Path('/data/shared_upload/hust-zsx/restore-causal-20261110');h='hust-zsx-91';results=[]
p=b/h/'numa-matrix-progress.json'
while True:
 rows=json.loads(p.read_text()) if p.exists() else []
 if len(rows)==8:break
 if rows and rows[-1]['returncode']:raise RuntimeError('NUMA campaign failed')
 time.sleep(1)
for device,numa in [(1,2),(0,6)]:
 command=['/usr/local/python3.12.13/bin/python3',str(b/'restore_causal_probe_alltags_20261110.py'),'--host',h,'--device',str(device),'--numa',str(numa),'--name','native-async-pieces','--counts','161','--layouts','reversed','--policies','0,22,0,22','--policy-library','memory-policy-piece-api.so','--observer','light','--all-tags']
 with (b/h/f'native-async-pieces-device{device}.log').open('w') as log:
  p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (b/h/f'native-async-pieces-device{device}-process.json').write_text(json.dumps(dict(pid=p.pid,command=command,start=time.time()),indent=2))
  result=p.wait(timeout=940)
 results.append(dict(device=device,returncode=result,end=time.time()));(b/h/'async-pieces-progress.json').write_text(json.dumps(results,indent=2))
 if result:break
