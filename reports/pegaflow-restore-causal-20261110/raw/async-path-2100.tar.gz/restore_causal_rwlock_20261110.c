#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static Batch batch;
static int (*read_real)(pthread_rwlock_t*),(*write_real)(pthread_rwlock_t*),(*unlock_real)(pthread_rwlock_t*);
static int fd=-1;
static __thread uint64_t reads,writes,sampled,total_wait,max_wait;
static __thread int inside;
static __thread struct {pthread_rwlock_t *lock;uintptr_t caller;uint64_t start,end;int writer;uint32_t state_readers,state_writers;} pending;
static uint64_t stamp(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
__attribute__((constructor)) static void init(void){
 batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");
 read_real=(int(*)(pthread_rwlock_t*))dlsym(RTLD_NEXT,"pthread_rwlock_rdlock");
 write_real=(int(*)(pthread_rwlock_t*))dlsym(RTLD_NEXT,"pthread_rwlock_wrlock");
 unlock_real=(int(*)(pthread_rwlock_t*))dlsym(RTLD_NEXT,"pthread_rwlock_unlock");
 const char *path=getenv("NATIVE_COPY_TRACE_LOG");if(path)fd=open(path,O_WRONLY|O_CREAT|O_APPEND,0600);
 if(!batch||!read_real||!write_real||!unlock_real)_Exit(125);
}
static int acquire(pthread_rwlock_t *lock,int writer,uintptr_t caller){
 int timed=writer||((reads&1023U)==0);uint64_t start=timed?stamp():0;
 uint32_t readers=timed?__atomic_load_n(&lock->__data.__readers,__ATOMIC_RELAXED):0;
 uint32_t writers=timed?__atomic_load_n(&lock->__data.__writers,__ATOMIC_RELAXED):0;
 int result=writer?write_real(lock):read_real(lock);uint64_t end=timed?stamp():0;
 if(writer)writes++;else reads++;
 if(timed){uint64_t elapsed=end-start;sampled++;total_wait+=elapsed;if(elapsed>max_wait)max_wait=elapsed;
  if(elapsed>250000){pending.lock=lock;pending.caller=caller;pending.start=start;pending.end=end;pending.writer=writer;pending.state_readers=readers;pending.state_writers=writers;}}
 return result;
}
int pthread_rwlock_rdlock(pthread_rwlock_t *lock){if(!read_real)read_real=dlsym(RTLD_NEXT,"pthread_rwlock_rdlock");return acquire(lock,0,(uintptr_t)__builtin_return_address(0));}
int pthread_rwlock_wrlock(pthread_rwlock_t *lock){if(!write_real)write_real=dlsym(RTLD_NEXT,"pthread_rwlock_wrlock");return acquire(lock,1,(uintptr_t)__builtin_return_address(0));}
int pthread_rwlock_unlock(pthread_rwlock_t *lock){
 if(!unlock_real)unlock_real=dlsym(RTLD_NEXT,"pthread_rwlock_unlock");int result=unlock_real(lock);
 if(pending.lock==lock&&fd>=0){char line[640];int n=snprintf(line,sizeof(line),"{\"event\":\"rw_slow_wait\",\"tid\":%ld,\"inside_batch\":%d,\"writer\":%d,\"lock\":\"%p\",\"caller\":\"0x%lx\",\"start_ns\":%llu,\"end_ns\":%llu,\"state_readers\":%u,\"state_writers\":%u}\n",syscall(SYS_gettid),inside,pending.writer,(void*)lock,(unsigned long)pending.caller,(unsigned long long)pending.start,(unsigned long long)pending.end,pending.state_readers,pending.state_writers);pending.lock=NULL;if(n>0&&(size_t)n<sizeof(line))write(fd,line,n);}
 return result;
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
 aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream){
 uint64_t r=reads,w=writes,s=sampled,t=total_wait;max_wait=0;inside++;
 uint64_t start=stamp();aclError result=batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);uint64_t end=stamp();inside--;
 if(fd>=0){char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"rw_batch\",\"tid\":%ld,\"count\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"reads\":%llu,\"writes\":%llu,\"samples\":%llu,\"sample_wait_ns\":%llu,\"max_sample_wait_ns\":%llu}\n",syscall(SYS_gettid),count,(unsigned long long)start,(unsigned long long)end,(unsigned long long)(reads-r),(unsigned long long)(writes-w),(unsigned long long)(sampled-s),(unsigned long long)(total_wait-t),(unsigned long long)max_wait);if(n>0&&(size_t)n<sizeof(line))write(fd,line,n);}
 return result;
}
