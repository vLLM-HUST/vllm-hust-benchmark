#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <unistd.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
    alarm(900);
    int device=argc>1?atoi(argv[1]):1;
    size_t block=65536,planes=64,count=256,capacity=512,bytes=block*planes*count;
    void *original=NULL,*packed=NULL,*alias=NULL,*dest=NULL,*readback=NULL; aclrtStream stream=NULL;
    CHECK(aclInit(NULL)); CHECK(aclrtSetDevice(device));
    original=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    packed=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(original==MAP_FAILED||packed==MAP_FAILED)return 2;
    memset(original,0x5a,bytes); memset(packed,0,bytes);
    for(size_t i=0;i<count;i++)for(size_t p=0;p<planes;p++)*(uint64_t*)((char*)original+(i*planes+p)*block)=((uint64_t)p<<32)|i;
    CHECK(aclrtHostRegister(original,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
    CHECK(aclrtHostRegister(packed,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
    CHECK(aclrtMalloc(&dest,bytes*2,ACL_MEM_MALLOC_HUGE_FIRST)); CHECK(aclrtCreateStream(&stream));
    void *sources[512],*targets[512]; size_t sizes[512],maximum[512];
    readback=malloc(bytes*2);if(!readback)return 2;
    for(int repeat=0;repeat<8;repeat++) {
        for(size_t i=0;i<count;i++)for(size_t p=0;p<planes;p++)*(uint64_t*)((char*)original+(i*planes+p)*block)=((uint64_t)p<<32)|((uint64_t)(repeat+1)<<16)|i;
        int mode=repeat%2;uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
        if(mode)for(size_t p=0;p<planes;p++)for(size_t j=0;j<count;j++)
            memcpy((char*)packed+(p*count+j)*block,(char*)original+((count-1-j)*planes+p)*block,block);
        uint64_t prepared=ns(CLOCK_MONOTONIC);
        if(mode) {
            for(size_t p=0;p<planes;p++)
                CHECK(aclrtMemcpyAsync((char*)dest+(p*capacity+256)*block,count*block,(char*)packed+p*count*block,count*block,ACL_MEMCPY_HOST_TO_DEVICE,stream));
        } else {
            aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=ACL_MEM_LOCATION_TYPE_HOST;attr.dstLoc.type=ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=device;
            size_t index=0,failed=0;
            for(size_t offset=0;offset<count*planes;offset+=512) {
                for(size_t j=0;j<512;j++) { size_t i=(offset+j)/planes,p=(offset+j)%planes;
                    sources[j]=(char*)original+(i*planes+p)*block;targets[j]=(char*)dest+(p*capacity+256+count-1-i)*block;sizes[j]=maximum[j]=block;
                }
                CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,512,&attr,&index,1,&failed,stream));
            }
        }
        uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));
        uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
        printf("{\"repeat\":%d,\"packed\":%d,\"bytes\":%zu,\"descriptors\":%zu,\"pack_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",repeat,mode,bytes,mode?planes:planes*count,(unsigned long long)(prepared-start),(unsigned long long)(submitted-prepared),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu));fflush(stdout);
        CHECK(aclrtMemcpy(readback,bytes*2,dest,bytes*2,ACL_MEMCPY_DEVICE_TO_HOST));
        for(size_t p=0;p<planes;p++)for(size_t i=0;i<count;i++) {
            uint64_t *sample=(uint64_t*)((char*)readback+(p*capacity+256+count-1-i)*block);
            if(sample[0]!=(((uint64_t)p<<32)|((uint64_t)(repeat+1)<<16)|i)||sample[1]!=0x5a5a5a5a5a5a5a5aULL)return 3;
        }
        fprintf(stderr,"verified repeat=%d tags=%zu\n",repeat,planes*count);

    }
    CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(original));CHECK(aclrtHostUnregister(packed));
    free(readback);munmap(original,bytes);munmap(packed,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
