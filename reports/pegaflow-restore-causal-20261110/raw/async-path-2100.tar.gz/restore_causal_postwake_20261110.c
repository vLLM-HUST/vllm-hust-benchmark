#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <errno.h>
#include <link.h>
#include <pthread.h>
#include <sched.h>
#include <semaphore.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static Batch batch;
static int (*value_real)(sem_t*,int*);
static int (*post_real)(sem_t*);
static __thread sem_t *pending_post;
static __thread uint64_t posts;
static uintptr_t runtime_base;
static int supported;
static pthread_once_t once=PTHREAD_ONCE_INIT;
static __thread int inside,mode;
static __thread uint64_t queries,zero,one,above_one,pauses,pause_ns;
static uint64_t stamp(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static int find(struct dl_phdr_info *i,size_t size,void *p) {(void)size;(void)p;if(strstr(i->dlpi_name,"libruntime_v100.so"))runtime_base=i->dlpi_addr;return 0;}
static void locate(void) {
    dl_iterate_phdr(find,NULL);
    if(runtime_base)supported=(*(uint32_t*)(runtime_base+0x2c9110)==0x97f5e4a8U && *(uint32_t*)(runtime_base+0x2c9114)==0xb94027a0U && *(uint32_t*)(runtime_base+0x2c9118)==0x7100041fU);
}
__attribute__((constructor)) static void init(void) {
    batch=(Batch)dlsym(RTLD_NEXT,"aclrtMemcpyBatchAsync");value_real=(int(*)(sem_t*,int*))dlsym(RTLD_NEXT,"sem_getvalue");post_real=(int(*)(sem_t*))dlsym(RTLD_NEXT,"sem_post");if(!batch||!value_real||!post_real)_exit(125);
}
static void pause_now(void) {
 if(!mode||(queries&63U))return;
 int saved=errno;uint64_t start=stamp();
 if(mode==1)sched_yield();
 else {
  long slack=prctl(PR_GET_TIMERSLACK,0,0,0,0);int changed=slack>0&&prctl(PR_SET_TIMERSLACK,1UL,0,0,0)==0;
  struct timespec delay={0,mode==2?20000:100000};nanosleep(&delay,NULL);
  if(changed)prctl(PR_SET_TIMERSLACK,(unsigned long)slack,0,0,0);
 }
 pauses++;pause_ns+=stamp()-start;errno=saved;
}
int sem_getvalue(sem_t *sem,int *value) {
 if(!value_real)value_real=dlsym(RTLD_NEXT,"sem_getvalue");
 int result=value_real(sem,value);
 if(inside&&!result&&supported&&(uintptr_t)__builtin_return_address(0)==runtime_base+0x2c9114) {
  queries++;zero+=*value==0;one+=*value==1;above_one+=*value>1;
  if(*value<=1)pending_post=sem;else pause_now();
 }
 return result;
}
int sem_post(sem_t *sem) {
 if(!post_real)post_real=dlsym(RTLD_NEXT,"sem_post");
 int result=post_real(sem);
 if(inside&&pending_post==sem){pending_post=NULL;posts++;if(!result)pause_now();}
 return result;
}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
    aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream) {
    pthread_once(&once,locate);int outer=!inside;
    if(outer) {
        mode=0;const char *p=getenv("NATIVE_COPY_POLICY");if(p){int fd=open(p,O_RDONLY);if(fd>=0){if(read(fd,&mode,sizeof(mode))!=sizeof(mode))mode=0;close(fd);}}
        if(mode<0||mode>3||(mode&&!supported))_exit(126);queries=zero=one=above_one=pauses=pause_ns=posts=0;pending_post=NULL;
    }
    inside++;uint64_t start=stamp();aclError result=batch(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);uint64_t end=stamp();inside--;
    if(outer) {
        const char *p=getenv("NATIVE_COPY_TRACE_LOG");if(p){int fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);if(fd>=0){char line[640];int n=snprintf(line,sizeof(line),"{\"event\":\"postwake_backoff\",\"tid\":%ld,\"mode\":%d,\"supported\":%d,\"count\":%zu,\"start_ns\":%llu,\"end_ns\":%llu,\"queries\":%llu,\"zero\":%llu,\"one\":%llu,\"above_one\":%llu,\"pauses\":%llu,\"pause_wall_ns\":%llu}\n",syscall(SYS_gettid),mode,supported,count,(unsigned long long)start,(unsigned long long)end,(unsigned long long)queries,(unsigned long long)zero,(unsigned long long)one,(unsigned long long)above_one,(unsigned long long)pauses,(unsigned long long)pause_ns);if(n>0&&(size_t)n<sizeof(line))write(fd,line,n);close(fd);}}
    }
    return result;
}
