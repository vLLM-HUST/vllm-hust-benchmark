#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
static uint64_t stamp(clockid_t k){struct timespec t;clock_gettime(k,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
static void *symbol(const char *name){void *p=dlsym(RTLD_NEXT,name);if(!p)_Exit(125);return p;}
aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
 aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream){
 int mode=0;const char *p=getenv("NATIVE_COPY_POLICY");if(p){int f=open(p,O_RDONLY);if(f>=0){if(read(f,&mode,sizeof(mode))!=sizeof(mode))mode=0;close(f);}}
 int h2d=attr&&indices&&nattr==1&&indices[0]==0&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
 if(!h2d||mode==0)return ((Batch)symbol("aclrtMemcpyBatchAsync"))(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);
 if(mode!=21&&mode!=22)_Exit(126);
 typedef aclError(*Sync)(aclrtStream);typedef aclError(*Copy)(void*,size_t,const void*,size_t,aclrtMemcpyKind);
 Sync sync=(Sync)symbol("aclrtSynchronizeStream");Copy copy=(Copy)symbol("aclrtMemcpy");
 typedef aclError(*Async)(void*,size_t,const void*,size_t,aclrtMemcpyKind,aclrtStream);Async async=(Async)symbol("aclrtMemcpyAsync");
 uint64_t epoch=stamp(CLOCK_REALTIME),start=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID);aclError result=mode==21?sync(stream):0;size_t bytes=0,completed=0;
 for(size_t i=0;i<count&&!result;i++){result=mode==21?copy(dst[i],maximum[i],src[i],sizes[i],ACL_MEMCPY_HOST_TO_DEVICE):async(dst[i],maximum[i],src[i],sizes[i],ACL_MEMCPY_HOST_TO_DEVICE,stream);if(result){if(failed)*failed=i;}else{bytes+=sizes[i];completed++;}}
 uint64_t end=stamp(CLOCK_MONOTONIC),cpu_end=stamp(CLOCK_THREAD_CPUTIME_ID);
 p=getenv("NATIVE_COPY_TRACE_LOG");if(p){int fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);if(fd>=0){char line[512];int n=snprintf(line,sizeof(line),"{\"event\":\"piece_api_control\",\"mode\":%d,\"tid\":%ld,\"epoch_ns\":%llu,\"count\":%zu,\"completed\":%zu,\"bytes\":%zu,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"result\":%d}\n",mode,syscall(SYS_gettid),(unsigned long long)epoch,count,completed,bytes,(unsigned long long)(end-start),(unsigned long long)(cpu_end-cpu),result);if(n>0&&(size_t)n<sizeof(line))write(fd,line,n);close(fd);}}
 return result;
}
