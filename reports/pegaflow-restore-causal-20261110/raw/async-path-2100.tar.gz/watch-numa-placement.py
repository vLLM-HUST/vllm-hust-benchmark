from pathlib import Path
import json,time,os
b=Path('/data/shared_upload/hust-zsx/restore-causal-20261110/hust-zsx-91');seen=set();deadline=time.monotonic()+600
while time.monotonic()<deadline:
 for root in b.glob('native-numa-*-device*'):
  if root.name in seen or not (root/'affinity-stages.jsonl').exists():continue
  p=root/'native-process.json'
  if not p.exists():continue
  pid=json.loads(p.read_text())['pid'];proc=Path('/proc')/str(pid)
  try:
   if 'pegaflow-server' not in (proc/'comm').read_text():continue
   (root/'verified-native-numa-maps.txt').write_text((proc/'numa_maps').read_text())
   (root/'verified-native-status.txt').write_text((proc/'status').read_text())
   tasks=[]
   for task in (proc/'task').iterdir():
    try:tasks.append(dict(tid=int(task.name),name=(task/'comm').read_text().strip(),affinity=sorted(os.sched_getaffinity(int(task.name)))))
    except OSError:pass
   (root/'verified-native-affinity.json').write_text(json.dumps(dict(pid=pid,epoch=time.time(),tasks=tasks),indent=2));seen.add(root.name)
  except OSError:pass
 progress=b/'numa-matrix-progress.json'
 if progress.exists():
  rows=json.loads(progress.read_text())
  if len(rows)==8 or (rows and rows[-1]['returncode']):break
 time.sleep(.2)
(b/'numa-placement-watch-done.json').write_text(json.dumps(dict(seen=sorted(seen),epoch=time.time())))
