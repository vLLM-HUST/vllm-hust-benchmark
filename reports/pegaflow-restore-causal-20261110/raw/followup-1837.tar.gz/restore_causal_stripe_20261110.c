#define _GNU_SOURCE
#include <acl/acl_rt.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef aclError (*Batch)(void**,size_t*,void**,size_t*,size_t,aclrtMemcpyBatchAttr*,size_t*,size_t,size_t*,aclrtStream);
typedef aclError (*Sync)(aclrtStream);
static __thread aclrtStream stripes[32],origin;
static __thread uint32_t used;
static __thread size_t submitted;
static void *symbol(const char *name) {void *p=dlsym(RTLD_NEXT,name);if(!p)_exit(125);return p;}

aclError aclrtMemcpyBatchAsync(void **dst,size_t *maximum,void **src,size_t *sizes,size_t count,
    aclrtMemcpyBatchAttr *attr,size_t *indices,size_t nattr,size_t *failed,aclrtStream stream) {
    Batch next=(Batch)symbol("aclrtMemcpyBatchAsync");
    int mode=0;const char *path=getenv("NATIVE_COPY_POLICY");
    if(path) {int fd=open(path,O_RDONLY);if(fd>=0){if(read(fd,&mode,sizeof(mode))!=sizeof(mode))mode=0;close(fd);}}
    int h2d=nattr==1&&indices&&indices[0]==0&&attr&&attr[0].srcLoc.type==ACL_MEM_LOCATION_TYPE_HOST&&attr[0].dstLoc.type==ACL_MEM_LOCATION_TYPE_DEVICE;
    if(mode==0||!h2d)return next(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stream);
    if(mode!=10&&mode!=11)_exit(127);
    Sync sync=(Sync)symbol("aclrtSynchronizeStream");
    if(!used) {aclError e=sync(stream);if(e)return e;origin=stream;submitted=0;}
    if(origin!=stream)_exit(127);
    size_t number=mode==10?16:32,index=submitted++%number;
    if(!stripes[index]) {
        typedef aclError(*Create)(aclrtStream*);
        aclError e=((Create)symbol("aclrtCreateStream"))(&stripes[index]);if(e)return e;
    }
    used|=1U<<index;
    return next(dst,maximum,src,sizes,count,attr,indices,nattr,failed,stripes[index]);
}

aclError aclrtSynchronizeStream(aclrtStream stream) {
    Sync next=(Sync)symbol("aclrtSynchronizeStream");aclError error=0;
    if(used&&origin==stream) {
        for(int i=0;i<32;i++)if(used&(1U<<i)) {aclError e=next(stripes[i]);if(e&&!error)error=e;}
        used=0;submitted=0;origin=NULL;
    }
    aclError e=next(stream);return error?error:e;
}
