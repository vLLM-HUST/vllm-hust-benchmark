import pathlib,subprocess,time,json
b=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110');r=b/'hust-zsx-81'
until=time.monotonic()+1500
while not (r/'model-stripe-device0/campaign-done.json').exists():
 if time.monotonic()>until:raise TimeoutError('Wait for completed real-model campaign before copy control')
 time.sleep(2)
with (r/'chain-control-v1.jsonl').open('w') as f,(r/'chain-control-v1.stderr').open('w') as e:
 start=time.time();result=subprocess.run(['/usr/bin/numactl','--membind=2',str(b/'chain-control'),'1'],stdout=f,stderr=e,timeout=900)
(r/'chain-control-v1-done.json').write_text(json.dumps(dict(status=result.returncode,start=start,end=time.time())))
