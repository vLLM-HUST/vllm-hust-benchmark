import pathlib,subprocess,json,time
b=pathlib.Path('/data/shared_upload/hust-zsx/restore-causal-20261110');root=b/'hust-zsx-81'
rows=[]
for repeat in range(4):
 drop=repeat%2;name=f'large-cap-{repeat}-'+('drop' if drop else 'normal')
 cmd=['/usr/bin/numactl','--membind=2',str(b/'layout-control'),'1','pinned']
 if drop:cmd=['/usr/bin/setpriv','--bounding-set=-ipc_lock']+cmd
 start=time.time()
 with (root/(name+'.jsonl')).open('w') as f,(root/(name+'.stderr')).open('w') as e:
  result=subprocess.run(cmd,stdout=f,stderr=e,timeout=240)
 rows.append(dict(command=cmd,status=result.returncode,start=start,end=time.time()))
 (root/'large-cap-progress.json').write_text(json.dumps(rows,indent=2))
