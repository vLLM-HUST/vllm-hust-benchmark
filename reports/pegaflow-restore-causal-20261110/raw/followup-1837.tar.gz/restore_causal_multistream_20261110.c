#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <unistd.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return 1; } } while(0)
int main(int argc,char **argv) {
    alarm(900);
    int device=argc>1?atoi(argv[1]):1;size_t bytes=1024UL*1024*1024,n=16384,piece=bytes/n;
    void *alias=NULL,*dest=NULL; aclrtStream streams[16]={0};
    CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));
    void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(host==MAP_FAILED)return 2;
    memset(host,0x5a,bytes);for(size_t i=0;i<n;i++)*(uint64_t*)((char*)host+i*piece)=i;
    CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
    CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));
    for(int i=0;i<16;i++)CHECK(aclrtCreateStream(&streams[i]));
    CHECK(aclrtMemcpyAsync(dest,bytes,host,bytes,ACL_MEMCPY_HOST_TO_DEVICE,streams[0]));CHECK(aclrtSynchronizeStream(streams[0]));
    void *sources[512],*targets[512];size_t sizes[512],maximum[512];int active[5]={1,2,4,8,16};
    for(int repeat=0;repeat<4;repeat++)for(int step=0;step<10;step++) {
        int v=(step*3+repeat*4)%10,direction=v%2,nsrc=active[v/2];
        aclrtMemcpyBatchAttr attr={0};attr.srcLoc.type=direction?ACL_MEM_LOCATION_TYPE_DEVICE:ACL_MEM_LOCATION_TYPE_HOST;
        attr.srcLoc.id=direction?device:0;attr.dstLoc.type=direction?ACL_MEM_LOCATION_TYPE_HOST:ACL_MEM_LOCATION_TYPE_DEVICE;attr.dstLoc.id=direction?0:device;
        size_t index=0,failed=0;uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
        for(size_t offset=0;offset<n;offset+=512) {
            for(size_t j=0;j<512;j++) {size_t pos=(offset+j)*piece;sources[j]=(char*)(direction?dest:host)+pos;targets[j]=(char*)(direction?host:dest)+pos;sizes[j]=maximum[j]=piece;}
            CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,512,&attr,&index,1,&failed,streams[(offset/512)%nsrc]));
        }
        uint64_t submitted=ns(CLOCK_MONOTONIC);for(int i=0;i<nsrc;i++)CHECK(aclrtSynchronizeStream(streams[i]));
        uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
        printf("{\"repeat\":%d,\"direction\":%d,\"streams\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",repeat,direction,nsrc,n,bytes,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu));fflush(stdout);
        for(size_t i=0;i<n;i+=8191) {uint64_t sample[8];CHECK(aclrtMemcpy(sample,sizeof(sample),(char*)dest+i*piece,sizeof(sample),ACL_MEMCPY_DEVICE_TO_HOST));if(sample[0]!=i||sample[1]!=0x5a5a5a5a5a5a5a5aULL)return 3;}
    }
    for(int i=0;i<16;i++)CHECK(aclrtDestroyStream(streams[i]));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);
    CHECK(aclrtResetDevice(device));CHECK(aclFinalize());return 0;
}
