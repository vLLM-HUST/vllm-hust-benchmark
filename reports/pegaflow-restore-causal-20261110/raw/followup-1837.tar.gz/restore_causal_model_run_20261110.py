"""Matched real-model restoration, bounded submission crossover and slow-call sampling."""
import argparse
import ctypes
import gzip
import json
from pathlib import Path
import signal
import struct
import threading
import time

import httpx

BASE=Path('/data/shared_upload/hust-zsx/restore-causal-20261110')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--host',required=True);parser.add_argument('--name',default='model-device0')
    parser.add_argument('--policies',default='0,5,0,6')
    args=parser.parse_args();root=BASE/args.host/args.name
    deadline=time.monotonic()+1500
    while not (root/'ready.json').exists():
        if time.monotonic()>deadline:raise TimeoutError('Model readiness')
        time.sleep(1)
    config=json.loads((root/'config.json').read_text());live=Path(config['live']);pid=json.loads((root/'native-process.json').read_text())['pid']
    with gzip.open('/data/shared_upload/hust-zsx/restore-card-diag-20261110/fixtures-token-ids.json.gz','rt') as stream:fixtures=json.load(stream)
    client=httpx.Client(timeout=170,trust_env=False);url=f'http://127.0.0.1:{config["http"]}'
    policy=Path(config['policy']);counter=0

    def emit(name,row):
        with (root/name).open('a') as stream:stream.write(json.dumps(row)+'\n')

    def drain():
        deadline=time.monotonic()+180
        while time.monotonic()<deadline:
            waits=[]
            for task in Path(f'/proc/{pid}/task').iterdir():
                if '-load' in (task/'comm').read_text():waits.append((task/'wchan').read_text())
            if waits and all('futex' in s for s in waits):return
            time.sleep(.5)
        raise TimeoutError('Native work has not drained; leave policy unchanged')

    def sample(stop,key):
        if stop.wait(3):return
        (root/f'{key}-maps.txt').write_text(Path(f'/proc/{pid}/maps').read_text())
        libc=ctypes.CDLL(None);send=libc.tgkill;send.argtypes=[ctypes.c_int]*3;send.restype=ctypes.c_int
        marker=dict(request=key,start_epoch_ns=time.time_ns(),native_pid=pid)
        until=time.monotonic()+8
        while time.monotonic()<until and not stop.is_set():
            for task in Path(f'/proc/{pid}/task').iterdir():
                try:
                    name=(task/'comm').read_text()
                    if '-load' in name or 'RT_RECYCLE' in name:send(pid,int(task.name),signal.SIGUSR2)
                except OSError:pass
            stop.wait(.02)
        marker['end_epoch_ns']=time.time_ns();emit('sample-windows.jsonl',marker)

    def request(index,phase,mode,reset=True,profile=False):
        nonlocal counter
        counter+=1;key=f'{args.host}-{phase}-{counter:03d}'
        drain();policy.write_bytes(struct.pack('i',mode))
        if reset:client.post(url+'/reset_prefix_cache').raise_for_status()
        stop=threading.Event();thread=None
        if profile:thread=threading.Thread(target=sample,args=(stop,key),daemon=True);thread.start()
        resource=Path('/sys/fs/cgroup/cpu.stat').read_text();start=time.monotonic();epoch=time.time_ns()
        row=dict(id=key,fixture=index,prompt_tokens=fixtures[index]['prompt_tokens'],phase=phase,policy=mode,
                 start_epoch_ns=epoch,status='running',profile_requested=profile,cpu_before=resource)
        payload=dict(model='qwen14',prompt=fixtures[index]['prompt_token_ids'],max_tokens=1,ignore_eos=True,
                     temperature=0,cache_salt=f'causal-real-fixture-{index}',request_id=key,
                     stream=True,stream_options=dict(include_usage=True))
        try:
            text=''
            with client.stream('POST',url+'/v1/completions',json=payload) as response:
                response.raise_for_status()
                for line in response.iter_lines():
                    if not line.startswith('data: ') or line=='data: [DONE]':continue
                    chunk=json.loads(line[6:])
                    if chunk.get('error'):raise RuntimeError(str(chunk['error']))
                    if chunk.get('usage'):row['usage']=chunk['usage']
                    for choice in chunk.get('choices',[]):
                        part=choice.get('text') or '';text+=part
                        if part and 'TTFT_s' not in row:row['TTFT_s']=time.monotonic()-start
            row['text']=text
            if row.get('usage',{}).get('completion_tokens')!=1:raise RuntimeError('Expected one completion token')
            row['status']='ok'
        except Exception as error:row.update(status='error',error=repr(error))
        finally:
            stop.set()
            if thread:thread.join(3)
            row.update(elapsed_s=time.monotonic()-start,end_epoch_ns=time.time_ns(),cpu_after=Path('/sys/fs/cgroup/cpu.stat').read_text())
            emit('requests.jsonl',row);print(json.dumps({k:row[k] for k in ['id','policy','prompt_tokens','status','elapsed_s']}),flush=True)
        # Draining is mandatory before the next policy, including failed HTTP requests.
        drain();return row

    for index in range(4):
        if request(index,'seed',0,reset=False)['status']!='ok':raise RuntimeError('Fixture seed failed')
    for stage,mode in enumerate([int(s) for s in args.policies.split(',')]):
        for index in ([0,2] if stage%2==0 else [2,0]):
            request(index,f'stage-{stage}',mode,profile=stage==0 and index==2)
    policy.write_bytes(struct.pack('i',0))
    (root/'campaign-done.json').write_text(json.dumps(dict(epoch=time.time(),requests=counter)))


if __name__=='__main__':
    try:main()
    except BaseException as error:
        import traceback
        print(traceback.format_exc(),flush=True)
        raise
