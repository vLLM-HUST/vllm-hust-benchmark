#define _GNU_SOURCE
#include <acl/acl.h>
#include <acl/acl_rt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>

static uint64_t ns(clockid_t c) { struct timespec t; clock_gettime(c,&t); return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec; }
#define CHECK(x) do { int e=(x); if(e) { fprintf(stderr,"%s=%d\n",#x,e); return e; } } while(0)
int measure(int device, void **planes, const char *phase) {
    size_t block=262144,nplanes=96,count=161,bytes=block*nplanes*count;
    void *alias=NULL; aclrtStream stream=NULL; CHECK(aclrtSetDevice(device));
    void *host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(host==MAP_FAILED)return 2;
    memset(host,0x5a,bytes); CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias)); CHECK(aclrtCreateStream(&stream));
    void *sources[512],*targets[512]; size_t sizes[512],maximum[512];
    for(int repeat=0;repeat<6;repeat++) {
        int direction=repeat%2; aclrtMemcpyBatchAttr attr={0}; attr.srcLoc.type=direction?ACL_MEM_LOCATION_TYPE_DEVICE:ACL_MEM_LOCATION_TYPE_HOST;
        attr.srcLoc.id=direction?device:0; attr.dstLoc.type=direction?ACL_MEM_LOCATION_TYPE_HOST:ACL_MEM_LOCATION_TYPE_DEVICE; attr.dstLoc.id=direction?0:device;
        size_t index=0,failed=0; uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
        for(size_t offset=0;offset<count*nplanes;offset+=512) {
            size_t batch=count*nplanes-offset; if(batch>512)batch=512;
            for(size_t j=0;j<batch;j++) {
                size_t i=(offset+j)/nplanes,p=(offset+j)%nplanes;
                void *h=(char*)host+(i*nplanes+p)*block;
                void *d=(char*)planes[p]+(256+count-1-i)*block;
                sources[j]=direction?d:h; targets[j]=direction?h:d; sizes[j]=maximum[j]=block;
            }
            CHECK(aclrtMemcpyBatchAsync(targets,maximum,sources,sizes,batch,&attr,&index,1,&failed,stream));
        }
        uint64_t submitted=ns(CLOCK_MONOTONIC); CHECK(aclrtSynchronizeStream(stream));
        uint64_t end=ns(CLOCK_MONOTONIC),cpudone=ns(CLOCK_THREAD_CPUTIME_ID);
        printf("{\"phase\":\"%s\",\"repeat\":%d,\"direction\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",phase,repeat,direction,count*nplanes,bytes,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpudone-cpu)); fflush(stdout);
        for(size_t p=0;p<96;p+=95) {
            unsigned char sample[64]; CHECK(aclrtMemcpy(sample,64,(char*)planes[p]+256*block,64,ACL_MEMCPY_DEVICE_TO_HOST)); for(int j=0;j<64;j++)if(sample[j]!=0x5a)return 3;
        }
        for(int j=0;j<64;j++)if(((unsigned char*)host)[j]!=0x5a)return 3;
    }
    CHECK(aclrtDestroyStream(stream)); CHECK(aclrtHostUnregister(host)); munmap(host,bytes); return 0;
}
