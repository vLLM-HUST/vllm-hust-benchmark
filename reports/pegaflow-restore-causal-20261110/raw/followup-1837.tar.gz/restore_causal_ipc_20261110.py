"""Compare identical tensor destinations before, during and after IPC import."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import pickle
import subprocess
import sys

BASE = Path('/data/shared_upload/hust-zsx/restore-causal-20261110')
SOURCE = '/data/shared_upload/hust-zsx/long-pd-20261109/source/python'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', required=True)
    parser.add_argument('--device', type=int, default=1)
    parser.add_argument('--child', action='store_true')
    args = parser.parse_args()
    root = BASE / args.host / 'isolated-ipc-v1'
    root.mkdir(exist_ok=True)
    sys.path.insert(0, SOURCE)
    import torch
    import torch_npu
    from pegaflow.npu_ipc_wrapper import NpuIPCWrapper
    torch.set_num_threads(1)
    torch.npu.set_device(args.device)
    lib = ctypes.CDLL(str(BASE / 'borrowed-control.so'))
    lib.measure.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_void_p), ctypes.c_char_p]
    lib.measure.restype = ctypes.c_int

    def measure(tensors, phase):
        pointers = (ctypes.c_void_p * len(tensors))(*(t.data_ptr() for t in tensors))
        status = lib.measure(args.device, pointers, phase.encode())
        if status:
            raise RuntimeError(f'{phase}: CANN control returned {status}')

    if args.child:
        wrappers = pickle.loads((root / 'handles.pkl').read_bytes())
        tensors = [w.to_tensor() for w in wrappers]
        torch.npu.synchronize()
        measure(tensors, 'imported-child')
    else:
        tensors = [torch.full((512, 131072), .25, dtype=torch.bfloat16,
                              device=f'npu:{args.device}') for _ in range(96)]
        torch.npu.synchronize()
        measure(tensors, 'owner-before')
        wrappers = [NpuIPCWrapper(t) for t in tensors]
        (root / 'handles.pkl').write_bytes(pickle.dumps(wrappers))
        env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
        command = [sys.executable, str(Path(__file__)), '--host', args.host,
                   '--device', str(args.device), '--child']
        status = subprocess.run(command, env=env, timeout=600).returncode
        if status:
            raise RuntimeError(f'IPC child exited {status}')
        measure(tensors, 'owner-after')
        (root / 'done.json').write_text(json.dumps(dict(status='ok', device=args.device)))


if __name__ == '__main__':
    main()
