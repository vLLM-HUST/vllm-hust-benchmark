/* Installed public HAL: measure address/DMA preparation and destruction, no payload copy. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <ascend_hal.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char**argv){
 alarm(180);int device=argc>1?atoi(argv[1]):1;size_t count=4096,piece=262144,bytes=count*piece;
 void*host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*dest=NULL;
 if(host==MAP_FAILED)return 2;memset(host,0x5a,bytes);
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtMemset(dest,bytes,0,bytes));
 typedef DVresult(*Convert)(DVdeviceptr,DVdeviceptr,UINT32,struct DMA_ADDR*);
 typedef DVresult(*Destroy)(struct DMA_ADDR*);
 Convert convert=(Convert)dlsym(RTLD_DEFAULT,"drvMemConvertAddr");Destroy destroy=(Destroy)dlsym(RTLD_DEFAULT,"drvMemDestroyAddr");if(!convert||!destroy)return 3;
 struct DMA_ADDR*descriptors=calloc(count,sizeof(*descriptors));if(!descriptors)return 8;
 int windows[6]={1,32,2048,2048,32,1};
 for(int trial=0;trial<6;trial++){
  size_t window=windows[trial];uint64_t sum_create=0,sum_destroy=0,max_create=0,max_destroy=0,begin=ns();
  printf("{\"event\":\"prepare_begin\",\"trial\":%d,\"window\":%zu,\"start_ns\":%llu}\n",trial,window,(unsigned long long)begin);fflush(stdout);
  for(size_t offset=0;offset<count;offset+=window){
   size_t take=count-offset;if(take>window)take=window;
   for(size_t j=0;j<take;j++){
    size_t i=offset+j;struct DMA_ADDR*d=&descriptors[i];memset(d,0,sizeof(*d));d->offsetAddr.devid=device;
    uint64_t a=ns();int e=convert((DVdeviceptr)(uintptr_t)((char*)host+i*piece),(DVdeviceptr)(uintptr_t)((char*)dest+i*piece),(UINT32)piece,d);uint64_t b=ns();
    if(e){printf("{\"event\":\"convert_error\",\"trial\":%d,\"index\":%zu,\"error\":%d}\n",trial,i,e);fflush(stdout);return 4;}
    if(d->fixed_size!=piece){fprintf(stderr,"partial conversion %u/%zu\n",d->fixed_size,piece);return 6;}
    uint64_t duration=b-a;sum_create+=duration;if(duration>max_create)max_create=duration;
   }
   for(size_t j=0;j<take;j++){
    size_t i=offset+j;uint64_t a=ns();int e=destroy(&descriptors[i]);uint64_t b=ns();
    if(e){fprintf(stderr,"destroy=%d\n",e);return 5;}
    uint64_t duration=b-a;sum_destroy+=duration;if(duration>max_destroy)max_destroy=duration;
   }
   if((offset+take)%128==0){printf("{\"event\":\"progress\",\"trial\":%d,\"count\":%zu,\"create_ns\":%llu,\"destroy_ns\":%llu}\n",trial,offset+take,(unsigned long long)sum_create,(unsigned long long)sum_destroy);fflush(stdout);}
  }
  uint64_t end=ns();
  for(int j=0;j<8;j++){uint64_t value=1;size_t block=(size_t)j*(count-1)/7;CHECK(aclrtMemcpy(&value,8,(char*)dest+block*piece,8,ACL_MEMCPY_DEVICE_TO_HOST));if(value){fprintf(stderr,"preparation changed destination\n");return 7;}}
  printf("{\"event\":\"prepare_destroy\",\"trial\":%d,\"window\":%zu,\"device_input\":%d,\"descriptors\":%zu,\"bytes_prepared\":%zu,\"payload_copied\":0,\"verified_unchanged_tags\":8,\"start_ns\":%llu,\"end_ns\":%llu,\"create_ns\":%llu,\"destroy_ns\":%llu,\"max_create_ns\":%llu,\"max_destroy_ns\":%llu,\"wall_ns\":%llu}\n",trial,window,device,count,bytes,(unsigned long long)begin,(unsigned long long)end,(unsigned long long)sum_create,(unsigned long long)sum_destroy,(unsigned long long)max_create,(unsigned long long)max_destroy,(unsigned long long)(end-begin));fflush(stdout);
 }
 free(descriptors);
 CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());puts("{\"event\":\"completed\",\"cases\":6}");return 0;
}
