#include <acl/acl.h>
#include <ascend_hal.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc,char**argv){alarm(30);int device=atoi(argv[1]);void*raw=0,*alias=0;size_t bytes=16UL<<20;int init=aclInit(0),set=aclrtSetDevice(device),alloc=aclrtMallocHost(&raw,bytes+4096);if(init||set||alloc)return 2;void*src=(void*)(((uintptr_t)raw+4095)&~(uintptr_t)4095);typedef drvError_t(*Reg)(void*,UINT64,UINT32,UINT32,void**);typedef drvError_t(*Unreg)(void*,UINT32);Reg reg=(Reg)dlsym(RTLD_DEFAULT,"halHostRegister");Unreg unreg=(Unreg)dlsym(RTLD_DEFAULT,"halHostUnregister");if(!reg||!unreg)return 3;int e=reg(src,bytes,HOST_MEM_MAP_DMA,device,&alias);printf("{\"device\":%d,\"register_result\":%d,\"source_alignment\":%lu,\"flag\":%u}\n",device,e,(unsigned long)((uintptr_t)src%4096),HOST_MEM_MAP_DMA);fflush(stdout);if(!e){int u=unreg(src,device);printf("{\"unregister_result\":%d}\n",u);fflush(stdout);if(u)return 4;}int f=aclrtFreeHost(raw);aclrtResetDevice(device);aclFinalize();return f?5:0;}
