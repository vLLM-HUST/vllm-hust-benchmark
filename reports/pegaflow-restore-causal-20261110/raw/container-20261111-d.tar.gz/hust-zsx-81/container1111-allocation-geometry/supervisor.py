"""Observe the finite owned test and its newly allocated driver channels."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

output, binary, device, physical, numa, preload = sys.argv[1:]
out = Path(output)
channel_root = Path(f'/proc/trs_chan/dev{physical}-ts0')
before = {p.name for p in channel_root.glob('*-rts')}
stat = Path('/sys/fs/cgroup/cpu.stat')
(out / 'wrapper-start.json').write_text(json.dumps({
    'begin_epoch': time.time(), 'cpu_stat_before': stat.read_text()}))
command = ['numactl', '--cpunodebind=' + numa, '--membind=' + numa, binary, device]
with (out / 'results.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    child = subprocess.Popen(
        command, stdout=stdout, stderr=stderr,
        env=dict(os.environ, LD_PRELOAD=preload,
                 NATIVE_COPY_TRACE_LOG=str(out / 'api.jsonl')))
    (out / 'child.json').write_text(json.dumps({'pid': child.pid, 'command': command,
                                              'begin_epoch': time.time()}))
    with (out / 'kernel-queue.jsonl').open('w') as stream:
        while child.poll() is None:
            row = dict(begin_ns=time.monotonic_ns(), epoch_ns=time.time_ns(), files={})
            for path in channel_root.glob('*-rts'):
                if path.name in before:
                    continue
                begin = time.monotonic_ns()
                try:
                    text = path.read_text()
                except OSError:
                    continue
                row['files'][str(path)] = dict(begin_ns=begin, end_ns=time.monotonic_ns(),
                                               text=text)
            row['cpu_stat'] = stat.read_text()
            stream.write(json.dumps(row) + '\n')
            stream.flush()
            time.sleep(1)
    status = child.wait()
(out / 'exit.json').write_text(json.dumps({
    'exit_code': status, 'end_epoch': time.time(), 'cpu_stat_after': stat.read_text()}))
