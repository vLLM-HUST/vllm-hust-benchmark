/* Equal payload/tasks: contiguous target, strided views, or 96 allocations. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
static void*target(void*big,void**planes,size_t index,int mode){size_t piece=262144,plane=index/161,block=index%161;if(!mode)return(char*)big+index*piece;if(mode==1)return(char*)big+(plane*512+256+block)*piece;return(char*)planes[plane]+(256+block)*piece;}
int main(int argc,char**argv){
 alarm(240);int device=argc>1?atoi(argv[1]):1;size_t n=96*161,piece=262144,host_bytes=5UL<<30,plane_bytes=512*piece;
 void*host=mmap(NULL,host_bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*big=NULL,*planes[96]={0};aclrtStream stream=NULL;
 if(host==MAP_FAILED)return 2;memset(host,0x5a,host_bytes);
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtHostRegister(host,host_bytes,ACL_HOST_REGISTER_MAPPED,&alias));
 CHECK(aclrtMalloc(&big,96*plane_bytes,ACL_MEM_MALLOC_HUGE_FIRST));
 for(int p=0;p<96;p++)CHECK(aclrtMalloc(&planes[p],plane_bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 int plan[9]={0,1,2,2,1,0,0,1,2};
 for(int trial=0;trial<9;trial++){
  int mode=plan[trial];uint64_t tag=20000+trial*100;
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;*(uint64_t*)((char*)host+block*piece)=tag+block;CHECK(aclrtMemsetAsync(target(big,planes,block,mode),8,0,8,stream));}
  CHECK(aclrtSynchronizeStream(stream));uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  printf("{\"event\":\"copy_begin\",\"trial\":%d,\"mode\":%d,\"start_ns\":%llu,\"epoch_ns\":%llu}\n",trial,mode,(unsigned long long)start,(unsigned long long)ns(CLOCK_REALTIME));fflush(stdout);
  for(size_t i=0;i<n;i++)CHECK(aclrtMemcpyAsync(target(big,planes,i,mode),piece,(char*)host+i*piece,piece,ACL_MEMCPY_HOST_TO_DEVICE,stream));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC),cpu_end=ns(CLOCK_THREAD_CPUTIME_ID);
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;uint64_t actual=0;CHECK(aclrtMemcpy(&actual,8,target(big,planes,block,mode),8,ACL_MEMCPY_DEVICE_TO_HOST));if(actual!=tag+block){fprintf(stderr,"tag mismatch\n");return 3;}}
  printf("{\"event\":\"copy\",\"trial\":%d,\"mode\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"verified_tags\":8,\"start_ns\":%llu,\"end_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"thread_cpu_ns\":%llu}\n",trial,mode,n,n*piece,(unsigned long long)start,(unsigned long long)end,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpu_end-cpu));fflush(stdout);
 }
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(big));for(int p=0;p<96;p++)CHECK(aclrtFree(planes[p]));CHECK(aclrtHostUnregister(host));munmap(host,host_bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());puts("{\"event\":\"completed\",\"cases\":9}");return 0;
}
