/* Compare per-copy DMA preparation with reused prepared addresses, same sync transport. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <ascend_hal.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char**argv){
 alarm(180);int device=argc>1?atoi(argv[1]):1;size_t n=4096,piece=262144,bytes=n*piece;
 void*host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*dest=NULL;
 if(host==MAP_FAILED)return 2;memset(host,0x5a,bytes);
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));
 typedef DVresult(*Convert)(DVdeviceptr,DVdeviceptr,UINT32,struct DMA_ADDR*);typedef DVresult(*Destroy)(struct DMA_ADDR*);typedef DVresult(*Submit)(struct DMA_ADDR*,int);
 Convert convert=(Convert)dlsym(RTLD_DEFAULT,"drvMemConvertAddr");Destroy destroy=(Destroy)dlsym(RTLD_DEFAULT,"drvMemDestroyAddr");Submit submit=(Submit)dlsym(RTLD_DEFAULT,"halMemcpySumbit");if(!convert||!destroy||!submit)return 3;
 struct DMA_ADDR*cached=calloc(n,sizeof(*cached));if(!cached)return 8;
 for(int trial=0;trial<4;trial++){
  int reuse=trial==1||trial==2;
  if(trial==1){uint64_t start=ns();for(size_t i=0;i<n;i++){cached[i].offsetAddr.devid=device;CHECK(convert((DVdeviceptr)(uintptr_t)((char*)host+i*piece),(DVdeviceptr)(uintptr_t)((char*)dest+i*piece),piece,&cached[i]));if(cached[i].fixed_size!=piece)return 6;}printf("{\"event\":\"cache_prepare\",\"descriptors\":%zu,\"wall_ns\":%llu}\n",n,(unsigned long long)(ns()-start));fflush(stdout);}
  if(trial==3){uint64_t start=ns();for(size_t i=0;i<n;i++)CHECK(destroy(&cached[i]));printf("{\"event\":\"cache_destroy\",\"descriptors\":%zu,\"wall_ns\":%llu}\n",n,(unsigned long long)(ns()-start));fflush(stdout);}
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;CHECK(aclrtMemset((char*)dest+block*piece,8,0,8));}
  uint64_t begin=ns(),sum_create=0,sum_submit=0,sum_destroy=0,max_submit=0;
  printf("{\"event\":\"copy_begin\",\"trial\":%d,\"reuse\":%d,\"start_ns\":%llu}\n",trial,reuse,(unsigned long long)begin);fflush(stdout);
  for(size_t i=0;i<n;i++){
   struct DMA_ADDR fresh={0};struct DMA_ADDR*d=reuse?&cached[i]:&fresh;
   if(!reuse){d->offsetAddr.devid=device;uint64_t a=ns();CHECK(convert((DVdeviceptr)(uintptr_t)((char*)host+i*piece),(DVdeviceptr)(uintptr_t)((char*)dest+i*piece),piece,d));sum_create+=ns()-a;if(d->fixed_size!=piece)return 6;}
   uint64_t a=ns();int status=submit(d,MEMCPY_SUMBIT_SYNC);uint64_t duration=ns()-a;
   if(status){printf("{\"event\":\"submit_error\",\"trial\":%d,\"index\":%zu,\"error\":%d}\n",trial,i,status);fflush(stdout);return 4;}sum_submit+=duration;if(duration>max_submit)max_submit=duration;
   if(!reuse){a=ns();CHECK(destroy(d));sum_destroy+=ns()-a;}
   if(i%512==511){printf("{\"event\":\"progress\",\"trial\":%d,\"count\":%zu,\"submit_ns\":%llu}\n",trial,i+1,(unsigned long long)sum_submit);fflush(stdout);}
  }
  uint64_t end=ns();
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;uint64_t value=0;CHECK(aclrtMemcpy(&value,8,(char*)dest+block*piece,8,ACL_MEMCPY_DEVICE_TO_HOST));if(value!=0x5a5a5a5a5a5a5a5aULL){fprintf(stderr,"copy verification failed\n");return 5;}}
  printf("{\"event\":\"copy\",\"trial\":%d,\"reuse\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"verified_tags\":8,\"start_ns\":%llu,\"end_ns\":%llu,\"create_ns\":%llu,\"submit_ns\":%llu,\"destroy_ns\":%llu,\"max_submit_ns\":%llu,\"wall_ns\":%llu}\n",trial,reuse,n,bytes,(unsigned long long)begin,(unsigned long long)end,(unsigned long long)sum_create,(unsigned long long)sum_submit,(unsigned long long)sum_destroy,(unsigned long long)max_submit,(unsigned long long)(end-begin));fflush(stdout);
 }
 free(cached);CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());puts("{\"event\":\"completed\",\"cases\":4}");return 0;
}
