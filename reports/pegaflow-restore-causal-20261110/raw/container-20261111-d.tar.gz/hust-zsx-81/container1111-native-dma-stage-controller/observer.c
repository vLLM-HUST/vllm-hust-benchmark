/* Read-only timing and eight-byte task-header metadata at the installed HAL ABI. */
#define _GNU_SOURCE
#include <ascend_hal.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
static int fd=-1;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
__attribute__((constructor))static void init(void){const char*p=getenv("NATIVE_COPY_TRACE_LOG");if(p)fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);}
drvError_t halSqTaskSend(uint32_t device,struct halTaskSendInfo *info){
 typedef drvError_t(*Fn)(uint32_t,struct halTaskSendInfo*);static Fn fn;
 if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"halSqTaskSend");if(!fn)_Exit(125);
 unsigned char h[8]={0};int valid=info&&info->sqe_addr&&info->sqe_num;
 if(valid)memcpy(h,info->sqe_addr,8);
 uint16_t stream=0,task=0;memcpy(&stream,h+4,2);memcpy(&task,h+6,2);
 uint64_t start=ns();drvError_t error=fn(device,info);uint64_t end=ns();
 if(fd>=0){char line[700];int n=snprintf(line,sizeof(line),"{\"event\":\"hal_send\",\"kind\":\"task\",\"start_ns\":%llu,\"end_ns\":%llu,\"device\":%u,\"sq\":%u,\"count\":%u,\"position\":%u,\"error\":%d,\"tid\":%ld,\"header8_valid\":%d,\"sqe_type6\":%u,\"flags8\":%u,\"stream_id16\":%u,\"task_id16\":%u}\n",(unsigned long long)start,(unsigned long long)end,device,info->sqId,info->sqe_num,info->pos,error,syscall(SYS_gettid),valid,h[0]&63,h[1],stream,task);write(fd,line,n);}
 return error;
}

/* Append to task-header observer: transparent public HAL preparation/release timing. */
static __thread unsigned dma_depth=0;
static void emit_dma(const char*api,uint64_t a,uint64_t b,uint32_t device,uint32_t sq,uint32_t count,uint64_t bytes,int error,unsigned depth){
 if(fd<0)return;char line[600];int n=snprintf(line,sizeof(line),"{\"event\":\"dma_stage\",\"api\":\"%s\",\"start_ns\":%llu,\"end_ns\":%llu,\"device\":%u,\"sq\":%u,\"count\":%u,\"bytes\":%llu,\"error\":%d,\"depth\":%u,\"tid\":%ld}\n",api,(unsigned long long)a,(unsigned long long)b,device,sq,count,(unsigned long long)bytes,error,depth,syscall(SYS_gettid));write(fd,line,n);
}
DVresult drvMemConvertAddr(DVdeviceptr src,DVdeviceptr dst,UINT32 len,struct DMA_ADDR*out){
 typedef DVresult(*Fn)(DVdeviceptr,DVdeviceptr,UINT32,struct DMA_ADDR*);static Fn fn;if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"drvMemConvertAddr");if(!fn)_Exit(125);
 uint32_t device=out?out->offsetAddr.devid:UINT32_MAX;unsigned depth=dma_depth++;uint64_t a=ns();DVresult e=fn(src,dst,len,out);uint64_t b=ns();dma_depth--;emit_dma("drvMemConvertAddr",a,b,device,UINT32_MAX,1,len,e,depth);return e;
}
DVresult drvMemDestroyAddr(struct DMA_ADDR*in){
 typedef DVresult(*Fn)(struct DMA_ADDR*);static Fn fn;if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"drvMemDestroyAddr");if(!fn)_Exit(125);
 uint32_t device=in?in->virt_id:UINT32_MAX;unsigned depth=dma_depth++;uint64_t a=ns();DVresult e=fn(in);uint64_t b=ns();dma_depth--;emit_dma("drvMemDestroyAddr",a,b,device,UINT32_MAX,1,0,e,depth);return e;
}
DVresult halMemDestroyAddrBatch(struct DMA_ADDR*in[],uint32_t count){
 typedef DVresult(*Fn)(struct DMA_ADDR*[],uint32_t);static Fn fn;if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"halMemDestroyAddrBatch");if(!fn)_Exit(125);
 uint32_t device=count&&in&&in[0]?in[0]->virt_id:UINT32_MAX;unsigned depth=dma_depth++;uint64_t a=ns();DVresult e=fn(in,count);uint64_t b=ns();dma_depth--;emit_dma("halMemDestroyAddrBatch",a,b,device,UINT32_MAX,count,0,e,depth);return e;
}
#define CREATE_WRAPPER(name) drvError_t name(uint32_t device,struct halAsyncDmaInputPara*in,struct halAsyncDmaOutputPara*out){typedef drvError_t(*Fn)(uint32_t,struct halAsyncDmaInputPara*,struct halAsyncDmaOutputPara*);static Fn fn;if(!fn)fn=(Fn)dlsym(RTLD_NEXT,#name);if(!fn)_Exit(125);unsigned depth=dma_depth++;uint64_t a=ns();drvError_t e=fn(device,in,out);uint64_t b=ns();dma_depth--;emit_dma(#name,a,b,device,in?in->sqId:UINT32_MAX,1,in?in->len:0,e,depth);return e;}
#define DESTROY_WRAPPER(name) drvError_t name(uint32_t device,struct halAsyncDmaDestoryPara*in){typedef drvError_t(*Fn)(uint32_t,struct halAsyncDmaDestoryPara*);static Fn fn;if(!fn)fn=(Fn)dlsym(RTLD_NEXT,#name);if(!fn)_Exit(125);unsigned depth=dma_depth++;uint64_t a=ns();drvError_t e=fn(device,in);uint64_t b=ns();dma_depth--;emit_dma(#name,a,b,device,in?in->sqId:UINT32_MAX,1,0,e,depth);return e;}
CREATE_WRAPPER(halAsyncDmaCreate)
CREATE_WRAPPER(halAsyncDmaWqeCreate)
DESTROY_WRAPPER(halAsyncDmaDestory)
DESTROY_WRAPPER(halAsyncDmaWqeDestory)
