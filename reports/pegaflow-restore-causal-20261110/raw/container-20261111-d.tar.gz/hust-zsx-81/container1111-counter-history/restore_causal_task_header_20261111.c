/* Read-only timing and eight-byte task-header metadata at the installed HAL ABI. */
#define _GNU_SOURCE
#include <ascend_hal.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
static int fd=-1;
static uint64_t ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
__attribute__((constructor))static void init(void){const char*p=getenv("NATIVE_COPY_TRACE_LOG");if(p)fd=open(p,O_WRONLY|O_CREAT|O_APPEND,0600);}
drvError_t halSqTaskSend(uint32_t device,struct halTaskSendInfo *info){
 typedef drvError_t(*Fn)(uint32_t,struct halTaskSendInfo*);static Fn fn;
 if(!fn)fn=(Fn)dlsym(RTLD_NEXT,"halSqTaskSend");if(!fn)_Exit(125);
 unsigned char h[8]={0};int valid=info&&info->sqe_addr&&info->sqe_num;
 if(valid)memcpy(h,info->sqe_addr,8);
 uint16_t stream=0,task=0;memcpy(&stream,h+4,2);memcpy(&task,h+6,2);
 uint64_t start=ns();drvError_t error=fn(device,info);uint64_t end=ns();
 if(fd>=0){char line[700];int n=snprintf(line,sizeof(line),"{\"event\":\"hal_send\",\"kind\":\"task\",\"start_ns\":%llu,\"end_ns\":%llu,\"device\":%u,\"sq\":%u,\"count\":%u,\"position\":%u,\"error\":%d,\"tid\":%ld,\"header8_valid\":%d,\"sqe_type6\":%u,\"flags8\":%u,\"stream_id16\":%u,\"task_id16\":%u}\n",(unsigned long long)start,(unsigned long long)end,device,info->sqId,info->sqe_num,info->pos,error,syscall(SYS_gettid),valid,h[0]&63,h[1],stream,task);write(fd,line,n);}
 return error;
}
