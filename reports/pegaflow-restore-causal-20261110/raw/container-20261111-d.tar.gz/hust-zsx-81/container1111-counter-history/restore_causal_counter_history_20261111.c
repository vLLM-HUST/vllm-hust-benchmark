/* Hold H2D buffers/work fixed while advancing the stream with finite NOP tasks. */
#define _GNU_SOURCE
#include <acl/acl.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint64_t ns(clockid_t c){struct timespec t;clock_gettime(c,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(x) do{int e=(x);if(e){fprintf(stderr,"%s=%d\n",#x,e);return 1;}}while(0)
int main(int argc,char**argv){
 alarm(180);int device=argc>1?atoi(argv[1]):1;size_t n=16384,piece=262144,bytes=n*piece;
 void*host=mmap(NULL,bytes,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0),*alias=NULL,*dest=NULL;aclrtStream stream=NULL;
 if(host==MAP_FAILED)return 2;memset(host,0x5a,bytes);
 CHECK(aclInit(NULL));CHECK(aclrtSetDevice(device));CHECK(aclrtHostRegister(host,bytes,ACL_HOST_REGISTER_MAPPED,&alias));
 CHECK(aclrtMalloc(&dest,bytes,ACL_MEM_MALLOC_HUGE_FIRST));CHECK(aclrtCreateStream(&stream));
 typedef int(*Nop)(void*);typedef int(*StreamId)(void*,int32_t*);
 Nop nop=(Nop)dlsym(RTLD_DEFAULT,"rtNopTask");StreamId getid=(StreamId)dlsym(RTLD_DEFAULT,"rtGetStreamId");
 if(!nop||!getid)return 3;int32_t stream_id=-1;CHECK(getid(stream,&stream_id));
 printf("{\"event\":\"ready\",\"stream_id\":%d,\"epoch_ns\":%llu}\n",stream_id,(unsigned long long)ns(CLOCK_REALTIME));fflush(stdout);
 int plan[8]={0,65536,0,49152,0,65536,0,0};
 for(int trial=0;trial<8;trial++){
  uint64_t prep=ns(CLOCK_MONOTONIC);
  for(int i=0;i<plan[trial];i++)CHECK(nop(stream));CHECK(aclrtSynchronizeStream(stream));
  uint64_t prep_end=ns(CLOCK_MONOTONIC),tag=10000+trial*100;
  for(int j=0;j<8;j++){
   size_t block=(size_t)j*(n-1)/7;*(uint64_t*)((char*)host+block*piece)=tag+block;
   CHECK(aclrtMemsetAsync((char*)dest+block*piece,8,0,8,stream));
  }CHECK(aclrtSynchronizeStream(stream));
  uint64_t start=ns(CLOCK_MONOTONIC),cpu=ns(CLOCK_THREAD_CPUTIME_ID);
  printf("{\"event\":\"copy_begin\",\"trial\":%d,\"nop_count\":%d,\"start_ns\":%llu,\"epoch_ns\":%llu}\n",trial,plan[trial],(unsigned long long)start,(unsigned long long)ns(CLOCK_REALTIME));fflush(stdout);
  for(size_t i=0;i<n;i++)CHECK(aclrtMemcpyAsync((char*)dest+i*piece,piece,(char*)host+i*piece,piece,ACL_MEMCPY_HOST_TO_DEVICE,stream));
  uint64_t submitted=ns(CLOCK_MONOTONIC);CHECK(aclrtSynchronizeStream(stream));uint64_t end=ns(CLOCK_MONOTONIC),cpu_end=ns(CLOCK_THREAD_CPUTIME_ID);
  for(int j=0;j<8;j++){size_t block=(size_t)j*(n-1)/7;uint64_t actual=0;CHECK(aclrtMemcpy(&actual,8,(char*)dest+block*piece,8,ACL_MEMCPY_DEVICE_TO_HOST));if(actual!=tag+block){fprintf(stderr,"tag mismatch trial%d block%zu\n",trial,block);return 4;}}
  printf("{\"event\":\"copy\",\"trial\":%d,\"nop_count\":%d,\"stream_id\":%d,\"descriptors\":%zu,\"bytes\":%zu,\"verified_tags\":8,\"preparation_ns\":%llu,\"start_ns\":%llu,\"end_ns\":%llu,\"api_ns\":%llu,\"sync_ns\":%llu,\"wall_ns\":%llu,\"thread_cpu_ns\":%llu}\n",trial,plan[trial],stream_id,n,bytes,(unsigned long long)(prep_end-prep),(unsigned long long)start,(unsigned long long)end,(unsigned long long)(submitted-start),(unsigned long long)(end-submitted),(unsigned long long)(end-start),(unsigned long long)(cpu_end-cpu));fflush(stdout);
 }
 CHECK(aclrtDestroyStream(stream));CHECK(aclrtFree(dest));CHECK(aclrtHostUnregister(host));munmap(host,bytes);CHECK(aclrtResetDevice(device));CHECK(aclFinalize());puts("{\"event\":\"completed\",\"cases\":8}");return 0;
}
