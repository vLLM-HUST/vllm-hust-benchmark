import json,pathlib,subprocess,time,os
root=pathlib.Path(__file__).parent
plan=json.loads((root/'plan.json').read_text())
for entry in plan['plan']:
 start=time.time()
 with (root/('device'+str(entry['device'])+'.log')).open('w') as stream:
  child=subprocess.Popen(entry['command'],env=dict(os.environ,CAUSAL_IMMUTABLE_SOURCE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'),stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  (root/('device'+str(entry['device'])+'-child.json')).write_text(json.dumps(dict(pid=child.pid,epoch=start)))
  status=child.wait()
 (root/('device'+str(entry['device'])+'-exit.json')).write_text(json.dumps(dict(exit_code=status,begin_epoch=start,end_epoch=time.time())))
 if status:raise SystemExit(status)
(root/'done.json').write_text(json.dumps(dict(epoch=time.time(),devices=len(plan['plan']))))
