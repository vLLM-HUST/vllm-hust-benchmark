"""Local protocol fixture: 128 held streams must not starve telemetry."""
import asyncio,contextlib,importlib.util,io,json,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
from aiohttp import web

async def check(path):
 spec=importlib.util.spec_from_file_location('client_under_test',path);client=importlib.util.module_from_spec(spec);spec.loader.exec_module(client)
 arrived=set();all_arrived=asyncio.Event();release=asyncio.Event();metrics_during=asyncio.Event()
 async def completion(request):
  identity=request.headers['X-Request-Id']
  if identity!='long-readiness':
   arrived.add(identity)
   if len(arrived)==128:all_arrived.set()
   await release.wait()
  return web.Response(text='data: {"choices":[{"text":"a"}]}\n\ndata: {"choices":[{"text":"b"}]}\n\ndata: {"choices":[],"usage":{"prompt_tokens":1,"completion_tokens":2}}\n\ndata: [DONE]\n\n',content_type='text/event-stream')
 async def metrics(request):
  if len(arrived)==128 and not release.is_set():metrics_during.set()
  return web.Response(text='vllm:kv_cache_usage_perc 0\n')
 app=web.Application();app.router.add_post('/v1/completions',completion);app.router.add_get('/metrics',metrics)
 runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
 try:
  with tempfile.TemporaryDirectory(prefix='client-protocol-fixture-') as tmp:
   root=Path(tmp);requests=root/'input.json';requests.write_text(json.dumps({'long':[{'id':f'long-{i}','input_tokens':1,'delay_seconds':0,'payload':{'prompt':'fixture','max_tokens':2}} for i in range(128)]}))
   with contextlib.redirect_stdout(io.StringIO()):
    task=asyncio.create_task(client.run(SimpleNamespace(requests=requests,output=root/'output',base=f'http://127.0.0.1:{port}',kinds=['long'])))
    try:
     try:await asyncio.wait_for(all_arrived.wait(),3)
     except asyncio.TimeoutError:pass
     count=len(arrived)
     if count==128:
      try:await asyncio.wait_for(metrics_during.wait(),3)
      except asyncio.TimeoutError:pass
     telemetry_ok=metrics_during.is_set()
    finally:
     release.set();await asyncio.wait_for(task,15)
   assert count==128,f'Only {count}/128 requests arrived before any completed'
   assert telemetry_ok,'Metrics were blocked while all 128 requests were in flight'
   assert len(json.loads((root/'output/long/group.json').read_text())['results'])==128
 finally:await runner.cleanup()
 print('PASS: 128 simultaneous held requests and live metrics, using real measurement client')
if __name__=='__main__':asyncio.run(check(Path(sys.argv[1])))
