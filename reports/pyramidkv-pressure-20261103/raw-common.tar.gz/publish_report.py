"""Package this pressure experiment only after independent raw verification."""
import gzip,hashlib,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPORT=Path('/tmp/pyramidkv-pressure-delivery/reports/pyramidkv-pressure-20261103')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def main():
 a=json.loads((ROOT/'analysis.json').read_text());c=json.loads((ROOT/'contract.json').read_text())
 assert a['verified_measured_requests']==576 and a['verified_readiness_requests']==8
 assert a['contract_sha256']==sha(ROOT/'contract.json')
 REPORT.mkdir(parents=True,exist_ok=False)
 shutil.copyfile(ROOT/'analysis.json',REPORT/'analysis.json')
 shutil.copyfile(ROOT/'pressure-coverage.json',REPORT/'pressure-coverage.json')
 tables=[]
 metrics=[('Output throughput (tokens/s)','output_token_throughput',1),('TTFT (ms)','mean_ttft_ms',1),('TPOT (ms)','mean_tpot_ms',1),('End to end (ms)','mean_e2e_ms',1),('Peak active KV (%)','kv_peak_fraction',100),('Peak simultaneous two-card HBM (MiB)','hbm_peak_mib_sum',1),('Peak running requests','peak_running',1),('Peak waiting requests','peak_waiting',1)]
 for model,title in [('qwen25','Qwen2.5-14B-Instruct C64'),('qwen35','Qwen3.5-35B-A3B C128')]:
  g=a['models'][model]['long_aggregates'];changes=a['models'][model]['long_percent_change']
  lines=[f'## {title}','','| Metric | OFF | ON | Change |','| --- | ---: | ---: | ---: |']
  for label,key,factor in metrics:
   delta='n/a' if changes[key] is None else f'{changes[key]:+.2f}%'
   lines.append(f'| {label} | {g["off"][key]*factor:,.2f} | {g["on"][key]*factor:,.2f} | {delta} |')
  lines+=['','| Arm | Native blocks | Logical page | Effective token capacity | Rank0 KV budget GiB | Exact lifecycle preemptions |','| --- | ---: | ---: | ---: | ---: | ---: |']
  for run in a['runs']:
   if run['model']==model:
    p=run['kv_pool'];lines.append(f'| {"ON" if run["enabled"] else "OFF"} | {p["physical_blocks"]} | {p["logical_block_size"]} | {p["effective_capacity_tokens"]} | {run["kv_pool_available_gib_rank0_log_rounded"]:.2f} | {run["lifecycle_preemptions_total"]:.0f} |')
  tables.append('\n'.join(lines))
 (REPORT/'README.md').write_text(f'''# PyramidKV pressure test at 64 and 128 concurrent requests

**Single-round Eager diagnostic; excluded from official performance leaderboards.**
The user requested doubling Qwen2.5 concurrency from32 to64 and quadrupling
Qwen3.5 concurrency from32 to128. Each model has one fresh-process OFF/ON pair.
Both request concurrency and the server sequence limit increase together.
The automatic KV pool is retained. Different concurrency between models means
this measures their response to pressure, not the isolated effect of model choice.

Both OFF arms reached practical pool saturation: Qwen2.5 peaked at100% with3
lifecycle preemptions; Qwen3.5 at99.62% with1. Enabling PyramidKV removed those
preemptions and increased batch output throughput by18.94% and6.45%, respectively.
TTFT improved by19.29% and4.00%. The tradeoff remains: TPOT increased by21.90%
and7.38%, and mean request E2E increased by8.87% and3.83%. Faster completion of
the entire batch therefore does not imply lower average per-request latency.

At C32, enabling the same candidate reduced throughput by17.25% and3.68%, with
zero baseline preemptions. This pressure test demonstrates that the observed
benefit depends on workload pressure. It does not attribute the difference to a
specific kernel or establish repeatability from a single pair.

{chr(10).join(tables)}

## Configuration and relationship to the previous run

The [previous C32 comparison](https://github.com/vLLM-HUST/vllm-hust-benchmark/tree/6c136e521fa6ca09fc89a2d70d4ac40946fab48f/reports/pyramidkv-model-comparison-20261103)
used the same model weights, plugin wheel, native runtime, physical Ascend910B2
cards1/6, TP2, BF16, Eager, no MTP, 7168 input tokens and512 forced output tokens.
This run keeps max model length8192, batch-token budget4096, utilization0.8,
APC, async scheduling, chunked prefill, seed0 and generation-config=vllm.
Qwen3.5 retains native Mamba align; Qwen2.5 has no Mamba state.
The HTTP timeout increases from600 to1800 seconds in both arms to allow pressure
queueing/recomputation; successful-request metric definitions stay unchanged.

Candidate source `{c['candidate_source_commit']}` and wheel0.4.0rc2.dev0 are reused
byte for byte. Source PR35 has since merged without changing the measured runtime
code. This is not a measurement of the published0.4.0rc1 wheel.
CANN9.1, Torch2.10.0+cpu, torch-npu2.10.0.post4 and transformers5.14.1 are unchanged.
Native core `{c['core_commit']}` and Ascend `{c['ascend_commit']}` remain pinned.
Installed vLLM metadata is0.23.0+empty, Ascend0.23.0.post1; VLLM_VERSION=0.25.1
selects the prepared ABI branch, rather than identifying the installed version.

PyramidKV retains capacity512, beta20, window8, kernel7, maxpool, KV-head/mean
GQA, no merge, and prompt admission above4096 tokens. Dense allocation after
compression is1024 physical tokens; hybrid logical alignment requires2048.
Layer-specific selected lengths remain distinct from the physical allocation.

The original common vocabulary and seed0 generator extend the long cohort to
128 unique literal prompts. Whole prompts encode to exactly7168 tokens under
both tokenizers. The first32 are byte-identical to the previous run; Qwen2.5
uses the first64 of Qwen3.5's128. No old request is duplicated to inflate load.
OFF/ON inputs within a model are identical. Request files are pinned in
contract SHA256 `{a['contract_sha256']}`.

Each lifecycle retains48 short1024/256 requests at rate1, then64 or128 long
requests sent simultaneously. One separate readiness request precedes each
cohort; the long readiness reuses its first prompt, identically in both arms.
Thus576 measured and8 readiness requests are verified, including384 target long
requests. Each model has one accepted pair. An initial Qwen3.5 OFF attempt was
aborted when the default aiohttp connector capped active HTTP requests at100
and blocked metrics polling. Its full partial evidence is retained and excluded
from performance aggregates. connection-limit-amendment.json freezes the fix:
TCPConnector(limit=0), applied identically to both accepted Qwen3.5 arms. A local
behavioral test reproduces100/128 arrivals with the original client and verifies
128 held requests plus live metrics with the corrected client. Qwen2.5 C64 never
reached the original100-connection limit and was not repeated. Original contract
and amended contract `{a['amended_contract_sha256']}` are both preserved; no model, request or algorithm setting
changed during this correction. The client fix and local HTTP regression test are
merged in [source PR36](https://github.com/vLLM-HUST/vllm-ascend-pyramidkv-hust/pull/36).
Startup-only file
cache eviction is recorded to keep checkpoint loading within the64GiB host
cgroup; no eviction occurs during inference.

## How to interpret the metrics

KV usage measures active blocks within the preallocated pool. Reclaiming blocks
increases room for other requests; it does not release that entire allocation
back to device HBM. Dense and hybrid native pool layouts differ; the hybrid
reported effective token capacity cannot be divided by its logical page size
to recover physical block count. Pool sizes above come directly from native
cache_config_info metrics.

Preemption totals are exact final counters across each fresh lifecycle, including
its readiness and short prelude. The JSON also exposes sampled cohort lower
bounds, which may miss an unsampled tail. Running/waiting peaks and KV usage are
sampled about every0.2s; two-card HBM about every2s. HBM sum is the maximum
simultaneous sampled sum, not the sum of separate per-card maxima.

TTFT ends at the first streamed choice, including an empty choice; E2E ends at
the last choice, excluding usage/DONE. TPOT is the interval after the first choice
divided by output tokens minus one. Throughput is completed output tokens divided
by cohort wall time. Per-request records and cohort mean/p50/p95 are preserved.
Synchronous artifact writes and telemetry add common instrumentation overhead.
A single pair provides no run-to-run variance estimate, and synthetic throughput
does not establish task-quality parity. Differences against C32 also include
additional unique requests and scheduling effects, not just resident KV demand.

## Raw evidence and verification

The capsule retains every server log, raw SSE stream, timestamped event, request
result, telemetry sample, final native metric, shutdown receipt, frozen launcher,
input, package and model identity. The aborted Qwen3.5 attempt is preserved in
its own archive alongside the four accepted lifecycles. Model weights are referenced by hashes/stat
pins rather than duplicated. All per-request usage must match7168/512 for long
requests and1024/256 for short requests. Both TP ranks must acknowledge admitted
scheduler commits. Final running/waiting counters must be zero and both devices
free after every lifecycle. Known native output-handler exceptions after explicit
shutdown are separated from serving errors; no serving error is accepted.

Run with Python3.12 or newer, CPU only:

```sh
python verify.py
```

The verifier checks SHA256SUMS, every archived member, safe extraction, exact
request identities/usage, raw SSE/event correspondence, independent metric
recomputation, TP-rank acknowledgements, native pools and cleanup. Its recomputed
analysis must match analysis.json byte for byte. pressure-coverage.json additionally
verifies that all64 or128 requests were visible as running plus waiting on the
server before any completed, and records telemetry gaps/errors. The public archives are also
read back after upload. No model installation is needed for offline verification.
''')
 members={}
 def archive(name,paths):
  with tarfile.open(REPORT/name,'w:gz',compresslevel=6) as tar:
   for p in sorted(paths):
    relative=str(p.relative_to(ROOT));assert relative not in members
    members[relative]={'bytes':p.stat().st_size,'sha256':sha(p),'archive':name}
    info=tar.gettarinfo(str(p),arcname=relative);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
    with p.open('rb') as stream:tar.addfile(info,stream)
  assert (REPORT/name).stat().st_size<50*2**20,name
 common=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and (len(p.relative_to(ROOT).parts)==1 or p.relative_to(ROOT).parts[0] in ('candidate-overlay','wheels')) and p.name!='lifecycle.lock']
 archive('raw-common.tar.gz',common)
 for run in sorted((ROOT/'runs').iterdir()):archive('raw-'+run.name+'.tar.gz',[p for p in run.rglob('*') if p.is_file()])
 (REPORT/'members.json.gz').write_bytes(gzip.compress(json.dumps(members,sort_keys=True,indent=2).encode(),mtime=0))
 shutil.copyfile(ROOT/'verify_public.py',REPORT/'verify.py')
 (REPORT/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(REPORT.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
 print(REPORT,len(members),sum(p.stat().st_size for p in REPORT.iterdir()))
if __name__=='__main__':main()
