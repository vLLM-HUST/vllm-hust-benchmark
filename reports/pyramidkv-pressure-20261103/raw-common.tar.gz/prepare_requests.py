import hashlib,json
from pathlib import Path
import numpy as np
from transformers import AutoTokenizer
root=Path(__file__).resolve().parent
old=Path('/root/.cache/pyramidkv-model-compare-20261103')
previous=json.loads((old/'requests.json').read_text())
words=json.loads((root/'common-words.json').read_text())
paths=['/data/shared_models/Qwen2.5-14B-Instruct','/root/workspace/Qwen3.5-35B-A3B']
toks=[AutoTokenizer.from_pretrained(p,local_files_only=True) for p in paths]
rng=np.random.default_rng(0);rows=[]
for i in range(128):
 text=''.join(words[k] for k in rng.integers(0,len(words),7168))
 ids=[t.encode(text,add_special_tokens=False) for t in toks];assert all(len(x)==7168 for x in ids)
 payload=dict(previous['long'][0]['payload'],prompt=text)
 rows.append({'id':f'long-{i:02d}','input_tokens':7168,'token_ids_sha256_by_model':{name:hashlib.sha256(json.dumps(x).encode()).hexdigest() for name,x in zip(('qwen25','qwen35'),ids)},'delay_seconds':0.0,'payload':payload})
assert rows[:32]==previous['long']
assert len({r['payload']['prompt'] for r in rows})==128
for model,n in [('qwen25',64),('qwen35',128)]:
 (root/f'{model}-requests.json').write_text(json.dumps({'short':previous['short'],'long':rows[:n]},ensure_ascii=False,indent=2)+'\n')
 print(model,n,'unique prompts; exact7168 tokens in both tokenizers; first32 unchanged',flush=True)
(root/'request-generation-receipt.json').write_text(json.dumps({'prior_requests_sha256':hashlib.sha256((old/'requests.json').read_bytes()).hexdigest(),'both_tokenizers_verified':True,'prior_32_exactly_preserved':True,'qwen25_is_prefix_of_qwen35':True,'unique_long_prompts':128},indent=2)+'\n')
