import hashlib,json,time
from pathlib import Path
r=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
c=json.loads((r/'contract.json').read_text())
for name,h in c['files_sha256'].items():assert sha(r/name)==h,name
assert 'PASS: 128' in (r/'client-concurrency-green.log').read_text()
assert (r/'runs/qwen35-off-1/npu-after.txt').read_text().count('No running processes found')==2
s=(r/'run_series.py').read_text().replace("'contract.json'","'contract-v2.json'").replace("'measure.py'","'measure_unbounded.py'").replace("'lifecycle.lock'","'lifecycle-v2.lock'")
(r/'run_qwen35.py').write_text(s)
s=(r/'analyze.py').read_text().replace("digest(ROOT/'contract.json')\n assert process", "digest(ROOT/row.get('contract_file','contract.json'))\n assert process")
s=s.replace("digest(ROOT/'measure.py')", "digest(ROOT/row.get('client_file','measure.py'))")
s=s.replace("for relative,sha in contract['files_sha256'].items():assert digest(ROOT/relative)==sha,relative", "amended=json.loads((ROOT/'contract-v2.json').read_text())\n for item in (contract,amended):\n  for relative,sha in item['files_sha256'].items():assert digest(ROOT/relative)==sha,relative")
s=s.replace("for row in contract['lifecycles']]", "for row in contract['lifecycles'][:2]+amended['lifecycles']]")
s=s.replace("result={'contract_sha256':digest(ROOT/'contract.json')", "result={'amended_contract_sha256':digest(ROOT/'contract-v2.json'),'excluded_attempt':{'name':'qwen35-off-1','reason':'Aborted: default client connector capped active HTTP requests at100 and starved telemetry; originals preserved'},'contract_sha256':digest(ROOT/'contract.json')")
(r/'analyze_pressure.py').write_text(s)
amendment={'created_at':time.time(),'reason':'Observed default aiohttp connection limit100 capped C128 and starved telemetry. Local behavioral test reproduces100/128; corrected client passes128 held streams plus live metrics.','original_contract_sha256':sha(r/'contract.json'),'excluded_attempt':'runs/qwen35-off-1','excluded_server_sha256':sha(r/'runs/qwen35-off-1/server.log'),'retained_valid_runs':['qwen25-off-1','qwen25-on-1'],'scope':'Only HTTP connector limit changes to0 (no pool cap). Per-request/cohort metrics, inputs and model settings unchanged. Both Qwen3.5 arms use corrected client. No additional Qwen2.5 run.','client_sha256':sha(r/'measure_unbounded.py')}
write(r/'connection-limit-amendment.json',amendment)
c['created_at']=time.time();c['supersedes_qwen35_only']=sha(r/'contract.json');c['client_connector_limit']=0
c['lifecycles']=[dict(name=f'qwen35-{arm}-128',model='qwen35',enabled=arm=='on',concurrency=128,contract_file='contract-v2.json',client_file='measure_unbounded.py') for arm in ('off','on')]
for name in ['measure_unbounded.py','run_qwen35.py','analyze_pressure.py','test_client_concurrency.py','client-concurrency-red.log','client-concurrency-green.log','connection-limit-amendment.json','amend_connections.py']:
 c['files_sha256'][name]=sha(r/name)
write(r/'contract-v2.json',c);print('amended freeze',sha(r/'contract-v2.json'))
