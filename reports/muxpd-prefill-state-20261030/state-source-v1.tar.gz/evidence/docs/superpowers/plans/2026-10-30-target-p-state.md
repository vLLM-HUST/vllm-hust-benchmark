# Target prefill persistent-state implementation plan

> **For agentic workers:** Use superpowers:subagent-driven-development. Implement the two independent components below, then review the integrated experiment before root freezes or runs it.

**Goal:** Determine whether target07338's first complete prefill leaves different persistent state in native and prefix execution, despite equal observed MoE hidden outputs.

**Architecture:** Reuse the qualified MoE-v2 controller, request loop, numeric observer and historical controls. Replace only the hidden observer with two owner hooks that enqueue target state copies immediately after the original prefill forward and export them after original bookkeeping. Preserve the original return object, cache objects, stream treatment, scheduler and numerical operations.

**Tech stack:** Python, PyTorch/torch_npu, installed vLLM/Ascend, CPU pytest, one TP4 attempt per role.

**Spec:** `/root/workspace/muxpd-target-prefill-next-20261030/state-boundary-design-v1.md`, supplemented by the explicit conditions below.

## Global constraints

- New isolated directory `/root/workspace/muxpd-target-prefill-state-20261030`; do not alter any frozen predecessor.
- Unchanged batch7 plan, eight prompts/order, target208 cutoff, greedy seed42, native then prefix, physical3/4/5/6 subject to fresh root preflight.
- The original full200 quality gate remains FAIL. This is observation, not a runtime candidate.
- All80 full logits and all8 saved prefixes per role must match old same-role controls; preserve prefix B-v2 plain bridge.
- 30 conv plus30 recurrent plus20 K/V logical tensors per rank. Expected value payload29,818,880 bytes; metadata at most1MiB; total clone storage below256MiB.
- No extra collectives, operator replay, device gather, format conversion, in-forward synchronization, model mutation or changed admission loop.
- Installation returns all4 rank success/error/cleanup envelopes, saved before admission. Failures and partial cleanup remain visible.
- Root alone owns device lifecycle and GitHub. No NPU experiment before integration tests, independent review and immutable freeze.

## Review focus

- Native target row3 versus prefix row2; GDN recurrent prefill ordinal2 is a distinct index space.
- Device slot mapping is authoritative; CPU mirror may be stale. Preserve integer/bool metadata dtype exactly, including integers above2^24.
- Prefix alias checks include seed/decode_runner and all active shared owner requests, not only the seven P rows. Shared backing allocation is legitimate; reject intersecting selected byte ranges, not all shared storage pointers.
- Use actual installed Ascend method bindings, logical block expansion, actual ND format and storage strides. Do not infer runtime bindings from upstream definitions.
- A returned host forward is not a device fence. Check original overlap lane/current stream/context and event ordering; export only after original bookkeeping, before target D can mutate state.

## Task1: State observer (peer_p_helper)

**Files:** create `state_capture_v1.py`, `capture-profile-v1.json`, `test_state_capture_v1.py`, source-binding receipt and test logs in the new directory.

**Interfaces:** retain MoE-v2 public RPC signatures `install_rpc_on_worker(argument, expected_cases, output_dir, capture_profile)`, `validate_install_rpc_receipts(rows,module_sha)`, `snapshot_on_worker(argument)`, `uninstall_on_worker(argument,allow_incomplete=False)`, `validate_uninstall_receipts`, `validate_receipts`. Snapshot fields retain lifecycle semantics; new state/metadata file records explicitly distinguish logical tensors and physical segments. Tell harness the schema before implementation settles.

- [ ] Add and run failing tests for wrong mixed-row/prefill-ordinal mapping, physical/logical expansion, stale device mapping, cross-runner alias, integer metadata precision, non-ND layout, wrong stream and partial installation cleanup.
- [ ] Implement only owner `_model_forward` and `_bookkeeping_sync` hooks. Bind actual GDN/cache/backend methods and cache identities. Derive CPU block indices; clone actual GPU index/slot/flag proofs plus target-owned stored states. Clone contiguous KV segments as views and assemble ordered logical arrays on CPU.
- [ ] Preserve all device metadata dtypes; state BF16 export may use exact FP32 representation, recurrent FP32 remains exact. Reject mismatched post-copy mappings before accepting state files.
- [ ] Verify original output/cache aliases and pre/post forward ownership. Enforce2 owned slots, exactly one target activation/flush, bounds and reverse/idempotent restoration.
- [ ] Run focused CPU tests and source binding checks. Report remaining instance-only assertions without treating CPU fixtures as hardware evidence.

## Task2: Host harness and analysis (peer_p_harness)

**Files:** adapt qualified v2 `probe_run_v1.py`, `probe_control_v1.py`, numeric/source modules unchanged, `state_analysis_v1.py`, `analyze_state_v1.py`, tests, run matrix, references and producer manifest.

- [ ] Add failing tests using actual completed v2 reports and vectors for all80 receipt selection and full8 prefix bridges; include malformed/missing state segments, integer mapping mismatch and partial envelope cases.
- [ ] Preserve driver admission/step loop AST and all normal numeric/source/runtime behavior; replace observer module only and save4 installation envelopes before validation/admission.
- [ ] Validate terminal proofs, exact producer identities, all state and metadata files, required80 logical tensors/rank and segment completeness/order. Compare same-rank canonical target state only after all historical controls pass.
- [ ] Report per-layer/per-state unequal count, byte equality, maximum/RMS and first difference, without claiming quality restoration. Preserve existing failed MoE-v1 lineage and qualified MoE-v2 motivation as external references.
- [ ] Run the relevant integrated CPU suite, including actual historical receipts. Deliver exact producer map, no model launch.

## Task3: Independent review and root experiment

- [ ] Independently finish MoE-v2 raw-file audit. Review state helper, host integration, source/stream/cache proofs and exact CPU checks. Fix concrete findings before freeze.
- [ ] Root performs bounded actual runtime import-only binding check if new methods need it; no model or cache allocation. Freeze exact producer bytes after fresh idle/source preflight.
- [ ] Root runs native once, proves terminal, then full native control analysis. Only if qualified, run prefix once and prove terminal before reading output.
- [ ] Run complete primary and independent raw-file analysis. A failed mapping/source/control invalidates attribution; retain failure and version corrections explicitly.

## Task4: Decide from evidence

- [ ] If persistent states differ, localize the earliest stored-state boundary and design a one-variable intervention. If equal, inspect actual decode evolution and co-batch context; do not repeat cleared P boundaries.
- [ ] Only a verified answer-repair candidate enters runtime code. Then run original regression cohort and fresh full200, report every fixed/new-wrong/new-length case and retain PR27 Draft until appropriate evidence exists.
