"""CPU postprocess only; root must authorize both model terminals before use."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

BUNDLE = Path("/root/workspace/muxpd-target-prefill-state-20261030")
sys.path.insert(0, str(BUNDLE))
import window_analysis_core_v1 as core


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def terminal(path):
    value = json.loads((path / "controller.json").read_text())
    assert value["finished_at"] and value["passed"] and value["exit_code"] == 0
    assert value["terminal_process_proven"]
    assert value["owned_members_after_cleanup"] == [] and not value["errors"]
    assert not value.get("cleanup_required") and not value.get("forced_termination")
    return value


def array(path, receipt, shape):
    assert path.name == receipt["file"] and not path.is_symlink()
    assert sha(path) == receipt["sha256"] and path.stat().st_size == receipt["bytes"]
    value = np.load(path, allow_pickle=False, mmap_mode="r")
    assert value.dtype == np.dtype("float32") and list(value.shape) == shape
    return value


def check_installations(report, module_sha, imported):
    assert report["schema"] == "muxpd-peer-p-state-run-v1"
    assert report["layer_hook_module_sha256"] == module_sha
    initial = {r["rank"]: r for r in report["layer_hook_installation"]}
    final = {r["rank"]: r for r in report["layer_hook_final"]}
    envelopes = report["layer_hook_install_rpc"]
    assert len(initial) == len(final) == len(envelopes) == 4
    assert set(initial) == set(final) == {e["rank"] for e in envelopes} == set(range(4))

    def binding(name):
        row = imported["bindings"].get(name, imported.get(name))
        return {
            k: row[k] for k in ("module", "qualname", "path", "sha256", "unwrapped")
        }

    for e in envelopes:
        rank = e["rank"]
        assert (
            e["schema"] == "muxpd-state-install-rpc-v1" and e["status"] == "installed"
        )
        assert e["module_sha256"] == module_sha and e["receipt"] == initial[rank]
        assert all(e[k] is None for k in ("error", "cleanup", "cleanup_error"))
        guards = initial[rank]["source_guards"]
        assert final[rank]["source_guards"] == guards
        assert guards["cpu_fixture_only"] is False
        assert (
            guards["runtime_vllm_version"] == "0.25.1"
            and guards["ascend_release_patch_active"]
        )
        assert guards["runtime_bindings"] == {
            k: binding(k)
            for k in (
                "runner_forward",
                "gdn_builder_build",
                "gdn_builder_attach_prefill",
                "device_reshape_and_cache",
                "npu_format",
            )
        }
        modules = guards["modules"]
        assert len(modules) == len({m["python_id"] for m in modules}) == 40
        assert len({m["layer_name"] for m in modules}) == 40
        for index, m in enumerate(modules):
            linear = index % 4 != 3
            assert (
                m["index"] == index
                and type(m["python_id"]) is int
                and m["python_id"] > 0
            )
            assert m["registry_identity"] is True
            assert m["kind"] == ("linear_attention" if linear else "full_attention")
            assert m["layer_name"].endswith(
                f".layers.{index}" + (".linear_attn" if linear else ".self_attn.attn")
            )
            names = {"decoder_forward": "decoder_forward"}
            names.update(
                {
                    "forward": "gdn_forward",
                    "_forward_core": "gdn_core",
                    "get_state_shape": "gdn_state_shape",
                    "get_attn_backend": "gdn_attn_backend",
                    "get_state_dtype": "gdn_state_dtype",
                }
                if linear
                else {
                    "forward": "attention_forward",
                    "reshape_and_cache": "attention_reshape_and_cache",
                }
            )
            assert m["bindings"] == {k: binding(v) for k, v in names.items()}
            assert m["attention_type"] == (
                None
                if linear
                else {
                    "type": "vllm.v1.attention.backend.AttentionType",
                    "name": "DECODER",
                    "value": "decoder",
                }
            )
        assert (
            initial[rank]["installed_hook_count"] == 2
            and initial[rank]["state"] == "WAIT_P"
        )
        assert (
            initial[rank]["capture_forward_count"] == initial[rank]["flush_count"] == 0
        )
        assert not initial[rank]["files"] and initial[rank]["manifest"] is None
    source_files = initial[0]["source_guards"]["source_files"]
    assert all(
        initial[r]["source_guards"]["source_files"] == source_files for r in range(4)
    )
    for path, digest in source_files.items():
        assert sha(Path(path)) == digest
    return {
        "successful_rank_envelopes": 4,
        "actual_state_modules": 160,
        "actual_module_method_bindings": 840,
        "actual_global_runtime_bindings": 20,
    }


def read_state_npy(directory, record, rank):
    name = record["file"]
    assert name == f"rank-{rank}-{record['key']}.npy" and Path(name).name == name
    path = directory / name
    assert not path.is_symlink() and path.resolve().parent == directory.resolve()
    assert sha(path) == record["sha256"] and path.stat().st_size == record["bytes"]
    value = np.load(path, allow_pickle=False, mmap_mode="r")
    assert (
        list(value.shape) == record["shape"]
        and str(value.dtype) == record["stored_dtype"]
    )
    assert (
        record["producer_event_synchronized"] is True and record["all_finite"] is True
    )
    assert np.isfinite(value).all()
    assert record["selected_view"]["device"] == f"npu:{rank}"
    return value


def canonical_rows(rows):
    return sorted(json.dumps(v, sort_keys=True, separators=(",", ":")) for v in rows)


def check_states(path, report, role):
    directory = path / "results/layer-observations"
    finals = {r["rank"]: r for r in report["layer_hook_final"]}
    uninstalls = report["layer_hook_uninstall"]
    assert len(uninstalls) == 4 and {r["rank"] for r in uninstalls} == set(range(4))
    for row in uninstalls:
        assert row["schema"] == "muxpd-state-uninstall-v1" and row["ok"] is True
        assert (
            row["collection_complete"] is True and row["all_originals_restored"] is True
        )
        assert row["installed_hook_count"] == row["restored_count"] == 2
        assert row["pending_after"] == 0 and row["allow_incomplete"] is False
        assert row["error"] is None and row["collection_error"] is None
        graph = row["graph_ownership"]
        assert graph["controller_present"] is (role == "prefix")
        if role == "prefix":
            assert (
                graph["all_graph_patches_owned"]
                and graph["owner_forward_is_graph_wrapper"]
            )
    results, checks, expected_files = {}, {}, set()
    for rank, receipt in finals.items():
        manifest = directory / f"rank-{rank}-state-captures.json"
        assert (
            receipt["manifest"]["file"] == manifest.name and not manifest.is_symlink()
        )
        assert sha(manifest) == receipt["manifest"]["sha256"]
        saved = json.loads(manifest.read_text())
        assert (
            saved["manifest"] is None
            and {**saved, "manifest": receipt["manifest"]} == receipt
        )
        expected_files.add(manifest.name)
        assert receipt["role"] == ("prefill" if role == "prefix" else "native")
        assert (
            receipt["state"] == "DONE"
            and receipt["owner_forward_original_returned"] is True
        )
        assert (
            receipt["forward_finished"] is True
            and receipt["capture_forward_count"] == receipt["flush_count"] == 1
        )
        assert (
            receipt["installed_hook_count"] == 2
            and receipt["pending_tensor_count"] == 0
        )
        assert (
            receipt["captured_tensor_count"] == 80
            and receipt["state_clone_bytes"] == 29818880
        )
        assert (
            receipt["clone_bytes"]
            == receipt["state_clone_bytes"] + receipt["metadata_clone_bytes"]
        )
        assert 0 < receipt["metadata_clone_bytes"] <= 1024 * 1024
        assert receipt["clone_bytes"] <= receipt["max_clone_bytes"] == 256 * 1024 * 1024
        streams = receipt["stream_receipts"]
        assert streams["stable"] is True and streams["before"] == streams["after"]
        stream = streams["after"]
        assert stream["device"] == stream["expected_device"] == f"npu:{rank}"
        assert (
            stream["context_python_id"] is not None
            and stream["stream_id"] == stream["expected_stream_id"]
        )
        assert (
            stream["lane"]
            == stream["expected_lane"]
            == ("prefill" if role == "prefix" else None)
        )
        assert stream["cudagraph_mode"] == "NONE"
        assert not any(
            stream[k] for k in ("capturing", "enable_enpu", "flash_comm_v1_enabled")
        )
        if role == "prefix" or stream["ascend_stream_id"] is not None:
            assert stream["ascend_stream_id"] == stream["stream_id"]
        ownership = receipt["cache_ownership"]
        assert ownership["pre_post_identity"] and ownership["overlap_checked"]
        rows = ownership["active_rows"]
        owner = {r["request_id"]: r for r in rows if r["runner"] == "owner"}
        assert (
            len(owner) == 8
            and len({r["request_python_id"] for r in owner.values()}) == 8
        )
        assert {r["prompt_sha256"] for r in owner.values()} == set(
            receipt["capture_profile"]["prompt_sha256"].values()
        )
        labels = {"owner", "decode"} if role == "prefix" else {"owner"}
        assert (
            set(ownership["runner_request_ids"])
            == set(ownership["runner_batch_ids"])
            == labels
        )
        for label in labels:
            actual = [r for r in rows if r["runner"] == label]
            assert len(actual) == len(ownership["runner_request_ids"][label]) == 8
            assert (
                {r["request_id"] for r in actual}
                == set(ownership["runner_request_ids"][label])
                == set(owner)
            )
            batch = ownership["runner_batch_ids"][label]
            for r in actual:
                rid = r["request_id"]
                assert r["row"] == (batch.index(rid) if rid in batch else None)
                assert r["in_batch"] is (rid in batch)
                assert r["shared_registry_duplicate"] is (label == "decode")
                if label == "decode":
                    assert r["request_python_id"] == owner[rid]["request_python_id"]
                    assert r["prompt_sha256"] == owner[rid]["prompt_sha256"]
                    assert [
                        {k: v for k, v in g.items() if k != "cpu_table_checked"}
                        for g in r["groups"]
                    ] == [
                        {k: v for k, v in g.items() if k != "cpu_table_checked"}
                        for g in owner[rid]["groups"]
                    ]
                    assert not (owner[rid]["target"] and r["in_batch"])
                for gid, group in enumerate(r["groups"]):
                    bs, ps = group["block_size"], group["physical_block_size"]
                    assert ps % bs == 0 and group["group_id"] == gid
                    expanded = [
                        b * (ps // bs) + i
                        for b in group["physical_block_ids"]
                        for i in range(ps // bs)
                    ]
                    assert group["logical_block_ids"] == expanded
                    assert (
                        group["num_blocks"] == len(expanded)
                        and group["blocks_per_phys_block"] == ps // bs
                    )
                    assert group["cpu_table_checked"] is r["in_batch"]
        target_rows = [r for r in rows if r["target"]]
        assert len(target_rows) == 1 and target_rows == [
            r for r in ownership["pre_forward_active_rows"] if r["target"]
        ]
        target, batch_target = target_rows[0], receipt["batch"]["target"]
        assert (
            target["request_id"] == batch_target["request_id"]
            and target["row"] == batch_target["row"]
        )
        assert batch_target["case_id"] == "mmlu-pro-07338" and target["row"] == (
            3 if role == "native" else 2
        )
        assert batch_target["token_end"] - batch_target["token_start"] == 1340
        for k in ("shared_owner_decode_requests", "shared_owner_decode_kv_caches"):
            assert ownership[k] is (True if role == "prefix" else None)
        records = {r["key"]: r for r in receipt["files"]}
        assert len(records) == len(receipt["files"])
        loaded = {k: read_state_npy(directory, r, rank) for k, r in records.items()}
        expected_files.update(r["file"] for r in records.values())
        for r in records.values():
            assert r["producer_stream"] == stream
        logicals = {r["key"]: r for r in receipt["logical_tensors"]}
        expected_keys = {
            f"layer-{i:02d}-{k}"
            for i in range(40)
            for k in (("key", "value") if i % 4 == 3 else ("conv", "recurrent"))
        }
        assert len(logicals) == 80 and set(logicals) == expected_keys
        caches = ownership["layers"]
        assert [c["layer_index"] for c in caches] == list(range(40))
        target_ranges, other_ranges, expected_meta, used = [], [], {}, set()
        results[rank] = {}
        for index, cache in enumerate(caches):
            module = receipt["source_guards"]["modules"][index]
            assert cache["bound_layer_python_id"] == module["python_id"]
            assert (
                cache["layer_name"] == module["layer_name"]
                and cache["kind"] == module["kind"]
            )
            group = target["groups"][cache["group_id"]]
            gid, blocks, bs = (
                group["group_id"],
                group["logical_block_ids"],
                group["block_size"],
            )
            linear = index % 4 != 3
            kinds = ("conv", "recurrent") if linear else ("key", "value")
            assert len(cache["cache_tensors"]) == 2
            for kind, source in zip(kinds, cache["cache_tensors"]):
                key = f"layer-{index:02d}-{kind}"
                logical = logicals[key]
                shape = {
                    "conv": [3, 2048],
                    "recurrent": [8, 128, 128],
                    "key": [1340, 1, 256],
                    "value": [1340, 1, 256],
                }[kind]
                dtype = "torch.float32" if kind == "recurrent" else "torch.bfloat16"
                element = 4 if kind == "recurrent" else 2
                assert (
                    logical["shape"] == shape
                    and logical["source_dtype"] == dtype
                    and logical["stored_dtype"] == "float32"
                )
                assert (
                    logical["layer_index"] == index
                    and logical["layer_name"] == module["layer_name"]
                    and logical["cache_group_id"] == gid
                )
                tail = shape if linear else [bs, 1, 256]
                strides = [
                    int(np.prod(tail)),
                    *[int(np.prod(tail[j + 1 :])) for j in range(len(tail))],
                ]
                assert source["shape"][1:] == tail and source["stride"] == strides
                assert (
                    source["dtype"] == dtype
                    and source["device"] == f"npu:{rank}"
                    and source["format"] == 2
                )
                assert source["element_size"] == element
                assert (
                    source["data_ptr"]
                    == source["storage_ptr"] + source["storage_offset"] * element
                )
                assert source["nbytes"] == int(np.prod(source["shape"])) * element
                assert (
                    0 <= source["storage_offset"] * element
                    and source["storage_offset"] * element + source["nbytes"]
                    <= source["storage_nbytes"]
                )
                parts, cursor, identities = [], 0, []
                for pos, segment in enumerate(logical["segment_keys"]):
                    assert segment not in used
                    used.add(segment)
                    r, value = records[segment], loaded[segment]
                    assert (
                        r["kind"] == "state"
                        and r["logical_key"] == key
                        and r["segment_index"] == pos
                    )
                    end = shape[0] if linear else min(cursor + bs, shape[0])
                    block = blocks[0] if linear else blocks[cursor // bs]
                    assert 0 <= block < source["shape"][0]
                    if linear:
                        assert len(blocks) == len(logical["segment_keys"]) == 1
                    assert r["position_start"] == cursor and r["position_end"] == end
                    assert (
                        r["shape"] == [end - cursor, *shape[1:]]
                        and value.dtype == np.float32
                    )
                    assert r["source_dtype"] == dtype
                    view = r["selected_view"]
                    pointer = source["data_ptr"] + block * strides[0] * element
                    assert (
                        view["shape"] == r["shape"]
                        and view["stride"] == strides[1:]
                        and view["dtype"] == dtype
                        and view["format"] == 2
                    )
                    assert (
                        view["data_ptr"] == pointer
                        and view["storage_ptr"] == source["storage_ptr"]
                    )
                    assert (
                        view["storage_offset"]
                        == source["storage_offset"] + block * strides[0]
                    )
                    assert (
                        view["storage_nbytes"] == source["storage_nbytes"]
                        and view["element_size"] == element
                    )
                    assert view["nbytes"] == value.size * element
                    target_ranges.append(
                        {
                            "logical_key": key,
                            "segment_index": pos,
                            "start": pointer,
                            "end": pointer + view["nbytes"],
                        }
                    )
                    parts.append(value)
                    identities.append(r["sha256"])
                    cursor = end
                assert cursor == shape[0]
                values = parts[0] if len(parts) == 1 else np.concatenate(parts, axis=0)
                results[rank][key] = (values, logical, identities)
            for row in owner.values():
                if row["target"]:
                    continue
                for source in cache["cache_tensors"]:
                    for block in row["groups"][gid]["logical_block_ids"]:
                        assert 0 <= block < source["shape"][0]
                        start = (
                            source["data_ptr"]
                            + block * source["stride"][0] * source["element_size"]
                        )
                        other_ranges.append(
                            {
                                "runner": "owner",
                                "request_id": row["request_id"],
                                "layer_index": index,
                                "start": start,
                                "end": start
                                + source["stride"][0] * source["element_size"],
                            }
                        )
            start, end = batch_target["token_start"], batch_target["token_end"]
            offset = int(role == "native")
            entries = (
                {
                    "gdn-state-index": [blocks[0]],
                    "gdn-non-spec-index": [blocks[0]],
                    "gdn-conv-index": [[blocks[0]]],
                    "gdn-prefill-flag": [False],
                    "gdn-conv-flag": [False],
                    "gdn-query": [start, end],
                    "gdn-prefill-query": [start - offset, end - offset],
                }
                if linear
                else {
                    "kv-block-table": [blocks[: (1340 + bs - 1) // bs]],
                    "kv-slot-mapping": [
                        blocks[p // bs] * bs + p % bs for p in range(1340)
                    ],
                }
            )
            for name, value in entries.items():
                key = f"group-{gid:02d}-{name}"
                if key in expected_meta:
                    assert expected_meta[key] == (gid, name, value)
                expected_meta[key] = (gid, name, value)
        assert canonical_rows(target_ranges) == canonical_rows(
            ownership["target_ranges"]
        )
        assert canonical_rows(other_ranges) == canonical_rows(ownership["other_ranges"])
        for i, interval in enumerate(target_ranges):
            assert interval["start"] < interval["end"]
            assert all(
                max(interval["start"], other["start"])
                >= min(interval["end"], other["end"])
                for other in target_ranges[i + 1 :] + other_ranges
            )
        metadata = {k: r for k, r in records.items() if r["kind"] == "metadata"}
        assert set(metadata) == set(expected_meta) and used | set(metadata) == set(
            records
        )
        assert (
            len(used) == receipt["captured_segment_count"]
            and len(metadata) == receipt["metadata_tensor_count"]
        )
        for key, (gid, name, expected) in expected_meta.items():
            r = records[key]
            dtype = "bool" if name.endswith("-flag") else "int32"
            assert r["cache_group_id"] == gid and r["mapping"] == name
            assert r["source_dtype"] == "torch." + dtype and r["stored_dtype"] == dtype
            assert r["expected_values"] == expected and np.array_equal(
                loaded[key], np.asarray(expected)
            )
        assert {r["key"] for r in receipt["mapping_checks"]} == set(metadata)
        assert all(r["exact_match"] is True for r in receipt["mapping_checks"])
        assert (
            sum(records[k]["selected_view"]["nbytes"] for k in used)
            == receipt["state_clone_bytes"]
        )
        assert (
            sum(records[k]["selected_view"]["nbytes"] for k in metadata)
            == receipt["metadata_clone_bytes"]
        )
        checks[rank] = {
            "logical_states": 80,
            "state_segments": len(used),
            "metadata_files": len(metadata),
            "manifest_sha256": sha(manifest),
            "target_owned_intervals": len(target_ranges),
            "other_request_intervals": len(other_ranges),
            "stream": stream,
            "restored_slots": 2,
        }
    assert {p.name for p in directory.iterdir()} == expected_files
    return results, checks


def verify(analysis):
    new = {
        role: BUNDLE / "runs-v1" / f"{role}-peer-p-state-observed-v1-01"
        for role in ("native", "prefix")
    }
    controllers = {role: terminal(path) for role, path in new.items()}
    # All new controllers must be terminal before reading either child or tensor.
    primary = json.loads(analysis.read_text())
    assert primary["passed"] and primary["localization_allowed"]
    import_path = BUNDLE / "root-import-preflight-v1/bindings.json"
    assert (
        sha(import_path)
        == "80e50f695b60e3bfcd748eee126342c2e31902e5a2779079619c76251c4aba5c"
    )
    imported = json.loads(import_path.read_text())
    assert imported["passed"] and imported["npu_python_initialized_flag"] is False
    for binding in imported["bindings"].values():
        assert binding["identity_matches_expected"] and not binding["unwrapped"]
        assert sha(Path(binding["path"])) == binding["sha256"]
    references = json.loads((BUNDLE / "control-references-v1.json").read_text())
    observations, vectors, prefixes, layers, installations, state_checks = (
        {},
        {},
        {},
        {},
        {},
        {},
    )
    freeze_path = BUNDLE / "freeze-manifest-v1.json"
    assert (
        sha(freeze_path)
        == "b7bb84338f917c5048cf84f444769ad4636452137c62c240f45c297e59cd4977"
    )
    frozen = json.loads(freeze_path.read_text())
    assert len(frozen["files"]) == 25
    for name, digest in frozen["files"].items():
        assert sha(BUNDLE / name) == digest
        for role, path in new.items():
            assert controllers[role]["files"] == frozen["files"]
            assert sha(path / "producer" / name) == digest
    for role, path in new.items():
        control = Path(references["attempts"][role + "-observed"]["directory"])
        terminal(control)
        current, old = core.load_attempt(path), core.load_attempt(control)
        assert current["public"]["included_in_numerical_comparisons"]
        assert old["public"]["included_in_numerical_comparisons"]
        observations[role] = current
        module_sha = sha(path / "producer/state_capture_v1.py")
        assert module_sha == controllers[role]["files"]["state_capture_v1.py"]
        installations[role] = check_installations(
            current["report"], module_sha, imported
        )
        plan = current["report"]["plan"]
        for field in ("plan", "sources", "launch_config"):
            assert current["report"][field] == old["report"][field]
        expected = {
            (case["case_id"], position - 1)
            for case in plan["cases"]
            for position in plan["capture_token_indices_one_based"]
        }
        assert len(expected) == 80
        for value in (current, old):
            assert {
                k for k, v in value["decisions"].items() if v["receipt"]
            } == expected
        vectors[role] = []
        for case, index in sorted(expected):
            a, b = [v["decisions"][(case, index)] for v in (current, old)]
            x, y = [
                array(
                    p / "results/worker-observations" / v["receipt"]["file"],
                    v["receipt"],
                    [plan["expected_vocabulary_size"]],
                )
                for p, v in zip((path, control), (a, b))
            ]
            assert x.tobytes() == y.tobytes()
            assert a["semantic_batch"] == b["semantic_batch"]
            assert a["batch_descriptor"] is not None
            assert a["batch_descriptor"] == b["batch_descriptor"]
            for field in (
                "prompt_token_ids",
                "output_prefix_token_ids",
                "sampled_token_ids",
            ):
                assert a["row"][field] == b["row"][field]
            vectors[role].append(
                {
                    "case_id": case,
                    "position_one_based": index + 1,
                    "sha256": a["receipt"]["sha256"],
                }
            )
        assert set(current["prefixes"]) == set(old["prefixes"])
        prefixes[role] = {}
        for case, value in current["prefixes"].items():
            assert (
                value["output_token_ids"] == old["prefixes"][case]["output_token_ids"]
            )
            prefixes[role][case] = len(value["output_token_ids"])
        layers[role], state_checks[role] = check_states(path, current["report"], role)
    bplain = Path(references["attempts"]["b-plain"]["directory"])
    terminal(bplain)
    bp = json.loads((bplain / "results/run.json").read_text())["prefixes_before_abort"]
    assert all(
        v["output_token_ids"] == bp[k]["output_token_ids"]
        for k, v in observations["prefix"]["prefixes"].items()
    )
    reported = {r["rank"]: r for r in primary["rank_comparisons"]}
    compared = []
    for rank in range(4):
        assert (
            set(layers["native"][rank])
            == set(layers["prefix"][rank])
            == set(reported[rank]["tensors"])
        )
        rank_results = []
        for key in sorted(layers["native"][rank]):
            (x, a, ah), (y, b, bh) = (
                layers["native"][rank][key],
                layers["prefix"][rank][key],
            )
            for field in (
                "key",
                "layer_index",
                "state_kind",
                "layer_name",
                "shape",
                "source_dtype",
                "stored_dtype",
            ):
                assert a[field] == b[field]
            assert x.shape == y.shape and x.dtype == y.dtype == np.float32
            unequal = np.flatnonzero(x != y)
            xb, yb = x.tobytes(order="C"), y.tobytes(order="C")
            byte_diff = np.flatnonzero(
                np.frombuffer(xb, np.uint8) != np.frombuffer(yb, np.uint8)
            )
            delta = x.astype(np.float64) - y.astype(np.float64)
            metrics = {
                "elements": int(x.size),
                "unequal_entries": int(unequal.size),
                "canonical_value_bytes_equal": xb == yb,
                "first_difference_index": list(
                    map(int, np.unravel_index(unequal[0], x.shape))
                )
                if unequal.size
                else None,
                "first_byte_difference_offset": int(byte_diff[0])
                if byte_diff.size
                else None,
                "max_abs_delta": float(np.abs(delta).max()),
                "rms_delta": float(np.sqrt(np.mean(delta * delta))),
                "all_finite": True,
                "left_canonical_sha256": hashlib.sha256(xb).hexdigest(),
                "right_canonical_sha256": hashlib.sha256(yb).hexdigest(),
            }
            reference = reported[rank]["tensors"][key]
            for field, value in metrics.items():
                assert reference[field] == value, (rank, key, field)
            result = {
                "rank": rank,
                "key": key,
                **metrics,
                "left_segment_sha256": ah,
                "right_segment_sha256": bh,
            }
            rank_results.append(result)
            compared.append(result)
        assert reported[rank]["first_numeric_differing_key"] == next(
            (r["key"] for r in rank_results if r["unequal_entries"]), None
        )
        assert reported[rank]["first_byte_differing_key"] == next(
            (r["key"] for r in rank_results if not r["canonical_value_bytes_equal"]),
            None,
        )
    assert len(compared) == 320
    return {
        "passed": True,
        "script_sha256": sha(Path(__file__)),
        "scope": "Independent original NPY/metadata/owner mapping and primary-metric comparison. Post-P persistent state only; no answer repair, first faulty operator, or performance qualification.",
        "primary_analysis": {"path": str(analysis), "sha256": sha(analysis)},
        "freeze_manifest_sha256": sha(freeze_path),
        "current_children": {
            role: sha(path / "results/run.json") for role, path in new.items()
        },
        "current_controller_terminals": {
            role: value["finished_at"] for role, value in controllers.items()
        },
        "full_vocabulary_vectors": vectors,
        "full_prefix_lengths": prefixes,
        "runtime_import_bindings_sha256": sha(import_path),
        "installation_and_source_checks": installations,
        "state_mapping_and_restore_checks": state_checks,
        "b_plain_prefix_equal": True,
        "logical_state_pairs": compared,
        "restored_slots_per_rank": 2,
        "all320_numeric_equal": all(r["unequal_entries"] == 0 for r in compared),
        "all320_canonical_bytes_equal": all(
            r["canonical_value_bytes_equal"] for r in compared
        ),
        "first_differing_state_in_rank_key_order": next(
            (
                {"rank": r["rank"], "key": r["key"]}
                for r in compared
                if r["unequal_entries"]
            ),
            None,
        ),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), "Preserve prior output"
    result = verify(args.analysis)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "passed": True,
                "output": str(args.output),
                "sha256": sha(args.output),
                "all320_numeric_equal": result["all320_numeric_equal"],
            }
        )
    )
