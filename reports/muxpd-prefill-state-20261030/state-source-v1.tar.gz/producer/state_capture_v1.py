"""Read-only target-P persistent states; no imports/patches on module import.

Two owner hooks preserve all model/operator calls and original return objects.
Same-role 80-logit/eight-prefix controls remain mandatory for attribution.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import math
import operator
import os
from pathlib import Path

ATTRIBUTE = "_muxpd_state_capture_v1"
_MISSING = object()
MAX_CLONE_BYTES = 256 * 1024 * 1024
MAX_METADATA_BYTES = 1024 * 1024
EXPECTED_STATE_BYTES = 29818880
CAPTURE_PROFILE_SHA256 = (
    "4d036ab421c11fba996a88bea6bdd05e2c8ca7839722b358084d4850335f8fe3"
)
EXPECTED_KEYS = frozenset(
    f"layer-{i:02d}-{kind}"
    for i in range(40)
    for kind in (("key", "value") if i % 4 == 3 else ("conv", "recurrent"))
)
SOURCE_FILES = {
    "/root/workspace/vllm-hust/vllm/v1/attention/backend.py": "5c0a767708b20c44b8267268f904976e39bd52c9c84ac0b69a048e5d1b7d7e50",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/patch/worker/patch_qwen3_5.py": "97ff11df1d7db0930d5742cfc6020e5ec425064bd37ea5d17e5089712f5fcdae",
    "/root/workspace/vllm-hust/vllm/model_executor/models/qwen3_5.py": "5f47ae4f4a08d0a78dd681d58b290f3298744c73a82f1349f3e2853469ef73e6",
    "/root/workspace/vllm-hust/vllm/model_executor/models/qwen3_next.py": "b0e0b96d08329e7ad91756eb67e8c4a9ad19ac0a38cbebbc3fbf13716ec424cd",
    "/root/workspace/vllm-hust/vllm/model_executor/layers/mamba/gdn/base.py": "7fec748fc74131f5a45bcaf2644b3fa3a0598fd437d7347f8207ea3644a951c5",
    "/root/workspace/vllm-hust/vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py": "97faa7eeb0c2a3ea0c51330a45c038d8c644c57da52946692168019585c6cee6",
    "/root/workspace/vllm-hust/vllm/model_executor/layers/mamba/mamba_utils.py": "9aa40a17f77b29915b6df5098b8efc62f1a16511d5ca80d06ea5f2cbb8fde71a",
    "/root/workspace/vllm-hust/vllm/model_executor/models/config.py": "c7cf2bea1f12ea978b28d2459d865f40b4896d747c94c5485e96d4bb5dc8cbcc",
    "/root/workspace/vllm-hust/vllm/model_executor/layers/attention/attention.py": "ebf418e644fb41ae89d2f7905dd87f7b028411ab1fe54b4c980d7ab4782f930c",
    "/root/workspace/vllm-hust/vllm/v1/attention/backends/utils.py": "192e6b5df24ff52ae57a6a23d6cf58d1b4dd34f14c9283ce268e5f88b1123b96",
    "/root/workspace/vllm-hust/vllm/v1/worker/block_table.py": "b3a6649b968fba0b48c333d7ac96e65cc713a86133cc7eef0a8399f5339ec600",
    "/root/workspace/vllm-hust/vllm/v1/worker/utils.py": "36cae980896d5607ce238606ec6c053eff17b7597a0c9185549f94583c1b9de6",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/ops/gdn.py": "8c349f68d37bede53ebe4771ac0ffd4396896f11473627446ab71f782a01eb71",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/ops/gdn_attn_builder.py": "af181fdd860d221bf7d35512c26c265559e11f111ea97484a0bba68ae2fa6458",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/attention/attention_v1.py": "96d36dbd87fd422b8a4928b136b334209510cd321e0d7d2b2e5bdd7a3e259d9e",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/device/device_op.py": "a0288fca27ce4fb24d67cf5c2e677fcfc71f02b56c311a31a81a496e41be8435",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/worker/model_runner_v1.py": "2c188ee04a4eb1c3b4f3bff9d5f3c4e4c69dddc4e0ed39137b09675420765463",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/worker/block_table.py": "47b3ec1a19283ecc81bfebaf9c3b39af74e8a0dc8b2a1ed3fd0923f25f84daa7",
    "/root/workspace/vllm-ascend-hust/vllm_ascend/utils.py": "c21e2fbb6d04da43f7490c418a5a19e53f2ff5aff9f068f8fa4f1ad0f7d81593",
    "/root/workspace/vllm-ascend-hust/csrc/torch_binding.cpp": "c7462699459acb6ebd423aaac7197f0b6a3cac9766ed7b193308efe95254f27c",
    "/root/workspace/vllm-ascend-hust/csrc/aclnn_torch_adapter/op_api_common.h": "0d0dc34a02151b72fc8e50000fd1c2db948fbe8a4090c5c6eaae8dc229e12cbb",
    "/root/workspace/muxpd-composite-token-logits/src/vllm_muxpd/worker.py": "3b555dc5e46f8c2d2d23f00dbbe84db4e7baadf5378b9df686ffc4e7b661bbb3",
    "/root/workspace/muxpd-composite-token-logits/src/vllm_muxpd/overlap.py": "418199e194a1743101604ebddb826e33a166a41abfdd6a2032a25ce6179fd45b",
    "/root/workspace/muxpd-composite-token-logits/src/vllm_muxpd/decode_graph.py": "32c31673985d1d66828caecfa09ce03a5930db18fd2d2ed27c798928ee29f724",
    "/usr/local/python3.12.13/lib/python3.12/site-packages/torch_npu/npu/_format.py": "8abe7bea6817f25d2360aee783afae16fe7fe2aaa46a04e7b7b865e7f2039488",
    "/usr/local/python3.12.13/lib/python3.12/site-packages/torch_npu/utils/custom_ops.py": "5d40c778a341928e294c22085843730823128a3256569da2aa3841e8a3f43f9e",
}


def _unwrap(argument):
    try:
        return object.__getattribute__(argument, "worker")
    except AttributeError:
        return argument


def _ints(values, count=None):
    device = getattr(values, "device", None)
    if device is not None and str(device) != "cpu":
        raise RuntimeError("Layer capture refuses device metadata reads")
    selected = values if count is None else values[:count]
    result = [operator.index(value) for value in selected]
    if count is not None and len(result) != count:
        raise RuntimeError("Layer capture CPU metadata length mismatch")
    return result


def _digest(tokens):
    return hashlib.sha256(
        json.dumps(_ints(tokens), separators=(",", ":")).encode()
    ).hexdigest()


def verify_source_files():
    for path, expected in SOURCE_FILES.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise RuntimeError("Frozen survey source changed: " + path)
    return dict(SOURCE_FILES)


def original_bound(owner, name, function):
    value = getattr(owner, name)
    if (
        getattr(value, "__self__", None) is not owner
        or getattr(value, "__func__", None) is not function
        or inspect.unwrap(function) is not function
    ):
        raise RuntimeError("Survey requires original bound method: " + name)
    path = str(Path(inspect.getsourcefile(function)).resolve())
    if path not in SOURCE_FILES:
        raise RuntimeError("Unbound function source: " + name)
    return {
        "module": function.__module__,
        "qualname": function.__qualname__,
        "path": path,
        "sha256": SOURCE_FILES[path],
        "unwrapped": False,
    }


def validate_capture_profile(expected_cases, supplied):
    """Bind caller metadata to this module's frozen sidecar and original plan."""
    path = Path(__file__).with_name("capture-profile-v1.json")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != CAPTURE_PROFILE_SHA256:
        raise RuntimeError("Worker capture profile SHA differs from frozen sidecar")
    profile = json.loads(raw)
    canonical = lambda value: json.dumps(value, sort_keys=True, separators=(",", ":"))
    if canonical(supplied) != canonical(profile):
        raise ValueError("Caller capture profile differs from worker frozen profile")
    source = profile["source_plan"]
    plan_path = Path(source["path"])
    if not plan_path.is_absolute() or plan_path.resolve(strict=True) != plan_path:
        raise RuntimeError("Capture profile plan path must be canonical/absolute")
    plan_bytes = plan_path.read_bytes()
    if hashlib.sha256(plan_bytes).hexdigest() != source["sha256"]:
        raise RuntimeError("Capture profile original plan SHA differs")
    plan = json.loads(plan_bytes)
    plan_payload = {key: value for key, value in plan.items() if key != "plan_sha256"}
    if (
        hashlib.sha256(canonical(plan_payload).encode()).hexdigest()
        != plan["plan_sha256"]
        or source["plan_sha256"] != plan["plan_sha256"]
        or source["quality_plan_semantic_sha256"]
        != plan["quality_plan_semantic_sha256"]
    ):
        raise RuntimeError("Capture profile semantic plan identity differs")
    if canonical(expected_cases) != canonical(plan["cases"]):
        raise ValueError("Capture expected cases differ from frozen plan tokens/order")
    ordered = [case["case_id"] for case in plan["cases"]]
    lengths = {case["case_id"]: len(case["prompt_token_ids"]) for case in plan["cases"]}
    hashes = {
        case["case_id"]: _digest(case["prompt_token_ids"]) for case in plan["cases"]
    }
    seed, target = plan["batch"]["seed_case_id"], plan["target_case_id"]
    if (
        profile["schema"] != "muxpd-target-peer-p-state-profile-v1"
        or len(ordered) != 8
        or len(set(ordered)) != 8
        or ordered != plan["batch"]["case_ids"]
        or seed != ordered[0]
        or target not in ordered[1:]
        or profile["ordered_case_ids"] != ordered
        or profile["seed_case_id"] != seed
        or profile["target_case_id"] != target
        or profile["batch_id"] != plan["batch"]["batch_id"]
        or profile["prompt_lengths"] != lengths
        or profile["prompt_sha256"] != hashes
        or profile["target_tokens"] != lengths[target]
        or profile["prefill_tokens"] != sum(lengths[rid] for rid in ordered[1:])
        or profile["capture_layer_indices"] != list(range(40))
        or profile["capture_tensor_count"] != 80
        or profile["installed_hook_count"] != 2
        or profile["hidden_size"] != 2048
        or profile["metadata_clone_limit_bytes"] != MAX_METADATA_BYTES
        or profile["capture_kinds"]
        != {
            "linear_attention": ["conv", "recurrent"],
            "full_attention": ["key", "value"],
        }
        or profile["expected_clone_bytes"] != EXPECTED_STATE_BYTES
        or profile["required_vectors_per_role"] != plan["maximum_full_vectors"]
        or profile["target_generated_tokens"] != plan["target_generated_tokens"]
        or profile["capture_token_indices_one_based"]
        != plan["capture_token_indices_one_based"]
    ):
        raise ValueError("Capture profile does not derive from its frozen plan")
    return profile


def expand_block_ids(physical_ids, physical_size, logical_size):
    if physical_size <= 0 or logical_size <= 0 or physical_size % logical_size:
        raise RuntimeError("Invalid physical/logical block sizes")
    ratio = physical_size // logical_size
    values = _ints(physical_ids)
    if any(v < 0 for v in values) or len(set(values)) != len(values):
        raise RuntimeError("Invalid or duplicate physical blocks")
    return [v * ratio + part for v in values for part in range(ratio)]


def kv_segment_plan(blocks, block_size, tokens):
    if tokens <= 0 or block_size <= 0 or len(blocks) < math.ceil(tokens / block_size):
        raise RuntimeError("Incomplete logical target block table")
    blocks = _ints(blocks[: math.ceil(tokens / block_size)])
    if len(set(blocks)) != len(blocks) or any(v < 0 for v in blocks):
        raise RuntimeError("Duplicate or invalid logical target blocks")
    result = []
    for i, block in enumerate(blocks):
        start, end = i * block_size, min(tokens, (i + 1) * block_size)
        result.append(
            {
                "block": block,
                "block_start": 0,
                "block_end": end - start,
                "position_start": start,
                "position_end": end,
            }
        )
    return result


def gdn_target_indices(role, row, num_decodes, num_prefills, num_spec_decodes):
    if (
        role not in ("native", "prefill")
        or num_decodes != int(role == "native")
        or num_prefills != 7
        or num_spec_decodes != 0
        or row - num_decodes != 2
    ):
        raise RuntimeError("GDN mixed row/prefill ordinal differs from target plan")
    return {"conv_row": row, "prefill_ordinal": row - num_decodes}


def validate_metadata_array(record, array):
    import numpy as np

    dtype = {"torch.int32": "int32", "torch.int64": "int64", "torch.bool": "bool"}.get(
        record["source_dtype"]
    )
    if (
        dtype is None
        or str(array.dtype) != dtype
        or list(array.shape) != record["shape"]
    ):
        raise RuntimeError("Device metadata dtype/shape changed during export")
    expected = np.asarray(record["expected_values"], dtype=dtype)
    if expected.shape != array.shape or not np.array_equal(expected, array):
        raise RuntimeError("Actual device mapping differs from CPU target derivation")


def validate_no_overlap(target, other):
    for i, row in enumerate(target):
        if row["start"] >= row["end"]:
            raise RuntimeError("Invalid selected storage interval")
        for candidate in target[i + 1 :] + other:
            if max(row["start"], candidate["start"]) < min(
                row["end"], candidate["end"]
            ):
                raise RuntimeError("Target state storage overlap: " + str(candidate))


def validate_tensor_layout(info, shape, stride, dtype):
    if (
        info["shape"] != shape
        or info["stride"] != stride
        or info["dtype"] != dtype
        or not info["device"].startswith("npu")
        or info["format"] != 2
    ):
        raise RuntimeError("State tensor shape/stride/dtype/ND format differs")
    if (
        info["nbytes"] != math.prod(shape) * info["element_size"]
        or info["data_ptr"]
        != info["storage_ptr"] + info["storage_offset"] * info["element_size"]
        or info["storage_offset"] < 0
        or info["storage_offset"] * info["element_size"] + info["nbytes"]
        > info["storage_nbytes"]
    ):
        raise RuntimeError("State selected storage bounds differ")


def validate_stream_receipt(row):
    if (
        row["context_python_id"] is None
        or row["stream_id"] != row["expected_stream_id"]
        or (
            (row["expected_lane"] == "prefill" or row["ascend_stream_id"] is not None)
            and row["ascend_stream_id"] != row["stream_id"]
        )
        or row["lane"] != row["expected_lane"]
        or row["cudagraph_mode"] != "NONE"
        or row["capturing"]
        or row["enable_enpu"]
        or row["flash_comm_v1_enabled"]
        or not row["device"].startswith("npu")
        or row["device"] != row["expected_device"]
    ):
        raise RuntimeError("Target owner stream/context/graph mode differs")


def validate_decoder_attention_type(value, enum_type):
    if type(value) is not enum_type or value != enum_type.DECODER:
        raise RuntimeError("Actual attention type is not decoder Enum")
    return {
        "type": type(value).__module__ + "." + type(value).__qualname__,
        "name": value.name,
        "value": value.value,
    }


def function_receipt(function):
    function = getattr(function, "__func__", function)
    path = str(Path(inspect.getsourcefile(function)).resolve())
    if path not in SOURCE_FILES or inspect.unwrap(function) is not function:
        raise RuntimeError("Unknown or wrapped state producer source")
    return {
        "module": function.__module__,
        "qualname": function.__qualname__,
        "path": path,
        "sha256": SOURCE_FILES[path],
        "unwrapped": False,
    }


class TorchRuntime:
    def __init__(self):
        import torch
        import torch_npu
        from vllm.forward_context import get_forward_context

        self.torch, self.torch_npu, self.context = torch, torch_npu, get_forward_context

    def tensor_info(self, tensor):
        storage = tensor.untyped_storage()
        return {
            "shape": list(tensor.shape),
            "stride": list(tensor.stride()),
            "dtype": str(tensor.dtype),
            "device": str(tensor.device),
            "format": int(self.torch_npu.get_npu_format(tensor)),
            "data_ptr": tensor.data_ptr(),
            "storage_ptr": storage.data_ptr(),
            "storage_offset": tensor.storage_offset(),
            "storage_nbytes": storage.nbytes(),
            "element_size": tensor.element_size(),
            "nbytes": tensor.numel() * tensor.element_size(),
        }

    def stream_receipt(self, worker, context):
        from vllm_ascend import utils

        stream = self.torch.npu.current_stream()
        prefill = getattr(worker, "decode_runner", None) is not None
        backend = getattr(worker, "_execution_backend", None)
        expected = worker._streams["prefill"] if prefill else stream
        cached = utils._CURRENT_STREAM
        result = {
            "context_python_id": id(context) if context is not None else None,
            "stream_id": stream.stream_id,
            "npu_stream": int(stream.npu_stream),
            "device": str(stream.device),
            "expected_device": str(worker.device),
            "ascend_stream_id": getattr(cached, "stream_id", None),
            "lane": backend.active_lane if prefill else None,
            "expected_lane": "prefill" if prefill else None,
            "expected_stream_id": expected.stream_id,
            "cudagraph_mode": getattr(context.cudagraph_runtime_mode, "name", None),
            "capturing": bool(getattr(context, "capturing", False)),
            "enable_enpu": bool(worker.model_runner.enable_enpu),
            "flash_comm_v1_enabled": bool(context.flash_comm_v1_enabled),
        }
        validate_stream_receipt(result)
        return result

    def clone(self, tensor):
        stream = self.torch.npu.current_stream()
        value = tensor.detach().clone()
        event = self.torch.npu.Event()
        event.record(stream)
        return value, event

    @staticmethod
    def wait(event):
        event.synchronize()

    @staticmethod
    def to_numpy(clone, *, metadata):
        return (clone if metadata else clone.float()).cpu().numpy()

    def installation_receipts(self, worker, layers):
        from vllm.model_executor.layers.mamba.gdn.base import GatedDeltaNetAttention
        from vllm.model_executor.layers.mamba.gdn.qwen_gdn_linear_attn import (
            QwenGatedDeltaNetAttention,
        )
        from vllm.model_executor.models.qwen3_5 import Qwen3_5DecoderLayer
        from vllm.v1.attention.backend import AttentionType
        from vllm_ascend.attention.attention_v1 import AscendAttentionBackendImpl
        from vllm_ascend.device.device_op import BaseDeviceAdaptor, DeviceOperator
        from vllm_ascend.ops.gdn import AscendGatedDeltaNetAttention as AGDN
        from vllm_ascend.ops.gdn_attn_builder import AscendGDNAttentionMetadataBuilder
        from vllm_ascend.patch.worker import patch_qwen3_5 as patch
        from vllm_ascend.worker.model_runner_v1 import NPUModelRunner

        if (
            os.environ.get("VLLM_VERSION") != "0.25.1"
            or not patch._IS_VLLM_RELEASE
            or DeviceOperator is not BaseDeviceAdaptor
        ):
            raise RuntimeError(
                "State observer requires actual A2/0.25.1 installed bindings"
            )
        files = verify_source_files()
        if len(layers) != 40:
            raise RuntimeError("State observer requires exactly forty decoder layers")
        modules = []
        registry = worker.vllm_config.compilation_config.static_forward_context
        for i, layer in enumerate(layers):
            if (
                type(layer) is not Qwen3_5DecoderLayer
                or layer.layer_idx != i
                or layer.layer_scale
            ):
                raise RuntimeError("Decoder architecture differs")
            bindings = {
                "decoder_forward": original_bound(
                    layer, "forward", patch.AscendQwen3_5DecoderLayer.forward
                )
            }
            kind = "full_attention" if i % 4 == 3 else "linear_attention"
            if layer.layer_type != kind:
                raise RuntimeError("State layer type/order differs")
            attention_type = None
            if kind == "linear_attention":
                node = layer.linear_attn
                if (
                    type(node) is not QwenGatedDeltaNetAttention
                    or node.tp_size != 4
                    or node.num_spec != 0
                ):
                    raise RuntimeError("GDN instance/TP/speculation differs")
                expected = {
                    "forward": AGDN.forward,
                    "_forward_core": AGDN._forward_core,
                    "get_state_shape": AGDN.get_state_shape,
                    "get_attn_backend": AGDN.get_attn_backend,
                    "get_state_dtype": GatedDeltaNetAttention.get_state_dtype,
                }
                bindings.update(
                    {
                        name: original_bound(node, name, fn)
                        for name, fn in expected.items()
                    }
                )
                if tuple(node.get_state_shape()) != ((3, 2048), (8, 128, 128)) or tuple(
                    map(str, node.get_state_dtype())
                ) != ("torch.bfloat16", "torch.float32"):
                    raise RuntimeError("Actual GDN state shapes/dtypes differ")
                name = node.prefix
            else:
                node = layer.self_attn.attn
                attention_type = validate_decoder_attention_type(
                    node.impl.attn_type, AttentionType
                )
                if (
                    type(node.impl) is not AscendAttentionBackendImpl
                    or node.impl.kv_sharing_target_layer_name is not None
                    or node.impl.is_kv_producer
                    or node._k_scale_float != 1.0
                    or node._v_scale_float != 1.0
                    or node.impl.num_kv_heads != 1
                    or node.impl.head_size != 256
                    or node.impl.enable_c8_quant
                ):
                    raise RuntimeError("Full attention cache producer config differs")
                name = node.layer_name
                bindings.update(
                    {
                        "forward": original_bound(
                            node.impl, "forward", AscendAttentionBackendImpl.forward
                        ),
                        "reshape_and_cache": original_bound(
                            node.impl,
                            "reshape_and_cache",
                            AscendAttentionBackendImpl.reshape_and_cache,
                        ),
                    }
                )
            if registry.get(name) is not node:
                raise RuntimeError("State layer registry identity differs")
            modules.append(
                {
                    "index": i,
                    "kind": kind,
                    "layer_name": name,
                    "python_id": id(node),
                    "registry_identity": True,
                    "bindings": bindings,
                    "attention_type": attention_type,
                }
            )
        actual = inspect.unwrap(worker.model_runner._model_forward)
        if (
            getattr(actual, "__self__", None) is not worker.model_runner
            or getattr(actual, "__func__", None) is not NPUModelRunner._model_forward
        ):
            raise RuntimeError("Owner model forward no longer wraps original runner")
        formatter = self.torch_npu.get_npu_format
        if (
            inspect.getclosurevars(formatter).nonlocals.get("orig_get_format")
            is not self.torch.ops.npu.get_npu_format
            or int(self.torch_npu.Format.ND) != 2
        ):
            raise RuntimeError("Actual NPU format reader differs")
        return {
            "source_files": files,
            "runtime_vllm_version": "0.25.1",
            "ascend_release_patch_active": True,
            "cpu_fixture_only": False,
            "modules": modules,
            "runtime_bindings": {
                "runner_forward": function_receipt(actual),
                "gdn_builder_build": function_receipt(
                    AscendGDNAttentionMetadataBuilder.build
                ),
                "gdn_builder_attach_prefill": function_receipt(
                    AscendGDNAttentionMetadataBuilder._attach_non_spec_prefill_metadata
                ),
                "device_reshape_and_cache": function_receipt(
                    DeviceOperator.reshape_and_cache
                ),
                "npu_format": function_receipt(formatter),
            },
        }


class StateCapture:
    def __init__(self, worker, expected_cases, directory, runtime, capture_profile):
        self.capture_profile = validate_capture_profile(expected_cases, capture_profile)
        self.target_id = self.capture_profile["target_case_id"]
        self.seed_id = self.capture_profile["seed_case_id"]
        self.peer_order = self.capture_profile["ordered_case_ids"][1:]
        self.peer_ids = frozenset(self.peer_order)
        self.worker, self.runner, self.runtime = worker, worker.model_runner, runtime
        self.rank = int(worker.rank)
        self.role = (
            "prefill"
            if getattr(worker, "decode_runner", None) is not None
            else "native"
        )
        self.directory = Path(directory)
        if not self.directory.is_absolute():
            raise ValueError("Layer capture requires an absolute directory")
        self.expected = {}
        for case in expected_cases:
            digest = _digest(case["prompt_token_ids"])
            if digest in self.expected:
                raise ValueError("Frozen prompts must be distinct")
            self.expected[digest] = {
                "case_id": case["case_id"],
                "tokens": len(case["prompt_token_ids"]),
            }
            if case["case_id"] == self.target_id:
                self.target_tokens = _ints(case["prompt_token_ids"])
        if (
            len(self.expected) != 8
            or len(self.target_tokens) != self.capture_profile["target_tokens"]
        ):
            raise ValueError("Layer capture requires the worker-frozen peer-P profile")
        self.directory.mkdir(parents=True, exist_ok=True)
        self.context = None
        self.batch = None
        self.forward_count = 0
        self.forward_finished = False
        self.flush_count = 0
        self.pending = []
        self.keys = set()
        self.clone_bytes = 0
        self.captured_calls = {}
        self.original_calls = {}
        self.files = []
        self.patches = []
        self.error = None
        self.installation_count = 1
        self.manifest = None

        self.original_instance_slots = []
        self.uninstall_receipt = None
        self.restored_count = 0
        self.discarded_pending_count = 0
        self.discard_event_waits = 0
        self.state = "WAIT_P"
        self.source_guards = None
        self.bindings = []
        self.logical_tensors = []
        self.mapping_checks = []
        self.stream_receipts = {}
        self.cache_ownership = {}
        self.state_clone_bytes = 0
        self.metadata_clone_bytes = 0
        self.owner_forward_original_returned = False

    def _patch(self, owner, name, factory):
        original = getattr(owner, name)
        wrapper = factory(original)
        self.original_instance_slots.append(vars(owner).get(name, _MISSING))
        setattr(owner, name, wrapper)
        self.patches.append((owner, name, original, wrapper))

    def _idle_receipt(self):
        runners = {"owner": self.runner}
        decode = getattr(self.worker, "decode_runner", None)
        if decode is not None:
            runners["decode"] = decode
        rows = {}
        for name, runner in runners.items():
            batch = runner.input_batch
            rows[name] = {
                "request_count": len(runner.requests),
                "num_reqs": int(batch.num_reqs),
                "mapped_request_count": len(batch.req_id_to_index),
                "nonempty_row_count": sum(rid is not None for rid in batch.req_ids),
                "execute_pending": getattr(runner, "execute_model_state", None)
                is not None,
            }
        receipt = {
            "forward_active": self.context is not None,
            "prefill_task_present": getattr(self.worker, "_prefill_task", None)
            is not None,
            "awaiting_sample": bool(getattr(self.worker, "_awaiting_sample", False)),
            "pending_lanes": list(getattr(self.worker, "_pending_lanes", ())),
            "runners": rows,
        }
        receipt["idle"] = not (
            receipt["forward_active"]
            or receipt["prefill_task_present"]
            or receipt["awaiting_sample"]
            or receipt["pending_lanes"]
            or any(any(row.values()) for row in rows.values())
        )
        return receipt

    def _originals_restored(self):
        return all(
            (
                name not in vars(owner) and getattr(owner, name) == original
                if slot is _MISSING
                else vars(owner).get(name, _MISSING) is slot
            )
            for (owner, name, original, _), slot in zip(
                self.patches, self.original_instance_slots
            )
        )

    def _graph_ownership(self):
        controller = getattr(self.worker, "_decode_graph_controller", None)
        if controller is None:
            return {
                "controller_present": False,
                "all_graph_patches_owned": None,
                "owner_forward_is_graph_wrapper": None,
            }
        patches = controller._patches
        owner_forward = [
            installed
            for target, name, _, installed in patches
            if target is self.runner and name == "_model_forward"
        ]
        return {
            "controller_present": True,
            "graph_patch_count": len(patches),
            "all_graph_patches_owned": bool(patches)
            and all(
                vars(target).get(name, _MISSING) is installed
                for target, name, _, installed in patches
            ),
            "owner_forward_is_graph_wrapper": len(owner_forward) == 1
            and vars(self.runner).get("_model_forward", _MISSING) is owner_forward[0],
        }

    def _batch_target(self):
        batch = self.runner.input_batch
        n = int(batch.num_reqs)
        ids = list(batch.req_ids[:n])
        if not ids or self.forward_count:
            return None
        rows = []
        for index, rid in enumerate(ids):
            request = self.runner.requests[rid]
            digest = _digest(request.prompt_token_ids)
            known = self.expected.get(digest)
            rows.append(
                {
                    "row": index,
                    "request_id": rid,
                    "prompt_sha256": digest,
                    "case_id": None if known is None else known["case_id"],
                    "output_prefix": _ints(request.output_token_ids),
                }
            )
        if not any(row["case_id"] in self.peer_ids for row in rows):
            return None
        qsl = _ints(self.runner.query_start_loc.cpu, n + 1)
        computed = _ints(batch.num_computed_tokens_cpu, n)
        schedule = self.runner._muxpd_numerical_observer.schedule[
            "num_scheduled_tokens"
        ]
        if set(schedule) != set(ids) or [qsl[i + 1] - qsl[i] for i in range(n)] != [
            schedule[rid] for rid in ids
        ]:
            raise RuntimeError("CPU query offsets disagree with the actual schedule")
        expected_order = (
            self.peer_order
            if self.role == "prefill"
            else self.capture_profile["ordered_case_ids"]
        )
        expected_ids = set(expected_order)
        if [row["case_id"] for row in rows] != expected_order:
            raise RuntimeError(
                "Actual peer-P request row order differs from frozen plan"
            )
        if (
            len(set(ids)) != n
            or {row["case_id"] for row in rows} != expected_ids
            or n != len(expected_ids)
            or qsl[0] != 0
            or qsl[-1]
            != self.capture_profile["prefill_tokens"] + int(self.role == "native")
        ):
            raise RuntimeError(
                "First peer P batch differs from original native/raw admission"
            )
        for row in rows:
            index = row["row"]
            length = qsl[index + 1] - qsl[index]
            row.update(
                num_computed_tokens=computed[index],
                scheduled_tokens=length,
                token_start=qsl[index],
                token_end=qsl[index + 1],
            )
            if row["case_id"] == self.seed_id:
                if (
                    length != 1
                    or computed[index]
                    != self.capture_profile["prompt_lengths"][self.seed_id]
                    or len(row["output_prefix"]) != 1
                ):
                    raise RuntimeError(
                        "Native mixed seed context differs from first D step"
                    )
            elif (
                computed[index] != 0
                or row["output_prefix"]
                or length != self.expected[row["prompt_sha256"]]["tokens"]
            ):
                raise RuntimeError("Peer capture requires complete untouched prompts")
        target = next(row for row in rows if row["case_id"] == self.target_id)
        expected_start = sum(
            1 if rid == self.seed_id else self.capture_profile["prompt_lengths"][rid]
            for rid in expected_order[: expected_order.index(self.target_id)]
        )
        if target["token_start"] != expected_start:
            raise RuntimeError("Target token offset differs from original batch order")
        start, end = target["token_start"], target["token_end"]
        packed = _ints(self.runner.input_ids.cpu[start:end])
        positions = _ints(self.runner._positions_np_buf[start:end])
        if packed != self.target_tokens or positions != list(
            range(self.capture_profile["target_tokens"])
        ):
            raise RuntimeError(
                "Packed target tokens/positions differ from the frozen prompt"
            )
        return {
            "rows": rows,
            "query_start_loc": qsl,
            "target": target,
            "total_tokens": qsl[-1],
            "num_reqs": n,
            "packed_target_input_sha256": _digest(packed),
            "packed_target_positions_sha256": _digest(positions),
            "packed_target_input_matches_prompt": True,
            "packed_target_positions_are_zero_based": True,
        }

    def _bookkeeping_wrapper(self, original):
        def wrapper(*args, **kwargs):
            # Installed after NativeSamplerObserver: native bookkeeping and
            # its final-logit copy/receipt complete before layer D2H begins.
            result = original(*args, **kwargs)
            if self.pending and not self.flush_count:
                try:
                    self._flush(result)
                except BaseException as exc:
                    self.error = f"{type(exc).__name__}: {exc}"
                    raise
            return result

        return wrapper

    def uninstall(self, *, allow_incomplete=False):
        """Restore only owned instance slots; report cleanup independently.

        A failed collection can release retained clones after abort has made
        both runners idle. Event failure retains clones and wrappers for a
        later safe retry. It never changes the original collection result.
        """
        receipt = {
            "schema": "muxpd-state-uninstall-v1",
            "rank": self.rank,
            "role": self.role,
            "installed_hook_count": len(self.patches),
            "allow_incomplete": allow_incomplete,
            "ok": False,
            "status": "failed",
            "error": None,
            "module_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "collection_error": self.error,
            "collection_forward_count": self.forward_count,
            "collection_flush_count": self.flush_count,
            "pending_before": len(self.pending),
        }
        try:
            if type(allow_incomplete) is not bool:
                raise ValueError("allow_incomplete must be a boolean")
            receipt["idle_state"] = self._idle_receipt()
            if not receipt["idle_state"]["idle"]:
                raise RuntimeError(
                    "Layer capture uninstall requires idle owner and decode runners"
                )
            complete = (
                self.forward_count == 1
                and self.forward_finished
                and self.flush_count == 1
                and not self.pending
                and self.error is None
                and self.keys == EXPECTED_KEYS
                and len(self.logical_tensors) == 80
                and self.state == "DONE"
                and self.manifest is not None
            )
            receipt["collection_complete"] = complete
            if not allow_incomplete and not complete:
                raise RuntimeError(
                    "Normal layer uninstall requires a complete flushed collection"
                )
            if self.uninstall_receipt is not None and self.uninstall_receipt["ok"]:
                if not self._originals_restored():
                    raise RuntimeError("Restored methods changed after layer uninstall")
                receipt["status"] = "already_uninstalled"
            else:
                # Check every slot before mutating any of them. A foreign
                # wrapper may retain ours; overwriting it is never safe.
                foreign = [
                    name
                    for owner, name, _, wrapper in self.patches
                    if vars(owner).get(name, _MISSING) is not wrapper
                ]
                receipt["foreign_slots"] = foreign
                if foreign:
                    raise RuntimeError(f"Layer hook changed externally: {foreign}")
                if self.pending:
                    if not allow_incomplete:
                        raise RuntimeError("Layer capture retains unflushed tensors")
                    for _, _, event in self.pending:
                        self.runtime.wait(event)
                        self.discard_event_waits += 1
                    self.discarded_pending_count += len(self.pending)
                    self.pending.clear()
                for (owner, name, _, _), slot in reversed(
                    list(zip(self.patches, self.original_instance_slots))
                ):
                    if slot is _MISSING:
                        delattr(owner, name)
                    else:
                        setattr(owner, name, slot)
                    self.restored_count += 1
                receipt["status"] = "uninstalled"
            if not self._originals_restored():
                raise RuntimeError(
                    "Layer capture did not restore original method slots"
                )
            graph = self._graph_ownership()
            if graph["controller_present"] and not (
                graph["all_graph_patches_owned"]
                and graph["owner_forward_is_graph_wrapper"]
            ):
                raise RuntimeError(
                    "Original decode-graph controller ownership was not restored"
                )
            receipt["ok"] = True
        except BaseException as exc:  # noqa: BLE001 -- retain a failed cleanup receipt
            receipt["error"] = f"{type(exc).__name__}: {exc}"
        receipt.update(
            restored_count=self.restored_count,
            all_originals_restored=self._originals_restored(),
            pending_after=len(self.pending),
            discarded_pending_count=self.discarded_pending_count,
            discard_event_wait_count=self.discard_event_waits,
            graph_ownership=self._graph_ownership(),
            collection_success_not_inferred_from_cleanup=True,
        )
        # This independent receipt does not alter files or collection error,
        # counts, or the terminal collection snapshot already returned to root.
        self.uninstall_receipt = json.loads(json.dumps(receipt))
        return self.uninstall_receipt

    def install(self, layers):
        self.source_guards = self.runtime.installation_receipts(self.worker, layers)
        groups = self.runner.kv_cache_config.kv_cache_groups
        for row, layer in zip(self.source_guards["modules"], layers):
            i, kind, name = row["index"], row["kind"], row["layer_name"]
            node = (
                layer.self_attn.attn if kind == "full_attention" else layer.linear_attn
            )
            matches = [gid for gid, g in enumerate(groups) if name in g.layer_names]
            if len(matches) != 1 or len(node.kv_cache) != 2:
                raise RuntimeError("State cache group/container binding differs")
            self.bindings.append(
                {
                    "index": i,
                    "kind": kind,
                    "name": name,
                    "node": node,
                    "group": matches[0],
                    "container": node.kv_cache,
                    "caches": tuple(node.kv_cache),
                    "signatures": [self.runtime.tensor_info(t) for t in node.kv_cache],
                }
            )
        if len(self.bindings) != 40 or len({b["name"] for b in self.bindings}) != 40:
            raise RuntimeError("Expected all forty unique state producers")
        self._patch(self.runner, "_model_forward", self._forward_wrapper)
        self._patch(self.runner, "_bookkeeping_sync", self._bookkeeping_wrapper)

    def _check_cache_bindings(self, *, post):
        if self.runtime.context() is not self.context or not isinstance(
            self.context.attn_metadata, dict
        ):
            raise RuntimeError("Owner forward context/attention metadata changed")
        decode = getattr(self.worker, "decode_runner", None)
        if decode is not None and (
            decode.requests is not self.runner.requests
            or decode.kv_caches is not self.runner.kv_caches
            or decode.kv_cache_config.kv_cache_groups
            != self.runner.kv_cache_config.kv_cache_groups
        ):
            raise RuntimeError(
                "P/D no longer share the original cache allocation/groups"
            )
        result = []
        for item in self.bindings:
            node, caches, gid = item["node"], item["caches"], item["group"]
            if (
                self.context.no_compile_layers.get(item["name"]) is not node
                or node.kv_cache is not item["container"]
                or any(a is not b for a, b in zip(node.kv_cache, caches))
            ):
                raise RuntimeError("State cache/registry object identity changed")
            infos = [self.runtime.tensor_info(t) for t in caches]
            if infos != item["signatures"]:
                raise RuntimeError(
                    "State storage identities/layouts changed after install"
                )
            if item["kind"] == "linear_attention":
                shapes, strides, dtypes = (
                    ([3, 2048], [8, 128, 128]),
                    ([6144, 2048, 1], [131072, 16384, 128, 1]),
                    ("torch.bfloat16", "torch.float32"),
                )
                for info, tail, stride, dtype in zip(infos, shapes, strides, dtypes):
                    validate_tensor_layout(
                        info, [info["shape"][0], *tail], stride, dtype
                    )
            else:
                block_size = self.runner.input_batch.block_table[gid].block_size
                for info in infos:
                    validate_tensor_layout(
                        info,
                        [info["shape"][0], block_size, 1, 256],
                        [block_size * 256, 256, 256, 1],
                        "torch.bfloat16",
                    )
                for name, tensor in zip(("key_cache", "value_cache"), caches):
                    actual = getattr(node.impl, name)
                    if actual is not tensor and (post or actual is not None):
                        raise RuntimeError(
                            "Attention implementation cache alias differs"
                        )
            result.append(
                {
                    "layer_index": item["index"],
                    "kind": item["kind"],
                    "group_id": gid,
                    "layer_name": item["name"],
                    "bound_layer_python_id": id(node),
                    "cache_container_python_id": id(node.kv_cache),
                    "cache_tensors": infos,
                }
            )
        return result

    def _active_cache_rows(self):
        result, request_ids, batch_ids = [], {}, {}
        runners = [("owner", self.runner)]
        if getattr(self.worker, "decode_runner", None) is not None:
            runners.append(("decode", self.worker.decode_runner))
        for label, runner in runners:
            batch = runner.input_batch
            ids = list(batch.req_ids[: int(batch.num_reqs)])
            if len(ids) != len(set(ids)) or any(
                rid is None or rid not in runner.requests for rid in ids
            ):
                raise RuntimeError("Active cache row identity differs")
            if label == "decode" and self.batch["target"]["request_id"] in ids:
                raise RuntimeError(
                    "Target P is present in the active decode input batch"
                )
            request_ids[label] = list(runner.requests)
            batch_ids[label] = ids
            for rid, request in runner.requests.items():
                row = ids.index(rid) if rid in ids else None
                duplicate = label == "decode"
                if duplicate and (
                    runner.requests is not self.runner.requests
                    or request is not self.runner.requests.get(rid)
                ):
                    raise RuntimeError(
                        "Decode request is not the original shared registry object"
                    )
                tables = []
                for gid, _group in enumerate(
                    self.runner.kv_cache_config.kv_cache_groups
                ):
                    table = batch.block_table[gid]
                    physical = _ints(request.block_ids[gid])
                    logical = expand_block_ids(
                        physical, table.physical_block_size, table.block_size
                    )
                    count = len(logical)
                    if (
                        table.blocks_per_phys_block
                        != table.physical_block_size // table.block_size
                        or table.logical_block_size != table.block_size
                    ):
                        raise RuntimeError("Active physical/logical block sizes differ")
                    if row is not None:
                        count = operator.index(table.num_blocks_per_row[row])
                        actual = _ints(table.block_table.cpu[row, :count])
                        if count != len(logical) or actual != logical:
                            raise RuntimeError(
                                "Active CPU physical/logical block mapping differs"
                            )
                    tables.append(
                        {
                            "group_id": gid,
                            "physical_block_size": table.physical_block_size,
                            "block_size": table.block_size,
                            "blocks_per_phys_block": table.blocks_per_phys_block,
                            "num_blocks": count,
                            "physical_block_ids": physical,
                            "logical_block_ids": logical,
                            "cpu_table_checked": row is not None,
                        }
                    )
                result.append(
                    {
                        "runner": label,
                        "request_id": rid,
                        "row": row,
                        "in_batch": row is not None,
                        "prompt_sha256": _digest(request.prompt_token_ids),
                        "request_python_id": id(request),
                        "shared_registry_duplicate": duplicate,
                        "target": label == "owner"
                        and rid == self.batch["target"]["request_id"],
                        "groups": tables,
                    }
                )
        return result, request_ids, batch_ids

    def _state_plan(self):
        active, request_ids, batch_ids = self._active_cache_rows()
        targets = [row for row in active if row["target"]]
        if len(targets) != 1 or targets[0]["row"] != self.batch["target"]["row"]:
            raise RuntimeError("Target cache row differs from actual P target")
        target = targets[0]
        plans, logical, meta, other_ranges = [], [], {}, []
        for item in self.bindings:
            i, gid = item["index"], item["group"]
            blocks = target["groups"][gid]["logical_block_ids"]
            table = self.runner.input_batch.block_table[gid]
            metadata = self.context.attn_metadata[item["name"]]
            if gid in meta and meta[gid]["object"] is not metadata:
                raise RuntimeError(
                    "Layers sharing a cache group have distinct metadata"
                )
            if item["kind"] == "linear_attention":
                indices = gdn_target_indices(
                    self.role,
                    target["row"],
                    metadata.num_decodes,
                    metadata.num_prefills,
                    metadata.num_spec_decodes,
                )
                if len(blocks) != 1 or metadata.num_decode_tokens != int(
                    self.role == "native"
                ):
                    raise RuntimeError("GDN none-mode target state allocation differs")
                shapes = ([3, 2048], [8, 128, 128])
                kinds = ("conv", "recurrent")
                views = [
                    [(cache[blocks[0]], 0, shape[0])]
                    for cache, shape in zip(item["caches"], shapes)
                ]
                if gid not in meta:
                    r, p = indices["conv_row"], indices["prefill_ordinal"]
                    conv = metadata.non_spec_prefill_metadata.causal_conv1d
                    start, end = (
                        self.batch["target"]["token_start"],
                        self.batch["target"]["token_end"],
                    )
                    offset = metadata.num_decode_tokens
                    entries = [
                        (
                            "gdn-state-index",
                            metadata.prefill_state_indices[p : p + 1],
                            [blocks[0]],
                        ),
                        (
                            "gdn-non-spec-index",
                            metadata.non_spec_state_indices_tensor[r : r + 1],
                            [blocks[0]],
                        ),
                        (
                            "gdn-conv-index",
                            conv.cache_indices[r : r + 1, :1],
                            [[blocks[0]]],
                        ),
                        (
                            "gdn-prefill-flag",
                            metadata.prefill_has_initial_state[p : p + 1],
                            [False],
                        ),
                        ("gdn-conv-flag", conv.initial_state_mode[r : r + 1], [False]),
                        ("gdn-query", conv.query_start_loc[r : r + 2], [start, end]),
                        (
                            "gdn-prefill-query",
                            metadata.prefill_query_start_loc[p : p + 2],
                            [start - offset, end - offset],
                        ),
                    ]
                    meta[gid] = {"object": metadata, "entries": entries}
            else:
                specs = kv_segment_plan(
                    blocks, table.block_size, self.capture_profile["target_tokens"]
                )
                shapes = ([self.capture_profile["target_tokens"], 1, 256],) * 2
                kinds = ("key", "value")
                views = [
                    [
                        (
                            cache[s["block"], s["block_start"] : s["block_end"]],
                            s["position_start"],
                            s["position_end"],
                        )
                        for s in specs
                    ]
                    for cache in item["caches"]
                ]
                if gid not in meta:
                    start, end = (
                        self.batch["target"]["token_start"],
                        self.batch["target"]["token_end"],
                    )
                    needed = math.ceil(
                        self.capture_profile["target_tokens"] / table.block_size
                    )
                    expected_slots = [
                        blocks[p // table.block_size] * table.block_size
                        + p % table.block_size
                        for p in range(self.capture_profile["target_tokens"])
                    ]
                    if metadata.num_actual_tokens != self.batch["total_tokens"]:
                        raise RuntimeError(
                            "Attention actual tokens differ from P batch"
                        )
                    meta[gid] = {
                        "object": metadata,
                        "entries": [
                            (
                                "kv-block-table",
                                table.block_table.gpu[
                                    target["row"] : target["row"] + 1, :needed
                                ],
                                [blocks[:needed]],
                            ),
                            (
                                "kv-slot-mapping",
                                metadata.slot_mapping[start:end],
                                expected_slots,
                            ),
                        ],
                    }
            for kind, shape, parts in zip(kinds, shapes, views):
                key = f"layer-{i:02d}-{kind}"
                segments = []
                for j, (view, start, end) in enumerate(parts):
                    segment = f"{key}-segment-{j:03d}"
                    info = self.runtime.tensor_info(view)
                    expected_stride = {
                        "conv": [2048, 1],
                        "recurrent": [16384, 128, 1],
                        "key": [256, 256, 1],
                        "value": [256, 256, 1],
                    }[kind]
                    dtype = "torch.float32" if kind == "recurrent" else "torch.bfloat16"
                    validate_tensor_layout(
                        info, [end - start, *shape[1:]], expected_stride, dtype
                    )
                    record = {
                        "key": segment,
                        "kind": "state",
                        "logical_key": key,
                        "segment_index": j,
                        "position_start": start,
                        "position_end": end,
                        "shape": info["shape"],
                        "source_dtype": info["dtype"],
                        "selected_view": info,
                    }
                    plans.append((record, view))
                    segments.append(segment)
                logical.append(
                    {
                        "key": key,
                        "layer_index": i,
                        "state_kind": kind,
                        "layer_name": item["name"],
                        "cache_group_id": gid,
                        "shape": list(shape),
                        "source_dtype": dtype,
                        "stored_dtype": "float32",
                        "segment_keys": segments,
                    }
                )
            for row in active:
                if row["target"] or row["shared_registry_duplicate"]:
                    continue
                owned = row["groups"][gid]["logical_block_ids"]
                if not owned:
                    continue
                if item["kind"] == "linear_attention":
                    if len(owned) != 1:
                        raise RuntimeError("Other GDN row allocation differs")
                    selected = [cache[owned[0]] for cache in item["caches"]]
                else:
                    selected = [cache[b] for cache in item["caches"] for b in owned]
                for view in selected:
                    info = self.runtime.tensor_info(view)
                    other_ranges.append(
                        {
                            "runner": row["runner"],
                            "request_id": row["request_id"],
                            "layer_index": i,
                            "start": info["data_ptr"],
                            "end": info["data_ptr"] + info["nbytes"],
                        }
                    )
        target_ranges = [
            {
                "logical_key": r["logical_key"],
                "segment_index": r["segment_index"],
                "start": r["selected_view"]["data_ptr"],
                "end": r["selected_view"]["data_ptr"] + r["selected_view"]["nbytes"],
            }
            for r, _ in plans
        ]
        validate_no_overlap(target_ranges, other_ranges)
        metadata_plans = []
        for gid, value in sorted(meta.items()):
            for mapping, view, expected in value["entries"]:
                info = self.runtime.tensor_info(view)
                if (
                    info["format"] != 2
                    or not info["device"].startswith("npu")
                    or info["dtype"] not in ("torch.int32", "torch.bool")
                ):
                    raise RuntimeError("State mapping metadata layout/dtype differs")
                record = {
                    "key": f"group-{gid:02d}-{mapping}",
                    "kind": "metadata",
                    "mapping": mapping,
                    "cache_group_id": gid,
                    "shape": info["shape"],
                    "source_dtype": info["dtype"],
                    "expected_values": expected,
                    "selected_view": info,
                }
                metadata_plans.append((record, view))
        if {row["key"] for row in logical} != EXPECTED_KEYS or sum(
            r["selected_view"]["nbytes"] for r, _ in plans
        ) != EXPECTED_STATE_BYTES:
            raise RuntimeError("State logical collection/budget differs")
        return (
            plans,
            metadata_plans,
            logical,
            {
                "shared_owner_decode_requests": True
                if self.role == "prefill"
                else None,
                "shared_owner_decode_kv_caches": True
                if self.role == "prefill"
                else None,
                "active_rows": active,
                "runner_request_ids": request_ids,
                "runner_batch_ids": batch_ids,
                "target_ranges": target_ranges,
                "other_ranges": other_ranges,
                "overlap_checked": True,
            },
        )

    def _enqueue(self, record, view):
        stream = self.runtime.stream_receipt(self.worker, self.context)
        validate_stream_receipt(stream)
        if (
            stream != self.stream_receipts["after"]
            or record["selected_view"]["device"] != stream["expected_device"]
        ):
            raise RuntimeError("Producer stream/context changed during state cloning")
        size = record["selected_view"]["nbytes"]
        metadata = record["kind"] == "metadata"
        if (
            self.clone_bytes + size > MAX_CLONE_BYTES
            or (metadata and self.metadata_clone_bytes + size > MAX_METADATA_BYTES)
            or (not metadata and self.state_clone_bytes + size > EXPECTED_STATE_BYTES)
        ):
            raise RuntimeError("State/metadata clone budget exceeded")
        clone, event = self.runtime.clone(view)
        self.pending.append(({**record, "producer_stream": stream}, clone, event))
        self.clone_bytes += size
        if metadata:
            self.metadata_clone_bytes += size
        else:
            self.state_clone_bytes += size

    def _forward_wrapper(self, original):
        def wrapper(*args, **kwargs):
            armed = False
            try:
                if self.context is not None:
                    raise RuntimeError("Reentrant target state capture")
                batch = self._batch_target()
                if batch is None:
                    return original(*args, **kwargs)
                self.batch = batch
                self.context = self.runtime.context()
                armed = True
                if self.context is None:
                    raise RuntimeError("Target P state capture lacks context")
                self.forward_count += 1
                before = self.runtime.stream_receipt(self.worker, self.context)
                validate_stream_receipt(before)
                cache_before = self._check_cache_bindings(post=False)
                plans, metadata, logical, ownership = self._state_plan()
                result = original(*args, **kwargs)
                after = self.runtime.stream_receipt(self.worker, self.context)
                validate_stream_receipt(after)
                if after != before:
                    raise RuntimeError("Owner P returned on a different stream/context")
                if self._check_cache_bindings(post=True) != cache_before:
                    raise RuntimeError(
                        "Cache ownership changed through original P forward"
                    )
                post_plans, post_metadata, post_logical, post_ownership = (
                    self._state_plan()
                )
                if (
                    logical != post_logical
                    or [r for r, _ in plans] != [r for r, _ in post_plans]
                    or [r for r, _ in metadata] != [r for r, _ in post_metadata]
                ):
                    raise RuntimeError(
                        "Target cache mapping changed during original P forward"
                    )
                post_ownership["pre_forward_active_rows"] = ownership["active_rows"]
                ownership = post_ownership
                self.stream_receipts = {
                    "before": before,
                    "after": after,
                    "stable": True,
                }
                self.cache_ownership = {
                    **ownership,
                    "layers": cache_before,
                    "pre_post_identity": True,
                }
                self.logical_tensors = logical
                for record, view in metadata + plans:
                    self._enqueue(record, view)
                self.keys = {row["key"] for row in logical}
                self.forward_finished = True
                self.state = "CAPTURED"
                self.owner_forward_original_returned = True
                return result
            except BaseException as exc:
                self.error = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                if armed:
                    self.context = None

        return wrapper

    def _flush(self, native_result):
        import numpy as np

        if (
            not self.forward_finished
            or self.keys != EXPECTED_KEYS
            or self.state != "CAPTURED"
        ):
            raise RuntimeError("State capture incomplete at bookkeeping")
        ids = list(native_result[3])
        rid = self.batch["target"]["request_id"]
        if (
            rid not in ids
            or ids.index(rid) in native_result[5]
            or len(native_result[1][ids.index(rid)]) != 1
        ):
            raise RuntimeError("State bookkeeping does not match one target P sample")
        for record, clone, event in self.pending:
            self.runtime.wait(event)
            is_metadata = record["kind"] == "metadata"
            array = self.runtime.to_numpy(clone, metadata=is_metadata)
            if is_metadata:
                validate_metadata_array(record, array)
                self.mapping_checks.append(
                    {
                        "key": record["key"],
                        "exact_match": True,
                        "shape": list(array.shape),
                        "stored_dtype": str(array.dtype),
                    }
                )
            elif list(array.shape) != record["shape"] or array.dtype != np.float32:
                raise RuntimeError("State segment export shape/dtype differs")
            if not np.isfinite(array).all():
                raise RuntimeError("Nonfinite stored target state")
            name = f"rank-{self.rank}-{record['key']}.npy"
            path = self.directory / name
            with path.open("xb") as stream:
                np.save(stream, array, allow_pickle=False)
            self.files.append(
                {
                    **record,
                    "file": name,
                    "bytes": path.stat().st_size,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "stored_dtype": str(array.dtype),
                    "all_finite": True,
                    "producer_event_synchronized": True,
                }
            )
        self.pending.clear()
        self.flush_count = 1
        self.state = "DONE"
        path = self.directory / f"rank-{self.rank}-state-captures.json"
        with path.open("x") as stream:
            json.dump(self.snapshot(), stream, indent=2, allow_nan=False)
            stream.write("\n")
        self.manifest = {
            "file": path.name,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }

    def snapshot(self):
        return json.loads(
            json.dumps(
                {
                    "schema": "muxpd-target-peer-p-state-v1",
                    "capture_profile": self.capture_profile,
                    "capture_profile_sha256": CAPTURE_PROFILE_SHA256,
                    "rank": self.rank,
                    "role": self.role,
                    "installation_count": self.installation_count,
                    "installed_hook_count": len(self.patches),
                    "all_hooks_intact": all(
                        getattr(o, n) is w for o, n, _, w in self.patches
                    ),
                    "capture_forward_count": self.forward_count,
                    "forward_finished": self.forward_finished,
                    "flush_count": self.flush_count,
                    "pending_tensor_count": len(self.pending),
                    "captured_tensor_count": len(self.keys),
                    "captured_segment_count": sum(
                        len(r["segment_keys"]) for r in self.logical_tensors
                    ),
                    "metadata_tensor_count": sum(
                        r["kind"] == "metadata" for r, _, _ in self.pending
                    )
                    if self.pending
                    else sum(r["kind"] == "metadata" for r in self.files),
                    "clone_bytes": self.clone_bytes,
                    "state_clone_bytes": self.state_clone_bytes,
                    "metadata_clone_bytes": self.metadata_clone_bytes,
                    "max_clone_bytes": MAX_CLONE_BYTES,
                    "state": self.state,
                    "source_guards": self.source_guards,
                    "cache_ownership": self.cache_ownership,
                    "stream_receipts": self.stream_receipts,
                    "owner_forward_original_returned": self.owner_forward_original_returned,
                    "logical_tensors": self.logical_tensors,
                    "mapping_checks": self.mapping_checks,
                    "batch": self.batch,
                    "files": self.files,
                    "manifest": self.manifest,
                    "error": self.error,
                    "module_sha256": hashlib.sha256(
                        Path(__file__).read_bytes()
                    ).hexdigest(),
                    "scope": "Target persistent state observation only; unchanged 80-logit/eight-prefix controls and final quality gate remain mandatory.",
                }
            )
        )


def install_on_worker(argument, expected_cases, output_dir, capture_profile):
    worker = _unwrap(argument)
    if getattr(worker, ATTRIBUTE, None) is not None:
        raise RuntimeError("Layer capture installation already attempted")
    if getattr(worker, "_muxpd_numerics_install_state", None) != "installed":
        raise RuntimeError("Install the existing numerical observer first")
    runner = worker.model_runner
    observer = getattr(runner, "_muxpd_numerical_observer", None)
    if observer is None or observer.sequence != 0 or observer.pending is not None:
        raise RuntimeError("Layer capture must precede all serving requests")
    if (
        runner.requests
        or runner.input_batch.num_reqs
        or getattr(runner, "execute_model_state", None) is not None
    ):
        raise RuntimeError("Layer capture requires an idle post-startup runner")
    if getattr(worker, "_prefill_task", None) is not None or getattr(
        worker, "_awaiting_sample", False
    ):
        raise RuntimeError("Layer capture cannot install during a pending P forward")
    if (
        getattr(worker, "_prefill_groups_enabled", False)
        or getattr(worker, "_muxpd_paged_prefill_diagnostic", None) is not None
    ):
        raise RuntimeError("Layer capture cannot combine other P experiments")
    cfg = worker.vllm_config
    if (
        cfg.scheduler_config.async_scheduling
        or cfg.speculative_config is not None
        or cfg.parallel_config.tensor_parallel_size != 4
    ):
        raise ValueError(
            "Layer capture requires the synchronous, non-speculative TP4 profile"
        )
    parallel = cfg.parallel_config
    if (
        any(
            getattr(parallel, name, 1) != 1
            for name in (
                "data_parallel_size",
                "pipeline_parallel_size",
                "prefill_context_parallel_size",
                "decode_context_parallel_size",
            )
        )
        or getattr(parallel, "enable_dbo", False)
        or getattr(parallel, "use_sequence_parallel_moe", False)
    ):
        raise ValueError("Layer capture requires unsharded request rows and no DBO")
    controller = getattr(worker, "_decode_graph_controller", None)
    if controller is not None:
        graph = controller.snapshot()
        if (
            not graph["captured"]
            or graph["failed"]
            or graph["closed"]
            or graph["compile_full_prefill"]
        ):
            raise RuntimeError(
                "Layer capture must follow successful raw-P D graph capture"
            )
    if (
        cfg.cache_config.mamba_cache_mode != "none"
        or cfg.cache_config.enable_prefix_caching
        or cfg.kv_transfer_config is not None
    ):
        raise RuntimeError(
            "State capture requires none-mode caches without sharing/transfer"
        )
    model = runner.get_model()
    if hasattr(model, "language_model"):
        model = model.language_model
    capture = StateCapture(
        worker, expected_cases, output_dir, TorchRuntime(), capture_profile
    )
    setattr(worker, ATTRIBUTE, capture)
    try:
        capture.install(model.model.layers)
    except BaseException as exc:
        capture.error = f"{type(exc).__name__}: {exc}"
        raise
    return capture.snapshot()


def snapshot_on_worker(argument):
    capture = getattr(_unwrap(argument), ATTRIBUTE, None)
    return None if capture is None else capture.snapshot()


def install_rpc_on_worker(argument, expected_cases, output_dir, capture_profile):
    """Keep rank-local install failures inside the RPC, with cleanup evidence."""
    worker = _unwrap(argument)
    envelope = {
        "schema": "muxpd-state-install-rpc-v1",
        "status": "error",
        "rank": int(worker.rank),
        "module_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "receipt": None,
        "error": None,
        "cleanup": None,
        "cleanup_error": None,
    }
    try:
        envelope["receipt"] = install_on_worker(
            argument, expected_cases, output_dir, capture_profile
        )
        envelope["status"] = "installed"
    except BaseException as exc:  # noqa: BLE001 -- do not terminate executor workers
        envelope["error"] = {"type": type(exc).__name__, "message": str(exc)}
        try:
            envelope["cleanup"] = uninstall_on_worker(argument, allow_incomplete=True)
        except BaseException as cleanup_exc:  # noqa: BLE001 -- preserve both failures
            envelope["cleanup_error"] = {
                "type": type(cleanup_exc).__name__,
                "message": str(cleanup_exc),
            }
    return envelope


def validate_install_rpc_receipts(rows, module_sha):
    """Unwrap four successful installs; cleanup never converts an error to success."""
    if (
        not isinstance(rows, list)
        or len(rows) != 4
        or any(not isinstance(row, dict) for row in rows)
        or {row.get("rank") for row in rows} != set(range(4))
    ):
        raise RuntimeError("Survey install RPC requires all four distinct TP ranks")
    for row in rows:
        if (
            set(row)
            != {
                "schema",
                "status",
                "rank",
                "module_sha256",
                "receipt",
                "error",
                "cleanup",
                "cleanup_error",
            }
            or row.get("schema") != "muxpd-state-install-rpc-v1"
            or row.get("module_sha256") != module_sha
            or row.get("status") not in ("installed", "error")
        ):
            raise RuntimeError("Survey install RPC schema/source differs")
    failed = [row["rank"] for row in rows if row["status"] == "error"]
    if failed:
        raise RuntimeError(f"Survey install RPC failed on rank(s) {failed}")
    for row in rows:
        receipt = row.get("receipt")
        if (
            row.get("error") is not None
            or row.get("cleanup") is not None
            or row.get("cleanup_error") is not None
            or not isinstance(receipt, dict)
            or receipt.get("rank") != row["rank"]
            or receipt.get("module_sha256") != module_sha
        ):
            raise RuntimeError("Survey install RPC success envelope is malformed")
    return [row["receipt"] for row in rows]


def uninstall_on_worker(argument, allow_incomplete=False):
    worker = _unwrap(argument)
    capture = getattr(worker, ATTRIBUTE, None)
    if capture is None:
        return {
            "schema": "muxpd-state-uninstall-v1",
            "rank": int(worker.rank),
            "status": "not_installed",
            "ok": bool(allow_incomplete),
            "allow_incomplete": allow_incomplete,
            "installed_hook_count": 0,
            "restored_count": 0,
            "all_originals_restored": True,
            "pending_before": 0,
            "pending_after": 0,
            "discarded_pending_count": 0,
            "discard_event_wait_count": 0,
            "error": None if allow_incomplete else "Layer capture was never installed",
            "module_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "collection_complete": False,
            "collection_success_not_inferred_from_cleanup": True,
        }
    return capture.uninstall(allow_incomplete=allow_incomplete)


def validate_uninstall_receipts(rows, module_sha, *, allow_incomplete=False):
    """Validate cleanup; this never promotes incomplete collection to PASS."""
    if len(rows) != 4 or {row["rank"] for row in rows} != set(range(4)):
        raise RuntimeError("Layer uninstall requires all four distinct TP ranks")
    for row in rows:
        if (
            row["module_sha256"] != module_sha
            or not row["ok"]
            or row["error"] is not None
            or row["pending_after"] != 0
            or not row["all_originals_restored"]
            or row["restored_count"] != row["installed_hook_count"]
            or row["allow_incomplete"] != allow_incomplete
        ):
            raise RuntimeError("Layer uninstall receipt failed")
        if not allow_incomplete and (
            row["installed_hook_count"] != 2
            or not row["collection_complete"]
            or row["discarded_pending_count"] != 0
        ):
            raise RuntimeError(
                "Normal layer uninstall did not follow a complete collection"
            )
        if row["status"] == "not_installed":
            if not allow_incomplete:
                raise RuntimeError("Layer capture was not installed")
            continue
        if (
            row["status"] not in ("uninstalled", "already_uninstalled")
            or not row["idle_state"]["idle"]
        ):
            raise RuntimeError("Layer uninstall lacks an idle successful restoration")
        graph = row["graph_ownership"]
        if graph["controller_present"] and not (
            graph["all_graph_patches_owned"] and graph["owner_forward_is_graph_wrapper"]
        ):
            raise RuntimeError("Decode graph ownership was not restored")
    return {
        "validated_ranks": [0, 1, 2, 3],
        "allow_incomplete": allow_incomplete,
        "collection_success_not_inferred_from_cleanup": True,
    }


def validate_receipts(rows, expected_activations, module_sha):
    if expected_activations not in (0, 1):
        raise ValueError("Expected zero/one state activation")
    if len(rows) != 4 or {r["rank"] for r in rows} != set(range(4)):
        raise RuntimeError("State capture requires all four distinct TP ranks")
    if len({r["role"] for r in rows}) != 1 or rows[0]["role"] not in (
        "native",
        "prefill",
    ):
        raise RuntimeError("State roles disagree")
    profile = json.loads(
        Path(__file__).with_name("capture-profile-v1.json").read_bytes()
    )
    for row in rows:
        if (
            row["schema"] != "muxpd-target-peer-p-state-v1"
            or row["capture_profile"] != profile
            or row["capture_profile_sha256"] != CAPTURE_PROFILE_SHA256
            or row["module_sha256"] != module_sha
            or row["installation_count"] != 1
            or row["installed_hook_count"] != 2
            or not row["all_hooks_intact"]
            or row["error"] is not None
            or row["capture_forward_count"] != expected_activations
            or row["flush_count"] != expected_activations
            or row["pending_tensor_count"] != 0
            or row["captured_tensor_count"] != 80 * expected_activations
            or row["source_guards"]["source_files"] != SOURCE_FILES
            or row["source_guards"]["runtime_vllm_version"] != "0.25.1"
            or row["source_guards"]["ascend_release_patch_active"] is not True
            or len(row["source_guards"]["modules"]) != 40
            or row["max_clone_bytes"] != MAX_CLONE_BYTES
        ):
            raise RuntimeError("State lifecycle/source/profile receipt failed")
        if not expected_activations:
            if (
                row["forward_finished"]
                or row["files"]
                or row["manifest"] is not None
                or row["clone_bytes"]
                or row["state_clone_bytes"]
                or row["metadata_clone_bytes"]
                or row["logical_tensors"]
                or row["mapping_checks"]
                or row["stream_receipts"]
                or row["cache_ownership"]
                or row["owner_forward_original_returned"]
                or row["state"] != "WAIT_P"
                or row["captured_segment_count"]
                or row["metadata_tensor_count"]
            ):
                raise RuntimeError("State capture was active before admission")
            continue
        logical = row["logical_tensors"]
        files = row["files"]
        ownership = row["cache_ownership"]
        if (
            row["state"] != "DONE"
            or not row["forward_finished"]
            or not row["owner_forward_original_returned"]
            or row["manifest"] is None
            or len(logical) != 80
            or {t["key"] for t in logical} != EXPECTED_KEYS
            or row["state_clone_bytes"] != EXPECTED_STATE_BYTES
            or not 0 < row["metadata_clone_bytes"] <= MAX_METADATA_BYTES
            or row["clone_bytes"]
            != row["state_clone_bytes"] + row["metadata_clone_bytes"]
            or row["clone_bytes"] > MAX_CLONE_BYTES
        ):
            raise RuntimeError("State terminal collection/count/budget differs")
        streams = row["stream_receipts"]
        validate_stream_receipt(streams["before"])
        validate_stream_receipt(streams["after"])
        if (
            not streams["stable"]
            or streams["before"] != streams["after"]
            or not ownership["overlap_checked"]
            or not ownership["pre_post_identity"]
            or len(ownership["layers"]) != 40
        ):
            raise RuntimeError("State stream/cache ownership proof differs")
        if row["role"] == "prefill" and (
            ownership["shared_owner_decode_requests"] is not True
            or ownership["shared_owner_decode_kv_caches"] is not True
        ):
            raise RuntimeError("State shared P/D ownership proof missing")
        validate_no_overlap(ownership["target_ranges"], ownership["other_ranges"])
        bykey = {f["key"]: f for f in files}
        statekeys = [key for t in logical for key in t["segment_keys"]]
        meta = [f for f in files if f["kind"] == "metadata"]
        if (
            len(bykey) != len(files)
            or len(statekeys) != len(set(statekeys))
            or set(statekeys) != {f["key"] for f in files if f["kind"] == "state"}
            or len(files) != len(statekeys) + len(meta)
            or row["captured_segment_count"] != len(statekeys)
            or row["metadata_tensor_count"] != len(meta)
        ):
            raise RuntimeError("State physical segment/metadata coverage differs")
        groups = {}
        for item in logical:
            i, kind = item["layer_index"], item["state_kind"]
            if item["key"] != f"layer-{i:02d}-{kind}" or kind not in (
                ("key", "value") if i % 4 == 3 else ("conv", "recurrent")
            ):
                raise RuntimeError("State logical key/layer kind differs")
            shape = {
                "conv": [3, 2048],
                "recurrent": [8, 128, 128],
                "key": [1340, 1, 256],
                "value": [1340, 1, 256],
            }[kind]
            dtype = "torch.float32" if kind == "recurrent" else "torch.bfloat16"
            stride = {
                "conv": [2048, 1],
                "recurrent": [16384, 128, 1],
                "key": [256, 256, 1],
                "value": [256, 256, 1],
            }[kind]
            family = (
                "full_attention" if kind in ("key", "value") else "linear_attention"
            )
            gid = item["cache_group_id"]
            if gid in groups and groups[gid] != family:
                raise RuntimeError("State cache group mixes incompatible producers")
            groups[gid] = family
            if (
                item["shape"] != shape
                or item["source_dtype"] != dtype
                or item["stored_dtype"] != "float32"
            ):
                raise RuntimeError("State canonical tensor shape/dtype differs")
            cursor = 0
            for j, key in enumerate(item["segment_keys"]):
                part = bykey[key]
                end = part["position_end"]
                if (
                    part["logical_key"] != item["key"]
                    or part["segment_index"] != j
                    or part["position_start"] != cursor
                    or end <= cursor
                    or end > shape[0]
                    or part["shape"] != [end - cursor, *shape[1:]]
                    or part["stored_dtype"] != "float32"
                    or part["source_dtype"] != dtype
                ):
                    raise RuntimeError("State segment order/shape/dtype differs")
                validate_tensor_layout(
                    part["selected_view"], part["shape"], stride, dtype
                )
                cursor = end
            if cursor != shape[0] or (
                kind in ("conv", "recurrent") and len(item["segment_keys"]) != 1
            ):
                raise RuntimeError("State logical segment coverage incomplete")
        mappings = {
            "linear_attention": (
                "gdn-state-index",
                "gdn-non-spec-index",
                "gdn-conv-index",
                "gdn-prefill-flag",
                "gdn-conv-flag",
                "gdn-query",
                "gdn-prefill-query",
            ),
            "full_attention": ("kv-block-table", "kv-slot-mapping"),
        }
        expected_meta = {
            f"group-{gid:02d}-{name}"
            for gid, family in groups.items()
            for name in mappings[family]
        }
        if (
            {f["key"] for f in meta} != expected_meta
            or len(row["mapping_checks"]) != len(meta)
            or {c["key"] for c in row["mapping_checks"]} != expected_meta
            or any(c["exact_match"] is not True for c in row["mapping_checks"])
        ):
            raise RuntimeError("State metadata proof incomplete")
        if (
            sum(f["selected_view"]["nbytes"] for f in files if f["kind"] == "state")
            != row["state_clone_bytes"]
            or sum(f["selected_view"]["nbytes"] for f in meta)
            != row["metadata_clone_bytes"]
        ):
            raise RuntimeError("State physical clone byte accounting differs")
        for f in files:
            if (
                f["producer_stream"] != streams["after"]
                or f["selected_view"]["device"] != streams["after"]["expected_device"]
                or not f["all_finite"]
                or not f["producer_event_synchronized"]
                or f["bytes"] <= 0
                or len(f["sha256"]) != 64
            ):
                raise RuntimeError("State segment export/event provenance differs")
    return {
        "validated_ranks": [0, 1, 2, 3],
        "expected_activations": expected_activations,
        "final_logits_and_prefix_bridge_still_required": True,
    }
