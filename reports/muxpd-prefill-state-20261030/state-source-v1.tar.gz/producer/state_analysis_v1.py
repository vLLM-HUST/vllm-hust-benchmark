"""Terminal-only canonical target persistent-state analysis."""

import hashlib
import json
from pathlib import Path

import numpy as np

import window_analysis_core_v1 as core

TARGET_ROWS = 1340


def token_sha(tokens):
    return hashlib.sha256(
        json.dumps(tokens, separators=(",", ":")).encode()
    ).hexdigest()


def file_in(directory, name):
    if not isinstance(name, str) or Path(name).name != name or name in ("", ".", ".."):
        raise ValueError("Unsafe layer evidence filename")
    path = directory / name
    if path.resolve().parent != directory.resolve() or path.is_symlink():
        raise ValueError("Layer evidence escapes its directory")
    return path


def validate_batch(batch, collection, role):
    plan = collection["report"]["plan"]
    prompts = {x["case_id"]: x["prompt_token_ids"] for x in plan["cases"]}
    expected = list(prompts) if role == "native" else list(prompts)[1:]
    rows = batch["rows"]
    target_index = expected.index(core.TARGET)
    offset = sum(
        1 if cid == core.SEED else len(prompts[cid]) for cid in expected[:target_index]
    )
    total = sum(1 if cid == core.SEED else len(prompts[cid]) for cid in expected)
    if (
        [r["case_id"] for r in rows] != expected
        or batch["num_reqs"] != len(expected)
        or batch["total_tokens"] != total
        or batch["query_start_loc"][0] != 0
        or batch["query_start_loc"][-1] != total
        or len(batch["query_start_loc"]) != len(rows) + 1
    ):
        raise ValueError("Layer batch is not the original ordered native/raw first P")
    observer = collection["decisions"][(core.TARGET, 0)]
    mapping = {
        v["case_id"]: v["internal"]
        for a in collection["report"]["admissions"]
        for v in a["bindings"]
    }
    for index, row in enumerate(rows):
        cid = row["case_id"]
        semantic = observer["semantic_batch"][index]
        count = 1 if cid == core.SEED else len(prompts[cid])
        prefix = (
            collection["prefixes"][cid]["output_token_ids"][:1]
            if cid == core.SEED
            else []
        )
        computed = len(prompts[cid]) if cid == core.SEED else 0
        if (
            row["row"] != index
            or row["request_id"] != mapping[cid]
            or row["prompt_sha256"] != token_sha(prompts[cid])
            or row["output_prefix"] != prefix
            or row["num_computed_tokens"] != computed
            or row["scheduled_tokens"] != count
            or row["token_start"] != batch["query_start_loc"][index]
            or row["token_end"] != batch["query_start_loc"][index + 1]
            or row["token_end"] - row["token_start"] != count
            or semantic["case_id"] != cid
            or semantic["output_prefix_token_ids"] != prefix
            or semantic["num_computed_tokens"] != computed
            or semantic["scheduled_tokens"] != count
        ):
            raise ValueError(
                "Layer rows are not bound to the actual native sampler batch"
            )
    target = next(r for r in rows if r["case_id"] == core.TARGET)
    if (
        batch["target"] != target
        or target["token_start"] != offset
        or batch["packed_target_input_sha256"] != token_sha(prompts[core.TARGET])
        or batch["packed_target_positions_sha256"]
        != token_sha(list(range(TARGET_ROWS)))
        or not batch["packed_target_input_matches_prompt"]
        or not batch["packed_target_positions_are_zero_based"]
    ):
        raise ValueError("Layer target token/position identity differs")
    return total, offset


STATE_KINDS = {
    i: ("key", "value") if i % 4 == 3 else ("conv", "recurrent") for i in range(40)
}
SHAPES = {
    "conv": [3, 2048],
    "recurrent": [8, 128, 128],
    "key": [1340, 1, 256],
    "value": [1340, 1, 256],
}
EXPECTED_KEYS = {
    f"layer-{i:02d}-{kind}" for i, kinds in STATE_KINDS.items() for kind in kinds
}
DTYPES = {"torch.int32": "int32", "torch.int64": "int64", "torch.bool": "bool"}


def load_file(directory, record):
    """Read original-dtype mapping proofs or exact float32 state exports."""
    path = file_in(directory, record["file"])
    identity = core.identity(path)
    if (
        identity["sha256"] != record["sha256"]
        or identity["size_bytes"] != record["bytes"]
    ):
        raise ValueError("State evidence SHA/size mismatch")
    values = np.load(path, allow_pickle=False, mmap_mode="r")
    if (
        list(values.shape) != record["shape"]
        or str(values.dtype) != record["stored_dtype"]
        or not record["shape"]
        or any(type(n) is not int or n <= 0 for n in record["shape"])
        or record.get("producer_event_synchronized") is not True
        or record.get("all_finite") is not True
        or not np.isfinite(values).all()
    ):
        raise ValueError("State evidence shape/dtype/event/finite mismatch")
    if record["kind"] == "metadata":
        expected_dtype = DTYPES.get(record["source_dtype"])
        expected = np.asarray(record["expected_values"])
        if (
            expected_dtype != record["stored_dtype"]
            or list(expected.shape) != record["shape"]
            or expected.dtype.kind not in "biu"
            or not np.array_equal(values, expected)
        ):
            raise ValueError("Exact integer/bool mapping proof differs")
    elif record["kind"] == "state":
        if record["stored_dtype"] != "float32" or record["source_dtype"] not in (
            "torch.bfloat16",
            "torch.float32",
        ):
            raise ValueError("State export dtype differs")
    else:
        raise ValueError("Undeclared evidence kind")
    return {"values": values, "receipt": record, "identity": identity}


def assemble_logical(logical, records):
    """Concatenate only complete ordered contiguous original-view segments on CPU."""
    shape, keys = logical["shape"], logical["segment_keys"]
    if (
        shape != SHAPES[logical["state_kind"]]
        or not keys
        or len(keys) != len(set(keys))
        or logical["stored_dtype"] != "float32"
        or logical["source_dtype"]
        != (
            "torch.float32"
            if logical["state_kind"] == "recurrent"
            else "torch.bfloat16"
        )
    ):
        raise ValueError("Logical state shape/dtype/segment declaration invalid")
    cursor, arrays, identities = 0, [], []
    for index, key in enumerate(keys):
        loaded = records[key]
        record, values = loaded["receipt"], loaded["values"]
        stop = record["position_end"]
        expected_shape = [stop - cursor, *shape[1:]]
        if (
            record["key"] != key
            or record["kind"] != "state"
            or record["logical_key"] != logical["key"]
            or record["segment_index"] != index
            or record["position_start"] != cursor
            or type(stop) is not int
            or stop <= cursor
            or stop > shape[0]
            or record["shape"] != expected_shape
            or list(values.shape) != expected_shape
            or str(values.dtype) != "float32"
            or not np.isfinite(values).all()
            or record["source_dtype"] != logical["source_dtype"]
            or record["stored_dtype"] != "float32"
        ):
            raise ValueError(
                "State segments have a gap/overlap/order/shape/dtype mismatch"
            )
        arrays.append(values)
        identities.append(loaded["identity"])
        cursor = stop
    if cursor != shape[0]:
        raise ValueError("State segments do not cover the entire logical state")
    if logical["state_kind"] in ("conv", "recurrent") and len(keys) != 1:
        raise ValueError("GDN state must be one original contiguous slot view")
    values = arrays[0] if len(arrays) == 1 else np.concatenate(arrays, axis=0)
    return {
        "values": values,
        "receipt": logical,
        "segments": identities,
        "canonical_sha256": hashlib.sha256(values.tobytes(order="C")).hexdigest(),
    }


def tensor_metrics(left, right):
    if (
        left.shape != right.shape
        or left.dtype != right.dtype
        or left.dtype != np.float32
    ):
        raise ValueError("Canonical state shape/dtype mismatch")
    if not np.isfinite(left).all() or not np.isfinite(right).all():
        raise ValueError("Nonfinite canonical state")
    unequal = np.not_equal(left, right)
    positions = np.flatnonzero(unequal)
    delta = left.astype(np.float64) - right.astype(np.float64)
    left_bytes, right_bytes = left.tobytes(order="C"), right.tobytes(order="C")
    byte_positions = np.flatnonzero(
        np.frombuffer(left_bytes, dtype=np.uint8)
        != np.frombuffer(right_bytes, dtype=np.uint8)
    )
    return {
        "elements": int(left.size),
        "unequal_entries": int(unequal.sum()),
        "canonical_value_bytes_equal": left_bytes == right_bytes,
        "first_difference_index": list(
            map(int, np.unravel_index(positions[0], left.shape))
        )
        if positions.size
        else None,
        "first_byte_difference_offset": int(byte_positions[0])
        if byte_positions.size
        else None,
        "max_abs_delta": float(np.max(np.abs(delta))),
        "rms_delta": float(np.sqrt(np.mean(delta * delta))),
        "all_finite": True,
    }


def runtime_import_proof():
    refs = json.loads(Path(__file__).with_name("state-references-v1.json").read_text())
    path = Path(refs["runtime_import_directory"]) / "bindings.json"
    if core.identity(path)["sha256"] != refs["files"][str(path)]:
        raise ValueError("State runtime import proof changed")
    return json.loads(path.read_text())


def validate_source_guards(guards):
    import state_capture_v1 as helper

    proof = runtime_import_proof()
    if (
        guards.get("cpu_fixture_only") is not False
        or guards.get("runtime_vllm_version") != "0.25.1"
        or guards.get("ascend_release_patch_active") is not True
        or guards.get("source_files") != helper.SOURCE_FILES
    ):
        raise ValueError("State lacks actual runtime source proof")
    helper.verify_source_files()

    def binding(key):
        row = proof["bindings"][key] if key in proof["bindings"] else proof[key]
        return {
            name: row[name]
            for name in ("module", "qualname", "path", "sha256", "unwrapped")
        }

    runtime = (
        "runner_forward",
        "gdn_builder_build",
        "gdn_builder_attach_prefill",
        "device_reshape_and_cache",
        "npu_format",
    )
    if guards.get("runtime_bindings") != {key: binding(key) for key in runtime}:
        raise ValueError("State runtime function/format binding differs")
    modules = guards["modules"]
    if (
        len(modules) != 40
        or len({row["python_id"] for row in modules}) != 40
        or len({row["layer_name"] for row in modules}) != 40
    ):
        raise ValueError("State module identities are missing/repeated")
    for index, row in enumerate(modules):
        linear = index % 4 != 3
        names = {"decoder_forward": "decoder_forward"}
        names.update(
            {
                "forward": "gdn_forward",
                "_forward_core": "gdn_core",
                "get_state_shape": "gdn_state_shape",
                "get_attn_backend": "gdn_attn_backend",
                "get_state_dtype": "gdn_state_dtype",
            }
            if linear
            else {
                "forward": "attention_forward",
                "reshape_and_cache": "attention_reshape_and_cache",
            }
        )
        suffix = ".linear_attn" if linear else ".self_attn.attn"
        if (
            row.get("index") != index
            or row.get("kind") != ("linear_attention" if linear else "full_attention")
            or not row["layer_name"].endswith(f".layers.{index}" + suffix)
            or type(row["python_id"]) is not int
            or row["python_id"] <= 0
            or row.get("registry_identity") is not True
            or row.get("attention_type")
            != (
                None
                if linear
                else {
                    "type": "vllm.v1.attention.backend.AttentionType",
                    "name": "DECODER",
                    "value": "decoder",
                }
            )
            or row.get("bindings")
            != {name: binding(key) for name, key in names.items()}
        ):
            raise ValueError("Actual state module order/source binding differs")
    return {
        "actual_module_count": 40,
        "actual_runtime_bindings": len(runtime),
        "cpu_fixture_only": False,
    }


def validate_uninstall(report, role, expected_sha):
    rows = report.get("layer_hook_uninstall", [])
    if len(rows) != 4 or {row["rank"] for row in rows} != set(range(4)):
        raise ValueError("State uninstall lacks four distinct ranks")
    for row in rows:
        graph = row.get("graph_ownership", {})
        if (
            row.get("schema") != "muxpd-state-uninstall-v1"
            or row.get("role") != role
            or row.get("module_sha256") != expected_sha
            or row.get("ok") is not True
            or row.get("error") is not None
            or row.get("collection_error") is not None
            or row.get("allow_incomplete") is not False
            or row.get("collection_complete") is not True
            or row.get("collection_forward_count") != 1
            or row.get("collection_flush_count") != 1
            or row.get("installed_hook_count") != 2
            or row.get("restored_count") != 2
            or row.get("all_originals_restored") is not True
            or row.get("pending_before") != 0
            or row.get("pending_after") != 0
            or row.get("discarded_pending_count") != 0
            or row.get("discard_event_wait_count") != 0
            or row.get("status") not in ("uninstalled", "already_uninstalled")
            or row.get("idle_state", {}).get("idle") is not True
            or graph.get("controller_present") is not (role == "prefill")
            or (
                role == "prefill"
                and not (
                    graph.get("all_graph_patches_owned") is True
                    and graph.get("owner_forward_is_graph_wrapper") is True
                )
            )
        ):
            raise ValueError("State uninstall restoration/ownership failed")
    return rows


def validate_layer_profile(report, run):
    import state_capture_v1 as helper

    profile_path = run / "producer/capture-profile-v1.json"
    profile = json.loads(profile_path.read_text())
    digest = core.identity(profile_path)["sha256"]
    module_sha = core.identity(run / "producer/state_capture_v1.py")["sha256"]
    helper.validate_capture_profile(report["plan"]["cases"], profile)
    if (
        report.get("schema") != "muxpd-peer-p-state-run-v1"
        or report.get("layer_capture_profile") != profile
        or report.get("layer_capture_profile_sha256") != digest
        or report.get("layer_hook_module_sha256") != module_sha
    ):
        raise ValueError("State profile/source differs from frozen producer")
    if (
        helper.validate_install_rpc_receipts(
            report["layer_hook_install_rpc"], module_sha
        )
        != report["layer_hook_installation"]
    ):
        raise ValueError("State successful RPC envelopes differ from snapshots")
    role = "native" if report["profile"] == "native-observed" else "prefill"
    for field, activations in (("layer_hook_installation", 0), ("layer_hook_final", 1)):
        rows = report[field]
        helper.validate_receipts(rows, activations, module_sha)
        for row in rows:
            validate_source_guards(row["source_guards"])
            if (
                row.get("schema") != "muxpd-target-peer-p-state-v1"
                or row.get("capture_profile") != profile
                or row.get("capture_profile_sha256") != digest
                or row.get("role") != role
                or row.get("max_clone_bytes") != 256 * 1024 * 1024
            ):
                raise ValueError("State rank schema/profile/role/bound differs")
    before = {
        row["rank"]: row["source_guards"] for row in report["layer_hook_installation"]
    }
    after = {row["rank"]: row["source_guards"] for row in report["layer_hook_final"]}
    if before != after:
        raise ValueError("State instance/source identities changed while serving")
    helper.validate_uninstall_receipts(report["layer_hook_uninstall"], module_sha)
    validate_uninstall(report, role, module_sha)
    return {
        "profile_sha256": digest,
        "module_sha256": module_sha,
        "ranks": [0, 1, 2, 3],
    }


def load_layers(collection):
    import state_capture_v1 as helper

    report, run = collection["report"], collection["directory"]
    role = "native" if report["profile"] == "native-observed" else "prefill"
    directory = run / "results/layer-observations"
    validate_layer_profile(report, run)
    module = run / "producer/state_capture_v1.py"
    module_identity = core.identity(module)
    controller = json.loads((run / "controller.json").read_text())
    expected_sha = report["layer_hook_module_sha256"]
    if (
        module_identity["sha256"] != expected_sha
        or controller["files"].get(module.name) != expected_sha
    ):
        raise ValueError("State observer differs from frozen producer")
    uninstall = validate_uninstall(report, role, expected_sha)
    ranks, sources, batches, receipts, expected_files = (
        {},
        [module_identity],
        {},
        {},
        set(),
    )
    for final in report["layer_hook_final"]:
        rank = final["rank"]
        manifest = file_in(directory, final["manifest"]["file"])
        if manifest.name != f"rank-{rank}-state-captures.json":
            raise ValueError("State manifest filename does not bind rank")
        identity = core.identity(manifest)
        if identity["sha256"] != final["manifest"]["sha256"]:
            raise ValueError("State manifest SHA mismatch")
        saved = json.loads(manifest.read_text())
        for name in (
            "schema",
            "rank",
            "role",
            "module_sha256",
            "capture_profile",
            "capture_profile_sha256",
            "files",
            "batch",
            "source_guards",
            "clone_bytes",
            "max_clone_bytes",
            "state",
            "state_clone_bytes",
            "metadata_clone_bytes",
            "captured_tensor_count",
            "captured_segment_count",
            "metadata_tensor_count",
            "logical_tensors",
            "mapping_checks",
            "cache_ownership",
            "stream_receipts",
            "capture_forward_count",
            "forward_finished",
            "flush_count",
            "pending_tensor_count",
        ):
            if saved[name] != final[name]:
                raise ValueError("State final receipt differs from on-disk manifest")
        if saved.get("manifest") is not None:
            raise ValueError("State manifest contains unexpected self-reference")
        validate_batch(saved["batch"], collection, role)
        logicals, files = saved["logical_tensors"], saved["files"]
        if len(logicals) != 80 or {row["key"] for row in logicals} != EXPECTED_KEYS:
            raise ValueError("State requires exactly80 distinct logical tensors")
        if len({row["key"] for row in files}) != len(files) or len(
            {row["file"] for row in files}
        ) != len(files):
            raise ValueError("State physical file declarations are duplicated")
        if any(row["file"] != f"rank-{rank}-{row['key']}.npy" for row in files):
            raise ValueError("State file name does not bind rank and key")
        streams = saved["stream_receipts"]
        if streams.get("stable") is not True or streams["before"] != streams["after"]:
            raise ValueError("State producer stream/context changed across target P")
        helper.validate_stream_receipt(streams["before"])
        if (
            streams["before"]["device"] != f"npu:{rank}"
            or streams["before"].get("expected_device") != f"npu:{rank}"
        ):
            raise ValueError("State producer stream/worker device differs from TP rank")
        if streams["after"]["expected_lane"] != (
            "prefill" if role == "prefill" else None
        ):
            raise ValueError("State capture came from the wrong execution lane")
        loaded = {row["key"]: load_file(directory, row) for row in files}
        state_keys = {row["key"] for row in files if row["kind"] == "state"}
        meta_keys = {row["key"] for row in files if row["kind"] == "metadata"}
        declared_keys = [key for row in logicals for key in row["segment_keys"]]
        if (
            len(declared_keys) != len(set(declared_keys))
            or set(declared_keys) != state_keys
        ):
            raise ValueError(
                "Logical states do not own every physical segment exactly once"
            )
        state_bytes, metadata_bytes = 0, 0
        for record in files:
            view = record["selected_view"]
            if (
                view["shape"] != record["shape"]
                or view["dtype"] != record["source_dtype"]
                or view["device"] != f"npu:{rank}"
                or record["producer_stream"] != streams["after"]
            ):
                raise ValueError("State file view/source stream identity differs")
            stride, step = [], 1
            for extent in reversed(record["shape"]):
                stride.insert(0, step)
                step *= extent
            if record["kind"] == "metadata":
                if any(
                    extent > 1 and actual != expected
                    for extent, actual, expected in zip(
                        record["shape"], view["stride"], stride
                    )
                ):
                    raise ValueError("Mapping proof is not a contiguous selected view")
                stride = view["stride"]
            if (
                view["element_size"]
                != {
                    "torch.bfloat16": 2,
                    "torch.float32": 4,
                    "torch.int32": 4,
                    "torch.int64": 8,
                    "torch.bool": 1,
                }[record["source_dtype"]]
            ):
                raise ValueError("State selected view element size differs from dtype")
            helper.validate_tensor_layout(
                view, record["shape"], stride, record["source_dtype"]
            )
            if record["kind"] == "state":
                state_bytes += view["nbytes"]
            else:
                metadata_bytes += view["nbytes"]
        if (
            state_bytes != saved["state_clone_bytes"]
            or state_bytes != 29818880
            or metadata_bytes != saved["metadata_clone_bytes"]
            or not 0 < metadata_bytes <= 1048576
            or saved["clone_bytes"] != state_bytes + metadata_bytes
            or saved["captured_segment_count"] != len(state_keys)
            or saved["metadata_tensor_count"] != len(meta_keys)
        ):
            raise ValueError("State/meta clone cardinality or allocation bound differs")
        checks = saved["mapping_checks"]
        if len(checks) != len(meta_keys) or {row["key"] for row in checks} != meta_keys:
            raise ValueError("Missing/duplicate actual device mapping check")
        for check in checks:
            record = loaded[check["key"]]["receipt"]
            if (
                check.get("exact_match") is not True
                or check["shape"] != record["shape"]
                or check["stored_dtype"] != record["stored_dtype"]
            ):
                raise ValueError("Actual mapping check differs from metadata file")
        for logical in logicals:
            index, kind = logical["layer_index"], logical["state_kind"]
            if (
                index not in STATE_KINDS
                or kind not in STATE_KINDS[index]
                or logical["key"] != f"layer-{index:02d}-{kind}"
                or logical["layer_name"]
                != saved["source_guards"]["modules"][index]["layer_name"]
            ):
                raise ValueError("Logical state does not bind actual ordered module")
        validate_ownership(saved, loaded, role)
        ranks[rank] = {row["key"]: assemble_logical(row, loaded) for row in logicals}
        sources.append(identity)
        sources.extend(row["identity"] for row in loaded.values())
        batches[rank] = saved["batch"]
        receipts[rank] = {
            key: saved[key]
            for key in (
                "logical_tensors",
                "cache_ownership",
                "stream_receipts",
                "mapping_checks",
                "state_clone_bytes",
                "metadata_clone_bytes",
                "captured_segment_count",
                "metadata_tensor_count",
            )
        }
        expected_files.add(manifest.name)
        expected_files.update(row["file"] for row in files)
    if {
        str(p.relative_to(directory)) for p in directory.rglob("*") if p.is_file()
    } != expected_files:
        raise ValueError("State directory contains missing/undeclared files")
    if any(batch != batches[0] for batch in batches.values()):
        raise ValueError("State target batch identity differs across TP ranks")
    return {
        "ranks": ranks,
        "batch": batches[0],
        "module_sha256": expected_sha,
        "sources": sources,
        "uninstall_receipts": uninstall,
        "state_receipts": receipts,
    }


def compare_layers(left, right):
    if left["module_sha256"] != right["module_sha256"]:
        raise ValueError("Cannot compare different persistent-state observers")
    result = []
    for rank in range(4):
        tensors = {}
        for key in sorted(EXPECTED_KEYS):
            a, b = left["ranks"][rank][key], right["ranks"][rank][key]
            ra, rb = a["receipt"], b["receipt"]
            if any(
                ra[name] != rb[name]
                for name in (
                    "key",
                    "layer_index",
                    "state_kind",
                    "layer_name",
                    "shape",
                    "source_dtype",
                    "stored_dtype",
                )
            ):
                raise ValueError("Native/prefix logical state semantics differ")
            tensors[key] = {
                **tensor_metrics(a["values"], b["values"]),
                "layer_index": ra["layer_index"],
                "state_kind": ra["state_kind"],
                "source_dtype": ra["source_dtype"],
                "shape": ra["shape"],
                "left_canonical_sha256": a["canonical_sha256"],
                "right_canonical_sha256": b["canonical_sha256"],
                "left_segments": a["segments"],
                "right_segments": b["segments"],
                "scope": "Post-prefill stored target state, before target decode consumes its first generated token. Difference localizes a state boundary; it does not uniquely identify a faulty operator.",
            }
        result.append(
            {
                "rank": rank,
                "tensors": tensors,
                "first_numeric_differing_key": next(
                    (k for k, v in tensors.items() if v["unequal_entries"]), None
                ),
                "first_byte_differing_key": next(
                    (
                        k
                        for k, v in tensors.items()
                        if not v["canonical_value_bytes_equal"]
                    ),
                    None,
                ),
            }
        )
    return result


def validate_ownership(saved, loaded, role):
    """Re-derive target slots and absolute byte ranges from all request owners."""
    import state_capture_v1 as helper

    ownership = saved["cache_ownership"]
    if (
        ownership.get("pre_post_identity") is not True
        or ownership.get("overlap_checked") is not True
        or ownership.get("shared_owner_decode_kv_caches")
        is not (True if role == "prefill" else None)
        or ownership.get("shared_owner_decode_requests")
        is not (True if role == "prefill" else None)
        or saved.get("owner_forward_original_returned") is not True
    ):
        raise ValueError("State cache/original-return ownership proof incomplete")
    active, before = ownership["active_rows"], ownership["pre_forward_active_rows"]
    runners = {"owner", "decode"} if role == "prefill" else {"owner"}
    request_ids, batch_ids = (
        ownership["runner_request_ids"],
        ownership["runner_batch_ids"],
    )
    if set(request_ids) != runners or set(batch_ids) != runners:
        raise ValueError("Missing shared owner/decode request inventory")
    batch_rows = saved["batch"]["rows"]
    if batch_ids["owner"] != [row["request_id"] for row in batch_rows]:
        raise ValueError("Owner cache rows differ from actual sampler batch")
    known = saved["capture_profile"]["prompt_sha256"]
    if {row["prompt_sha256"] for row in active} != set(known.values()):
        raise ValueError("Cache ownership does not cover all eight admitted cases")
    if len({(row["runner"], row["request_id"]) for row in active}) != len(active):
        raise ValueError("Duplicate active cache request ownership")
    for runner in runners:
        rows = [row for row in active if row["runner"] == runner]
        if len(request_ids[runner]) != len(set(request_ids[runner])) or {
            row["request_id"] for row in rows
        } != set(request_ids[runner]):
            raise ValueError("Cache alias check omitted an active runner request")
        if len(batch_ids[runner]) != len(set(batch_ids[runner])) or not set(
            batch_ids[runner]
        ) <= set(request_ids[runner]):
            raise ValueError("Cache batch/request inventories disagree")
    owners = {row["request_id"]: row for row in active if row["runner"] == "owner"}
    if len({row["request_python_id"] for row in owners.values()}) != len(owners):
        raise ValueError("Different owner requests share one request object")
    if role == "prefill" and set(request_ids["decode"]) != set(request_ids["owner"]):
        raise ValueError("Shared owner/decode request inventories differ")
    for row in active:
        duplicate = row["runner"] == "decode"
        if (
            row.get("shared_registry_duplicate") is not duplicate
            or type(row.get("request_python_id")) is not int
            or row["request_python_id"] <= 0
        ):
            raise ValueError("State shared request registry identity differs")
        if duplicate:
            owner = owners[row["request_id"]]
            if (
                row["request_python_id"] != owner["request_python_id"]
                or row["prompt_sha256"] != owner["prompt_sha256"]
                or [
                    {k: v for k, v in group.items() if k != "cpu_table_checked"}
                    for group in row["groups"]
                ]
                != [
                    {k: v for k, v in group.items() if k != "cpu_table_checked"}
                    for group in owner["groups"]
                ]
            ):
                raise ValueError(
                    "Duplicate registry entry is not the same shared request and blocks"
                )
            if owner["target"] and row["in_batch"]:
                raise ValueError("Target first P is already in the active decode batch")
        ids = batch_ids[row["runner"]]
        expected_row = (
            ids.index(row["request_id"]) if row["request_id"] in ids else None
        )
        if row["row"] != expected_row or row["in_batch"] is not (
            expected_row is not None
        ):
            raise ValueError("Cache batch row/off-batch ownership differs")
        for gid, group in enumerate(row["groups"]):
            logical = helper.expand_block_ids(
                group["physical_block_ids"],
                group["physical_block_size"],
                group["block_size"],
            )
            if (
                group["group_id"] != gid
                or group["logical_block_ids"] != logical
                or group["num_blocks"] != len(logical)
                or group["blocks_per_phys_block"]
                != group["physical_block_size"] // group["block_size"]
                or group["cpu_table_checked"] is not row["in_batch"]
            ):
                raise ValueError("Cache physical/logical expansion differs")
    target_rows = [row for row in active if row["target"]]
    prior_targets = [row for row in before if row["target"]]
    if (
        len(target_rows) != 1
        or len(prior_targets) != 1
        or target_rows[0] != prior_targets[0]
    ):
        raise ValueError("Target allocation changed across original P forward")
    target = target_rows[0]
    batch_target = saved["batch"]["target"]
    if (
        target["runner"] != "owner"
        or target["request_id"] != batch_target["request_id"]
        or target["row"] != batch_target["row"]
        or target["prompt_sha256"] != known[core.TARGET]
    ):
        raise ValueError("State allocation does not belong to semantic target")
    layers = ownership["layers"]
    if len(layers) != 40 or [row["layer_index"] for row in layers] != list(range(40)):
        raise ValueError("State cache layer order/cardinality differs")
    logicals = {row["key"]: row for row in saved["logical_tensors"]}
    expected_target_ranges, expected_other_ranges, metadata = [], [], {}
    for layer in layers:
        index, gid = layer["layer_index"], layer["group_id"]
        module = saved["source_guards"]["modules"][index]
        if (
            layer["layer_name"] != module["layer_name"]
            or layer["kind"] != module["kind"]
            or layer["bound_layer_python_id"] != module["python_id"]
            or type(layer["cache_container_python_id"]) is not int
            or layer["cache_container_python_id"] <= 0
            or len(layer["cache_tensors"]) != 2
        ):
            raise ValueError("State cache does not bind installed layer instance")
        group = target["groups"][gid]
        blocks = group["logical_block_ids"]
        block_size = group["block_size"]
        linear = index % 4 != 3
        if linear and len(blocks) != 1:
            raise ValueError("GDN target does not own one none-mode state slot")
        specs = (
            [{"block": blocks[0], "position_start": 0, "position_end": None}]
            if linear
            else helper.kv_segment_plan(blocks, block_size, TARGET_ROWS)
        )
        for kind, cache in zip(STATE_KINDS[index], layer["cache_tensors"]):
            key = f"layer-{index:02d}-{kind}"
            logical = logicals[key]
            if logical["cache_group_id"] != gid:
                raise ValueError("Logical tensor cache group differs")
            tail = SHAPES[kind] if linear else [block_size, 1, 256]
            strides = [
                int(np.prod(tail)),
                *[int(np.prod(tail[i + 1 :])) for i in range(len(tail))],
            ]
            dtype = "torch.float32" if kind == "recurrent" else "torch.bfloat16"
            helper.validate_tensor_layout(
                cache, [cache["shape"][0], *tail], strides, dtype
            )
            element = 4 if kind == "recurrent" else 2
            if (
                cache["element_size"] != element
                or cache["device"] != f"npu:{saved['rank']}"
            ):
                raise ValueError("Cache source dtype/rank differs")
            if len(logical["segment_keys"]) != len(specs):
                raise ValueError(
                    "State segment count differs from actual target blocks"
                )
            for position, spec in enumerate(specs):
                record = loaded[logical["segment_keys"][position]]["receipt"]
                view = record["selected_view"]
                block = spec["block"]
                start = spec["position_start"]
                end = SHAPES[kind][0] if linear else spec["position_end"]
                pointer = cache["data_ptr"] + block * cache["stride"][0] * element
                if (
                    not 0 <= block < cache["shape"][0]
                    or record["position_start"] != start
                    or record["position_end"] != end
                    or view["data_ptr"] != pointer
                    or view["storage_ptr"] != cache["storage_ptr"]
                    or view["storage_nbytes"] != cache["storage_nbytes"]
                    or view["storage_offset"]
                    != cache["storage_offset"] + block * cache["stride"][0]
                ):
                    raise ValueError(
                        "State segment is not the target-owned original cache view"
                    )
                expected_target_ranges.append(
                    {
                        "logical_key": key,
                        "segment_index": position,
                        "start": pointer,
                        "end": pointer + view["nbytes"],
                    }
                )
        for row in active:
            if row["target"] or row["shared_registry_duplicate"]:
                continue
            owned = row["groups"][gid]["logical_block_ids"]
            if linear and len(owned) != 1:
                raise ValueError("Other GDN request owns multiple slots")
            for cache in layer["cache_tensors"]:
                for block in owned:
                    if not 0 <= block < cache["shape"][0]:
                        raise ValueError("Other request cache block is out of bounds")
                    start = (
                        cache["data_ptr"]
                        + block * cache["stride"][0] * cache["element_size"]
                    )
                    expected_other_ranges.append(
                        {
                            "runner": row["runner"],
                            "request_id": row["request_id"],
                            "layer_index": index,
                            "start": start,
                            "end": start + cache["stride"][0] * cache["element_size"],
                        }
                    )
        if gid not in metadata:
            start, end = batch_target["token_start"], batch_target["token_end"]
            if linear:
                if batch_target["row"] - int(role == "native") != 2:
                    raise ValueError(
                        "GDN recurrent ordinal confused with mixed batch row"
                    )
                offset = int(role == "native")
                metadata[gid] = {
                    "gdn-state-index": [blocks[0]],
                    "gdn-non-spec-index": [blocks[0]],
                    "gdn-conv-index": [[blocks[0]]],
                    "gdn-prefill-flag": [False],
                    "gdn-conv-flag": [False],
                    "gdn-query": [start, end],
                    "gdn-prefill-query": [start - offset, end - offset],
                }
            else:
                needed = (TARGET_ROWS + block_size - 1) // block_size
                metadata[gid] = {
                    "kv-block-table": [blocks[:needed]],
                    "kv-slot-mapping": [
                        blocks[p // block_size] * block_size + p % block_size
                        for p in range(TARGET_ROWS)
                    ],
                }

    def canonical(rows):
        return sorted(
            json.dumps(row, sort_keys=True, separators=(",", ":")) for row in rows
        )

    if canonical(expected_target_ranges) != canonical(
        ownership["target_ranges"]
    ) or canonical(expected_other_ranges) != canonical(ownership["other_ranges"]):
        raise ValueError("Alias range inventory omits or changes cache ownership")
    helper.validate_no_overlap(expected_target_ranges, expected_other_ranges)
    expected_metadata = {
        f"group-{gid:02d}-{kind}": (gid, kind, values)
        for gid, entries in metadata.items()
        for kind, values in entries.items()
    }
    actual_metadata = {
        key: value
        for key, value in loaded.items()
        if value["receipt"]["kind"] == "metadata"
    }
    if set(actual_metadata) != set(expected_metadata):
        raise ValueError("Actual device mapping proofs are incomplete/extra")
    for key, value in actual_metadata.items():
        gid, kind, expected = expected_metadata[key]
        record = value["receipt"]
        dtype = "torch.bool" if kind.endswith("-flag") else "torch.int32"
        if (
            record["cache_group_id"] != gid
            or record["mapping"] != kind
            or record["source_dtype"] != dtype
            or record["expected_values"] != expected
            or not np.array_equal(value["values"], np.asarray(expected))
        ):
            raise ValueError(
                "Device mapping does not match derived semantic target state"
            )
