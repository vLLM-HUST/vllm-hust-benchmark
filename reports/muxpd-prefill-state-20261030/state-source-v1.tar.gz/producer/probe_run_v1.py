"""Bounded original-batch localization; no quality scoring or performance claim."""

import argparse
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import subprocess
import sys
import time
import traceback
from datetime import UTC, datetime
from pathlib import Path

SOURCE = "6c606f789450a45ef35afee398b0a3e516caa1a1"
QUALITY_SOURCE = "f7ed21e183b27d2141176f3e7a5c8a5ff4ede07d"
PLAN_SHA = "ae0706510213a83df43b6c9bbac310c572398dad7819aed1b853d1bec93c95f4"
PROFILES = ("native-observed", "prefix-observed")
WORKERS = {
    "native": "vllm_ascend.worker.worker.NPUWorker",
    "prefix": "vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker",
}
CORE_SOURCE = "d0f22d2bda562156e4dbf433ce645e1769b4f804"
ASCEND_SOURCE = "03766ac696fde5ab1980d80ca0b8543d3580c989"


def now():
    return datetime.now(UTC).isoformat()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    pending = path.with_suffix(path.suffix + ".pending")
    with pending.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    pending.replace(path)


def git(source, *args):
    return subprocess.check_output(["git", "-C", str(source), *args], text=True).strip()


def source_equivalence(source):
    if git(source, "rev-parse", "HEAD") != SOURCE or git(
        source, "status", "--porcelain"
    ):
        raise ValueError("Require the clean frozen 6c observer source")
    existing = git(
        source, "ls-tree", "-r", "--name-only", QUALITY_SOURCE, "--", "src"
    ).splitlines()
    changed = git(
        source, "diff", "--name-only", QUALITY_SOURCE, SOURCE, "--", *existing
    )
    if changed:
        raise ValueError("Existing f7 runtime files differ from observer source")
    return {
        "source": str(source),
        "observer_source": SOURCE,
        "quality_runtime_source": QUALITY_SOURCE,
        "existing_runtime_files": existing,
        "existing_runtime_diff": changed,
        "added_paths": git(
            source, "diff", "--name-status", QUALITY_SOURCE, SOURCE
        ).splitlines(),
        "scope": "All src files existing at f7 are unchanged; 6c adds diagnostic code/docs/tests.",
    }


def load_plan(path):
    plan = json.loads(path.read_text())
    declared = plan.pop("plan_sha256")
    actual = hashlib.sha256(
        json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    if declared != PLAN_SHA or actual != PLAN_SHA:
        raise ValueError("Frozen batch7 late-window plan identity differs")
    plan["plan_sha256"] = declared
    return plan


def engine_config(profile, base, plan):
    if profile not in PROFILES:
        raise ValueError("Unknown profile")
    role = profile.split("-")[0]
    config = copy.deepcopy(base)
    for key, value in plan["runtime"].items():
        if config.get(key) != value:
            raise ValueError(f"Frozen engine setting differs: {key}")
    if config.get("enable_chunked_prefill") is not (role == "native"):
        raise ValueError("Native/raw chunked-prefill treatment differs")
    if any(
        config.get(k) is not None
        for k in (
            "worker_cls",
            "worker_extension_cls",
            "speculative_config",
            "num_gpu_blocks_override",
        )
    ):
        raise ValueError("Do not override worker, observer, speculation or KV pressure")
    backend = config.get("additional_config", {}).get("ascend_compilation_config", {})
    if any(
        backend.get(k) is not False
        for k in ("enable_npugraph_ex", "enable_static_kernel")
    ):
        raise ValueError("Both roles require the original fusion backend")
    policy = config.get("batch_admission_policy_config", {})
    if role == "native":
        if config.get("scheduler_cls") or config.get("batch_admission_policy"):
            raise ValueError("Native role cannot activate plugin scheduling")
    elif (
        policy.get("compile_prefill_groups") is not False
        or policy.get("stream_mode") != "overlap"
        or policy.get("layers_per_slice") != 4
        or policy.get("overlap_communication") != "isolated"
    ):
        raise ValueError(
            "Raw role must preserve the original raw q4 isolated overlap profile"
        )
    config["worker_cls"] = WORKERS[role]
    if profile.endswith("observed"):
        config["worker_extension_cls"] = (
            "window_numeric_workers_v1.NumericalObserverExtension"
        )
    return config


def source_identities():
    result = {}
    for name, expected in (
        ("vllm", CORE_SOURCE),
        ("vllm_ascend", ASCEND_SOURCE),
        ("vllm_muxpd", SOURCE),
    ):
        origin = Path(importlib.util.find_spec(name).origin).resolve()
        root = Path(git(origin.parent, "rev-parse", "--show-toplevel"))
        commit = git(root, "rev-parse", "HEAD")
        if commit != expected:
            raise RuntimeError(f"Imported {name} source differs from pinned runtime")
        result[name] = {
            "path": str(origin),
            "commit": commit,
            "status": git(root, "status", "--porcelain"),
            "diff": git(root, "diff", "HEAD"),
            "module_sha256": file_sha(origin),
        }
    return result


def tokenizer_identities(plan):
    observed = {}
    for name, expected in plan["tokenizer_files"].items():
        actual = file_sha(expected["path"])
        if actual != expected["sha256"]:
            raise ValueError(
                f"Tokenizer file differs from frozen quality input: {name}"
            )
        observed[name] = {**expected, "observed_sha256": actual}
    return observed


def worker_snapshot(argument):
    from dataclasses import asdict

    from torch._dynamo.utils import counters
    from vllm.compilation.counter import compilation_counter
    from vllm_ascend.ascend_config import get_ascend_config

    try:
        worker = object.__getattribute__(argument, "worker")
    except AttributeError:
        worker = argument
    runners = {"model": worker.model_runner}
    if getattr(worker, "decode_runner", None) is not None:
        runners["decode"] = worker.decode_runner
    cfg, ascend = worker.vllm_config, get_ascend_config()
    external_modules = {}
    for name in ("window_numeric_diagnostics_v1", "window_numeric_workers_v1"):
        module = sys.modules.get(name)
        if module is not None:
            origin = Path(module.__file__).resolve()
            external_modules[name] = {"path": str(origin), "sha256": file_sha(origin)}
    return {
        "rank": worker.rank,
        "compilation_counter": asdict(compilation_counter),
        "dynamo_counters": {str(k): dict(v) for k, v in counters.items()},
        "decode_graph_snapshot": (
            worker._decode_graph_controller.snapshot()
            if hasattr(worker, "_decode_graph_controller")
            else None
        ),
        "worker_class": type(worker).__module__ + "." + type(worker).__qualname__,
        "requests": {lane: sorted(runner.requests) for lane, runner in runners.items()},
        "input_rows": {
            lane: list(runner.input_batch.req_ids) for lane, runner in runners.items()
        },
        "input_num_reqs": {
            lane: runner.input_batch.num_reqs for lane, runner in runners.items()
        },
        "input_req_id_to_index": {
            lane: dict(runner.input_batch.req_id_to_index)
            for lane, runner in runners.items()
        },
        "prefill_task_present": getattr(worker, "_prefill_task", None) is not None,
        "prefill_cohort_id": getattr(worker, "_prefill_cohort_id", None),
        "awaiting_sample": getattr(worker, "_awaiting_sample", False),
        "pending_lanes": list(getattr(worker, "_pending_lanes", [])),
        "observer_state": getattr(worker, "_muxpd_numerics_install_state", None),
        "external_observer_modules": external_modules,
        "runtime": {
            "async_scheduling": cfg.scheduler_config.async_scheduling,
            "use_v2_model_runner": cfg.use_v2_model_runner,
            "tensor_parallel_size": cfg.parallel_config.tensor_parallel_size,
            "enable_expert_parallel": cfg.parallel_config.enable_expert_parallel,
            "enable_chunked_prefill": cfg.scheduler_config.enable_chunked_prefill,
            "policy": dict(cfg.scheduler_config.batch_admission_policy_config or {}),
            "enable_npugraph_ex": ascend.ascend_compilation_config.enable_npugraph_ex,
            "enable_static_kernel": ascend.ascend_compilation_config.enable_static_kernel,
            "resolved_fusion": {
                name: getattr(ascend.ascend_compilation_config, name)
                for name in ("fuse_norm_quant", "fuse_qknorm_rope", "fuse_muls_add")
            },
            "cudagraph_mode": cfg.compilation_config.cudagraph_mode.name,
            "cudagraph_capture_sizes": list(
                cfg.compilation_config.cudagraph_capture_sizes
            ),
            "runner_async": {
                lane: runner.use_async_scheduling for lane, runner in runners.items()
            },
            "HCCL_DETERMINISTIC": os.environ.get("HCCL_DETERMINISTIC"),
        },
    }


def validate_workers(rows, profile, observer_installed=False):
    role = profile.split("-")[0]
    if len(rows) != 4 or {w["rank"] for w in rows} != set(range(4)):
        raise RuntimeError("Worker readback does not cover all TP4 ranks")
    for row in rows:
        actual = row["runtime"]
        expected = {
            "async_scheduling": False,
            "use_v2_model_runner": False,
            "tensor_parallel_size": 4,
            "enable_expert_parallel": True,
            "enable_chunked_prefill": role == "native",
            "enable_npugraph_ex": False,
            "enable_static_kernel": False,
            "cudagraph_mode": "FULL_DECODE_ONLY",
            "cudagraph_capture_sizes": [1, 2, 4, 8],
            "HCCL_DETERMINISTIC": "true",
        }
        if row["worker_class"] != WORKERS[role] or any(
            actual[k] != v for k, v in expected.items()
        ):
            raise RuntimeError("Resolved worker/runtime differs from frozen profile")
        if any(actual["runner_async"].values()):
            raise RuntimeError("Historical diagnostic cannot enable async sampling")
        if (
            role == "prefix"
            and actual["policy"].get("compile_prefill_groups") is not False
        ):
            raise RuntimeError("Raw worker resolved grouped prefill")
        expected_observer = "installed" if observer_installed else None
        if row["observer_state"] != expected_observer:
            raise RuntimeError(
                "Observer state differs from explicit observed/plain profile"
            )


def scheduler_snapshot(engine):
    scheduler = engine.engine_core.engine_core.scheduler
    pool = scheduler.kv_cache_manager.block_pool
    return {
        "request_ids": sorted(scheduler.requests),
        "running_ids": [r.request_id for r in scheduler.running],
        "waiting_ids": [r.request_id for r in scheduler.waiting],
        "skipped_waiting_ids": [r.request_id for r in scheduler.skipped_waiting],
        "finished_req_ids": sorted(scheduler.finished_req_ids),
        "client_request_ids": sorted(engine.output_processor.request_states),
        "cohort_present": getattr(scheduler, "_prefill_cohort", None) is not None,
        "held_prefill_ids": sorted(getattr(scheduler, "_held_prefill_blocks", {})),
        "free_blocks": pool.get_num_free_blocks(),
        "pool_blocks": pool.num_gpu_blocks,
    }


def require_empty(snapshot, baseline):
    if any(
        snapshot[k]
        for k in (
            "request_ids",
            "running_ids",
            "waiting_ids",
            "skipped_waiting_ids",
            "finished_req_ids",
            "client_request_ids",
            "cohort_present",
            "held_prefill_ids",
        )
    ):
        raise RuntimeError("Native cancellation did not fully drain")
    if snapshot["free_blocks"] != baseline["free_blocks"]:
        raise RuntimeError("KV free blocks did not return to baseline")


def require_empty_worker(worker):
    # InputBatch.remove_request clears the mapping and writes None into its
    # retained slot list. List capacity is not the number of active requests.
    # Preserve those raw slots in the receipt; reject every non-None ID,
    # including an empty string, and independently check native live counts/maps.
    live_rows = any(
        rid is not None for rows in worker["input_rows"].values() for rid in rows
    )
    if (
        any(worker["requests"].values())
        or live_rows
        or any(worker["input_num_reqs"].values())
        or any(worker["input_req_id_to_index"].values())
        or worker["prefill_task_present"]
        or worker["prefill_cohort_id"] is not None
        or worker["awaiting_sample"]
        or worker["pending_lanes"]
    ):
        raise RuntimeError("Worker retains request/iteration state after cancellation")


def abort_and_drain(engine, max_steps):
    scheduler = engine.engine_core.engine_core.scheduler
    aborted = sorted(scheduler.requests)
    engine.abort_request(aborted, internal=True)
    steps = 0
    while scheduler.has_requests() or engine.has_unfinished_requests():
        if steps >= max_steps:
            raise RuntimeError("Cancellation exceeded bounded maintenance steps")
        engine.step()
        steps += 1
    return {"aborted_internal_ids": aborted, "maintenance_steps": steps}


def install_layer_capture(llm, layer, plan, args, report):
    """Persist all rank envelopes before fail-closed host validation/admission."""
    rows = llm.collective_rpc(
        layer.install_rpc_on_worker,
        args=(
            plan["cases"],
            str(args.output / "layer-observations"),
            report["layer_capture_profile"],
        ),
        timeout=60,
    )
    report["layer_hook_install_rpc"] = rows
    save(args.output / "run.json", report)
    installed = layer.validate_install_rpc_receipts(
        rows, report["layer_hook_module_sha256"]
    )
    report["layer_hook_installation"] = installed
    layer.validate_receipts(installed, 0, report["layer_hook_module_sha256"])


def run(args):
    plan = load_plan(args.plan)
    source = source_equivalence(args.source)
    config = engine_config(args.profile, json.loads(args.config.read_text()), plan)
    args.output.mkdir(parents=True, exist_ok=False)
    observed = args.profile.endswith("observed")
    use_layout = args.profile.startswith("prefix-")
    if any(
        os.environ.get(k)
        for k in (
            "MUXPD_NUMERIC_OUTPUT",
            "MUXPD_NUMERIC_CAPTURE_STEPS",
            "MUXPD_NUMERIC_CAPTURE_WINDOW",
            "MUXPD_PRESSURE_TRACE_DIR",
            "VLLM_TORCH_PROFILER_DIR",
        )
    ):
        raise ValueError("Remove unrelated observer environments")
    if observed:
        os.environ.update(
            MUXPD_NUMERIC_OUTPUT=str(args.output / "worker-observations"),
            MUXPD_NUMERIC_CAPTURE_WINDOW=json.dumps(
                plan["capture_token_indices_one_based"]
            ),
            MUXPD_NUMERIC_RANKS="0",
        )
    if os.environ.get("HCCL_DETERMINISTIC") != "true" or os.environ.get(
        "VLLM_BATCH_INVARIANT"
    ) not in (None, "0"):
        raise ValueError(
            "Preserve the original literal HCCL=true, batch-invariance-off profile"
        )
    os.environ["VLLM_ENABLE_V1_MULTIPROCESSING"] = "0"
    report = {
        "schema": "muxpd-peer-p-state-run-v1",
        "profile": args.profile,
        "layout_mode": "prefix" if use_layout else None,
        "started_at": now(),
        "pid": os.getpid(),
        "plan": plan,
        "source_equivalence": source,
        "launch_config": copy.deepcopy(config),
        "producer_sha256": file_sha(__file__),
        "config_file_sha256": file_sha(args.config),
        "plan_file_sha256": file_sha(args.plan),
        "admissions": [],
        "natural_completions": [],
        "errors": [],
        "collection_complete": False,
        "shutdown_returned": False,
        "passed": False,
        "scope": plan["scope"],
        "capture_token_indices_one_based": plan["capture_token_indices_one_based"],
        "environment": {
            k: os.environ.get(k)
            for k in (
                "ASCEND_RT_VISIBLE_DEVICES",
                "HCCL_DETERMINISTIC",
                "VLLM_BATCH_INVARIANT",
                "VLLM_USE_V2_MODEL_RUNNER",
                "VLLM_ENABLE_V1_MULTIPROCESSING",
                "PYTHONPATH",
            )
        },
        "interpreter": sys.executable,
        "packages": {
            name: importlib.metadata.version(name)
            for name in (
                "vllm",
                "vllm-ascend",
                "torch",
                "torch-npu",
                "transformers",
                "tokenizers",
            )
        },
    }
    save(args.output / "run.json", report)
    llm, baseline, scheduler, original_schedule = None, None, None, None
    handles, mapping = {}, {}
    layout_install_attempted, layout_restored = False, False
    layer_install_attempted, layer_restored = False, False
    try:
        from vllm import LLM, SamplingParams
        from vllm.v1.engine.core_client import InprocClient

        report["sources"] = source_identities()
        report["tokenizer_files"] = tokenizer_identities(plan)
        model_identity = plan["model_config_identity"]
        if file_sha(model_identity["path"]) != model_identity["sha256"]:
            raise ValueError(
                "Model configuration differs from pinned vocabulary profile"
            )
        report["model_config_identity"] = model_identity
        llm = LLM(**config)
        engine = llm.llm_engine
        if not isinstance(engine.engine_core, InprocClient):
            raise TypeError("Actual coordinator is not InprocClient")
        scheduler = engine.engine_core.engine_core.scheduler
        baseline = scheduler_snapshot(engine)
        require_empty(baseline, baseline)
        report["idle_baseline"] = baseline
        report["worker_before"] = llm.collective_rpc(worker_snapshot, timeout=30)
        validate_workers(report["worker_before"], args.profile)
        report["sources_after_startup"] = source_identities()
        report["source_equivalence_after_startup"] = source_equivalence(args.source)
        if observed:
            installed = llm.collective_rpc(
                "muxpd_install_numerical_observers", timeout=30
            )
            if (
                len(installed) != 4
                or {x["rank"] for x in installed} != set(range(4))
                or not all(x["installed"] for x in installed)
            ):
                raise RuntimeError(
                    "Observer installation did not confirm all TP4 workers"
                )
            report["observer_installation"] = installed
        if use_layout:
            import prefill_collective_layout_v1 as layout

            layout_path = Path(__file__).with_name("prefill_collective_layout_v1.py")
            report["layout_module_sha256"] = file_sha(layout_path)
            layout_install_attempted = True
            rows = llm.collective_rpc(
                layout.install_on_worker, args=("prefix",), timeout=60
            )
            report["layout_installation"] = rows
            layout.validate_receipts(
                rows,
                report["layout_module_sha256"],
                mode="prefix",
                expected_treated_cohorts=0,
                expected_completed=0,
            )
        import state_capture_v1 as layer

        layer_path = Path(__file__).with_name("state_capture_v1.py")
        profile_path = Path(__file__).with_name("capture-profile-v1.json")
        capture_profile = json.loads(profile_path.read_text())
        report["layer_hook_module_sha256"] = file_sha(layer_path)
        report["layer_capture_profile"] = capture_profile
        report["layer_capture_profile_sha256"] = file_sha(profile_path)
        layer_install_attempted = True
        install_layer_capture(llm, layer, plan, args, report)
        params = SamplingParams(**plan["sampling"])

        def enqueue(cases, step):
            ids = llm.enqueue(
                [{"prompt_token_ids": c["prompt_token_ids"]} for c in cases],
                params,
                use_tqdm=False,
            )
            if len(ids) != len(cases):
                raise RuntimeError("Admission cardinality differs")
            bindings = []
            for case, rid in zip(cases, ids):
                handle = scheduler.requests[rid]
                if list(handle.prompt_token_ids) != case["prompt_token_ids"]:
                    raise RuntimeError("Admitted prompt differs from frozen input")
                handles[case["case_id"]] = handle
                mapping[case["case_id"]] = rid
                external = engine.output_processor.request_states[rid].external_req_id
                bindings.append(
                    {"case_id": case["case_id"], "internal": rid, "external": external}
                )
            report["admissions"].append({"after_step": step, "bindings": bindings})

        enqueue(plan["cases"][:1], 0)
        seed = handles[plan["batch"]["seed_case_id"]]
        start, steps, peers = time.monotonic(), 0, False
        with (args.output / "history.jsonl").open("x", buffering=1) as history:
            original_schedule = scheduler.schedule

            def schedule(*a, **kw):
                value = original_schedule(*a, **kw)
                history.write(
                    json.dumps(
                        {
                            "event": "scheduled",
                            "step": steps,
                            "cohort_id": getattr(
                                value, "muxpd_prefill_cohort_id", None
                            ),
                            "num_scheduled_tokens": dict(value.num_scheduled_tokens),
                            "prefill_ids": list(
                                getattr(value, "muxpd_prefill_request_ids", [])
                            ),
                            "pending_prefill_ids": list(
                                getattr(value, "muxpd_pending_prefill_ids", [])
                            ),
                            "finished_ids": sorted(value.finished_req_ids),
                            "preempted_ids": sorted(value.preempted_req_ids or []),
                        }
                    )
                    + "\n"
                )
                return value

            scheduler.schedule = schedule
            while True:
                if (
                    steps >= plan["maximum_engine_steps"]
                    or time.monotonic() - start
                    > plan["maximum_run_seconds_after_startup"]
                ):
                    raise RuntimeError(
                        "Bounded diagnostic exceeded its step/time limit"
                    )
                steps += 1
                outputs = engine.step()
                for out in outputs:
                    if out.finished:
                        report["natural_completions"].append(
                            {
                                "request_id": out.request_id,
                                "outputs": [
                                    {
                                        "token_ids": list(x.token_ids),
                                        "finish_reason": x.finish_reason,
                                        "stop_reason": x.stop_reason,
                                    }
                                    for x in out.outputs
                                ],
                            }
                        )
                history.write(
                    json.dumps(
                        {
                            "event": "step-return",
                            "step": steps,
                            "requests": {
                                case: {
                                    "internal": mapping[case],
                                    "tokens": list(req.output_token_ids),
                                    "num_computed_tokens": req.num_computed_tokens,
                                    "status": str(req.status),
                                }
                                for case, req in handles.items()
                            },
                        }
                    )
                    + "\n"
                )
                if not peers:
                    if seed.num_output_tokens > 1 or seed.is_finished():
                        raise RuntimeError(
                            "Missed exact live-seed output1 admission gate"
                        )
                    if seed.num_output_tokens == 1:
                        enqueue(plan["cases"][1:], steps)
                        report["admissions"][-1]["seed_output_tokens"] = (
                            seed.num_output_tokens
                        )
                        peers = True
                target = handles.get(plan["target_case_id"])
                if (
                    target is not None
                    and target.num_output_tokens >= plan["target_generated_tokens"]
                ):
                    if target.num_output_tokens != plan["target_generated_tokens"]:
                        raise RuntimeError(
                            "Target passed the frozen observation boundary"
                        )
                    break
                if target is not None and target.is_finished():
                    raise RuntimeError(
                        "Target naturally finished before observation boundary"
                    )
            report["engine_steps_to_boundary"] = steps
            report["prefixes_before_abort"] = {
                case: {
                    "internal_id": mapping[case],
                    "prompt_token_ids": list(req.prompt_token_ids),
                    "output_token_ids": list(req.output_token_ids),
                    "status": str(req.status),
                    "num_computed_tokens": req.num_computed_tokens,
                    "num_preemptions": req.num_preemptions,
                }
                for case, req in handles.items()
            }
            report["state_before_abort"] = scheduler_snapshot(engine)
            report["stop_kind"] = (
                "supervisor_abort_after_target_output208_not_natural_termination"
            )
            report["cancellation"] = abort_and_drain(
                engine, plan["maximum_cleanup_steps"]
            )
            report["final_state"] = scheduler_snapshot(engine)
            require_empty(report["final_state"], baseline)
            report["worker_after"] = llm.collective_rpc(worker_snapshot, timeout=30)
            validate_workers(report["worker_after"], args.profile, observed)
            if len(report["worker_after"]) != 4 or {
                w["rank"] for w in report["worker_after"]
            } != set(range(4)):
                raise RuntimeError("Final worker readback does not cover TP4")
            for worker in report["worker_after"]:
                require_empty_worker(worker)
            layer_rows = llm.collective_rpc(layer.snapshot_on_worker, timeout=60)
            report["layer_hook_final"] = layer_rows
            layer.validate_receipts(layer_rows, 1, report["layer_hook_module_sha256"])
            restored = llm.collective_rpc(layer.uninstall_on_worker, timeout=60)
            report["layer_hook_uninstall"] = restored
            layer.validate_uninstall_receipts(
                restored, report["layer_hook_module_sha256"]
            )
            layer_restored = True
            if use_layout:
                rows = llm.collective_rpc(layout.snapshot_on_worker, timeout=60)
                report["layout_final"] = rows
                layout.validate_receipts(
                    rows,
                    report["layout_module_sha256"],
                    mode="prefix",
                    expected_treated_cohorts=1,
                    expected_completed=2,
                )
                rows = llm.collective_rpc(layout.uninstall_on_worker, timeout=60)
                report["layout_uninstall"] = rows
                layout.validate_uninstall_receipts(
                    rows, report["layout_module_sha256"], mode="prefix"
                )
                layout_restored = True
            report["collection_complete"] = True
    except BaseException:  # noqa: BLE001 -- retain interruption/failure and always clean up
        report["errors"].append(traceback.format_exc())
    finally:
        if scheduler is not None and original_schedule is not None:
            # A failing observed step leaves the history context before this
            # cleanup. Restore the native callable before draining aborts so
            # cleanup never attempts to write to the closed history stream.
            scheduler.schedule = original_schedule
        if llm is not None:
            try:
                if not report["collection_complete"]:
                    report["failure_cleanup"] = abort_and_drain(
                        llm.llm_engine, plan["maximum_cleanup_steps"]
                    )
            except BaseException:  # noqa: BLE001 -- retain interruption/failure and always clean up
                report["errors"].append(traceback.format_exc())
            if layer_install_attempted and not layer_restored:
                try:
                    import state_capture_v1 as layer

                    report["layer_hook_failure_uninstall"] = llm.collective_rpc(
                        layer.uninstall_on_worker, args=(True,), timeout=60
                    )
                except BaseException:  # noqa: BLE001 -- preserve cleanup failure
                    report["errors"].append(traceback.format_exc())
            if layout_install_attempted and not layout_restored:
                try:
                    import prefill_collective_layout_v1 as layout

                    report["layout_failure_uninstall"] = llm.collective_rpc(
                        layout.uninstall_on_worker, args=(True,), timeout=60
                    )
                except BaseException:  # noqa: BLE001 -- preserve cleanup failure
                    report["errors"].append(traceback.format_exc())
            try:
                llm.llm_engine.engine_core.shutdown()
                report["shutdown_returned"] = True
            except BaseException:  # noqa: BLE001 -- retain interruption/failure and always clean up
                report["errors"].append(traceback.format_exc())
        if "prefixes_before_abort" in report:
            from new_loss_checks_v1 import reproduction_checks

            references = json.loads(
                Path(__file__).with_name("historical-prefixes-v1.json").read_text()
            )
            report["full_run_reproduction"] = reproduction_checks(report, references)
        report["finished_at"] = now()
        report["passed"] = bool(
            report["collection_complete"]
            and report["shutdown_returned"]
            and not report["errors"]
        )
        save(args.output / "run.json", report)
    print(
        json.dumps(
            {
                "passed": report["passed"],
                "output": str(args.output),
                "errors": report["errors"],
            }
        )
    )
    return 0 if report["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=PROFILES, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return run(parser.parse_args())


if __name__ == "__main__":
    raise SystemExit(main())
