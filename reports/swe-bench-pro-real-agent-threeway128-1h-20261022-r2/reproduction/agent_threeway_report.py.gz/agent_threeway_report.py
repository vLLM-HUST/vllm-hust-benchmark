"""Three-arm view of the existing real-Agent statistics; offline only."""
import base64
import csv
import html
import json

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, PercentFormatter, StrMethodFormatter

from agent_report_data import counter_delta
from report_agent_devices import METRICS, read_device_rows
from plot_run import BLUE, AQUA, ORANGE, style

ARMS = {
    'native': ('Native', BLUE),
    'thunderagent_original': ('ThunderAgent original', AQUA),
    'controller_original': ('Controller original', ORANGE),
}


def render_threeway(data, output, run, window, boundaries, rate_window, sources, question):
    """Preserve actual group identities, common windows and missing values."""
    figures = []
    plt.rcParams.update({'font.size': 10, 'axes.titlesize': 11,
                         'svg.hashsalt': 'agent-threeway-report-v1'})

    def save(fig, name, title):
        fig.suptitle(title, fontsize=14)
        fig.tight_layout(rect=(0, .04, 1, .94))
        for suffix in ('png', 'svg', 'pdf'):
            fig.savefig(output / (name + '.' + suffix), dpi=150)
        plt.close(fig)
        figures.append((name, title))

    def units(ax, ylabel):
        style(ax, ylabel)
        if 'fraction' in ylabel.lower():
            ax.yaxis.set_major_locator(MaxNLocator(5))
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1))
        elif ylabel not in ('Count', 'Requests', 'Preemptions', 'Programs', 'Completed model requests'):
            ax.yaxis.set_major_locator(MaxNLocator(5))
            ax.yaxis.set_major_formatter(StrMethodFormatter('{x:,.2f}'))
        else:
            ax.set_ylim(bottom=0)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=5, integer=True, min_n_ticks=1))

    def finish(ax, ylabel):
        units(ax, ylabel)
        ax.set_xlabel('Seconds since each arm started')
        ax.set_xlim(0, window)
        ax.legend(frameon=False, fontsize=8)

    def value(v):
        return np.nan if v is None else v

    def rates(rows, key, denominator=None):
        times, values = [], []
        left = 0
        for right, last in enumerate(rows):
            while left + 1 < right and rows[left + 1]['t'] <= last['t'] - rate_window:
                left += 1
            first = rows[left]
            dt = last['t'] - first['t']
            if dt <= 0:
                continue
            numerator = counter_delta(first, last, key)
            divisor = counter_delta(first, last, denominator) if denominator else dt
            times.append(last['t'])
            values.append(numerator / divisor if numerator is not None and divisor else np.nan)
        return times, values

    fig, axes = plt.subplots(2, 2, figsize=(12.4, 7.8), sharex=True)
    for arm, (label, color) in ARMS.items():
        rows = data[arm]['rows']; times = [r['t'] for r in rows]
        for ax, state in zip(axes.flat[:2], ('active', 'paused')):
            counts = [sum(p.get('state') == state for p in r['programs'].values())
                      if r['programs'] is not None else np.nan for r in rows]
            ax.plot(times, counts, color=color, label=label)
        axes[1, 0].plot(times, [len(r['scheduler']['waiting'])
            if r['scheduler'] is not None and 'waiting' in r['scheduler'] else np.nan
            for r in rows], color=color, label=label)
        axes[1, 1].plot(times, [value(r['m'].get('vllm:num_requests_running')) for r in rows],
                        color=color, label=label)
    for ax, title in zip(axes.flat, ('Active programs', 'Paused programs',
                                    'Controller waiting programs', 'Engine running requests')):
        ax.set_title(title, loc='left');finish(ax, 'Count')
    fig.text(.5, .01, 'Snapshot states; missing Controller observations remain missing. Engine execution is a separate layer.', ha='center', fontsize=8)
    save(fig, 'controller', 'CONTROLLER | Admission states and the downstream engine')

    fig, axes = plt.subplots(3, 3, figsize=(14, 10.5), sharex=True)
    specifications = [('generation_tokens_total', None, 'Engine output', 'Tokens/s'),
                ('prefix_cache_hits_total', 'prefix_cache_queries_total', 'Prefix cache hit fraction', 'Hit/query token fraction'),
        ('prefix_cache_hits_total', None, 'Cache hits', 'Tokens/s')]
    for arm, (label, color) in ARMS.items():
        rows = data[arm]['rows'];times = [r['t'] for r in rows]
        for ax, (key, denominator, title, unit) in zip(axes[0], specifications):
            x, y = rates(rows, key, denominator);ax.plot(x, y, color=color, label=label)
            ax.set_title(title, loc='left');finish(ax, unit)
        for ax, key, title, unit in zip(axes[1],
                ('kv_cache_usage_perc', 'num_requests_waiting', 'num_preemptions_total'),
                ('KV pool usage', 'Engine waiting requests', 'Cumulative preemptions'),
                ('Fraction of cache pool', 'Requests', 'Preemptions')):
            first = rows[0]['m'].get('vllm:' + key)
            vals = [value(r['m'].get('vllm:' + key)) for r in rows]
            if key == 'num_preemptions_total':
                vals = [v - value(first) for v in vals]
            ax.plot(times, vals, color=color, label=label);ax.set_title(title, loc='left');finish(ax, unit)
        for ax, key, title in ((axes[2, 0], 'request_prefill_kv_computed_tokens_sum', 'Computed prefill tokens'),
                               (axes[2, 1], 'prompt_tokens_total', 'Engine prompt tokens')):
            x, y = rates(rows, key);ax.plot(x, y, color=color, label=label)
            ax.set_title(title, loc='left');finish(ax, 'Tokens/s')
        capacity = data[arm]['cache_gib_per_rank']
        axes[2, 2].plot(times, [value(r['m'].get('vllm:kv_cache_usage_perc')) * value(capacity) for r in rows],
                        color=color, label=label)
        axes[2, 2].set_title('Cache-pool occupied capacity per rank', loc='left');finish(axes[2, 2], 'GiB per rank')
    for ax in axes.flat:
        if not any(np.isfinite(np.asarray(line.get_ydata(), dtype=float)).any() for line in ax.lines):
            ax.text(.5, .5, 'not recorded', transform=ax.transAxes, ha='center')
    fig.text(.5, .01, f'Counter rates use a backward {rate_window:g}s sampled interval; sequential HTTP observations are not atomic.', ha='center', fontsize=8)
    save(fig, 'engine-load', 'ENGINE | Output, cache reuse and memory pressure')

    phases = list(zip([0, *boundaries], [*boundaries, window]))
    labels = [f'{lo:g}-{hi:g}s' for lo, hi in phases]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.8))
    for ax, metric, title in zip(axes,
            ('request_queue_time_seconds', 'request_prefill_time_seconds', 'request_decode_time_seconds'),
            ('Engine queue', 'Engine prefill', 'Engine decode')):
        for index, (arm, (label, color)) in enumerate(ARMS.items()):
            vals = [value(data[arm]['phases'][f'{lo:g}-{hi:g}']['histograms'][metric]['mean']) for lo, hi in phases]
            ax.bar(np.arange(len(phases)) + (index - 1) * .25, vals, width=.25, color=color, label=label)
        ax.set_xticks(range(len(phases)), labels);ax.set_title(title, loc='left')
        units(ax, 'Completed engine requests: mean seconds');ax.legend(frameon=False, fontsize=8);ax.margins(y=.2)
    fig.text(.5, .01, 'Histogram sum/count deltas; engine queue excludes admission waiting outside the engine. Missing values are not zero.', ha='center', fontsize=8)
    save(fig, 'engine-latency-and-batches', 'ENGINE | Queue, prefill and decode stage latency')

    fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.8))
    for ax, metric, title in zip(axes, ('time_to_first_token_seconds', 'request_time_per_output_token_seconds'),
                                ('Engine first-token latency', 'Engine per-output-token latency')):
        for index, (arm, (label, color)) in enumerate(ARMS.items()):
            vals = [value(data[arm]['phases'][f'{lo:g}-{hi:g}']['histograms'][metric]['mean']) for lo, hi in phases]
            ax.bar(np.arange(len(phases)) + (index - 1) * .25, vals, width=.25, color=color, label=label)
        ax.set_xticks(range(len(phases)), labels);ax.set_title(title, loc='left');units(ax, 'Mean seconds');ax.margins(y=.2)
        ax.legend(frameon=False, fontsize=8)
    save(fig, 'engine-token-latency', 'ENGINE | Internal token latency, excluding external admission waiting')

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.8), sharex=True, sharey=True)
    for ax, (arm, (label, _)) in zip(axes, ARMS.items()):
        programs = data[arm]['programs'];edges = np.linspace(0, window, 181)
        matrix = [[sum(q['t'] <= t for q in p['returns']) for t in edges] for p in programs]
        im = ax.imshow(matrix, aspect='auto', origin='lower', extent=(0, window, 0, len(programs)),
                       interpolation='nearest', cmap='Blues', vmin=0,
                       vmax=max(1, max(len(p['returns']) for d in data.values() for p in d['programs'])))
        ax.set_title(label);ax.set_xlabel('Seconds since arm started');ax.set_ylabel('All program indices')
    fig.colorbar(im, ax=list(axes), label='Completed model requests', fraction=.025, pad=.02)
    fig.suptitle('PROGRAM | All programs, including late and zero replies', fontsize=14)
    # Reserve colorbar explicitly; do not let tight_layout overlap it.
    fig.subplots_adjust(right=.88, bottom=.15, top=.82, wspace=.2)
    for suffix in ('png', 'svg', 'pdf'):
        fig.savefig(output / ('program.' + suffix), dpi=150)
    plt.close(fig);figures.append(('program', 'PROGRAM | All programs, including late and zero replies'))

    fig, axes = plt.subplots(2, 2, figsize=(12.4, 7.8))
    edges = np.arange(0, window, rate_window).tolist() + [window]
    for arm, (label, color) in ARMS.items():
        replies = data[arm]['returns']
        for ax, weights, title in ((axes[0, 0], None, 'Completed model requests/s'),
                (axes[0, 1], [r['output'] for r in replies], 'Client-delivered output tokens/s')):
            counts, _ = np.histogram([r['t'] for r in replies], bins=edges, weights=weights)
            ax.step(edges[1:], counts / np.diff(edges), where='pre', color=color, label=label)
            ax.set_title(title, loc='left');finish(ax, title.split('/')[0] + '/s')
        lat = np.sort([r['latency'] for r in replies])
        axes[1, 0].plot(lat, np.arange(1, len(lat) + 1) / len(lat) if len(lat) else [], color=color, label=label)
        per_program = sorted(len(p['returns']) for p in data[arm]['programs'])
        axes[1, 1].plot(per_program, np.arange(1, len(per_program) + 1) / len(per_program), color=color, label=label)
    for ax, xlabel, title in ((axes[1, 0], 'Client end-to-end seconds, including admission wait', 'Request latency CDF: completed only'),
                              (axes[1, 1], 'Completed model requests per program', 'Program progress distribution')):
        ax.set_title(title, loc='left');units(ax, 'Cumulative fraction');ax.set_xlabel(xlabel);ax.legend(frameon=False, fontsize=8)
    save(fig, 'request', 'REQUEST | Client throughput, end-to-end latency and progress')

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.8))
    for ax, key, title in zip(axes, ('mean_latency_s', 'p95_latency_s', 'p99_latency_s'),
                              ('Mean client latency', '95th-percentile client latency', '99th-percentile client latency')):
        for index, (arm, (label, color)) in enumerate(ARMS.items()):
            vals = [value(data[arm]['phases'][f'{lo:g}-{hi:g}']['client'][key]) for lo, hi in phases]
            ax.bar(np.arange(len(phases)) + (index - 1) * .25, vals, width=.25, color=color, label=label)
        ax.set_xticks(range(len(phases)), labels);ax.set_title(title, loc='left')
        units(ax, 'Client end-to-end seconds');ax.legend(frameon=False, fontsize=8);ax.margins(y=.2)
    save(fig, 'request-latency-by-interval', 'REQUEST | Completed-client latency by return-time interval')

    fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.8))
    for arm, (label, color) in ARMS.items():
        programs = data[arm]['programs'];first = sorted(min(q['t'] for q in p['returns']) for p in programs if p['returns'])
        axes[0].step([0, *first, window], [0, *range(1, len(first) + 1), len(first)], color=color, label=label, where='post')
        counts = sorted(len(p['returns']) for p in programs)
        axes[1].plot(range(1, len(counts) + 1), counts, color=color, label=label)
    axes[0].set_title('Programs receiving a first normal model reply', loc='left');finish(axes[0], 'Programs')
    axes[1].set_title('All programs sorted by their own reply count', loc='left')
    units(axes[1], 'Completed model requests');axes[1].set_xlabel('Sorted program index');axes[1].legend(frameon=False, fontsize=8)
    save(fig, 'controller-first-call', 'CONTROLLER / PROGRAM | First-call access and progress distribution')

    device_data = {}
    fig, axes = plt.subplots(2, 2, figsize=(12.4, 7.8), sharex=True)
    for arm, (label, color) in ARMS.items():
        path = run / data[arm]['evidence_path'] / 'device-observations-private.jsonl'
        if not path.exists():
            device_data[arm] = None;continue
        device_data[arm] = read_device_rows(path, data[arm]['origin_epoch'], window)
        sources[str(path.relative_to(run))] = device_data[arm]['source_sha256']
        for ax, (metric, title) in zip(axes.flat, METRICS.items()):
            for index, (card, points) in enumerate(sorted(device_data[arm]['points'][metric].items())):
                points.sort();ax.plot([p[0] for p in points], [p[1] for p in points], color=color,
                    ls=('-', '--', ':')[index % 3], label=label + ' card ' + card, lw=1)
            ax.set_title(title, loc='left');finish(ax, 'Exporter native units')
    fig.text(.5, .01, 'AI Core uses unique recorded scrape timestamps; other metrics use query-observed points. Utilization alone is not saturation proof.', ha='center', fontsize=8)
    save(fig, 'engine-device', 'ENGINE / DEVICE | Recorded physical-card observations')

    summary = []
    phases = list(zip([0, *boundaries], [*boundaries, window])) + [(0, window)]
    for arm, (label, _) in ARMS.items():
        for lo, hi in phases:
            p = data[arm]['phases'][f'{lo:g}-{hi:g}'];c = p['engine_counter_deltas'];client = p['client']
            summary.append({'arm': arm, 'phase_seconds': f'{lo:g}-{hi:g}',
                'engine_sample_start_s': p['engine_sample_start_s'], 'engine_sample_end_s': p['engine_sample_end_s'],
                'engine_output_tokens_per_s': p['engine_counter_rates_per_second']['generation_tokens_total'],
                'client_returns_per_s': client['returns'] / (hi - lo),
                'client_output_tokens_per_s': client['output_tokens'] / (hi - lo),
                'prefix_hit_fraction': c['prefix_cache_hits_total'] / c['prefix_cache_queries_total']
                    if c['prefix_cache_hits_total'] is not None and c['prefix_cache_queries_total'] else None,
                'preemptions': c['num_preemptions_total'],
                'computed_prefill_tokens': p['histograms']['request_prefill_kv_computed_tokens']['sum'],
                'engine_mean_running_requests': p['engine_time_weighted_means']['num_requests_running'],
                'engine_mean_waiting_requests': p['engine_time_weighted_means']['num_requests_waiting'],
                'mean_kv_pool_fraction': p['engine_time_weighted_means']['kv_cache_usage_perc'],
                **{key: client[key] for key in ('mean_latency_s', 'p50_latency_s', 'p95_latency_s', 'p99_latency_s')}})
    with (output / 'summary.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    with (output / 'normal-client-returns.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=['arm', 'program', 't', 'start', 'latency', 'input', 'output']);writer.writeheader()
        for arm, d in data.items():
            writer.writerows({'arm': arm, **r} for r in d['returns'])
    payload = {'window_seconds': window, 'phase_boundaries_seconds': boundaries, 'summary': summary,
        'arms': {arm: {k: d[k] for k in ('agent_count', 'settings', 'phases', 'pending', 'errors', 'cache_gib_per_rank')}
                 for arm, d in data.items()}, 'devices': device_data}
    (output / 'data.json').write_text(json.dumps(payload, indent=2, allow_nan=False) + '\n')
    (output / 'source-sha256.json').write_text(json.dumps(sources, indent=2) + '\n')
    report = ['# 真实 SWE-bench Pro 三组系统性能', '', question, '',
        f'各组 {window:g} 秒、每组 {data["native"]["agent_count"]} 个真实 Agent program；整批 time0、无客户端 slots。',
        '系统性能独立于解答提交数及质量评分。以下为同预算窗口性能，不是完整批次 makespan。', '',
        '## 系统链路与统计边界', '',
        '真实 Agent → Native / 独立 ThunderAgent 原版 / Controller 原版 → 同一模型引擎 → 返回 Agent → 实际工具 → 下一轮。',
        '客户端延迟包含准入等待，按正常返回时间归窗；失败和窗口末未返回保留。引擎聚合直方图不能代替客户端分位数。',
        '计数器使用段内首末实际采样，端点及分母见 summary.csv；非原子顺序采样不外推补齐。', '',
        '|组别|窗口末未返回请求|窗口内异常请求|', '|---|---:|---:|']
    for arm, (label, _) in ARMS.items():
        report.append(f'|{label}|{data[arm]["pending"]}|{data[arm]["errors"]}|')
    report += ['', '## 同一窗口系统数据', '', '|组别|阶段秒|引擎输出 token/s|客户端 request/s|平均延迟 s|P50 s|P95 s|P99 s|缓存命中率 %|抢占|',
               '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    def fmt(v):
        return '未记录' if v is None else f'{v:.3f}'
    for row in summary:
        report.append('|' + '|'.join([ARMS[row['arm']][0], row['phase_seconds'], *[fmt(
            row[k] * 100 if k == 'prefix_hit_fraction' and row[k] is not None else row[k]) for k in
            ('engine_output_tokens_per_s', 'client_returns_per_s', 'mean_latency_s', 'p50_latency_s',
             'p95_latency_s', 'p99_latency_s', 'prefix_hit_fraction', 'preemptions')]]) + '|')
    for name, title in figures:
        report += ['', '## ' + title, '', f'![{title}]({name}.png)', '',
            '按各组实际开始对齐。保留所有阶段及程序；状态快照不代表逐事件因果，设备利用率不单独证明硬件饱和。']
    report += ['', '## 解释边界', '',
        '三组真实模型输出会改变后续轨迹、请求长度和工具等待，因此比较的是同协议窗口系统行为。',
        'ThunderAgent 与 Controller 出现相似下降仅支持共同因素，仍需区分原算法、共同适配、容量、引擎和工作负载。',
        '缺少逐块 evict/touch 或逐请求缓存关联时，不把缓存命中变化直接写成已证驱逐因果；异常及收尾超时需结合原件单列。']
    markdown = '\n'.join(report) + '\n';(output / 'report.md').write_text(markdown)
    # Standalone HTML follows the same text and embeds the identical figures.
    body = [];in_table = False
    for line in report:
        if line.startswith('|'):
            if not in_table:
                body.append('<table>');in_table = True
            if set(line.replace('|', '').replace(':', '').replace(' ', '')) <= {'-'}:
                continue
            body.append('<tr>' + ''.join('<td>' + html.escape(x) + '</td>' for x in line.strip('|').split('|')) + '</tr>')
            continue
        if in_table:
            body.append('</table>');in_table = False
        if line.startswith('!['):
            name = line.split('](')[1][:-1]
            encoded = base64.b64encode((output / name).read_bytes()).decode()
            body.append(f'<img alt="{html.escape(name)}" src="data:image/png;base64,{encoded}">')
        elif line.startswith('## '):
            body.append('<h2>' + html.escape(line[3:]) + '</h2>')
        elif line.startswith('# '):
            body.append('<h1>' + html.escape(line[2:]) + '</h1>')
        else:
            body.append('<p>' + html.escape(line) + '</p>')
    (output / 'report.html').write_text('<!doctype html><meta charset="utf-8"><title>真实 SWE-bench Pro 系统性能</title>'
        '<style>body{max-width:1200px;margin:32px auto;padding:0 24px;font:16px/1.7 sans-serif;color:#172333}img{width:100%;height:auto}p{white-space:pre-wrap}table{border-collapse:collapse;width:100%;font-size:14px}td{padding:8px;border-bottom:1px solid #dce2e8}h2{margin-top:48px;border-top:1px solid #dce2e8;padding-top:20px}</style>' + ''.join(body))
    return {'figures': len(figures), 'summary_rows': len(summary)}
