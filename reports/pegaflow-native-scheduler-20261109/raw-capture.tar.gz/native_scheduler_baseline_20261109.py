"""Collect a finite real-model scheduling trace using one allocated NPU."""

import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import traceback
import urllib.request


ROOT = Path(__file__).resolve().parent / 'baseline-v2'
PYTHON = '/usr/local/python3.12.13/bin/python3.12'


def main():
    ROOT.mkdir(exist_ok=False)
    stopped = threading.Event()
    process = None

    def watchdog():
        if not stopped.wait(900):
            (ROOT / 'timeout.json').write_text(json.dumps({'epoch_ns': time.time_ns()}))
            if process is not None:
                os.killpg(process.pid, signal.SIGTERM)

    def monitor():
        with (ROOT / 'resources.jsonl').open('w') as f:
            while not stopped.is_set():
                try:
                    p = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=8)
                    f.write(json.dumps({'epoch_ns': time.time_ns(), 'npu': p.stdout,
                                        'memory': Path('/sys/fs/cgroup/memory.current').read_text(),
                                        'cpu': Path('/sys/fs/cgroup/cpu.stat').read_text()}) + '\n')
                    f.flush()
                except Exception as e:
                    f.write(json.dumps({'error': str(e)}) + '\n')
                stopped.wait(3)

    threading.Thread(target=watchdog, daemon=True).start()
    threading.Thread(target=monitor, daemon=True).start()
    try:
        import httpx
        env = dict(os.environ, ASCEND_RT_VISIBLE_DEVICES='0', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH=str(ROOT.parent) + ':' + os.environ.get('PYTHONPATH', ''),
                   NATIVE_TRACE_ROOT=str(ROOT / 'trace'), HF_HUB_OFFLINE='1',
                   VLLM_SERVER_DEV_MODE='1', TOKENIZERS_PARALLELISM='false', PYTHONHASHSEED='17')
        command = [PYTHON, '-m', 'vllm.entrypoints.cli.main', 'serve', '/data/shared_models/Qwen2.5-7B-Instruct',
                   '--host', '127.0.0.1', '--port', '38480', '--served-model-name', 'qwen25',
                   '--dtype', 'bfloat16', '--tensor-parallel-size', '1', '--max-model-len', '32768',
                   '--max-num-seqs', '16', '--max-num-batched-tokens', '2048', '--block-size', '128',
                   '--kv-cache-memory-bytes', str(16 * 2**30), '--enable-prefix-caching',
                   '--no-async-scheduling', '--seed', '17', '--generation-config', 'vllm',
                   '--safetensors-load-strategy', 'lazy', '--scheduler-cls',
                   'native_scheduler_trace_20261109.NativeTraceScheduler',
                   '--compilation-config', json.dumps({'mode': 3, 'cudagraph_mode': 'FULL_DECODE_ONLY',
                                                       'cudagraph_capture_sizes': [1, 2, 4, 8, 16]})]
        (ROOT / 'config.json').write_text(json.dumps({'command': command, 'devices': 1, 'scope': 'scheduler parity'}, indent=2))
        with (ROOT / 'model.log').open('w') as log:
            process = subprocess.Popen(command, env=env, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            (ROOT / 'model-process.json').write_text(json.dumps({'pid': process.pid, 'command': command}))
            deadline = time.monotonic() + 330
            while True:
                if process.poll() is not None:
                    raise RuntimeError('Real model exited during startup')
                try:
                    urllib.request.urlopen('http://127.0.0.1:38480/health', timeout=1).read()
                    break
                except Exception:
                    if time.monotonic() > deadline:
                        raise TimeoutError('Model readiness deadline')
                    time.sleep(.5)
            rows = [json.loads(line) for line in Path('/data/shared_upload/hust-zsx/issue23-calibration-20261029/V/requests.jsonl').read_text().splitlines()]
            long = max((r for r in rows if r['split'] == 'calibration'), key=lambda r: r['prompt_tokens'])

            async def collect():
                async with httpx.AsyncClient(timeout=120, trust_env=False) as client:
                    output = (ROOT / 'requests.jsonl').open('w')

                    async def request(label, i, length, tokens, salt):
                        key = f'native29-{label}-{i}'
                        start = time.monotonic_ns()
                        response = await client.post('http://127.0.0.1:38480/v1/completions', json={
                            'model': 'qwen25', 'prompt': long['prompt_token_ids'][:length], 'temperature': 0,
                            'max_tokens': tokens, 'ignore_eos': True, 'request_id': key, 'cache_salt': salt})
                        response.raise_for_status()
                        record = {'id': key, 'case': label, 'prompt_tokens': length, 'output_tokens': tokens,
                                  'begin_ns': start, 'end_ns': time.monotonic_ns(), 'response': response.json()}
                        output.write(json.dumps(record) + '\n'); output.flush()
                        print(json.dumps({k: v for k, v in record.items() if k != 'response'}), flush=True)

                    for i, length in enumerate([2049, 8193, 16385, 24577]):
                        (await client.post('http://127.0.0.1:38480/reset_prefix_cache')).raise_for_status()
                        await request('serial', i, length, 16, f'cold-{i}')
                    (await client.post('http://127.0.0.1:38480/reset_prefix_cache')).raise_for_status()
                    await asyncio.gather(*(request('mixed4', i, length, 32, f'mixed-{i}') for i, length in enumerate([2049, 8193, 16385, 24577])))
                    for label in ['shared-first', 'shared-warm']:
                        await asyncio.gather(*(request(label, i, 8193, 32, 'shared') for i in range(4)))
                    (await client.post('http://127.0.0.1:38480/reset_prefix_cache')).raise_for_status()
                    await asyncio.gather(*(request('mixed8', i, [513, 2049, 4097, 8193][i % 4], [32, 64, 128][i % 3], f'eight-{i}') for i in range(8)))
                    output.close()

            asyncio.run(collect())
            (ROOT / 'done.json').write_text(json.dumps({'requests': 24, 'epoch_ns': time.time_ns()}))
    except BaseException:
        (ROOT / 'failure.json').write_text(json.dumps({'traceback': traceback.format_exc()}))
        raise
    finally:
        stopped.set()
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(12)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)


if __name__ == '__main__':
    main()
