import json,sys,pytest,traceback
from pathlib import Path
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'code'))
status=pytest.main(['-q',str(p/'code/test_native_vllm_adapter.py'),'--junitxml='+str(p/'native-tests-accepted.xml')])
from replay_native_trace import replay
results={}
for label,folder in [('baseline','baseline-v2/trace'),('P','local-pd/P/trace'),('D','local-pd/D/trace')]:
 try:
  trace=list((p/folder).glob('process-*.jsonl'))
  assert len(trace)==1
  result=replay([json.loads(x) for x in trace[0].read_text().splitlines()],'/data/shared_models/Qwen2.5-7B-Instruct')
 except Exception:
  result={'passed':False,'traceback':traceback.format_exc()}
 (p/f'parity-{label}-accepted.json').write_text(json.dumps(result,indent=2))
 results[label]=result
 print(label,json.dumps(result),flush=True)
(p/'validation-accepted.json').write_text(json.dumps({'pytest_exit':int(status),'parity':results},indent=2))
