"""Finite two-NPU local PegaFlow handoff and native scheduling capture."""

import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import traceback
import urllib.request

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'local-pd'
PYTHON = '/usr/local/python3.12.13/bin/python3.12'
SOURCE = '/data/shared_upload/hust-zsx/issue23-generalization-20261027/source/python'
BINARY = '/data/shared_upload/hust-zsx/issue23-scaled-20261014/runtime/bin/pegaflow-server'


def main():
    ROOT.mkdir(exist_ok=False)
    processes = []
    stopped = threading.Event()

    def stop():
        for p in reversed(processes):
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGTERM)
        for p in reversed(processes):
            try:
                p.wait(10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)

    def watchdog():
        if not stopped.wait(900):
            (ROOT / 'timeout.json').write_text(json.dumps({'epoch_ns': time.time_ns()}))
            stop()

    threading.Thread(target=watchdog, daemon=True).start()

    def spawn(name, command, env):
        log = (ROOT / (name + '.log')).open('x')
        p = subprocess.Popen(command, env=env, cwd=ROOT, stdout=log,
                             stderr=subprocess.STDOUT, start_new_session=True)
        log.close()
        processes.append(p)
        (ROOT / (name + '-process.json')).write_text(json.dumps({'pid': p.pid, 'command': command}))
        return p

    def ready(process, url, seconds):
        until = time.monotonic() + seconds
        while True:
            if process.poll() is not None:
                raise RuntimeError('Service exited before ready: ' + url)
            try:
                urllib.request.urlopen(url, timeout=1).read()
                return
            except Exception:
                if time.monotonic() > until:
                    raise TimeoutError(url)
                time.sleep(.5)

    try:
        env = dict(os.environ, LD_LIBRARY_PATH='/usr/local/python3.12.13/lib:' + os.environ.get('LD_LIBRARY_PATH', ''),
                   PYTHONPATH=f'{BASE}:{SOURCE}:' + os.environ.get('PYTHONPATH', ''),
                   OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKIO_WORKER_THREADS='2',
                   HF_HUB_OFFLINE='1', PYTHONHASHSEED='17', TOKENIZERS_PARALLELISM='false',
                   VLLM_SERVER_DEV_MODE='1', PEGAFLOW_SYNC_SAVE='1', PEGAFLOW_SYNC_SAVE_ON_FINISH='1',
                   PEGAFLOW_ISSUE23_DEFAULT_SCHEDULER='1', VLLM_WORKER_MULTIPROC_METHOD='spawn')
        env.pop('ASCEND_RT_VISIBLE_DEVICES', None)
        p = spawn('native', [BINARY, '--devices', '0,1', '--pool-size', '16gb', '--disable-numa-affinity',
                            '--addr', '127.0.0.1:38450', '--http-addr', '127.0.0.1:38490', '--enable-prometheus'], env)
        ready(p, 'http://127.0.0.1:38490/health', 60)
        roles = []
        for i, role in enumerate(['P', 'D']):
            transfer = {'kv_connector': 'PegaKVConnector', 'kv_connector_module_path': 'pegaflow.connector',
                        'kv_role': 'kv_both', 'engine_id': 'native-adapter-20261109-' + role,
                        'kv_connector_extra_config': {'pegaflow.model_revision': 'a09a35458c702b33eeacc393d103063234e8bc28',
                        'pegaflow.transfer_backend': 'ascend_direct', 'pegaflow.mode': 'save_only' if role == 'P' else 'read_write',
                        'pegaflow.host': 'http://127.0.0.1', 'pegaflow.port': 38450}}
            command = [PYTHON, '-m', 'vllm.entrypoints.cli.main', 'serve', '/data/shared_models/Qwen2.5-7B-Instruct',
                       '--host', '127.0.0.1', '--port', str(38481 + i), '--served-model-name', 'qwen25',
                       '--dtype', 'bfloat16', '--tensor-parallel-size', '1', '--max-model-len', '32768',
                       '--max-num-seqs', '16', '--max-num-batched-tokens', '2048', '--block-size', '128',
                       '--kv-cache-memory-bytes', str(16 * 2**30), '--enable-prefix-caching', '--no-async-scheduling',
                       '--seed', '17', '--generation-config', 'vllm', '--safetensors-load-strategy', 'lazy',
                       '--scheduler-cls', 'native_scheduler_trace_20261109.NativeTraceScheduler',
                       '--kv-transfer-config', json.dumps(transfer), '--compilation-config', json.dumps({
                           'mode': 3, 'cudagraph_mode': 'FULL_DECODE_ONLY', 'cudagraph_capture_sizes': [1, 2, 4, 8, 16]})]
            current = dict(env, ASCEND_RT_VISIBLE_DEVICES=str(i), NATIVE_TRACE_ROOT=str(ROOT / role / 'trace'),
                           PEGAFLOW_TELEMETRY_DIR=str(ROOT / role / 'telemetry'), PEGAFLOW_TELEMETRY_ROLE=role,
                           PEGAFLOW_SAVE_ACK_DIR=str(ROOT / role / 'visibility'))
            roles.append(spawn(role, command, current))
        for i, process in enumerate(roles):
            ready(process, f'http://127.0.0.1:{38481 + i}/health', 360)
        import httpx
        rows = [json.loads(line) for line in Path('/data/shared_upload/hust-zsx/issue23-calibration-20261029/V/requests.jsonl').read_text().splitlines()]
        long = max((r for r in rows if r['split'] == 'calibration'), key=lambda r: r['prompt_tokens'])

        async def collect():
            async with httpx.AsyncClient(timeout=100, trust_env=False) as client:
                with (ROOT / 'requests.jsonl').open('x') as output:
                    async def request(role, case, i, length, tokens):
                        start = time.monotonic_ns()
                        response = await client.post(f'http://127.0.0.1:{38481 if role == "P" else 38482}/v1/completions', json={
                            'model': 'qwen25', 'prompt': long['prompt_token_ids'][:length], 'max_tokens': tokens,
                            'temperature': 0, 'ignore_eos': True, 'cache_salt': f'local-pd-{i}',
                            'request_id': f'local-pd-{role}-{case}-{i}'})
                        response.raise_for_status()
                        row = {'role': role, 'case': case, 'i': i, 'prompt_tokens': length,
                               'begin_ns': start, 'end_ns': time.monotonic_ns(), 'response': response.json()}
                        output.write(json.dumps(row) + '\n'); output.flush()
                        print(json.dumps({k: v for k, v in row.items() if k != 'response'}), flush=True)
                    for i, length in enumerate([2049, 8193, 16385, 24577]):
                        await request('P', 'seed', i, length, 1)
                    for case in ['restore', 'apc-warm']:
                        await asyncio.gather(*(request('D', case, i, length, 32)
                                               for i, length in enumerate([2049, 8193, 16385, 24577])))
        asyncio.run(collect())
        (ROOT / 'done.json').write_text(json.dumps({'requests': 12, 'epoch_ns': time.time_ns(),
             'scope': 'One host, two NPUs, shared native CPU pool; excludes cross-host transport'}))
    except BaseException:
        (ROOT / 'failure.json').write_text(json.dumps({'traceback': traceback.format_exc()}))
        raise
    finally:
        stopped.set()
        stop()


if __name__ == '__main__':
    main()
