import json,sys,traceback
from pathlib import Path
p=Path('/data/shared_upload/hust-zsx/native-scheduler-20261109')
sys.path.insert(0,str(p/'code'))
from replay_native_trace import replay
for label,folder in [('baseline','baseline-v2/trace'),('P','local-pd/P/trace'),('D','local-pd/D/trace')]:
 try:
  traces=list((p/folder).glob('process-*.jsonl'))
  assert len(traces)==1
  events=[json.loads(x) for x in traces[0].read_text().splitlines()]
  result=replay(events,'/data/shared_models/Qwen2.5-7B-Instruct')
 except Exception:
  result={'passed':False,'traceback':traceback.format_exc()}
 (p/f'parity-{label}-v2.json').write_text(json.dumps(result,indent=2))
 print(label,json.dumps(result),flush=True)
