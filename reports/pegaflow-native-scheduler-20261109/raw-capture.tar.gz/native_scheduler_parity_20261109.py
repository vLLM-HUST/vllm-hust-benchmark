"""Replay real-model scheduler events through the unmodified installed scheduler."""

import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))


def main():
    import inspect
    from vllm.config import SchedulerConfig
    from native_vllm_adapter import NativeVllmEngine

    traces = list((ROOT / 'baseline-v2/trace').glob('process-*.jsonl'))
    if len(traces) != 1:
        raise ValueError('Expected one real engine scheduling trace')
    events = [json.loads(line) for line in traces[0].read_text().splitlines()]
    config = next(e for e in events if e['event'] == 'config')
    options = dict(config['scheduler_fields'])
    maximum = options.pop('max_num_seqs')
    budget = options.pop('max_num_batched_tokens')
    limit = options.pop('max_model_len', 32768)
    for key in ['is_encoder_decoder', 'async_scheduling', 'scheduler_cls']:
        options.pop(key, None)
    valid = set(inspect.signature(SchedulerConfig).parameters)
    options = {key: value for key, value in options.items() if key in valid}
    engine = NativeVllmEngine(model_path='/data/shared_models/Qwen2.5-7B-Instruct',
                               num_blocks=config['num_gpu_blocks'], block_tokens=config['block_size'],
                               max_sequences=maximum, token_budget=budget, max_model_len=limit,
                               scheduler_options=options)
    mismatches = []
    counters = {'requests': 0, 'schedules': 0, 'updates': 0, 'resets': 0, 'scheduled_tokens': 0}

    def compare(frame):
        actual = engine.snapshot()
        expected = frame['after']
        if actual.keys() != expected.keys():
            mismatches.append({'step': frame.get('step'), 'event': frame['event'],
                               'field': 'request-set', 'actual': list(actual), 'expected': list(expected)})
            return
        for key in actual:
            for field in ['computed', 'outputs', 'status', 'preemptions', 'block_ids']:
                a = json.loads(json.dumps(actual[key][field]))
                b = expected[key][field]
                if a != b:
                    mismatches.append({'step': frame.get('step'), 'event': frame['event'],
                                       'request': key, 'field': field, 'actual': a, 'expected': b})

    try:
        for frame in events:
            kind = frame['event']
            if kind == 'add_request':
                engine.add(frame['request_id'], len(frame['prompt_token_ids']), frame['max_tokens'], frame['arrival_time'],
                           prompt_token_ids=frame['prompt_token_ids'], cache_salt=frame['cache_salt'],
                           priority=frame['priority'], native_prefix_hashes=frame['block_hashes'])
                counters['requests'] += 1
            elif kind == 'reset_prefix_cache':
                engine.scheduler.reset_prefix_cache(*frame['args'], **frame['kwargs'])
                counters['resets'] += 1
            elif kind == 'schedule':
                rows = engine.schedule()
                planned = {key: count for key, count, _ in rows}
                if planned != frame['tokens']:
                    mismatches.append({'step': frame['step'], 'event': kind, 'field': 'scheduled_tokens',
                                       'actual': planned, 'expected': frame['tokens']})
                compare(frame)
                counters['schedules'] += 1
                counters['scheduled_tokens'] += sum(planned.values())
            elif kind == 'update':
                engine.complete(frame['sampled'])
                compare(frame)
                counters['updates'] += 1
            if mismatches:
                break
        result = {'identity': engine.identity, 'counts': counters, 'mismatches': mismatches,
                  'passed': not mismatches, 'scope': 'Native iteration/token/block/state parity on one-NPU real-model traces; timing costs not fitted'}
        (ROOT / 'native-parity.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result))
        if mismatches:
            raise RuntimeError('Native scheduler parity differs')
    finally:
        engine.shutdown()


if __name__ == '__main__':
    main()
