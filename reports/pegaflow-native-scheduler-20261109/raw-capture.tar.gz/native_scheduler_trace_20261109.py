"""Observe the installed scheduler without changing its scheduling decisions."""

import atexit
import dataclasses
import json
import os
from pathlib import Path
import time

from vllm.v1.core.sched.scheduler import Scheduler


_writer = None


def emit(event, **values):
    global _writer
    if _writer is None:
        root = Path(os.environ['NATIVE_TRACE_ROOT'])
        root.mkdir(parents=True, exist_ok=True)
        _writer = (root / f'process-{os.getpid()}.jsonl').open('a', buffering=65536)
        atexit.register(_writer.close)
    _writer.write(json.dumps({'event': event, 'monotonic_ns': time.monotonic_ns(),
                              'epoch_ns': time.time_ns(), 'pid': os.getpid(), **values}, default=str) + '\n')
    _writer.flush()


class NativeTraceScheduler(Scheduler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.trace_step = 0
        if self.connector is not None:
            query = self.connector.get_num_new_matched_tokens
            allocated = self.connector.update_state_after_alloc
            finished = self.connector.request_finished

            def observe_query(request, computed):
                result = query(request, computed)
                emit('external_query', request_id=request.request_id, computed=computed, result=result)
                return result

            def observe_allocated(request, blocks, external):
                result = allocated(request, blocks, external)
                emit('external_allocated', request_id=request.request_id, external=external, blocks=blocks.get_block_ids())
                return result

            def observe_finished(request, blocks):
                result = finished(request, blocks)
                emit('external_finished', request_id=request.request_id, delayed=result[0])
                return result

            self.connector.get_num_new_matched_tokens = observe_query
            self.connector.update_state_after_alloc = observe_allocated
            self.connector.request_finished = observe_finished
        emit('config', scheduler=repr(self.scheduler_config), model=repr(self.vllm_config.model_config),
             scheduler_fields=dataclasses.asdict(self.scheduler_config),
             hash_seed=os.environ.get('PYTHONHASHSEED'),
             block_size=self.block_size, kv_config=repr(self.kv_cache_config),
             num_gpu_blocks=self.kv_cache_manager.block_pool.num_gpu_blocks,
             reserve_full_isl=getattr(self, 'scheduler_reserve_full_isl', None))

    def add_request(self, request):
        emit('add_request', request_id=request.request_id, prompt_token_ids=request.prompt_token_ids,
             max_tokens=request.max_tokens, arrival_time=request.arrival_time, priority=request.priority,
             cache_salt=request.cache_salt, block_hashes=[bytes(h).hex() for h in request.block_hashes])
        return super().add_request(request)

    def snapshot(self):
        return {key: {'computed': r.num_computed_tokens, 'outputs': r.num_output_tokens,
                      'status': r.status.name, 'preemptions': r.num_preemptions,
                      'cached_tokens': getattr(r, 'num_cached_tokens', None),
                      'block_ids': self.kv_cache_manager.get_block_ids(key)}
                for key, r in self.requests.items()}

    def schedule(self):
        self.trace_step += 1
        before = self.snapshot()
        start = time.monotonic_ns()
        result = super().schedule()
        emit('schedule', step=self.trace_step, begin_ns=start, before=before, after=self.snapshot(),
             tokens=result.num_scheduled_tokens, finished=list(result.finished_req_ids),
             running=[r.request_id for r in self.running],
             waiting=[r.request_id for r in self.waiting],
             skipped=[r.request_id for r in getattr(self, 'skipped_waiting', [])],
             free_blocks=self.kv_cache_manager.block_pool.get_num_free_blocks())
        return result

    def update_from_output(self, scheduler_output, model_runner_output):
        before = self.snapshot()
        sampled = model_runner_output.sampled_token_ids
        outputs = dict(zip(model_runner_output.req_ids, sampled))
        connector = model_runner_output.kv_connector_output
        start = time.monotonic_ns()
        result = super().update_from_output(scheduler_output, model_runner_output)
        emit('update', step=self.trace_step, begin_ns=start, before=before, after=self.snapshot(),
             sampled=outputs,
             recvs=list(connector.finished_recving or []) if connector else [],
             sends=list(connector.finished_sending or []) if connector else [],
             finished={str(client): [r.request_id for r in rows.outputs if getattr(r, 'finished', r.finish_reason is not None)]
                       for client, rows in result.items()})
        return result

    def _preempt_request(self, request, timestamp):
        emit('preempt', step=self.trace_step, request_id=request.request_id,
             computed=request.num_computed_tokens, outputs=request.num_output_tokens)
        return super()._preempt_request(request, timestamp)

    def reset_prefix_cache(self, *args, **kwargs):
        emit('reset_prefix_cache', args=args, kwargs=kwargs)
        return super().reset_prefix_cache(*args, **kwargs)
