"""Independent offline candidate audit; execute only after root terminal authorization."""

import argparse
import copy
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path

from tokenizers import Tokenizer

BUNDLE = Path("/root/workspace/muxpd-runtime-quality-candidate-v2-20261030")
FREEZE_SHA = "507f4c76f999476e7a182fca9b2e7ba1655a8678d37454b4286d18664f3fdfcb"
SCORER_SHA = "157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd"
sys.path.insert(0, str(BUNDLE))
# Reuse original scorer and previously reviewed runtime/lifecycle validators only.
# Deliberately never import candidate_quality_analysis_v2 or quality_tables_v1.
import candidate_checks_v1 as checks
import candidate_control_v1 as control
import probe_run_v1 as runtime
import run_quality
import score_quality as scorer
from probe_control_v1 import inventory


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def canonical(value):
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode()


def terminal(directory, legacy=False):
    value = read(directory / "controller.json")
    assert value["finished_at"] and value["passed"] and value["exit_code"] == 0
    if not legacy:
        assert value["terminal_process_proven"] is True
        assert (
            value["owned_members_before_cleanup"]
            == value["owned_members_after_cleanup"]
            == []
        )
        assert (
            not value["errors"]
            and not value.get("cleanup_required")
            and not value.get("forced_termination")
        )
        assert (
            value["idle_physical_before"]
            == value["idle_physical_after"]
            == value["expected_physical"]
        )
        assert value["expected_physical"] == ["3", "4", "5", "6"]
    return value


def schedule_check(report, directory, batches, cases):
    path = directory / "results/scheduler-receipts.jsonl"
    assert sha(path) == report["scheduler_receipts_sha256"]
    receipts = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(receipts) % 2 == 0 and len(receipts) == 2 * report["answer_engine_steps"]
    pairs = list(zip(receipts[::2], receipts[1::2], strict=True))
    assert [s["global_step"] for s, _ in pairs] == list(range(1, len(pairs) + 1))
    batch_ids = [b["batch_id"] for b in batches]
    assert sorted({s["batch_id"] for s, _ in pairs}) == batch_ids
    assert [s["batch_id"] for s, _ in pairs] == sorted(s["batch_id"] for s, _ in pairs)
    admissions = report["admissions"]
    assert len(admissions) == 2 * len(batches)
    case_map = {c["case_id"]: c for c in cases}
    outputs = {row["case_id"]: row for row in report["outputs"]}
    all_ids, all_external, results = set(), set(), []
    decode_turns = 0
    for n, batch in enumerate(batches):
        selected = [(s, r) for s, r in pairs if s["batch_id"] == batch["batch_id"]]
        order = batch["case_ids"]
        seed, peers = admissions[2 * n : 2 * n + 2]
        assert [(a["batch_id"], a["stage"]) for a in (seed, peers)] == [
            (batch["batch_id"], "seed"),
            (batch["batch_id"], "peers"),
        ]
        assert [[v["case_id"] for v in a["bindings"]] for a in (seed, peers)] == [
            order[:1],
            order[1:],
        ]
        assert seed["global_step"] == selected[0][0]["global_step"] - 1
        assert peers["global_step"] == selected[1][0]["global_step"] - 1
        assert peers["seed_output_tokens"] == 1 and peers["seed_still_live"] is True
        bindings = {v["case_id"]: v for a in (seed, peers) for v in a["bindings"]}
        ids = {c: bindings[c]["internal"] for c in order}
        external = {bindings[c]["external"] for c in order}
        assert len(set(ids.values())) == len(external) == 8
        assert not set(ids.values()) & all_ids and not external & all_external
        all_ids.update(ids.values())
        all_external.update(external)
        assert all(outputs[c]["request_id"] == bindings[c]["external"] for c in order)
        prompts = {ids[c]: len(case_map[c]["prompt_token_ids"]) for c in order}
        previous, sizes = set(), []
        retirements = dict.fromkeys(ids.values(), 0)
        for ordinal, (s, r) in enumerate(selected):
            p = (
                {ids[order[0]]}
                if ordinal == 0
                else {ids[c] for c in order[1:]}
                if ordinal == 1
                else set()
            )
            assert s["event"] == "schedule" and r["event"] == "retirement"
            assert (
                s["batch_id"] == r["batch_id"] == batch["batch_id"]
                and s["global_step"] == r["global_step"]
            )
            phases = s["phases_before"]
            assert set(phases) <= set(ids.values()) and set(phases.values()) <= {
                "P",
                "D",
            }
            d = {rid for rid, phase in phases.items() if phase == "D"}
            assert {rid for rid, phase in phases.items() if phase == "P"} == p
            assert (
                not d
                if ordinal == 0
                else d == {ids[order[0]]}
                if ordinal == 1
                else bool(d) and d <= previous
            )
            assert s["scheduled_tokens"] == (
                {rid: prompts[rid] for rid in p} | dict.fromkeys(d, 1)
            )
            assert set(s["new_prefill_ids"]) == set(s["pending_prefill_ids"]) == p
            assert len(s["new_prefill_ids"]) == len(s["pending_prefill_ids"]) == len(p)
            assert not s["preempted_req_ids"] and s["prefill_layers_before"] == 0
            assert set(r["completed_prefill_ids"]) == p and len(
                r["completed_prefill_ids"]
            ) == len(p)
            assert not r["cancelled_prefill_ids"] and r["prefill_layers_completed"] == (
                40 if p else 0
            )
            assert r["actual_prefill_progress"] is bool(p)
            assert r["mixed_pd_progress_and_retirement"] is bool(p and d)
            assert r["native_mixed_scheduled_and_decode_retired"] is False
            assert set(r["decode_retired_ids"]) == d and len(
                r["decode_retired_ids"]
            ) == len(d)
            if d:
                sizes.append(len(d))
                decode_turns += 1
                for rid in d:
                    retirements[rid] += 1
            previous = p | d
        results.append(
            {
                "batch_id": batch["batch_id"],
                "serving_steps": len(selected),
                "decode_turns": len(sizes),
                "decode_batch_sizes": sizes,
                "peer_prefill_advancements": 1,
                "peer_layers": 40,
                "peer_ack_count": 7,
                "decode_retirements_per_case": {c: retirements[ids[c]] for c in order},
            }
        )
    coverage = report["mixed_coverage"]
    assert {int(k): v for k, v in coverage["steps_per_batch"].items()} == dict.fromkeys(
        batch_ids, 1
    )
    assert (
        coverage["covered_batches"] == batch_ids and coverage["uncovered_batches"] == []
    )
    graphs = []
    before, after = (
        checks.four(report["worker_before"]),
        checks.four(report["worker_after"]),
    )
    for rank in range(4):
        a, b = (
            before[rank]["decode_graph_snapshot"],
            after[rank]["decode_graph_snapshot"],
        )
        for field, value in {
            "enabled": True,
            "attached": True,
            "capture_started": True,
            "captured": True,
            "failed": False,
            "closed": False,
            "compile_full_prefill": False,
            "prefill_compile_profiled": False,
            "includes_startup_warmups": True,
            "captured_graph_entries": 4,
        }.items():
            assert a[field] == b[field] == value
        for field in (
            "capture_attempts",
            "capture_successes",
            "capture_failures",
            "decode_capture_forward_calls",
            "decode_eager_fallback_calls",
            "decode_uncaptured_full_calls",
            "decode_forward_failures",
            "prefill_compiled_calls",
            "prefill_compile_profile_runs",
            "prefill_compile_profile_failures",
        ):
            assert a[field] == b[field]
        assert a["capture_successes"] >= 1
        assert all(
            a[k] == 0
            for k in (
                "capture_failures",
                "decode_uncaptured_full_calls",
                "decode_forward_failures",
                "prefill_compiled_calls",
                "prefill_compile_profile_runs",
                "prefill_compile_profile_failures",
            )
        )
        assert b["prefill_forced_eager_calls"] - a[
            "prefill_forced_eager_calls"
        ] == 2 * len(batches)
        assert b["decode_replay_calls"] - a["decode_replay_calls"] == decode_turns
        graphs.append(
            {
                "rank": rank,
                "decode_replay_before": a["decode_replay_calls"],
                "decode_replay_after": b["decode_replay_calls"],
                "decode_replay_delta": decode_turns,
            }
        )
    return receipts, {
        "receipt_sha256": sha(path),
        "serving_steps": len(pairs),
        "decode_turns": decode_turns,
        "batches": results,
        "graphs": graphs,
    }


def prefix_check(report, directory, batches, cases, receipts):
    tracker = checks.PrefixTracker(
        report["prefix_initial"], report["layout_module_sha256"]
    )
    assert [x["batch_id"] for x in report["prefix_batches"]] == [
        b["batch_id"] for b in batches
    ]
    expected = {f"prefix-batch-{b['batch_id']:02d}.json" for b in batches}
    assert {
        p.name for p in (directory / "results").glob("prefix-batch-*.json")
    } == expected
    verified = []
    for batch, item in zip(batches, report["prefix_batches"], strict=True):
        path = directory / "results" / f"prefix-batch-{batch['batch_id']:02d}.json"
        assert (
            Path(item["path"]).resolve() == path.resolve()
            and sha(path) == item["sha256"]
        )
        raw = read(path)
        assert raw["batch_id"] == batch["batch_id"]
        value = tracker.append(
            raw["rows"], batch, report["admissions"], receipts, cases
        )
        assert value == item["validation"]
        verified.append(
            {
                "batch_id": batch["batch_id"],
                "sha256": sha(path),
                "total_cohorts": value["total_cohorts"],
                "stats": value["stats"],
            }
        )
    final = checks.validate_final_snapshot(report["prefix_final"], tracker)
    assert final == report["prefix_validation"] and final["total_cohorts"] == 2 * len(
        batches
    )
    return {"passed": True, "raw_files": verified, "final": final}


def verify(scope, analysis, posterior_audit):
    assert sha(BUNDLE / "freeze-manifest-v1.json") == FREEZE_SHA
    freeze = read(BUNDLE / "freeze-manifest-v1.json")
    assert freeze["status"] == "frozen"
    declared = freeze["declared_attempts"]
    directory = Path(declared[scope]["directory"])
    controller = terminal(directory)
    posterior_controller = None
    if scope == "full":
        assert posterior_audit is not None
        posterior_controller = terminal(Path(declared["posterior32"]["directory"]))
    refs = read(BUNDLE / "candidate-quality-references-v1.json")
    for role, item in refs["historical_runs"].items():
        # Legacy native/raw reports have their original exit-only terminal contract.
        old = terminal(Path(item["directory"]), legacy=True)
        if role == "prefix":
            assert (
                old["owned_members_after_cleanup"] == []
                and not old["errors"]
                and not old.get("cleanup_required")
            )
            assert old["idle_physical_after"] == old["expected_physical"]
    # No child, scheduler history, batch snapshot or log is read before terminal gates above.
    files = freeze["files"]
    assert len(files) == 22 and set(files) == set(control.FILES)
    assert all(
        sha(BUNDLE / n) == sha(directory / "producer" / n) == digest
        for n, digest in files.items()
    )
    assert controller["files"] == files and controller["bundle_frozen"] is True
    assert (
        sha(directory / "producer/freeze-manifest-v1.json")
        == FREEZE_SHA
        == controller["freeze_manifest_sha256"]
    )
    assert (
        controller["label"] == directory.name == declared[scope]["label"]
        and controller["scope"] == scope
    )
    assert controller["schema"] == "muxpd-runtime-candidate-quality-controller-v1"
    identity_path = BUNDLE / "candidate-identity-v1.json"
    identity = read(identity_path)
    identity_sha = sha(identity_path)
    assert (
        identity_sha
        == freeze["candidate_identity_sha256"]
        == controller["candidate_identity_sha256"]
        == sha(directory / "producer/candidate-identity-v1.json")
    )
    assert (
        identity["candidate_commit"]
        == freeze["candidate_commit"]
        == "a05029484b2c9bc21e4e6fd705cc396d111dfaa5"
    )
    source = checks.source_guard(Path(identity["source_root"]), identity, BUNDLE)
    assert controller["source_preflight"] == source
    for key in ("independent_review", "root_preflight"):
        assert sha(freeze[key]["path"]) == freeze[key]["sha256"]
    for path, digest in refs["files"].items():
        assert sha(path) == digest
    assert sha(BUNDLE / "score_quality.py") == SCORER_SHA
    plan, cases, extract = scorer.load_frozen(BUNDLE / "frozen-v2")
    assert (
        plan["plan_sha256"] == checks.PLAN_SHA
        and len(cases) == plan["case_count"] == 200
    )
    assert plan["sampling"] == {
        "temperature": 0.0,
        "seed": 42,
        "max_tokens": 8192,
        "ignore_eos": False,
        "detokenize": False,
    }
    batch_ids = [3, 6, 7, 14] if scope == "posterior32" else list(range(25))
    batches = [b for b in plan["batches"] if b["batch_id"] in batch_ids]
    ordered = [c for batch in batches for c in batch["case_ids"]]
    case_map = {c["case_id"]: c for c in cases}
    selected = [case_map[c] for c in ordered]
    report_path = directory / "results/run.json"
    report = read(report_path)
    assert (
        report["scope"] == scope
        and report["schema"] == "muxpd-runtime-candidate-quality-run-v1"
    )
    assert (
        report["passed"]
        and report["collection_complete"]
        and report["shutdown_returned"]
        and not report["errors"]
    )
    assert (
        not report.get("failure_cleanup")
        and not report["terminal_maintenance"]["aborted_internal_ids"]
    )
    assert report["process_id"] == controller["pid"] == controller["process_group"]
    assert report["plan_sha256"] == plan["plan_sha256"]
    assert report["selected_batch_ids"] == controller["selected_batch_ids"] == batch_ids
    assert report["selected_case_ids"] == ordered and controller[
        "selected_case_count"
    ] == len(ordered)
    assert (
        report["profile"]
        == controller["profile"]
        == "canonical-runtime-candidate-prefix"
    )
    assert report["role"] == "raw" and report["layout_mode"] == "prefix"
    assert report["sources"] == source["sources"]
    for field in (
        "candidate_identity",
        "source_after_startup",
        "sources_after_shutdown",
    ):
        assert report[field] == source
    assert (
        report["layout_module_sha256"]
        == identity["runtime_files"]["src/vllm_muxpd/prefill_collective_layout.py"]
    )
    for field, filename in {
        "producer_sha256": "candidate_run_v1.py",
        "original_producer_sha256": "run_quality.py",
        "original_scorer_sha256": "score_quality.py",
        "source_manifest_sha256": "source-manifest-v1.json",
    }.items():
        assert report[field] == files[filename]
    histories = {
        role: read(Path(item["directory"]) / "results/run.json")
        for role, item in refs["historical_runs"].items()
    }
    scorer.compare_provenance([histories[k] for k in ("native1", "native2", "raw")])
    for old in histories.values():
        assert (
            old["collection_complete"]
            and old["shutdown_returned"]
            and not old["errors"]
            and len(old["outputs"]) == 200
        )
    base = run_quality.validate("raw", read(BUNDLE / "raw-engine-args-v1.json"), plan)
    launch = copy.deepcopy(base)
    resolved = copy.deepcopy(histories["raw"]["engine_args"])
    assert identity["policy_additions"] == {
        "experimental_prefill_collective_layout": "prefix",
        "require_hccl_deterministic": True,
    }
    assert identity["policy_overrides"] == [
        {"key": "layers_per_slice", "from": 4, "to": 40}
    ]
    for config in (launch, resolved):
        assert (
            type(config["batch_admission_policy_config"]["layers_per_slice"]) is int
            and config["batch_admission_policy_config"]["layers_per_slice"] == 4
        )
        assert not set(identity["policy_additions"]) & set(
            config["batch_admission_policy_config"]
        )
        config["batch_admission_policy_config"].update(identity["policy_additions"])
        config["batch_admission_policy_config"]["layers_per_slice"] = 40
    assert (
        report["base_engine_args"] == controller["launch_engine_args"] == launch
        and report["engine_args"] == resolved
    )
    assert (
        report["engine_coordinator"] == "InprocClient"
        and report["scheduler_class"] == resolved["scheduler_cls"]
    )
    assert report["effective"] == {k: resolved[k] for k in report["effective"]}
    assert identity["environment_overrides"] == {}
    assert report["runtime_environment"] == histories["raw"]["runtime_environment"]
    assert controller["runtime_environment_guard"]["passed"] is True
    assert (
        controller["runtime_environment_guard"]["environment"]
        == report["runtime_environment"]["environment"]
    )
    model = refs["model_config_identity"]
    assert (
        identity["model_config_identity"]
        == report["model_config_before_startup"]
        == report["model_config_after_startup"]
        == model
    )
    assert sha(model["path"]) == model["sha256"]
    assert report["tokenizer_files"] == runtime.tokenizer_identities(plan)
    decoder = Tokenizer.from_file(plan["tokenizer_files"]["tokenizer.json"]["path"])
    vocabulary = decoder.get_vocab_size()
    outputs = {r["case_id"]: r for r in report["outputs"]}
    assert len(outputs) == len(report["outputs"]) == len(ordered) and set(
        outputs
    ) == set(ordered)
    for row in outputs.values():
        ids = row["token_ids"]
        assert (
            row["finished"] is True
            and not row.get("error")
            and row["finish_reason"] in ("stop", "length")
        )
        assert 0 < len(ids) <= 8192 and all(
            type(t) is int and 0 <= t < vocabulary for t in ids
        )
        assert row["finish_reason"] != "length" or len(ids) == 8192
        assert row["text"] == decoder.decode(ids, skip_special_tokens=True)
    for when in ("worker_before", "worker_after"):
        checks.validate_candidate_workers(report[when], identity)
        for row in report[when]:
            runtime.require_empty_worker(row)
    assert report["prefix_initial"] == [
        r["builtin_layout"] for r in report["worker_before"]
    ]
    assert report["prefix_final"] == [
        r["builtin_layout"] for r in report["worker_after"]
    ]
    runtime.require_empty(report["final_state"], report["idle_baseline"])
    assert (
        report["warmup"]
        == "Existing LLM constructor warmup only; zero extra request warmups."
    )
    for when in ("before", "after"):
        assert (
            inventory((directory / f"npu-{when}.txt").read_text())
            == controller["expected_physical"]
        )
    actual_terminal = control.terminal_assessment(directory, controller)
    assert actual_terminal == controller["terminal_assessment"] and actual_terminal[
        "child_sha256"
    ] == sha(report_path)
    receipts, schedule = schedule_check(report, directory, batches, cases)
    prefix = prefix_check(report, directory, batches, cases, receipts)
    scores, rows = {}, []
    for role, value in {**histories, "candidate": report}.items():
        subset = (
            value
            if role == "candidate"
            else {
                **value,
                "outputs": [r for r in value["outputs"] if r["case_id"] in ordered],
            }
        )
        scores[role] = scorer.score(subset, plan, selected, extract)
    indexed = {
        role: {r["case_id"]: r for r in score["rows"]} for role, score in scores.items()
    }
    source_paths = {
        role: Path(item["directory"]) / "results/run.json"
        for role, item in refs["historical_runs"].items()
    } | {"candidate": report_path}
    sources = {
        role: {"path": str(path), "sha256": sha(path)}
        for role, path in source_paths.items()
    }
    old_outputs = {
        role: {r["case_id"]: r for r in value["outputs"]}
        for role, value in {**histories, "candidate": report}.items()
    }
    for batch in batches:
        for position, cid in enumerate(batch["case_ids"]):
            arms = {}
            for role in scores:
                output = old_outputs[role][cid]
                arms[role] = {
                    **indexed[role][cid],
                    "stop_reason": output.get("stop_reason"),
                    "token_ids_sha256": hashlib.sha256(
                        canonical(output["token_ids"])
                    ).hexdigest(),
                    "text_sha256": hashlib.sha256(output["text"].encode()).hexdigest(),
                    "source_run_sha256": sources[role]["sha256"],
                }
            stable = arms["native1"]["correct"] and arms["native2"]["correct"]
            rows.append(
                {
                    "case_id": cid,
                    "original_batch_id": batch["batch_id"],
                    "original_position": position,
                    "gold": case_map[cid]["answer"],
                    "arms": arms,
                    "both_native_correct": stable,
                    "new_wrong": stable and not arms["candidate"]["correct"],
                    "old_raw_loss": stable and not arms["raw"]["correct"],
                    "old_prefix_loss": stable and not arms["prefix"]["correct"],
                }
            )
    new_wrong = [r["case_id"] for r in rows if r["new_wrong"]]
    resolved_losses = [
        r["case_id"]
        for r in rows
        if (r["old_raw_loss"] or r["old_prefix_loss"])
        and r["arms"]["candidate"]["correct"]
    ]
    unresolved = [
        r["case_id"]
        for r in rows
        if (r["old_raw_loss"] or r["old_prefix_loss"])
        and not r["arms"]["candidate"]["correct"]
    ]
    lengths = {
        role: [
            r["case_id"] for r in rows if r["arms"][role]["finish_reason"] == "length"
        ]
        for role in scores
    }
    new_lengths = {
        role: [c for c in lengths["candidate"] if c not in lengths[role]]
        for role in histories
    }
    historic_scores = {
        role: scorer.score(value, plan, cases, extract)
        for role, value in histories.items()
        if role in ("native1", "native2", "raw")
    }
    historical_strict = scorer.evaluate(
        historic_scores["native1"], historic_scores["native2"], historic_scores["raw"]
    )
    assert (
        historical_strict["checks"]["both_native_controls_complete"] is False
        and historical_strict["bounded_answer_quality_gate_passed"] is False
    )
    strict = (
        scorer.evaluate(scores["native1"], scores["native2"], scores["candidate"])
        if scope == "full"
        else None
    )
    primary = read(analysis)
    assert (
        primary["schema"] == "muxpd-runtime-candidate-quality-assessment-v2"
        and primary["passed"]
        and primary["runtime_collection_qualified"]
        and primary["errors"] == []
    )
    assert primary["analysis_scope"] == (
        "posterior32" if scope == "posterior32" else "pair"
    )
    bound = primary["qualification"]["attempts"][scope]
    assert bound["controller_sha256"] == sha(directory / "controller.json") and bound[
        "child_sha256"
    ] == sha(report_path)
    table = primary["answer_results"][
        "posterior32" if scope == "posterior32" else "full200"
    ]
    assert (
        scores == table["scores"]
        and new_wrong == table["new_wrong_on_both_native_correct"]
    )
    primary_rows = {r["case_id"]: r for r in table["rows"]}
    for row in rows:
        saved = primary_rows[row["case_id"]]
        assert (
            saved["original_batch_id"] == row["original_batch_id"]
            and saved["original_position"] == row["original_position"]
        )
        for role in scores:
            assert all(
                saved["arms"][role][key] == value
                for key, value in indexed[role][row["case_id"]].items()
            )
    if scope == "posterior32":
        assert (
            primary["full_quality_gate_attempted"] is False
            and primary["full_frozen_plan_passed"] is None
        )
    else:
        assert strict == primary["answer_results"]["original_strict_evaluation"]
        assert (
            primary["full_quality_gate_attempted"] is True
            and primary["full_frozen_plan_passed"]
            == strict["bounded_answer_quality_gate_passed"]
        )
    fresh = None
    if scope == "full":
        old_audit = read(posterior_audit)
        pdir = Path(declared["posterior32"]["directory"])
        assert (
            old_audit["passed"]
            and old_audit["scope"] == "posterior32"
            and old_audit["freeze_sha256"] == FREEZE_SHA
        )
        assert old_audit["candidate_identity_sha256"] == identity_sha and old_audit[
            "child_sha256"
        ] == sha(pdir / "results/run.json")
        assert (
            old_audit["controller_sha256"] == sha(pdir / "controller.json")
            and not old_audit["new_wrong_on_both_native_correct"]
        )
        assert (
            directory != pdir
            and controller["controller_pid"] != posterior_controller["controller_pid"]
        )
        assert controller["process_group"] != posterior_controller["process_group"]
        assert report["process_id"] != read(pdir / "results/run.json")["process_id"]
        assert datetime.fromisoformat(
            controller["started_at"]
        ) > datetime.fromisoformat(posterior_controller["finished_at"])
        assert datetime.fromisoformat(report["started_at"]) >= datetime.fromisoformat(
            controller["started_at"]
        )
        fresh = {
            "passed": True,
            "posterior_audit_sha256": sha(posterior_audit),
            "posterior_finished_at": posterior_controller["finished_at"],
            "full_started_at": controller["started_at"],
        }
    assert all(
        sha(BUNDLE / n) == sha(directory / "producer" / n) == digest
        for n, digest in files.items()
    )
    return {
        "passed": True,
        "scope": scope,
        "script_sha256": sha(__file__),
        "primary_analysis": {"path": str(analysis), "sha256": sha(analysis)},
        "controller_sha256": sha(directory / "controller.json"),
        "child_sha256": sha(report_path),
        "freeze_sha256": FREEZE_SHA,
        "candidate_identity_sha256": identity_sha,
        "candidate_commit": identity["candidate_commit"],
        "scorer_sha256": SCORER_SHA,
        "selected_case_ids": ordered,
        "actual_outputs_decoded": len(outputs),
        "sources": sources,
        "scores": scores,
        "per_case_rows": rows,
        "new_wrong_on_both_native_correct": new_wrong,
        "resolved_old_regressions": resolved_losses,
        "unresolved_old_regressions": unresolved,
        "length_cases": lengths,
        "new_length_cases": new_lengths,
        "relative_no_new_wrong_passed": not new_wrong,
        "historical_strict_evaluation": historical_strict,
        "original_strict_evaluation": strict,
        "full_quality_gate_attempted": scope == "full",
        "full_frozen_plan_passed": None
        if strict is None
        else strict["bounded_answer_quality_gate_passed"],
        "schedule": schedule,
        "prefix": prefix,
        "terminal": actual_terminal,
        "fresh_pair": fresh,
        "limits": "Independent audit success is not answer-quality acceptance. Posterior32 is diagnostic only; full200 strict baseline completeness and relative no-new-wrong remain separate. No performance claim.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scope", choices=("posterior32", "full"), required=True)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--posterior-audit", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    result = verify(args.scope, args.analysis, args.posterior_audit)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "passed": True,
                "scope": args.scope,
                "output": str(args.output),
                "sha256": sha(args.output),
                "correct": {
                    role: value["correct"] for role, value in result["scores"].items()
                },
                "new_wrong": result["new_wrong_on_both_native_correct"],
                "new_lengths": result["new_length_cases"],
                "full_frozen_plan_passed": result["full_frozen_plan_passed"],
            }
        )
    )
