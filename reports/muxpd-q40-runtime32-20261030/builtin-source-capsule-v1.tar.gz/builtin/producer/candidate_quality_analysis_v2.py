"""Terminal-first candidate quality qualification, with unchanged five-arm scoring.

This module prepares an unbound protocol. Only a future root-frozen real runtime
identity and declared posterior32/full pair can pass the execution gates.
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path

import candidate_checks_v1 as checks
import quality_tables_v1 as tables
import score_quality as original

REFS_SHA = "8ddb03d30be915a3fc1a60bdac8e41fa862e73588d8c59ed63231c2630e0d9ee"
WRAPPER_FILES = {
    "candidate_quality_analysis_v2.py",
    "analyze_candidate_quality_v2.py",
    "candidate-quality-references-v1.json",
    "quality_tables_v1.py",
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def terminal_controller(directory):
    value = read(Path(directory) / "controller.json")
    require(
        value.get("terminal_process_proven") is True
        and value.get("passed") is True
        and bool(value.get("finished_at"))
        and value.get("exit_code") == 0
        and value.get("errors") == []
        and value.get("owned_members_after_cleanup") == []
        and not value.get("cleanup_required")
        and not value.get("forced_termination")
        and len(value.get("expected_physical", [])) == 4
        and value.get("idle_physical_after") == value["expected_physical"],
        "Clean terminal proof required before child/log reads",
    )
    return value


def verify_histories(bundle):
    bundle = Path(bundle)
    refs_path = bundle / "candidate-quality-references-v1.json"
    require(sha(refs_path) == REFS_SHA, "Frozen historical references changed")
    refs = read(refs_path)
    require(
        refs["schema"] == "muxpd-runtime-quality-historical-references-v1"
        and refs["status"] == "qualified-historical-only",
        "Historical reference scope changed",
    )
    contracts = {}
    for role, item in refs["historical_runs"].items():
        path = Path(item["directory"]) / "controller.json"
        require(
            sha(path) == item["files"]["controller.json"],
            "Historical controller changed",
        )
        controller = read(path)
        require(
            controller.get("passed") is True
            and controller.get("exit_code") == 0
            and controller.get("finished_at"),
            "Historical controller not terminal",
        )
        if role == "prefix":
            require(
                controller["schema"] == "muxpd-layout-quality-controller-v1"
                and controller["errors"] == []
                and controller["owned_members_after_cleanup"] == []
                and not controller.get("cleanup_required")
                and controller["idle_physical_after"]
                == controller["expected_physical"],
                "Historical prefix terminal proof failed",
            )
            contracts[role] = "original-layout-terminal-owned-idle"
        else:
            require(
                role in ("native1", "native2", "raw") and "schema" not in controller,
                "Unknown legacy historical format",
            )
            contracts[role] = "original-terminal-exit-only"
    require(
        set(contracts) == {"native1", "native2", "raw", "prefix"},
        "Missing historical arm",
    )
    for path, digest in refs["files"].items():
        require(sha(path) == digest, "Historical artifact changed: " + path)
    runs = {
        role: read(Path(item["directory"]) / "results/run.json")
        for role, item in refs["historical_runs"].items()
    }
    manifest = checks.original_manifest(bundle)
    for role, label in (
        ("native1", "native-quality-v2-hccl-true-01"),
        ("native2", "native-quality-v2-hccl-true-02"),
        ("raw", "raw-quality-v2-hccl-true-01"),
    ):
        bound = manifest["historical_runs"][label]
        run = runs[role]
        require(
            sha(bound["path"])
            == bound["sha256"]
            == refs["historical_runs"][role]["files"]["results/run.json"]
            and all(
                run[k] == bound[k]
                for k in (
                    "engine_args",
                    "sources",
                    "runtime_environment",
                    "producer_sha256",
                )
            ),
            "Original historical provenance differs",
        )
    original.compare_provenance([runs[k] for k in ("native1", "native2", "raw")])
    for run in runs.values():
        require(
            run["collection_complete"]
            and run["shutdown_returned"]
            and not run["errors"]
            and run["plan_sha256"] == checks.PLAN_SHA
            and len(run["outputs"]) == 200,
            "Historical full200 collection changed",
        )
    require(
        runs["native1"]["process_id"] != runs["native2"]["process_id"]
        and runs["native1"]["started_at"] != runs["native2"]["started_at"],
        "Paired native controls are not distinct",
    )
    assessment, audit = [read(v["path"]) for v in refs["historical_assessments"]]
    require(
        assessment["full_quality_gate_attempted"] is True
        and assessment["full_frozen_plan_passed"] is False
        and audit["audit_passed"] is True
        and audit["collection_lifecycle_passed"] is True
        and audit["full_frozen_plan_passed"] is False,
        "Historical strict failure was lost",
    )
    require(
        sha(bundle / "quality_tables_v1.py") == refs["unchanged_table_sha256"],
        "Original five-arm table code changed",
    )
    model = refs["model_config_identity"]
    require(
        sha(model["path"]) == model["sha256"], "Original model config bytes changed"
    )
    return (
        refs,
        runs,
        {
            "historical_strict_gate_passed": False,
            "references_sha256": REFS_SHA,
            "legacy_historical_terminal_contracts": contracts,
            "scope": "Immutable historical qualification retained; no modern legacy process evidence fabricated.",
        },
    )


def replay_prefixes(report, results, batches, cases, receipts):
    results = Path(results)
    items = report["prefix_batches"]
    require(
        [v["batch_id"] for v in items] == [b["batch_id"] for b in batches],
        "Missing/reordered/extra batch prefix snapshots",
    )
    expected = {f"prefix-batch-{b['batch_id']:02d}.json" for b in batches}
    require(
        {p.name for p in results.glob("prefix-batch-*.json")} == expected,
        "Unexpected batch snapshot files",
    )
    tracker = checks.PrefixTracker(
        report["prefix_initial"], report["layout_module_sha256"]
    )
    files = []
    for batch, item in zip(batches, items, strict=True):
        path = results / f"prefix-batch-{batch['batch_id']:02d}.json"
        require(
            Path(item["path"]).resolve() == path.resolve()
            and sha(path) == item["sha256"],
            "Raw batch snapshot path/hash changed",
        )
        raw = read(path)
        require(raw["batch_id"] == batch["batch_id"], "Raw snapshot batch differs")
        value = tracker.append(
            raw["rows"], batch, report["admissions"], receipts, cases
        )
        require(
            value == item["validation"],
            "Saved batch validation differs from raw replay",
        )
        files.append({"path": str(path.resolve()), "sha256": sha(path)})
    final = checks.validate_final_snapshot(report["prefix_final"], tracker)
    require(
        final == report["prefix_validation"],
        "Final prefix counters differ from raw replay",
    )
    return {**final, "files": files, "batches": tracker.batches}


def verify_fresh_pair(posterior, full):
    a, b = posterior["controller"], full["controller"]
    require(
        Path(posterior["directory"]).resolve() != Path(full["directory"]).resolve()
        and a["controller_pid"] != b["controller_pid"]
        and a["process_group"] != b["process_group"]
        and posterior["report"]["process_id"] != full["report"]["process_id"]
        and datetime.fromisoformat(b["started_at"])
        > datetime.fromisoformat(a["finished_at"])
        and datetime.fromisoformat(full["report"]["started_at"])
        >= datetime.fromisoformat(b["started_at"]),
        "Full200 must be a separately fresh process after posterior32 terminal; no concatenation/retry selection",
    )
    return {
        "passed": True,
        "posterior_directory": posterior["directory"],
        "full_directory": full["directory"],
        "posterior_finished_at": a["finished_at"],
        "full_started_at": b["started_at"],
    }


def validate_schedule(report, receipts, batches, cases):
    by_case = {c["case_id"]: c for c in cases}
    require(
        len(receipts) % 2 == 0 and len(receipts) // 2 == report["answer_engine_steps"],
        "Unpaired serving receipt/step count",
    )
    pairs = list(zip(receipts[::2], receipts[1::2], strict=True))
    require(
        [s["global_step"] for s, _ in pairs] == list(range(1, len(pairs) + 1)),
        "Serving steps repeated/reordered",
    )
    require(
        [s["batch_id"] for s, _ in pairs] == sorted([s["batch_id"] for s, _ in pairs]),
        "Batch execution order changed",
    )
    require(
        {s["batch_id"] for s, _ in pairs} == {b["batch_id"] for b in batches},
        "Missing/extra scheduled batch",
    )
    admissions = report["admissions"]
    require(len(admissions) == 2 * len(batches), "Admission count differs")
    decode_turns = 0
    rows = []
    all_ids = set()
    for index, batch in enumerate(batches):
        selected = [pair for pair in pairs if pair[0]["batch_id"] == batch["batch_id"]]
        seed, peers = admissions[index * 2 : index * 2 + 2]
        require(
            seed["batch_id"] == peers["batch_id"] == batch["batch_id"]
            and seed["stage"] == "seed"
            and peers["stage"] == "peers"
            and [v["case_id"] for v in seed["bindings"]] == batch["case_ids"][:1]
            and [v["case_id"] for v in peers["bindings"]] == batch["case_ids"][1:]
            and peers["seed_output_tokens"] == 1
            and peers["seed_still_live"] is True
            and seed["global_step"] == selected[0][0]["global_step"] - 1
            and peers["global_step"] == selected[1][0]["global_step"] - 1,
            "Original seed-first admission changed",
        )
        ids = {
            v["case_id"]: v["internal"] for a in (seed, peers) for v in a["bindings"]
        }
        require(
            len(set(ids.values())) == 8 and not (set(ids.values()) & all_ids),
            "Request identity reused across batches",
        )
        all_ids.update(ids.values())
        seed_id = ids[batch["case_ids"][0]]
        previous = set()
        sizes = []
        for ordinal, (s, r) in enumerate(selected):
            p = (
                {seed_id}
                if ordinal == 0
                else set(ids.values()) - {seed_id}
                if ordinal == 1
                else set()
            )
            d = {rid for rid, phase in s["phases_before"].items() if phase == "D"}
            require(
                s["event"] == "schedule"
                and r["event"] == "retirement"
                and s["global_step"] == r["global_step"]
                and s["batch_id"] == r["batch_id"]
                and set(s["phases_before"]) <= set(ids.values())
                and set(s["phases_before"].values()) <= {"P", "D"}
                and {rid for rid, phase in s["phases_before"].items() if phase == "P"}
                == p
                and (
                    not d
                    if ordinal == 0
                    else d == {seed_id}
                    if ordinal == 1
                    else bool(d) and d <= previous
                ),
                "Actual P/D phase population changed",
            )
            expected = {
                ids[c]: len(by_case[c]["prompt_token_ids"]) for c in ids if ids[c] in p
            } | dict.fromkeys(d, 1)
            require(
                s["scheduled_tokens"] == expected
                and set(s["new_prefill_ids"]) == p
                and len(s["new_prefill_ids"]) == len(p)
                and set(s["pending_prefill_ids"]) == p
                and len(s["pending_prefill_ids"]) == len(p)
                and s["prefill_layers_before"] == 0
                and not s["preempted_req_ids"]
                and not r["cancelled_prefill_ids"]
                and set(r["completed_prefill_ids"]) == p
                and len(r["completed_prefill_ids"]) == len(p)
                and r["prefill_layers_completed"] == (40 if p else 0)
                and r["actual_prefill_progress"] is bool(p)
                and r["mixed_pd_progress_and_retirement"] is bool(p and d)
                and r["native_mixed_scheduled_and_decode_retired"] is False
                and set(r["decode_retired_ids"]) == d
                and len(r["decode_retired_ids"]) == len(d),
                "Actual q40 progress/ACK or D retirement changed",
            )
            previous = p | d
            if d:
                sizes.append(len(d))
                decode_turns += 1
        rows.append(
            {
                "batch_id": batch["batch_id"],
                "serving_steps": len(selected),
                "decode_batch_sizes": sizes,
                "prefill_advancements": 2,
            }
        )
    return {"passed": True, "decode_turns": decode_turns, "batches": rows}


def validate_graphs(report, decode_turns, prefill_forwards):
    before = checks.four(report["worker_before"])
    after = checks.four(report["worker_after"])
    for rank in range(4):
        a, b = (
            before[rank]["decode_graph_snapshot"],
            after[rank]["decode_graph_snapshot"],
        )
        for key, value in {
            "enabled": True,
            "attached": True,
            "capture_started": True,
            "captured": True,
            "failed": False,
            "closed": False,
            "compile_full_prefill": False,
            "prefill_compile_profiled": False,
            "includes_startup_warmups": True,
            "captured_graph_entries": 4,
        }.items():
            require(
                a[key] == b[key] == value, "Actual decode graph capture state differs"
            )
        stable = (
            "capture_attempts",
            "capture_successes",
            "capture_failures",
            "decode_capture_forward_calls",
            "decode_eager_fallback_calls",
            "decode_uncaptured_full_calls",
            "decode_forward_failures",
            "prefill_compiled_calls",
            "prefill_compile_profile_runs",
            "prefill_compile_profile_failures",
        )
        require(
            all(a[k] == b[k] for k in stable)
            and a["capture_successes"] >= 1
            and all(
                a[k] == 0
                for k in (
                    "capture_failures",
                    "decode_uncaptured_full_calls",
                    "decode_forward_failures",
                    "prefill_compiled_calls",
                    "prefill_compile_profile_runs",
                    "prefill_compile_profile_failures",
                )
            )
            and b["prefill_forced_eager_calls"] - a["prefill_forced_eager_calls"]
            == prefill_forwards
            and b["decode_replay_calls"] - a["decode_replay_calls"] == decode_turns,
            "Dynamic replay/P-forward/eager/failure accounting differs",
        )
    return {
        "passed": True,
        "decode_replay_delta": decode_turns,
        "prefill_forced_eager_delta": prefill_forwards,
        "ranks": [0, 1, 2, 3],
    }


def validate_outputs(report, selected, plan):
    from tokenizers import Tokenizer

    outputs = report["outputs"]
    require(
        len(outputs) == len(selected)
        and {r["case_id"] for r in outputs} == set(selected),
        "Missing/duplicate/foreign candidate outputs",
    )
    tokenfile = plan["tokenizer_files"]["tokenizer.json"]
    require(sha(tokenfile["path"]) == tokenfile["sha256"], "Tokenizer bytes changed")
    decoder = Tokenizer.from_file(tokenfile["path"])
    vocabulary_size = decoder.get_vocab_size()
    for row in outputs:
        ids = row["token_ids"]
        require(
            row["finished"] is True
            and not row.get("error")
            and row["finish_reason"] in ("stop", "length")
            and 0 < len(ids) <= 8192
            and (row["finish_reason"] != "length" or len(ids) == 8192)
            and all(type(v) is int and 0 <= v < vocabulary_size for v in ids),
            "Candidate output is not a natural finished answer",
        )
        require(
            row["text"] == decoder.decode(ids, skip_special_tokens=True),
            "Stored scoring text differs from actual tokens",
        )
    return {
        "count": len(outputs),
        "length_cases": [
            r["case_id"] for r in outputs if r["finish_reason"] == "length"
        ],
    }


def audit_attempt(
    directory,
    scope,
    bundle,
    candidate,
    candidate_sha,
    source,
    freeze,
    refs,
    histories,
    controller,
):
    import candidate_control_v1 as control
    import run_quality
    from probe_control_v1 import inventory
    from probe_run_v1 import require_empty, require_empty_worker, tokenizer_identities

    directory, bundle = Path(directory), Path(bundle)
    declaration = freeze["declared_attempts"][scope]
    require(
        directory.resolve() == Path(declaration["directory"]).resolve()
        and directory.name == declaration["label"] == controller["label"]
        and controller["schema"] == "muxpd-runtime-candidate-quality-controller-v1"
        and controller["scope"] == scope
        and controller["profile"] == "canonical-runtime-candidate-prefix"
        and controller["bundle_frozen"] is True
        and controller["source_preflight"] == source,
        "Attempt is outside the one frozen scope/label/source declaration",
    )
    names = set(control.FILES) | WRAPPER_FILES
    actual = {name: sha(directory / "producer" / name) for name in names}
    require(
        actual
        == controller["files"]
        == freeze["files"]
        == {name: sha(bundle / name) for name in names},
        "Exact archived producer map is incomplete or changed",
    )
    require(
        sha(directory / "producer/freeze-manifest-v1.json")
        == controller["freeze_manifest_sha256"]
        == sha(bundle / "freeze-manifest-v1.json")
        and sha(directory / "producer/candidate-identity-v1.json")
        == controller["candidate_identity_sha256"]
        == candidate_sha,
        "Frozen candidate identity/producer differs",
    )
    terminal = control.terminal_assessment(directory, controller)
    require(
        terminal == controller["terminal_assessment"],
        "Saved terminal assessment differs from actual child/log",
    )
    report = read(directory / "results/run.json")
    for when in ("before", "after"):
        require(
            inventory((directory / f"npu-{when}.txt").read_text())
            == controller["expected_physical"],
            "Saved physical idle proof changed",
        )
    plan, cases, _ = original.load_frozen(bundle / "frozen-v2")
    batches = checks.select_batches(plan, scope)
    selected = [case for batch in batches for case in batch["case_ids"]]
    require(
        report["schema"] == "muxpd-runtime-candidate-quality-run-v1"
        and report["role"] == "raw"
        and report["profile"] == "canonical-runtime-candidate-prefix"
        and report["layout_mode"] == "prefix"
        and report["scope"] == scope
        and report["plan_sha256"] == checks.PLAN_SHA
        and report["selected_batch_ids"]
        == controller["selected_batch_ids"]
        == [b["batch_id"] for b in batches]
        and report["selected_case_ids"] == selected
        and controller["selected_case_count"] == len(selected)
        and not report.get("failure_cleanup")
        and not report["terminal_maintenance"]["aborted_internal_ids"],
        "Actual candidate selected scope/lifecycle differs",
    )
    for field, name in {
        "producer_sha256": "candidate_run_v1.py",
        "original_producer_sha256": "run_quality.py",
        "original_scorer_sha256": "score_quality.py",
        "source_manifest_sha256": "source-manifest-v1.json",
    }.items():
        require(report[field] == actual[name], "Child producer/scorer identity differs")
    require(
        report["layout_module_sha256"]
        == candidate["runtime_files"]["src/vllm_muxpd/prefill_collective_layout.py"]
        and report["sources"] == source["sources"]
        and report["candidate_identity"] == source,
        "Builtin runtime source differs",
    )
    raw = histories["raw"]
    base = run_quality.validate("raw", read(bundle / "raw-engine-args-v1.json"), plan)
    launch = checks.apply_policy_changes(base, candidate)
    resolved = checks.apply_policy_changes(raw["engine_args"], candidate)
    require(
        report["base_engine_args"] == controller["launch_engine_args"] == launch
        and report["engine_args"] == resolved
        and report["effective"] == {k: resolved[k] for k in report["effective"]}
        and report["scheduler_class"] == resolved["scheduler_cls"]
        and report["engine_coordinator"] == "InprocClient",
        "Actual launch/resolved/scheduler/coordinator differs from explicit candidate delta",
    )
    checks.validate_environment(
        report["runtime_environment"], raw["runtime_environment"], candidate
    )
    require(
        report["tokenizer_files"] == tokenizer_identities(plan),
        "Tokenizer lifetime receipt differs",
    )
    model = refs["model_config_identity"]
    require(
        candidate["model_config_identity"] == model
        and sha(model["path"]) == model["sha256"]
        and report["model_config_before_startup"]
        == report["model_config_after_startup"]
        == model,
        "Actual pre/post-constructor model config receipt missing/different",
    )
    for when in ("worker_before", "worker_after"):
        checks.validate_candidate_workers(report[when], candidate)
        for row in report[when]:
            require_empty_worker(row)
    require(
        report["prefix_initial"]
        == [r["builtin_layout"] for r in report["worker_before"]]
        and report["prefix_final"]
        == [r["builtin_layout"] for r in report["worker_after"]],
        "Builtin snapshots differ from actual worker readback",
    )
    require_empty(report["final_state"], report["idle_baseline"])
    history = directory / "results/scheduler-receipts.jsonl"
    require(
        sha(history) == report["scheduler_receipts_sha256"],
        "Scheduler history bytes changed",
    )
    receipts = [json.loads(line) for line in history.read_text().splitlines()]
    prefix = replay_prefixes(report, directory / "results", batches, cases, receipts)
    schedule = validate_schedule(report, receipts, batches, cases)
    graph = validate_graphs(report, schedule["decode_turns"], 2 * len(batches))
    mixed = original.verify_mixed_coverage(
        directory / "results/run.json", report, {**plan, "batches": batches}
    )
    require(
        mixed["passed"]
        and {int(k): v for k, v in report["mixed_coverage"]["steps_per_batch"].items()}
        == {b["batch_id"]: 1 for b in batches},
        "Original actual mixed coverage/q40 single-advance count failed",
    )
    outputs = validate_outputs(report, selected, plan)
    require(
        report["warmup"]
        == "Existing LLM constructor warmup only; zero extra request warmups.",
        "Additional warmup requests are not allowed",
    )
    return {
        "directory": str(directory.resolve()),
        "controller": controller,
        "report": report,
        "qualification": {
            "passed": True,
            "scope": scope,
            "controller_sha256": sha(directory / "controller.json"),
            "child_sha256": sha(directory / "results/run.json"),
            "terminal": terminal,
            "prefix": prefix,
            "schedule": schedule,
            "graph": graph,
            "mixed": mixed,
            "outputs": outputs,
            "model_config_constructor_receipts": model,
        },
    }


def qualify_scopes(declared, bundle, identity_path):
    bundle = Path(bundle)
    candidate = read(identity_path)
    require(
        candidate.get("schema") == checks.IDENTITY_SCHEMA
        and candidate.get("status") == "bound"
        and candidate.get("purpose") == "actual-runtime-quality-candidate"
        and candidate.get("fixture_only") is False,
        "Candidate identity is unbound or is a fixture",
    )
    # Every requested controller passes terminal gates before any child/log read.
    # Posterior-only mode never resolves, opens or requires the future full path.
    controllers = {
        scope: terminal_controller(directory) for scope, directory in declared
    }
    freeze = read(bundle / "freeze-manifest-v1.json")
    candidate_sha = sha(identity_path)
    require(
        freeze["status"] == "frozen"
        and freeze["candidate_identity_sha256"] == candidate_sha
        and set(freeze["declared_attempts"]) == {"posterior32", "full"},
        "Concrete freeze/declaration missing",
    )
    source = checks.source_guard(Path(candidate["source_root"]), candidate, bundle)
    refs, histories, historical = verify_histories(bundle)
    values = {
        scope: audit_attempt(
            directory,
            scope,
            bundle,
            candidate,
            candidate_sha,
            source,
            freeze,
            refs,
            histories,
            controllers[scope],
        )
        for scope, directory in declared
    }
    return (
        {
            "passed": True,
            "candidate_identity_sha256": candidate_sha,
            "freeze_manifest_sha256": sha(bundle / "freeze-manifest-v1.json"),
            "historical": historical,
            "attempts": {
                scope: value["qualification"] for scope, value in values.items()
            },
        },
        values,
        refs,
    )


def qualify_pair(posterior, full, bundle, identity_path):
    proof, values, refs = qualify_scopes(
        (("posterior32", posterior), ("full", full)), bundle, identity_path
    )
    proof["fresh_pair"] = verify_fresh_pair(values["posterior32"], values["full"])
    return proof, values, refs


def qualify_posterior(posterior, bundle, identity_path):
    proof, values, refs = qualify_scopes(
        (("posterior32", posterior),), bundle, identity_path
    )
    return proof, values["posterior32"], refs


def score_posterior(value, refs, bundle):
    """Score original32 cases directly; never construct a partial full200 table."""
    bundle = Path(bundle)
    paths = {
        role: Path(item["directory"]) / "results/run.json"
        for role, item in refs["historical_runs"].items()
    }
    paths["candidate"] = Path(value["directory"]) / "results/run.json"
    plan, cases, extract = original.load_frozen(bundle / "frozen-v2")
    batches = checks.select_batches(plan, "posterior32")
    selected = [case for batch in batches for case in batch["case_ids"]]
    by_case = {c["case_id"]: c for c in cases}
    subset = [by_case[case] for case in selected]
    scores, sources, outputs = {}, {}, {}
    for role, path in paths.items():
        run = read(path)
        # Historical full reports are subset for the diagnostic. Candidate must
        # actually contain exactly32 outputs; no output selection is permitted.
        if role == "candidate":
            require(
                len(run["outputs"]) == 32
                and {r["case_id"] for r in run["outputs"]} == set(selected),
                "Posterior candidate must contain exactly the original32 outputs",
            )
        else:
            run = {
                **run,
                "outputs": [r for r in run["outputs"] if r["case_id"] in selected],
            }
        scores[role] = original.score(run, plan, subset, extract)
        sources[role] = {"path": str(path.resolve()), "sha256": sha(path)}
        outputs[role] = {r["case_id"]: r for r in run["outputs"]}
    indexed = {
        role: {r["case_id"]: r for r in score["rows"]} for role, score in scores.items()
    }
    rows = []
    for batch in batches:
        for position, case in enumerate(batch["case_ids"]):
            arms = {}
            for role in paths:
                output = outputs[role].get(case, {})
                arms[role] = {
                    **indexed[role][case],
                    "missing": case not in outputs[role],
                    "error": output.get("error"),
                    "stop_reason": output.get("stop_reason"),
                    "token_ids_sha256": tables.digest(
                        tables.canonical(output.get("token_ids", []))
                    ),
                    "text_sha256": tables.digest(output.get("text", "").encode()),
                    "source_run_path": sources[role]["path"],
                    "source_run_sha256": sources[role]["sha256"],
                }
            stable = arms["native1"]["correct"] and arms["native2"]["correct"]
            rows.append(
                {
                    "case_id": case,
                    "original_batch_id": batch["batch_id"],
                    "original_position": position,
                    "gold": by_case[case]["answer"],
                    "arms": arms,
                    "both_native_correct": stable,
                    "candidate_new_wrong_on_both_native_correct": stable
                    and not arms["candidate"]["correct"],
                    "old_prefix_loss_resolved": stable
                    and not arms["prefix"]["correct"]
                    and arms["candidate"]["correct"],
                }
            )
    wrong = [
        r["case_id"] for r in rows if r["candidate_new_wrong_on_both_native_correct"]
    ]
    return {
        "scope": "Original posterior32 diagnostic only; no full200 table or gate constructed",
        "selected_batch_ids": [3, 6, 7, 14],
        "rows": rows,
        "scores": scores,
        "sources": sources,
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "new_wrong_on_both_native_correct": wrong,
        "relative_no_new_wrong": {
            "passed": not wrong,
            "case_ids": wrong,
            "scope": "Posterior32 only",
        },
        "candidate_all_complete": scores["candidate"]["all_complete"],
        "candidate_vs": {
            role: original.paired(scores[role], scores["candidate"])
            for role in paths
            if role != "candidate"
        },
    }


def score_qualified_pair(values, refs, bundle):
    """Scores only. Caller must qualify both actual terminal attempts first."""
    bundle = Path(bundle)
    paths = {
        role: Path(item["directory"]) / "results/run.json"
        for role, item in refs["historical_runs"].items()
    }
    paths["candidate"] = Path(values["full"]["directory"]) / "results/run.json"
    full_table = tables.build_case_table(bundle / "frozen-v2", paths)
    posterior = score_posterior(values["posterior32"], refs, bundle)
    relative = {
        "passed": not full_table["new_wrong_on_both_native_correct"],
        "stable_both_native_correct_count": sum(
            r["both_native_correct"] for r in full_table["rows"]
        ),
        "new_wrong_case_ids": full_table["new_wrong_on_both_native_correct"],
        "scope": "Relative full200 no-new-wrong only; distinct from the unchanged original strict gate.",
    }
    return {
        "posterior32": posterior,
        "full200": full_table,
        "relative_no_new_wrong": relative,
        "original_strict_evaluation": full_table["original_strict_evaluation"],
    }
