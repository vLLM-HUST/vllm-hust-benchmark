"""Build auditable full200 tables; runtime/lifecycle qualification is separate."""

import hashlib
import importlib.util
import json
from pathlib import Path

ARMS = ("native1", "native2", "raw", "prefix", "candidate")
SCORER_SHA = "157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode()


def original_scorer():
    path = Path(__file__).with_name("score_quality.py")
    if digest(path.read_bytes()) != SCORER_SHA:
        raise ValueError("Original frozen scorer changed")
    spec = importlib.util.spec_from_file_location("original_quality_table_scorer", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build_case_table(frozen, run_paths):
    """Return scores and tables from actual run bytes, without accepting a candidate.

    This pure postprocessor intentionally does not certify a new runtime identity,
    process terminal evidence or mixed coverage. The future candidate wrapper must
    establish those gates independently before drawing an acceptance conclusion.
    """
    if set(run_paths) != set(ARMS):
        raise ValueError("Expected exactly five named run arms")
    scorer = original_scorer()
    plan, cases, extract = scorer.load_frozen(Path(frozen))
    case_map = {case["case_id"]: case for case in cases}
    ordered = [
        (batch["batch_id"], position, case)
        for batch in plan["batches"]
        for position, case in enumerate(batch["case_ids"])
    ]
    if (
        len(cases) != 200
        or len(ordered) != 200
        or len({case for _, _, case in ordered}) != 200
        or {case for _, _, case in ordered} != set(case_map)
        or [batch["batch_id"] for batch in plan["batches"]] != list(range(25))
    ):
        raise ValueError("Table requires the full original200-case batch plan")
    runs, scores, sources = {}, {}, {}
    for arm in ARMS:
        path = Path(run_paths[arm]).resolve(strict=True)
        raw = path.read_bytes()
        run = json.loads(raw)
        runs[arm] = run
        scores[arm] = scorer.score(run, plan, cases, extract)
        sources[arm] = {
            "path": str(path),
            "sha256": digest(raw),
            "runtime_commit": run.get("sources", {})
            .get("vllm_muxpd", {})
            .get("commit"),
            "reported_collection_complete": run.get("collection_complete"),
            "reported_shutdown_returned": run.get("shutdown_returned"),
            "reported_errors": run.get("errors"),
        }
    by_case = {
        arm: {row["case_id"]: row for row in scores[arm]["rows"]} for arm in ARMS
    }
    outputs = {
        arm: {row["case_id"]: row for row in runs[arm]["outputs"]} for arm in ARMS
    }
    rows = []
    for batch, position, case_id in ordered:
        case = case_map[case_id]
        arms = {}
        for arm in ARMS:
            output = outputs[arm].get(case_id, {})
            arms[arm] = {
                **by_case[arm][case_id],
                "missing": case_id not in outputs[arm],
                "error": output.get("error"),
                "token_ids_sha256": digest(canonical(output.get("token_ids", []))),
                "text_sha256": digest(output.get("text", "").encode()),
                "source_run_path": sources[arm]["path"],
                "source_run_sha256": sources[arm]["sha256"],
                "runtime_commit": sources[arm]["runtime_commit"],
            }
        stable = arms["native1"]["correct"] and arms["native2"]["correct"]
        raw_loss = stable and not arms["raw"]["correct"]
        prefix_loss = stable and not arms["prefix"]["correct"]
        candidate_correct = arms["candidate"]["correct"]
        length = arms["candidate"]["finish_reason"] == "length"
        rows.append(
            {
                "case_id": case_id,
                "original_batch_id": batch,
                "original_position": position,
                "subject": case["category"],
                "gold": case["answer"],
                "prompt_sha256": case["prompt_token_ids_sha256"],
                "plan_semantic_sha256": plan["plan_sha256"],
                "arms": arms,
                "both_native_correct": stable,
                "candidate_new_wrong_on_both_native_correct": stable
                and not candidate_correct,
                "old_raw_regression": raw_loss,
                "old_prefix_regression": prefix_loss,
                "old_regression_resolved": (raw_loss or prefix_loss)
                and candidate_correct,
                "old_regression_unresolved": (raw_loss or prefix_loss)
                and not candidate_correct,
                "candidate_length": length,
                **{
                    f"new_length_vs_{arm}": length
                    and arms[arm]["finish_reason"] != "length"
                    for arm in ARMS[:-1]
                },
            }
        )

    def flagged(field):
        return [row["case_id"] for row in rows if row[field]]

    return {
        "schema": "muxpd-full200-five-arm-case-table-v1",
        "runtime_and_lifecycle_qualification": "NOT_ASSESSED",
        "scope": "Table/scoring only. No runtime identity, fresh process, mixed-coverage or terminal acceptance is asserted. A fifth-arm CPU fixture is not a tested runtime candidate.",
        "plan_semantic_sha256": plan["plan_sha256"],
        "plan_file_sha256": digest((Path(frozen) / "plan.json").read_bytes()),
        "scorer_sha256": SCORER_SHA,
        "sources": sources,
        "rows": rows,
        "scores": scores,
        "old_raw_regressions": flagged("old_raw_regression"),
        "old_prefix_regressions": flagged("old_prefix_regression"),
        "resolved_old_regressions": flagged("old_regression_resolved"),
        "unresolved_old_regressions": flagged("old_regression_unresolved"),
        "new_wrong_on_both_native_correct": flagged(
            "candidate_new_wrong_on_both_native_correct"
        ),
        "length_cases": {
            arm: [
                row["case_id"]
                for row in rows
                if row["arms"][arm]["finish_reason"] == "length"
            ]
            for arm in ARMS
        },
        "new_length_cases": {arm: flagged(f"new_length_vs_{arm}") for arm in ARMS[:-1]},
        "missing_cases": {
            arm: [row["case_id"] for row in rows if row["arms"][arm]["missing"]]
            for arm in ARMS
        },
        "error_cases": {
            arm: [row["case_id"] for row in rows if row["arms"][arm]["error"]]
            for arm in ARMS
        },
        "invalid_answer_cases": {
            arm: [
                row["case_id"] for row in rows if not row["arms"][arm]["valid_answer"]
            ]
            for arm in ARMS
        },
        "candidate_vs": {
            arm: scorer.paired(scores[arm], scores["candidate"]) for arm in ARMS[:-1]
        },
        "original_strict_evaluation": scorer.evaluate(
            scores["native1"], scores["native2"], scores["candidate"]
        ),
    }
