"""CPU provenance and read-only builtin-prefix evidence for a future candidate."""

import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

from probe_run_v1 import file_sha, git, save

IDENTITY_SCHEMA = "muxpd-runtime-quality-candidate-identity-v2"
BUNDLE = Path(__file__).resolve().parent
PLAN_SHA = "dd3e1f305475ec556dc824947f26d5fb5743242e82b5099155c95b8954bb2e65"
WORKER = "vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker"
SCOPES = ("posterior32", "full")
POLICY_KEY = "experimental_prefill_collective_layout"
PREFIX_SCHEMA = "muxpd-prefill-collective-prefix-v1"
PREFIX_PROFILE = "experimental-qwen35-moe-tp4ep4-prefix-v1"
FINAL_SCHEMA = "muxpd-prefill-collective-prefix-uninstall-v1"
STATS = (
    "admitted",
    "closed",
    "admission_failed",
    "treated",
    "transformed_calls",
    "zero_d_calls",
)
HISTORICAL_COMMITS = {
    "6c606f789450a45ef35afee398b0a3e516caa1a1",
    "f7ed21e183b27d2141176f3e7a5c8a5ff4ede07d",
    "28169700c4f80e8ebbb8202d0218104ce91ede5e",
    "3e3b2023431a424287ae9e9da285642131f7bb6e",
}


def require(value, reason):
    if not value:
        raise ValueError(reason)


def original_manifest(bundle=BUNDLE):
    reuse = json.loads((bundle / "original-reuse-v1.json").read_text())
    for name, item in reuse.items():
        require(
            file_sha(bundle / name) == item["sha256"],
            f"Original copied bytes changed: {name}",
        )
    return json.loads((bundle / "source-manifest-v1.json").read_text())


def select_batches(plan, scope):
    require(scope in SCOPES, "Unknown candidate quality scope")
    require(
        plan["plan_sha256"] == PLAN_SHA and plan["case_count"] == 200,
        "Original plan identity changed",
    )
    require(
        [b["batch_id"] for b in plan["batches"]] == list(range(25)),
        "Original full packing changed",
    )
    selected = [3, 6, 7, 14] if scope == "posterior32" else list(range(25))
    batches = [b for b in plan["batches"] if b["batch_id"] in selected]
    require(
        all(len(b["case_ids"]) == 8 for b in batches), "Original batch size changed"
    )
    return batches


def repository_identity(origin):
    origin = Path(origin).resolve()
    root = Path(git(origin.parent, "rev-parse", "--show-toplevel"))
    diff = subprocess.check_output(["git", "-C", str(root), "diff", "--binary", "HEAD"])
    changed = subprocess.check_output(
        ["git", "-C", str(root), "diff", "--name-only", "-z", "HEAD"]
    )
    untracked = subprocess.check_output(
        ["git", "-C", str(root), "ls-files", "--others", "--exclude-standard", "-z"]
    )
    files = []
    for raw in sorted(set(changed.split(b"\0") + untracked.split(b"\0")) - {b""}):
        name = raw.decode()
        path = root / name
        files.append(
            {
                "path": name,
                "exists": path.exists(),
                "sha256": file_sha(path) if path.is_file() else None,
            }
        )
    return {
        "path": str(origin),
        "sha256": file_sha(origin),
        "commit": git(root, "rev-parse", "HEAD"),
        "status": git(origin.parent, "status", "--short"),
        "diff_sha256": hashlib.sha256(diff).hexdigest(),
        "diff_bytes_utf8": diff.decode(),
        "changed_files": files,
    }


def source_guard(source, candidate, bundle=BUNDLE):
    require(
        candidate.get("schema") == IDENTITY_SCHEMA
        and candidate.get("status") == "bound"
        and candidate.get("candidate_commit"),
        "Candidate identity is unbound; no model may be loaded",
    )
    require(
        candidate.get("purpose") == "actual-runtime-quality-candidate"
        and candidate.get("fixture_only") is False,
        "Synthetic fixture cannot authorize runtime execution",
    )
    commit = candidate["candidate_commit"]
    require(
        re.fullmatch("[0-9a-f]{40}", commit) and commit not in HISTORICAL_COMMITS,
        "A historical diagnostic/PR27 identity is not a qualified candidate",
    )
    source = Path(source).resolve()
    require(str(source) == candidate["source_root"], "Candidate source root differs")
    require(
        git(source, "rev-parse", "--show-toplevel") == str(source)
        and git(source, "rev-parse", "HEAD") == commit
        and not git(source, "status", "--porcelain"),
        "Candidate requires exact clean repository identity",
    )
    names = git(source, "ls-files", "--", "src").splitlines()
    actual = {name: file_sha(source / name) for name in names}
    require(
        actual == candidate["runtime_files"] and actual,
        "All tracked runtime source bytes must be bound",
    )
    for name in (
        "src/vllm_muxpd/__init__.py",
        "src/vllm_muxpd/decoupled_worker.py",
        "src/vllm_muxpd/prefill_collective_layout.py",
    ):
        require(name in actual, "Canonical worker/builtin prefix source is missing")
    review = candidate["reviewed_diff"]
    diff = subprocess.check_output(
        ["git", "-C", str(source), "diff", "--binary", review["base_commit"], commit]
    )
    require(
        diff
        and hashlib.sha256(diff).hexdigest() == review["sha256"]
        and Path(review["path"]).read_bytes() == diff,
        "Reviewed candidate diff differs",
    )
    changed = git(
        source, "diff", "--name-only", review["base_commit"], commit
    ).splitlines()
    require(
        any(name.startswith("src/") for name in changed),
        "Candidate has no reviewed runtime change",
    )
    history = original_manifest(bundle)["historical_runs"][
        "raw-quality-v2-hccl-true-01"
    ]
    sources = {}
    for name in ("vllm", "vllm_ascend"):
        sources[name] = repository_identity(history["sources"][name]["path"])
        require(
            sources[name] == history["sources"][name],
            f"Original core/Ascend identity changed: {name}",
        )
    sources["vllm_muxpd"] = repository_identity(source / "src/vllm_muxpd/__init__.py")
    require(
        sources["vllm_muxpd"] == candidate["plugin_identity"],
        "Candidate package identity differs",
    )
    return {
        "sources": sources,
        "candidate_manifest": copy.deepcopy(candidate),
        "runtime_files": actual,
        "reviewed_diff_sha256": review["sha256"],
    }


def apply_policy_changes(config, candidate):
    require(
        candidate.get("schema") == IDENTITY_SCHEMA,
        "Require explicit q40 identity schema-v2",
    )
    result = copy.deepcopy(config)
    changes = candidate.get("policy_additions")
    require(
        type(changes) is dict
        and set(changes) == {POLICY_KEY, "require_hccl_deterministic"}
        and changes[POLICY_KEY] == "prefix"
        and changes["require_hccl_deterministic"] is True,
        "Only the two explicit builtin-prefix policy additions are permitted",
    )
    policy = result["batch_admission_policy_config"]
    require(
        not set(changes) & set(policy),
        "Policy additions cannot overwrite original fields",
    )
    overrides = candidate.get("policy_overrides")
    require(
        type(overrides) is list and len(overrides) == 1,
        "Require exactly one policy override",
    )
    override = overrides[0]
    require(
        type(override) is dict
        and set(override) == {"key", "from", "to"}
        and override["key"] == "layers_per_slice"
        and type(override["from"]) is int
        and override["from"] == 4
        and type(override["to"]) is int
        and override["to"] == 40,
        "Only exact integer layers_per_slice4-to40 override is permitted",
    )
    require(
        type(policy.get("layers_per_slice")) is int and policy["layers_per_slice"] == 4,
        "Declared original policy before-value differs",
    )
    policy["layers_per_slice"] = 40
    policy.update(changes)
    require(
        result["worker_cls"] == WORKER and not result.get("worker_extension_cls"),
        "Only the canonical runtime worker is permitted",
    )
    return result


def validate_model_config(candidate):
    """Read the original config bytes at a declared constructor boundary."""
    expected = {
        "path": "/root/workspace/models/Qwen3.5-35B-A3B/config.json",
        "sha256": "5e4d7f74fec2f360eb9cfbfcd6ec0c4c76e684d3a11caaed259d9fd9bfbc7944",
    }
    require(
        candidate.get("model_config_identity") == expected,
        "Candidate must bind the original model config identity",
    )
    require(
        file_sha(expected["path"]) == expected["sha256"],
        "Actual model config bytes changed",
    )
    return copy.deepcopy(expected)


def validate_launch_environment(env, history, candidate):
    """Check the actual child environment, allowing declared placement only."""
    expected = copy.deepcopy(history["environment"])
    overrides = candidate["environment_overrides"]
    require(
        set(overrides) <= {"ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES"},
        "Only declared placement environment overrides are permitted",
    )
    expected.update(overrides)
    actual = {key: env.get(key) for key in expected}
    mismatch = sorted(key for key in expected if actual[key] != expected[key])
    require(
        not mismatch,
        "Source /root/workspace/runtime/env.sh before launch; mismatched environment: "
        + ", ".join(mismatch),
    )
    return {
        "passed": True,
        "environment": actual,
        "scope": "Actual child tracked environment; only declared placement differs. No environment mutation or package metadata inference.",
    }


def validate_environment(actual, history, candidate):
    expected = copy.deepcopy(history)
    # Device placement is declared independently from unchanged model/config/sampling.
    overrides = candidate["environment_overrides"]
    require(
        set(overrides) <= {"ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES"},
        "Undeclared non-placement environment change",
    )
    expected["environment"].update(overrides)
    require(
        actual == expected, "Original runtime environment or declared placement changed"
    )


def builtin_snapshot(argument):
    from vllm_muxpd.prefill_collective_layout import snapshot_on_worker

    return snapshot_on_worker(argument)


def candidate_worker_snapshot(argument):
    import inspect

    from probe_run_v1 import worker_snapshot

    row = worker_snapshot(argument)
    worker = getattr(argument, "worker", argument)
    row["builtin_layout"] = builtin_snapshot(worker)
    row["worker_source_path"] = str(Path(inspect.getfile(type(worker))).resolve())
    row["foreign_diagnostic_state"] = {
        name: hasattr(worker, name)
        for name in (
            "_graph_tap_observer",
            "_mixed_ordered_observer",
            "_muxpd_prefill_collective_layout_v1",
            "_muxpd_layer_capture_v3",
        )
    }
    return row


def validate_candidate_workers(rows, candidate):
    from probe_run_v1 import validate_workers

    validate_workers(rows, "raw-layout-plain")
    historical = original_manifest()["historical_runs"]["raw-quality-v2-hccl-true-01"][
        "engine_args"
    ]
    expected = apply_policy_changes(historical, candidate)[
        "batch_admission_policy_config"
    ]
    for row in rows:
        require(
            row["worker_source_path"]
            == str(
                Path(candidate["source_root"]) / "src/vllm_muxpd/decoupled_worker.py"
            )
            and not any(row["foreign_diagnostic_state"].values()),
            "Worker source/diagnostic state differs",
        )
        require(
            json.dumps(row["runtime"]["policy"], sort_keys=True, separators=(",", ":"))
            == json.dumps(expected, sort_keys=True, separators=(",", ":")),
            "Actual entire worker policy differs from configured candidate policy",
        )


def four(rows):
    require(
        len(rows) == 4 and {r["rank"] for r in rows} == set(range(4)),
        "Expected four unique TP ranks",
    )
    return {r["rank"]: r for r in rows}


def route(row, rank, lane):
    require(
        row["ranks"] == [0, 1, 2, 3]
        and row["ranks"][row["rank_in_group"]] == rank
        and row["active_lane"] == lane
        and row["device_group_python_id"] != row["selected_device_group_python_id"]
        and row["coordinator_name"] != row["selected_coordinator_name"],
        "Original isolated collective route differs",
    )


def validate_snapshot(row, sha, count):
    require(
        row["schema"] == PREFIX_SCHEMA
        and row["profile"] == PREFIX_PROFILE
        and row["mode"] == "prefix"
        and row["module_sha256"] == sha
        and row["installed_hook_count"] == 3
        and row["all_hooks_intact"]
        and row["hidden_size"] == 2048
        and row["expected_device"] == f"npu:{row['local_rank']}"
        and row["active_cohort"] is None
        and row["active"] is None
        and not row["in_collective"]
        and not row["errors"]
        and row["primary_failure"] is None
        and not row["uninstalled"]
        and row["stats"]["admitted"] == row["stats"]["closed"] == count
        and row["stats"]["admission_failed"] == 0
        and row["history_is_complete"] == (count <= 16)
        and row["limits"]["history_size"] == 16
        and len(row["recent_cohorts"]) == min(count, 16)
        and row["first_execute_verified"] == (count > 0)
        and row["treated_cohorts"] == row["stats"]["treated"],
        "Builtin prefix lifecycle/stats failed",
    )
    route(row["startup_route"], row["rank"], None)


def expected_cohorts(batch, admissions, receipts, cases):
    selected = [a for a in admissions if a["batch_id"] == batch["batch_id"]]
    scheduled = [
        r
        for r in receipts
        if r["batch_id"] == batch["batch_id"]
        and r["event"] == "schedule"
        and r["new_prefill_ids"]
    ]
    retired = [
        r
        for r in receipts
        if r["batch_id"] == batch["batch_id"] and r["event"] == "retirement"
    ]
    require(
        len(selected) == len(scheduled) == 2,
        "Missing original seed/peer admissions or schedules",
    )
    by_case = {r["case_id"]: r for r in cases}
    expected = []
    for i, (admission, schedule) in enumerate(zip(selected, scheduled, strict=True)):
        ids = batch["case_ids"][:1] if i == 0 else batch["case_ids"][1:]
        require(
            admission["stage"] == ("seed" if i == 0 else "peers")
            and [r["case_id"] for r in admission["bindings"]] == ids,
            "Original batch admission changed",
        )
        if i:
            require(
                admission["seed_output_tokens"] == 1,
                "Original first-token gate changed",
            )
        tokens = {
            r["internal"]: by_case[r["case_id"]]["prompt_token_ids"]
            for r in admission["bindings"]
        }
        pcounts = {rid: len(t) for rid, t in tokens.items()}
        dcounts = {
            rid: n
            for rid, n in schedule["scheduled_tokens"].items()
            if rid not in pcounts
        }
        require(
            set(schedule["new_prefill_ids"]) == set(pcounts)
            and not schedule["preempted_req_ids"]
            and {rid: schedule["scheduled_tokens"][rid] for rid in pcounts} == pcounts,
            "Actual P schedule differs",
        )
        seed = selected[0]["bindings"][0]["internal"]
        require(
            (not dcounts if i == 0 else set(dcounts) <= {seed})
            and all(type(n) is int and n == 1 for n in dcounts.values()),
            "Actual sequential D admission differs",
        )
        completions = [
            rid for r in retired for rid in r["completed_prefill_ids"] if rid in pcounts
        ]
        require(
            sorted(completions) == sorted(pcounts)
            and not any(r["cancelled_prefill_ids"] for r in retired),
            "Actual prefill retirement is missing/duplicated/cancelled",
        )
        expected.append((pcounts, dcounts, tokens))
    return expected


def validate_record(record, expected, row, ordinal):
    p, d, tokens = expected
    require(
        record["cohort_id"] == ordinal
        and record["mode"] == "prefix"
        and record["status"] == "closed"
        and record["clear_count"] == 1
        and record["error"] is None
        and not record["native_equivalent_order_claimed"]
        and record["admission_p_counts"] == p
        and record["admission_d_counts"] == d
        and record["p_rows"] == sum(p.values())
        and record["d_rows"] == sum(d.values()),
        "Cohort ownership/admission differs",
    )
    batch = record["batch"]
    ids = batch["req_ids"]
    qsl = batch["query_start_loc"]
    require(
        batch["packed_tokens_and_positions_verified"]
        and len(ids) == len(p)
        and set(ids) == set(p)
        and len(qsl) == len(p) + 1
        and qsl[0] == 0
        and qsl[-1] == sum(p.values())
        and len(batch["rows"]) == len(p),
        "Packed P metadata differs",
    )
    for i, item in enumerate(batch["rows"]):
        rid = ids[i]
        begin, end = qsl[i : i + 2]
        require(
            item["request_id"] == rid
            and item["computed_tokens"] == item["output_tokens"] == 0
            and item["token_start"] == begin
            and item["token_end"] == end
            and item["prompt_tokens"] == end - begin == p[rid]
            and item["prompt_sha256"]
            == hashlib.sha256(
                json.dumps(tokens[rid], separators=(",", ":")).encode()
            ).hexdigest(),
            "Frozen prompt fingerprint/boundary differs",
        )
    calls = record["calls"]
    zero = record["zero_d_bypass_calls"]
    require(
        (len(calls) == 81 and zero == 0) if d else (not calls and zero == 81),
        "Original 81 P reductions differ",
    )
    for i, call in enumerate(calls, 1):
        require(
            call["ordinal"] == i
            and call["mode"] == "prefix"
            and call["input_shape"] == [sum(p.values()), 2048]
            and call["collective_payload_shape"]
            == [sum(p.values()) + sum(d.values()), 2048]
            and call["prefix_rows"]
            == call["dummy_rows"]
            == call["copyback_offset"]
            == sum(d.values())
            and call["suffix_rows"] == 0
            and call["dtype"] == "torch.bfloat16"
            and call["device"] == row["expected_device"]
            and call["existing_collective_calls"] == 1
            and call["return_original_input"]
            and call["status"] == "complete"
            and call["error"] is None
            and call["router_call_delta"] == {"caller": 0, "decode": 0, "prefill": 1},
            "Original collective/alias/payload receipt differs",
        )
        before, after = call["route_before"], call["route_after"]
        for side in (before, after):
            route(side, row["rank"], "prefill")
            require(
                all(
                    side[k] == row["startup_route"][k]
                    for k in side
                    if k not in ("router_calls", "active_lane")
                ),
                "Collective startup route changed",
            )
        require(
            {
                k: after["router_calls"][k] - before["router_calls"][k]
                for k in ("caller", "decode", "prefill")
            }
            == call["router_call_delta"],
            "Router count delta differs",
        )


def normalized(records):
    result = copy.deepcopy(records)
    for record in result:
        for call in record["calls"]:
            for key in ("device", "route_before", "route_after"):
                del call[key]
    return result


class PrefixTracker:
    def __init__(self, rows, module_sha):
        self.module_sha = module_sha
        self.previous = copy.deepcopy(four(rows))
        self.total_cohorts = 0
        self.batches = []
        for row in self.previous.values():
            validate_snapshot(row, module_sha, 0)
            require(
                row["stats"] == dict.fromkeys(STATS, 0),
                "Startup prefix counters are not zero",
            )

    def append(self, rows, batch, admissions, receipts, cases):
        require(
            batch["batch_id"] not in [b["batch_id"] for b in self.batches],
            "Repeated batch cannot replace fresh full execution",
        )
        current = four(rows)
        expected = expected_cohorts(batch, admissions, receipts, cases)
        signatures = []
        for rank, row in current.items():
            validate_snapshot(row, self.module_sha, self.total_cohorts + 2)
            prev = self.previous[rank]
            new = row["recent_cohorts"][-2:]
            require(
                row["recent_cohorts"][:-2] == prev["recent_cohorts"][-14:],
                "Retained prefix ring was rewritten",
            )
            require(
                row["startup_route"] == prev["startup_route"],
                "Original startup route drifted",
            )
            for i, record in enumerate(new):
                validate_record(record, expected[i], row, self.total_cohorts + i + 1)
            delta = {
                "admitted": 2,
                "closed": 2,
                "admission_failed": 0,
                "treated": sum(bool(d) for _, d, _ in expected),
                "transformed_calls": sum(len(r["calls"]) for r in new),
                "zero_d_calls": sum(r["zero_d_bypass_calls"] for r in new),
            }
            require(
                {k: row["stats"][k] - prev["stats"][k] for k in STATS} == delta,
                "Prefix counters do not match the two new cohorts",
            )
            signatures.append(normalized(new))
        require(
            all(r == signatures[0] for r in signatures),
            "Four-rank cohort/call metadata differs",
        )
        self.total_cohorts += 2
        self.previous = copy.deepcopy(current)
        item = {
            "batch_id": batch["batch_id"],
            "total_cohorts": self.total_cohorts,
            "new_cohorts": signatures[0],
            "stats": copy.deepcopy(current[0]["stats"]),
            "passed": True,
        }
        self.batches.append(item)
        return item


def save_batch_snapshot(llm, tracker, report, output, batch, cases):
    rows = llm.collective_rpc(builtin_snapshot, timeout=60)
    receipts = [
        json.loads(line)
        for line in (output / "scheduler-receipts.jsonl").read_text().splitlines()
    ]
    path = output / f"prefix-batch-{batch['batch_id']:02d}.json"
    require(not path.exists(), "Batch snapshot cannot overwrite earlier evidence")
    # Persist raw evidence before semantic validation; failed receipts are retained.
    save(path, {"batch_id": batch["batch_id"], "rows": rows})
    item = {
        "batch_id": batch["batch_id"],
        "path": str(path.resolve()),
        "sha256": file_sha(path),
        "validation": None,
    }
    report["prefix_batches"].append(item)
    item["validation"] = tracker.append(
        rows, batch, report["admissions"], receipts, cases
    )


def validate_final_snapshot(rows, tracker):
    current = four(rows)
    require(
        current == tracker.previous,
        "Final maintenance changed builtin prefix cohort evidence",
    )
    return {
        "passed": True,
        "total_cohorts": tracker.total_cohorts,
        "stats": current[0]["stats"],
    }


def audit_terminal(path, terminal, last_rows, module_sha):
    require(
        terminal.get("terminal_process_proven") is True,
        "Process terminal proof required before reading child log",
    )
    require(
        terminal.get("exit_code") == 0
        and terminal.get("owned_processes") == []
        and terminal.get("controller_forced_cleanup") is False
        and terminal.get("forced_termination") is False
        and terminal.get("devices_idle") is True,
        "Unclean process/device terminal state",
    )
    last = four(last_rows)
    data = Path(path).read_bytes()
    lines = re.sub(r"\x1b\[[0-9;]*m", "", data.decode(errors="replace")).splitlines()
    require(
        not any(
            "Traceback" in line
            or "Layout slot changed externally" in line
            or "Layout is poisoned" in line
            for line in lines
        ),
        "Terminal log contains failure/ownership evidence",
    )
    starts = []
    finals = []
    for line in lines:
        for marker, target in (
            ("MuxPD prefix layout startup ", starts),
            ("MuxPD prefix layout final ", finals),
        ):
            if marker in line:
                target.append(json.loads(line.split(marker, 1)[1]))
    for row in four(starts).values():
        validate_snapshot(row, module_sha, 0)
    for rank, row in four(finals).items():
        count = last[rank]["stats"]["closed"]
        require(
            row["schema"] == FINAL_SCHEMA
            and row["mode"] == "prefix"
            and row["module_sha256"] == module_sha
            and row["installed_hook_count"] == row["restored_count"] == 3
            and row["all_originals_restored"]
            and row["uninstalled"]
            and row["primary_failure"] is None
            and not row["in_collective"]
            and row["active_cohort"] is None
            and row["stats"] == last[rank]["stats"]
            and row["retained_history_size"] == min(count, 16)
            and row["history_is_complete"] == (count <= 16)
            and row["collection_success_not_inferred_from_cleanup"] is True,
            "Builtin shutdown restoration failed",
        )
    return {
        "passed": True,
        "startup_ranks": sorted(four(starts)),
        "final_ranks": sorted(four(finals)),
        "log_sha256": hashlib.sha256(data).hexdigest(),
        "quality_qualification": False,
    }
