"""Offline terminal assessment of one frozen posterior32/freshfull200 candidate pair."""

import argparse
import json
from pathlib import Path

import candidate_quality_analysis_v2 as core


def analyze(posterior, full, bundle, identity, output):
    core.require(
        not output.exists(), "Refuse to overwrite a prior candidate assessment"
    )
    result = {
        "schema": "muxpd-runtime-candidate-quality-assessment-v2",
        "analysis_scope": "posterior32" if full is None else "pair",
        "passed": False,
        "runtime_collection_qualified": False,
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "errors": [],
        "scope": "Terminal/runtime qualification and answer outcomes are separate. No performance claim; posterior32 cannot replace freshfull200.",
    }
    try:
        if full is None:
            proof, value, refs = core.qualify_posterior(posterior, bundle, identity)
            result["qualification"] = proof
            result["runtime_collection_qualified"] = True
            result["answer_results"] = {
                "posterior32": core.score_posterior(value, refs, bundle)
            }
        else:
            proof, values, refs = core.qualify_pair(posterior, full, bundle, identity)
            result["qualification"] = proof
            result["runtime_collection_qualified"] = True
            result["answer_results"] = core.score_qualified_pair(values, refs, bundle)
            result["full_quality_gate_attempted"] = True
            result["full_frozen_plan_passed"] = result["answer_results"][
                "original_strict_evaluation"
            ]["bounded_answer_quality_gate_passed"]
        result["passed"] = (
            True  # Assessment/collection success, never answer-quality acceptance.
        )
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--posterior", type=Path, required=True)
    parser.add_argument(
        "--full",
        type=Path,
        help="Omit to qualify and score only posterior32 before starting full200",
    )
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument(
        "--identity",
        type=Path,
        default=Path(__file__).with_name("candidate-identity-template-v1.json"),
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.posterior, args.full, args.bundle, args.identity, args.output)
    print(
        json.dumps(
            {
                k: result[k]
                for k in (
                    "passed",
                    "runtime_collection_qualified",
                    "full_quality_gate_attempted",
                    "full_frozen_plan_passed",
                    "errors",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
