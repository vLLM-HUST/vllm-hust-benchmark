"""Stage only qualified builtin32 evidence; never read the live external attempt."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

BRIDGE = Path('/root/workspace/muxpd-q40-external-posterior32-20261030')
BUILTIN = Path('/root/workspace/muxpd-runtime-quality-candidate-v2-20261030')
RUN = BUILTIN/'runs-v1/prefix-q40-runtime-posterior32-v1-01'
STAGING = BRIDGE/'publication-staging-v1'
DEST = STAGING/'report-v1'
PRIMARY_SHA = '8cf06b3396fc484baab24e2af710b74890f2b28269515c40fea1d692ef50910a'
INDEPENDENT_SHA = '99094b40a6cbf63287986713e44e56db5690b1198752ac99f022327c9d6fc09d'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def source(path):
    path=Path(path)
    # This producer has no external-run read path, including its controller.
    if path.resolve().is_relative_to(BRIDGE/'runs-v1'):
        raise ValueError('External live attempt is forbidden to this builtin stager')
    return path.read_bytes()


def read(path):
    return json.loads(source(path))


def main():
    controller=read(RUN/'controller.json')
    assert controller['passed'] is True and controller['terminal_process_proven'] is True
    assert controller['exit_code']==0 and controller['owned_members_after_cleanup']==[]
    assert controller['idle_physical_after']==['3','4','5','6']
    assert not controller.get('cleanup_required') and not controller.get('forced_termination')
    primary_path=BUILTIN/'analysis-posterior32-v1.json'
    independent_path=BUILTIN/'independent-review-v1/posterior32-terminal-check-v1.json'
    assert digest(source(primary_path))==PRIMARY_SHA
    assert digest(source(independent_path))==INDEPENDENT_SHA
    primary,independent=read(primary_path),read(independent_path)
    assert primary['passed'] is True and primary['runtime_collection_qualified'] is True and independent['passed'] is True
    assert primary['full_quality_gate_attempted'] is False and primary['full_frozen_plan_passed'] is None
    answers=primary['answer_results']['posterior32']
    assert answers['relative_no_new_wrong']=={'passed':False,'case_ids':['mmlu-pro-01741'],'scope':'Posterior32 only'}
    assert independent['relative_no_new_wrong_passed'] is False
    report=read(RUN/'results/run.json')
    assert digest(source(RUN/'results/run.json'))==independent['child_sha256']=='c1dab8b9c7cca79850c69b1a63d3adc368cb241b864ab596aac8c7103f88189e'
    assert report['selected_batch_ids']==[3,6,7,14] and len(report['outputs'])==32
    assert answers['scores']['candidate']['correct']==29 and answers['scores']['candidate']['all_complete'] is True
    rows=answers['rows']
    target=next(r for r in rows if r['case_id']=='mmlu-pro-01741')
    restored=next(r for r in rows if r['case_id']=='mmlu-pro-07338')
    assert target['arms']['candidate']['answer']=='C' and target['arms']['candidate']['output_tokens']==5551 and target['arms']['candidate']['finish_reason']=='stop'
    assert target['gold']=='E' and all(target['arms'][arm]['correct'] for arm in ('native1','native2','prefix'))
    assert restored['arms']['candidate']['answer']=='H' and restored['arms']['candidate']['output_tokens']==3292 and restored['arms']['candidate']['correct']
    assert not DEST.exists(),'Refuse to overwrite fixed builtin staging artifacts'
    DEST.mkdir()
    assert digest(source(BUILTIN/'posterior32-token-localization-v1.json'))=='ba03247fc6f554397817af40d2588ccba078ab61f6d956aa9e8edba2d46f64ca'
    paths={
        'builtin-controller-v1.json.gz':RUN/'controller.json',
        'builtin-run-v1.json.gz':RUN/'results/run.json',
        'builtin-scheduler-v1.jsonl.gz':RUN/'results/scheduler-receipts.jsonl',
        'builtin-process-v1.log.gz':RUN/'process.log',
        'builtin-npu-before-v1.txt':RUN/'npu-before.txt',
        'builtin-npu-after-v1.txt':RUN/'npu-after.txt',
        'builtin-analysis-v1.json.gz':primary_path,
        'builtin-independent-v1.json.gz':independent_path,
        'builtin-token-localization-v1.json.gz':BUILTIN/'posterior32-token-localization-v1.json',
        'builtin-source-identity-v1.json.gz':BUILTIN/'candidate-identity-v1.json',
        'builtin-freeze-v1.json.gz':BUILTIN/'freeze-manifest-v1.json',
    }
    for batch in (3,6,7,14):
        paths[f'builtin-prefix-batch-{batch:02d}-v1.json.gz']=RUN/f'results/prefix-batch-{batch:02d}.json'
    entries={}
    for name,path in paths.items():
        raw=source(path)
        encoded=gzip.compress(raw,mtime=0) if name.endswith('.gz') else raw
        (DEST/name).write_bytes(encoded)
        restored_bytes=gzip.decompress(encoded) if name.endswith('.gz') else encoded
        assert restored_bytes==raw
        entries[name]={'kind':'exact-source-copy','source_path':str(path),'source_sha256':digest(raw),'source_bytes':len(raw),'encoding':'gzip' if name.endswith('.gz') else 'identity','stored_sha256':digest(encoded),'stored_bytes':len(encoded),'local_roundtrip_verified':True}
    members={};origins={}
    def member(name,path,expected=None):
        raw=source(path)
        assert name not in members
        if expected is not None:assert digest(raw)==expected
        members[name]=raw;origins[name]=str(path)
    freeze=read(BUILTIN/'freeze-manifest-v1.json')
    assert len(freeze['files'])==22
    for name,sha in freeze['files'].items():member('builtin/producer/'+name,BUILTIN/name,sha)
    identity=read(BUILTIN/'candidate-identity-v1.json')
    assert identity['candidate_commit']=='a05029484b2c9bc21e4e6fd705cc396d111dfaa5'
    for name,sha in identity['runtime_files'].items():member('runtime/'+name,Path(identity['source_root'])/name,sha)
    member('builtin/evidence/independent-checker-v1.py',BUILTIN/'independent-review-v1/check_terminal_v1.py',independent['script_sha256'])
    member('publication/stage_builtin_v1.py',Path(__file__).resolve())
    capsule_manifest={'schema':'muxpd-builtin-q40-posterior32-source-capsule-v1','status':'builtin-terminal-only-external-pending','producer_count':22,'runtime_source_count':len(identity['runtime_files']),'scope':'One copy of original frozen200 inputs in builtin producer set, actual bound a050 runtime source files and independent checker. No external result, logits NPY, model weights or recopy of historical full200 reports. Published identity/freeze bind source files; original server dependencies remain required.','members':{name:{'source_path':origins[name],'sha256':digest(raw),'bytes':len(raw)} for name,raw in members.items()}}
    members['MANIFEST.json']=(json.dumps(capsule_manifest,indent=2)+'\n').encode()
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as archive:
        for name,raw in sorted(members.items()):
            item=tarfile.TarInfo(name);item.size=len(raw);item.mtime=0;item.mode=0o444
            archive.addfile(item,io.BytesIO(raw))
    packed=gzip.compress(buffer.getvalue(),mtime=0)
    capsule=DEST/'builtin-source-capsule-v1.tar.gz';capsule.write_bytes(packed)
    with tarfile.open(capsule) as archive:
        assert set(archive.getnames())==set(members)
        for name,raw in members.items():assert archive.extractfile(name).read()==raw
    entries[capsule.name]={'kind':'source-capsule','stored_sha256':digest(packed),'stored_bytes':len(packed),'member_count':len(members),'member_manifest_sha256':digest(members['MANIFEST.json']),'local_all_members_verified':True}
    external={'schema':'muxpd-external-q40-publication-status-v1','status':'PENDING','collection_qualified':None,'port_equivalence_passed':None,'answer_results':None,'source_evidence_files':None,'full_quality_gate_attempted':False,'full_frozen_plan_passed':None,'reason':'Root has not authorized reading this attempt after terminal qualification. No current external controller, child, log, scheduler, tokens or snapshots were read by this stager.'}
    table={'schema':'muxpd-builtin-external-posterior32-table-v1','builtin_source_sha256':independent['child_sha256'],'primary_sha256':PRIMARY_SHA,'independent_sha256':INDEPENDENT_SHA,'external_status':'PENDING','selected_batch_ids':[3,6,7,14],'rows':[{**r,'external_q40':None} for r in rows],'scores':answers['scores'],'builtin_new_wrong_on_both_native_correct':['mmlu-pro-01741'],'builtin_relative_no_new_wrong_passed':False,'full_quality_gate_attempted':False,'full_frozen_plan_passed':None}
    (DEST/'external-status-v1.json').write_text(json.dumps(external,indent=2)+'\n')
    (DEST/'posterior32-table-v1.json').write_text(json.dumps(table,indent=2)+'\n')
    def cell(arm):
        answer=arm['answer'] if arm['answer'] is not None else '—'
        return f"{answer} / {arm['finish_reason']} / {arm['output_tokens']}"
    header='| batch | case | gold | native1 历史 | native2 历史 | raw 历史 | prefix q4 历史 | builtin q40 本轮 | external q40 |\n|---|---|---|---|---|---|---|---|---|'
    markdown=header+'\n'+'\n'.join('| '+' | '.join([str(r['original_batch_id']),r['case_id'].replace('mmlu-pro-',''),r['gold']]+[cell(r['arms'][arm]) for arm in ('native1','native2','raw','prefix','candidate')]+['PENDING'])+' |' for r in rows)+'\n'
    (DEST/'posterior32-table-v1.md').write_text(markdown)
    schedule=primary['qualification']['attempts']['posterior32']['schedule']
    assert sum(r['serving_steps'] for r in schedule['batches'])==15457 and schedule['decode_turns']==15453
    text=f'''# q40 内置运行时 posterior32 仍有新增错误；外置同历史对照待完成

**实际内置 q40 候选完成了原 posterior32，采集与独立复核通过，但答案“不新增错误”失败。** 原评分器给出29/32，全部自然 `stop` 完成。01741金答案E，两个历史native和旧prefix q4均答E；本轮内置q40答C，输出5551 tokens。07338恢复为H/stop/3292，并不能抵消01741新增错误。**未启动full200；当前候选不能宣称答案质量验收通过。**

外置q40同源码、同32题历史对照为 **PENDING**。本草稿未读取其正在运行的控制器、子报告、日志、调度或token数据，也没有预填等价/不等价、评分或吞吐结论。此目录是本地staging，不表示已发布、已上传或通过匿名HTTPS读回。

## 32题与历史对照

保留原冻结200题计划字节，仅按原顺序执行batch3、6、7、14，共32题；每批仍先seed输出一个token，再加入原七条peer，并等待整批自然结束。温度0、seed42、max_tokens8192、自然停止和原canonical scorer未改。历史各臂对应行来自其完整200题，之前执行的批次历史与本轮posterior32不同；它们不是新增匹配进程。当前对照的重点是同一a050源码和同一posterior32顺序下，内置与外置prefix是否产生相同实际结果。

每格为“原提取答案 / finish_reason / 输出token数”。`—`是原评分器不提取答案；`length`按原规则不完整且错误，不以文本含金答案改判。外置列尚无数据。

{markdown}

历史native1/native2各30/32且这些选中案例均完整；raw为27/32、旧prefix q4为29/32且仍有不完整案例。当前builtin q40为29/32、32题均完整；错误为01680、01741、01802，其中**只有01741是两次native都正确但候选错误的新增错题**。旧prefix07338的length退化已恢复。不能仅凭总分与旧prefix同为29/32宣称无退化，也不能凭8题局部成功宣称整体修复。历史完整200题的严格完整性门仍FAIL，不能把posterior32的完整性替代它。

## 实际内置候选与调度

候选源码commit为`a05029484b2c9bc21e4e6fd705cc396d111dfaa5`，模型Qwen3.5-35B-A3B BF16，TP4/EP4，物理卡3/4/5/6，HCCL deterministic。实际内置prefix配置、显式layers_per_slice4→40、模型config构造前后、tokenizer、全worker policy和源码收据均经主/独立校验。没有数值观察器或更换原评分器。

实际15457次serving，四批分别5413/1199/3293/5552次。各rank D图replay增量15453，P eager forward增量8；每批两个P cohort（seedD0、七peer伴随seedD1），peer一次推进40层并收齐七条ACK，每个cohort保留原81次P reduction或D0 bypass。D覆盖根据实际调度随自然完成缩减计算，未用固定token截止数代替。

此前单独新进程external q40 full8的batch7全部正确；当前内置posterior32的batch7八条完整输出也逐token延续为同样的完整输出。这只支持batch7的一致性。batch14的01741相对native首次token差异14早已存在于旧prefix q4；新旧prefix目标前57tokens相同，最早同批peer01923在22、01984在34变化，目标在58变化。完整差异记录见[终态CPU token定位](builtin-token-localization-v1.json.gz)。该定位不证明某算子根因，也不支持按题号、金答案或两例结果选择quota。

## 外置同历史桥接：PENDING

预先声明的唯一对照使用同a050源码、同batch3/6/7/14原32题顺序、同8192自然完整答案和每批一次快照RPC节奏；将builtin prefix明确设为off，安装冻结external prefix模块`6431c4c0abdd869ef17e7122f681c457ad2b4d5741f86c6a0653e9fca44e02fc`，其余q40、环境、模型和采样保持。外置控制并非新候选通过声明。

root确认终态后，才补全部32条完整tokens/text/finish/stop与原评分、实际admission映射后的调度及各rank collective几何比较。双方自然输出长度允许不同，D replay分别按真实调度重算；合法不等将报告为port-equivalence差异，不伪装成采集失败。无论该对照是否相等，当前内置01741C/5551失败均保留。没有full200授权、性能或Goodput收益结论。

## 已固定的内置终态证据

| 项目 | SHA256或结果 |
|---|---|
| 终态 | {controller['finished_at']}，exit0，自有进程为空，四卡空闲 |
| 子报告 | `c1dab8b9c7cca79850c69b1a63d3adc368cb241b864ab596aac8c7103f88189e` |
| 控制器 | `6baaeb18ad8b70e819c8dcc8cae57fb1b27a05077d8da2af5be501af84793ffd` |
| 主分析 | `{PRIMARY_SHA}` |
| 独立复核 | `{INDEPENDENT_SHA}` |
| 源身份 | `8d04890973c369a5412e80cc08c6cb55ef405e9360bd38e2bfafa9b5d65fe4fe` |
| 冻结清单 | `507f4c76f999476e7a182fca9b2e7ba1655a8678d37454b4286d18664f3fdfcb` |
| 原评分器 | `157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd` |

[发布映射](publication-map-v1.json)记录原件与无损gzip副本的SHA及字节数；[源码包](builtin-source-capsule-v1.tar.gz)包含原22文件producer、25个实际绑定runtime文件、独立脚本与本stager，逐成员SHA见包内MANIFEST。原200输入只保留一次，历史完整200报告及模型依赖未重复打包；没有大NPY或任何新logits张量。本地已逐字节复核gzip还原和全部源码包成员。

外置终态以后应新增明确版本的addendum、比较结果和报告，保留当前builtin固定证据及PENDING草稿谱系；不得覆盖失败样本或选择性重跑。关联：[Issue #23](https://github.com/vLLM-HUST/vllm-ascend-MuxPD-hust/issues/23)、[此前局部8题完整答案](../muxpd-q40-full-answer-20261030/REPORT-v1.md)。
'''
    (DEST/'REPORT-v1.md').write_text(text)
    (DEST/'README.md').write_text('''**内置 q40 posterior32 为29/32，01741新增答错（E→C，5551 tokens，自然stop），“不新增错误”失败；full200未启动。** 07338恢复H/3292和此前局部8题成功不能代表整体修复。

外置同源码、同32题历史对照 **PENDING**；当前目录只固定已终态的builtin证据，未读取外置live结果。此为本地staging，不表示已发布。

- [报告草稿与32题表](REPORT-v1.md)
- [机器可读32题表](posterior32-table-v1.json)
- [完整token子报告](builtin-run-v1.json.gz)、[原调度](builtin-scheduler-v1.jsonl.gz)
- [主分析](builtin-analysis-v1.json.gz)、[独立复核](builtin-independent-v1.json.gz)
- [源码包](builtin-source-capsule-v1.tar.gz)、[发布映射](publication-map-v1.json)、[外置PENDING状态](external-status-v1.json)

不包含logits NPY，不声称性能、Goodput或完整200题验收通过。
''')
    subprocess.run(['/root/workspace/.venv/bin/mdformat','--wrap','100',str(DEST/'README.md'),str(DEST/'REPORT-v1.md'),str(DEST/'posterior32-table-v1.md')],check=True)
    assert all(p.stat().st_size < 950_000 for p in DEST.iterdir()),'Per-file publication size limit exceeded'
    for name in ('external-status-v1.json','posterior32-table-v1.json','posterior32-table-v1.md','REPORT-v1.md','README.md'):
        raw=(DEST/name).read_bytes();entries[name]={'kind':'derived-draft','stored_sha256':digest(raw),'stored_bytes':len(raw),'derived_from_primary_sha256':PRIMARY_SHA,'external_status':'PENDING'}
    mapping={'schema':'muxpd-builtin-external-posterior32-publication-map-v1','status':'builtin-fixed-external-pending-local-staging','builtin_collection_qualified':True,'builtin_relative_no_new_wrong_passed':False,'builtin_new_wrong':['mmlu-pro-01741'],'external_status':'PENDING','full_quality_gate_attempted':False,'full_frozen_plan_passed':None,'entries':entries,'scope':'No GitHub write, shared benchmark worktree mutation, external live read, NPY publication or anonymous readback claim.'}
    (DEST/'publication-map-v1.json').write_text(json.dumps(mapping,indent=2)+'\n')
    verification={'schema':'muxpd-builtin-posterior32-local-publication-verification-v1','passed':True,'directory':str(DEST),'source_copy_count':len(paths),'source_capsule_members':len(members),'table_rows':len(rows),'publication_map_sha256':digest((DEST/'publication-map-v1.json').read_bytes()),'external_status':'PENDING','external_live_read':False,'markdown_format':'mdformat --wrap 100 before publication map','max_file_bytes':max(p.stat().st_size for p in DEST.iterdir()),'all_gzip_roundtrips_exact':True,'all_capsule_members_exact':True,'source_capsule_sha256':digest(packed),'total_staged_bytes':sum(p.stat().st_size for p in DEST.iterdir())}
    (STAGING/'local-verification-v1.json').write_text(json.dumps(verification,indent=2)+'\n')
    print(json.dumps(verification,indent=2))


if __name__=='__main__':
    main()
