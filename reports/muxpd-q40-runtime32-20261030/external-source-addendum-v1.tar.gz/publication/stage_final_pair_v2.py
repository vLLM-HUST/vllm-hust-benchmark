"""Append only terminal external32 evidence; retain the fixed PENDING v1 draft."""
import argparse
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

BRIDGE=Path('/root/workspace/muxpd-q40-external-posterior32-20261030')
STAGING=BRIDGE/'publication-staging-v1'
DRAFT=STAGING/'report-v1'
DEST=STAGING/'report-v2'
RUN=BRIDGE/'runs-v1/external-q40-posterior32-bridge-v1-01'
PRIMARY_SHA='f6ca2553f1b75bc978f9a29c420f6f4738415326eb034e054e8380370c1c285f'
CONTROLLER_SHA='ff95526437d6275b2c75eac1dad6362e5252970d43b8cf84c0645919bcbee876'
CHILD_SHA='d6fdb9311a6a25d4b94716e091c0de7bcb4afef597a7d1e3312a9c9414233b59'
DRAFT_MAP_SHA='7147fab552b95cb48b0d8aa6b1c873748a1684b13c3dfe8690bf95dcbb9bd1ee'


def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(Path(path).read_text())


def main(args):
    # Terminal proof precedes every external child/log/raw read.
    cp=RUN/'controller.json'
    assert digest(cp.read_bytes())==CONTROLLER_SHA
    c=read(cp)
    assert c['passed'] is True and c['terminal_process_proven'] is True and c['exit_code']==0
    assert c['owned_members_after_cleanup']==[] and c['idle_physical_after']==['3','4','5','6']
    assert not c.get('cleanup_required') and not c.get('forced_termination')
    rootgate=read(BRIDGE/'root-terminal-gate-v1.json')
    assert rootgate['passed'] and rootgate['controller_sha256']==CONTROLLER_SHA and rootgate['full200_authorized'] is False
    assert digest(args.independent.read_bytes())==args.independent_sha
    independent=read(args.independent)
    assert independent['passed'] is True and independent['collection_checks_passed'] is True and independent['port_equivalence_passed'] is True
    assert independent['errors']==[] and independent['answer_quality_accepted'] is False and independent['full_quality_gate_attempted'] is False
    assert digest(args.checker.read_bytes())=='65118cd1f1ec048a66336cd7ef60f952e0f42cbc0342678fd20e77e17f4d2394'
    assert digest((BRIDGE/'analysis-final-v1.json').read_bytes())==PRIMARY_SHA
    a=read(BRIDGE/'analysis-final-v1.json')
    assert a['passed'] and a['runtime_collection_qualified'] and a['port_equivalence_passed']
    assert a['full_quality_gate_attempted'] is False and a['full_frozen_plan_passed'] is None
    assert digest((RUN/'results/run.json').read_bytes())==CHILD_SHA
    r=read(RUN/'results/run.json')
    assert len(r['outputs'])==32 and r['selected_batch_ids']==[3,6,7,14]
    comparison=a['comparison']
    assert comparison['complete_outputs']['all_32_equal'] and comparison['schedule']['equal']
    assert all(v['equal'] for v in comparison['per_rank_collective_geometry'])
    assert comparison['answers']['external_new_wrong_on_both_native_correct']==['mmlu-pro-01741']
    assert comparison['answers']['scores']['external']['correct']==29 and comparison['answers']['scores']['external']['all_complete']
    assert digest((DRAFT/'publication-map-v1.json').read_bytes())==DRAFT_MAP_SHA
    oldmap=read(DRAFT/'publication-map-v1.json')
    assert not DEST.exists(),'Refuse to overwrite final staged report'
    DEST.mkdir()
    entries={}
    def copy(name,path,encoding=None,kind='exact-source-copy'):
        raw=Path(path).read_bytes()
        if encoding is None:encoding='gzip' if name.endswith('.gz') else 'identity'
        encoded=gzip.compress(raw,mtime=0) if encoding=='gzip' else raw
        (DEST/name).write_bytes(encoded)
        assert (gzip.decompress((DEST/name).read_bytes()) if encoding=='gzip' else (DEST/name).read_bytes())==raw
        entries[name]={'kind':kind,'source_path':str(Path(path)),'source_sha256':digest(raw),'source_bytes':len(raw),'encoding':encoding,'stored_sha256':digest(encoded),'stored_bytes':len(encoded),'local_roundtrip_verified':True}
    for name,metadata in oldmap['entries'].items():
        assert digest((DRAFT/name).read_bytes())==metadata['stored_sha256']
        if name=='README.md':
            copy('README-draft-v1.md',DRAFT/name,encoding='identity',kind='retained-draft')
        else:
            shutil.copyfile(DRAFT/name,DEST/name)
            entries[name]={**metadata,'retained_from_draft_map_sha256':DRAFT_MAP_SHA}
    copy('draft-publication-map-v1.json.gz',DRAFT/'publication-map-v1.json',kind='retained-draft-manifest')
    paths={
        'external-controller-v1.json.gz':cp,
        'external-run-v1.json.gz':RUN/'results/run.json',
        'external-scheduler-v1.jsonl.gz':RUN/'results/scheduler-receipts.jsonl',
        'external-process-v1.log.gz':RUN/'process.log',
        'external-npu-before-v1.txt':RUN/'npu-before.txt',
        'external-npu-after-v1.txt':RUN/'npu-after.txt',
        'external-analysis-v1.json.gz':BRIDGE/'analysis-final-v1.json',
        'external-independent-v1.json.gz':args.independent,
        'external-freeze-v1.json.gz':BRIDGE/'freeze-manifest-v1.json',
        'external-root-terminal-gate-v1.json.gz':BRIDGE/'root-terminal-gate-v1.json',
    }
    for batch in (3,6,7,14):paths[f'external-prefix-batch-{batch:02d}-v1.json.gz']=RUN/f'results/external-prefix-batch-{batch:02d}.json'
    for name,path in paths.items():copy(name,path)
    oldfreeze=json.loads(gzip.decompress((DRAFT/'builtin-freeze-v1.json.gz').read_bytes()))
    freeze=read(BRIDGE/'freeze-manifest-v1.json')
    assert len(freeze['files'])==31
    members={};origins={};logical={}
    def member(name,path,expected=None):
        raw=Path(path).read_bytes()
        if expected is not None:assert digest(raw)==expected
        assert name not in members
        members[name]=raw;origins[name]=str(path)
    for name,expected in freeze['files'].items():
        source=BRIDGE/name
        assert digest(source.read_bytes())==expected
        if oldfreeze['files'].get(name)==expected:
            logical[name]={'sha256':expected,'reused_capsule':'builtin-source-capsule-v1.tar.gz','reused_member':'builtin/producer/'+name}
        elif name=='source-reference-identity-v1.json':
            assert gzip.decompress((DRAFT/'builtin-source-identity-v1.json.gz').read_bytes())==source.read_bytes()
            logical[name]={'sha256':expected,'reused_artifact':'builtin-source-identity-v1.json.gz','encoding':'gzip'}
        else:
            target='external/producer/'+name;member(target,source,expected);logical[name]={'sha256':expected,'member':target}
    member('external/evidence/independent-checker-v1.py',args.checker)
    member('external/evidence/independent-before-review-v1.py',args.checker.with_name('audit_terminal_before_static_review_v1.py'))
    member('external/evidence/PLAN-v1.md',BRIDGE/'PLAN-v1.md')
    member('external/evidence/host-source-proof-v1.json',BRIDGE/'host-source-proof-v1.json')
    member('external/evidence/analyzer-cpu-validation-v1.json',BRIDGE/'analyzer-cpu-validation-v1.json')
    for name,expected in freeze['supporting_files'].items():
        target='external/evidence/'+name
        if target in members:assert digest(members[target])==expected
        else:member(target,BRIDGE/name,expected)
    member('publication/stage_final_pair_v2.py',Path(__file__).resolve())
    manifest={'schema':'muxpd-external32-source-addendum-v1','scope':'Only new bridge producer/support files. The22 unchanged producer files and original200 inputs reuse builtin capsule; actual source identity reuses the published builtin identity gzip. No copied historical200 reports or NPY.','logical_producer_files':logical,'members':{name:{'source_path':origins[name],'sha256':digest(raw),'bytes':len(raw)} for name,raw in members.items()}}
    members['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as archive:
        for name,raw in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o444;archive.addfile(info,io.BytesIO(raw))
    encoded=gzip.compress(buffer.getvalue(),mtime=0);capsule=DEST/'external-source-addendum-v1.tar.gz';capsule.write_bytes(encoded)
    with tarfile.open(capsule) as archive:
        assert set(archive.getnames())==set(members)
        for name,raw in members.items():assert archive.extractfile(name).read()==raw
    entries[capsule.name]={'kind':'source-addendum','stored_sha256':digest(encoded),'stored_bytes':len(encoded),'member_count':len(members),'member_manifest_sha256':digest(members['MANIFEST.json']),'local_all_members_verified':True,'unchanged_producer_reuse_count':sum('reused_capsule' in v for v in logical.values())}
    oldtable=read(DRAFT/'posterior32-table-v1.json')
    scores={v['case_id']:v for v in comparison['answers']['scores']['external']['rows']}
    outputs={v['case_id']:v for v in r['outputs']}
    table=copy_table={**oldtable,'schema':'muxpd-builtin-external-posterior32-table-v2','external_status':'terminal-qualified-port-equivalent','external_child_sha256':CHILD_SHA,'external_primary_sha256':PRIMARY_SHA,'external_independent_sha256':args.independent_sha,'rows':[]}
    for oldrow in oldtable['rows']:
        case=oldrow['case_id'];output=outputs[case]
        tokens_sha=digest(json.dumps(output['token_ids'],sort_keys=True,separators=(',',':')).encode())
        assert tokens_sha==oldrow['arms']['candidate']['token_ids_sha256']
        assert digest(output['text'].encode())==oldrow['arms']['candidate']['text_sha256']
        table['rows'].append({**oldrow,'external_q40':{**scores[case],'stop_reason':output.get('stop_reason'),'token_ids_sha256':tokens_sha,'text_sha256':digest(output['text'].encode())}})
    copy_table['scores']={**oldtable['scores'],'external':comparison['answers']['scores']['external']}
    (DEST/'posterior32-table-v2.json').write_text(json.dumps(table,indent=2)+'\n')
    def cell(v):return f"{v['answer'] if v['answer'] is not None else '—'} / {v['finish_reason']} / {v['output_tokens']}"
    markdown='| batch | case | gold | native1 历史 | native2 历史 | raw 历史 | prefix q4 历史 | builtin q40 | external q40 |\n|---|---|---|---|---|---|---|---|---|\n'+'\n'.join('| '+' | '.join([str(v['original_batch_id']),v['case_id'].replace('mmlu-pro-',''),v['gold']]+[cell(v['arms'][arm]) for arm in ('native1','native2','raw','prefix','candidate')]+[cell(v['external_q40'])])+' |' for v in table['rows'])+'\n'
    (DEST/'posterior32-table-v2.md').write_text(markdown)
    status={'status':'terminal-qualified-port-equivalent','collection_qualified':True,'port_equivalence_passed':True,'primary_sha256':PRIMARY_SHA,'independent_sha256':args.independent_sha,'relative_no_new_wrong_passed':False,'new_wrong':['mmlu-pro-01741'],'full_quality_gate_attempted':False,'full_frozen_plan_passed':None}
    (DEST/'external-status-v2.json').write_text(json.dumps(status,indent=2)+'\n')
    report=f'''# q40 posterior32仍有新增错误；同源码外置对照复现全部32条完整输出

**内置和外置q40都为29/32，01741均答C而金答案为E，输出5551 tokens后自然stop。“不新增错误”失败，full200没有启动。** 07338均恢复为H/stop/3292；此前局部八题成功不能代表整体修复。

同a050源码、同posterior32执行历史下，主分析和独立复核确认：**全部32条完整token序列、文本、finish/stop、原评分、按真实admission映射的调度，以及四rank collective几何全部相同。** 这支持本次外置prefix到内置prefix移植在该冻结实验中的可观测等价；不证明所有输入等价，也不证明quota是退化的唯一原因或某个算子故障。

## 32题完整结果

每格为“原canonical scorer提取答案 / 实际finish_reason / 输出token数”。历史四臂来自各自原full200，对应的前置批次与本轮posterior32不同；没有把历史结果当作新匹配进程。`length`仍是不完整和错误，不因文本含金答案改判。

{markdown}

两个历史native各30/32；raw27/32；旧prefix q4为29/32但07338达到8192 length。本轮两种q40均29/32且全部32题stop完成，错题为01680、01741、01802；**唯一两次native都正确却被q40新增答错的是01741。** 两种q40复现同一失败不构成质量通过；总分等于旧prefix也不代表逐题不退化。历史完整200题严格完整性门仍FAIL，当前32题的完整性不能替代它。

## 相同历史与唯一布局切换

内外置均使用clean `a05029484b2c9bc21e4e6fd705cc396d111dfaa5`、Qwen3.5-35B-A3B BF16、TP4/EP4、物理3/4/5/6、HCCL deterministic、layers_per_slice40及相同graph/backend。原200计划字节保留，仅按原顺序选择batch3/6/7/14，每批seed输出一个token后加入原七peer，整批自然完成才进入下一批。temperature0、seed42、max_tokens8192、tokenizer和评分器不改，无额外request warmup、数值observer或成功路径活请求取消。

外置对照把builtin prefix明确设off，再安装冻结模块`6431c4c0abdd869ef17e7122f681c457ad2b4d5741f86c6a0653e9fca44e02fc`；全配置比较只允许该布局旗标变化，两者保留每批一次只读snapshot RPC节奏。源码身份用于来源证明，并不把外置诊断冒充新质量候选。

两者实际各15457次serving（四批5413/1199/3293/5552），每rank D replay增量15453、P eager forward增量8；每批seed P一次及七peer P一次，peer推进40层并收齐七ACK。8个cohort中4个D0 seed各81次bypass、4个peer各81次真实P collective；四rank原prompt指纹、布局偏移、单次原collective、返回input别名、路由与3slot恢复均验证。请求/进程ID按原admission和角色规范化，不要求运行时Python对象ID相同，也未把aggregate计数当逐算子数值证据。

## 因果边界与后续

原旧q4 full200、此前后验诊断和本轮posterior32的前置历史不同，当前移植对照没有把这些历史差异消除。01741相对native的token14分歧早已存在；旧q4/currentq40目标前57tokens相同，同批peer01923在22、01984在34变化，目标在58变化。详情见保留的[CPU token定位](builtin-token-localization-v1.json.gz)。不能据这些边界按题号、金答案选择quota，也不能跳过实际完整轨迹复现直接归因某核。

后续预声明方案是在相同a050运行时，对原batch14做两个独立新进程的q4/q40自然完整八题诊断，只有quota不同；该方案不是本报告中已执行的结果。它仍需各自调度/完成证据和完整八条历史轨迹核对，不能将q4十轮P推进套用q40单轮门。**本报告不报告该未来实验、不报告吞吐或Goodput收益，也不授权失败q40候选的full200。**

## 终态、公开证据与草稿谱系

内置终态2026-10-30T13:48:19.319811+00:00；外置终态{c['finished_at']}，均exit0、自有进程为空、四卡空闲。root在外置终态及新空闲复查后才授权读取child/log。主分析和独立复核均PASS，表示采集与等价证据通过，答案相对门仍FAIL。

| 证据 | SHA256 |
|---|---|
| builtin child | `c1dab8b9c7cca79850c69b1a63d3adc368cb241b864ab596aac8c7103f88189e` |
| builtin primary | `8cf06b3396fc484baab24e2af710b74890f2b28269515c40fea1d692ef50910a` |
| builtin independent | `99094b40a6cbf63287986713e44e56db5690b1198752ac99f022327c9d6fc09d` |
| external child | `{CHILD_SHA}` |
| external controller | `{CONTROLLER_SHA}` |
| external primary | `{PRIMARY_SHA}` |
| external independent | `{args.independent_sha}` |

完整tokens/文本run、调度JSONL、日志、每批四rank快照均为无损gzip副本；主/独立、root终态门和冻结清单同时保留。[发布映射](publication-map-v2.json)绑定每份原件与存储副本SHA。builtin源码包包含原22producer和25runtime源码，external addendum仅补新增桥接文件，复用既有22项和原200输入，避免重复打包。没有大NPY、模型权重或完整旧200报告；服务器依赖未打包。不宣称原始短logits已上传，也不把本地校验说成匿名HTTPS读回。

[REPORT-v1.md](REPORT-v1.md)与v1表/status是外置运行期间形成的PENDING草稿，原字节保留；本v2才记录已终态对照。两次真实模型尝试各自保留，没有选择性重跑。独立复核保留静态审查前/后的脚本源码，最终结论只绑定通过的最终脚本和原终态数据。关联：[Issue #23](https://github.com/vLLM-HUST/vllm-ascend-MuxPD-hust/issues/23)、[此前局部八题](../muxpd-q40-full-answer-20261030/REPORT-v1.md)。
'''
    (DEST/'REPORT-v2.md').write_text(report)
    (DEST/'README.md').write_text('''**内置与外置q40在相同源码和32题执行历史下，全部完整tokens、文本、finish/stop、评分、映射调度和四rank collective几何相同。两者都29/32，01741仍新增答错（E→C，5551 tokens、stop）；full200未启动。**

移植对照的等价性通过不等于质量修复，也没有证明quota或某个算子是唯一根因。07338恢复H/3292与此前八题局部成功不能代表整体通过。

- [完整报告](REPORT-v2.md)、[32题机器可读表](posterior32-table-v2.json)
- [内置完整输出](builtin-run-v1.json.gz)、[外置完整输出](external-run-v1.json.gz)
- [外置主分析](external-analysis-v1.json.gz)、[独立复核](external-independent-v1.json.gz)
- [builtin源码包](builtin-source-capsule-v1.tar.gz)、[external增补源码包](external-source-addendum-v1.tar.gz)、[发布映射](publication-map-v2.json)
- [原PENDING草稿](REPORT-v1.md)保留，当前状态见[已终态状态](external-status-v2.json)。

无完整200题、性能或Goodput通过声明，无NPY或匿名HTTPS读回声明。
''')
    subprocess.run(['/root/workspace/.venv/bin/mdformat','--wrap','100',str(DEST/'README.md'),str(DEST/'REPORT-v2.md'),str(DEST/'posterior32-table-v2.md')],check=True)
    for name in ('README.md','REPORT-v2.md','posterior32-table-v2.md','posterior32-table-v2.json','external-status-v2.json'):
        raw=(DEST/name).read_bytes();entries[name]={'kind':'derived-final','stored_sha256':digest(raw),'stored_bytes':len(raw),'external_primary_sha256':PRIMARY_SHA,'external_independent_sha256':args.independent_sha}
    assert all(p.stat().st_size<950000 for p in DEST.iterdir())
    mapping={'schema':'muxpd-builtin-external-posterior32-publication-map-v2','status':'both-terminal-qualified-port-equivalent','builtin_relative_no_new_wrong_passed':False,'external_relative_no_new_wrong_passed':False,'new_wrong':['mmlu-pro-01741'],'full_quality_gate_attempted':False,'full_frozen_plan_passed':None,'draft_map_sha256':DRAFT_MAP_SHA,'entries':entries,'scope':'Local staging only; no GitHub/shared benchmark mutation or public-readback claim.'}
    (DEST/'publication-map-v2.json').write_text(json.dumps(mapping,indent=2)+'\n')
    print(json.dumps({'directory':str(DEST),'publication_map_sha256':digest((DEST/'publication-map-v2.json').read_bytes()),'files':len(list(DEST.iterdir())),'max_file_bytes':max(p.stat().st_size for p in DEST.iterdir()),'external_source_members':len(members),'external_source_reused_producers':sum('reused_capsule' in v for v in logical.values())},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--independent',type=Path,required=True)
    parser.add_argument('--independent-sha',required=True)
    parser.add_argument('--checker',type=Path,required=True)
    main(parser.parse_args())
