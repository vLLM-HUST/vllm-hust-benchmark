"""Explicit synthetic bridge built from terminal raw32 and real external schema.

No fixture is a candidate, device observation or producer result.
"""

import copy
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from tokenizers import Tokenizer

import analyze_external_bridge_v1 as entry
import external_bridge_analysis_v1 as bridge
import external_bridge_control_v1 as control
import external_treatment_v1 as treatment

BUNDLE = Path(__file__).parent
BUILTIN = Path(
    "/root/workspace/muxpd-runtime-quality-candidate-v2-20261030/runs-v1/prefix-q40-runtime-posterior32-v1-01"
)
EXTERNAL = Path(
    "/root/workspace/muxpd-q40-full-answer-batch7-v2-20261030/runs-v1/prefix-q40-full-answer-batch7-v2-01"
)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def owned(stage):
    return {
        "builtin_layout": None,
        "external_present": stage != "absent",
        "external_uninstalled": None if stage == "absent" else stage == "restored",
        "external_hooks_owned": stage == "installed",
        "foreign_observers": dict.fromkeys(
            (
                "_graph_tap_observer",
                "_mixed_ordered_observer",
                "_muxpd_layer_capture_v3",
            ),
            False,
        ),
    }


@pytest.fixture(scope="module")
def fixture(tmp_path_factory):
    bridge.legacy.terminal_controller(BUILTIN)
    bridge.legacy.terminal_controller(EXTERNAL)
    root = tmp_path_factory.mktemp("explicit-synthetic-external32")
    bundle = root / "bundle"
    directory = root / "runs" / treatment.LABEL
    results = directory / "results"
    bundle.mkdir()
    results.mkdir(parents=True)
    for name in control.FILES:
        path = bundle / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(BUNDLE / name, path)
    raw = bridge.read(BUILTIN / "results/run.json")
    external = bridge.read(EXTERNAL / "results/run.json")
    report = copy.deepcopy(raw)
    plan, cases, _ = bridge.original.load_frozen(bundle / "frozen-v2")
    batches = bridge.checks.select_batches(plan, "posterior32")
    _refs, proof = bridge.verify_references(bundle)
    source = report.pop("candidate_identity")
    for name in list(report):
        if name.startswith("prefix_"):
            del report[name]
    report.update(
        schema="muxpd-q40-external-posterior32-run-v1",
        profile="external-q40-posterior32-bridge",
        source_reference_identity=source,
        builtin_layout_mode="off",
        external_treatment=treatment.treatment_receipt(bundle),
        layout_module_sha256=treatment.LAYOUT_SHA,
        external_batch_snapshots=[],
        external_layout_restored=True,
    )
    report["process_id"] += 1000000
    report["producer_sha256"] = bridge.sha(bundle / "external_bridge_run_v1.py")
    for field in ("base_engine_args", "engine_args"):
        report[field] = treatment.apply_external_treatment(report[field])
    cohorts = bridge.read(BUILTIN / "results/prefix-batch-14.json")["rows"]
    template = external["layout_final"]

    def snapshots(count):
        rows = copy.deepcopy(template)
        for rank, row in enumerate(rows):
            row["cohorts"] = copy.deepcopy(cohorts[rank]["recent_cohorts"][:count])
            row["treated_cohorts"] = count // 2
            row["bridge_ownership"] = owned("installed")
        return rows

    report["external_layout_installation"] = snapshots(0)
    report["external_layout_final"] = snapshots(8)
    for field, stage in [("worker_before", "absent"), ("worker_after", "installed")]:
        for rank, row in enumerate(report[field]):
            row["builtin_layout"] = None
            row["runtime"]["policy"][bridge.checks.POLICY_KEY] = "off"
            row["foreign_diagnostic_state"]["_muxpd_prefill_collective_layout_v1"] = (
                stage == "installed"
            )
            row["bridge_ownership"] = owned(stage)
            row["external_layout"] = (
                None
                if stage == "absent"
                else copy.deepcopy(report["external_layout_final"][rank])
            )
    report["external_layout_uninstall"] = copy.deepcopy(external["layout_uninstall"])
    for row in report["external_layout_uninstall"]:
        row["bridge_ownership"] = owned("restored")
    tracker = []
    receipts = [
        json.loads(line)
        for line in (BUILTIN / "results/scheduler-receipts.jsonl")
        .read_text()
        .splitlines()
    ]
    for index, batch in enumerate(batches, 1):
        included = {b["batch_id"] for b in batches[:index]}
        history = [r for r in receipts if r["batch_id"] in included]
        (results / "scheduler-receipts.jsonl").write_text(
            "".join(json.dumps(r) + "\n" for r in history)
        )
        original_admissions = report["admissions"]
        report["admissions"] = original_admissions[: 2 * index]
        rows = snapshots(2 * index)
        llm = SimpleNamespace(
            collective_rpc=lambda *args, snapshot=rows, **kwargs: copy.deepcopy(
                snapshot
            )
        )
        treatment.save_batch_snapshot(llm, tracker, report, results, batch, cases)
        report["admissions"] = original_admissions
    report["external_layout_validation"] = treatment.validate_final_snapshot(
        report["external_layout_final"], tracker, report, results
    )
    report["external_layout_admission_validation"] = (
        treatment.validate_layout_admissions(
            report["external_layout_final"],
            report["admissions"],
            results / "scheduler-receipts.jsonl",
            batches,
            cases,
        )
    )
    report["scheduler_receipts_sha256"] = bridge.sha(
        results / "scheduler-receipts.jsonl"
    )
    controller = copy.deepcopy(bridge.read(BUILTIN / "controller.json"))
    start = datetime.fromisoformat(controller["finished_at"]) + timedelta(seconds=2)
    controller.update(
        schema="muxpd-q40-external-posterior32-controller-v1",
        profile="external-q40-posterior32-bridge",
        label=treatment.LABEL,
        destination=str(directory),
        reference_qualification=proof,
        external_treatment=treatment.treatment_receipt(bundle),
        source_reference_identity_sha256=treatment.IDENTITY_SHA,
        started_at=start.isoformat(),
        finished_at=(start + timedelta(seconds=2)).isoformat(),
        launch_engine_args=report["base_engine_args"],
    )
    controller["controller_pid"] += 1000000
    controller["process_group"] += 1000000
    report["started_at"] = start.isoformat()
    report["finished_at"] = controller["finished_at"]
    files = {name: bridge.sha(bundle / name) for name in control.FILES}
    freeze = {
        "status": "frozen",
        "source_reference_identity_sha256": treatment.IDENTITY_SHA,
        "declared_attempts": {
            "posterior32": {"directory": str(directory), "label": treatment.LABEL}
        },
        "files": files,
        "fixture_only": True,
    }
    save(bundle / "freeze-manifest-v1.json", freeze)
    controller.update(
        files=files,
        freeze_manifest_sha256=bridge.sha(bundle / "freeze-manifest-v1.json"),
        bundle_frozen=True,
    )
    shutil.copytree(bundle, directory / "producer")
    for name in ("npu-before.txt", "npu-after.txt"):
        shutil.copyfile(BUILTIN / name, directory / name)
    (directory / "process.log").write_text(
        "Explicit CPU synthetic fixture, no model executed.\n"
    )
    save(results / "run.json", report)
    controller["terminal_assessment"] = control.terminal_assessment(
        directory, controller
    )
    save(directory / "controller.json", controller)
    return bundle, directory


def test_real_serializer_to_terminal_analyzer(fixture):
    bundle, directory = fixture
    result = entry.analyze(directory, bundle, directory / "analysis-equal.json")
    assert result["errors"] == []
    assert result["passed"] is True and result["runtime_collection_qualified"] is True
    assert result["port_equivalence_passed"] is True
    assert result["comparison"]["answers"][
        "external_new_wrong_on_both_native_correct"
    ] == ["mmlu-pro-01741"]


def test_valid_token_inequality_is_not_invalid_collection(fixture):
    bundle, directory = fixture
    path = directory / "results/run.json"
    report = bridge.read(path)
    row = next(r for r in report["outputs"] if r["case_id"] == "mmlu-pro-01741")
    row["token_ids"][13] += 1
    tokenizer = Tokenizer.from_file(report["tokenizer_files"]["tokenizer.json"]["path"])
    row["text"] = tokenizer.decode(row["token_ids"], skip_special_tokens=True)
    save(path, report)
    controller = bridge.read(directory / "controller.json")
    controller["terminal_assessment"] = control.terminal_assessment(
        directory, controller
    )
    save(directory / "controller.json", controller)
    result = entry.analyze(directory, bundle, directory / "analysis-different.json")
    assert result["errors"] == []
    assert result["passed"] is True and result["runtime_collection_qualified"] is True
    assert result["port_equivalence_passed"] is False
    target = next(
        r
        for r in result["comparison"]["complete_outputs"]["rows"]
        if r["case_id"] == "mmlu-pro-01741"
    )
    assert target["first_token_difference"]["position_one_based"] == 14
