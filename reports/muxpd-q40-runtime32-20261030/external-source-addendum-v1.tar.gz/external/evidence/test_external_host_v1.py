import copy
import importlib
import json
from pathlib import Path

import pytest

BUNDLE = Path(__file__).resolve().parent


def treatment():
    return importlib.import_module("external_treatment_v1")


def builtin_config():
    import candidate_checks_v1 as checks

    identity = json.loads((BUNDLE / "source-reference-identity-v1.json").read_text())
    history = checks.original_manifest()["historical_runs"][
        "raw-quality-v2-hccl-true-01"
    ]["engine_args"]
    return checks.apply_policy_changes(history, identity)


def test_only_prefix_flag_changes_and_input_unchanged():
    before = builtin_config()
    frozen = copy.deepcopy(before)
    after = treatment().apply_external_treatment(before)
    assert before == frozen
    assert (
        after["batch_admission_policy_config"]["experimental_prefill_collective_layout"]
        == "off"
    )
    after["batch_admission_policy_config"]["experimental_prefill_collective_layout"] = (
        "prefix"
    )
    assert after == frozen


@pytest.mark.parametrize(
    "key,value",
    [
        ("layers_per_slice", 4),
        ("layers_per_slice", 40.0),
        ("require_hccl_deterministic", False),
        ("experimental_prefill_collective_layout", "off"),
    ],
)
def test_treatment_rejects_wrong_reference_policy(key, value):
    config = builtin_config()
    config["batch_admission_policy_config"][key] = value
    with pytest.raises(ValueError):
        treatment().apply_external_treatment(config)


def test_no_full_scope_or_reordered_original32():
    from score_quality import load_frozen

    plan, _, _ = load_frozen(BUNDLE / "frozen-v2")
    assert [b["batch_id"] for b in treatment().select_batches(plan, "posterior32")] == [
        3,
        6,
        7,
        14,
    ]
    with pytest.raises(ValueError):
        treatment().select_batches(plan, "full")
    altered = copy.deepcopy(plan)
    altered["batches"][3], altered["batches"][6] = (
        altered["batches"][6],
        altered["batches"][3],
    )
    with pytest.raises(ValueError):
        treatment().select_batches(altered, "posterior32")


def test_frozen_external_module_and_source_reference_identity():
    import candidate_checks_v1 as checks

    t = treatment()
    receipt = t.treatment_receipt()
    assert receipt["external_module_sha256"] == checks.file_sha(
        BUNDLE / "prefill_collective_layout_v1.py"
    )
    assert receipt["source_reference_identity_sha256"] == checks.file_sha(
        BUNDLE / "source-reference-identity-v1.json"
    )
    assert receipt["quality_candidate"] is False


def test_new_driver_natural_loops_are_original_ast():
    import ast

    source = (BUNDLE / "candidate_run_v1.py").read_text()
    new = (BUNDLE / "external_bridge_run_v1.py").read_text()
    old_run = next(
        n
        for n in ast.parse(source).body
        if isinstance(n, ast.FunctionDef) and n.name == "run"
    )
    new_run = next(
        n
        for n in ast.parse(new).body
        if isinstance(n, ast.FunctionDef) and n.name == "run"
    )
    loops = lambda node: [
        ast.dump(n, include_attributes=False)
        for n in ast.walk(node)
        if isinstance(n, ast.While)
    ]
    assert loops(old_run) == loops(new_run)
    batch = lambda node: next(
        n
        for n in ast.walk(node)
        if isinstance(n, ast.For)
        and isinstance(n.target, ast.Name)
        and n.target.id == "batch"
    )
    assert ast.dump(batch(old_run), include_attributes=False) == ast.dump(
        batch(new_run), include_attributes=False
    )


def test_ownership_rejects_builtin_and_unrestored_slots():
    t = treatment()
    value = {
        "builtin_layout": None,
        "external_present": True,
        "external_uninstalled": False,
        "external_hooks_owned": True,
        "foreign_observers": dict.fromkeys(
            (
                "_graph_tap_observer",
                "_mixed_ordered_observer",
                "_muxpd_layer_capture_v3",
            ),
            False,
        ),
    }
    t.validate_ownership(value, "installed")
    with pytest.raises(ValueError):
        t.validate_ownership(value, "restored")
    value["builtin_layout"] = {}
    with pytest.raises(ValueError):
        t.validate_ownership(value, "installed")


def test_controller_does_not_read_nonterminal_child(tmp_path, monkeypatch):
    import external_bridge_control_v1 as controller

    def forbidden(*args, **kwargs):
        raise AssertionError("Nonterminal child read")

    monkeypatch.setattr(Path, "read_text", forbidden)
    with pytest.raises(ValueError, match="terminal proof"):
        controller.terminal_assessment(tmp_path, {"terminal_process_proven": False})


def test_actual_clean_source_prepare_and_exact_builtin_config():
    from external_bridge_run_v1 import prepare

    _, _, batches, config, manifest, identity = prepare(
        "posterior32",
        Path("/root/workspace/muxpd-prefix-q40-runtime"),
        BUNDLE / "source-reference-identity-v1.json",
    )
    assert [b["batch_id"] for b in batches] == [3, 6, 7, 14]
    assert (
        identity["sources"]["vllm_muxpd"]["commit"]
        == manifest["external_treatment"]["source_commit"]
    )
    assert config["batch_admission_policy_config"]["layers_per_slice"] == 40
    assert config["batch_admission_policy_config"]["require_hccl_deterministic"] is True


@pytest.fixture
def actual_external_receipts():
    from score_quality import load_frozen

    old = Path(
        "/root/workspace/muxpd-q40-full-answer-batch7-v2-20261030/runs-v1/prefix-q40-full-answer-batch7-v2-01/results"
    )
    report = json.loads((old / "run.json").read_text())
    assert (
        report["passed"] and report["collection_complete"] and report["layout_restored"]
    )
    rows = copy.deepcopy(report["layout_final"])
    for row in rows:
        row["bridge_ownership"] = {
            "builtin_layout": None,
            "external_present": True,
            "external_uninstalled": False,
            "external_hooks_owned": True,
            "foreign_observers": dict.fromkeys(
                (
                    "_graph_tap_observer",
                    "_mixed_ordered_observer",
                    "_muxpd_layer_capture_v3",
                ),
                False,
            ),
        }
    plan, cases, _ = load_frozen(BUNDLE / "frozen-v2")
    return old, report, rows, plan["batches"][7], cases


def test_actual_external_batch_serializer_one_rpc_and_validation(
    tmp_path, actual_external_receipts
):
    old, original, rows, batch, cases = actual_external_receipts
    (tmp_path / "scheduler-receipts.jsonl").write_bytes(
        (old / "scheduler-receipts.jsonl").read_bytes()
    )
    report = {"external_batch_snapshots": [], "admissions": original["admissions"]}
    calls = []

    class LLM:
        def collective_rpc(self, fn, timeout):
            assert fn is treatment().external_snapshot and timeout == 60
            calls.append(fn)
            return rows

    tracker = []
    treatment().save_batch_snapshot(LLM(), tracker, report, tmp_path, batch, cases)
    assert len(calls) == 1 and tracker == [batch]
    assert report["external_batch_snapshots"][0]["validation"]["completed_cohorts"] == 2
    assert (
        json.loads((tmp_path / "external-prefix-batch-07.json").read_text())["rows"]
        == rows
    )


def test_invalid_actual_external_receipt_persisted_before_rejection(
    tmp_path, actual_external_receipts
):
    old, original, rows, batch, cases = actual_external_receipts
    (tmp_path / "scheduler-receipts.jsonl").write_bytes(
        (old / "scheduler-receipts.jsonl").read_bytes()
    )
    rows[0]["cohorts"][1]["admission_p_counts"][
        next(iter(rows[0]["cohorts"][1]["admission_p_counts"]))
    ] += 1

    class LLM:
        def collective_rpc(self, *args, **kwargs):
            return rows

    report = {"external_batch_snapshots": [], "admissions": original["admissions"]}
    with pytest.raises((ValueError, RuntimeError)):
        treatment().save_batch_snapshot(LLM(), [], report, tmp_path, batch, cases)
    assert (
        json.loads((tmp_path / "external-prefix-batch-07.json").read_text())["rows"]
        == rows
    )
    assert (
        json.loads((tmp_path / "run.json").read_text())["external_batch_snapshots"][0][
            "validation"
        ]
        is None
    )


@pytest.mark.parametrize(
    "key",
    ["VLLM_VERSION", "VLLM_WORKER_MULTIPROC_METHOD", "VLLM_PLUGINS", "LD_LIBRARY_PATH"],
)
def test_environment_missing_original_key_rejected(key):
    import candidate_checks_v1 as checks

    history = checks.original_manifest()["historical_runs"][
        "raw-quality-v2-hccl-true-01"
    ]["runtime_environment"]
    identity = json.loads((BUNDLE / "source-reference-identity-v1.json").read_text())
    env = copy.deepcopy(history["environment"])
    env.pop(key)
    with pytest.raises(ValueError):
        checks.validate_launch_environment(env, history, identity)


def test_controller_rejects_alternate_label_before_source_reads(tmp_path):
    from types import SimpleNamespace

    import external_bridge_control_v1 as controller

    with pytest.raises(ValueError):
        controller.preview(SimpleNamespace(label="retry-02"))


def test_real_sourced_child_environment_is_exact_and_unmutated():
    import subprocess

    command = """source /root/workspace/runtime/env.sh
/root/workspace/.venv/bin/python -B - <<'INNER'
import json
from pathlib import Path
import external_bridge_control_v1 as c
from candidate_checks_v1 import original_manifest, validate_launch_environment
identity=json.loads(Path('source-reference-identity-v1.json').read_text())
env=c.environment(Path('/root/workspace/muxpd-prefix-q40-runtime'),Path('/tmp/external-bridge-cpu-only-no-launch'),identity)
before=dict(env)
history=original_manifest()['historical_runs']['raw-quality-v2-hccl-true-01']['runtime_environment']
proof=validate_launch_environment(env,history,identity)
assert env==before
print(json.dumps(proof))
INNER"""
    result = subprocess.run(
        ["bash", "-c", command], cwd=BUNDLE, capture_output=True, text=True, check=False
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert json.loads(result.stdout.splitlines()[-1])["passed"]


def test_source_and_collector_reuse_remains_exact():
    import ast
    import hashlib

    import external_bridge_control_v1 as c

    old = Path("/root/workspace/muxpd-runtime-quality-candidate-v2-20261030")
    node = next(
        n
        for n in ast.parse((old / "candidate_control_v1.py").read_text()).body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "FILES" for t in n.targets)
    )
    names = ast.literal_eval(node.value)
    assert len(c.FILES) == len(set(c.FILES)) == 31
    assert set(names) <= set(c.FILES)
    for name in names:
        assert (
            hashlib.sha256((BUNDLE / name).read_bytes()).digest()
            == hashlib.sha256((old / name).read_bytes()).digest()
        ), name


@pytest.mark.parametrize(
    "failure_stage", ["partial-install", "partial-uninstall", "missing-rank"]
)
def test_actual_finalizer_cleans_drained_workers_despite_partial_ownership(
    failure_stage, actual_external_receipts
):
    # Execute the actual run() finalizer block in isolation: no constructor/model.
    # Deliberately inconsistent ownership must remain an error but cannot suppress
    # cleanup once original scheduler/worker emptiness checks prove safe drain.
    import ast
    from types import SimpleNamespace

    import external_bridge_run_v1 as driver

    _, original, _, _, _ = actual_external_receipts
    report = {
        "collection_complete": False,
        "external_layout_restored": False,
        "errors": [],
        "shutdown_returned": False,
    }
    calls = []

    class LLM:
        def collective_rpc(self, fn, **kwargs):
            calls.append((fn, kwargs))
            if fn is driver.worker_snapshot:
                return copy.deepcopy(
                    original["worker_after"][:3]
                    if failure_stage == "missing-rank"
                    else original["worker_after"]
                )
            assert fn is treatment().uninstall_external and kwargs == {
                "args": (True,),
                "timeout": 60,
            }
            return [
                dict(row, allow_incomplete=True) for row in original["layout_uninstall"]
            ]

    llm = LLM()
    llm.llm_engine = SimpleNamespace(
        engine_core=SimpleNamespace(shutdown=lambda: calls.append(("shutdown", {})))
    )

    def bad_ownership(*args, **kwargs):
        raise ValueError(failure_stage)

    namespace = {
        **vars(driver),
        "llm": llm,
        "report": report,
        "layout_attempted": True,
        "baseline": original["idle_baseline"],
        "manifest": {"candidate": {}},
        "abort_and_drain": lambda *a: {"aborted_internal_ids": []},
        "scheduler_snapshot": lambda *a: copy.deepcopy(original["final_state"]),
        "validate_external_workers": bad_ownership,
    }
    run = next(
        n
        for n in ast.parse((BUNDLE / "external_bridge_run_v1.py").read_text()).body
        if isinstance(n, ast.FunctionDef) and n.name == "run"
    )
    finalizer = next(n for n in run.body if isinstance(n, ast.Try)).finalbody
    block = next(
        n
        for n in finalizer
        if isinstance(n, ast.If)
        and isinstance(n.test, ast.Compare)
        and isinstance(n.test.left, ast.Name)
        and n.test.left.id == "llm"
    )
    module = ast.fix_missing_locations(ast.Module(body=[block], type_ignores=[]))
    exec(compile(module, "actual-finalizer", "exec"), namespace)  # noqa: S102 -- trusted local production AST, CPU fake engine only
    if failure_stage == "missing-rank":
        assert not any(fn is treatment().uninstall_external for fn, _ in calls)
        assert "four unique TP ranks" in report["errors"][0]
        assert report["shutdown_returned"] is True
        return
    assert any(fn is treatment().uninstall_external for fn, _ in calls)
    assert report["external_layout_failure_cleanup_restored"] is True
    assert failure_stage in report["errors"][0]
    assert (
        report["collection_complete"] is False
        and report["external_layout_restored"] is False
    )
    assert report["shutdown_returned"] is True
