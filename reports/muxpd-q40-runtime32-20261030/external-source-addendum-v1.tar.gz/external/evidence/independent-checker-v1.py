"""Independent, terminal-first external/builtin comparison. Never runs a model.

Only the frozen original scorer and external layout validator are imported.
Do not execute until root explicitly declares the current attempt terminal.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
import subprocess
from collections import Counter
from datetime import datetime
from pathlib import Path

IDENTITY_SHA = "8d04890973c369a5412e80cc08c6cb55ef405e9360bd38e2bfafa9b5d65fe4fe"
LAYOUT_SHA = "6431c4c0abdd869ef17e7122f681c457ad2b4d5741f86c6a0653e9fca44e02fc"
SCORER_SHA = "157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd"
LABEL = "external-q40-posterior32-bridge-v1-01"
PHYSICAL = ["3", "4", "5", "6"]
BATCHES = [3, 6, 7, 14]


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def terminal(directory):
    # Controller is the only attempted-run artifact opened before this gate.
    row = read(directory / "controller.json")
    require(
        row.get("terminal_process_proven") is True
        and row.get("exit_code") == 0
        and row.get("owned_members_after_cleanup") == []
        and row.get("owned_members_before_cleanup") == []
        and not row.get("cleanup_required", False)
        and not row.get("forced_termination", False)
        and not row.get("timeout", False)
        and not row.get("errors")
        and row.get("passed") is True,
        "Both controllers must prove clean terminal process state before child/log reads",
    )
    require(
        row.get("expected_physical") == PHYSICAL
        and row.get("idle_physical_before") == PHYSICAL
        and row.get("idle_physical_after") == PHYSICAL,
        "Four-device terminal idle receipts differ",
    )
    return row


def load_original(path, name, expected):
    require(sha(path) == expected, f"Original module changed: {path.name}")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def four(rows):
    require(
        len(rows) == 4 and {r["rank"] for r in rows} == set(range(4)),
        "Four unique rank receipts required",
    )
    return {r["rank"]: r for r in rows}


def bind_admissions(report, batches, cases):
    require(len(report["admissions"]) == 8, "Original8 seed/peer admissions required")
    mapping = {}
    normalized = []
    by_case = {c["case_id"]: c for c in cases}
    for index, row in enumerate(report["admissions"]):
        batch = batches[index // 2]
        members = batch["case_ids"][:1] if index % 2 == 0 else batch["case_ids"][1:]
        require(
            row["batch_id"] == batch["batch_id"]
            and row["stage"] == ("seed" if index % 2 == 0 else "peers")
            and [b["case_id"] for b in row["bindings"]] == members,
            "Admission case identity/order differs",
        )
        if index % 2:
            require(
                row["seed_output_tokens"] == 1 and row["seed_still_live"] is True,
                "Peer release must follow exact live first seed token",
            )
        for binding in row["bindings"]:
            for kind in ("internal", "external"):
                rid = binding[kind]
                require(
                    rid not in mapping and binding["case_id"] in by_case,
                    "Duplicate/unknown request binding",
                )
                mapping[rid] = binding["case_id"]
        normalized.append(
            {k: copy.deepcopy(v) for k, v in row.items() if k != "bindings"}
            | {"bindings": [{"case_id": b["case_id"]} for b in row["bindings"]]}
        )
    return mapping, normalized


def mapped(mapping, value):
    require(
        value in mapping, "Unknown request ID cannot be dropped during normalization"
    )
    return mapping[value]


def schedule(report, results, mapping):
    path = results / "scheduler-receipts.jsonl"
    require(
        sha(path) == report["scheduler_receipts_sha256"],
        "Scheduler file digest differs",
    )
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    normalized = []
    new_prefills = []
    completed = []
    decode_retirements = Counter()
    pairs = {}
    for row in rows:
        result = copy.deepcopy(row)
        event = row["event"]
        require(
            event in ("schedule", "retirement"), "Unexpected scheduler event schema"
        )
        key = (row["batch_id"], row["global_step"])
        require(
            row["batch_id"] in BATCHES and type(row["global_step"]) is int,
            "Unexpected schedule scope",
        )
        slots = pairs.setdefault(key, {})
        require(event not in slots, "Duplicate scheduler event within one engine turn")
        slots[event] = row
        if event == "schedule":
            require(not row["preempted_req_ids"], "Unexpected preemption")
            for name in ("scheduled_tokens", "phases_before"):
                result[name] = {mapped(mapping, rid): v for rid, v in row[name].items()}
            for name in ("pending_prefill_ids", "new_prefill_ids", "preempted_req_ids"):
                result[name] = [mapped(mapping, rid) for rid in row[name]]
            if row["new_prefill_ids"]:
                require(
                    row["prefill_layers_before"] == 0,
                    "P cohort did not start at layer0",
                )
                new_prefills.append(
                    (key, [mapped(mapping, rid) for rid in row["new_prefill_ids"]])
                )
        else:
            require(not row["cancelled_prefill_ids"], "Unexpected P cancellation")
            for name in (
                "decode_retired_ids",
                "completed_prefill_ids",
                "cancelled_prefill_ids",
            ):
                result[name] = [mapped(mapping, rid) for rid in row[name]]
            decode_retirements.update(result["decode_retired_ids"])
            if row["completed_prefill_ids"]:
                require(
                    row["prefill_layers_completed"] == 40
                    and row["actual_prefill_progress"] is True,
                    "P must complete all40 actual layers",
                )
                completed.append((key, result["completed_prefill_ids"]))
        normalized.append(result)
    require(
        len(new_prefills) == len(completed) == 8, "Expected8 actual P advancements/ACKs"
    )
    for (key, pending), (other, done) in zip(new_prefills, completed, strict=True):
        require(
            key == other and set(pending) == set(done),
            "P advance/retirement ACK membership differs",
        )
    for key, events in pairs.items():
        require(
            set(events) == {"schedule", "retirement"},
            "Missing actual schedule/retirement pair",
        )
        s, r = events["schedule"], events["retirement"]
        require(
            set(r["decode_retired_ids"])
            == {
                rid
                for rid, phase in s["phases_before"].items()
                if phase == "D" and rid in s["scheduled_tokens"]
            },
            "Decode retirement differs from actual D schedule",
        )
    return normalized, {
        "events": len(rows),
        "turns": len(pairs),
        "prefill_cohorts": len(new_prefills),
        "decode_retirements": dict(decode_retirements),
    }


def workers_and_graph(report, schedule_rows):
    before, after = four(report["worker_before"]), four(report["worker_after"])
    decode_turns = sum(
        row["event"] == "schedule"
        and any(
            phase == "D" and rid in row["scheduled_tokens"]
            for rid, phase in row["phases_before"].items()
        )
        for row in schedule_rows
    )
    policy = report["engine_args"]["batch_admission_policy_config"]
    deltas = []
    for rank in range(4):
        for row in (before[rank], after[rank]):
            require(
                not any(row["requests"].values())
                and not any(row["input_num_reqs"].values())
                and not any(row["input_req_id_to_index"].values())
                and not any(
                    rid is not None
                    for rows in row["input_rows"].values()
                    for rid in rows
                )
                and not row["prefill_task_present"]
                and row["prefill_cohort_id"] is None
                and not row["awaiting_sample"]
                and not row["pending_lanes"],
                "Worker request/iteration state not empty",
            )
            require(
                canonical(row["runtime"]["policy"]) == canonical(policy),
                "Actual full worker policy differs",
            )
            graph = row["decode_graph_snapshot"]
            require(
                graph["captured"]
                and not graph["failed"]
                and not graph["closed"]
                and graph["enabled"]
                and not graph["compile_full_prefill"],
                "Original D graph/P eager mode differs",
            )
        first, last = (
            before[rank]["decode_graph_snapshot"],
            after[rank]["decode_graph_snapshot"],
        )
        require(set(first) == set(last), "Graph snapshot fields changed")
        for key in first:
            if key not in ("decode_replay_calls", "prefill_forced_eager_calls"):
                require(
                    first[key] == last[key],
                    f"Graph state/capture/fallback/failure field changed: {key}",
                )
        require(
            first["captured_graph_entries"] > 0, "No actual captured D graph entries"
        )
        for worker in (before[rank], after[rank]):
            runtime = worker["runtime"]
            require(
                runtime["enable_npugraph_ex"] is False
                and runtime["enable_static_kernel"] is False
                and runtime["cudagraph_mode"] == "FULL_DECODE_ONLY"
                and runtime["cudagraph_capture_sizes"] == [1, 2, 4, 8]
                and runtime["async_scheduling"] is False
                and runtime["enable_chunked_prefill"] is False
                and runtime["tensor_parallel_size"] == 4
                and runtime["enable_expert_parallel"] is True,
                "Actual worker graph/backend configuration changed",
            )
        require(
            last["decode_replay_calls"] - first["decode_replay_calls"] == decode_turns
            and last["prefill_forced_eager_calls"] - first["prefill_forced_eager_calls"]
            == 8,
            "Actual graph/P forwards differ from schedule",
        )
        deltas.append(
            {
                "rank": rank,
                "decode_replay_calls": last["decode_replay_calls"]
                - first["decode_replay_calls"],
                "prefill_eager_calls": 8,
            }
        )
    state = report["final_state"]
    require(
        not any(
            state[k]
            for k in (
                "request_ids",
                "running_ids",
                "waiting_ids",
                "skipped_waiting_ids",
                "finished_req_ids",
                "client_request_ids",
                "cohort_present",
                "held_prefill_ids",
            )
        )
        and state["free_blocks"] == report["idle_baseline"]["free_blocks"],
        "Scheduler/KV state not fully returned",
    )
    return deltas


def own(value, stage):
    require(
        value["builtin_layout"] is None, "Builtin layout must be absent in external arm"
    )
    require(
        set(value["foreign_observers"])
        == {"_graph_tap_observer", "_mixed_ordered_observer", "_muxpd_layer_capture_v3"}
        and not any(value["foreign_observers"].values()),
        "Foreign observer present",
    )
    target = {
        "installed": (True, False, True),
        "restored": (True, True, False),
        "absent": (False, None, False),
    }[stage]
    require(
        (
            value["external_present"],
            value["external_uninstalled"],
            value["external_hooks_owned"],
        )
        == target,
        "External ownership/restoration differs",
    )


def normalized_cohorts(rows, mapping, cases):
    by_case = {c["case_id"]: c for c in cases}
    result = []
    for ordinal, raw in enumerate(rows, 1):
        c = copy.deepcopy(raw)
        require(
            c["cohort_id"] == ordinal
            and c["mode"] == "prefix"
            and c["status"] == "closed"
            and c["clear_count"] == 1
            and c["error"] is None,
            "Cohort order/retirement differs",
        )
        for name in ("admission_p_counts", "admission_d_counts"):
            c[name] = {mapped(mapping, rid): n for rid, n in c[name].items()}
        require(
            c["p_rows"] == sum(c["admission_p_counts"].values())
            and c["d_rows"] == sum(c["admission_d_counts"].values()),
            "Collective row geometry differs from admission",
        )
        batch = c["batch"]
        batch["req_ids"] = [mapped(mapping, rid) for rid in batch["req_ids"]]
        starts = [0]
        require(
            batch["order_matches_admission_p_map"] is True
            and batch["packed_tokens_and_positions_verified"] is True,
            "Packed P order/IDs not verified",
        )
        require(
            batch["req_ids"] == list(c["admission_p_counts"]), "P map/order differs"
        )
        for row, case_id in zip(batch["rows"], batch["req_ids"], strict=True):
            require(
                mapped(mapping, row["request_id"]) == case_id,
                "P row case mapping differs",
            )
            row["request_id"] = case_id
            prompt = by_case[case_id]["prompt_token_ids"]
            # Frozen layout prompt digest uses compact JSON, no token reinterpretation.
            require(
                row["prompt_sha256"]
                == hashlib.sha256(
                    json.dumps(prompt, separators=(",", ":")).encode()
                ).hexdigest()
                and row["prompt_tokens"] == len(prompt)
                and row["computed_tokens"] == 0
                and row["output_tokens"] == 0
                and row["token_start"] == starts[-1]
                and row["token_end"] == starts[-1] + len(prompt),
                "P prompt/span/state differs",
            )
            starts.append(starts[-1] + len(prompt))
        require(batch["query_start_loc"] == starts, "P packed offsets differ")
        if c["d_rows"] == 0:
            require(
                not c["calls"] and c["zero_d_bypass_calls"] == 81,
                "Seed must retain81 zero-D original collectives",
            )
        else:
            require(
                c["d_rows"] == 1
                and len(c["calls"]) == 81
                and c["zero_d_bypass_calls"] == 0,
                "Peer must retain81 prefixed original collectives",
            )
        for index, call in enumerate(c["calls"], 1):
            require(
                call["ordinal"] == index
                and call["mode"] == "prefix"
                and call["input_shape"] == [c["p_rows"], 2048]
                and call["collective_payload_shape"]
                == [c["p_rows"] + c["d_rows"], 2048]
                and call["prefix_rows"]
                == call["dummy_rows"]
                == call["copyback_offset"]
                == c["d_rows"]
                and call["suffix_rows"] == 0
                and call["dtype"] == "torch.bfloat16"
                and call["existing_collective_calls"] == 1
                and call["return_original_input"] is True
                and call["status"] == "complete"
                and call["error"] is None,
                "Actual collective geometry/copyback differs",
            )
            before, after = call["route_before"], call["route_after"]
            require(
                {k: v for k, v in before.items() if k != "router_calls"}
                == {k: v for k, v in after.items() if k != "router_calls"},
                "Route changed during original collective",
            )
            require(
                before["active_lane"] == "prefill"
                and before["ranks"] == [0, 1, 2, 3]
                and before["selected_coordinator_name"].startswith("tp:muxpd_prefill:")
                and before["selected_device_group_python_id"]
                != before["device_group_python_id"],
                "Actual isolated prefill route invalid",
            )
            require(
                call["router_call_delta"] == {"caller": 0, "decode": 0, "prefill": 1}
                and {
                    k: after["router_calls"][k] - before["router_calls"][k]
                    for k in ("caller", "decode", "prefill")
                }
                == call["router_call_delta"],
                "Actual router call delta differs",
            )
            # Process/object IDs differ naturally; their intra-call identity was
            # validated above. Device/rank identity is validated by caller.
            for key in ("device", "route_before", "route_after"):
                del call[key]
        result.append(c)
    return result


def geometry(report, results, role, mapping, cases, layout):
    entries = (
        report["external_batch_snapshots"]
        if role == "external"
        else report["prefix_batches"]
    )
    require([r["batch_id"] for r in entries] == BATCHES, "Snapshot batch order differs")
    prior = {}
    outputs = []
    for number, entry in enumerate(entries, 1):
        path = Path(entry["path"])
        require(
            path.resolve().parent == results.resolve() and sha(path) == entry["sha256"],
            "Snapshot path/hash differs",
        )
        saved = read(path)
        require(
            saved["batch_id"] == entry["batch_id"], "Snapshot batch identity differs"
        )
        rows = four(saved["rows"])
        if role == "external":
            layout.validate_receipts(
                list(rows.values()),
                LAYOUT_SHA,
                mode="prefix",
                expected_treated_cohorts=number,
                expected_completed=2 * number,
            )
        normalized = []
        for rank, row in rows.items():
            if role == "external":
                own(row["bridge_ownership"], "installed")
                cohorts = row["cohorts"]
            else:
                require(
                    row["schema"] == "muxpd-prefill-collective-prefix-v1"
                    and row["mode"] == "prefix"
                    and row["installed_hook_count"] == 3
                    and row["all_hooks_intact"] is True
                    and row["active_cohort"] is None
                    and not row["errors"]
                    and not row["uninstalled"]
                    and row["stats"]["admitted"]
                    == row["stats"]["closed"]
                    == 2 * number,
                    "Builtin snapshot schema/state differs",
                )
                cohorts = row["recent_cohorts"]
            require(
                len(cohorts) == 2 * number and cohorts[:-2] == prior.get(rank, []),
                "Cumulative cohort history was rewritten",
            )
            for cohort in cohorts:
                for call in cohort["calls"]:
                    require(
                        call["device"] == f"npu:{rank}"
                        and call["route_before"]["rank_in_group"] == rank
                        and call["route_after"]["rank_in_group"] == rank,
                        "Collective rank/device differs",
                    )
            normalized.append(normalized_cohorts(cohorts, mapping, cases))
            prior[rank] = copy.deepcopy(cohorts)
        require(
            all(v == normalized[0] for v in normalized),
            "Four-rank normalized P geometry differs",
        )
        outputs.append({"batch_id": entry["batch_id"], "cohorts": normalized[0][-2:]})
    if role == "external":
        require(
            [row["cohorts"] for row in report["external_layout_final"]]
            == [prior[row["rank"]] for row in report["external_layout_final"]],
            "Final external cohorts differ",
        )
        layout.validate_uninstall_receipts(
            report["external_layout_uninstall"], LAYOUT_SHA, mode="prefix"
        )
        for row in report["external_layout_uninstall"]:
            own(row["bridge_ownership"], "restored")
        require(
            report["external_layout_restored"] is True, "External slots not restored"
        )
    return outputs


def first_difference(left, right):
    for index, (a, b) in enumerate(zip(left, right), 1):
        if a != b:
            return index
    return None if len(left) == len(right) else min(len(left), len(right)) + 1


def validate_outputs(report, selected, decoder, vocab_size):
    require(
        len(report["outputs"]) == len(selected) == 32
        and {r["case_id"] for r in report["outputs"]} == set(selected),
        "Complete32 output identities required",
    )
    result = {}
    for row in report["outputs"]:
        require(
            row["finished"] is True
            and not row.get("error")
            and row["finish_reason"] in ("stop", "length")
            and 0 < len(row["token_ids"]) <= 8192,
            "All32 must finish naturally or at original8192 cap",
        )
        require(
            all(type(t) is int and 0 <= t < vocab_size for t in row["token_ids"]),
            "Invalid complete token payload",
        )
        require(
            decoder.decode(row["token_ids"], skip_special_tokens=True) == row["text"],
            "Stored text differs from original tokenizer decode",
        )
        result[row["case_id"]] = row
    return result


def audit(bundle, external, builtin):
    # Crucial ordering: prove BOTH processes terminal before reading either child.
    ec, bc = terminal(external), terminal(builtin)
    frozen = read(bundle / "freeze-manifest-v1.json")
    require(
        frozen["status"] == "frozen"
        and frozen["source_reference_identity_sha256"] == IDENTITY_SHA
        and set(frozen["declared_attempts"]) == {"posterior32"},
        "Frozen bridge declaration differs",
    )
    declaration = frozen["declared_attempts"]["posterior32"]
    require(
        external.resolve() == Path(declaration["directory"]).resolve()
        and external.name == declaration["label"] == LABEL,
        "Unexpected external attempt/retry",
    )
    require(
        ec["schema"] == "muxpd-q40-external-posterior32-controller-v1"
        and ec["scope"] == "posterior32"
        and ec["source_reference_identity_sha256"] == IDENTITY_SHA,
        "External controller identity differs",
    )
    require(
        sha(bundle / "source-reference-identity-v1.json") == IDENTITY_SHA,
        "Source reference identity bytes changed",
    )
    require(
        len(frozen["files"]) == 31 and frozen["files"] == ec["files"],
        "Producer map cardinality differs",
    )
    for name, expected in frozen["files"].items():
        require(
            sha(bundle / name) == sha(external / "producer" / name) == expected,
            "Frozen producer bytes differ",
        )
    require(
        sha(bundle / "freeze-manifest-v1.json")
        == sha(external / "producer/freeze-manifest-v1.json")
        == ec["freeze_manifest_sha256"],
        "Archived freeze differs",
    )
    refs = read(bundle / "external-bridge-references-v1.json")
    for name in ("identity", "freeze", "primary", "independent", "controller", "child"):
        require(
            sha(refs[name]["path"]) == refs[name]["sha256"],
            "Pinned builtin reference changed",
        )
    require(
        Path(refs["controller"]["path"]).resolve()
        == (builtin / "controller.json").resolve(),
        "Unexpected builtin reference",
    )
    for directory in (external, builtin):
        log = (directory / "process.log").read_text(errors="replace")
        require(
            not any(
                marker in log
                for marker in (
                    "Traceback",
                    "Layout slot changed externally",
                    "Layout is poisoned",
                )
            ),
            "Terminal log has failure/ownership evidence",
        )
    for directory, controller in ((external, ec), (builtin, bc)):
        terminal_receipt = controller["terminal_assessment"]
        require(
            terminal_receipt["passed"] is True
            and terminal_receipt["child_sha256"] == sha(directory / "results/run.json"),
            "Controller terminal assessment does not bind the actual child bytes",
        )
    require(
        Path(refs["child"]["path"]).resolve()
        == (builtin / "results/run.json").resolve(),
        "Pinned builtin child path differs from the declared reference run",
    )
    er, br = read(external / "results/run.json"), read(builtin / "results/run.json")
    for report in (er, br):
        require(
            report["passed"] is True
            and report["collection_complete"] is True
            and report["shutdown_returned"] is True
            and not report["errors"],
            "Collection incomplete",
        )
        require(
            report["scope"] == "posterior32"
            and report["selected_batch_ids"] == BATCHES,
            "Original32 scope differs",
        )
        require(
            not report.get("failure_cleanup")
            and not report["terminal_maintenance"]["aborted_internal_ids"],
            "Success cannot cancel live requests",
        )
    require(
        er["schema"] == "muxpd-q40-external-posterior32-run-v1"
        and "candidate_identity" not in er,
        "External arm must not impersonate a candidate",
    )
    require(
        datetime.fromisoformat(ec["started_at"])
        > datetime.fromisoformat(bc["finished_at"])
        and er["process_id"] != br["process_id"],
        "External process not fresh after builtin terminal",
    )
    for key in ("base_engine_args", "engine_args"):
        expected = copy.deepcopy(br[key])
        policy = expected["batch_admission_policy_config"]
        require(
            policy["experimental_prefill_collective_layout"] == "prefix"
            and type(policy["layers_per_slice"]) is int
            and policy["layers_per_slice"] == 40
            and policy["require_hccl_deterministic"] is True,
            "Builtin fixed q40 policy changed",
        )
        policy["experimental_prefill_collective_layout"] = "off"
        require(
            canonical(er[key]) == canonical(expected),
            "Configuration changed beyond declared prefix-to-off",
        )
    require(
        ec["launch_engine_args"] == er["base_engine_args"]
        and er["runtime_environment"] == br["runtime_environment"],
        "Actual launch/environment differs",
    )
    source = ec["source_preflight"]
    identity = read(bundle / "source-reference-identity-v1.json")
    require(
        er["source_reference_identity"]
        == er["source_after_startup"]
        == er["sources_after_shutdown"]
        == source
        and source == br["candidate_identity"]
        and source["candidate_manifest"] == identity,
        "Actual pre/post source identities differ",
    )
    root = Path(identity["source_root"])
    git = lambda *args: subprocess.check_output(
        ["git", "-C", str(root), *args], text=True
    ).strip()
    require(
        git("rev-parse", "HEAD") == identity["candidate_commit"]
        and not git("status", "--porcelain"),
        "Actual runtime source is not exact clean reference",
    )
    require(
        {name: sha(root / name) for name in git("ls-files", "--", "src").splitlines()}
        == identity["runtime_files"],
        "Actual full src bytes changed",
    )
    model = identity["model_config_identity"]
    require(
        sha(model["path"]) == model["sha256"]
        and er["model_config_before_startup"]
        == er["model_config_after_startup"]
        == br["model_config_before_startup"]
        == br["model_config_after_startup"]
        == model,
        "Actual constructor model config receipts differ",
    )
    scorer = load_original(
        bundle / "score_quality.py", "independent_original_scorer", SCORER_SHA
    )
    layout = load_original(
        bundle / "prefill_collective_layout_v1.py",
        "independent_original_layout",
        LAYOUT_SHA,
    )
    plan, cases, extract = scorer.load_frozen(bundle / "frozen-v2")
    batches = [b for b in plan["batches"] if b["batch_id"] in BATCHES]
    selected = [rid for batch in batches for rid in batch["case_ids"]]
    chosen = [next(c for c in cases if c["case_id"] == rid) for rid in selected]
    require(
        er["selected_case_ids"] == br["selected_case_ids"] == selected,
        "Selected original case order differs",
    )
    from tokenizers import Tokenizer

    tokenizer = plan["tokenizer_files"]["tokenizer.json"]
    require(sha(tokenizer["path"]) == tokenizer["sha256"], "Original tokenizer changed")
    decoder = Tokenizer.from_file(tokenizer["path"])
    vocab_size = decoder.get_vocab_size()
    eout = validate_outputs(er, selected, decoder, vocab_size)
    bout = validate_outputs(br, selected, decoder, vocab_size)
    emap, eadmit = bind_admissions(er, batches, cases)
    bmap, badmit = bind_admissions(br, batches, cases)
    for values, mapping in ((eout, emap), (bout, bmap)):
        for case_id, row in values.items():
            require(
                mapped(mapping, row["request_id"]) == case_id,
                "Final output request ID does not match its admitted case",
            )
    eschedule, esummary = schedule(er, external / "results", emap)
    bschedule, bsummary = schedule(br, builtin / "results", bmap)
    egraph = workers_and_graph(er, eschedule)
    bgraph = workers_and_graph(br, bschedule)
    egeometry = geometry(er, external / "results", "external", emap, cases, layout)
    bgeometry = geometry(br, builtin / "results", "builtin", bmap, cases, layout)
    escore = scorer.score(er, plan, chosen, extract)
    bscore = scorer.score(br, plan, chosen, extract)
    per_case = []
    for rid in selected:
        a, b = bout[rid], eout[rid]
        per_case.append(
            {
                "case_id": rid,
                "tokens_equal": a["token_ids"] == b["token_ids"],
                "text_equal": a["text"] == b["text"],
                "finish_equal": a["finish_reason"] == b["finish_reason"],
                "stop_equal": a["stop_reason"] == b["stop_reason"],
                "first_token_difference_one_based": first_difference(
                    a["token_ids"], b["token_ids"]
                ),
                "builtin_tokens": len(a["token_ids"]),
                "external_tokens": len(b["token_ids"]),
            }
        )
    failed = next(r for r in bscore["rows"] if r["case_id"] == "mmlu-pro-01741")
    require(
        bscore["correct"] == 29
        and bscore["all_complete"]
        and failed["gold"] == "E"
        and failed["answer"] == "C"
        and failed["output_tokens"] == 5551
        and not failed["correct"],
        "Frozen builtin quality failure was altered",
    )
    checks = {
        "all32_tokens_text_finish_stop_equal": all(
            all(
                r[k]
                for k in ("tokens_equal", "text_equal", "finish_equal", "stop_equal")
            )
            for r in per_case
        ),
        "original_scores_equal": bscore == escore,
        "admissions_equal": badmit == eadmit,
        "complete_schedule_equal": bschedule == eschedule,
        "all4rank_geometry_equal": bgeometry == egeometry,
        "schedule_derived_graph_counts_equal": bgraph == egraph,
    }
    return {
        "collection_checks_passed": True,
        "port_equivalence_passed": all(checks.values()),
        "checks": checks,
        "per_case": per_case,
        "builtin_score": bscore,
        "graph": {"builtin": bgraph, "external": egraph},
        "external_score": escore,
        "preserved_builtin_failure": failed,
        "schedule": {
            "builtin": bsummary,
            "external": esummary,
            "first_difference_event_one_based": first_difference(bschedule, eschedule),
            "builtin_sha256": digest(bschedule),
            "external_sha256": digest(eschedule),
        },
        "geometry": {
            "builtin_sha256": digest(bgeometry),
            "external_sha256": digest(egeometry),
            "first_difference_batch_one_based": first_difference(bgeometry, egeometry),
            "cohorts": 8,
            "calls_per_peer_cohort_per_rank": 81,
        },
        "provenance": {
            "external_controller_sha256": sha(external / "controller.json"),
            "builtin_controller_sha256": sha(builtin / "controller.json"),
            "external_child_sha256": sha(external / "results/run.json"),
            "builtin_child_sha256": sha(builtin / "results/run.json"),
            "freeze_sha256": sha(bundle / "freeze-manifest-v1.json"),
            "source_reference_identity_sha256": IDENTITY_SHA,
        },
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bundle", type=Path, required=True)
    p.add_argument("--external", type=Path, required=True)
    p.add_argument("--builtin", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    require(
        not args.output.exists(), "Independent audit cannot overwrite earlier evidence"
    )
    result = {
        "schema": "muxpd-external-posterior32-independent-terminal-v1",
        "passed": False,
        "collection_checks_passed": False,
        "port_equivalence_passed": None,
        "answer_quality_accepted": False,
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "errors": [],
        "scope": "Independent terminal/source/original32 output/score/schedule/geometry comparison. Audit success is not port equivalence or candidate quality acceptance.",
    }
    try:
        result.update(
            audit(
                args.bundle.resolve(), args.external.resolve(), args.builtin.resolve()
            )
        )
        result["passed"] = True
    except (
        OSError,
        ValueError,
        KeyError,
        TypeError,
        RuntimeError,
        subprocess.SubprocessError,
    ) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                k: result[k]
                for k in (
                    "passed",
                    "collection_checks_passed",
                    "port_equivalence_passed",
                    "errors",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
