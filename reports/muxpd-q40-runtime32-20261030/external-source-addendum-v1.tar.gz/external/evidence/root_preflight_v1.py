"""Root read-only final source/environment/device preflight; no model import."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from probe_control_v1 import inventory

BUNDLE = Path(__file__).resolve().parent
OUT = BUNDLE / "root-preflight-v1"
OUT.mkdir(exist_ok=False)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


matrix = json.loads((BUNDLE / "run-matrix-v1.json").read_text())
completed = subprocess.run(matrix["dry_run_command"], capture_output=True)
(OUT / "dry-run.json").write_bytes(completed.stdout)
(OUT / "dry-run.stderr").write_bytes(completed.stderr)
if completed.returncode:
    raise SystemExit("Root preflight dry-run failed; retained stdout/stderr")
preview = json.loads(completed.stdout)
assert preview["selected_batch_ids"] == [3, 6, 7, 14]
assert preview["selected_case_count"] == 32
assert preview["runtime_environment_guard"]["passed"]
assert preview["reference_qualification"]["passed"]
assert preview["reference_qualification"]["builtin_relative_no_new_wrong_passed"] is False
assert len(preview["files"]) == 31
assert preview["files"] == {name: sha(BUNDLE / name) for name in preview["files"]}
assert not Path(preview["destination"]).exists()
source = "/root/workspace/muxpd-prefix-q40-runtime"
head = subprocess.check_output(["git", "-C", source, "rev-parse", "HEAD"], text=True).strip()
status = subprocess.check_output(["git", "-C", source, "status", "--porcelain"], text=True)
assert head == "a05029484b2c9bc21e4e6fd705cc396d111dfaa5" and not status
devices = subprocess.check_output(["npu-smi", "info"], timeout=30)
(OUT / "npu-idle.txt").write_bytes(devices)
physical = inventory(devices.decode())
assert physical == ["3", "4", "5", "6"]
record = {
    "schema": "muxpd-external32-root-preflight-v1",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "passed": True,
    "source_commit": head,
    "source_clean": True,
    "idle_physical": physical,
    "source_reference_identity_sha256": sha(BUNDLE / "source-reference-identity-v1.json"),
    "matrix_sha256": sha(BUNDLE / "run-matrix-v1.json"),
    "dry_run_sha256": sha(OUT / "dry-run.json"),
    "npu_idle_sha256": sha(OUT / "npu-idle.txt"),
    "producer_files": preview["files"],
    "full200_started_or_authorized": False,
}
(OUT / "preflight.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"passed": True, "sha256": sha(OUT / "preflight.json"), "physical": physical}))
