"""CPU-only semantic comparisons using the real terminal builtin posterior32."""

import copy
import json
from pathlib import Path

import pytest

import external_bridge_analysis_v1 as bridge

REFERENCE = Path(
    "/root/workspace/muxpd-runtime-quality-candidate-v2-20261030/runs-v1/prefix-q40-runtime-posterior32-v1-01"
)


@pytest.fixture(scope="module")
def actual():
    bridge.legacy.terminal_controller(REFERENCE)
    report = json.loads((REFERENCE / "results/run.json").read_text())
    history = [
        json.loads(line)
        for line in (REFERENCE / "results/scheduler-receipts.jsonl")
        .read_text()
        .splitlines()
    ]
    return report, history


def test_identical_complete_outputs_preserve_wrong_answer(actual):
    report, _ = actual
    result = bridge.compare_outputs(report, copy.deepcopy(report))
    assert result["all_32_equal"] is True
    target = next(r for r in result["rows"] if r["case_id"] == "mmlu-pro-01741")
    assert target["builtin_tokens"] == target["external_tokens"] == 5551
    assert target["first_token_difference"] is None


def test_length_only_and_numeric_token_differences_are_explicit(actual):
    report, _ = actual
    other = copy.deepcopy(report)
    row = next(r for r in other["outputs"] if r["case_id"] == "mmlu-pro-01741")
    row["token_ids"] = row["token_ids"][:57]
    row["text"] = "synthetic shorter completion"
    result = bridge.compare_outputs(report, other)
    target = next(r for r in result["rows"] if r["case_id"] == row["case_id"])
    assert result["all_32_equal"] is False
    assert target["first_token_difference"]["position_one_based"] == 58
    assert target["first_token_difference"]["kind"] == "length"
    other = copy.deepcopy(report)
    row = next(r for r in other["outputs"] if r["case_id"] == "mmlu-pro-01741")
    row["token_ids"][13] += 1
    target = next(
        r
        for r in bridge.compare_outputs(report, other)["rows"]
        if r["case_id"] == row["case_id"]
    )
    assert target["first_token_difference"]["position_one_based"] == 14
    assert target["first_token_difference"]["kind"] == "token"


def rename(report, history):
    result, events = copy.deepcopy(report), copy.deepcopy(history)
    ids = {
        b["internal"]: "renamed-" + b["internal"]
        for a in result["admissions"]
        for b in a["bindings"]
    }
    for admission in result["admissions"]:
        for binding in admission["bindings"]:
            binding["internal"] = ids[binding["internal"]]

    def visit(value):
        if isinstance(value, dict):
            return {ids.get(k, k): visit(v) for k, v in value.items()}
        if isinstance(value, list):
            return [visit(v) for v in value]
        return ids.get(value, value) if isinstance(value, str) else value

    return result, visit(events), ids


def test_schedule_compares_semantics_not_process_request_ids(actual):
    report, history = actual
    other, events, _ = rename(report, history)
    assert bridge.normalize_schedule(report, history) == bridge.normalize_schedule(
        other, events
    )
    events[0]["scheduled_tokens"]["foreign-request"] = 1
    with pytest.raises(ValueError, match="Unknown request"):
        bridge.normalize_schedule(other, events)


def test_schedule_difference_does_not_require_equal_natural_lengths(actual):
    report, history = actual
    other, events, _ = rename(report, history)
    result = bridge.compare_schedule(report, history, other, events[:-2])
    assert result["equal"] is False
    assert result["first_difference"]["kind"] == "length"


def test_cohort_request_and_process_identity_normalization(actual):
    report, history = actual
    rows = json.loads((REFERENCE / "results/prefix-batch-14.json").read_text())["rows"]
    original = rows[0]["recent_cohorts"]
    other, _, ids = rename(report, history)
    changed = copy.deepcopy(original)
    for record in changed:
        for field in ("admission_p_counts", "admission_d_counts"):
            record[field] = {ids[k]: v for k, v in record[field].items()}
        record["batch"]["req_ids"] = [ids[k] for k in record["batch"]["req_ids"]]
        for row in record["batch"]["rows"]:
            row["request_id"] = ids[row["request_id"]]
        for call in record["calls"]:
            for side in ("route_before", "route_after"):
                for key in (
                    "process_id",
                    "coordinator_python_id",
                    "device_group_python_id",
                    "selected_device_group_python_id",
                ):
                    call[side][key] += 900
                call[side]["router_calls"] = {
                    k: v + 500 for k, v in call[side]["router_calls"].items()
                }
    assert bridge.normalize_cohorts(report, original) == bridge.normalize_cohorts(
        other, changed
    )
    changed[-1]["calls"][0]["route_before"]["selected_coordinator_name"] = "wrong-route"
    assert bridge.normalize_cohorts(report, original) != bridge.normalize_cohorts(
        other, changed
    )


def test_reference_accepts_qualified_builtin_quality_failure():
    refs, proof = bridge.verify_references(Path(__file__).parent)
    assert proof["passed"] is True
    assert proof["builtin_relative_no_new_wrong_passed"] is False
    assert refs["expected_new_wrong"] == ["mmlu-pro-01741"]


def test_terminal_first_does_not_read_missing_live_child(tmp_path):
    (tmp_path / "controller.json").write_text(
        json.dumps({"passed": False, "terminal_process_proven": False})
    )
    with pytest.raises(ValueError, match="terminal"):
        bridge.qualify_external(tmp_path, Path(__file__).parent)


def external_rows():
    rows = json.loads((REFERENCE / "results/prefix-batch-14.json").read_text())["rows"]
    for row in rows:
        row["schema"] = "muxpd-prefill-collective-layout-v1"
        row["module_sha256"] = bridge.treatment.LAYOUT_SHA
        row["cohorts"] = row.pop("recent_cohorts")
        row["bridge_ownership"] = {
            "builtin_layout": None,
            "external_present": True,
            "external_uninstalled": False,
            "external_hooks_owned": True,
            "foreign_observers": dict.fromkeys(
                (
                    "_graph_tap_observer",
                    "_mixed_ordered_observer",
                    "_muxpd_layer_capture_v3",
                ),
                False,
            ),
        }
    return rows


def test_external_raw_81_calls_prompt_source_and_route_owner(actual):
    report, receipts = actual
    plan, cases, _ = bridge.original.load_frozen(Path(__file__).parent / "frozen-v2")
    batches = bridge.checks.select_batches(plan, "posterior32")
    rows = external_rows()
    assert (
        bridge.validate_external_cohorts(rows, report, batches, cases, receipts)[
            "completed_cohorts"
        ]
        == 8
    )
    changed = copy.deepcopy(rows)
    for row in changed:
        row["cohorts"][-1]["batch"]["rows"][2]["prompt_sha256"] = "f" * 64
    with pytest.raises(ValueError, match="fingerprint"):
        bridge.validate_external_cohorts(changed, report, batches, cases, receipts)
    changed = copy.deepcopy(rows)
    for row in changed:
        for call in row["cohorts"][-1]["calls"]:
            for side in ("route_before", "route_after"):
                call[side]["selected_device_group_python_id"] += 1
    with pytest.raises(ValueError, match="ownership drifted"):
        bridge.validate_external_cohorts(changed, report, batches, cases, receipts)


def test_complete_answer_comparison_retains_shared_new_wrong(actual):
    report, _ = actual
    result = bridge.compare_answers(
        report, copy.deepcopy(report), Path(__file__).parent
    )
    assert result["all_scores_equal"] is True
    assert result["external_new_wrong_on_both_native_correct"] == ["mmlu-pro-01741"]
    target = next(r for r in result["rows"] if r["case_id"] == "mmlu-pro-01741")
    assert target["builtin"]["answer"] == target["external"]["answer"] == "C"
    assert target["external"]["correct"] is False
