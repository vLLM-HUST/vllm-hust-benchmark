"""Narrow prefix-to-off configuration and external observer lifecycle bridge."""

import copy
import json
from pathlib import Path

import candidate_checks_v1 as checks
import prefill_collective_layout_v1 as layout
from probe_run_v1 import file_sha, save, validate_workers

BUNDLE = Path(__file__).resolve().parent
SCOPES = ("posterior32",)
PLAN_SHA = checks.PLAN_SHA
LAYOUT_SHA = "6431c4c0abdd869ef17e7122f681c457ad2b4d5741f86c6a0653e9fca44e02fc"
IDENTITY_SHA = "8d04890973c369a5412e80cc08c6cb55ef405e9360bd38e2bfafa9b5d65fe4fe"
LABEL = "external-q40-posterior32-bridge-v1-01"


def load_treatment(bundle=BUNDLE):
    value = json.loads((bundle / "external-treatment-v1.json").read_text())
    expected = {
        "schema": "muxpd-q40-external-posterior32-treatment-v1",
        "scope": "posterior32",
        "label": LABEL,
        "batch_ids": [3, 6, 7, 14],
        "source_commit": "a05029484b2c9bc21e4e6fd705cc396d111dfaa5",
        "source_reference_identity_sha256": IDENTITY_SHA,
        "policy_change": {"key": checks.POLICY_KEY, "from": "prefix", "to": "off"},
        "layers_per_slice": 40,
        "require_hccl_deterministic": True,
        "external_module_sha256": LAYOUT_SHA,
        "external_mode": "prefix",
        "quality_candidate": False,
        "numerical_observer": False,
        "per_batch_snapshot_rpc_count": 1,
        "maximum_wall_seconds": 10800,
        "controller_timeout_seconds": 12600,
    }
    checks.require(
        json.dumps(value, sort_keys=True) == json.dumps(expected, sort_keys=True),
        "Declared external bridge treatment differs",
    )
    checks.require(
        file_sha(bundle / "prefill_collective_layout_v1.py") == LAYOUT_SHA,
        "Frozen external module differs",
    )
    checks.require(
        file_sha(bundle / "source-reference-identity-v1.json") == IDENTITY_SHA,
        "Frozen source reference identity differs",
    )
    return value


def treatment_receipt(bundle=BUNDLE):
    return {
        **load_treatment(bundle),
        "profile_sha256": file_sha(bundle / "external-treatment-v1.json"),
    }


def apply_external_treatment(config):
    result = copy.deepcopy(config)
    policy = result["batch_admission_policy_config"]
    checks.require(
        policy.get(checks.POLICY_KEY) == "prefix"
        and type(policy.get("layers_per_slice")) is int
        and policy["layers_per_slice"] == 40
        and policy.get("require_hccl_deterministic") is True,
        "External bridge requires exact builtin q40 deterministic reference policy",
    )
    policy[checks.POLICY_KEY] = "off"
    return result


def select_batches(plan, scope):
    checks.require(
        scope == "posterior32", "External bridge only permits original posterior32"
    )
    batches = checks.select_batches(plan, scope)
    checks.require(
        [b["batch_id"] for b in batches] == [3, 6, 7, 14],
        "Original posterior batch sequence differs",
    )
    return batches


def ownership(argument):
    worker = getattr(argument, "worker", argument)
    obj = getattr(worker, layout.ATTRIBUTE, None)
    snapshot = None if obj is None else obj.snapshot()
    return {
        "builtin_layout": checks.builtin_snapshot(worker),
        "external_present": obj is not None,
        "external_uninstalled": None if obj is None else obj.uninstalled,
        "external_hooks_owned": bool(
            snapshot and not snapshot["uninstalled"] and snapshot["all_hooks_intact"]
        ),
        "foreign_observers": {
            name: hasattr(worker, name)
            for name in (
                "_graph_tap_observer",
                "_mixed_ordered_observer",
                "_muxpd_layer_capture_v3",
            )
        },
    }


def validate_ownership(value, stage):
    checks.require(
        stage in ("absent", "installed", "restored"), "Unknown external ownership stage"
    )
    checks.require(
        value["builtin_layout"] is None
        and set(value["foreign_observers"])
        == {"_graph_tap_observer", "_mixed_ordered_observer", "_muxpd_layer_capture_v3"}
        and not any(value["foreign_observers"].values()),
        "Builtin/foreign observer unexpectedly active",
    )
    expected = {
        "absent": (False, None, False),
        "installed": (True, False, True),
        "restored": (True, True, False),
    }[stage]
    actual = (
        value["external_present"],
        value["external_uninstalled"],
        value["external_hooks_owned"],
    )
    checks.require(actual == expected, "External hook ownership/restoration differs")


def install_external(argument):
    validate_ownership(ownership(argument), "absent")
    result = layout.install_on_worker(argument, "prefix")
    result["bridge_ownership"] = ownership(argument)
    validate_ownership(result["bridge_ownership"], "installed")
    return result


def external_snapshot(argument):
    result = layout.snapshot_on_worker(argument)
    if result is not None:
        result["bridge_ownership"] = ownership(argument)
    return result


def uninstall_external(argument, allow_incomplete=False):
    result = layout.uninstall_on_worker(argument, allow_incomplete)
    result["bridge_ownership"] = ownership(argument)
    return result


def worker_snapshot(argument):
    result = checks.candidate_worker_snapshot(argument)
    result["external_layout"] = external_snapshot(argument)
    result["bridge_ownership"] = ownership(argument)
    return result


def validate_external_workers(rows, identity, *, installed):
    validate_workers(rows, "raw-layout-plain")
    checks.four(rows)
    historical = checks.original_manifest()["historical_runs"][
        "raw-quality-v2-hccl-true-01"
    ]["engine_args"]
    expected = apply_external_treatment(
        checks.apply_policy_changes(historical, identity)
    )["batch_admission_policy_config"]
    for row in rows:
        checks.require(
            row["worker_source_path"]
            == str(
                Path(identity["source_root"]) / "src/vllm_muxpd/decoupled_worker.py"
            ),
            "Worker source differs",
        )
        validate_ownership(
            row["bridge_ownership"], "installed" if installed else "absent"
        )
        checks.require(row["builtin_layout"] is None, "Builtin prefix must be absent")
        checks.require(
            json.dumps(row["runtime"]["policy"], sort_keys=True, separators=(",", ":"))
            == json.dumps(expected, sort_keys=True, separators=(",", ":")),
            "Entire external worker policy differs",
        )
        flags = row["foreign_diagnostic_state"]
        checks.require(
            flags
            == {
                "_graph_tap_observer": False,
                "_mixed_ordered_observer": False,
                "_muxpd_prefill_collective_layout_v1": installed,
                "_muxpd_layer_capture_v3": False,
            },
            "Foreign diagnostic state differs",
        )


def save_batch_snapshot(llm, tracker, report, output, batch, cases):
    rows = llm.collective_rpc(external_snapshot, timeout=60)
    path = output / f"external-prefix-batch-{batch['batch_id']:02d}.json"
    checks.require(not path.exists(), "External batch snapshot cannot overwrite")
    save(path, {"batch_id": batch["batch_id"], "rows": rows})
    item = {
        "batch_id": batch["batch_id"],
        "path": str(path.resolve()),
        "sha256": file_sha(path),
        "validation": None,
    }
    report["external_batch_snapshots"].append(item)
    save(output / "run.json", report)
    checks.require(
        batch["batch_id"] not in [b["batch_id"] for b in tracker],
        "Repeated batch snapshot",
    )
    for row in rows:
        validate_ownership(row["bridge_ownership"], "installed")
    item["validation"] = validate_layout_admissions(
        rows,
        report["admissions"],
        output / "scheduler-receipts.jsonl",
        [*tracker, batch],
        cases,
    )
    tracker.append(copy.deepcopy(batch))


def validate_final_snapshot(rows, tracker, report, output):
    checks.require(len(tracker) == 4, "Incomplete external per-batch snapshots")
    previous = json.loads((output / "external-prefix-batch-14.json").read_text())[
        "rows"
    ]
    checks.require(
        rows == previous, "Final maintenance changed external cohort evidence"
    )
    return {
        "passed": True,
        "total_cohorts": 8,
        "per_batch_snapshot_count": len(report["external_batch_snapshots"]),
    }


def validate_layout_admissions(rows, admissions, receipt_path, batches, cases):
    """Bind every layout admission to the original host admission and scheduler.

    Actual D rows come from the scheduler receipt; a D1 assumption cannot supply
    missing evidence. The normal seed-D0/peer-D1 pattern is reported separately.
    """
    by_case = {c["case_id"]: c for c in cases}
    if len(admissions) != 2 * len(batches):
        raise ValueError("Missing seed/peer admission")
    scheduled = []
    for line in receipt_path.read_text().splitlines():
        item = json.loads(line)
        if item["event"] == "schedule" and item["new_prefill_ids"]:
            scheduled.append(item)
    if len(scheduled) != len(admissions):
        raise ValueError("Unexpected number of actually scheduled P cohorts")
    expected, pattern = [], []
    for index, (admission, schedule) in enumerate(
        zip(admissions, scheduled, strict=True)
    ):
        batch = batches[index // 2]
        seed_stage = index % 2 == 0
        members = batch["case_ids"][:1] if seed_stage else batch["case_ids"][1:]
        if (
            admission["batch_id"] != batch["batch_id"]
            or admission["stage"] != ("seed" if seed_stage else "peers")
            or [b["case_id"] for b in admission["bindings"]] != members
        ):
            raise ValueError("Frozen batch admission identity/order changed")
        p_counts = {
            b["internal"]: len(by_case[b["case_id"]]["prompt_token_ids"])
            for b in admission["bindings"]
        }
        counts = schedule["scheduled_tokens"]
        d_counts = {rid: n for rid, n in counts.items() if rid not in p_counts}
        if (
            schedule["batch_id"] != batch["batch_id"]
            or set(schedule["new_prefill_ids"]) != set(p_counts)
            or {rid: counts[rid] for rid in p_counts} != p_counts
        ):
            raise ValueError("Layout P rows do not match complete frozen prompts")
        seed_id = (
            admissions[index - 1]["bindings"][0]["internal"] if not seed_stage else None
        )
        if (
            (seed_stage and d_counts)
            or (not seed_stage and set(d_counts) - {seed_id})
            or any(n != 1 for n in d_counts.values())
        ):
            raise ValueError("Unexpected actual D admission in sequential batch")
        expected.append((p_counts, d_counts))
        pattern.append(
            {
                "batch_id": batch["batch_id"],
                "stage": admission["stage"],
                "d_rows": sum(d_counts.values()),
                "p_request_count": len(p_counts),
            }
        )
    treated = sum(bool(d) for _, d in expected)
    layout.validate_receipts(
        rows,
        LAYOUT_SHA,
        mode="prefix",
        expected_treated_cohorts=treated,
        expected_completed=len(expected),
    )
    for row in rows:
        for cohort, (p_counts, d_counts) in zip(row["cohorts"], expected, strict=True):
            if (
                cohort["admission_p_counts"] != p_counts
                or cohort["admission_d_counts"] != d_counts
                or not (cohort["calls"] if d_counts else cohort["zero_d_bypass_calls"])
            ):
                raise ValueError("Worker layout differs from actual host admission")
    return {
        "completed_cohorts": len(expected),
        "treated_cohorts": treated,
        "actual_admission_pattern": pattern,
        "all_seed_d0_peer_d1": all(
            x["d_rows"] == (i % 2) for i, x in enumerate(pattern)
        ),
    }
