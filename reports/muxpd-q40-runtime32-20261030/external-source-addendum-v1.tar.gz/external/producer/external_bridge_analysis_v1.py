"""Terminal-only same-source external-layout bridge; not quality acceptance."""

import copy
import hashlib
import json
from datetime import datetime
from pathlib import Path

import candidate_checks_v1 as checks
import candidate_quality_analysis_v2 as legacy
import external_treatment_v1 as treatment
import prefill_collective_layout_v1 as layout
import score_quality as original

require, read, sha = legacy.require, legacy.read, legacy.sha
REFS_SHA = "1167ea651bef6b9c40eab0ec5d5ad489d7f06d5432a3dd3b4d2d9e9311e7fe6e"


def request_map(report):
    result = {}
    for admission in report["admissions"]:
        for binding in admission["bindings"]:
            rid, case = binding["internal"], binding["case_id"]
            require(
                rid not in result and case not in result.values(),
                "Duplicate admission identity",
            )
            result[rid] = case
    require(len(result) == 32, "Expected all32 actual admission identities")
    return result


def mapped(mapping, value):
    require(value in mapping, "Unknown request identity: " + str(value))
    return mapping[value]


def first_difference(left, right):
    for index, (a, b) in enumerate(zip(left, right), 1):
        if a != b:
            return {
                "position_one_based": index,
                "kind": "token",
                "builtin": a,
                "external": b,
            }
    if len(left) != len(right):
        index = min(len(left), len(right))
        return {
            "position_one_based": index + 1,
            "kind": "length",
            "builtin": left[index] if index < len(left) else None,
            "external": right[index] if index < len(right) else None,
        }
    return None


def compare_outputs(builtin, external):
    ids = [b["case_id"] for a in builtin["admissions"] for b in a["bindings"]]
    require(len(ids) == len(set(ids)) == 32, "Builtin original32 identity differs")
    indexed = []
    for report in (builtin, external):
        require(
            len(report["outputs"]) == 32
            and {r["case_id"] for r in report["outputs"]} == set(ids),
            "Missing/duplicate/foreign bridge outputs",
        )
        indexed.append({r["case_id"]: r for r in report["outputs"]})
    rows = []
    for case in ids:
        a, b = [values[case] for values in indexed]
        fields = {
            key: a.get(key) == b.get(key)
            for key in ("text", "finish_reason", "stop_reason", "finished", "error")
        }
        difference = first_difference(a["token_ids"], b["token_ids"])
        rows.append(
            {
                "case_id": case,
                "equal": difference is None and all(fields.values()),
                "builtin_tokens": len(a["token_ids"]),
                "external_tokens": len(b["token_ids"]),
                "common_prefix_tokens": min(len(a["token_ids"]), len(b["token_ids"]))
                if difference is None
                else difference["position_one_based"] - 1,
                "first_token_difference": difference,
                "field_equality": fields,
                "builtin_finish": a["finish_reason"],
                "external_finish": b["finish_reason"],
            }
        )
    return {
        "all_32_equal": all(r["equal"] for r in rows),
        "rows": rows,
        "different_case_ids": [r["case_id"] for r in rows if not r["equal"]],
    }


def normalize_schedule(report, events):
    ids = request_map(report)
    result, offsets = [], {}
    maps = {"scheduled_tokens", "phases_before"}
    sequences = {
        "new_prefill_ids",
        "pending_prefill_ids",
        "preempted_req_ids",
        "completed_prefill_ids",
        "cancelled_prefill_ids",
        "decode_retired_ids",
    }
    for event in events:
        row = copy.deepcopy(event)
        batch = row["batch_id"]
        offsets.setdefault(batch, row["global_step"] - 1)
        row["batch_step"] = row.pop("global_step") - offsets[batch]
        for key in maps & row.keys():
            row[key] = {mapped(ids, rid): value for rid, value in row[key].items()}
        for key in sequences & row.keys():
            row[key] = [mapped(ids, rid) for rid in row[key]]
        result.append(row)
    return result


def compare_schedule(builtin, builtin_events, external, external_events):
    a, b = (
        normalize_schedule(builtin, builtin_events),
        normalize_schedule(external, external_events),
    )
    rows = []
    for batch in [3, 6, 7, 14]:
        left = [r for r in a if r["batch_id"] == batch]
        right = [r for r in b if r["batch_id"] == batch]
        difference = first_difference(left, right)
        if difference and difference["kind"] == "token":
            difference["kind"] = "semantic_receipt"
        rows.append(
            {
                "batch_id": batch,
                "equal": difference is None,
                "builtin_receipts": len(left),
                "external_receipts": len(right),
                "first_difference": difference,
            }
        )
    changed = next((r for r in rows if not r["equal"]), None)
    return {
        "equal": changed is None,
        "batches": rows,
        "first_difference": None
        if changed is None
        else {"batch_id": changed["batch_id"], **changed["first_difference"]},
        "normalization": "Exact admission internal-request IDs map to case IDs; batch-local step offsets remove earlier natural-duration shifts; all other receipt fields retained.",
    }


def normalize_cohorts(report, records):
    ids = request_map(report)
    result = copy.deepcopy(records)
    for record in result:
        for key in ("admission_p_counts", "admission_d_counts"):
            record[key] = {
                mapped(ids, rid): value for rid, value in record[key].items()
            }
        batch = record["batch"]
        batch["req_ids"] = [mapped(ids, rid) for rid in batch["req_ids"]]
        for row in batch["rows"]:
            row["request_id"] = mapped(ids, row["request_id"])
        for call in record["calls"]:
            for side in ("route_before", "route_after"):
                for key in (
                    "process_id",
                    "coordinator_python_id",
                    "device_group_python_id",
                    "selected_device_group_python_id",
                    "router_calls",
                ):
                    del call[side][key]
    return result


def verify_references(bundle):
    bundle = Path(bundle)
    path = bundle / "external-bridge-references-v1.json"
    require(sha(path) == REFS_SHA, "Frozen external bridge references changed")
    refs = read(path)
    require(
        refs["schema"] == "muxpd-q40-external-bridge-references-v1"
        and refs["status"] == "qualified-builtin-failed-quality-reference",
        "Reference role changed",
    )
    # Reference controller is checked before any reference child/log/raw read.
    legacy.terminal_controller(refs["builtin_directory"])
    for key in ("identity", "freeze", "primary", "independent", "controller", "child"):
        require(
            sha(refs[key]["path"]) == refs[key]["sha256"],
            "Frozen reference changed: " + key,
        )
    for name, digest in refs["files"].items():
        require(sha(name) == digest, "Frozen reference file changed: " + name)
    proof, _value, _ = legacy.qualify_posterior(
        Path(refs["builtin_directory"]),
        Path(refs["builtin_bundle"]),
        Path(refs["identity"]["path"]),
    )
    primary, independent = (
        read(refs["primary"]["path"]),
        read(refs["independent"]["path"]),
    )
    require(
        primary["passed"] is True
        and primary["runtime_collection_qualified"] is True
        and primary["analysis_scope"] == "posterior32"
        and primary["full_quality_gate_attempted"] is False
        and primary["full_frozen_plan_passed"] is None,
        "Builtin reference is not qualified posterior-only",
    )
    require(
        primary["qualification"] == json.loads(json.dumps(proof))
        and independent["passed"] is True
        and independent["scope"] == "posterior32"
        and independent["controller_sha256"] == refs["controller"]["sha256"]
        and independent["child_sha256"] == refs["child"]["sha256"]
        and independent["freeze_sha256"] == refs["freeze"]["sha256"]
        and independent["candidate_identity_sha256"] == refs["identity"]["sha256"],
        "Independent/primary provenance changed",
    )
    relative = primary["answer_results"]["posterior32"]["relative_no_new_wrong"]
    require(
        relative["passed"] is False
        and relative["case_ids"] == refs["expected_new_wrong"] == ["mmlu-pro-01741"]
        and independent["relative_no_new_wrong_passed"] is False
        and independent["new_wrong_on_both_native_correct"]
        == refs["expected_new_wrong"],
        "Qualified builtin answer failure must remain visible",
    )
    return refs, {
        "passed": True,
        "references_sha256": REFS_SHA,
        "builtin_controller_sha256": refs["controller"]["sha256"],
        "builtin_child_sha256": refs["child"]["sha256"],
        "builtin_primary_sha256": refs["primary"]["sha256"],
        "builtin_independent_sha256": refs["independent"]["sha256"],
        "builtin_relative_no_new_wrong_passed": False,
        "builtin_new_wrong": refs["expected_new_wrong"],
        "full_quality_gate_attempted": False,
    }


def validate_external_cohorts(rows, report, batches, cases, receipts):
    expected = [
        item
        for batch in batches
        for item in checks.expected_cohorts(
            batch, report["admissions"], receipts, cases
        )
    ]
    layout.validate_receipts(
        rows,
        treatment.LAYOUT_SHA,
        mode="prefix",
        expected_treated_cohorts=len(batches),
        expected_completed=2 * len(batches),
    )
    for rank, row in checks.four(rows).items():
        treatment.validate_ownership(row["bridge_ownership"], "installed")
        require(
            row["hidden_size"] == 2048
            and row["local_rank"] == rank
            and row["expected_device"] == f"npu:{rank}",
            "External actual rank/device/hidden differs",
        )
        # External source has no startup_route field. Bind every actual call to
        # its own first actual route, without claiming a startup observation.
        route_identity = None
        for ordinal, (cohort, (pcounts, dcounts, tokens)) in enumerate(
            zip(row["cohorts"], expected, strict=True), 1
        ):
            require(
                cohort["cohort_id"] == ordinal
                and cohort["admission_p_counts"] == pcounts
                and cohort["admission_d_counts"] == dcounts
                and cohort["native_equivalent_order_claimed"] is False,
                "External cohort admission/order differs",
            )
            require(
                (len(cohort["calls"]) == 81 and cohort["zero_d_bypass_calls"] == 0)
                if dcounts
                else (not cohort["calls"] and cohort["zero_d_bypass_calls"] == 81),
                "Actual81 P reductions differ",
            )
            for item in cohort["batch"]["rows"]:
                require(
                    item["prompt_sha256"]
                    == hashlib.sha256(
                        json.dumps(
                            tokens[item["request_id"]], separators=(",", ":")
                        ).encode()
                    ).hexdigest(),
                    "Actual packed original prompt fingerprint differs",
                )
            for call in cohort["calls"]:
                for side in ("route_before", "route_after"):
                    route = call[side]
                    checks.route(route, rank, "prefill")
                    identity = {
                        k: v
                        for k, v in route.items()
                        if k not in ("router_calls", "active_lane")
                    }
                    if route_identity is None:
                        route_identity = identity
                    require(
                        identity == route_identity,
                        "Actual external P route ownership drifted",
                    )
    return {
        "passed": True,
        "ranks": [0, 1, 2, 3],
        "completed_cohorts": len(expected),
        "treated_cohorts": len(batches),
        "calls_per_treated_cohort": 81,
        "prompt_fingerprints_verified": True,
    }


def replay_external(report, results, batches, cases, receipts):
    results = Path(results)
    installation = report["external_layout_installation"]
    layout.validate_receipts(
        installation,
        treatment.LAYOUT_SHA,
        mode="prefix",
        expected_treated_cohorts=0,
        expected_completed=0,
    )
    for row in installation:
        treatment.validate_ownership(row["bridge_ownership"], "installed")
    items = report["external_batch_snapshots"]
    require(
        [item["batch_id"] for item in items] == [b["batch_id"] for b in batches],
        "Missing/reordered external snapshots",
    )
    require(
        {p.name for p in results.glob("external-prefix-batch-*.json")}
        == {f"external-prefix-batch-{b['batch_id']:02d}.json" for b in batches},
        "Extra/missing external raw snapshots",
    )
    previous = checks.four(installation)
    files = []
    for index, (batch, item) in enumerate(zip(batches, items, strict=True), 1):
        path = results / f"external-prefix-batch-{batch['batch_id']:02d}.json"
        require(
            Path(item["path"]).resolve() == path.resolve()
            and sha(path) == item["sha256"],
            "External raw snapshot path/hash changed",
        )
        raw = read(path)
        require(raw["batch_id"] == batch["batch_id"], "External raw batch changed")
        subset = batches[:index]
        selected_ids = {b["batch_id"] for b in subset}
        selected_receipts = [r for r in receipts if r["batch_id"] in selected_ids]
        value = validate_external_cohorts(
            raw["rows"], report, subset, cases, selected_receipts
        )
        current = checks.four(raw["rows"])
        for rank in range(4):
            require(
                current[rank]["cohorts"][:-2] == previous[rank]["cohorts"],
                "External accumulated cohort evidence rewritten",
            )
        previous = current
        expected_validation = {
            "completed_cohorts": 2 * index,
            "treated_cohorts": index,
            "actual_admission_pattern": [
                {
                    "batch_id": b["batch_id"],
                    "stage": stage,
                    "d_rows": d,
                    "p_request_count": count,
                }
                for b in subset
                for stage, d, count in [("seed", 0, 1), ("peers", 1, 7)]
            ],
            "all_seed_d0_peer_d1": True,
        }
        require(
            item["validation"] == expected_validation,
            "Saved external admission validation differs from raw replay",
        )
        files.append({"path": str(path.resolve()), "sha256": sha(path), **value})
    require(
        checks.four(report["external_layout_final"]) == previous
        and report["external_layout_final"]
        == [r["external_layout"] for r in report["worker_after"]],
        "Final external state differs from last batch/worker evidence",
    )
    require(
        report["external_layout_validation"]
        == {"passed": True, "total_cohorts": 8, "per_batch_snapshot_count": 4}
        and report["external_layout_admission_validation"] == expected_validation,
        "Final external validation differs",
    )
    layout.validate_uninstall_receipts(
        report["external_layout_uninstall"], treatment.LAYOUT_SHA, mode="prefix"
    )
    for row in report["external_layout_uninstall"]:
        treatment.validate_ownership(row["bridge_ownership"], "restored")
    require(report["external_layout_restored"] is True, "External3 hooks not restored")
    return {
        "passed": True,
        "files": files,
        "completed_cohorts": 8,
        "treated_cohorts": 4,
        "all4rank_raw_calls_verified": True,
        "restored_slots_per_rank": 3,
    }


def qualify_external(directory, bundle):
    import external_bridge_control_v1 as control
    from probe_control_v1 import inventory
    from probe_run_v1 import require_empty, require_empty_worker, tokenizer_identities

    directory, bundle = Path(directory), Path(bundle)
    # Both controllers are terminal before either arm's child or log is opened.
    controller = legacy.terminal_controller(directory)
    refs, reference_proof = verify_references(bundle)
    builtin = read(refs["child"]["path"])
    identity = read(bundle / "source-reference-identity-v1.json")
    require(
        sha(bundle / "source-reference-identity-v1.json")
        == refs["identity"]["sha256"]
        == treatment.IDENTITY_SHA,
        "Concrete same-source identity changed",
    )
    source = checks.source_guard(Path(identity["source_root"]), identity, bundle)
    freeze = read(bundle / "freeze-manifest-v1.json")
    require(
        freeze["status"] == "frozen"
        and set(freeze["declared_attempts"]) == {"posterior32"}
        and freeze["source_reference_identity_sha256"] == treatment.IDENTITY_SHA,
        "Single frozen bridge declaration required",
    )
    declared = freeze["declared_attempts"]["posterior32"]
    require(
        directory.resolve() == Path(declared["directory"]).resolve()
        and directory.name
        == declared["label"]
        == controller["label"]
        == treatment.LABEL,
        "Bridge attempt outside frozen declaration",
    )
    require(
        controller["schema"] == "muxpd-q40-external-posterior32-controller-v1"
        and controller["scope"] == "posterior32"
        and controller["profile"] == "external-q40-posterior32-bridge"
        and controller["bundle_frozen"] is True
        and controller["source_preflight"] == source
        and controller["reference_qualification"] == reference_proof,
        "Actual controller/source/reference differs",
    )
    require(
        len(control.FILES) == len(set(control.FILES)) == 31,
        "Exactly31 unique producer files required",
    )
    actual = {name: sha(directory / "producer" / name) for name in control.FILES}
    require(
        actual
        == controller["files"]
        == freeze["files"]
        == {name: sha(bundle / name) for name in control.FILES},
        "Archived bridge producer differs",
    )
    require(
        sha(directory / "producer/freeze-manifest-v1.json")
        == controller["freeze_manifest_sha256"]
        == sha(bundle / "freeze-manifest-v1.json")
        and controller["source_reference_identity_sha256"] == treatment.IDENTITY_SHA,
        "Frozen source identity/map changed",
    )
    terminal = control.terminal_assessment(directory, controller)
    require(
        terminal == controller["terminal_assessment"],
        "Actual terminal assessment changed",
    )
    report = read(directory / "results/run.json")
    require(
        datetime.fromisoformat(controller["started_at"])
        > datetime.fromisoformat(read(refs["controller"]["path"])["finished_at"])
        and report["process_id"] != builtin["process_id"],
        "Bridge must be a fresh process after builtin terminal",
    )
    for when in ("before", "after"):
        require(
            inventory((directory / f"npu-{when}.txt").read_text())
            == controller["expected_physical"]
            == ["3", "4", "5", "6"],
            "Physical idle proof changed",
        )
    plan, cases, _ = original.load_frozen(bundle / "frozen-v2")
    batches = checks.select_batches(plan, "posterior32")
    selected = [case for batch in batches for case in batch["case_ids"]]
    require(
        report["schema"] == "muxpd-q40-external-posterior32-run-v1"
        and report["role"] == "raw"
        and report["profile"] == controller["profile"]
        and report["scope"] == "posterior32"
        and report["layout_mode"] == "prefix"
        and report["builtin_layout_mode"] == "off"
        and report["plan_sha256"] == checks.PLAN_SHA
        and report["selected_batch_ids"]
        == controller["selected_batch_ids"]
        == [3, 6, 7, 14]
        and report["selected_case_ids"] == selected
        and controller["selected_case_count"] == 32
        and not report.get("failure_cleanup")
        and not report["terminal_maintenance"]["aborted_internal_ids"],
        "Original bridge scope/lifecycle differs",
    )
    for field, name in {
        "producer_sha256": "external_bridge_run_v1.py",
        "original_producer_sha256": "run_quality.py",
        "original_scorer_sha256": "score_quality.py",
        "source_manifest_sha256": "source-manifest-v1.json",
    }.items():
        require(report[field] == actual[name], "Actual bridge producer/scorer differs")
    require(
        report["layout_module_sha256"] == treatment.LAYOUT_SHA
        and report["source_reference_identity"] == source
        and report["sources"] == source["sources"]
        and report["source_after_startup"] == report["sources_after_shutdown"] == source
        and "candidate_identity" not in report,
        "External/source role differs",
    )
    require(
        report["external_treatment"]
        == controller["external_treatment"]
        == treatment.treatment_receipt(bundle),
        "Declared single treatment differs",
    )
    launch = treatment.apply_external_treatment(builtin["base_engine_args"])
    resolved = treatment.apply_external_treatment(builtin["engine_args"])
    require(
        report["base_engine_args"] == controller["launch_engine_args"] == launch
        and report["engine_args"] == resolved
        and report["effective"] == {k: resolved[k] for k in report["effective"]}
        and report["scheduler_class"] == resolved["scheduler_cls"]
        and report["engine_coordinator"] == "InprocClient",
        "Exact same-source config differs beyond prefix-to-off",
    )
    checks.validate_environment(
        report["runtime_environment"], builtin["runtime_environment"], identity
    )
    require(
        report["runtime_environment"] == builtin["runtime_environment"],
        "Builtin/external runtime environment differs",
    )
    require(
        report["tokenizer_files"] == tokenizer_identities(plan),
        "Tokenizer runtime receipts changed",
    )
    model = identity["model_config_identity"]
    require(
        sha(model["path"]) == model["sha256"]
        and report["model_config_before_startup"]
        == report["model_config_after_startup"]
        == builtin["model_config_before_startup"]
        == model,
        "Actual model config constructor receipts differ",
    )
    for when, installed in [("worker_before", False), ("worker_after", True)]:
        treatment.validate_external_workers(report[when], identity, installed=installed)
        for row in report[when]:
            require_empty_worker(row)
    require_empty(report["final_state"], report["idle_baseline"])
    history = directory / "results/scheduler-receipts.jsonl"
    require(
        sha(history) == report["scheduler_receipts_sha256"],
        "Raw scheduler bytes changed",
    )
    receipts = [json.loads(line) for line in history.read_text().splitlines()]
    schedule = legacy.validate_schedule(report, receipts, batches, cases)
    graph = legacy.validate_graphs(report, schedule["decode_turns"], 8)
    prefix = replay_external(report, directory / "results", batches, cases, receipts)
    mixed = original.verify_mixed_coverage(
        directory / "results/run.json", report, {**plan, "batches": batches}
    )
    require(
        mixed["passed"]
        and {int(k): v for k, v in report["mixed_coverage"]["steps_per_batch"].items()}
        == dict.fromkeys([3, 6, 7, 14], 1),
        "Actual mixed q40 single advance differs",
    )
    outputs = legacy.validate_outputs(report, selected, plan)
    require(
        report["warmup"]
        == builtin["warmup"]
        == "Existing LLM constructor warmup only; zero extra request warmups.",
        "Additional request warmup changed history",
    )
    return (
        {
            "passed": True,
            "controller_sha256": sha(directory / "controller.json"),
            "child_sha256": sha(directory / "results/run.json"),
            "freeze_sha256": sha(bundle / "freeze-manifest-v1.json"),
            "source_reference_identity_sha256": treatment.IDENTITY_SHA,
            "reference": reference_proof,
            "terminal": terminal,
            "schedule": schedule,
            "graph": graph,
            "external_prefix": prefix,
            "mixed": mixed,
            "outputs": outputs,
        },
        report,
        receipts,
        refs,
    )


def compare_answers(builtin, external, bundle):
    bundle = Path(bundle)
    plan, cases, extract = original.load_frozen(bundle / "frozen-v2")
    selected = [
        case
        for batch in checks.select_batches(plan, "posterior32")
        for case in batch["case_ids"]
    ]
    subset = [c for c in cases if c["case_id"] in selected]
    scores = {
        role: original.score(report, plan, subset, extract)
        for role, report in [("builtin", builtin), ("external", external)]
    }
    indexed = {
        role: {r["case_id"]: r for r in score["rows"]} for role, score in scores.items()
    }
    refs = read(bundle / "external-bridge-references-v1.json")
    primary = read(refs["primary"]["path"])["answer_results"]["posterior32"]
    historical = {r["case_id"]: r for r in primary["rows"]}
    rows = [
        {
            "case_id": case,
            "builtin": indexed["builtin"][case],
            "external": indexed["external"][case],
            "both_native_correct": historical[case]["both_native_correct"],
        }
        for case in selected
    ]
    wrong = [
        r["case_id"]
        for r in rows
        if r["both_native_correct"] and not r["external"]["correct"]
    ]
    return {
        "all_scores_equal": scores["builtin"] == scores["external"],
        "scores": scores,
        "rows": rows,
        "external_new_wrong_on_both_native_correct": wrong,
        "external_relative_no_new_wrong": {
            "passed": not wrong,
            "case_ids": wrong,
            "scope": "posterior32 diagnostic only",
        },
        "original_scorer_sha256": sha(bundle / "score_quality.py"),
        "canonical_adapter_sha256": sha(bundle / "frozen-v2/canonical-adapter.py"),
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
    }


def compare_qualified(report, receipts, refs, bundle):
    builtin = read(refs["child"]["path"])
    builtin_dir = Path(refs["builtin_directory"])
    builtin_receipts = [
        json.loads(line)
        for line in (builtin_dir / "results/scheduler-receipts.jsonl")
        .read_text()
        .splitlines()
    ]
    outputs = compare_outputs(builtin, report)
    schedule = compare_schedule(builtin, builtin_receipts, report, receipts)
    builtin_rows = checks.four(
        read(builtin_dir / "results/prefix-batch-14.json")["rows"]
    )
    external_rows = checks.four(report["external_layout_final"])
    geometry = []
    for rank in range(4):
        a = normalize_cohorts(builtin, builtin_rows[rank]["recent_cohorts"])
        b = normalize_cohorts(report, external_rows[rank]["cohorts"])
        difference = first_difference(a, b)
        if difference and difference["kind"] == "token":
            difference["kind"] = "cohort_metadata"
        geometry.append(
            {
                "rank": rank,
                "equal": difference is None,
                "builtin_cohorts": len(a),
                "external_cohorts": len(b),
                "first_difference": difference,
            }
        )
    answers = compare_answers(builtin, report, bundle)
    return {
        "passed": outputs["all_32_equal"]
        and schedule["equal"]
        and all(r["equal"] for r in geometry)
        and answers["all_scores_equal"],
        "complete_outputs": outputs,
        "schedule": schedule,
        "per_rank_collective_geometry": geometry,
        "answers": answers,
        "scope": "Port/history diagnostic equivalence only. Collection remains qualified when legitimate trajectories or natural durations differ; no full200/performance/candidate acceptance claim.",
    }
