"""Terminal-first external/builtin posterior32 comparison; no model execution."""

import argparse
import json
from pathlib import Path

import external_bridge_analysis_v1 as core


def analyze(run, bundle, output):
    core.require(not output.exists(), "Refuse to overwrite a prior bridge assessment")
    result = {
        "schema": "muxpd-q40-external-posterior32-analysis-v1",
        "passed": False,
        "runtime_collection_qualified": False,
        "port_equivalence_passed": None,
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "errors": [],
        "scope": "One same-source external posterior32 control. Assessment success is not answer-quality or port-equivalence success. Failed builtin01741 retained; no full200 attempt.",
    }
    try:
        proof, report, receipts, refs = core.qualify_external(run, bundle)
        result["qualification"] = proof
        result["runtime_collection_qualified"] = True
        result["comparison"] = core.compare_qualified(report, receipts, refs, bundle)
        result["port_equivalence_passed"] = result["comparison"]["passed"]
        result["passed"] = True
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.run, args.bundle, args.output)
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "passed",
                    "runtime_collection_qualified",
                    "port_equivalence_passed",
                    "full_quality_gate_attempted",
                    "errors",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
