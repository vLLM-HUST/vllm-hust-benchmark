set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export ASCEND_RT_VISIBLE_DEVICES=0,1
export PYTHONPATH=/root/.cache/pyramidkv-qwen35-pool456704-20261104/candidate-overlay:$PYTHONPATH
export SERVE_PORT=8016
export PYRAMIDKV_CONFIG=/root/.cache/pyramidkv-qwen35-pool456704-20261104/pyramidkv.json
unset VLLMHUST_EXT_ENABLED_BUNDLES VLLM_EXTENSION_MANIFESTS VLLM_EXTENSION_BUNDLES VLLM_ASCEND_KVCOMPRESS_ENABLED VLLM_ASCEND_KVCOMPRESS_CONFIG VLLM_ASCEND_PYRAMIDKV_EXPERIMENTAL_MTP2 VLLM_ASCEND_PYRAMIDKV_BATCHED_METADATA
python -c 'import vllm_ascend_pyramidkv as p; assert p.__file__.startswith("/root/.cache/pyramidkv-qwen35-pool456704-20261104/candidate-overlay/"); assert p.__version__=="0.4.0rc2.dev0"; print("Candidate:",p.__file__,p.__version__,flush=True)'
exec bash /root/.cache/pyramidkv-qwen35-pool456704-20261104/serve.sh
