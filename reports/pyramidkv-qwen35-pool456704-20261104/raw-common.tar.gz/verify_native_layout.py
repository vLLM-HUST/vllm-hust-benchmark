"""Check native pool layout labels independently of derived performance metrics."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
result={}
for row in json.loads((ROOT/'contract.json').read_text())['lifecycles']:
 out=ROOT/'runs'/row['name'];views=[]
 for name in ('startup-metrics.prom','final-metrics.prom'):
  lines=re.findall(r'^vllm:cache_config_info\{([^\n]+)\} \S+$',(out/name).read_text(),re.MULTILINE)
  assert len(lines)==1
  labels=dict(re.findall(r'(?:^|,)(\w+)="([^"]*)"',lines[0]))
  expected={'num_gpu_blocks':'558','num_gpu_blocks_override':'558','block_size':'2048','kv_cache_size_tokens':'457113','kv_cache_max_concurrency':'55.8','mamba_page_size_padded':'2121728','mamba_cache_mode':'align','mamba_block_size':'2048'}
  assert {k:labels[k] for k in expected}==expected,(row['name'],name,labels)
  views.append(expected)
 assert views[0]==views[1]
 result[row['name']]={**views[0],'shared_tensor_slots_from_pinned_geometry':10,'pool_tensor_bytes_per_rank':558*2121728*10}
(ROOT/'native-layout.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
