import json,time
from pathlib import Path
r=Path(__file__).resolve().parent
print(time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()))
for out in sorted((r/'runs').glob('*')):
 print(out.name,{name:(out/name).exists() for name in ['ready.json','completion.json','failure.json','shutdown.json']})
 for name in ['failure.json','pool-confirmation.json']:
  if (out/name).exists():print(name,(out/name).read_text().strip())
 telemetry=out/'evaluation/telemetry.jsonl'
 if telemetry.exists():
  with telemetry.open('rb') as f:
   f.seek(max(0,telemetry.stat().st_size-65536));lines=f.read().splitlines()
  for line in reversed(lines):
   try:sample=json.loads(line)
   except ValueError:continue
   if 'metrics' in sample:
    keys=['num_requests_running','num_requests_waiting','kv_cache_usage_perc','num_preemptions_total']
    print('stage',sample.get('stage'),{k:v for k,v in sample['metrics'].items() if any(k.split('{')[0]=='vllm:'+x for x in keys)});break
  print('long completed',len(list((out/'evaluation/long').glob('long-*.result.json'))))
 else:
  log=out/'server.log'
  if log.exists():print('\n'.join(log.read_text(errors='replace').splitlines()[-2:]))
