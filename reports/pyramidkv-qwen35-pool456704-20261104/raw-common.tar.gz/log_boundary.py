"""Keep native teardown exceptions distinct from serving-time failures."""
def check_errors(log):
 before,marker,after=log.partition('[shutdown]')
 if ' ERROR ' in before:
  raise ValueError('Serving-time error before shutdown')
 errors=[line for line in after.splitlines() if ' ERROR ' in line]
 if errors:
  if not marker or 'MPClient: complete' not in after or 'AsyncLLM output_handler failed.' not in after or 'EngineDeadError:' not in after:
   raise ValueError('Unrecognized shutdown error')
  if any('[async_llm.py:704]' not in line for line in errors):
   raise ValueError('Unexpected shutdown error outside known native output handler')
 return len(errors)
