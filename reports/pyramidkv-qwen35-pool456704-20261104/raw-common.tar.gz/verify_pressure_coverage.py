"""Verify server-side concurrency and report telemetry coverage, without changing metrics."""
import json
from pathlib import Path
from analyze import value
ROOT=Path(__file__).resolve().parent
result={}
for contract,selection in [('contract.json',slice(None))]:
 for row in json.loads((ROOT/contract).read_text())['lifecycles'][selection]:
  out=ROOT/'runs'/row['name']/'evaluation';group=json.loads((out/'long/group.json').read_text())
  lines=[json.loads(x) for x in (out/'telemetry.jsonl').read_text().splitlines()]
  during=[x for x in lines if group['start']<=x['t']<=group['end']]
  samples=[x for x in during if 'metrics' in x]
  peak=max(value(x,'num_requests_running')+value(x,'num_requests_waiting') for x in samples)
  assert peak==row['concurrency'],(row['name'],peak,row['concurrency'])
  first_completion=min(x['end'] for x in group['results'])
  assert any(x['t']<first_completion and value(x,'num_requests_running')+value(x,'num_requests_waiting')==row['concurrency'] for x in samples),row['name']
  result[row['name']]={'peak_server_running_plus_waiting':peak,'all_requests_admitted_before_first_completed':True,'telemetry_error_samples':sum('error' in x for x in during),'max_metric_sample_gap_seconds':max(b['t']-a['t'] for a,b in zip(samples,samples[1:])),'request_start_spread_seconds':max(x['start'] for x in group['results'])-min(x['start'] for x in group['results'])}
(ROOT/'pressure-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
