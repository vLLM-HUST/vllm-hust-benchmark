"""Real-log integrity regressions for reporting incomplete compression coverage."""
import importlib,json,os,re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
AUDIT=importlib.import_module(os.environ.get('AUDIT_MODULE','audit'))
LOG=(ROOT/'runs/qwen35-on-558/server.log').read_text()
IDS=['long-readiness']+[r['id'] for r in json.loads((ROOT/'qwen35-requests.json').read_text())['long']]
class TransactionAudit(unittest.TestCase):
 def test_observed_subset_is_counted_without_inventing_missing_commit(self):
  self.assertEqual(AUDIT.transactions(LOG,'qwen35',IDS),128)
 def test_rejects_missing_rank_ack(self):
  bad=re.sub(r'^.*worker commit acknowledged[^\n]+\n','',LOG,count=1,flags=re.M)
  with self.assertRaises(ValueError):AUDIT.transactions(bad,'qwen35',IDS)
 def test_rejects_duplicate_commit(self):
  line=next(x for x in LOG.splitlines() if 'scheduler commit request_id=' in x)
  with self.assertRaises(ValueError):AUDIT.transactions(LOG+'\n'+line,'qwen35',IDS)
 def test_rejects_unknown_request(self):
  with self.assertRaises(ValueError):AUDIT.transactions(LOG.replace('cmpl-long-readiness-0-','cmpl-unknown-0-'),'qwen35',IDS)
 def test_rejects_wrong_geometry(self):
  with self.assertRaises(ValueError):AUDIT.transactions(LOG.replace('physical_tokens=2048','physical_tokens=1024',1),'qwen35',IDS)
 def test_rejects_malformed_commit(self):
  with self.assertRaises(ValueError):AUDIT.transactions(LOG+'\nscheduler commit request_id=malformed','qwen35',IDS)
if __name__=='__main__':unittest.main()
