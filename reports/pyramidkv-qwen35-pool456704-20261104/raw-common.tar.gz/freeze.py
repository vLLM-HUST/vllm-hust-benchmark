import hashlib,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
c=json.loads((root/'contract-draft.json').read_text())
for name,commit in [('vllm',c['core_commit']),('vllm-ascend',c['ascend_commit'])]:
 repo=Path('/root/workspace/pyramidkv-runtime/src')/name
 assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==commit
 assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
for path,stat in c['model_stats'].items():
 s=Path(path).stat();assert [s.st_size,s.st_mtime_ns]==stat,path
for model,n in [('qwen35',128)]:
 r=json.loads((root/f'{model}-requests.json').read_text());assert [len(r[k]) for k in ('short','long')]==[48,n]
c['files_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='contract-draft.json' and p.suffix!='.log'}
c['created_at']=time.time()
(root/'contract.json').write_text(json.dumps(c,indent=2)+'\n')
print(hashlib.sha256((root/'contract.json').read_bytes()).hexdigest(),len(c['files_sha256']),'frozen files')
