"""Run every frozen lifecycle in order; retain failures and owned process cleanup."""
import fcntl,hashlib,json,os,signal,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8015'
CLIENT=urllib.request.build_opener(urllib.request.ProxyHandler({}))
PYTHON='/root/workspace/pyramidkv-runtime/venv/bin/python'
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def health():
 try:return CLIENT.open(BASE+'/health',timeout=2).status==200
 except OSError:return False
def validate():
 c=json.loads((ROOT/'contract.json').read_text())
 for relative,sha in c['files_sha256'].items():
  if digest(ROOT/relative)!=sha:raise RuntimeError('Frozen file changed: '+relative)
 for path,sha in c['host_files_sha256'].items():
  if digest(Path(path))!=sha:raise RuntimeError('Host file changed: '+path)
 for path,stat in c['model_stats'].items():
  s=Path(path).stat()
  if [s.st_size,s.st_mtime_ns]!=stat:raise RuntimeError('Model changed: '+path)
 return c
def run(name,enabled):
 contract=validate()
 npu=subprocess.check_output(['npu-smi','info'],text=True)
 if npu.count('No running processes found')!=2 or health():raise RuntimeError('Device or port occupied')
 out=ROOT/'runs'/name;out.mkdir(parents=True,exist_ok=False)
 (out/'npu-before.txt').write_text(npu)
 env=os.environ.copy();env['PYRAMIDKV_ENABLED']=str(int(enabled))
 with (out/'server.log').open('wb') as log:
  server=subprocess.Popen(['bash',str(ROOT/'launch.sh')],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  write(out/'process.json',{'pid':server.pid,'start_ticks':Path(f'/proc/{server.pid}/stat').read_text().split()[21],'at':time.time(),'enabled':enabled,'contract_sha256':digest(ROOT/'contract.json')})
  print('START',name,server.pid,flush=True)
  try:
   start=time.monotonic()
   while time.monotonic()-start<900:
    if server.poll() is not None:raise RuntimeError(f'Server startup exited {server.returncode}')
    if health():break
    time.sleep(2)
   else:raise RuntimeError('Startup timeout 900s')
   write(out/'ready.json',{'at':time.time()});print('READY',name,flush=True)
   with (out/'client.log').open('wb') as clientlog:
    client=subprocess.Popen([PYTHON,str(ROOT/'measure.py'),'--requests',str(ROOT/'requests.json'),'--output',str(out/'evaluation')],stdout=clientlog,stderr=subprocess.STDOUT)
    try:
     code=client.wait(timeout=3600)
     if code:raise RuntimeError(f'Client exited {code}')
    finally:
     if client.poll() is None:
      client.terminate()
      try:client.wait(timeout=30)
      except subprocess.TimeoutExpired:client.kill();client.wait(timeout=10)
   summaries=json.loads((out/'evaluation/summary.json').read_text())
   if [r['requests'] for r in summaries]!=[48,32]:raise RuntimeError('Wrong request count')
   write(out/'completion.json',{'at':time.time(),'measured_requests':80,'readiness_requests':2})
   print('COMPLETE',name,json.dumps(summaries[-1]),flush=True)
  except BaseException as e:
   write(out/'failure.json',{'at':time.time(),'type':type(e).__name__,'message':str(e)});raise
  finally:
   try:os.killpg(server.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:server.wait(timeout=35)
   except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
   write(out/'shutdown.json',{'at':time.time(),'returncode':server.returncode})
   (out/'npu-after.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True))
if __name__=='__main__':
 lock=(ROOT/'lifecycle.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for row in validate()['lifecycles']:run(row['name'],row['enabled'])
