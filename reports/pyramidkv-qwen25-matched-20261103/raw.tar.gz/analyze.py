"""Recompute every request from timestamped SSE and all six arm means."""
import hashlib,json,re,statistics,sys
from pathlib import Path
import measure
ROOT=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def value(row,key):
 vals=[v for k,v in row.get('metrics',{}).items() if k.split('{')[0]=='vllm:'+key]
 if len(vals)!=1:raise ValueError(('Missing/ambiguous metric',key,vals))
 return vals[0]
def hbm(text):
 lines=text.splitlines()
 for i,line in enumerate(lines):
  if re.match(r'\|\s*6\s+910B2',line):
   match=re.search(r'(\d+)\s*/\s*65536\s*\|',lines[i+1]);assert match;return int(match.group(1))
 raise ValueError('Missing physical card6 HBM')
def verify_run(name,enabled,requests):
 out=ROOT/'runs'/name
 completion=json.loads((out/'completion.json').read_text());assert completion['measured_requests']==80
 telemetry=[json.loads(x) for x in (out/'evaluation/telemetry.jsonl').read_text().splitlines()]
 summaries=json.loads((out/'evaluation/summary.json').read_text())
 assert json.loads((out/'evaluation/identity.json').read_text())['requests_sha256']==digest(ROOT/'requests.json')
 log=(out/'server.log').read_text()
 assert ('PyramidKV plugin activated' in log)==enabled
 assert not re.search(r'ERROR.*(?:fatal|Traceback|failed)',log.split('[shutdown]')[0])
 tokens=int(re.search(r'GPU KV cache size: ([\d,]+) tokens',log).group(1).replace(',',''))
 sched=re.findall(r'scheduler commit request_id=(\S+) semantic_tokens=(\d+) physical_tokens=(\d+) source_blocks=(\d+) destination_blocks=(\d+)',log)
 worker=re.findall(r'worker commit acknowledged request_id=(\S+) semantic_tokens=(\d+) physical_tokens=(\d+) destination_blocks=(\d+)',log)
 assert sorted((a,b,c,e) for a,b,c,d,e in sched)==sorted(worker)
 if enabled:
  assert len(sched)==33,(name,len(sched))
  assert all((b,c,d,e)==('7168','1024','56','8') for a,b,c,d,e in sched)
 else:assert not sched
 result={'name':name,'enabled':enabled,'kv_pool_tokens':tokens,'kv_pool_blocks':tokens//128,'kv_pool_gib':tokens*48*8*128*2*2/2**30,'transactions':len(sched),'groups':{}}
 for kind in ('short','long'):
  folder=out/'evaluation'/kind;g=json.loads((folder/'group.json').read_text());rows=[]
  assert len(g['results'])==len(requests[kind])
  for expected,stored in zip(requests[kind],g['results']):
   artifact=json.loads((folder/(expected['id']+'.events.json')).read_text());assert artifact['request']==expected
   raw=(folder/(expected['id']+'.sse')).read_bytes();data=[]
   for line in raw.splitlines():
    if line.startswith(b'data: '):
     payload=line[6:].strip();data.append('[DONE]' if payload==b'[DONE]' else json.loads(payload))
   assert data==[e['data'] for e in artifact['events']]
   computed=measure.request_metrics(artifact['events'],artifact['start'],expected['input_tokens'],expected['payload']['max_tokens'])
   assert stored['success'] and stored['id']==expected['id']
   for key,val in computed.items():assert stored[key]==val,(name,expected['id'],key)
   rows.append(computed)
  computed=measure.group_metrics(rows,g['end']-g['start']);original=next(x for x in summaries if x['kind']==kind)
  for k,v in computed.items():assert original[k]==v,(name,kind,k)
  samples=[x for x in telemetry if g['start']<=x['t']<=g['end'] and 'metrics' in x];assert samples
  prior=[x for x in telemetry if x['t']<g['start'] and 'metrics' in x];assert prior
  computed['kv_peak_fraction']=max(value(x,'kv_cache_usage_perc') for x in samples)
  computed['preemptions']=max(value(x,'num_preemptions_total') for x in samples)-value(prior[-1],'num_preemptions_total')
  memory=[hbm(x['npu_smi']) for x in samples if 'npu_smi' in x];assert memory
  computed['hbm_peak_mib']=max(memory)
  computed['peak_running']=max(value(x,'num_requests_running') for x in samples)
  computed['peak_waiting']=max(value(x,'num_requests_waiting') for x in samples)
  computed['telemetry_samples']=len(samples)
  result['groups'][kind]=computed
 final=next(x for x in reversed(telemetry) if 'metrics' in x)
 assert value(final,'num_requests_running')==0 and value(final,'num_requests_waiting')==0
 assert 'No running processes found in NPU 6' in (out/'npu-after.txt').read_text()
 return result

def main():
 contract=json.loads((ROOT/'contract.json').read_text());requests=json.loads((ROOT/'requests.json').read_text())
 for relative,sha in contract['files_sha256'].items():assert digest(ROOT/relative)==sha,relative
 runs=[verify_run(row['name'],row['enabled'],requests) for row in contract['lifecycles']]
 aggregates={}
 for arm in ('off','on'):
  rows=[x['groups']['long'] for x in runs if x['enabled']==(arm=='on')];assert len(rows)==3
  aggregates[arm]={key:statistics.mean(x[key] for x in rows) for key in rows[0] if isinstance(rows[0][key],(int,float))}
 changes={key:100*(aggregates['on'][key]/aggregates['off'][key]-1) if aggregates['off'][key] else None for key in aggregates['off']}
 result={'contract_sha256':digest(ROOT/'contract.json'),'runs':runs,'long_aggregates':aggregates,'long_percent_change':changes,'verified_measured_requests':480,'verification':'Raw SSE equals timestamped events; exact frozen request payloads and usage; independent metric recomputation; scheduler-worker correspondence; zero final active requests; physical device free after shutdown.'}
 (ROOT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'aggregates':aggregates,'changes':changes},indent=2))
if __name__=='__main__':main()
