"""Execute the pinned legacy generator's AST without unrelated dataset imports."""
import ast, hashlib, json, logging, math
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from transformers import AutoTokenizer
ROOT=Path(__file__).resolve().parent
PINS={'legacy-datasets.py':'3b2ca59e8f9ece9b53d418ddf0b29d38f077ee8118559552cfdcf907973ab099','legacy-utils.py':'14efee4c78ea60b38e1be458c192ff1972c3295dbebe91bacff414ebcf89c3b6'}
class Base:
 def __init__(self,random_seed):self.random_seed=random_seed
 def get_lora_request(self,**kw):
  assert kw['max_loras'] is None and kw['lora_path'] is None
  return None
ns={'np':np,'math':math,'logger':logging.getLogger(), 'BenchmarkDataset':Base,'SampleRequest':SimpleNamespace}
for name,names in [('legacy-utils.py',{'_resolve_range_ratios','get_sampling_params'}),('legacy-datasets.py',{'gen_prompt_decode_to_target_len','RandomDataset'})]:
 raw=(ROOT/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==PINS[name]
 tree=ast.parse(raw);nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 assert len(nodes)==len(names)
 code='from __future__ import annotations\n'+'\n'.join(ast.unparse(n) for n in nodes)
 exec(compile(code,name,'exec'),ns)
tok=AutoTokenizer.from_pretrained('/data/shared_models/Qwen2.5-14B-Instruct',local_files_only=True)
result={}
for kind,n,isl,osl in [('short',48,1024,256),('long',32,7168,512)]:
 rows=ns['RandomDataset'](random_seed=0).sample(tok,n,input_len=isl,output_len=osl,range_ratio=0.0)
 np.random.seed(0)
 delays=np.cumsum(np.random.gamma(shape=1,scale=1,size=n)) if kind=='short' else np.zeros(n)
 if kind=='short':delays*=n/delays[-1]
 result[kind]=[]
 for i,r in enumerate(rows):
  ids=tok.encode(r.prompt,add_special_tokens=False);assert len(ids)==isl,(i,len(ids))
  payload={'model':'qwen25-pyramidkv','prompt':r.prompt,'repetition_penalty':1.0,'max_tokens':osl,'logprobs':None,'stream':True,'stream_options':{'include_usage':True},'ignore_eos':True}
  result[kind].append({'id':f'{kind}-{i:02d}','input_tokens':isl,'token_ids_sha256':hashlib.sha256(json.dumps(ids).encode()).hexdigest(),'delay_seconds':float(delays[i]),'payload':payload})
(ROOT/'requests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print({k:len(v) for k,v in result.items()},hashlib.sha256((ROOT/'requests.json').read_bytes()).hexdigest())
