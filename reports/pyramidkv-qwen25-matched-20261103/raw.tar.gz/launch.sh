set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export ASCEND_RT_VISIBLE_DEVICES=1
export PYTHONPATH=/root/.cache/pyramidkv-qwen25-20261103/candidate-overlay:$PYTHONPATH
export MODEL_PATH=/data/shared_models/Qwen2.5-14B-Instruct SERVE_PORT=8015
export PYRAMIDKV_CONFIG=/root/.cache/pyramidkv-qwen25-20261103/pyramidkv.json
unset VLLMHUST_EXT_ENABLED_BUNDLES VLLM_EXTENSION_MANIFESTS VLLM_EXTENSION_BUNDLES VLLM_ASCEND_KVCOMPRESS_ENABLED VLLM_ASCEND_KVCOMPRESS_CONFIG VLLM_ASCEND_PYRAMIDKV_EXPERIMENTAL_MTP2 VLLM_ASCEND_PYRAMIDKV_BATCHED_METADATA
python -c 'import vllm_ascend_pyramidkv as p; assert p.__file__.startswith("/root/.cache/pyramidkv-qwen25-20261103/candidate-overlay/"); print("Candidate:",p.__file__,p.__version__,flush=True)'
exec bash /root/.cache/pyramidkv-qwen25-20261103/serve.sh
