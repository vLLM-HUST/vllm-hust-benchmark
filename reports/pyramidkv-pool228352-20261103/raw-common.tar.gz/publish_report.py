"""Package the fixed-capacity experiment after raw-stream verification."""
import gzip,hashlib,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPORT=Path('/tmp/pyramidkv-pool-delivery/reports/pyramidkv-pool228352-20261103')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 a=json.loads((ROOT/'analysis.json').read_text());c=json.loads((ROOT/'contract.json').read_text());prior=json.loads((ROOT/'prior-c64-analysis.json').read_text())
 assert a['verified_measured_requests']==224 and a['verified_readiness_requests']==4
 assert a['contract_sha256']==sha(ROOT/'contract.json')
 REPORT.mkdir(parents=True,exist_ok=False)
 for name in ['analysis.json','pressure-coverage.json']:shutil.copyfile(ROOT/name,REPORT/name)
 x=a['models']['qwen25'];g=x['long_aggregates'];table=['| Metric | OFF | ON | Change |','| --- | ---: | ---: | ---: |']
 for label,key,factor in [('Output throughput (tokens/s)','output_token_throughput',1),('Mean TTFT (s)','mean_ttft_ms',.001),('Median TTFT (s)','p50_ttft_ms',.001),('p95 TTFT (s)','p95_ttft_ms',.001),('Mean TPOT (ms)','mean_tpot_ms',1),('Mean request E2E (s)','mean_e2e_ms',.001),('Peak active KV (%)','kv_peak_fraction',100),('Peak simultaneous two-card HBM (MiB)','hbm_peak_mib_sum',1)]:
  table.append(f'| {label} | {g["off"][key]*factor:,.2f} | {g["on"][key]*factor:,.2f} | {x["long_percent_change"][key]:+.2f}% |')
 runs={r['enabled']:r for r in a['runs']};table.append(f'| Exact lifecycle preemptions | {runs[False]["lifecycle_preemptions_total"]:.0f} | {runs[True]["lifecycle_preemptions_total"]:.0f} | — |')
 old=prior['models']['qwen25'];comparison=['| Configured pool | Physical cards | OFF tokens/s | ON tokens/s | ON throughput change |','| --- | --- | ---: | ---: | ---: |']
 for capacity,cards,data in [(373248,'1/6 (previous)',old),(228352,'2/3 (current, user-approved)',x)]:
  ag=data['long_aggregates'];comparison.append(f'| {capacity:,} tokens | {cards} | {ag["off"]["output_token_throughput"]:.2f} | {ag["on"]["output_token_throughput"]:.2f} | {data["long_percent_change"]["output_token_throughput"]:+.2f}% |')
 (REPORT/'README.md').write_text(f'''# PyramidKV Qwen2.5 TP2 C64 with 228352 token cache capacity

**One OFF/ON pair, Eager diagnostic, excluded from official leaderboards.**
The user requested retaining TP2/C64, prompts, batch budget and plugin version while reducing
both arms' native effective KV capacity from 373,248 to 228,352 token slots.
The only serving-argument change is `--num-gpu-blocks-override 1784`: both arms verify
1784 native blocks, 128-token pages and 228,352 reported effective token capacity before
sending any measured request, and verify the same native configuration after completion.

The current container exposes physical cards 2/3 instead of the prior run's 1/6. Both are
64 GiB Ascend910B2 cards and the user explicitly approved this substitution. The current
OFF/ON pair uses the same two cards; comparisons with the previous pool size also include
this device change and cannot establish a strict pool-size-only causal effect.

Enabling PyramidKV in this pair increased output throughput by56.20%, reduced mean TTFT
by46.88% and median TTFT by62.58%, and changed peak active KV occupancy from100% to43.07%.
Exact lifecycle preemptions fell from5 to0. Mean TPOT increased35.43%, while mean request
E2E changed by−0.57%, effectively similar in this single observation. The result therefore
combines higher batch throughput and earlier first tokens with slower subsequent tokens.

{chr(10).join(table)}

## Comparison with the previous C64 pair

{chr(10).join(comparison)}

The [previous report](https://github.com/vLLM-HUST/vllm-hust-benchmark/tree/8afbf04a57963dcefd5c9f1bb54556a023173740/reports/pyramidkv-pressure-20261103)
is immutable. Its original analysis is included for reference, with SHA256
`{sha(ROOT/'prior-c64-analysis.json')}`. The two capacity settings were not rerun together
on the current physical cards. A single pair does not quantify run-to-run variance.

## Preserved settings and input identity

Qwen2.5-14B-Instruct, TP2/PP1, BF16, 64 maximum sequences and simultaneous long requests,
7168 input tokens and 512 forced output tokens, context8192, batch-token budget4096,
utilization0.8, seed0, APC, async scheduling, chunked prefill, Eager, no MTP, and
`generation-config=vllm` remain as in the prior C64 pair. Each fresh lifecycle first
receives48 short1024/256 requests at rate1, then64 long requests at rate infinity;
one separate first-prompt readiness request precedes each cohort. There are224 measured
requests and4 readiness requests in total. No additional valid rounds are selected.

The exact prior C64 request file, algorithm config, client and candidate wheel are reused.
Request SHA256: `{sha(ROOT/'qwen25-requests.json')}`. The original C64 client is retained
byte for byte; its100-connection ceiling does not bind64 requests plus telemetry.
`pressure-coverage.json` verifies64 server-side running-plus-waiting requests before any
completion and reports all telemetry errors and maximum sampling gaps.

Candidate wheel version0.4.0rc2.dev0, source `{c['candidate_source_commit']}`;
core `{c['core_commit']}`, Ascend `{c['ascend_commit']}`.
Runtime remains CANN9.1, Torch2.10.0+cpu, torch-npu2.10.0.post4, transformers5.14.1.
Installed vLLM metadata0.23.0+empty and Ascend0.23.0.post1 are distinct from the prepared
ABI selector `VLLM_VERSION=0.25.1`. All package versions, model size/mtime pins and clean
native source commits were rechecked before freezing. CPU quota remains8 cores and host
memory limit64 GiB. Startup-only checkpoint file-cache eviction is recorded; it does not
run during inference.

Algorithm settings remain capacity512/beta20/window8/kernel7/maxpool, KV-head/mean GQA,
no merge, and prompt admission above4096 tokens. For7168-token prompts, dense compressed
allocation remains1024 physical tokens (8 pages); layer-specific selected lengths are
separate from this physical allocation. Both TP ranks acknowledge every admitted commit.

Contract SHA256: `{a['contract_sha256']}`. The parameter override changes native allocation
and admission capacity; it does not alter the algorithm, batch budget or request texts.

## Pool memory and metric definitions

Configured token capacity is1784×128. With48 attention layers, 4 local KV heads per TP
rank, head dimension128, separate K/V and BF16, each native block occupies12 MiB per rank.
Thus the configured KV tensors occupy20.90625 GiB per rank, versus34.171875 GiB at2916
blocks. These tensor bytes are derived from pinned model geometry; total device HBM is
measured separately and includes weights, workspace and runtime allocations. The worker's
`Available KV cache memory` log is its profiled budget, not the overridden allocation.

KV usage is active block occupancy inside this configured pool. HBM peaks are sampled
on physical cards2/3; their sum is the peak simultaneous sampled sum. Metrics are sampled
about every0.2s and HBM about every2s, so peaks can miss events between samples. Exact
preemption totals span the whole fresh lifecycle, including readiness and the short prelude;
cohort sampled preemption lower bounds are separately labeled in analysis.json.

TTFT ends at the first choice event, including an empty choice. E2E ends at the last
choice, excluding usage/DONE. TPOT divides the interval after first choice by output tokens
minus one. Cohort throughput uses output tokens divided by cohort wall time. Latency means,
median and p95 plus per-request data are retained. Synchronous artifact writes and telemetry
add common overhead. This synthetic run provides no task-quality evidence.

## Originals and offline verification

The capsule retains frozen inputs, launchers, wheel, source/model identities, both complete
server logs, SSE streams, timestamped events, request results, telemetry and cleanup receipts.
Every measured/readiness request is verified for exact payload and token usage, raw SSE/event
correspondence and recomputed timing. Both startup and final pool configurations must match
the requested target. Final active/waiting counts must be zero and both devices free.
Known native output-handler teardown errors are distinguished from serving errors.

`SHA256SUMS` verifies public files; `members.json.gz` identifies every archived member.
Use Python3.12 or newer, CPU only, without installing model/runtime packages:

```sh
python verify.py
```

The verifier safely extracts originals, checks all hashes, recomputes request/aggregate metrics,
TP-rank commits, pool identity and actual concurrency, then byte-compares the published analysis
and coverage. Public pinned-commit files are read back and verified after upload.
''')
 members={}
 def archive(name,paths):
  with tarfile.open(REPORT/name,'w:gz',compresslevel=6) as tar:
   for p in sorted(paths):
    rel=str(p.relative_to(ROOT));assert rel not in members;members[rel]={'bytes':p.stat().st_size,'sha256':sha(p),'archive':name}
    info=tar.gettarinfo(str(p),arcname=rel);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
    with p.open('rb') as f:tar.addfile(info,f)
  assert (REPORT/name).stat().st_size<50*2**20
 common=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and (len(p.relative_to(ROOT).parts)==1 or p.relative_to(ROOT).parts[0] in ('candidate-overlay','wheels')) and p.name!='lifecycle.lock']
 archive('raw-common.tar.gz',common)
 for run in sorted((ROOT/'runs').iterdir()):archive('raw-'+run.name+'.tar.gz',[p for p in run.rglob('*') if p.is_file()])
 (REPORT/'members.json.gz').write_bytes(gzip.compress(json.dumps(members,sort_keys=True,indent=2).encode(),mtime=0))
 shutil.copyfile(ROOT/'verify_public.py',REPORT/'verify.py')
 (REPORT/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(REPORT.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
 print(REPORT,len(members),sum(p.stat().st_size for p in REPORT.iterdir()))
if __name__=='__main__':main()
