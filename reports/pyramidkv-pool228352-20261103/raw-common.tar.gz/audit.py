"""Offline checks for the fixed two-rank model comparison evidence."""

import re
from collections import Counter


def transactions(log, model, expected_request_ids):
    scheduler = re.findall(
        r"scheduler commit request_id=(\S+) semantic_tokens=(\d+) physical_tokens=(\d+) "
        r"source_blocks=(\d+) destination_blocks=(\d+)",
        log,
    )
    worker = re.findall(
        r"worker commit acknowledged request_id=(\S+) semantic_tokens=(\d+) physical_tokens=(\d+) "
        r"destination_blocks=(\d+) worker_rank=(\d+)",
        log,
    )
    if len(scheduler) != len(expected_request_ids):
        raise ValueError("Unexpected scheduler transaction count")
    if log.count("worker commit acknowledged request_id=") != len(worker):
        raise ValueError("Unparseable worker acknowledgement")
    request_ids = [row[0] for row in scheduler]
    if len(set(request_ids)) != len(request_ids):
        raise ValueError("Duplicate scheduler commit")
    for expected in expected_request_ids:
        if sum(request.startswith(f"cmpl-{expected}-0-") for request in request_ids) != 1:
            raise ValueError(f"Missing or duplicate request transaction: {expected}")
    geometry = {"qwen25": ("7168", "1024", "56", "8"), "qwen35": ("7168", "2048", "4", "1")}[model]
    if any(tuple(row[1:]) != geometry for row in scheduler):
        raise ValueError("Unexpected model compression geometry")
    expected_workers = Counter(
        (request, semantic, physical, destination, rank)
        for request, semantic, physical, source, destination in scheduler
        for rank in ("0", "1")
    )
    if Counter(worker) != expected_workers:
        raise ValueError("Scheduler commit lacks exactly one matching acknowledgement from each TP rank")
    return len(scheduler)


def hbm(text):
    result = {}
    lines = text.splitlines()
    for index, line in enumerate(lines[:-1]):
        card = re.match(r"\|\s*(2|3)\s+910B2\b", line)
        if card:
            used = re.search(r"(\d+)\s*/\s*65536\s*\|", lines[index + 1])
            if used:
                result[card.group(1)] = int(used.group(1))
    if result.keys() != {"2", "3"}:
        raise ValueError("Missing physical card2 or card3 HBM")
    return result


def pool(metrics):
    rows = re.findall(r"^vllm:cache_config_info\{([^\n]+)\} \S+$", metrics, re.MULTILINE)
    if len(rows) != 1:
        raise ValueError("Missing or ambiguous native cache configuration")
    labels = dict(re.findall(r'(?:^|,)(\w+)="([^"]*)"', rows[0]))
    try:
        return {
            "physical_blocks": int(labels["num_gpu_blocks"]),
            "logical_block_size": int(labels["block_size"]),
            "effective_capacity_tokens": int(labels["kv_cache_size_tokens"]),
            "max_concurrency_at_max_model_len": float(labels["kv_cache_max_concurrency"]),
        }
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("Incomplete native cache configuration") from error
