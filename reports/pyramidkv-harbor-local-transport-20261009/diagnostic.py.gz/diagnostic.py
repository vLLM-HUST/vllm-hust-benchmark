"""One synthetic Harbor transport diagnostic; no task environment or benchmark score."""
import asyncio
import dataclasses
import hashlib
import json
import os
import time
from pathlib import Path

root = Path('/root/workspace/pyramidkv-runtime')
assert json.loads((root / 'performance/dedicated-state.json').read_text())['status'] == 'complete', 'Do not interfere with the dedicated performance series'
os.environ['LITELLM_LOCAL_MODEL_COST_MAP'] = 'True'
os.environ['LITELLM_TELEMETRY'] = 'False'
os.environ['OPENAI_API_KEY'] = 'local-no-auth'
os.environ['NO_PROXY'] = 'localhost,127.0.0.1,::1'
os.environ['no_proxy'] = os.environ['NO_PROXY']
from harbor.agents.terminus_2.terminus_2 import Terminus2
from harbor.agents.terminus_2.terminus_json_plain_parser import TerminusJSONPlainParser
from harbor.llms.chat import Chat

out = root / 'dataset-program/harbor-local-transport-v1'
out.mkdir(exist_ok=False)
job_path = root / 'dataset-program/terminal-harbor-plan-v1/job-b0.json'
job = json.loads(job_path.read_text())
config = job['agents'][0]
prompt = 'This is a local API transport diagnostic, not a benchmark task. Return only this JSON object without Markdown: {"analysis":"Transport check only.","plan":"No commands are needed.","commands":[],"task_complete":true}'
receipt = {'scope': 'synthetic local transport diagnostic only; not task execution, verifier validation or B0/B1', 'started_unix': time.time(), 'job_sha256': hashlib.sha256(job_path.read_bytes()).hexdigest(), 'prompt': prompt, 'tasks_executed': 0, 'environment_setup': False, 'compression_applicability': 'short synthetic prompt does not exercise PyramidKV', 'authentication': 'local unauthenticated server, synthetic client placeholder only'}
try:
    agent = Terminus2(logs_dir=out / 'agent', model_name=config['model_name'], **config['kwargs'])
    chat = Chat(agent._llm, interleaved_thinking=False)
    async def run():
        return await asyncio.wait_for(agent._query_llm(chat, prompt), timeout=180)
    response = asyncio.run(run())
    parsed = TerminusJSONPlainParser().parse_response(response.content)
    receipt['response'] = dataclasses.asdict(response)
    if hasattr(response.usage, 'model_dump'):
        receipt['response']['usage'] = response.usage.model_dump()
    receipt['parsed'] = dataclasses.asdict(parsed)
    receipt['request_timing_count'] = len(agent._api_request_times)
    receipt['chat_messages'] = chat.messages
    receipt['status'] = 'returned'
except BaseException as exc:
    receipt['status'] = 'failed'
    receipt['error'] = type(exc).__name__ + ': ' + str(exc)
    raise
finally:
    receipt['finished_unix'] = time.time()
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2, default=str) + '\n')
print(json.dumps(receipt, indent=2, default=str))
