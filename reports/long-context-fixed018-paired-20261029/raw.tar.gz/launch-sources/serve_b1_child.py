"""Compose the qualified corrections and record real child imports before loading weights."""
def main():
    import hashlib
    import importlib.metadata
    import json
    import os
    from pathlib import Path
    import sys
    plan_path=Path(sys.argv[1]);plan=json.loads(plan_path.read_text())
    arguments=sys.argv[2:]
    assert arguments[0]=='serve' and 'vllm' not in sys.modules
    from corrected_service_entry import compose_environment
    os.environ.update(compose_environment(os.environ))
    from vllm.plugins import load_general_plugins
    load_general_plugins()
    import vllm,vllm_ascend,corrected_serving_runtime
    import betterscale.qwen35_worker as worker
    assert worker.Worker is corrected_serving_runtime.CorrectedWorker
    assert vllm.__version__==plan['expected_versions']['vllm']
    assert importlib.metadata.version('vllm_ascend')==plan['expected_versions']['vllm_ascend']
    identity=dict(role='B1',vllm_version=vllm.__version__,ascend_version=importlib.metadata.version('vllm_ascend'),
        vllm_source=vllm.__file__,ascend_source=vllm_ascend.__file__,python=sys.executable,
        plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
        worker=f'{worker.Worker.__module__}.{worker.Worker.__name__}',cann_home=os.environ.get('ASCEND_HOME_PATH'),plugins=os.environ['VLLM_PLUGINS'])
    with (Path(plan['output'])/'runtime-identity.json').open('x') as stream:
        json.dump(identity,stream,indent=2);stream.write('\n')
    sys.argv=['vllm',*arguments]
    from vllm.entrypoints.cli.main import main as cli
    cli()


if __name__=='__main__':main()
