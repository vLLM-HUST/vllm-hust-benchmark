"""Native018 serving entry; version evidence is captured before model loading."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys

plan_path = Path(sys.argv[1])
plan = json.loads(plan_path.read_text())
import vllm
import vllm_ascend
assert vllm.__version__ == importlib.metadata.version('vllm_ascend') == '0.18.0'
assert os.environ['VLLM_PLUGINS'] == 'ascend,ascend_model_loader,ascend_kv_connector'
out = Path(plan['output'])
identity = dict(vllm_version=vllm.__version__, ascend_version=importlib.metadata.version('vllm_ascend'),
    vllm_source=vllm.__file__, ascend_source=vllm_ascend.__file__, python=sys.executable,
    plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
    role='B0', cann_home=os.environ['ASCEND_HOME_PATH'], plugins=os.environ['VLLM_PLUGINS'])
with (out/'runtime-identity.json').open('x') as stream:
    json.dump(identity, stream, indent=2)
    stream.write('\n')
sys.argv = ['vllm','serve',plan['model_view'],*plan['serve_args']]
from vllm.entrypoints.cli.main import main
main()
