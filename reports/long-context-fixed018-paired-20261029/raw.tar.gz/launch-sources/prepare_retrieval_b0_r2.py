"""Fix only the entrypoint spawn guard; preserve r1 failure and all request settings."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'retrieval-b0-plan-r1.json').read_text())
for name,digest in plan['source_sha256'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
receipt=json.loads((ROOT/'retrieval-b0-r1/receipt.json').read_text())
assert receipt['status']=='failed' and receipt['all_reserved_devices_released']
assert not (ROOT/'retrieval-b0-r1/parser-qualification.json').exists()
plan.update(output=str(ROOT/'retrieval-b0-r2'),cache=str(ROOT/'retrieval-b0-cache-r2'))
plan['recovery']=dict(prior='retrieval-b0-r1',cause='Missing __main__ guard re-executed launcher during multiprocessing spawn; no requests submitted',
                     changes=['spawn-safe service entrypoint','fresh service/output/cache'],inputs_scoring_and_runtime_unchanged=True)
for name in ('serve_b0_r2.py','run_retrieval_b0_r2.py','prepare_retrieval_b0_r2.py'):
    p=ROOT/name
    plan['source_sha256'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
with (ROOT/'retrieval-b0-plan-r2.json').open('x') as stream:
    json.dump(plan,stream,indent=2);stream.write('\n')
print('R2_FROZEN_NO_REQUEST_CHANGES')
