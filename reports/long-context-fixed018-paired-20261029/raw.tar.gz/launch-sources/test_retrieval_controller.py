import json
import os
from pathlib import Path
import subprocess
import sys
import runpy

import pytest

import run_retrieval_b0 as controller


@pytest.mark.parametrize('name',['serve_b0_r2.py','serve_b1.py','serve_b1_child.py'])
def test_spawn_reimport_does_not_read_plan_or_restart_service(monkeypatch,name):
    monkeypatch.setattr(sys,'argv',['vllm','serve','unused'])
    namespace=runpy.run_path(str(controller.TASK/name),run_name='__mp_main__')
    assert callable(namespace['main'])


def test_health_status_not_case_count():
    source=Path(controller.__file__).read_text()
    assert 'response.status == 200' in source
    assert 'response.status == 6' not in source
    assert 'sampling_failures>=3' in source
    assert '/workspace' not in source


def test_foreign_container_owner_rejected():
    row=f'| 5 0 | 99999999 | worker | 42 | {os.getpid()} |'
    with pytest.raises(RuntimeError,match='Foreign'):
        controller.check_owners(row,set())
    controller.check_owners(row,{os.getpid()})


def test_existing_probes_and_salts_are_frozen():
    path=controller.SOURCE/'long-context-inputs-r1.json'
    cases=json.loads(path.read_text())['cases']
    assert len(cases)==6
    assert all(c['input_tokens']>=16384 for c in cases)
    assert len({c['request']['cache_salt'] for c in cases})==6
    assert all(c['request']['max_completion_tokens']==8192 for c in cases)


def test_owned_group_cleanup():
    child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'],start_new_session=True,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    child.owned_start_ticks=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
    result=controller.stop_group(child)
    assert result != 0
    assert child.poll() is not None
