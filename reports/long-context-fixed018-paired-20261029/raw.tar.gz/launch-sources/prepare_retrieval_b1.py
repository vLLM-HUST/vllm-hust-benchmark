"""Freeze a matched corrected-B1 retrieval arm, without changing the original inputs."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
identity=json.loads((ROOT/'b1-preflight-r2/actual-imports.json').read_text())
composition=json.loads((ROOT/'b1-preflight-r2/composition.json').read_text())
assert composition['status']=='manager_child_composition_passed'
assert json.loads((ROOT/'b1-import-r2-admission.json').read_text())['devices_released']
plan=json.loads((ROOT/'retrieval-b0-plan-r2.json').read_text())
plan.pop('recovery')
plan.pop('serve_args')
plan.update(role='B1',expected_versions=dict(vllm=identity['modules']['vllm']['version'],vllm_ascend=identity['ascend_version']),
    output=str(ROOT/'retrieval-b1-r1'),cache=str(ROOT/'retrieval-b1-cache-r1'),model_view='/models/Qwen3.5-35B-A3B',
    comparison='Same six retrieval requests, tokenizer IDs, model weights, TP2/BF16, physical cards5/6 and score as fixed018 B0. B1 uses corrected E24/R36+request recompute+Microflow on0.28.1/Ascend0.25.1rc2/CANN9.1; engine tuning may differ and is recorded. Not a continuous-stability or throughput ranking run.',
    activation_audit='Seven distinct recompute admissions including parser qualification, policy/engine salt linkage, both Microflow ranks qualified and exercised; failures retained, not called valid B1 without audit.')
sources=[Path(p) for p in plan['source_sha256'] if not Path(p).is_relative_to(ROOT)]
sources += [ROOT/name for name in ('run_retrieval_b1.py','serve_b1.py','serve_b1_child.py','prepare_retrieval_b1.py')]
sources += list(Path('/root/m01-storage-timing-runtime-20261024').glob('*.py'))
sources += [Path('/root/m01-storage-timing-runtime-20261024/runtime_boundary_b1.sh')]
plan['source_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
with (ROOT/'retrieval-b1-plan-r1.json').open('x') as stream:
    json.dump(plan,stream,indent=2);stream.write('\n')
print('B1_FROZEN_NOT_RUN',len(sources),'source identities')
