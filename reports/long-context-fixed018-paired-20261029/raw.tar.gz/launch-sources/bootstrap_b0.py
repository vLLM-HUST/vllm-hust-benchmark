"""Use only the restored official018 interpreter, compatibility overlay and CANN."""
from pathlib import Path
import runpy
import sys

B = Path('/root/m01-b0-accounting-20261024')
R = B / 'runtime'
P = R / 'unpacked/rootfs/usr/local/python3.11.14'
C = R / 'unpacked/rootfs/usr/local/Ascend/cann-8.5.1'
TASK = Path(__file__).resolve().parent
assert sys.flags.no_site and Path(sys.prefix).resolve() == P.resolve()
sys.path[:] = [str(TASK), str(B), str(R/'text-only-overlay-r1/vllm'),
    str(R/'text-only-overlay-r1/vllm-ascend'), str(P/'lib/python3.11/site-packages'),
    str(C/'python/site-packages'), str(C/'opp/built-in/op_impl/ai_core/tbe'),
    str(P/'lib/python311.zip'), str(P/'lib/python3.11'), str(P/'lib/python3.11/lib-dynload')]
target = Path(sys.argv[1]).resolve()
assert target.is_relative_to(TASK)
sys.argv = sys.argv[1:]
runpy.run_path(str(target), run_name='__main__')
