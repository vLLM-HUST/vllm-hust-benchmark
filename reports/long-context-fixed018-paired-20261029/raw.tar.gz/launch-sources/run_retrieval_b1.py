"""Own the corrected B1 service lifecycle, reusing the frozen six retrieval inputs."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.request

TASK = Path(__file__).resolve().parent
BASE = Path('/root/m01-b0-accounting-20261024')
SOURCE = Path('/root/gennova-evidence/20261019-midterm-aligned')
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def descendant(pid, roots):
    seen = set()
    while pid > 1 and pid not in seen:
        if pid in roots:
            return True
        seen.add(pid)
        try:
            pid = int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[1])
        except (OSError, ValueError):
            return False
    return False


def check_owners(raw, roots):
    for line in raw.splitlines():
        columns = [p.strip() for p in line.strip('|').split('|')]
        if not columns or not re.fullmatch(r'[56]\s+0',columns[0]):
            continue
        if len(columns) < 4 or not columns[1].isdigit():
            continue
        pid = int(columns[-1] if columns[-1].isdigit() else columns[1])
        if Path(f'/proc/{pid}').exists() and not descendant(pid, roots):
            raise RuntimeError(f'Foreign NPU process {pid}; do not signal it')


def stop_group(child):
    # The child is created with start_new_session; no unrelated process group.
    identity = Path(f'/proc/{child.pid}/stat')
    if identity.exists():
        ticks = identity.read_text().rsplit(')',1)[1].split()[19]
        if ticks != child.owned_start_ticks:
            raise RuntimeError('PID reused; refusing to signal')
    for signum, seconds in ((signal.SIGINT,120),(signal.SIGTERM,30),(signal.SIGKILL,10)):
        try:
            os.killpg(child.pid, signum)
        except ProcessLookupError:
            break
        deadline = time.monotonic()+seconds
        while time.monotonic() < deadline:
            child.poll()
            try:
                os.killpg(child.pid,0)
            except ProcessLookupError:
                return child.wait(timeout=5)
            time.sleep(1)
    return child.wait(timeout=10)


def main():
    plan_path = TASK/'retrieval-b1-plan-r1.json'
    plan = json.loads(plan_path.read_text())
    assert plan['physical_cards'] == [5,6]
    assert plan['role']=='B1' and plan['expected_versions']['vllm'].startswith('0.28.1')
    for path, digest in plan['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    out, cache = Path(plan['output']), Path(plan['cache'])
    assert out.parent == cache.parent == TASK and not out.exists() and not cache.exists()
    out.mkdir(mode=0o700)
    record = dict(status='admitting', started=time.time(), plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                  reserved_physical_cards=[5,6], allocated_cards=2, children=[], model_run_started=False)
    save(out/'plan.json',plan)
    locks, children = [], []
    handles = []
    try:
        for path in ['/tmp/inference-project-container-model.lock','/tmp/gennova-device-leases/device-5.lock','/tmp/gennova-device-leases/device-6.lock']:
            Path(path).parent.mkdir(exist_ok=True)
            lock = open(path,'a+b')
            locks.append(lock)
            fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        for _ in range(3):
            raw = subprocess.check_output(['npu-smi','info'],text=True,timeout=20)
            assert all(f'No running processes found in NPU {n}' in raw for n in (5,6))
            time.sleep(1)
        (out/'npu-before.txt').write_text(raw)
        assert shutil.disk_usage(TASK).free > 4*2**30, 'Insufficient startup reserve'
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',18390))
        cache.mkdir(mode=0o700)
        save(out/'cache-initialization.json',dict(path=str(cache),initial_entries=[],os_page_cache_globally_flushed=False))
        env = dict(os.environ,KVMAT_RUN_DIR=str(out))
        command = ['bash','/root/m01-storage-timing-runtime-20261024/runtime_boundary_b1.sh',str(TASK/'serve_b1.py'),str(plan_path)]
        service_log = (out/'service.log').open('x'); handles.append(service_log)
        client_log = (out/'client.log').open('x'); handles.append(client_log)
        samples = (out/'device-samples.jsonl').open('x'); handles.append(samples)
        server = subprocess.Popen(command,env=env,stdout=service_log,stderr=subprocess.STDOUT,start_new_session=True)
        server.owned_start_ticks = Path(f'/proc/{server.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
        children.append(server)
        record.update(status='starting',service_pid=server.pid,model_run_started=True)
        save(out/'receipt.json',record)
        deadline = time.monotonic()+3900
        client = None
        sampling_failures = 0
        while True:
            assert server.poll() is None, f'Service exited {server.returncode}'
            assert time.monotonic()<deadline, 'Prospective deadline reached'
            assert shutil.disk_usage(TASK).free>2*2**30, 'Disk reserve exhausted'
            start_mono, start_wall = time.monotonic(),time.time()
            try:
                raw = subprocess.check_output(['npu-smi','info'],text=True,timeout=20)
            except (subprocess.TimeoutExpired,subprocess.CalledProcessError) as error:
                sampling_failures += 1
                samples.write(json.dumps(dict(monotonic=start_mono,wall=start_wall,error=type(error).__name__,phase=record['status']))+'\n');samples.flush()
                if sampling_failures>=3:
                    raise RuntimeError('Three consecutive NPU sampling failures') from error
                continue
            sampling_failures = 0
            samples.write(json.dumps(dict(monotonic_start=start_mono,wall_start=start_wall,monotonic_end=time.monotonic(),wall_end=time.time(),phase=record['status'],raw=raw))+'\n');samples.flush()
            check_owners(raw,{child.pid for child in children})
            if client is None:
                try:
                    with OPENER.open('http://127.0.0.1:18390/health',timeout=2) as response:
                        ready = response.status == 200
                except (OSError,TimeoutError):
                    ready = False
                if ready:
                    client = subprocess.Popen(['/root/agentx-bench/.venv/bin/python',str(SOURCE/'long_context_client_m05_parser_r1.py'),str(out)],
                        stdout=client_log,stderr=subprocess.STDOUT,start_new_session=True,
                        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(cache/'tmp')})
                    client.owned_start_ticks = Path(f'/proc/{client.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
                    children.append(client)
                    record.update(status='retrieval_running',client_pid=client.pid)
                    save(out/'receipt.json',record)
                    print('RETRIEVAL_CLIENT_STARTED',client.pid,flush=True)
            elif client.poll() is not None:
                record['client_exit']=client.returncode
                assert client.returncode == 0, f'Client failed {client.returncode}; retained'
                result=json.loads((out/'long-context.json').read_text())
                record.update(status='retrieval_complete',completed=result['completed'],correct=result['correct'],failed=result['failed'],cases=result['total'])
                break
            time.sleep(2)
    except BaseException as error:
        record.update(status='failed',error=f'{type(error).__name__}: {error}')
        raise
    finally:
        for child in reversed(children):
            record['children'].append(dict(pid=child.pid,exit_code=stop_group(child)))
        for handle in handles:
            handle.close()
        released=False
        for attempt in range(3):
            try:
                raw=subprocess.check_output(['npu-smi','info'],text=True,timeout=20)
                (out/f'npu-after-{attempt}.txt').write_text(raw)
                released=all(f'No running processes found in NPU {n}' in raw for n in (5,6))
                if released:break
            except (subprocess.TimeoutExpired,subprocess.CalledProcessError):
                pass
            time.sleep(2)
        record.update(ended=time.time(),all_reserved_devices_released=released)
        save(out/'receipt.json',record)
        for lock in locks:lock.close()
        if released:
            rows=[]
            for path in sorted(out.rglob('*')):
                if path.is_file() and path.name!='SHA256SUMS':
                    rows.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(out)))
            (out/'SHA256SUMS').write_text('\n'.join(rows)+'\n')
        print(json.dumps(record),flush=True)


if __name__=='__main__':
    main()
