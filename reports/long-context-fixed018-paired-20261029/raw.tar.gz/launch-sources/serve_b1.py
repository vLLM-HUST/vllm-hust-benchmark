"""Manager-owned corrected B1; only model relocation and reasoning parser added."""
def main():
    import hashlib
    import json
    import os
    from pathlib import Path
    import sys
    task=Path(__file__).resolve().parent
    plan_path=Path(sys.argv[1])
    plan=json.loads(plan_path.read_text())
    out,cache=Path(plan['output']),Path(plan['cache'])
    assert out.is_dir() and cache.is_dir() and not list(cache.iterdir())
    import launch_boundary_b1
    launch_boundary_b1.MODEL=Path('/models/Qwen3.5-35B-A3B')
    from launch_corrected_timing import prepare
    command,env,original=prepare(out,cache,'long-context-b1-retrieval-r1')
    command=[command[0],str(task/'serve_b1_child.py'),str(plan_path),*command[2:]]
    command+=['--reasoning-parser','qwen3']
    env['PYTHONPATH']='/root/m01-storage-timing-runtime-20261024:'+env['PYTHONPATH']
    env.update(TMPDIR=str(cache/'tmp'),ASCEND_CACHE_PATH=str(cache/'ascend'))
    for key in ('TMPDIR','ASCEND_CACHE_PATH'):
        Path(env[key]).mkdir(parents=True,exist_ok=True)
    os.environ.update(env)
    with (out/'launch-command.json').open('x') as stream:
        json.dump(dict(command=command,original_command_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),changes=['same verified checkpoint at local path','qwen3 reasoning parser']),stream,indent=2)
    from vllm_hust_ext.cli import main as manager
    raise SystemExit(manager(['run','--shutdown-grace-seconds','90','--',*command]))


if __name__=='__main__':main()
