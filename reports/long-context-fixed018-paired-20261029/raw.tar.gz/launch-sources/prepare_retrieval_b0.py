"""Freeze existing six requests and strict scorer with the fixed018 serving arm."""
import hashlib
import json
from pathlib import Path

TASK = Path(__file__).resolve().parent
BASE = Path('/root/m01-b0-accounting-20261024')
SOURCE = Path('/root/gennova-evidence/20261019-midterm-aligned')
MODEL = Path('/models/Qwen3.5-35B-A3B')
assert json.loads((TASK/'b0-cpu-preflight.json').read_text())['status'] == 'passed'
view = TASK/'model-text-only'
view.mkdir(exist_ok=False)
config = json.loads((BASE/'model-text-only/config.json').read_text())
full_config = json.loads((MODEL/'config.json').read_text())
for field in ('hidden_size', 'num_hidden_layers', 'vocab_size'):
    assert config[field] == full_config['text_config'][field], field
for path in MODEL.iterdir():
    if path.name != 'config.json' and path.is_file():
        (view/path.name).symlink_to(path)
(view/'config.json').write_bytes((BASE/'model-text-only/config.json').read_bytes())
sources = [TASK/name for name in ('bootstrap_b0.py','serve_b0.py','run_retrieval_b0.py','prepare_retrieval_b0.py')]
sources += [SOURCE/name for name in ('long-context-inputs-r1.json','long_context_client_m05_parser_r1.py','m05_parser_qualification_r1.py','m05_reasoning_wire.py')]
sources += [MODEL/name for name in ('config.json','tokenizer.json','tokenizer_config.json','chat_template.jinja')]
plan = dict(schema='fixed018-long-context-retrieval/v1', role='B0',
    expected_versions=dict(vllm='0.18.0', vllm_ascend='0.18.0'),
    output=str(TASK/'retrieval-b0-r1'),cache=str(TASK/'retrieval-b0-cache-r1'),model_view=str(view),
    physical_cards=[5,6],logical_devices='0,1',reserved_cards=2,
    inputs='Original six synthetic retrieval cases:16K/32K,10/50/90% positions, C1, max8192, temperature0,seed0; no substitution',
    criterion='Strict whole content equality to original code; reasoning collected separately; no post-hoc parsing changes',
    qualification='Original 2+2 parser qualification before six cases; failure prevents case submission',
    stop='No retries or case replacement; retain all failures. Stop on service exit, foreign NPU owner, three consecutive sampler failures, disk below2GiB or3900s deadline.',
    comparison='New fixed018 single arm. B1 paired run and continuous4K/16K measurement remain separate; no overall acceptance verdict.',
    cache_policy='Fresh independent service and empty writable caches. Original unique request salts retained. Read-only weights and OS page cache shared, not globally flushed.',
    source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
    serve_args=['--served-model-name','qwen3.5-35b','--host','127.0.0.1','--port','18390',
      '--dtype','bfloat16','--tensor-parallel-size','2','--pipeline-parallel-size','1','--data-parallel-size','1',
      '--max-model-len','65536','--max-num-seqs','24','--max-num-batched-tokens','4096',
      '--kv-cache-memory-bytes','21474836480','--enable-prefix-caching','--enable-chunked-prefill',
      '--async-scheduling','--mamba-cache-mode','align','--speculative-config','{"method":"mtp","num_speculative_tokens":2}',
      '--seed','17','--compilation-config','{"mode":3,"cudagraph_mode":"FULL_AND_PIECEWISE"}',
      '--distributed-executor-backend','mp','--disable-custom-all-reduce','--no-enable-log-requests',
      '--reasoning-parser','qwen3','--generation-config','vllm'])
with (TASK/'retrieval-b0-plan-r1.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
    stream.write('\n')
print('FROZEN_NOT_RUN',len(sources),'source identities')
