"""Manager-owned child: compose serving corrections before importing vLLM."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

ORIGINAL = 'hust_microflow_school028_fa'
CAPTURE = 'hust_m01_correction'
BUNDLES = {'org.vllm-hust.kv-materialization-school028-recompute',
           'org.vllm-hust.prefill-microflow-school028-fa'}


def compose_environment(env):
    if env.get('HUST_M01_CORRECTED_SERVING') != '1':
        raise ValueError('Serving correction must be explicitly enabled')
    if set(env.get('VLLMHUST_EXT_ENABLED_BUNDLES', '').split(',')) != BUNDLES:
        raise ValueError('Expected both Manager-activated B1 bundles')
    if env.get('HUST_MICROFLOW_SCHOOL028_FA') != '1':
        raise ValueError('Missing Manager Microflow activation')
    names = env.get('VLLM_PLUGINS', '').split(',')
    if names.count(ORIGINAL) != 1 or CAPTURE in names:
        raise ValueError('Expected original plugin exactly once before child composition')
    result = dict(env)
    result['VLLM_PLUGINS'] = ','.join(CAPTURE if name == ORIGINAL else name for name in names)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preflight-receipt', type=Path)
    options, args = parser.parse_known_args()
    if not args or args[0] != 'serve':
        raise ValueError('Expected preserved serve arguments')
    if 'vllm' in sys.modules:
        raise RuntimeError('Composition must precede vLLM import')
    before = os.environ.get('VLLM_PLUGINS', '').split(',')
    os.environ.update(compose_environment(os.environ))
    if options.preflight_receipt:
        # Reserve the file before importing the runtime; never replace a prior attempt.
        with options.preflight_receipt.open('x') as stream:
            from vllm.plugins import load_general_plugins
            load_general_plugins()
            import corrected_serving_runtime as runtime
            import betterscale.qwen35_worker as worker
            import betterscale.models.qwen35.seat_scheduler as scheduler
            if worker.Worker is not runtime.CorrectedWorker:
                raise RuntimeError('Manager child did not register corrected serving composition')
            import torch
            result = dict(status='manager_child_composition_passed', model_loaded=False,
                device_qualification=False, plugins_before=before,
                plugins_after=os.environ['VLLM_PLUGINS'].split(','),
                enabled_bundles=sorted(BUNDLES), command_arguments=args,
                worker_implementation=f'{worker.Worker.__module__}.{worker.Worker.__name__}',
                scheduler_implementation=f'{scheduler.LiveStateScheduler.__module__}.{scheduler.LiveStateScheduler.__name__}',
                npu_context_initialized=torch.npu.is_initialized(), effective_flops=None,
                m01_attainment=None,
                adapter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
            json.dump(result, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        print(json.dumps({key: value for key, value in result.items() if key != 'command_arguments'}))
        return
    sys.argv = ['vllm', *args]
    from vllm.entrypoints.cli.main import main as serve_main
    serve_main()


if __name__ == '__main__':
    main()
