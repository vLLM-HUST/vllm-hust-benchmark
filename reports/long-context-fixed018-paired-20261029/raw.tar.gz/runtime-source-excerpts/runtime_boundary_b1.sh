#!/usr/bin/env bash
# Device admission and fresh cache creation are controller responsibilities.
set -eo pipefail
unset PYTHONPATH LD_PRELOAD HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy OPENAI_API_KEY
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
ROOT=/root/gennova-evidence/20261019-midterm-aligned
REC=/root/frontierscience-recovery-20261022
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
export TMPDIR=${KVMAT_RUN_DIR:-$HERE}/runtime-tmp
mkdir -p "$TMPDIR"
export XDG_CACHE_HOME=${KVMAT_RUN_DIR:-$HERE}/import-cache
export PYTHONPATH=$HERE:$ROOT/microflow-recovery-payload-r2:/root/extension-manager/src:$ROOT/kvmat-managed-payload-r1:$ROOT/recovery-model-payload-r1:$ROOT/compat:/root/gennova-runtime/m01-triton-recovery-dev20261007-r2:$ROOT/runtime:/root/modcost-runtime-028-20261017/vllm-workspace/vllm:$REC/filtered-site${PYTHONPATH:+:$PYTHONPATH}
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4 TASK_QUEUE_ENABLE=0 HCCL_OP_EXPANSION_MODE=AIV
export VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ENABLE_V1_MULTIPROCESSING=1
export BETTERSCALE_FIA_METADATA=owned BETTERSCALE_STATE_CACHE_HOST_BYTES=8589934592
export BETTERSCALE_GDN_LIBRARY=/root/gennova-runtime/betterscale-dist/extracted/vllm_betterscale-0.5.1/src/betterscale/patches/qwen_gdn/libbs_gdn.so
export BETTERSCALE_GDN_HOST_LIBRARY=$ROOT/build/libbs_gdn_host_cann91.so
export BETTERSCALE_CP_LIBRARY=$ROOT/recovery-fia-build-r1/artifact/libbs_fia_cp.so
export VLLM_HUST_EXT_CONFIG=$ROOT/manager-recovery-r2/manager.json
export VLLM_KV_ENABLE_SCHOOL_028=1 VLLM_KV_POLICY_MODE=controller
export HUST_MICROFLOW_ARM=on HUST_TOKEN_OBSERVER=0 MTP_PROFILE=0
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector,kv_materialization,hust_microflow_school028_fa
export MTP_TOKENS=2 MTP_GDN_LAYOUT_FUSION=1 BETTERSCALE_MTP_GREEDY=1 BETTERSCALE_GDN_SMALL_COPIES=1
exec "$REC/venv/bin/python" "$@"
