"""Launch the measured B1 composition; external controller owns admission."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
HERE = Path(__file__).resolve().parent
MODEL = Path('/models/modelscope_cache/Qwen/Qwen3___5-35B-A3B')


def relocated_arguments(arguments):
    result = list(arguments)
    old = '/models/Qwen3.5-35B-A3B'
    if result.count(old) != 1:
        raise ValueError('Expected exactly one original model path')
    result[result.index(old)] = str(MODEL)
    return result


def prepare_command(out, cache):
    from betterscale.models.qwen35.launch import prepare
    command, env = prepare(
        model=MODEL, devices='0,1', port=18390,
        cache_dir=cache / 'on/vllm', runtime_dir=ROOT / 'runtime',
        context_tokens=65536, state_budget_bytes=21474836480,
        served_model_name='qwen3.5-35b', distributed_port=29670,
        execution_seats=24, resident_seats=36, mtp_tokens=2, max_images=0)
    original = ROOT / 'mmlu-b1-microflow-fa-on-r10/launch-command.json'
    if command[2:] != relocated_arguments(json.loads(original.read_text())[2:]):
        raise ValueError('B1 arguments differ from original measured composition')
    command = [sys.executable, '-m', 'vllm.entrypoints.cli.main', 'serve',
               *command[2:], '--worker-extension-cls', 'synchronized_boundary.WorkerBoundary']
    env.update(HUST_MICROFLOW_CACHE_ROOT=str(cache), HUST_MICROFLOW_EVENT_DIR=str(out),
        VLLM_CACHE_ROOT=str(cache / 'on/vllm'), TRITON_CACHE_DIR=str(cache / 'on/triton'),
        TORCHINDUCTOR_CACHE_DIR=str(cache / 'on/inductor'),
        XDG_CACHE_HOME=str(cache / 'xdg'),
        VLLM_KV_MATERIALIZATION_LOG_PATH=str(out / 'kvmat-policy.jsonl'),
        VLLM_KV_MATERIALIZATION_RUNTIME_EVENT_LOG_PATH=str(out / 'kvmat-engine.jsonl'),
        HUST_TOKEN_OBSERVER='0', MTP_PROFILE='0', VLLM_SERVER_DEV_MODE='1')
    return command, env, original


def reserve_cache(cache):
    if cache.exists() or cache.is_symlink():
        raise FileExistsError('Run cache must be new; seed reuse is forbidden')
    cache.mkdir()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cache', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    out, cache = args.output.absolute(), args.cache.absolute()
    if cache == out or cache in out.parents or out in cache.parents:
        raise ValueError('Evidence and cache must be independent directories')
    command, env, original = prepare_command(out, cache)
    if args.check:
        # Exercise the real plugin host-source/cache policy without model startup.
        os.environ.update(env)
        from hust_prefill_microflow.school028 import preflight
        preflight()
        print(json.dumps(dict(status='passed', service_started=False, command=command,
            comparison='verified checkpoint relocated; all other serving arguments unchanged; boundary extension added',
            original_sha256=hashlib.sha256(original.read_bytes()).hexdigest())))
        return
    if not out.is_dir():
        raise ValueError('Controller must create admitted output directory')
    reserve_cache(cache)
    receipt = dict(policy='fresh empty caches; no previous run or compile seed imported',
                   destination=str(cache), initial_entries=[],
                   startup_excluded_from_measurement=True)
    for name, value in [('compiler-cache-initialization.json', receipt),
                        ('launch-command.json', command)]:
        with (out / name).open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')
    os.environ.update(env)
    from vllm_hust_ext.cli import main as manager_main
    raise SystemExit(manager_main(['run', '--', *command]))


if __name__ == '__main__':
    main()
