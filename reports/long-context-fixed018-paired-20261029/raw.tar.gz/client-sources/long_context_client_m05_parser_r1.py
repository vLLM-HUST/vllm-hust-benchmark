"""Frozen synthetic retrieval ability check, never a performance-ranking run."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

import aiohttp
from m05_reasoning_wire import reasoning_delta
from m05_parser_qualification_r1 import qualify

ROOT = Path(__file__).resolve().parent
URL = 'http://127.0.0.1:18390'


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def exact_correct(output, expected):
    return output.strip() == expected


async def main(out):
    await qualify(out)
    plan = json.loads((ROOT / 'long-context-inputs-r1.json').read_text())
    cases = plan['cases']
    save(out / 'request-plan.json', plan)
    rows = []
    started = time.time()
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=1800), trust_env=False) as session:
        preflight = []
        for case in cases:
            async with session.post(URL + '/tokenize', json={
                'model': 'qwen3.5-35b', 'messages': case['request']['messages'],
                'add_generation_prompt': True,
            }) as response:
                assert response.status == 200
                value = await response.json()
                preflight.append({'case_id': case['case_id'], 'count': value['count'],
                                  'token_ids_sha256': hashlib.sha256(json.dumps(value['tokens']).encode()).hexdigest()})
        save(out / 'tokenize-preflight.json', preflight)
        assert all(p['count'] == c['input_tokens'] and p['token_ids_sha256'] == c['token_ids_sha256']
                   for p, c in zip(preflight, cases, strict=True))
        for i, case in enumerate(cases):
            row = {'case_id': case['case_id'], 'expected': case['expected'], 'started': time.time(),
                   'success': False, 'output': '', 'reasoning': '', 'finish_reason': None}
            try:
                done = False
                async with session.post(URL + '/v1/chat/completions', json=case['request']) as response:
                    row['http_status'] = response.status
                    assert response.status == 200
                    with gzip.open(out / f'long-sse-{i:03d}.gz', 'wb') as raw:
                        async for line in response.content:
                            raw.write(line)
                            if not line.startswith(b'data:'):
                                continue
                            content = line[5:].strip()
                            if content == b'[DONE]':
                                done = True
                                continue
                            event = json.loads(content)
                            if event.get('error'):
                                raise RuntimeError('Streaming error; see raw SSE')
                            if event.get('usage'):
                                row['usage'] = event['usage']
                            for choice in event.get('choices', []):
                                delta = choice.get('delta', {})
                                row['output'] += delta.get('content') or ''
                                row['reasoning'] += reasoning_delta(delta)
                                row['finish_reason'] = choice.get('finish_reason') or row['finish_reason']
                assert done and row['finish_reason']
                assert row['usage']['prompt_tokens'] == case['input_tokens']
                cached = row['usage'].get('prompt_tokens_details', {}).get('cached_tokens')
                assert cached in (None, 0), 'Unexpected prefix-cache reuse'
                row['success'] = True
            except Exception as error:
                row['error'] = f'{type(error).__name__}: {error}'
            row.update(ended=time.time(), correct=row['success'] and exact_correct(row['output'], case['expected']))
            save(out / f'long-case-{i:03d}.json', row)
            rows.append(row)
            print(json.dumps({'case': i, 'success': row['success'], 'correct': row['correct']}), flush=True)
    duration = time.time() - started
    summary = {'scope': 'M05 synthetic retrieval; no throughput ranking or primary-dataset quality claim',
               'completed': sum(r['success'] for r in rows), 'failed': sum(not r['success'] for r in rows),
               'correct': sum(r['correct'] for r in rows), 'total': len(cases), 'cases': rows,
               'duration': duration, 'output_throughput': None}
    save(out / 'long-context.json', summary)
    return int(summary['failed'] != 0)


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main(Path(sys.argv[1]))))
