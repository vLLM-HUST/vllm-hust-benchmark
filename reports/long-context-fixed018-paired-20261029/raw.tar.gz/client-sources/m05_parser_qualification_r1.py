"""One prospectively fixed API-field qualification before six original probes."""
import gzip
import json
import time

import aiohttp
from m05_reasoning_wire import reasoning_delta

REQUEST = {'model': 'qwen3.5-35b', 'messages': [
    {'role': 'user', 'content': 'Compute 2 + 2. Reply with only the digit.'}],
    'temperature': 0, 'seed': 0, 'max_tokens': 1024, 'stream': True,
    'stream_options': {'include_usage': True}}


async def qualify(out):
    record = {'request': REQUEST, 'started': time.time(), 'content': '', 'reasoning': '',
              'done': False, 'finish_reason': None, 'passed': False}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=300), trust_env=False) as session:
            async with session.post('http://127.0.0.1:18390/v1/chat/completions', json=REQUEST) as response:
                record['http_status'] = response.status
                assert response.status == 200
                with gzip.open(out / 'parser-qualification-sse.gz', 'wb') as raw:
                    async for line in response.content:
                        raw.write(line)
                        if not line.startswith(b'data:'):
                            continue
                        payload = line[5:].strip()
                        if payload == b'[DONE]':
                            record['done'] = True
                            continue
                        event = json.loads(payload)
                        assert not event.get('error')
                        if event.get('usage'):
                            record['usage'] = event['usage']
                        for choice in event.get('choices', []):
                            delta = choice.get('delta', {})
                            record['content'] += delta.get('content') or ''
                            record['reasoning'] += reasoning_delta(delta)
                            record['finish_reason'] = choice.get('finish_reason') or record['finish_reason']
        assert record['done'] and record['finish_reason'] == 'stop'
        assert record['content'].strip() == '4' and record['reasoning'].strip()
        assert '<think>' not in record['content'] and '</think>' not in record['content']
        record['passed'] = True
    except BaseException as error:
        record['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        record['ended'] = time.time()
        (out / 'parser-qualification.json').write_text(json.dumps(record, indent=2) + '\n')
