"""Collect old and current reasoning wire fields without changing answer text."""


def reasoning_delta(delta):
    current = delta.get('reasoning')
    legacy = delta.get('reasoning_content')
    if current is not None and legacy is not None and current != legacy:
        raise ValueError('Conflicting reasoning fields')
    value = current if current is not None else legacy
    if value is not None and not isinstance(value, str):
        raise TypeError('Reasoning delta must be text or null')
    return value or ''
