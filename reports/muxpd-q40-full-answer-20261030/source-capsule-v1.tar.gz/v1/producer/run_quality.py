"""Explicit run command for the frozen MCQ gate; dry-run never imports vLLM.

This uses an in-process coordinator and ordinary worker classes. It collects
answers and small scheduler receipts, not full-vocabulary tensors or timings.
Only root may invoke the device-owning run command after reviewing the plan.
"""

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import subprocess
import sys
import time
import traceback
from datetime import UTC, datetime
from pathlib import Path

from score_quality import load_frozen


def runtime_environment():
    packages = {}
    for name in ("vllm", "vllm-ascend", "torch", "torch-npu", "transformers", "tokenizers"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    keys = ("ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES", "OMP_NUM_THREADS",
            "VLLM_WORKER_MULTIPROC_METHOD", "VLLM_ENABLE_V1_MULTIPROCESSING", "VLLM_PLUGINS",
            "VLLM_VERSION", "HCCL_DETERMINISTIC", "VLLM_USE_V2_MODEL_RUNNER", "VLLM_BATCH_INVARIANT",
            "TASK_QUEUE_ENABLE", "PYTORCH_NPU_ALLOC_CONF", "VLLM_ASCEND_ENABLE_FLASHCOMM",
            "VLLM_ASCEND_ENABLE_MLAPO", "ASCEND_LAUNCH_BLOCKING", "LD_LIBRARY_PATH")
    return {"python": sys.version, "executable": sys.executable,
            "packages": packages, "environment": {key: os.environ.get(key) for key in keys}}


def source_identities():
    result = {}
    for name in ("vllm", "vllm_ascend", "vllm_muxpd"):
        spec = importlib.util.find_spec(name)
        if spec is None or spec.origin is None:
            result[name] = {"available": False}
            continue
        source = Path(spec.origin).resolve()
        commands = {}
        for label, flags in (("commit", ["rev-parse", "HEAD"]), ("status", ["status", "--short"])):
            completed = subprocess.run(["git", "-C", str(source.parent), *flags],
                                       capture_output=True, text=True, check=False)
            commands[label] = completed.stdout.strip() if completed.returncode == 0 else None
        root = subprocess.run(["git", "-C", str(source.parent), "rev-parse", "--show-toplevel"],
                              capture_output=True, text=True, check=True).stdout.strip()
        diff = subprocess.run(["git", "-C", root, "diff", "--binary", "HEAD"],
                              capture_output=True, check=True).stdout
        names = subprocess.run(["git", "-C", root, "diff", "--name-only", "-z", "HEAD"],
                               capture_output=True, check=True).stdout.split(b"\0")
        untracked = subprocess.run(["git", "-C", root, "ls-files", "--others", "--exclude-standard", "-z"],
                                   capture_output=True, check=True).stdout.split(b"\0")
        changed = []
        for raw_name in sorted(set(names + untracked) - {b""}):
            relative = raw_name.decode()
            path = Path(root) / relative
            changed.append({"path": relative, "exists": path.exists(),
                            "sha256": hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None})
        result[name] = {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                        **commands, "diff_sha256": hashlib.sha256(diff).hexdigest(),
                        "diff_bytes_utf8": diff.decode(), "changed_files": changed}
    return result


def write(path, value):
    pending = path.with_suffix(".pending")
    with pending.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    pending.replace(path)


def validate(role, engine_args, plan):
    for key, value in plan["runtime"].items():
        if engine_args.get(key) != value:
            raise ValueError(f"Required engine setting {key}={value!r}")
    if engine_args.get("enable_chunked_prefill") is not (role == "native"):
        raise ValueError("Native requires standard chunked prefill; MuxPD requires it disabled")
    if engine_args.get("speculative_config") is not None or engine_args.get("num_gpu_blocks_override") is not None:
        raise ValueError("No speculation or forced KV pressure in quality qualification")
    if "worker_cls" in engine_args:
        raise ValueError("Select ordinary worker classes through this driver")
    policy = engine_args.get("batch_admission_policy_config", {})
    if bool(policy.get("compile_prefill_groups", False)) != (role == "group"):
        raise ValueError("Group label and actual compile_prefill_groups disagree")
    if role == "native":
        if engine_args.get("batch_admission_policy") or engine_args.get("scheduler_cls"):
            raise ValueError("Native control cannot select a MuxPD scheduler")
    else:
        required = {"execution": "decoupled", "stream_mode": "overlap", "layers_per_slice": 4,
                    "adaptive_layers": False, "prefill_first": False, "decode_graph": True,
                    "compile_full_prefill": False, "decode_budget_guard": False,
                    "overlap_communication": "isolated"}
        if any(policy.get(key) != value for key, value in required.items()):
            raise ValueError("Candidate differs from prescribed isolated raw/group q4 recipe")
    backend = engine_args.get("additional_config", {}).get("ascend_compilation_config", {})
    if any(backend.get(key) is not False for key in ("enable_npugraph_ex", "enable_static_kernel")):
        raise ValueError("All quality arms require the same explicit group-compatible compiler settings")
    return dict(engine_args, worker_cls=("vllm_ascend.worker.worker.NPUWorker" if role == "native"
                else "vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker"))


def enqueue_bound(llm, cases, sampling):
    internal = llm.enqueue([{"prompt_token_ids": case["prompt_token_ids"]} for case in cases],
                           sampling, use_tqdm=False)
    if len(internal) != len(cases):
        raise RuntimeError("Enqueue cardinality differs from frozen inputs")
    external = [llm.llm_engine.output_processor.request_states[rid].external_req_id for rid in internal]
    return [{"case_id": case["case_id"], "internal": rid, "external": eid}
            for case, rid, eid in zip(cases, internal, external, strict=True)]


def install_receipts(scheduler, stream, context, coverage):
    schedule, update = scheduler.schedule, scheduler.update_from_output
    transaction = {}

    def observed_schedule(*args, **kwargs):
        phases = {rid: ("D" if req.num_output_tokens > 0 else "P")
                  for rid, req in scheduler.requests.items()}
        output = schedule(*args, **kwargs)
        row = {"event": "schedule", **context,
               "scheduled_tokens": dict(output.num_scheduled_tokens),
               "phases_before": phases,
               "pending_prefill_ids": sorted(getattr(output, "muxpd_pending_prefill_ids", [])),
               "new_prefill_ids": sorted(getattr(output, "muxpd_prefill_request_ids", [])),
               "prefill_layers_before": getattr(output, "muxpd_prefill_layers_completed_before", 0),
               "preempted_req_ids": sorted(output.preempted_req_ids or [])}
        transaction.clear()
        transaction.update(row)
        stream.write(json.dumps(row) + "\n")
        return output

    def observed_update(scheduled, result):
        before = {rid: (request, request.num_output_tokens)
                  for rid, request in scheduler.requests.items()}
        progress = getattr(result, "muxpd_prefill_layers_completed", None)
        returned = update(scheduled, result)
        retired = [rid for rid, (request, count) in before.items()
                   if count > 0 and request.num_output_tokens > count]
        pending = transaction.get("pending_prefill_ids", [])
        p_progress = bool(pending and progress is not None
                          and progress > transaction.get("prefill_layers_before", 0))
        native_mixed = (not pending and any(transaction.get("phases_before", {}).get(rid) == "P"
                                          for rid in scheduled.num_scheduled_tokens) and bool(retired))
        mixed = bool(p_progress and retired)
        if mixed:
            coverage[context["batch_id"]] = coverage.get(context["batch_id"], 0) + 1
        stream.write(json.dumps({"event": "retirement", **context,
                                 "decode_retired_ids": retired, "prefill_layers_completed": progress,
                                 "actual_prefill_progress": p_progress,
                                 "mixed_pd_progress_and_retirement": mixed,
                                 "native_mixed_scheduled_and_decode_retired": native_mixed,
                                 "completed_prefill_ids": sorted(getattr(result, "muxpd_completed_prefill_ids", [])),
                                 "cancelled_prefill_ids": sorted(getattr(result, "muxpd_cancelled_prefill_ids", []))}) + "\n")
        return returned

    scheduler.schedule = observed_schedule
    scheduler.update_from_output = observed_update


def run(args, plan, cases, engine_args):
    args.output.mkdir(parents=True, exist_ok=False)
    os.environ["VLLM_ENABLE_V1_MULTIPROCESSING"] = "0"
    forbidden = ("MUXPD_NUMERIC_OUTPUT", "MUXPD_PRESSURE_TRACE_DIR")
    if any(os.environ.get(key) for key in forbidden):
        raise ValueError("Remove unrelated numerical/pressure observers from this diagnostic")
    report = {"schema": "muxpd-mmlu-pro-quality-run-v1", "role": args.role,
              "plan_sha256": plan["plan_sha256"], "process_id": os.getpid(),
              "started_at": datetime.now(UTC).isoformat(),
              "engine_args": engine_args, "outputs": [], "admissions": [], "errors": [],
              "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "runtime_environment": runtime_environment(),
              "collection_complete": False, "shutdown_returned": False,
              "scope": "Bounded MCQ diagnostic, no timing or population-equivalence claim"}
    write(args.output / "run.json", report)
    llm = None
    coverage, context = {}, {"global_step": 0, "batch_id": -1}
    by_id = {row["case_id"]: row for row in cases}
    try:
        from tokenizers import Tokenizer
        from vllm import LLM, SamplingParams
        from vllm.v1.engine.core_client import InprocClient

        tokfile = plan["tokenizer_files"]["tokenizer.json"]
        if hashlib.sha256(Path(tokfile["path"]).read_bytes()).hexdigest() != tokfile["sha256"]:
            raise ValueError("Tokenizer decoder differs from frozen source")
        decoder = Tokenizer.from_file(tokfile["path"])
        llm = LLM(**engine_args)
        if not isinstance(llm.llm_engine.engine_core, InprocClient):
            raise TypeError("Actual coordinator is not InprocClient")
        core = llm.llm_engine.engine_core.engine_core
        report["sources"] = source_identities()
        cfg = core.vllm_config
        report["effective"] = {"max_model_len": cfg.model_config.max_model_len,
                               "max_num_seqs": cfg.scheduler_config.max_num_seqs,
                               "max_num_batched_tokens": cfg.scheduler_config.max_num_batched_tokens,
                               "enable_chunked_prefill": cfg.scheduler_config.enable_chunked_prefill,
                               "tensor_parallel_size": cfg.parallel_config.tensor_parallel_size}
        expected_effective = {key: engine_args[key] for key in report["effective"]}
        if report["effective"] != expected_effective:
            raise RuntimeError("Effective runtime differs from frozen launch arguments")
        report["scheduler_class"] = type(core.scheduler).__module__ + "." + type(core.scheduler).__name__
        report["engine_coordinator"] = type(llm.llm_engine.engine_core).__name__
        params = SamplingParams(**plan["sampling"])
        started = time.monotonic()
        with (args.output / "scheduler-receipts.jsonl").open("x", buffering=1) as receipts:
            install_receipts(core.scheduler, receipts, context, coverage)
            for batch in plan["batches"]:
                context["batch_id"] = batch["batch_id"]
                members = [by_id[rid] for rid in batch["case_ids"]]
                mappings = enqueue_bound(llm, members[:1], params)
                seed = mappings[0]["internal"]
                admitted = {mappings[0]["external"]: members[0]}
                report["admissions"].append({**context, "stage": "seed", "bindings": mappings})
                released, finished = False, set()
                while llm.llm_engine.has_unfinished_requests():
                    if context["global_step"] >= plan["maximum_engine_steps"] or time.monotonic() - started > plan["maximum_wall_seconds"]:
                        raise RuntimeError("Frozen bounded-work limit exceeded")
                    context["global_step"] += 1
                    outputs = llm.llm_engine.step()
                    seed_finished_tokens = None
                    for output in outputs:
                        if not output.finished:
                            continue
                        if output.request_id not in admitted or output.request_id in finished or len(output.outputs) != 1:
                            raise RuntimeError("Unknown, duplicate or multi-sample final output")
                        finished.add(output.request_id)
                        case, item = admitted[output.request_id], output.outputs[0]
                        if list(output.prompt_token_ids) != case["prompt_token_ids"]:
                            raise RuntimeError("Returned prompt differs from frozen token IDs")
                        tokens = list(map(int, item.token_ids))
                        report["outputs"].append({"case_id": case["case_id"], "request_id": output.request_id,
                                                  "finished": True, "token_ids": tokens,
                                                  "text": decoder.decode(tokens, skip_special_tokens=True),
                                                  "finish_reason": item.finish_reason, "stop_reason": item.stop_reason})
                        if case["case_id"] == batch["seed_case_id"]:
                            seed_finished_tokens = len(tokens)
                    if not released:
                        seed_request = core.scheduler.requests.get(seed)
                        count = seed_request.num_output_tokens if seed_request is not None else seed_finished_tokens
                        if count is None or count == 0:
                            if seed_request is None:
                                raise RuntimeError("Seed completed without an observed output token")
                            continue
                        if count != 1:
                            raise RuntimeError("Missed exact first-output-token admission gate")
                        bindings = enqueue_bound(llm, members[1:], params)
                        admitted.update({row["external"]: case for row, case in zip(bindings, members[1:], strict=True)})
                        report["admissions"].append({**context, "stage": "peers", "bindings": bindings,
                                                      "seed_output_tokens": count, "seed_still_live": seed_request is not None})
                        released = True
                if not released or len(finished) != len(members) or finished != set(admitted):
                    raise RuntimeError("Batch ended without every frozen request returning")
                write(args.output / "run.json", report)
        report["collection_complete"] = len(report["outputs"]) == plan["case_count"]
    except BaseException:  # noqa: BLE001 -- retain failed/interrupted collection and perform shutdown
        report["errors"].append(traceback.format_exc())
    finally:
        if llm is not None:
            try:
                llm.llm_engine.engine_core.shutdown()
                report["shutdown_returned"] = True
            except BaseException:  # noqa: BLE001 -- record teardown failure without losing original failure
                report["errors"].append(traceback.format_exc())
        report["finished_at"] = datetime.now(UTC).isoformat()
        report["mixed_coverage"] = {"steps_per_batch": coverage,
                                    "covered_batches": sorted(coverage),
                                    "uncovered_batches": [row["batch_id"] for row in plan["batches"] if row["batch_id"] not in coverage],
                                    "meaning": "Actual P layer progress plus D token retirement in one transaction; not physical kernel overlap"}
        receipt_path = args.output / "scheduler-receipts.jsonl"
        if receipt_path.exists():
            report["scheduler_receipts_sha256"] = hashlib.sha256(receipt_path.read_bytes()).hexdigest()
        write(args.output / "run.json", report)
    complete = report["collection_complete"] and report["shutdown_returned"] and not report["errors"]
    print(json.dumps({"collection_complete": complete, "outputs": len(report["outputs"]), "errors": report["errors"]}))
    return 0 if complete else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("dry-run", "run"))
    parser.add_argument("--frozen", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--engine-args", type=Path, required=True)
    parser.add_argument("--role", choices=("native", "raw", "group"), required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    plan, cases, _ = load_frozen(args.frozen)
    if plan["plan_sha256"] != args.plan_sha256:
        raise ValueError("Explicit plan identity mismatch")
    engine_args = validate(args.role, json.loads(args.engine_args.read_text()), plan)
    if args.command == "dry-run":
        print(json.dumps({"validated": True, "role": args.role, "case_count": len(cases),
                          "batches": len(plan["batches"]), "plan_sha256": plan["plan_sha256"]}))
        return 0
    if args.output is None:
        parser.error("run requires a new --output directory")
    return run(args, plan, cases, engine_args)


if __name__ == "__main__":
    raise SystemExit(main())
