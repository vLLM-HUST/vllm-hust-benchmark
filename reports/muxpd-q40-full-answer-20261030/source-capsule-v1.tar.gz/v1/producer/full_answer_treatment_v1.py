"""Pinned quota-only configuration for original batch7 complete answers."""

import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROFILE_SHA = "123b30f48d747c81063e0f30da112da737cad465a8614996e2aaf31d99cfc3e6"
WORKER = "vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_treatment():
    path = HERE / "full-answer-treatment-v1.json"
    if sha(path) != PROFILE_SHA:
        raise ValueError("Full-answer treatment sidecar changed")
    profile = json.loads(path.read_text())
    for key in ("base_plan", "base_config", "source_manifest"):
        item = profile[key]
        if sha(HERE / item["file"]) != item["sha256"]:
            raise ValueError("Original full200 plan/config/source receipt changed")
    return profile


def expected_launch(base, quota):
    profile = load_treatment()
    pinned = json.loads((HERE / profile["base_config"]["file"]).read_text())
    if base != pinned:
        raise ValueError("Require original raw q4 config before treatment")
    result = copy.deepcopy(base)
    result["worker_cls"] = WORKER
    result["batch_admission_policy_config"]["layers_per_slice"] = quota
    return result


def apply_treatment(base, configured):
    if configured != expected_launch(base, 4):
        raise ValueError("Original fullquality validated config changed")
    result = copy.deepcopy(configured)
    result["batch_admission_policy_config"]["layers_per_slice"] = 40
    validate_launch_config(base, result)
    return result


def validate_launch_config(base, actual):
    if actual != expected_launch(base, 40):
        raise ValueError("Full-answer launch differs beyond declared quota4-to40")


def validate_resolved_config(actual, historical):
    profile = load_treatment()
    manifest = json.loads((HERE / profile["source_manifest"]["file"]).read_text())
    pinned = manifest["historical_runs"]["raw-quality-v2-hccl-true-01"]["engine_args"]
    if historical != pinned:
        raise ValueError("Original resolved config reference changed")
    expected = copy.deepcopy(historical)
    expected["batch_admission_policy_config"]["layers_per_slice"] = 40
    if actual != expected:
        raise ValueError("Actual resolved full-answer config changed beyond quota")


def treatment_receipt(base, actual):
    validate_launch_config(base, actual)
    profile = load_treatment()
    return {
        "profile_sha256": PROFILE_SHA,
        "base_config_sha256": profile["base_config"]["sha256"],
        "plan_file_sha256": profile["base_plan"]["sha256"],
        "change": profile["change"],
        "scope": profile["scope"],
        "launch_config_sha256": hashlib.sha256(
            json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
    }
