"""Full-answer raw-prefix rerun of the unchanged frozen 200-case quality plan.

Only the root controller runs this device-owning command. Import/dry-run is CPU.
LLM construction includes the existing compile/graph warmup; no warmup requests
are added. The external prefix module is installed only after construction.
"""

import argparse
import copy
import hashlib
import json
import os
import subprocess
import time
import traceback
from pathlib import Path

import full_answer_treatment_v1 as treatment
import prefill_collective_layout_v1 as layout
import run_quality as original
from probe_run_v1 import (
    SOURCE,
    abort_and_drain,
    file_sha,
    git,
    now,
    require_empty,
    require_empty_worker,
    save,
    scheduler_snapshot,
    source_equivalence,
    tokenizer_identities,
    validate_workers,
    worker_snapshot,
)
from score_quality import load_frozen

PLAN_SHA = "dd3e1f305475ec556dc824947f26d5fb5743242e82b5099155c95b8954bb2e65"
LAYOUT_SHA = "6431c4c0abdd869ef17e7122f681c457ad2b4d5741f86c6a0653e9fca44e02fc"
SCOPES = ("batch7-full-answer",)
BUNDLE = Path(__file__).resolve().parent
MAX_CLEANUP_STEPS = 64


def source_manifest(bundle=BUNDLE):
    manifest = json.loads((bundle / "source-manifest-v1.json").read_text())
    for item in manifest["copied_files"]:
        if file_sha(bundle / item["destination"]) != item["sha256"]:
            raise ValueError(f"Copied source changed: {item['destination']}")
    if file_sha(bundle / "prefill_collective_layout_v1.py") != LAYOUT_SHA:
        raise ValueError("External prefix module is not the frozen layout-v1 bytes")
    return manifest


def select_batches(plan, scope, bundle=BUNDLE):
    profile = treatment.load_treatment()
    if scope != profile["scope"] or plan["plan_sha256"] != PLAN_SHA:
        raise ValueError("Require explicit original batch7 full-answer scope")
    batches = [b for b in plan["batches"] if b["batch_id"] == profile["batch_id"]]
    if len(batches) != 1 or batches[0]["case_ids"] != profile["case_ids"]:
        raise ValueError("Original batch7 order/membership changed")
    if batches[0]["seed_case_id"] != profile["case_ids"][0]:
        raise ValueError("Original batch7 seed changed")
    return batches


def repository_identity(origin):
    origin = Path(origin).resolve()
    root = Path(git(origin.parent, "rev-parse", "--show-toplevel"))
    diff = subprocess.check_output(["git", "-C", str(root), "diff", "--binary", "HEAD"])
    changed = subprocess.check_output(
        ["git", "-C", str(root), "diff", "--name-only", "-z", "HEAD"]
    )
    untracked = subprocess.check_output(
        ["git", "-C", str(root), "ls-files", "--others", "--exclude-standard", "-z"]
    )
    files = []
    for raw in sorted(set(changed.split(b"\0") + untracked.split(b"\0")) - {b""}):
        name = raw.decode()
        path = root / name
        files.append(
            {
                "path": name,
                "exists": path.exists(),
                "sha256": file_sha(path) if path.is_file() else None,
            }
        )
    return {
        "path": str(origin),
        "sha256": file_sha(origin),
        "commit": git(origin.parent, "rev-parse", "HEAD"),
        "status": git(origin.parent, "status", "--short"),
        "diff_sha256": hashlib.sha256(diff).hexdigest(),
        "diff_bytes_utf8": diff.decode(),
        "changed_files": files,
    }


def source_guard(source, manifest):
    equivalence = source_equivalence(source)
    if len(equivalence["existing_runtime_files"]) != 20:
        raise ValueError("Expected all 20 original f7 runtime source files")
    expected = manifest["historical_runs"]["raw-quality-v2-hccl-true-01"]["sources"]
    identities = {}
    for name in ("vllm", "vllm_ascend"):
        identities[name] = repository_identity(expected[name]["path"])
        if identities[name] != expected[name]:
            raise ValueError(f"Original core/Ascend source changed: {name}")
    identities["vllm_muxpd"] = repository_identity(
        source / "src/vllm_muxpd/__init__.py"
    )
    if (
        identities["vllm_muxpd"]["commit"] != SOURCE
        or identities["vllm_muxpd"]["status"]
        or identities["vllm_muxpd"]["sha256"] != expected["vllm_muxpd"]["sha256"]
    ):
        raise ValueError("Clean source diagnostic addition bridge failed")
    return {"sources": identities, "equivalence": equivalence}


def prepare(scope, source, bundle=BUNDLE):
    manifest = source_manifest(bundle)
    plan, cases, _ = load_frozen(bundle / "frozen-v2")
    if plan["plan_sha256"] != PLAN_SHA or plan["case_count"] != 200:
        raise ValueError("Original 200-case plan changed")
    batches = select_batches(plan, scope, bundle)
    config = original.validate(
        "raw", json.loads((bundle / "raw-engine-args-v1.json").read_text()), plan
    )
    config = treatment.apply_treatment(
        json.loads((bundle / "raw-engine-args-v1.json").read_text()), config
    )
    return plan, cases, batches, config, manifest, source_guard(source, manifest)


def validate_layout_admissions(rows, admissions, receipt_path, batches, cases):
    """Bind every layout admission to the original host admission and scheduler.

    Actual D rows come from the scheduler receipt; a D1 assumption cannot supply
    missing evidence. The normal seed-D0/peer-D1 pattern is reported separately.
    """
    by_case = {c["case_id"]: c for c in cases}
    if len(admissions) != 2 * len(batches):
        raise ValueError("Missing seed/peer admission")
    scheduled = []
    for line in receipt_path.read_text().splitlines():
        item = json.loads(line)
        if item["event"] == "schedule" and item["new_prefill_ids"]:
            scheduled.append(item)
    if len(scheduled) != len(admissions):
        raise ValueError("Unexpected number of actually scheduled P cohorts")
    expected, pattern = [], []
    for index, (admission, schedule) in enumerate(
        zip(admissions, scheduled, strict=True)
    ):
        batch = batches[index // 2]
        seed_stage = index % 2 == 0
        members = batch["case_ids"][:1] if seed_stage else batch["case_ids"][1:]
        if (
            admission["batch_id"] != batch["batch_id"]
            or admission["stage"] != ("seed" if seed_stage else "peers")
            or [b["case_id"] for b in admission["bindings"]] != members
        ):
            raise ValueError("Frozen batch admission identity/order changed")
        p_counts = {
            b["internal"]: len(by_case[b["case_id"]]["prompt_token_ids"])
            for b in admission["bindings"]
        }
        counts = schedule["scheduled_tokens"]
        d_counts = {rid: n for rid, n in counts.items() if rid not in p_counts}
        if (
            schedule["batch_id"] != batch["batch_id"]
            or set(schedule["new_prefill_ids"]) != set(p_counts)
            or {rid: counts[rid] for rid in p_counts} != p_counts
        ):
            raise ValueError("Layout P rows do not match complete frozen prompts")
        seed_id = (
            admissions[index - 1]["bindings"][0]["internal"] if not seed_stage else None
        )
        if (
            (seed_stage and d_counts)
            or (not seed_stage and set(d_counts) - {seed_id})
            or any(n != 1 for n in d_counts.values())
        ):
            raise ValueError("Unexpected actual D admission in sequential batch")
        expected.append((p_counts, d_counts))
        pattern.append(
            {
                "batch_id": batch["batch_id"],
                "stage": admission["stage"],
                "d_rows": sum(d_counts.values()),
                "p_request_count": len(p_counts),
            }
        )
    treated = sum(bool(d) for _, d in expected)
    layout.validate_receipts(
        rows,
        LAYOUT_SHA,
        mode="prefix",
        expected_treated_cohorts=treated,
        expected_completed=len(expected),
    )
    for row in rows:
        for cohort, (p_counts, d_counts) in zip(row["cohorts"], expected, strict=True):
            if (
                cohort["admission_p_counts"] != p_counts
                or cohort["admission_d_counts"] != d_counts
                or not (cohort["calls"] if d_counts else cohort["zero_d_bypass_calls"])
            ):
                raise ValueError("Worker layout differs from actual host admission")
    return {
        "completed_cohorts": len(expected),
        "treated_cohorts": treated,
        "actual_admission_pattern": pattern,
        "all_seed_d0_peer_d1": all(
            x["d_rows"] == (i % 2) for i, x in enumerate(pattern)
        ),
    }


def restore_receipts(scheduler, originals):
    if scheduler is not None and originals is not None:
        scheduler.schedule, scheduler.update_from_output = originals


def run(args):
    plan, cases, batches, config, manifest, identity = prepare(args.scope, args.source)
    args.output.mkdir(parents=True, exist_ok=False)
    forbidden = (
        "MUXPD_NUMERIC_OUTPUT",
        "MUXPD_PRESSURE_TRACE_DIR",
        "VLLM_TORCH_PROFILER_DIR",
    )
    if any(os.environ.get(key) for key in forbidden):
        raise ValueError("Remove unrelated observers/profilers")
    if os.environ.get("HCCL_DETERMINISTIC") != "true" or os.environ.get(
        "VLLM_BATCH_INVARIANT"
    ) not in (None, "0"):
        raise ValueError("Require original HCCL=true and batch invariance off")
    os.environ["VLLM_ENABLE_V1_MULTIPROCESSING"] = "0"
    report = {
        "schema": "muxpd-q40-full-answer-run-v1",
        "role": "raw",
        "profile": "raw-prefix",
        "scope": args.scope,
        "scheduling_treatment": treatment.treatment_receipt(
            json.loads((BUNDLE / "raw-engine-args-v1.json").read_text()), config
        ),
        "runtime_candidate": False,
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "layout_mode": "prefix",
        "plan_sha256": PLAN_SHA,
        "selected_batch_ids": [b["batch_id"] for b in batches],
        "selected_case_ids": [c for b in batches for c in b["case_ids"]],
        "process_id": os.getpid(),
        "started_at": now(),
        "engine_args": config,
        "base_engine_args": copy.deepcopy(config),
        "outputs": [],
        "admissions": [],
        "errors": [],
        "producer_sha256": file_sha(__file__),
        "original_producer_sha256": file_sha(BUNDLE / "run_quality.py"),
        "original_scorer_sha256": file_sha(BUNDLE / "score_quality.py"),
        "layout_module_sha256": LAYOUT_SHA,
        "source_manifest_sha256": file_sha(BUNDLE / "source-manifest-v1.json"),
        "source_equivalence": identity["equivalence"],
        "sources": identity["sources"],
        "runtime_environment": original.runtime_environment(),
        "collection_complete": False,
        "layout_restored": False,
        "shutdown_returned": False,
        "passed": False,
        "qualification_claim": "Posterior original batch7 natural complete-answer diagnostic; no runtime candidate or full200 quality acceptance.",
        "warmup": "Existing LLM constructor warmup only; zero extra request warmups.",
    }
    save(args.output / "run.json", report)
    llm, scheduler, originals, baseline = None, None, None, None
    layout_attempted = False
    coverage, context = {}, {"global_step": 0, "batch_id": -1}
    by_id = {row["case_id"]: row for row in cases}
    try:
        if (
            report["runtime_environment"]
            != manifest["historical_runs"]["raw-quality-v2-hccl-true-01"][
                "runtime_environment"
            ]
        ):
            raise RuntimeError(
                "Runtime environment differs from original quality before model construction"
            )
        from tokenizers import Tokenizer
        from vllm import LLM, SamplingParams
        from vllm.v1.engine.core_client import InprocClient

        report["tokenizer_files"] = tokenizer_identities(plan)
        decoder = Tokenizer.from_file(plan["tokenizer_files"]["tokenizer.json"]["path"])
        model_identity = treatment.load_treatment()["model_config_identity"]
        if file_sha(model_identity["path"]) != model_identity["sha256"]:
            raise ValueError("Model configuration differs from qualified short q40")
        report["model_config_identity"] = model_identity
        llm = LLM(**config)
        engine = llm.llm_engine
        if not isinstance(engine.engine_core, InprocClient):
            raise TypeError("Actual coordinator is not InprocClient")
        core = engine.engine_core.engine_core
        scheduler = core.scheduler
        report["sources"] = original.source_identities()
        if report["sources"] != identity["sources"]:
            raise RuntimeError("Imported source differs from pinned preflight source")
        report["source_after_startup"] = source_guard(args.source, manifest)
        expected_config = manifest["historical_runs"]["raw-quality-v2-hccl-true-01"][
            "engine_args"
        ]
        treatment.validate_resolved_config(config, expected_config)
        cfg = core.vllm_config
        report["effective"] = {
            "max_model_len": cfg.model_config.max_model_len,
            "max_num_seqs": cfg.scheduler_config.max_num_seqs,
            "max_num_batched_tokens": cfg.scheduler_config.max_num_batched_tokens,
            "enable_chunked_prefill": cfg.scheduler_config.enable_chunked_prefill,
            "tensor_parallel_size": cfg.parallel_config.tensor_parallel_size,
        }
        if report["effective"] != {k: config[k] for k in report["effective"]}:
            raise RuntimeError("Effective runtime differs from frozen launch arguments")
        report["scheduler_class"] = (
            type(scheduler).__module__ + "." + type(scheduler).__name__
        )
        report["engine_coordinator"] = type(engine.engine_core).__name__
        baseline = scheduler_snapshot(engine)
        require_empty(baseline, baseline)
        report["idle_baseline"] = baseline
        report["worker_before"] = llm.collective_rpc(worker_snapshot, timeout=60)
        validate_workers(report["worker_before"], "raw-layout-plain")
        for row in report["worker_before"]:
            require_empty_worker(row)
        layout_attempted = True
        report["layout_installation"] = llm.collective_rpc(
            layout.install_on_worker, args=("prefix",), timeout=60
        )
        layout.validate_receipts(
            report["layout_installation"],
            LAYOUT_SHA,
            mode="prefix",
            expected_treated_cohorts=0,
            expected_completed=0,
        )
        params = SamplingParams(**plan["sampling"])
        started = time.monotonic()
        with (args.output / "scheduler-receipts.jsonl").open(
            "x", buffering=1
        ) as receipts:
            originals = scheduler.schedule, scheduler.update_from_output
            original.install_receipts(scheduler, receipts, context, coverage)
            for batch in batches:
                context["batch_id"] = batch["batch_id"]
                members = [by_id[rid] for rid in batch["case_ids"]]
                mappings = original.enqueue_bound(llm, members[:1], params)
                seed = mappings[0]["internal"]
                admitted = {mappings[0]["external"]: members[0]}
                report["admissions"].append(
                    {**context, "stage": "seed", "bindings": mappings}
                )
                released, finished = False, set()
                while engine.has_unfinished_requests():
                    if (
                        context["global_step"] >= plan["maximum_engine_steps"]
                        or time.monotonic() - started > plan["maximum_wall_seconds"]
                    ):
                        raise RuntimeError(
                            "Original frozen bounded-work limit exceeded"
                        )
                    context["global_step"] += 1
                    outputs = engine.step()
                    seed_finished_tokens = None
                    for output in outputs:
                        if not output.finished:
                            continue
                        if (
                            output.request_id not in admitted
                            or output.request_id in finished
                            or len(output.outputs) != 1
                        ):
                            raise RuntimeError(
                                "Unknown, duplicate or multi-sample final output"
                            )
                        finished.add(output.request_id)
                        case, item = admitted[output.request_id], output.outputs[0]
                        if list(output.prompt_token_ids) != case["prompt_token_ids"]:
                            raise RuntimeError(
                                "Returned prompt differs from frozen token IDs"
                            )
                        tokens = list(map(int, item.token_ids))
                        report["outputs"].append(
                            {
                                "case_id": case["case_id"],
                                "request_id": output.request_id,
                                "finished": True,
                                "token_ids": tokens,
                                "text": decoder.decode(
                                    tokens, skip_special_tokens=True
                                ),
                                "finish_reason": item.finish_reason,
                                "stop_reason": item.stop_reason,
                            }
                        )
                        if case["case_id"] == batch["seed_case_id"]:
                            seed_finished_tokens = len(tokens)
                    if not released:
                        seed_request = scheduler.requests.get(seed)
                        count = (
                            seed_request.num_output_tokens
                            if seed_request is not None
                            else seed_finished_tokens
                        )
                        if count is None or count == 0:
                            if seed_request is None:
                                raise RuntimeError(
                                    "Seed completed without an observed output token"
                                )
                            continue
                        if count != 1:
                            raise RuntimeError(
                                "Missed exact first-output-token admission gate"
                            )
                        bindings = original.enqueue_bound(llm, members[1:], params)
                        admitted.update(
                            {
                                row["external"]: case
                                for row, case in zip(bindings, members[1:], strict=True)
                            }
                        )
                        report["admissions"].append(
                            {
                                **context,
                                "stage": "peers",
                                "bindings": bindings,
                                "seed_output_tokens": count,
                                "seed_still_live": seed_request is not None,
                            }
                        )
                        released = True
                if (
                    not released
                    or len(finished) != len(members)
                    or finished != set(admitted)
                ):
                    raise RuntimeError(
                        "Batch ended without every frozen request returning"
                    )
                save(args.output / "run.json", report)
        restore_receipts(scheduler, originals)
        originals = None
        report["answer_engine_steps"] = context["global_step"]
        report["answer_seconds"] = time.monotonic() - started
        # No live request may be cancelled on the success path. A final empty
        # maintenance turn only flushes naturally finished IDs to the workers.
        if scheduler.requests or engine.has_unfinished_requests():
            raise RuntimeError("Natural full-answer collection retained live requests")
        report["terminal_maintenance"] = abort_and_drain(engine, MAX_CLEANUP_STEPS)
        if report["terminal_maintenance"]["aborted_internal_ids"]:
            raise RuntimeError("Success path cancelled live requests")
        report["final_state"] = scheduler_snapshot(engine)
        require_empty(report["final_state"], baseline)
        report["worker_after"] = llm.collective_rpc(worker_snapshot, timeout=60)
        validate_workers(report["worker_after"], "raw-layout-plain")
        for row in report["worker_after"]:
            require_empty_worker(row)
        report["layout_final"] = llm.collective_rpc(
            layout.snapshot_on_worker, timeout=60
        )
        report["layout_admission_validation"] = validate_layout_admissions(
            report["layout_final"],
            report["admissions"],
            args.output / "scheduler-receipts.jsonl",
            batches,
            cases,
        )
        report["layout_uninstall"] = llm.collective_rpc(
            layout.uninstall_on_worker, timeout=60
        )
        layout.validate_uninstall_receipts(
            report["layout_uninstall"], LAYOUT_SHA, mode="prefix"
        )
        report["layout_restored"] = True
        report["collection_complete"] = len(report["outputs"]) == len(
            report["selected_case_ids"]
        ) and {x["case_id"] for x in report["outputs"]} == set(
            report["selected_case_ids"]
        )
    except BaseException:  # noqa: BLE001 -- keep the original failure and clean owned state
        report["errors"].append(traceback.format_exc())
    finally:
        restore_receipts(scheduler, originals)
        if llm is not None:
            safely_drained = False
            if not report["collection_complete"]:
                try:
                    report["failure_cleanup"] = abort_and_drain(
                        llm.llm_engine, MAX_CLEANUP_STEPS
                    )
                    report["failure_final_state"] = scheduler_snapshot(llm.llm_engine)
                    if baseline is None:
                        raise RuntimeError("No baseline for safe cleanup verification")
                    require_empty(report["failure_final_state"], baseline)
                    report["failure_worker_state"] = llm.collective_rpc(
                        worker_snapshot, timeout=60
                    )
                    validate_workers(report["failure_worker_state"], "raw-layout-plain")
                    for row in report["failure_worker_state"]:
                        require_empty_worker(row)
                    safely_drained = True
                except BaseException:  # noqa: BLE001 -- cleanup never promotes collection success
                    report["errors"].append(traceback.format_exc())
            if layout_attempted and not report["layout_restored"] and safely_drained:
                try:
                    report["layout_failure_uninstall"] = llm.collective_rpc(
                        layout.uninstall_on_worker, args=(True,), timeout=60
                    )
                    layout.validate_uninstall_receipts(
                        report["layout_failure_uninstall"],
                        LAYOUT_SHA,
                        mode="prefix",
                        allow_incomplete=True,
                    )
                    report["layout_failure_cleanup_restored"] = True
                except BaseException:  # noqa: BLE001 -- keep cleanup failure separate
                    report["errors"].append(traceback.format_exc())
            try:
                llm.llm_engine.engine_core.shutdown()
                report["shutdown_returned"] = True
            except BaseException:  # noqa: BLE001 -- preserve shutdown failure
                report["errors"].append(traceback.format_exc())
        try:
            report["sources_after_shutdown"] = source_guard(args.source, manifest)
        except BaseException:  # noqa: BLE001 -- retain provenance failure
            report["errors"].append(traceback.format_exc())
        report["finished_at"] = now()
        report["mixed_coverage"] = {
            "steps_per_batch": coverage,
            "covered_batches": sorted(coverage),
            "uncovered_batches": [
                b["batch_id"] for b in batches if b["batch_id"] not in coverage
            ],
            "meaning": "Actual P layer progress plus D token retirement in one transaction; not physical kernel overlap",
        }
        receipt_path = args.output / "scheduler-receipts.jsonl"
        if receipt_path.exists():
            report["scheduler_receipts_sha256"] = file_sha(receipt_path)
        report["passed"] = bool(
            report["collection_complete"]
            and report["layout_restored"]
            and report["shutdown_returned"]
            and not report["errors"]
        )
        save(args.output / "run.json", report)
    print(
        json.dumps(
            {
                "passed": report["passed"],
                "scope": args.scope,
                "outputs": len(report["outputs"]),
                "errors": report["errors"],
            }
        )
    )
    return 0 if report["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("dry-run", "run"))
    parser.add_argument("--scope", choices=SCOPES, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    args.source = args.source.resolve()
    if args.command == "dry-run":
        plan, _, batches, _, _, identity = prepare(args.scope, args.source)
        print(
            json.dumps(
                {
                    "validated": True,
                    "scope": args.scope,
                    "plan_sha256": PLAN_SHA,
                    "batch_ids": [b["batch_id"] for b in batches],
                    "case_count": sum(len(b["case_ids"]) for b in batches),
                    "max_tokens": plan["sampling"]["max_tokens"],
                    "maximum_engine_steps": plan["maximum_engine_steps"],
                    "maximum_wall_seconds": plan["maximum_wall_seconds"],
                    "layout_module_sha256": LAYOUT_SHA,
                    "source_equivalence": identity["equivalence"],
                },
                indent=2,
            )
        )
        return 0
    if args.output is None:
        parser.error("run requires a fresh --output directory")
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
