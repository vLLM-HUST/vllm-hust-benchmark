"""One terminal q40 natural full-answer batch7 diagnostic, not full200 acceptance."""

import argparse
import json
from pathlib import Path

import batch7_full_analysis_v1 as core


def analyze(run, bundle, output):
    core.require(not output.exists(), "Refuse to overwrite an earlier assessment")
    result = {
        "schema": "muxpd-q40-batch7-full-analysis-v1",
        "passed": False,
        "collection_valid": False,
        "trajectory_qualified": False,
        "errors": [],
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "runtime_candidate": False,
        "scope": "One posterior original batch7 full-answer diagnostic. Historical full200 arms include preceding batches; no performance or full200 quality acceptance.",
    }
    try:
        refs, qualification = core.verify_references(bundle)
        result["predecessor_qualification"] = qualification
        proof, report, plan, cases, histories, short = core.audit_attempt(
            run, bundle, refs, qualification
        )
        result["collection_valid"] = True
        result["collection_proof"] = proof
        # Save the real terminal score table before trajectory qualification;
        # a failed extension or a length answer must never hide observed scores.
        result["answer_diagnostic"] = core.score_eight(
            plan, cases, histories, report, bundle / "frozen-v2"
        )
        diagnostic = result["answer_diagnostic"]
        result["local_answer_outcome"] = {
            "correct_count": diagnostic["scores"]["q40"]["correct"],
            "case_count": 8,
            "all_complete": diagnostic["scores"]["q40"]["all_complete"],
            "no_new_wrong_on_both_native_correct": not diagnostic[
                "new_wrong_on_both_native_correct"
            ],
            "new_wrong_on_both_native_correct": diagnostic[
                "new_wrong_on_both_native_correct"
            ],
            "resolved_old_prefix_losses": diagnostic["resolved_old_prefix_losses"],
            "scope": "Local eight-case outcome only; does not determine collection validity or full200 acceptance.",
        }
        extension = core.check_extension(report, short)
        result["short_plain_trajectory_extension"] = extension
        result["trajectory_qualified"] = extension["passed"]
        core.require(
            extension["passed"],
            "Full answers do not extend all eight qualified short plain prefixes",
        )
        result["passed"] = True
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.run, args.bundle, args.output)
    print(
        json.dumps(
            {
                k: result[k]
                for k in (
                    "passed",
                    "collection_valid",
                    "trajectory_qualified",
                    "errors",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
