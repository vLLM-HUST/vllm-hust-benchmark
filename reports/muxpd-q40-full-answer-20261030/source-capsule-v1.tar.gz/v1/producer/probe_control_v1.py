"""Root-owned bounded diagnostic controller; dry-run performs no NPU calls."""

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import time
from pathlib import Path

from probe_run_v1 import (
    PROFILES,
    engine_config,
    file_sha,
    load_plan,
    now,
    save,
    source_equivalence,
)

FILES = (
    "probe_run_v1.py",
    "probe_control_v1.py",
    "plan-v1.json",
    "native-engine-args-v1.json",
    "raw-engine-args-v1.json",
    "layer_capture_v3.py",
    "prefill_collective_layout_v1.py",
)


def audit_terminal_log(path):
    data = path.read_bytes()
    lines = data.decode(errors="replace").splitlines()
    tracebacks = [
        i + 1
        for i, line in enumerate(lines)
        if "Traceback (most recent call last):" in line
    ]
    ownership = [
        i + 1
        for i, line in enumerate(lines)
        if "RuntimeError: MuxPD graph method changed externally:" in line
    ]
    return {
        "sha256": file_sha(path),
        "bytes": len(data),
        "traceback_line_numbers": tracebacks,
        "graph_ownership_error_line_numbers": ownership,
        "passed": not tracebacks and not ownership,
        "scope": "Terminal Python traceback and known graph ownership errors. SIGTERM executor cleanup warning alone is not a traceback.",
    }


def inventory(text):
    physical = set(re.findall(r"^\|\s*(\d+)\s+910B2\s*\|", text, re.MULTILINE))
    idle = set(re.findall(r"No running processes found in NPU (\d+)\b", text))
    if len(physical) != 4 or idle != physical:
        raise RuntimeError("Expected four idle 910B2 cards")
    return sorted(physical, key=int)


def members(group):
    found = []
    for path in Path("/proc").glob("[0-9]*/stat"):
        try:
            raw = path.read_text()
        except (FileNotFoundError, ProcessLookupError):
            continue
        fields = raw[raw.rfind(")") + 2 :].split()
        if fields[0] != "Z" and int(fields[2]) == group:
            found.append(int(path.parent.name))
    return sorted(found)


def environment(source, destination):
    env = os.environ.copy()
    if env.get("VLLM_BATCH_INVARIANT") not in (None, "0"):
        raise ValueError("Preserve batch-invariance-off profile")
    if any(
        env.get(k)
        for k in (
            "MUXPD_NUMERIC_OUTPUT",
            "MUXPD_PRESSURE_TRACE_DIR",
            "VLLM_TORCH_PROFILER_DIR",
        )
    ):
        raise ValueError("Remove unrelated observer/profiler environments")
    env.update(
        ASCEND_RT_VISIBLE_DEVICES="0,1,2,3",
        OMP_NUM_THREADS="1",
        HCCL_DETERMINISTIC="true",
        VLLM_USE_V2_MODEL_RUNNER="0",
        VLLM_ENABLE_V1_MULTIPROCESSING="0",
        PYTHONDONTWRITEBYTECODE="1",
        VLLM_CACHE_ROOT=str(destination / "compiler-cache"),
    )
    env["PYTHONPATH"] = ":".join(
        [
            str(source / "src"),
            "/root/workspace/vllm-hust",
            "/root/workspace/vllm-ascend-hust",
            env.get("PYTHONPATH", ""),
        ]
    )
    return env


def preview(args):
    if (
        not re.fullmatch(r"[a-z0-9][a-z0-9._-]+", args.label)
        or not 60 <= args.timeout <= 900
    ):
        raise ValueError("Require safe fresh label and timeout60..900")
    expected = sorted(args.expected_physical.split(","), key=int)
    if len(expected) != 4 or len(set(expected)) != 4:
        raise ValueError("Require four distinct root-selected physical devices")
    destination = args.output_root / args.label
    if destination.exists():
        raise FileExistsError(destination)
    source = source_equivalence(args.source)
    plan = load_plan(args.bundle / "plan-v1.json")
    role = args.profile.split("-")[0]
    config_path = args.bundle / f"{role}-engine-args-v1.json"
    base_config = json.loads(config_path.read_text())
    config = engine_config(args.profile, base_config, plan)
    hashes = {name: file_sha(args.bundle / name) for name in FILES}
    freeze = args.bundle / "freeze-manifest-v1.json"
    if not freeze.exists() or json.loads(freeze.read_text())["files"] != hashes:
        raise ValueError("Producer/config bytes differ from frozen bundle")
    env = environment(args.source, destination)
    command = [
        str(args.python),
        str(destination / "producer/probe_run_v1.py"),
        "--profile",
        args.profile,
        "--layout-mode",
        args.layout_mode,
        "--source",
        str(args.source),
        "--plan",
        str(destination / "plan-v1.json"),
        "--config",
        str(destination / "base-engine-args.json"),
        "--output",
        str(destination / "results"),
    ]
    return {
        "schema": "muxpd-quality-collective-layout-controller-v1",
        "label": args.label,
        "profile": args.profile,
        "layout_mode": args.layout_mode,
        "source": str(args.source),
        "source_commit": source["observer_source"],
        "source_equivalence": source,
        "destination": str(destination),
        "command": command,
        "base_engine_args": base_config,
        "launch_engine_args": config,
        "files": hashes,
        "freeze_manifest_sha256": file_sha(freeze),
        "expected_physical": expected,
        "environment": {
            k: env.get(k)
            for k in (
                "ASCEND_RT_VISIBLE_DEVICES",
                "HCCL_DETERMINISTIC",
                "VLLM_BATCH_INVARIANT",
                "VLLM_USE_V2_MODEL_RUNNER",
                "VLLM_ENABLE_V1_MULTIPROCESSING",
                "PYTHONPATH",
                "PYTHONDONTWRITEBYTECODE",
                "OMP_NUM_THREADS",
                "VLLM_CACHE_ROOT",
            )
        },
    }


def execute(args, record):
    root = Path(record["destination"])
    root.mkdir(parents=True, exist_ok=False)
    (root / "producer").mkdir()
    for name, sha in record["files"].items():
        shutil.copyfile(args.bundle / name, root / "producer" / name)
        if file_sha(root / "producer" / name) != sha:
            raise RuntimeError("Producer changed while copying")
    shutil.copyfile(
        args.bundle / "freeze-manifest-v1.json",
        root / "producer/freeze-manifest-v1.json",
    )
    shutil.copyfile(args.bundle / "plan-v1.json", root / "plan-v1.json")
    role = args.profile.split("-")[0]
    shutil.copyfile(
        args.bundle / f"{role}-engine-args-v1.json", root / "base-engine-args.json"
    )
    record.update(
        started_at=now(), timeout_seconds=args.timeout, errors=[], passed=False
    )
    process = None
    save(root / "controller.json", record)
    try:
        before = subprocess.check_output(["npu-smi", "info"], timeout=30)
        (root / "npu-before.txt").write_bytes(before)
        record["idle_physical_before"] = inventory(before.decode())
        if record["idle_physical_before"] != record["expected_physical"]:
            raise RuntimeError(
                "Physical card allocation differs from root-selected inventory"
            )
        record["controller_pid"] = os.getpid()
        with (root / "process.log").open("x") as log:
            process = subprocess.Popen(
                record["command"],
                cwd=args.source,
                env=environment(args.source, root),
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            record["pid"] = record["process_group"] = process.pid
            record["owned_members_after_spawn"] = members(process.pid)
            save(root / "controller.json", record)
            start, notice = time.monotonic(), 0
            while process.poll() is None:
                elapsed = time.monotonic() - start
                if elapsed > args.timeout:
                    record["timeout"] = True
                    raise TimeoutError("Diagnostic exceeded finite total deadline")
                if elapsed >= notice:
                    print(
                        f"{args.label}: pid={process.pid} running {elapsed:.0f}s",
                        flush=True,
                    )
                    notice = elapsed + 30
                time.sleep(1)
    except BaseException as error:  # noqa: BLE001 -- bounded owned-process cleanup on interruptions
        record["errors"].append(repr(error))
    finally:
        if process is not None:
            record["owned_members_before_cleanup"] = members(process.pid)
            if record["owned_members_before_cleanup"]:
                record["cleanup_required"] = True
                try:
                    os.killpg(process.pid, signal.SIGINT)
                    deadline = time.monotonic() + 45
                    while members(process.pid) and time.monotonic() < deadline:
                        time.sleep(1)
                    if members(process.pid):
                        record["forced_termination"] = True
                        os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                record["errors"].append("Owned producer did not exit after cleanup")
            record["exit_code"] = process.returncode
            record["owned_members_after_cleanup"] = members(process.pid)
        try:
            after = subprocess.check_output(["npu-smi", "info"], timeout=30)
            (root / "npu-after.txt").write_bytes(after)
            record["idle_physical_after"] = inventory(after.decode())
            if record["idle_physical_after"] != record.get("idle_physical_before"):
                raise RuntimeError("Physical inventory changed across run")
        except Exception as error:  # noqa: BLE001 -- preserve final device inventory failure
            record["errors"].append(repr(error))
        try:
            child = json.loads((root / "results/run.json").read_text())
        except (FileNotFoundError, ValueError) as error:
            child = {}
            record["errors"].append(repr(error))
        try:
            record["terminal_process_log_audit"] = audit_terminal_log(
                root / "process.log"
            )
            if not record["terminal_process_log_audit"]["passed"]:
                record["errors"].append(
                    "Terminal worker log contains a traceback or graph ownership error"
                )
        except Exception as error:  # noqa: BLE001 -- retain absent/unreadable log
            record["errors"].append(repr(error))
        record["passed"] = bool(
            record.get("exit_code") == 0
            and not record["errors"]
            and not record.get("cleanup_required")
            and not record.get("owned_members_after_cleanup", ["unknown"])
            and child.get("passed")
            and child.get("collection_complete")
            and child.get("shutdown_returned")
        )
        record["finished_at"] = now()
        save(root / "controller.json", record)
    print(
        json.dumps(
            {"label": args.label, "passed": record["passed"], "output": str(root)}
        ),
        flush=True,
    )
    return 0 if record["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("dry-run", "run"))
    parser.add_argument("--profile", choices=PROFILES, required=True)
    parser.add_argument(
        "--layout-mode", choices=("prefix", "copy_only", "suffix"), required=True
    )
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--expected-physical", default="0,2,3,4")
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path(__file__).resolve().parent.parent / "runs",
    )
    parser.add_argument(
        "--python",
        type=Path,
        default=Path("/root/workspace/.muxpd-ecpa-runtime/bin/python"),
    )
    args = parser.parse_args()
    for key in ("source", "bundle", "output_root"):
        setattr(args, key, getattr(args, key).resolve())
    args.python = args.python.absolute()
    record = preview(args)
    if args.command == "dry-run":
        print(json.dumps(record, indent=2))
        return 0
    return execute(args, record)


if __name__ == "__main__":
    raise SystemExit(main())
