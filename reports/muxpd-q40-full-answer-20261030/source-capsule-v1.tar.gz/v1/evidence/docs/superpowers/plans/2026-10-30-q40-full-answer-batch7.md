# q40 original batch7 complete-answer diagnostic

Root authorizes CPU implementation now. Short q40 pair primary570a82518880e41439e741065243d4c795f9b252f0bd98dbf8a4c95b5c7546bc qualified all8 observed/plain prefixes and all208 target logits identical to native; previous target183/207 and peer07461 token203 divergence disappear. Independent short audit must pass before this device freeze. This is promising local trajectory evidence, not a complete answer or runtime fix.

Use the narrow design /root/workspace/muxpd-target-prefill-next-20261030/q40-full-answer-followup-v1.md (SHAa3732fd346ecd614bef6125b2297e730956b3dd03f94015e2c15a38051c97842), correcting only stale statement that q40 observed is live. Both short arms are terminal. All prior protocols remain immutable.

## Scope and actual inputs

New isolated bundle /root/workspace/muxpd-q40-full-answer-batch7-20261030. Select only original frozen200 batch7 with all8 exact prompts/order, but retain complete frozen200 plan/canonical adapter bytes. Original sampling temperature0/seed42/max_tokens8192/ignore_eosfalse/detokenizefalse. Seed first output exactly1, then original7peers. No token208 abort; collect all8 naturally finished outputs including any true length8192 termination. Preserve full tokenIDs/text/finish reason and unchanged canonical scorer. Do not omit, retry, relabel or alter a length result.

Keep clean6c currentsource, exact external prefix treatment, model/native/Ascend identity and original config. Only quota4->40 changes. No numeric observer/graph tap/source invention or candidate-identity bypass. Both backendfusionflags false, originalDgraph/isolatedoverlap unchanged.

## Driver and controller (peer_p_harness)

Derive old quality-v1/quality_run_v1.py narrowly: add explicit batch7-full-answer scope; original collection/seed admission/enqueue/natural finish/decoding/maintenance/no live cancellation/uninstall/shutdown loop AST unchanged except selection and explicit exact quota adapter. Retain old run_quality.py receipts and score_quality.py literal. Add full-answer treatment sidecar bound to original200 plan/raw config; do not reuse short208 sidecar as though sameplan.

Reuse old full-answer timeout bounds workload10800/controller12600 (or stricter evidence-backed bound after review), with one declared q40 attempt and exact physical3/4/5/6. Root owns model/NPU lifecycle. Port current controller's terminal-before-child/log/NPY proof; old quality controller's unconditional postcleanup reads must not return. Require owned groupempty, cleanexit/no forcedcleanup,4idle and externalhookrestoration/empty runtime state. Do not change existing frozen producers. Prepare only one q40 attempt now; any later matched q4 full8 control requires a new explicit root decision/versioned matrix, not ad hoc retry.

## Analyzer and evidence (peer_p_helper)

Terminal-first qualification then original source/model/tokenizer/config/sampling/prompt/admission checks. Reuse original scheduler receipt installer unchanged and verify actualpeerP0->40 oneadvancement,7completeACK/81treatedPcalls/twooriginalPcohorts, no P recompute/preemption/cancellation. Full run naturally changes activeD batchsize; derive actual graph replay totals from schedules and ensure no serving fallback/failure, without imposing short208replays or fixed209/208lengths.

Score all8 actual outputs with unchanged score_quality.score/canonical extractor; compare against bothnative/raw/oldprefix original full200 rows using same exact8caseIDs. Report each row answer/gold/correctness/finishreason/tokenlength, missing/error/invalid, old/new wrong or length. Historical200 references have prior7batch history, so this fresh posteriorbatch result is not a matched causal comparison. Check fulloutput extends each qualified q40 short plain prefix (seed209/other208); mismatch remains failure of trajectory-extension qualification, not a silent retarget. Do not call full200 table on8outputs. full_quality_gate_attempted=false; full_frozen_plan_passed=null; runtime_candidate=false.

If q40 produces a correct stopped07338 without new local losses, root next decides matched fresh q4 full8 and canonical runtime integration/affectedposterior32/freshfull200. If it fails, retain full result and choose next cause from evidence. No full-quality/performance conclusion here.

## Review and tests

Helper/harness coordinate sidecar schema and producer FILES without shared edits. Independent reviewer checks source AST, configuration-only override, genuine all8-natural collection, terminal-first gates, exact canonical scoring and first208 extension. Use focused RED/GREEN tests and already-terminal metadata/scorer fixtures; avoid repeating unrelated or large vector suites. Any CPU synthetic q40 fixture must be labelled and cannot be promoted to hardware evidence. Root fresh preflight+frozen map and independent READY precede one model attempt. Root verifies terminal before any child/log/output reads.
