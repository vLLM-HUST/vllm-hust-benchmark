"""Terminal-first full-answer batch7 diagnostic; canonical scoring is unchanged."""

import hashlib
import importlib.util
import json
from pathlib import Path

SCORER_SHA = "157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd"
TARGET = "mmlu-pro-07338"
SEED = "mmlu-pro-07151"


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
    }


def require_terminal(directory):
    controller = json.loads((Path(directory) / "controller.json").read_text())
    require(
        controller.get("finished_at")
        and controller.get("passed") is True
        and controller.get("terminal_process_proven") is True
        and controller.get("exit_code") == 0
        and controller.get("errors") == []
        and controller.get("owned_members_after_cleanup") == []
        and not controller.get("cleanup_required")
        and not controller.get("forced_termination")
        and len(controller.get("expected_physical", [])) == 4
        and controller.get("idle_physical_after") == controller["expected_physical"],
        "Missing/unclean terminal proof; child/log deliberately not read",
    )
    return controller


def scorer():
    path = Path(__file__).with_name("score_quality.py")
    require(
        identity(path)["sha256"] == SCORER_SHA,
        "Original canonical scorer bytes changed",
    )
    spec = importlib.util.spec_from_file_location("unchanged_batch7_scorer", path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def score_eight(plan, cases, histories, run, frozen):
    original = scorer()
    frozen_plan, full_cases, extract = original.load_frozen(Path(frozen))
    order = plan["batches"][7]["case_ids"]
    require(
        plan == frozen_plan
        and [c["case_id"] for c in cases] == order
        and len(order) == 8
        and set(histories) == {"native1", "native2", "raw", "prefix"},
        "Require exact original batch7 and all four historical arms",
    )
    case_map = {c["case_id"]: c for c in full_cases}
    require(cases == [case_map[c] for c in order], "Selected prompt/gold cases changed")
    runs = {
        name: {
            **value,
            "outputs": [r for r in value["outputs"] if r["case_id"] in order],
        }
        for name, value in histories.items()
    }
    runs["q40"] = run
    scores = {
        name: original.score(value, plan, cases, extract)
        for name, value in runs.items()
    }
    rows = []
    for i, case in enumerate(cases):
        arms = {}
        for name, value in runs.items():
            found = [r for r in value["outputs"] if r["case_id"] == case["case_id"]]
            output = found[0] if found else {}
            arms[name] = {
                **scores[name]["rows"][i],
                "missing": not found,
                "error": output.get("error"),
                "stop_reason": output.get("stop_reason"),
                "token_ids_sha256": hashlib.sha256(
                    original.canonical(output.get("token_ids", []))
                ).hexdigest(),
                "text_sha256": hashlib.sha256(
                    output.get("text", "").encode()
                ).hexdigest(),
            }
        stable = arms["native1"]["correct"] and arms["native2"]["correct"]
        rows.append(
            {
                "case_id": case["case_id"],
                "original_batch_id": 7,
                "original_position": i,
                "gold": case["answer"],
                "arms": arms,
                "both_native_correct": stable,
                "new_wrong_on_both_native_correct": stable
                and not arms["q40"]["correct"],
                "old_prefix_loss_resolved": stable
                and not arms["prefix"]["correct"]
                and arms["q40"]["correct"],
                "new_length_vs": [
                    name
                    for name in histories
                    if arms["q40"]["finish_reason"] == "length"
                    and arms[name]["finish_reason"] != "length"
                ],
            }
        )
    full_native = {
        name: original.score(histories[name], plan, full_cases, extract)
        for name in ("native1", "native2")
    }
    return {
        "rows": rows,
        "scores": scores,
        "new_wrong_on_both_native_correct": [
            r["case_id"] for r in rows if r["new_wrong_on_both_native_correct"]
        ],
        "resolved_old_prefix_losses": [
            r["case_id"] for r in rows if r["old_prefix_loss_resolved"]
        ],
        "paired_diagnostic": {
            name: original.paired(scores[name], scores["q40"]) for name in histories
        },
        "historical_full200_baseline_complete": {
            name: value["all_complete"] for name, value in full_native.items()
        },
        "historical_full200_incomplete_cases": {
            name: value["incomplete"] for name, value in full_native.items()
        },
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "runtime_candidate": False,
        "scorer_sha256": SCORER_SHA,
        "scope": "Eight posterior cases scored by the unchanged canonical stop-only rule. Full200 references have preceding-batch history; no matched causal/full200 acceptance claim.",
    }


def check_extension(run, short):
    outputs = {r["case_id"]: r["token_ids"] for r in run["outputs"]}
    prefixes = short["prefixes_before_abort"]
    require(
        len(run["outputs"]) == len(outputs) == len(prefixes) == 8
        and set(outputs) == set(prefixes),
        "Extension requires all eight unique outputs",
    )
    rows = {}
    for case, prefix in prefixes.items():
        expected, actual = prefix["output_token_ids"], outputs[case]
        require(
            len(expected) == (209 if case == SEED else 208),
            "Qualified short prefix length changed",
        )
        first = next(
            (i + 1 for i, (a, b) in enumerate(zip(expected, actual)) if a != b), None
        )
        if first is None and len(actual) < len(expected):
            first = len(actual) + 1
        rows[case] = {
            "passed": first is None,
            "required_prefix_tokens": len(expected),
            "full_output_tokens": len(actual),
            "first_difference_one_based": first,
        }
    return {
        "passed": all(r["passed"] for r in rows.values()),
        "cases": rows,
        "scope": "All short plain prefixes including seed209 must extend; later full-answer lengths are not fixed.",
    }


def validate_schedule(report, receipts, cases):
    order = [c["case_id"] for c in cases]
    require(
        len(order) == 8 and order[0] == SEED and order[3] == TARGET,
        "Wrong original batch7 case order",
    )
    admissions = report["admissions"]
    require(
        len(admissions) == 2
        and [a["batch_id"] for a in admissions] == [7, 7]
        and [a["global_step"] for a in admissions] == [0, 1]
        and [a["stage"] for a in admissions] == ["seed", "peers"]
        and [[b["case_id"] for b in a["bindings"]] for a in admissions]
        == [order[:1], order[1:]]
        and admissions[1]["seed_output_tokens"] == 1
        and admissions[1]["seed_still_live"] is True,
        "Original seed-first+seven-peer admission changed",
    )
    ids = {b["case_id"]: b["internal"] for a in admissions for b in a["bindings"]}
    require(len(set(ids.values())) == 8, "Internal request mapping is ambiguous")
    prompts = {ids[c["case_id"]]: len(c["prompt_token_ids"]) for c in cases}
    require(
        len(receipts) >= 6 and len(receipts) % 2 == 0, "Missing paired serving receipts"
    )
    previous = set()
    decode_sizes = []
    decode_counts = dict.fromkeys(ids.values(), 0)
    for offset in range(0, len(receipts), 2):
        step = offset // 2 + 1
        scheduled, retired = receipts[offset : offset + 2]
        require(
            scheduled["event"] == "schedule"
            and retired["event"] == "retirement"
            and scheduled["batch_id"] == retired["batch_id"] == 7
            and scheduled["global_step"] == retired["global_step"] == step,
            "Missing/duplicate/reordered serving receipt",
        )
        p = (
            {ids[order[0]]}
            if step == 1
            else {ids[c] for c in order[1:]}
            if step == 2
            else set()
        )
        phases = scheduled["phases_before"]
        require(
            set(phases) <= set(ids.values()) and set(phases.values()) <= {"P", "D"},
            "Unknown phase/request",
        )
        d = {rid for rid, phase in phases.items() if phase == "D"}
        require(
            {rid for rid, phase in phases.items() if phase == "P"} == p
            and (
                not d
                if step == 1
                else d == {ids[SEED]}
                if step == 2
                else bool(d) and d <= previous
            ),
            "D population regrew or original P/D phase changed",
        )
        require(
            scheduled["scheduled_tokens"]
            == ({rid: prompts[rid] for rid in p} | dict.fromkeys(d, 1))
            and set(scheduled["new_prefill_ids"]) == p
            and len(scheduled["new_prefill_ids"]) == len(p)
            and set(scheduled["pending_prefill_ids"]) == p
            and len(scheduled["pending_prefill_ids"]) == len(p)
            and scheduled["prefill_layers_before"] == 0
            and not scheduled["preempted_req_ids"],
            "Unexpected P/recompute/preemption or D scheduling",
        )
        require(
            set(retired["completed_prefill_ids"]) == p
            and len(retired["completed_prefill_ids"]) == len(p)
            and not retired["cancelled_prefill_ids"]
            and retired["prefill_layers_completed"] == (40 if p else 0)
            and retired["actual_prefill_progress"] is bool(p)
            and retired["mixed_pd_progress_and_retirement"] is bool(p and d)
            and retired["native_mixed_scheduled_and_decode_retired"] is False
            and set(retired["decode_retired_ids"]) == d
            and len(retired["decode_retired_ids"]) == len(d),
            "Actual40-layer ACK or D retirement differs",
        )
        previous = p | d
        if d:
            decode_sizes.append(len(d))
            for rid in d:
                decode_counts[rid] += 1
    require(
        report["answer_engine_steps"] == len(receipts) // 2
        and {int(k): v for k, v in report["mixed_coverage"]["steps_per_batch"].items()}
        == {7: 1}
        and report["mixed_coverage"]["covered_batches"] == [7]
        and report["mixed_coverage"]["uncovered_batches"] == [],
        "Reported step/mixed coverage differs",
    )
    graphs = validate_graphs(report, len(decode_sizes))
    return {
        "passed": True,
        "serving_steps": len(receipts) // 2,
        "peer_prefill_advancements": 1,
        "completed_peer_ids": 7,
        "decode_turns": len(decode_sizes),
        "decode_batch_sizes": decode_sizes,
        "decode_retirements_per_case": {
            case: decode_counts[rid] for case, rid in ids.items()
        },
        "graph_receipts": graphs,
        "scope": "Actual scheduler and retirement counters; output lengths do not define graph replay counts.",
    }


def validate_graphs(report, decode_turns):
    before = {r["rank"]: r for r in report["worker_before"]}
    after = {r["rank"]: r for r in report["worker_after"]}
    require(
        len(report["worker_before"]) == len(report["worker_after"]) == 4
        and set(before) == set(after) == set(range(4)),
        "Graph snapshots lack TP4 ranks",
    )
    result = []
    for rank in range(4):
        a, b = (
            before[rank]["decode_graph_snapshot"],
            after[rank]["decode_graph_snapshot"],
        )
        for rows in (before, after):
            require(
                rows[rank]["runtime"]["policy"]
                == report["engine_args"]["batch_admission_policy_config"],
                "Resolved worker quota/policy differs",
            )
        fields = {
            "enabled": True,
            "attached": True,
            "capture_started": True,
            "captured": True,
            "failed": False,
            "closed": False,
            "compile_full_prefill": False,
            "prefill_compile_profiled": False,
            "includes_startup_warmups": True,
            "captured_graph_entries": 4,
        }
        require(
            all(a.get(k) == b.get(k) == v for k, v in fields.items()),
            "Decode graph capture/profile differs",
        )
        stable = (
            "capture_attempts",
            "capture_successes",
            "capture_failures",
            "decode_capture_forward_calls",
            "decode_eager_fallback_calls",
            "decode_uncaptured_full_calls",
            "decode_forward_failures",
            "prefill_compiled_calls",
            "prefill_compile_profile_runs",
            "prefill_compile_profile_failures",
        )
        require(
            all(a[k] == b[k] for k in stable)
            and a["capture_successes"] >= 1
            and a["capture_failures"]
            == a["decode_uncaptured_full_calls"]
            == a["decode_forward_failures"]
            == 0
            and a["prefill_compiled_calls"]
            == a["prefill_compile_profile_runs"]
            == a["prefill_compile_profile_failures"]
            == 0
            and b["prefill_forced_eager_calls"] - a["prefill_forced_eager_calls"] == 2
            and b["decode_replay_calls"] - a["decode_replay_calls"] == decode_turns,
            "Actual dynamic D replay/eager/failure/P-forward accounting differs",
        )
        result.append(
            {"rank": rank, "replay_delta": decode_turns, "before": a, "after": b}
        )
    return result


REFERENCES_SHA = "c446709a7b7e613a0e9734e899d797161279efbc1ef5663ac9f15c845cdaba03"


def verify_references(bundle):
    """CPU-only precursor gate. Terminal controllers precede child/log reads."""
    bundle = Path(bundle)
    path = bundle / "batch7-full-references-v1.json"
    require(
        identity(path)["sha256"] == REFERENCES_SHA,
        "Root-qualified reference bytes changed",
    )
    refs = json.loads(path.read_text())
    require(
        refs["schema"] == "muxpd-q40-batch7-full-references-v1"
        and refs["status"] == "qualified",
        "Precursor is not qualified",
    )
    short_controllers = {
        role: require_terminal(directory)
        for role, directory in refs["short_runs"].items()
    }
    require(set(short_controllers) == {"observed", "plain"}, "Missing short arm")
    terminals = {}
    for role, item in refs["historical_runs"].items():
        control_path = Path(item["directory"]) / "controller.json"
        require(
            identity(control_path)["sha256"] == item["files"]["controller.json"],
            "Historical controller changed",
        )
        controller = json.loads(control_path.read_text())
        require(
            controller.get("passed") is True
            and controller.get("exit_code") == 0
            and bool(controller.get("finished_at")),
            "Historical reference not terminal",
        )
        if role == "prefix":
            require(
                controller["schema"] == "muxpd-layout-quality-controller-v1"
                and controller["errors"] == []
                and controller["owned_members_after_cleanup"] == []
                and controller["idle_physical_after"] == controller["expected_physical"]
                and not controller.get("cleanup_required"),
                "Historical prefix lifecycle invalid",
            )
        else:
            require(
                role in ("native1", "native2", "raw")
                and "schema" not in controller
                and controller["label"]
                in (
                    "native-quality-v2-hccl-true-01",
                    "native-quality-v2-hccl-true-02",
                    "raw-quality-v2-hccl-true-01",
                ),
                "Unknown legacy historical terminal contract",
            )
        terminals[role] = {
            "controller_sha256": identity(control_path)["sha256"],
            "legacy_terminal_only": role != "prefix",
            "scope": "Existing qualified immutable historical format; no modern process/idle evidence invented.",
        }
    require(
        set(terminals) == {"native1", "native2", "raw", "prefix"},
        "Missing original historical arm",
    )
    for filename, digest in refs["files"].items():
        require(
            identity(filename)["sha256"] == digest,
            f"Historical reference changed: {filename}",
        )
    for item in refs["historical_runs"].values():
        for filename, digest in item["files"].items():
            require(
                identity(Path(item["directory"]) / filename)["sha256"] == digest,
                "Historical arm artifact changed",
            )
    primary = json.loads(Path(refs["short_primary"]["path"]).read_text())
    audit = json.loads(Path(refs["short_independent"]["path"]).read_text())
    for key in ("short_primary", "short_independent"):
        require(
            identity(refs[key]["path"])["sha256"] == refs[key]["sha256"],
            "Precursor analysis changed",
        )
    require(
        primary["schema"] == "muxpd-q40-analysis-v1"
        and primary["analysis_arm"] == "pair"
        and primary["passed"] is True
        and primary["localization_allowed"] is True
        and not primary["errors"]
        and primary["observed_plain_transparency"]["passed"] is True
        and audit["passed"] is True
        and audit["observed_plain_complete_prefixes_equal"] is True,
        "Short q40 primary/independent qualification failed",
    )
    positions = primary["target_vs_native"]["positions"]
    require(
        [r["position_one_based"] for r in positions] == list(range(1, 209))
        and all(
            r["canonical_value_bytes_equal"] and r["sampled_token_equal"]
            for r in positions
        )
        and all(
            audit["comparisons"]["native"]["summary"][key] is None
            for key in (
                "first_same_input_numeric_difference",
                "first_same_input_byte_difference",
                "first_observed_byte_difference_any_history",
                "first_sampled_token_difference",
            )
        ),
        "Qualified all208 target native equality missing",
    )
    for role, directory in refs["short_runs"].items():
        child = Path(directory) / "results/run.json"
        require(
            identity(child)["sha256"]
            == audit["current_children"][role]
            == next(
                r["child_sha256"]
                for r in primary["attempts"]
                if r["directory"] == directory
            ),
            "Short terminal child identity differs",
        )
    assessments = [
        json.loads(Path(v["path"]).read_text()) for v in refs["historical_assessments"]
    ]
    require(
        assessments[0]["full_quality_gate_attempted"] is True
        and assessments[0]["full_frozen_plan_passed"] is False
        and assessments[1]["audit_passed"] is True
        and assessments[1]["collection_lifecycle_passed"] is True
        and assessments[1]["full_frozen_plan_passed"] is False,
        "Historical strict quality failure was lost",
    )
    import full_answer_treatment_v1 as treatment

    model = refs["model_config_identity"]
    require(
        model == treatment.load_treatment()["model_config_identity"]
        and identity(model["path"])["sha256"] == model["sha256"],
        "Model configuration changed",
    )
    return refs, {
        "passed": True,
        "references_sha256": REFERENCES_SHA,
        "short_primary": refs["short_primary"],
        "short_independent": refs["short_independent"],
        "short_target_all208_bytes_equal_native": True,
        "historical_full200_strict_gate_passed": False,
        "historical_terminal_contracts": terminals,
        "model_config_identity": model,
        "scope": "Eligibility for one posterior batch7 full-answer diagnostic only; no runtime candidate/full200 acceptance.",
    }


def validate_outputs(report, plan, cases):
    from tokenizers import Tokenizer

    expected = {c["case_id"] for c in cases}
    outputs = report["outputs"]
    require(
        len(outputs) == 8 and {r["case_id"] for r in outputs} == expected,
        "Require exactly eight unique original outputs",
    )
    tokenizer_path = plan["tokenizer_files"]["tokenizer.json"]
    require(
        identity(tokenizer_path["path"])["sha256"] == tokenizer_path["sha256"],
        "Tokenizer changed",
    )
    decoder = Tokenizer.from_file(tokenizer_path["path"])
    vocabulary_size = decoder.get_vocab_size()
    for row in outputs:
        ids = row["token_ids"]
        require(
            row["finished"] is True
            and not row.get("error")
            and row["finish_reason"] in ("stop", "length")
            and 0 < len(ids) <= 8192
            and all(type(v) is int and 0 <= v < vocabulary_size for v in ids)
            and (row["finish_reason"] != "length" or len(ids) == 8192),
            "Incomplete/invalid natural output or length limit changed",
        )
        require(
            row["text"] == decoder.decode(ids, skip_special_tokens=True),
            "Stored answer text does not decode from actual token IDs",
        )
    return {
        "decoded_output_count": 8,
        "length_cases": [
            r["case_id"] for r in outputs if r["finish_reason"] == "length"
        ],
        "scope": "Natural length8192 counts as collected, but unchanged original scorer counts it incomplete/wrong.",
    }


def validate_source_config(report, controller, histories, refs, plan, bundle):
    import full_answer_treatment_v1 as treatment
    from probe_run_v1 import QUALITY_SOURCE, SOURCE, tokenizer_identities

    raw = histories["raw"]
    base = json.loads((bundle / "raw-engine-args-v1.json").read_text())
    treatment.validate_launch_config(base, report["base_engine_args"])
    treatment.validate_resolved_config(report["engine_args"], raw["engine_args"])
    receipt = treatment.treatment_receipt(base, report["base_engine_args"])
    require(
        controller["launch_engine_args"] == report["base_engine_args"]
        and controller["scheduling_treatment"]
        == report["scheduling_treatment"]
        == receipt,
        "Pre-LLM quota-only launch receipt changed",
    )
    require(
        report["runtime_environment"] == raw["runtime_environment"]
        and report["effective"] == histories["prefix"]["effective"]
        and report["scheduler_class"] == histories["prefix"]["scheduler_class"]
        and report["engine_coordinator"] == histories["prefix"]["engine_coordinator"],
        "Actual runtime/coordinator/effective configuration changed",
    )
    require(
        report["model_config_identity"] == refs["model_config_identity"]
        and report["tokenizer_files"] == tokenizer_identities(plan),
        "Model/tokenizer identity changed",
    )
    for module in ("vllm", "vllm_ascend"):
        require(
            report["sources"][module] == raw["sources"][module],
            "Original core/Ascend identity changed",
        )
    plugin = report["sources"]["vllm_muxpd"]
    require(
        plugin["commit"] == SOURCE
        and not plugin["status"]
        and not plugin["changed_files"]
        and plugin["sha256"] == raw["sources"]["vllm_muxpd"]["sha256"],
        "Clean actual plugin identity changed",
    )
    bridge = report["source_equivalence"]
    require(
        bridge["observer_source"] == SOURCE
        and bridge["quality_runtime_source"] == QUALITY_SOURCE
        and not bridge["existing_runtime_diff"]
        and len(bridge["existing_runtime_files"]) == 20,
        "Original20 runtime-file bridge missing",
    )
    # Compare the actual file manifest, not just its cardinality or commit label.
    require(
        bridge == histories["prefix"]["source_equivalence"],
        "Original runtime equivalence receipt differs",
    )
    for guard in (
        report["source_after_startup"],
        report["sources_after_shutdown"],
        controller["source_preflight"],
    ):
        require(
            guard == {"sources": report["sources"], "equivalence": bridge},
            "Source changed during attempt",
        )
    return {
        "quota_only": receipt,
        "model_config_identity": report["model_config_identity"],
        "original20_runtime_files_equal": True,
        "core_ascend_equal": True,
        "runtime_environment_equal": True,
        "runtime_candidate": False,
    }


def validate_layout(report, path, plan, full_cases):
    import prefill_collective_layout_v1 as layout
    from quality_run_v1 import LAYOUT_SHA, validate_layout_admissions

    layout.validate_receipts(
        report["layout_installation"],
        LAYOUT_SHA,
        mode="prefix",
        expected_treated_cohorts=0,
        expected_completed=0,
    )
    proof = validate_layout_admissions(
        report["layout_final"],
        report["admissions"],
        path,
        [plan["batches"][7]],
        full_cases,
    )
    require(
        proof == report["layout_admission_validation"],
        "Layout admission summary differs",
    )
    for row in report["layout_final"]:
        seed, peers = row["cohorts"]
        require(
            seed["calls"] == []
            and seed["zero_d_bypass_calls"] == 81
            and len(peers["calls"]) == 81
            and peers["zero_d_bypass_calls"] == 0,
            "Require actual81 seed bypass and81 peer P calls on each TP rank",
        )
    layout.validate_uninstall_receipts(
        report["layout_uninstall"], LAYOUT_SHA, mode="prefix"
    )
    return proof


def audit_attempt(directory, bundle, refs, qualification):
    """Read a single frozen producer only after root proves clean termination."""
    directory, bundle = Path(directory), Path(bundle)
    controller = require_terminal(directory)
    require(
        directory.name == "prefix-q40-full-answer-batch7-v2-01"
        and controller["schema"] == "muxpd-q40-full-answer-controller-v1"
        and controller["label"] == directory.name
        and controller["scope"] == "batch7-full-answer"
        and controller["expected_physical"] == ["3", "4", "5", "6"]
        and controller["selected_batch_ids"] == [7]
        and controller["selected_case_count"] == 8
        and controller["predecessor_qualification"] == qualification,
        "One declared terminal full-answer attempt required",
    )
    from probe_control_v1 import audit_terminal_log, inventory
    from probe_run_v1 import require_empty, require_empty_worker, validate_workers
    from quality_control_v1 import FILES
    from quality_run_v1 import LAYOUT_SHA, PLAN_SHA
    from score_layout_quality_v1 import historical_runs

    actual = {name: identity(directory / "producer" / name)["sha256"] for name in FILES}
    require(
        actual
        == controller["files"]
        == {name: identity(bundle / name)["sha256"] for name in FILES},
        "Frozen producer map differs",
    )
    frozen = directory / "producer/freeze-manifest-v1.json"
    freeze = json.loads(frozen.read_text())
    require(
        identity(frozen)["sha256"]
        == controller["freeze_manifest_sha256"]
        == identity(bundle / "freeze-manifest-v1.json")["sha256"]
        and freeze["status"] == "frozen"
        and freeze["files"] == actual
        and freeze["expected_physical"] == controller["expected_physical"],
        "Frozen producer identity invalid",
    )
    path = directory / "results/run.json"
    require(
        identity(path)["sha256"] == controller["terminal_run_sha256"],
        "Terminal child bytes changed",
    )
    report = json.loads(path.read_text())
    log = audit_terminal_log(directory / "process.log")
    require(
        log["passed"] and log == controller["terminal_process_log_audit"],
        "Terminal traceback/graph error",
    )
    for when in ("before", "after"):
        require(
            inventory((directory / f"npu-{when}.txt").read_text())
            == controller["expected_physical"],
            "Saved physical idle inventory differs",
        )
    require(
        report["schema"] == "muxpd-q40-full-answer-run-v1"
        and report["profile"] == "raw-prefix"
        and report["role"] == "raw"
        and report["scope"] == "batch7-full-answer"
        and report["layout_mode"] == "prefix"
        and report["plan_sha256"] == PLAN_SHA
        and report["passed"] is True
        and report["collection_complete"] is True
        and report["layout_restored"] is True
        and report["shutdown_returned"] is True
        and report["errors"] == []
        and report.get("finished_at")
        and not report.get("failure_cleanup")
        and not report["terminal_maintenance"]["aborted_internal_ids"]
        and report["runtime_candidate"] is False
        and report["full_quality_gate_attempted"] is False
        and report["full_frozen_plan_passed"] is None,
        "Full-answer child collection/lifecycle/scope failed",
    )
    for field, name in {
        "producer_sha256": "quality_run_v1.py",
        "original_producer_sha256": "run_quality.py",
        "original_scorer_sha256": "score_quality.py",
        "source_manifest_sha256": "source-manifest-v1.json",
        "layout_module_sha256": "prefill_collective_layout_v1.py",
    }.items():
        require(
            report[field] == actual[name], "Actual child producer/dependency differs"
        )
    require(
        report["layout_module_sha256"] == LAYOUT_SHA, "External prefix bytes changed"
    )
    original = scorer()
    plan, full_cases, _ = original.load_frozen(bundle / "frozen-v2")
    order = plan["batches"][7]["case_ids"]
    cases = [next(c for c in full_cases if c["case_id"] == case) for case in order]
    require(
        report["selected_batch_ids"] == [7] and report["selected_case_ids"] == order,
        "Original selected batch changed",
    )
    manifest = json.loads((bundle / "source-manifest-v1.json").read_text())
    historical_runs(manifest)  # Unchanged original three-arm provenance validator.
    histories = {
        role: json.loads((Path(item["directory"]) / "results/run.json").read_text())
        for role, item in refs["historical_runs"].items()
    }
    source = validate_source_config(report, controller, histories, refs, plan, bundle)
    for when in ("worker_before", "worker_after"):
        validate_workers(report[when], "raw-layout-plain")
        for row in report[when]:
            require_empty_worker(row)
    require_empty(report["final_state"], report["idle_baseline"])
    receipt = directory / "results/scheduler-receipts.jsonl"
    require(
        identity(receipt)["sha256"] == report["scheduler_receipts_sha256"],
        "Actual scheduler history changed",
    )
    lines = [json.loads(line) for line in receipt.read_text().splitlines()]
    layout_proof = validate_layout(report, receipt, plan, full_cases)
    schedule = validate_schedule(report, lines, cases)
    mixed = original.verify_mixed_coverage(
        path, report, {**plan, "batches": [plan["batches"][7]]}
    )
    require(mixed["passed"], "Original actual mixed coverage failed")
    outputs = validate_outputs(report, plan, cases)
    short = json.loads(
        (Path(refs["short_runs"]["plain"]) / "results/run.json").read_text()
    )
    proof = {
        "collection_valid": True,
        "controller": identity(directory / "controller.json"),
        "child": identity(path),
        "terminal_log": log,
        "freeze_manifest": identity(frozen),
        "source_config": source,
        "layout": layout_proof,
        "schedule": schedule,
        "mixed_coverage": mixed,
        "outputs": outputs,
    }
    return proof, report, plan, cases, histories, short
