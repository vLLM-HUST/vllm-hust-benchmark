"""Root-owned full-answer controller. dry-run never queries or opens an NPU."""

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import time
import traceback
from pathlib import Path

import full_answer_treatment_v1 as treatment
from probe_control_v1 import audit_terminal_log, environment, inventory, members
from quality_run_v1 import BUNDLE, SCOPES, file_sha, now, prepare, save

FILES = (
    "analyze_batch7_full_v1.py",
    "batch-context-v1.json",
    "batch7-full-references-v1.json",
    "batch7_full_analysis_v1.py",
    "frozen-v2/canonical-adapter.py",
    "frozen-v2/cases.jsonl",
    "frozen-v2/gold-source-rows.jsonl",
    "frozen-v2/initial_prompt.txt",
    "frozen-v2/materialized.200.cases.json",
    "frozen-v2/materialized.200.jsonl",
    "frozen-v2/plan.json",
    "full-answer-treatment-v1.json",
    "full_answer_treatment_v1.py",
    "prefill_collective_layout_v1.py",
    "probe_control_v1.py",
    "probe_run_v1.py",
    "quality_control_v1.py",
    "quality_run_v1.py",
    "raw-engine-args-v1.json",
    "run-matrix-v1.json",
    "run_quality.py",
    "score_layout_quality_v1.py",
    "score_quality.py",
    "source-manifest-v1.json",
)


def validate_launch_environment(env, manifest):
    """Reject missing setup before any child/model launch; never mutate env."""
    expected = manifest["historical_runs"]["raw-quality-v2-hccl-true-01"][
        "runtime_environment"
    ]["environment"]
    actual = {key: env.get(key) for key in expected}
    mismatched = sorted(key for key in expected if actual[key] != expected[key])
    if mismatched:
        raise ValueError(
            "Launch environment differs from historical runtime; source "
            "/root/workspace/runtime/env.sh before preflight/launch. "
            "Mismatched fields: " + ", ".join(mismatched)
        )
    return {
        "passed": True,
        "environment": actual,
        "scope": "Exact original tracked runtime environment; validated without mutation.",
    }


def preview(args):
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]+", args.label):
        raise ValueError("Require safe fresh label")
    if args.label != "prefix-q40-full-answer-batch7-v2-01":
        raise ValueError("Require the one declared full-answer attempt label")
    expected = sorted(args.expected_physical.split(","), key=int)
    if len(expected) != 4 or len(set(expected)) != 4:
        raise ValueError("Require four distinct root-selected physical devices")
    if expected != ["3", "4", "5", "6"]:
        raise ValueError("Require declared physical allocation3,4,5,6")
    destination = args.output_root / args.label
    if destination.exists():
        raise FileExistsError(destination)
    plan, _, batches, config, manifest, identity = prepare(
        args.scope, args.source, args.bundle
    )
    from batch7_full_analysis_v1 import verify_references

    _, predecessor = verify_references(args.bundle)
    hashes = {name: file_sha(args.bundle / name) for name in FILES}
    freeze = args.bundle / "freeze-manifest-v1.json"
    frozen = freeze.exists()
    if frozen and (
        json.loads(freeze.read_text()).get("status") != "frozen"
        or json.loads(freeze.read_text())["files"] != hashes
        or json.loads(freeze.read_text()).get("expected_physical") != expected
    ):
        raise ValueError("Reviewed frozen bundle bytes changed")
    if args.command == "run" and not frozen:
        raise ValueError(
            "Root/reviewer must freeze this concrete bundle before device execution"
        )
    deadline = manifest["controller_deadline_seconds"]
    if deadline != 12600 or deadline < plan["maximum_wall_seconds"] + 1800:
        raise ValueError(
            "Controller cannot truncate the original full-answer work bound"
        )
    env = environment(args.source, destination)
    environment_guard = validate_launch_environment(env, manifest)
    return {
        "schema": "muxpd-q40-full-answer-controller-v1",
        "label": args.label,
        "scope": args.scope,
        "profile": "raw-prefix",
        "predecessor_qualification": predecessor,
        "scheduling_treatment": treatment.treatment_receipt(
            json.loads((args.bundle / "raw-engine-args-v1.json").read_text()), config
        ),
        "destination": str(destination),
        "source": str(args.source),
        "source_preflight": identity,
        "runtime_environment_guard": environment_guard,
        "selected_batch_ids": [b["batch_id"] for b in batches],
        "selected_case_count": sum(len(b["case_ids"]) for b in batches),
        "command": [
            str(args.python),
            str(destination / "producer/quality_run_v1.py"),
            "run",
            "--scope",
            args.scope,
            "--source",
            str(args.source),
            "--output",
            str(destination / "results"),
        ],
        "launch_engine_args": config,
        "files": hashes,
        "bundle_frozen": frozen,
        "freeze_manifest_sha256": file_sha(freeze) if frozen else None,
        "timeout_seconds": deadline,
        "deadline_reason": manifest["deadline_reason"],
        "expected_physical": expected,
        "environment": {
            k: env.get(k)
            for k in (
                "ASCEND_RT_VISIBLE_DEVICES",
                "HCCL_DETERMINISTIC",
                "VLLM_BATCH_INVARIANT",
                "VLLM_USE_V2_MODEL_RUNNER",
                "VLLM_ENABLE_V1_MULTIPROCESSING",
                "PYTHONPATH",
                "PYTHONDONTWRITEBYTECODE",
                "OMP_NUM_THREADS",
                "VLLM_CACHE_ROOT",
            )
        },
        "qualification_claim": "Posterior full-answer batch7 collection only; no runtime candidate or full200 acceptance.",
    }


def execute(args, record):
    root = Path(record["destination"])
    root.mkdir(parents=True, exist_ok=False)
    for name, digest in record["files"].items():
        target = root / "producer" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(args.bundle / name, target)
        if file_sha(target) != digest:
            raise RuntimeError("Producer changed during immutable run copy")
    shutil.copyfile(
        args.bundle / "freeze-manifest-v1.json",
        root / "producer/freeze-manifest-v1.json",
    )
    record.update(started_at=now(), controller_pid=os.getpid(), errors=[], passed=False)
    process = None
    save(root / "controller.json", record)
    try:
        before = subprocess.check_output(["npu-smi", "info"], timeout=30)
        (root / "npu-before.txt").write_bytes(before)
        record["idle_physical_before"] = inventory(before.decode())
        if record["idle_physical_before"] != record["expected_physical"]:
            raise RuntimeError(
                "Idle device allocation differs from root-selected inventory"
            )
        with (root / "process.log").open("x") as log:
            process = subprocess.Popen(
                record["command"],
                cwd=args.source,
                env=environment(args.source, root),
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            record["pid"] = record["process_group"] = process.pid
            record["owned_members_after_spawn"] = members(process.pid)
            save(root / "controller.json", record)
            start, notice = time.monotonic(), 0
            while process.poll() is None:
                elapsed = time.monotonic() - start
                if elapsed > record["timeout_seconds"]:
                    record["timeout"] = True
                    raise TimeoutError(
                        "Full-answer collection exceeded finite total deadline"
                    )
                if elapsed >= notice:
                    print(
                        f"{args.label}: pid={process.pid} running {elapsed:.0f}s",
                        flush=True,
                    )
                    notice = elapsed + 30
                time.sleep(1)
    except BaseException:  # noqa: BLE001 -- only owned process group is cleaned
        record["errors"].append(traceback.format_exc())
    finally:
        if process is not None:
            record["owned_members_before_cleanup"] = members(process.pid)
            if record["owned_members_before_cleanup"]:
                record["cleanup_required"] = True
                try:
                    os.killpg(process.pid, signal.SIGINT)
                    deadline = time.monotonic() + 45
                    while members(process.pid) and time.monotonic() < deadline:
                        time.sleep(1)
                    if members(process.pid):
                        record["forced_termination"] = True
                        os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                record["errors"].append("Owned producer did not exit after cleanup")
            record["exit_code"] = process.returncode
            record["owned_members_after_cleanup"] = members(process.pid)
        try:
            after = subprocess.check_output(["npu-smi", "info"], timeout=30)
            (root / "npu-after.txt").write_bytes(after)
            record["idle_physical_after"] = inventory(after.decode())
            if record["idle_physical_after"] != record.get("idle_physical_before"):
                raise RuntimeError("Physical allocation differs across run")
        except Exception:  # noqa: BLE001 -- retain idle guard failure
            record["errors"].append(traceback.format_exc())
        terminal = bool(
            process is not None
            and process.returncode is not None
            and not members(process.pid)
        )
        record["terminal_process_proven"] = terminal
        try:
            if not terminal:
                raise RuntimeError("Nonterminal; child/log deliberately not read")
            child = json.loads((root / "results/run.json").read_text())
            record["terminal_run_sha256"] = file_sha(root / "results/run.json")
        except (FileNotFoundError, ValueError, RuntimeError):
            child = {}
            record["errors"].append(traceback.format_exc())
        try:
            if not terminal:
                raise RuntimeError("Nonterminal; child/log deliberately not read")
            record["terminal_process_log_audit"] = audit_terminal_log(
                root / "process.log"
            )
            if not record["terminal_process_log_audit"]["passed"]:
                raise RuntimeError("Terminal worker traceback or ownership error")
        except Exception:  # noqa: BLE001 -- absent log is also failure
            record["errors"].append(traceback.format_exc())
        record["passed"] = bool(
            terminal
            and record.get("exit_code") == 0
            and not record["errors"]
            and not record.get("cleanup_required")
            and not record.get("owned_members_after_cleanup", ["unknown"])
            and child.get("passed")
            and child.get("collection_complete")
            and child.get("layout_restored")
            and child.get("shutdown_returned")
            and child.get("scope") == args.scope
        )
        record["finished_at"] = now()
        save(root / "controller.json", record)
    print(
        json.dumps(
            {
                "label": args.label,
                "passed": record["passed"],
                "scope": args.scope,
                "output": str(root),
            }
        ),
        flush=True,
    )
    return 0 if record["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("dry-run", "run"))
    parser.add_argument("--scope", choices=SCOPES, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--expected-physical", default="3,4,5,6")
    parser.add_argument("--bundle", type=Path, default=BUNDLE)
    parser.add_argument("--output-root", type=Path, default=BUNDLE / "runs-v1")
    parser.add_argument(
        "--python",
        type=Path,
        default=Path("/root/workspace/.muxpd-ecpa-runtime/bin/python"),
    )
    args = parser.parse_args()
    for key in ("source", "bundle", "output_root"):
        setattr(args, key, getattr(args, key).resolve())
    args.python = args.python.absolute()
    record = preview(args)
    if args.command == "dry-run":
        print(json.dumps(record, indent=2))
        return 0
    return execute(args, record)


if __name__ == "__main__":
    raise SystemExit(main())
