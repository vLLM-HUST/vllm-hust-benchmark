"""Stage exact terminal evidence locally; no GitHub, navigation or git mutation."""
import gzip
import hashlib
import io
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

OLD=Path('/root/workspace/muxpd-q40-full-answer-batch7-20261030')
BUNDLE=Path('/root/workspace/muxpd-q40-full-answer-batch7-v2-20261030')
DEST=Path('/root/workspace/references/benchmark-muxpd-prefill-state/reports/muxpd-q40-full-answer-20261030')
RUN=BUNDLE/'runs-v1/prefix-q40-full-answer-batch7-v2-01'
FAILED=OLD/'runs-v1/prefix-q40-full-answer-batch7-v1-01'


def digest(raw):return hashlib.sha256(raw).hexdigest()


def load(path):return json.loads(path.read_text())


def main():
    # Controllers are inspected before any result/log evidence, including v1.
    for root,passed,exit_code in ((FAILED,False,1),(RUN,True,0)):
        control=load(root/'controller.json')
        assert control['terminal_process_proven'] is True and control['passed'] is passed
        assert control['exit_code']==exit_code and control['finished_at']
        assert control['owned_members_after_cleanup']==[]
        assert control['idle_physical_after']==['3','4','5','6']
        assert not control.get('cleanup_required') and not control.get('forced_termination')
    primary_path=BUNDLE/'analysis-final-v1.json'
    independent_path=BUNDLE/'independent-review-v1/terminal-check-v1.json'
    assert digest(primary_path.read_bytes())=='029831e8b47748516fecf70de37941bd4a52d87db471b836e09e177b386b9804'
    assert digest(independent_path.read_bytes())=='7ec93a9ed3a8a24e263308c0d108fd15b79fa6990e93a411f1a125cb1b1f661e'
    analysis,audit=load(primary_path),load(independent_path)
    assert analysis['passed'] and audit['passed'] and analysis['trajectory_qualified']
    assert analysis['local_answer_outcome']['correct_count']==8
    assert analysis['local_answer_outcome']['all_complete']
    assert analysis['local_answer_outcome']['new_wrong_on_both_native_correct']==[]
    assert analysis['full_quality_gate_attempted'] is False and analysis['full_frozen_plan_passed'] is None
    assert analysis['runtime_candidate'] is False
    actual=load(RUN/'results/run.json');failure=load(FAILED/'results/run.json')
    assert digest((RUN/'results/run.json').read_bytes())==audit['child_sha256']=='67afca2a3189071289437be95bd8a8d6184a0f5a5dad189a963b3b8e2be4365d'
    assert len(actual['outputs'])==8 and len(actual['admissions'])==2
    assert len(failure['outputs'])==len(failure['admissions'])==0 and 'worker_before' not in failure
    schedule=analysis['collection_proof']['schedule']
    assert (schedule['serving_steps'],schedule['decode_turns'])==(3293,3292)
    rows=analysis['answer_diagnostic']['rows']
    assert len(rows)==8 and all(r['arms']['q40']['correct'] and r['arms']['q40']['finish_reason']=='stop' for r in rows)
    target=next(r for r in rows if r['case_id']=='mmlu-pro-07338')
    assert target['arms']['q40']['answer']=='H' and target['arms']['q40']['output_tokens']==3292
    assert target['arms']['prefix']['finish_reason']=='length' and target['arms']['prefix']['output_tokens']==8192
    assert not DEST.exists(),'Refuse to overwrite existing publication directory'
    DEST.mkdir()
    sources={
        'analysis-final-v1.json.gz':primary_path,
        'independent-terminal-v1.json':independent_path,
        'independent-preflight-v1.json':BUNDLE/'independent-review-v1/review-v1.json',
        'freeze-manifest-v2.json':BUNDLE/'freeze-manifest-v1.json',
        'cpu-validation-v2.json':BUNDLE/'cpu-validation-v1.json',
        'controller-v2.json':RUN/'controller.json',
        'run-v2.json.gz':RUN/'results/run.json',
        'scheduler-receipts-v2.jsonl.gz':RUN/'results/scheduler-receipts.jsonl',
        'process-v2.log.gz':RUN/'process.log',
        'npu-before-v2.txt':RUN/'npu-before.txt',
        'npu-after-v2.txt':RUN/'npu-after.txt',
        'failure-lineage-v1.json':OLD/'failure-lineage-v1.json',
        'failed-controller-v1.json':FAILED/'controller.json',
        'failed-run-v1.json.gz':FAILED/'results/run.json',
        'failed-process-v1.log.gz':FAILED/'process.log',
        'cpu-postprocess-interruption-v1.json':BUNDLE/'independent-review-v1/cpu-postprocess-interruption-v1.json',
    }
    entries={}
    for name,path in sources.items():
        raw=path.read_bytes();encoded=gzip.compress(raw,mtime=0) if name.endswith('.gz') else raw
        (DEST/name).write_bytes(encoded)
        entries[name]={'source_path':str(path),'source_sha256':digest(raw),'source_bytes':len(raw),
                       'encoding':'gzip' if name.endswith('.gz') else 'identity','stored_sha256':digest(encoded),'stored_bytes':len(encoded)}
        restored=gzip.decompress((DEST/name).read_bytes()) if name.endswith('.gz') else (DEST/name).read_bytes()
        assert restored==raw
    members={};origins={}
    def member(name,path):
        assert name not in members
        members[name]=path.read_bytes();origins[name]=str(path)
    for version,base in (('v1',OLD),('v2',BUNDLE)):
        freeze=load(base/'freeze-manifest-v1.json')
        assert len(freeze['files'])==24
        for name,expected in freeze['files'].items():
            assert digest((base/name).read_bytes())==expected
            member(f'{version}/producer/{name}',base/name)
        member(f'{version}/evidence/freeze-manifest-v1.json',base/'freeze-manifest-v1.json')
    old_evidence=['cpu-validation-v1.json','harness-source-proof-v1.json','failure-lineage-v1.json','root-decision-v1.json',
                  'independent-review-v1/review-v1.json','docs/superpowers/plans/2026-10-30-q40-full-answer-batch7.md']
    current_evidence=['cpu-validation-v1.json','producer-map-v1.json','harness-source-proof-v1.json','analyzer-label-proof-v1.json',
                      'analyzer-label-adaptation-v1.diff','quality-control-environment-v2.diff','root-decision-v2.json',
                      'root-preflight-v1/run_preflight.py','root-preflight-v1/preflight.json','root-preflight-v1/batch7-full-answer-dry-run.json',
                      'independent-review-v1/review-v1.json','independent-review-v1/check_terminal_v1.py',
                      'independent-review-v1/check_terminal_v2.py','independent-review-v1/check_terminal_v3.py',
                      'independent-review-v1/cpu-postprocess-interruption-v1.json','independent-review-v1/terminal-check-v1.json',
                      'cpu-environment-controller-final-v2.log','cpu-analyzer-label-green-v1.log','stage_full_answer_report_v1.py']
    for name in old_evidence:member('v1/evidence/'+name,OLD/name)
    for name in current_evidence:member('v2/evidence/'+name,BUNDLE/name)
    capsule_manifest={'schema':'muxpd-q40-full-answer-source-capsule-v1',
        'scope':'Both immutable24-file producer versions and their failure/recovery/CPU/source/independent audit evidence. Full run/schedule/log copies are published separately. Historical original reports and prior short-logit NPY files are not in this capsule; execution requires original server dependencies.',
        'members':{name:{'source_path':origins[name],'sha256':digest(raw),'bytes':len(raw)} for name,raw in members.items()}}
    members['MANIFEST.json']=(json.dumps(capsule_manifest,indent=2)+'\n').encode()
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as archive:
        for name,raw in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o444;info.mtime=0
            archive.addfile(info,io.BytesIO(raw))
    packed=gzip.compress(buffer.getvalue(),mtime=0)
    (DEST/'source-capsule-v1.tar.gz').write_bytes(packed)
    with tarfile.open(DEST/'source-capsule-v1.tar.gz') as archive:
        assert set(archive.getnames())==set(members)
        for name,raw in members.items():assert archive.extractfile(name).read()==raw
    entries['source-capsule-v1.tar.gz']={'stored_sha256':digest(packed),'stored_bytes':len(packed),'members':len(members),
                                      'member_manifest_sha256':digest(members['MANIFEST.json']),'local_all_members_checked':True,
                                      'scope':capsule_manifest['scope']}
    def cell(value):
        answer=value['answer'] if value['answer'] is not None else '—'
        return f"{answer} / {value['finish_reason']} / {value['output_tokens']}"
    table='\n'.join('| '+ ' | '.join([r['case_id'].replace('mmlu-pro-',''),r['gold']]+[cell(r['arms'][arm]) for arm in ('native1','native2','raw','prefix','q40')])+' |' for r in rows)
    report=f'''# MuxPD q40 原 batch7 完整答案：八题自然结束且全部正确

在先前 q40 短窗口诊断之后，本轮让原 batch7 的八条请求运行到自然结束或原8192上限。**八题均以 `stop` 自然结束，原 canonical scorer 判定8/8正确；07338 回答 H，输出3292 tokens。** 历史 full200 外部 prefix q4 中同题曾达到8192 `length`，按原规则为不完整且答错。

这是一轮新进程的后验八题诊断。历史 native/raw/prefix 的对应八题来自完整200题运行，前面已有七批请求历史；本轮未重放这些历史，也没有新增匹配的新进程 q4 完整答案对照。**局部退化已在这次 q40 诊断中消失，不能据此宣布完整200题、部署运行时、吞吐或 Goodput 验收通过。** [PR #27](https://github.com/vLLM-HUST/vllm-ascend-MuxPD-hust/pull/27) 保持 Draft。

## 八题逐项结果

每格为“提取答案 / 实际 finish_reason / 输出 token 数”。`—` 表示原评分器不提取答案；`length` 即使文本包含金答案仍按不完整和错误计分。原件中的 `stop_reason` 均为 `null`，未据此推断具体 EOS 原因。

| case | gold | native1 历史 | native2 历史 | raw 历史 | prefix q4 历史 | 本轮 prefix q40 |
|---|---|---|---|---|---|---|
{table}

两个 native、raw 对应八题均为8/8；历史 prefix 为7/8；本轮 q40 为8/8。在这八题中，两次 native 均正确的题没有新增错误，历史 prefix 的07338退化得到恢复。seed07151输出486 tokens，仍不能把其与 native 不同的生成路径当作答错。

## 输入、调度和来源约束

使用 Qwen3.5-35B-A3B BF16、TP4/EP4、物理卡3/4/5/6，沿用冻结200题计划字节，仅选择原 batch7，顺序为07151、07213、07275、07338、07401、07461、07524、07585。仍先让 seed 输出一个 token，再加入原七条 peer；温度0、seed42、`max_tokens=8192`、自然 EOS/stop 策略和原评分器不变，无目标208截断、无成功路径的活请求取消。

配置保留外部 prefix 布局、独立 P/D communicator、重叠执行、`FULL_DECODE_ONLY [1,2,4,8]`，并由 treatment sidecar 将原配置唯一覆盖为 `layers_per_slice: 4→40`。没有数值采集器，也没有新模型算子或运行时代码候选。原运行时源码、模型config和tokenizer、构造前后配置及终态源码收据均经主/独立校验。

实际记录3293次 serving step，包含 seed P 和一次完整40层 peer P推进、七条完成ACK；每rank seed记录81次D0 bypass，peer记录81次P collective。各rank D图 replay增量为3292，按真实非空D调度推导，保留启动warmup计数并核对运行期间无新增eager fallback/图失败。随着请求自然结束，D批次缩小；没有把固定短窗口208或最长输出数当作唯一调度依据。正常最终空maintenance不计入serving收据。

所有完整答案均延续已资格通过的短 q40 plain 前缀：seed前209、其余七条前208完全相同。因此本轮连接了先前短轨迹和自然完整答案；没有重新采集或公开短窗口完整logits张量。

## 失败与修正记录

1. **v1启动环境失败保留。** root首次调用时遗漏 `source /root/workspace/runtime/env.sh`，原运行环境一致性门在导入vLLM/构造模型前拒绝。退出码1，outputs=0、admissions=0，自有进程为空，四卡空闲；这不是错误答案或被替换的模型样本。冻结v1源码、控制器、子报告、日志及[失败谱系](failure-lineage-v1.json)全部保留。
2. **v2为重新声明的启动修复。** root显式加载原环境，并在控制器CPU预检中比较既有子进程环境，不自动修补环境。24个producer中21个字节不变；变化仅控制器环境检查、实验标签和矩阵路径。原模型driver、自然收集循环、采样和评分器不变；先前37项CPU验证保留，新版只重跑受影响14项环境/控制器和4项标签/引用检查。
3. **独立CPU后处理修订保留。** 独立脚本v2逐token重复查询不变的 `get_vocab_size()`，root中断该CPU进程（exit130/KeyboardInterrupt）；当时没有输出结果。v3将同一词表大小缓存一次，数据、门限、评分器均不变，然后完成独立复核。旧脚本、修订脚本和[中断说明](cpu-postprocess-interruption-v1.json)均入包；这不是模型重跑或选择性挑选答案。

## 终态与独立复核

| 记录 | 结果或SHA256 |
|---|---|
| v1 UTC终态 | 2026-10-30 13:09:44.535319，exit1，模型未构造 |
| v2 UTC终态 | 2026-10-30 13:22:28.015148，exit0，自有进程为空，四卡空闲 |
| v2控制器 | `aaa98bc025a8152a23efbe1cbd113018ed6b45fd2bd0d0d9de0571e29978f8f3` |
| v2完整子报告 | `67afca2a3189071289437be95bd8a8d6184a0f5a5dad189a963b3b8e2be4365d` |
| v2冻结清单 | `ef37960b4869885dc6ff488d0e598ac90e74f76820c6478695f20062ff9244ae` |
| 主分析 | `029831e8b47748516fecf70de37941bd4a52d87db471b836e09e177b386b9804` |
| 独立终态复核 | `7ec93a9ed3a8a24e263308c0d108fd15b79fa6990e93a411f1a125cb1b1f661e` |
| 原评分器 | `157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd` |

主分析和独立脚本均在root确认终态后读取子报告/日志。独立复核重新核对原始JSON/调度JSONL、8份token到文本解码、原评分器结果、全部短前缀延续与调度证据；答案结果和采集成功分别报告。新八题实验的 `full_quality_gate_attempted=false`、`full_frozen_plan_passed=null`、`runtime_candidate=false`。历史完整200题严格门仍FAIL；两次历史native各有9个length案例，其原始完整性条件没有修改。

## 发布范围与下一步

本目录发布完整token/文本子报告、全部本轮scheduler JSONL、进程日志的无损gzip副本、控制器和空闲设备记录、主/独立分析，以及{len(members)}成员源码包（含成员清单）。[发布映射](publication-map-v1.json)记录每份原件和存储副本的SHA/字节数，包内清单记录全部成员SHA；本地已逐字节核对gzip还原和全部成员。历史完整报告依赖及既有短logits NPY不在本包，**没有原始短张量公开上传或匿名HTTPS读回声明**。

下一步先将有效的显式q40配置纳入真实内置运行时，完成来源绑定和原posterior32批次，再用独立新进程执行完整200题。后续即使相对新增错题检查通过，也要与历史native不完整导致的原严格门FAIL分开；性能/Goo​dput需另做匹配场景评测，不能由本轮token数推断。

关联：[Issue #23](https://github.com/vLLM-HUST/vllm-ascend-MuxPD-hust/issues/23)、[q40短窗口调度对照](../muxpd-q40-scheduling-20261030/REPORT-v1.md)、[首次P状态证据](../muxpd-prefill-state-20261030/REPORT-v1.md)。
'''
    report=report.replace('Goo\u200bdput','Goodput')
    readme='''原batch7八题在q40下全部自然 `stop`，原评分器判定 **8/8正确**。07338回答H、3292 tokens，历史外部prefix q4曾在8192处截断；全部答案延续已确认的短窗口前缀。

**这是新进程的后验八题诊断。历史对照含前七批上下文；没有匹配的新进程q4、完整200题、性能或实际运行时候选通过声明。PR #27仍为Draft。**

- [逐题结果、调度、失败谱系与边界](REPORT-v1.md)
- [主分析](analysis-final-v1.json.gz)、[独立复核](independent-terminal-v1.json)、[完整token子报告](run-v2.json.gz)
- [冻结源码包](source-capsule-v1.tar.gz)、[发布映射](publication-map-v1.json)
- [v1启动失败](failure-lineage-v1.json)与[独立CPU后处理中断](cpu-postprocess-interruption-v1.json)均保留。

本包不含既有短logits NPY，不宣称原始张量已公开读回。
'''
    for name,text in (('README.md',readme),('REPORT-v1.md',report)):
        raw=text.encode();(DEST/name).write_bytes(raw)
        entries[name]={'encoding':'authored-utf8','stored_sha256':digest(raw),'stored_bytes':len(raw),
                       'derived_from':['analysis-final-v1.json.gz','independent-terminal-v1.json','failure-lineage-v1.json','cpu-postprocess-interruption-v1.json']}
    record={'schema':'muxpd-q40-full-answer-publication-map-v1','created_at':datetime.now(timezone.utc).isoformat(),
            'files':entries,'local_exact_copies':True,'raw_short_logits':'NOT_INCLUDED; no new full-answer logits collected and no prior raw NPY publication claimed.',
            'public_readback':'NOT_ATTEMPTED; local validation is not anonymous public HTTPS readback.',
            'root_navigation_commit_publication':'Not performed by stager; root reviews and owns those actions.'}
    (DEST/'publication-map-v1.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'report_dir':str(DEST),'staged_files':len(entries)+1,'source_members':len(members),
                      'source_capsule_sha256':digest(packed),'publication_map_sha256':digest((DEST/'publication-map-v1.json').read_bytes()),
                      'largest_bytes':max(p.stat().st_size for p in DEST.iterdir()),'local_exact_copies':True}))


if __name__=='__main__':main()
