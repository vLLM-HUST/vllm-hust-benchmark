import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

B = Path(__file__).resolve().parents[1]
D = Path(__file__).resolve().parent
sys.path.insert(0, str(B))
import quality_control_v1 as control

assert not (B / 'freeze-manifest-v1.json').exists()
files = {name: control.file_sha(B / name) for name in control.FILES}
npu = subprocess.run(['npu-smi', 'info'], text=True, capture_output=True, check=True).stdout
physical = control.inventory(npu)
assert physical == ['3', '4', '5', '6']
(D / 'npu-smi.txt').write_text(npu)
record = {'schema': 'muxpd-q40-full-answer-root-preflight-v2', 'created_at': datetime.now(timezone.utc).isoformat(), 'physical': physical, 'idle': True, 'files': files, 'dry_runs': [], 'sources': {}, 'runtime_env_script': {'path': '/root/workspace/runtime/env.sh', 'sha256': control.file_sha(Path('/root/workspace/runtime/env.sh'))}, 'scope': 'Read-only current source/device inventory and one full-answer dry-run; no model child or runtime import.'}
for path, commit in [('/root/workspace/vllm-hust', 'd0f22d2bda562156e4dbf433ce645e1769b4f804'), ('/root/workspace/vllm-ascend-hust', '03766ac696fde5ab1980d80ca0b8543d3580c989'), ('/root/workspace/muxpd-composite-token-logits', '6c606f789450a45ef35afee398b0a3e516caa1a1')]:
    head = subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()
    assert head == commit
    status = subprocess.check_output(['git', '-C', path, 'status', '--porcelain'], text=True)
    if 'vllm-ascend-hust' not in path:
        assert not status
    else:
        assert status == ' M csrc/build_aclnn.sh\n'
        assert control.file_sha(Path(path, 'csrc/build_aclnn.sh')) == 'b089d52475c6cb36fffd733bb5be3fbe4158b6845074751268938e98a1d0042c'
    record['sources'][path] = {'commit': head, 'status': status}
matrix = json.loads((B / 'run-matrix-v1.json').read_text())
assert len(matrix['sequence']) == 1 and matrix['sequence'][0]['attempts'] == 1
step = matrix['sequence'][0]
argv = step['controller_argv'].copy()
assert argv[2] == 'run'
argv[2] = 'dry-run'
done = subprocess.run(argv, text=True, capture_output=True, check=True)
j = json.loads(done.stdout)
assert j['bundle_frozen'] is False and j['files'] == files and j['expected_physical'] == physical
assert j['selected_batch_ids'] == [7] and j['selected_case_count'] == 8
assert j['launch_engine_args']['batch_admission_policy_config']['layers_per_slice'] == 40
output = D / 'batch7-full-answer-dry-run.json'
output.write_text(done.stdout)
record['dry_runs'].append({'label': step['label'], 'argv': argv, 'sha256': control.file_sha(output)})
assert {name: control.file_sha(B / name) for name in control.FILES} == files
(D / 'preflight.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'passed': True, 'file_count': len(files), 'dry_runs': len(record['dry_runs']), 'physical': physical, 'sha256': control.file_sha(D / 'preflight.json')}))
