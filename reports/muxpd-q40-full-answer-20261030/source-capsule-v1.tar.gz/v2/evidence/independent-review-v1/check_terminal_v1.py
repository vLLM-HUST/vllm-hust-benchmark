"""Independent CPU audit of one full8 attempt; root terminal authorization required."""

import argparse
import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

from tokenizers import Tokenizer

BUNDLE = Path('/root/workspace/muxpd-q40-full-answer-batch7-v2-20261030')
RUN = BUNDLE / 'runs-v1/prefix-q40-full-answer-batch7-v2-01'
SCORER_SHA = '157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd'
SEED, TARGET = 'mmlu-pro-07151', 'mmlu-pro-07338'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def terminal(directory, modern=True):
    value = read(directory / 'controller.json')
    assert value['finished_at'] and value['passed'] and value['exit_code'] == 0
    if modern:
        assert value['terminal_process_proven'] and value['owned_members_after_cleanup'] == []
        assert not value['errors'] and not value.get('cleanup_required') and not value.get('forced_termination')
        assert value['idle_physical_after'] == value['expected_physical']
    return value


def original_scorer():
    path = BUNDLE / 'score_quality.py'
    assert sha(path) == SCORER_SHA
    spec = importlib.util.spec_from_file_location('independent_original_full8_score', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def schedule_check(report, cases):
    receipt = RUN / 'results/scheduler-receipts.jsonl'
    assert sha(receipt) == report['scheduler_receipts_sha256']
    rows = [json.loads(line) for line in receipt.read_text().splitlines()]
    assert len(rows) >= 6 and len(rows) % 2 == 0
    order = [c['case_id'] for c in cases]
    admissions = report['admissions']
    assert [(a['batch_id'], a['global_step'], a['stage']) for a in admissions] == [(7, 0, 'seed'), (7, 1, 'peers')]
    assert [[x['case_id'] for x in a['bindings']] for a in admissions] == [order[:1], order[1:]]
    assert admissions[1]['seed_output_tokens'] == 1 and admissions[1]['seed_still_live'] is True
    bindings = {x['case_id']: x for a in admissions for x in a['bindings']}
    ids = {c: value['internal'] for c, value in bindings.items()}
    assert len(set(ids.values())) == 8 and len({x['external'] for x in bindings.values()}) == 8
    assert all(row['request_id'] == bindings[row['case_id']]['external'] for row in report['outputs'])
    prompts = {ids[c['case_id']]: len(c['prompt_token_ids']) for c in cases}
    previous, decode_sizes, retired_counts = set(), [], dict.fromkeys(ids.values(), 0)
    for step in range(1, len(rows) // 2 + 1):
        scheduled, retired = rows[2 * (step - 1):2 * step]
        assert scheduled['event'] == 'schedule' and retired['event'] == 'retirement'
        assert scheduled['batch_id'] == retired['batch_id'] == 7
        assert scheduled['global_step'] == retired['global_step'] == step
        p = {ids[order[0]]} if step == 1 else {ids[c] for c in order[1:]} if step == 2 else set()
        phases = scheduled['phases_before']
        assert set(phases) <= set(ids.values()) and set(phases.values()) <= {'P', 'D'}
        d = {rid for rid, phase in phases.items() if phase == 'D'}
        assert {rid for rid, phase in phases.items() if phase == 'P'} == p
        assert (not d if step == 1 else d == {ids[SEED]} if step == 2 else bool(d) and d <= previous)
        expected = {rid: prompts[rid] for rid in p} | dict.fromkeys(d, 1)
        assert scheduled['scheduled_tokens'] == expected
        assert set(scheduled['new_prefill_ids']) == set(scheduled['pending_prefill_ids']) == p
        assert not scheduled['preempted_req_ids'] and scheduled['prefill_layers_before'] == 0
        assert set(retired['completed_prefill_ids']) == p and not retired['cancelled_prefill_ids']
        assert retired['prefill_layers_completed'] == (40 if p else 0)
        assert retired['actual_prefill_progress'] is bool(p)
        assert retired['mixed_pd_progress_and_retirement'] is bool(p and d)
        assert retired['native_mixed_scheduled_and_decode_retired'] is False
        assert set(retired['decode_retired_ids']) == d and len(retired['decode_retired_ids']) == len(d)
        if d:
            decode_sizes.append(len(d))
            for rid in d:
                retired_counts[rid] += 1
        previous = p | d
    assert report['answer_engine_steps'] == len(rows) // 2
    assert {int(k): v for k, v in report['mixed_coverage']['steps_per_batch'].items()} == {7: 1}
    assert report['mixed_coverage']['covered_batches'] == [7] and report['mixed_coverage']['uncovered_batches'] == []
    before = {r['rank']: r for r in report['worker_before']}
    after = {r['rank']: r for r in report['worker_after']}
    assert len(report['worker_before']) == len(report['worker_after']) == 4 and set(before) == set(after) == set(range(4))
    graphs = []
    for rank in range(4):
        a, b = before[rank]['decode_graph_snapshot'], after[rank]['decode_graph_snapshot']
        for workers in (before, after):
            assert workers[rank]['runtime']['policy'] == report['engine_args']['batch_admission_policy_config']
            assert workers[rank]['external_observer_modules'] == {}
        assert a['captured'] and b['captured'] and not a['failed'] and not b['failed']
        assert a['captured_graph_entries'] == b['captured_graph_entries'] == 4
        assert a['includes_startup_warmups'] and b['includes_startup_warmups']
        for key in ('capture_attempts', 'capture_successes', 'capture_failures', 'decode_capture_forward_calls', 'decode_eager_fallback_calls', 'decode_uncaptured_full_calls', 'decode_forward_failures', 'prefill_compiled_calls', 'prefill_compile_profile_runs', 'prefill_compile_profile_failures'):
            assert a[key] == b[key]
        assert a['capture_successes'] >= 1 and a['capture_failures'] == a['decode_forward_failures'] == a['decode_uncaptured_full_calls'] == 0
        assert a['prefill_compiled_calls'] == a['prefill_compile_profile_runs'] == a['prefill_compile_profile_failures'] == 0
        assert b['prefill_forced_eager_calls'] - a['prefill_forced_eager_calls'] == 2
        assert b['decode_replay_calls'] - a['decode_replay_calls'] == len(decode_sizes)
        graphs.append({'rank': rank, 'replay_before': a['decode_replay_calls'], 'replay_after': b['decode_replay_calls'], 'replay_delta': len(decode_sizes)})
    for rank in report['layout_final']:
        seed, peers = rank['cohorts']
        assert seed['admission_p_counts'] == {ids[SEED]: prompts[ids[SEED]]} and seed['admission_d_counts'] == {}
        assert seed['calls'] == [] and seed['zero_d_bypass_calls'] == 81
        assert peers['admission_p_counts'] == {ids[c]: prompts[ids[c]] for c in order[1:]}
        assert peers['admission_d_counts'] == {ids[SEED]: 1}
        assert len(peers['calls']) == 81 and peers['zero_d_bypass_calls'] == 0
    return {'receipt_sha256': sha(receipt), 'serving_steps': len(rows) // 2,
            'peer_prefill_advancements': 1, 'peer_completed_layers': 40, 'peer_ack_count': 7,
            'decode_turns': len(decode_sizes), 'decode_batch_sizes': decode_sizes,
            'decode_retirements_per_case': {c: retired_counts[rid] for c, rid in ids.items()},
            'graph_receipts': graphs, 'terminal_maintenance': report['terminal_maintenance']}


def previous_failure():
    old = Path('/root/workspace/muxpd-q40-full-answer-batch7-20261030')
    run = old / 'runs-v1/prefix-q40-full-answer-batch7-v1-01'
    assert sha(BUNDLE / 'root-decision-v2.json') == 'cd277920ae8394fe20c6109c19518088a6cfd38db0f941570a77e2b7f7587ffc'
    assert sha(old / 'failure-lineage-v1.json') == '7e37f193a37a8731be93880046820638b76fe7eee97b18ec21a3f555f82915e9'
    assert sha(run / 'controller.json') == '294f127f2d45187e1237b61b0013a553eadf5db4b0965d2900c40411e7a80238'
    controller = read(run / 'controller.json')
    assert controller['finished_at'] and controller['terminal_process_proven'] and controller['exit_code'] == 1
    assert not controller['passed'] and controller['owned_members_before_cleanup'] == controller['owned_members_after_cleanup'] == []
    assert sha(run / 'results/run.json') == '433f81f693ecf390f9f3f173b8d69d7fee83a2f99a0f6851ef96c2a19bbfecf3'
    report = read(run / 'results/run.json')
    assert report['outputs'] == report['admissions'] == [] and not report['collection_complete']
    assert 'worker_before' not in report and 'layout_installation' not in report
    assert 'Runtime environment differs from original quality before model construction' in report['errors'][0]
    return {'controller_sha256': sha(run / 'controller.json'), 'child_sha256': sha(run / 'results/run.json'),
            'failure_lineage_sha256': sha(old / 'failure-lineage-v1.json'), 'admissions': 0, 'outputs': 0,
            'scope': 'Original pre-model environment-guard failure retained; no selected answer output.'}


def verify(analysis):
    primary = read(analysis)
    assert primary['schema'] == 'muxpd-q40-batch7-full-analysis-v1' and primary['collection_valid']
    assert primary['runtime_candidate'] is False and primary['full_quality_gate_attempted'] is False and primary['full_frozen_plan_passed'] is None
    controller = terminal(RUN)
    failure = previous_failure()
    refs = read(BUNDLE / 'batch7-full-references-v1.json')
    short_dir = Path(refs['short_runs']['plain'])
    terminal(short_dir)
    for item in refs['historical_runs'].values():
        terminal(Path(item['directory']), modern=False)
    # All terminal receipts above precede all actual child/output reads below.
    for name, digest in refs['files'].items():
        assert sha(name) == digest
    freeze_path = BUNDLE / 'freeze-manifest-v1.json'; freeze = read(freeze_path); files = freeze['files']
    assert freeze['status'] == 'frozen' and len(files) == 24 and controller['files'] == files
    assert sha(RUN / 'producer/freeze-manifest-v1.json') == sha(freeze_path) == controller['freeze_manifest_sha256']
    assert all(sha(BUNDLE / n) == sha(RUN / 'producer' / n) == d for n, d in files.items())
    report_path = RUN / 'results/run.json'
    assert sha(report_path) == controller['terminal_run_sha256'] == primary['collection_proof']['child']['sha256']
    report = read(report_path)
    assert report['schema'] == 'muxpd-q40-full-answer-run-v1' and report['scope'] == 'batch7-full-answer'
    assert report['passed'] and report['collection_complete'] and report['layout_restored'] and report['shutdown_returned']
    assert report['errors'] == [] and not report.get('failure_cleanup') and not report['terminal_maintenance']['aborted_internal_ids']
    assert report['runtime_candidate'] is False and report['full_quality_gate_attempted'] is False and report['full_frozen_plan_passed'] is None
    original = original_scorer()
    plan, full_cases, extract = original.load_frozen(BUNDLE / 'frozen-v2')
    assert plan['plan_sha256'] == report['plan_sha256'] == 'dd3e1f305475ec556dc824947f26d5fb5743242e82b5099155c95b8954bb2e65'
    assert len(full_cases) == plan['case_count'] == 200
    batch = next(b for b in plan['batches'] if b['batch_id'] == 7)
    order = batch['case_ids']; case_map = {c['case_id']: c for c in full_cases}; cases = [case_map[c] for c in order]
    assert len(cases) == 8 and report['selected_batch_ids'] == [7] and report['selected_case_ids'] == order
    assert plan['sampling'] == {'temperature': 0.0, 'seed': 42, 'max_tokens': 8192, 'ignore_eos': False, 'detokenize': False}
    histories = {role: read(Path(item['directory']) / 'results/run.json') for role, item in refs['historical_runs'].items()}
    base = read(BUNDLE / 'raw-engine-args-v1.json'); expected = copy.deepcopy(base)
    expected['worker_cls'] = 'vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker'
    expected['batch_admission_policy_config']['layers_per_slice'] = 40
    assert expected == report['base_engine_args'] == controller['launch_engine_args']
    resolved = copy.deepcopy(histories['raw']['engine_args']); resolved['batch_admission_policy_config']['layers_per_slice'] = 40
    assert resolved == report['engine_args']
    assert report['runtime_environment'] == histories['raw']['runtime_environment']
    assert controller['runtime_environment_guard']['passed'] is True
    assert controller['runtime_environment_guard']['environment'] == report['runtime_environment']['environment']
    for module in ('vllm', 'vllm_ascend'):
        assert report['sources'][module] == histories['raw']['sources'][module]
    plugin = report['sources']['vllm_muxpd']
    assert plugin['commit'] == '6c606f789450a45ef35afee398b0a3e516caa1a1' and not plugin['status'] and not plugin['changed_files']
    assert report['source_equivalence'] == histories['prefix']['source_equivalence']
    for guard in (controller['source_preflight'], report['source_after_startup'], report['sources_after_shutdown']):
        assert guard == {'sources': report['sources'], 'equivalence': report['source_equivalence']}
    model = refs['model_config_identity']; assert report['model_config_identity'] == model and sha(model['path']) == model['sha256']
    for item in plan['tokenizer_files'].values():
        assert sha(item['path']) == item['sha256']
    decoder = Tokenizer.from_file(plan['tokenizer_files']['tokenizer.json']['path'])
    outputs = {r['case_id']: r for r in report['outputs']}
    assert len(report['outputs']) == len(outputs) == 8 and set(outputs) == set(order)
    for row in report['outputs']:
        ids = row['token_ids']
        assert row['finished'] and not row.get('error') and row['finish_reason'] in ('stop', 'length')
        assert 0 < len(ids) <= 8192 and all(type(t) is int and 0 <= t < decoder.get_vocab_size() for t in ids)
        assert row['finish_reason'] != 'length' or len(ids) == 8192
        assert row['text'] == decoder.decode(ids, skip_special_tokens=True)
    schedule = schedule_check(report, cases)
    expected_schedule = primary['collection_proof']['schedule']
    for field in ('serving_steps', 'peer_prefill_advancements', 'decode_turns', 'decode_batch_sizes', 'decode_retirements_per_case'):
        assert schedule[field] == expected_schedule[field]
    # Reuse only byte-identical original offline layout/runtime validators.
    sys.path.insert(0, str(BUNDLE))
    import prefill_collective_layout_v1 as layout
    import probe_run_v1 as runtime_checks
    layout_sha = files['prefill_collective_layout_v1.py']
    layout.validate_receipts(report['layout_installation'], layout_sha, mode='prefix', expected_treated_cohorts=0, expected_completed=0)
    layout.validate_receipts(report['layout_final'], layout_sha, mode='prefix', expected_treated_cohorts=1, expected_completed=2)
    layout.validate_uninstall_receipts(report['layout_uninstall'], layout_sha, mode='prefix')
    runtime_checks.require_empty(report['final_state'], report['idle_baseline'])
    for worker in report['worker_after']:
        runtime_checks.require_empty_worker(worker)
    scores = {}
    for role, value in {**histories, 'q40': report}.items():
        selected = {**value, 'outputs': [r for r in value['outputs'] if r['case_id'] in order]}
        scores[role] = original.score(selected, plan, cases, extract)
        assert scores[role] == primary['answer_diagnostic']['scores'][role]
    new_wrong, resolved_losses = [], []
    scored_rows = []
    primary_rows = {r['case_id']: r for r in primary['answer_diagnostic']['rows']}
    for index, case in enumerate(cases):
        cid = case['case_id']; arms = {role: score['rows'][index] for role, score in scores.items()}
        stable = arms['native1']['correct'] and arms['native2']['correct']
        if stable and not arms['q40']['correct']: new_wrong.append(cid)
        if stable and not arms['prefix']['correct'] and arms['q40']['correct']: resolved_losses.append(cid)
        for role, row in arms.items():
            assert all(primary_rows[cid]['arms'][role][k] == v for k, v in row.items())
        scored_rows.append({'case_id': cid, 'gold': case['answer'], 'arms': arms,
                            'q40_stop_reason': outputs[cid]['stop_reason'],
                            'q40_token_ids_sha256': hashlib.sha256(original.canonical(outputs[cid]['token_ids'])).hexdigest(),
                            'q40_text_sha256': hashlib.sha256(outputs[cid]['text'].encode()).hexdigest()})
    assert new_wrong == primary['answer_diagnostic']['new_wrong_on_both_native_correct']
    assert resolved_losses == primary['answer_diagnostic']['resolved_old_prefix_losses']
    short = read(short_dir / 'results/run.json'); extension = {}
    assert set(short['prefixes_before_abort']) == set(order)
    for cid in order:
        a, b = short['prefixes_before_abort'][cid]['output_token_ids'], outputs[cid]['token_ids']
        assert len(a) == (209 if cid == SEED else 208)
        first = next((i + 1 for i, (x, y) in enumerate(zip(a, b)) if x != y), None)
        if first is None and len(b) < len(a): first = len(b) + 1
        extension[cid] = {'passed': first is None, 'required_prefix_tokens': len(a), 'full_output_tokens': len(b), 'first_difference_one_based': first}
    trajectory = all(row['passed'] for row in extension.values())
    assert extension == primary['short_plain_trajectory_extension']['cases']
    assert trajectory == primary['trajectory_qualified'] == primary['short_plain_trajectory_extension']['passed']
    assert primary['passed'] == trajectory
    assert all(sha(BUNDLE / n) == sha(RUN / 'producer' / n) == d for n, d in files.items())
    return {'passed': True, 'script_sha256': sha(Path(__file__)), 'primary_analysis': {'path': str(analysis), 'sha256': sha(analysis)},
            'controller_sha256': sha(RUN / 'controller.json'), 'child_sha256': sha(report_path), 'freeze_sha256': sha(freeze_path),
            'scorer_sha256': SCORER_SHA, 'previous_failure': failure, 'selected_case_ids': order, 'actual_outputs_decoded': 8,
            'scores': scores, 'per_case_rows': scored_rows, 'new_wrong_on_both_native_correct': new_wrong,
            'resolved_old_prefix_losses': resolved_losses, 'trajectory_qualified': trajectory,
            'short_prefix_extension': extension, 'schedule': schedule,
            'full_quality_gate_attempted': False, 'full_frozen_plan_passed': None, 'runtime_candidate': False,
            'scope': 'Independent terminal/JSON/JSONL and exact original scoring audit of eight posterior answers. Quality outcomes remain separate from audit success. Historical full200 context differs; no freshfull200 or performance acceptance.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(); assert not args.output.exists()
    result = verify(args.analysis)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({'passed': True, 'output': str(args.output), 'sha256': sha(args.output),
                      'trajectory_qualified': result['trajectory_qualified'],
                      'correct': {name: value['correct'] for name, value in result['scores'].items()},
                      'new_wrong': result['new_wrong_on_both_native_correct']}))
