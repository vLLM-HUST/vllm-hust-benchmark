#!/usr/bin/env bash
set -Eeuo pipefail

export PATH=/root/miniconda3/envs/vllm-hust-dev/bin:$PATH
export MODEL=/data/shared_models/Qwen3.5-35B-A3B
export ASCEND_RT_VISIBLE_DEVICES=0,1
export VLLM_PLUGINS=ascend,vllm-ascend-quantized-kv-cache
export PYTHONUNBUFFERED=1

: "${OUT:?必须设置 OUT}"
mkdir -p "$OUT"

SERVER_PID=""
CLIENT_PID=""
echo RUNNING > "$OUT/STATUS"

stop_server() {
    if [[ -n "$SERVER_PID" ]]; then
        echo "停止本脚本启动的服务，进程组：$SERVER_PID"
        kill -TERM -- "-$SERVER_PID" 2>/dev/null || true

        for ((i=0; i<60; i++)); do
            if ! kill -0 -- "-$SERVER_PID" 2>/dev/null; then
                break
            fi
            sleep 1
        done

        if kill -0 -- "-$SERVER_PID" 2>/dev/null; then
            kill -KILL -- "-$SERVER_PID" 2>/dev/null || true
        fi
        wait "$SERVER_PID" 2>/dev/null || true
        SERVER_PID=""
    fi
}

cleanup() {
    rc=$?
    trap - EXIT INT TERM
    if [[ -n "$CLIENT_PID" ]]; then
        kill -TERM "$CLIENT_PID" 2>/dev/null || true
        wait "$CLIENT_PID" 2>/dev/null || true
    fi
    stop_server
    if ((rc != 0)); then
        echo FAILED > "$OUT/STATUS"
    fi
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# 检查端口是否可用，不干扰已有服务。
python - <<'PY'
import socket
with socket.socket() as s:
    try:
        s.bind(("127.0.0.1", 8000))
    except OSError:
        raise SystemExit("8000 端口已占用，请先手动停止旧服务。")
PY

for CONCURRENCY in 16 32 64; do
    RUN_OUT="$OUT/concurrency-$CONCURRENCY"
    mkdir -p "$RUN_OUT"
    CAPTURE_SIZES=(1 2 4 8 16)
    if ((CONCURRENCY >= 32)); then CAPTURE_SIZES+=(32); fi
    if ((CONCURRENCY >= 64)); then CAPTURE_SIZES+=(64); fi

for ARM in bf16 int8; do
    KV=auto
    [[ "$ARM" == int8 ]] && KV=int8

    echo "[$(date -Is)] 启动 concurrency=$CONCURRENCY $ARM 服务"

    # 独立进程组，便于压测结束后清理服务及其 worker。
    setsid vllm serve "$MODEL" \
      --served-model-name a3-model \
      --host 127.0.0.1 --port 8000 \
      --tensor-parallel-size 2 \
      --dtype bfloat16 \
      --kv-cache-dtype "$KV" \
      --max-model-len 32768 \
      --max-num-seqs "$CONCURRENCY" \
      --max-num-batched-tokens 2048 \
      --gpu-memory-utilization 0.80 \
      --enable-chunked-prefill \
      --no-enable-prefix-caching \
      --compilation-config '{"mode":3,"cudagraph_mode":"FULL_DECODE_ONLY"}' \
      --cudagraph-capture-sizes "${CAPTURE_SIZES[@]}" \
      > "$RUN_OUT/$ARM-server.log" 2>&1 < /dev/null &

    SERVER_PID=$!
    echo "$SERVER_PID" > "$RUN_OUT/$ARM-server.pid"

    READY=0
    for ((i=0; i<360; i++)); do
        if ! kill -0 "$SERVER_PID" 2>/dev/null; then
            echo "$ARM 服务退出，请查看 $RUN_OUT/$ARM-server.log"
            exit 1
        fi
        if env -u LD_LIBRARY_PATH /usr/bin/curl --noproxy '*' -fsS --max-time 3 \
            http://127.0.0.1:8000/health >/dev/null 2>&1; then
            READY=1
            break
        fi
        sleep 5
    done

    if ((READY == 0)); then
        echo "$ARM 服务启动等待超时"
        exit 1
    fi

    echo "[$(date -Is)] concurrency=$CONCURRENCY $ARM 服务就绪，开始预热及 1800 秒压测"

    python -u /root/a3_kv_bench.py \
      --model "$MODEL" \
      --seconds 1800 \
      --concurrency "$CONCURRENCY" \
      --output "$RUN_OUT/$ARM" \
      > "$RUN_OUT/$ARM-client.log" 2>&1 < /dev/null &

    CLIENT_PID=$!
    wait "$CLIENT_PID"
    CLIENT_PID=""

    echo "[$(date -Is)] concurrency=$CONCURRENCY $ARM 压测完成"
    stop_server
    sleep 5
done
done

python - <<'PY'
import json
import os
from pathlib import Path

root = Path(os.environ["OUT"])
for concurrency in (16, 32, 64):
    print(f"\n===== concurrency={concurrency} =====")
    results = {
        arm: json.loads((root / f"concurrency-{concurrency}" / arm / "summary.json").read_text())
        for arm in ("bf16", "int8")
    }
    
    for arm, result in results.items():
        print(f"\n{arm.upper()}")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    b = results["bf16"]["window_completed"]["output_tokens_per_second"]
    q = results["int8"]["window_completed"]["output_tokens_per_second"]
    if b > 0:
        print(f"\nINT8 窗口完成输出吞吐变化：{(q / b - 1) * 100:+.2f}%")

PY

# COMPLETE 表示流程完成，是否达到延迟门槛看 summary.json。
echo COMPLETE > "$OUT/STATUS"
echo "全部完成，结果目录：$OUT"
