"""A3-shaped KV comparison: closed-loop load, 1800s admission window plus drain."""
import argparse
import asyncio
import hashlib
import json
import time
from pathlib import Path

import aiohttp
import numpy as np
from transformers import AutoTokenizer
from vllm.benchmarks.lib.endpoint_request_func import (
    RequestFuncInput, async_request_openai_completions,
)


def summarize(rows):
    good = [r for r in rows if r['success']]
    result = {'requests': len(rows), 'successful': len(good),
              'failed': len(rows) - len(good),
              'output_tokens': sum(r['output_tokens'] for r in good)}
    passed = bool(good) and len(good) == len(rows)
    for name, limits in [('ttft_s', [30, 45, 60]), ('tpot_ms', [40, 60, 80])]:
        values = [r[name] for r in good]
        stats = ([float(np.mean(values)), *map(float, np.percentile(values, [95, 99]))]
                 if values else [None] * 3)
        result[name] = dict(zip(['mean', 'p95', 'p99'], stats))
        passed &= bool(values) and all(v <= lim for v, lim in zip(stats, limits))
    result['latency_thresholds_and_no_errors_pass'] = bool(passed)
    return result


async def main(args):
    dest = Path(args.output)
    dest.mkdir(parents=True, exist_ok=False)
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    text = ('This document describes a distributed inference service. '
            'Requests contain documents, schedules, experiments and observations. '
            'Read the context and continue with a detailed technical explanation.\n')
    unit = tokenizer.encode(text, add_special_tokens=False)
    prompt = (unit * (30720 // len(unit) + 1))[:30720]
    config = vars(args) | {'input_tokens': 30720, 'output_tokens': 2048,
                           'prompt_sha256': hashlib.sha256(json.dumps(prompt).encode()).hexdigest(),
                           'load': 'closed-loop fixed concurrency; synthetic repeated prose',
                           'scope': 'engineering comparison using A3 lengths and latency limits; not formal acceptance'}
    (dest / 'config.json').write_text(json.dumps(config, indent=2))
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=900)) as session:
        async def request():
            return await async_request_openai_completions(RequestFuncInput(
                prompt=prompt, api_url=args.url.rstrip('/') + '/v1/completions',
                prompt_len=30720, output_len=2048, model='a3-model',
                ignore_eos=True, extra_body={'temperature': 0, 'seed': 17,
                                             'add_special_tokens': False}), session)

        print('Warmup/calibration: 30720 input + 2048 output tokens', flush=True)
        warm = await request()
        if not warm.success or warm.prompt_len != 30720 or warm.output_tokens != 2048:
            raise RuntimeError(f'Warmup failed: {warm.error}; tokens={warm.prompt_len}/{warm.output_tokens}')
        start = time.perf_counter()
        end = start + args.seconds
        rows = []
        print(f'Measurement started: {args.seconds}s, concurrency={args.concurrency}', flush=True)
        with (dest / 'requests.jsonl').open('w') as raw:
            async def worker(index):
                while time.perf_counter() < end:
                    sent = time.perf_counter()
                    output = await request()
                    finished = time.perf_counter()
                    valid = (output.success and output.prompt_len == 30720 and output.output_tokens == 2048)
                    row = {'worker': index, 'start_s': sent - start, 'end_s': finished - start,
                           'in_window': finished <= end, 'success': valid,
                           'input_tokens': output.prompt_len, 'output_tokens': output.output_tokens,
                           'ttft_s': output.ttft,
                           'tpot_ms': max(0, output.latency - output.ttft) * 1000 / 2047,
                           'error': output.error if valid else output.error or 'token count mismatch'}
                    rows.append(row)
                    raw.write(json.dumps(row) + '\n')
                    raw.flush()
                    if not valid:
                        await asyncio.sleep(1)
            await asyncio.gather(*(worker(i) for i in range(args.concurrency)))
        window = [r for r in rows if r['in_window']]
        result = {'window_seconds': args.seconds, 'concurrency': args.concurrency,
                  'window_completed': summarize(window),
                  'all_admitted_including_drain': summarize(rows),
                  'unfinished_at_window_end': sum(not r['in_window'] for r in rows),
                  'drain_seconds': max(0, time.perf_counter() - end)}
        result['window_completed']['output_tokens_per_second'] = result['window_completed']['output_tokens'] / args.seconds
        (dest / 'summary.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--url', default='http://127.0.0.1:8000')
    parser.add_argument('--seconds', type=int, default=1800)
    parser.add_argument('--concurrency', type=int, default=4)
    parser.add_argument('--output', required=True)
    arguments = parser.parse_args()
    if arguments.seconds <= 0 or arguments.concurrency <= 0:
        parser.error('seconds and concurrency must be positive')
    asyncio.run(main(arguments))
