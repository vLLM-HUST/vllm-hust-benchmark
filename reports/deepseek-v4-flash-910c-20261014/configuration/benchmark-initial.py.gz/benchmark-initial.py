"""Fixed-shape cache-miss serving sweep; one immutable result directory per point."""
import argparse,json,pathlib,subprocess,time,urllib.request
p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--chips',type=int,required=True);p.add_argument('--concurrencies',default='32,64,128,256');p.add_argument('--input',type=int,default=8192);p.add_argument('--output',type=int,default=1024);a=p.parse_args()
b=pathlib.Path('/home/lumi-deepseek-baseline')/a.label;assert b.is_dir()
model='/home/models/DeepSeek-V4-Flash-0731-w8a8';py='/home/lumi-pd27/serving-venv/bin/python'
for c in map(int,a.concurrencies.split(',')):
 d=b/f'i{a.input}-o{a.output}-c{c}';d.mkdir(exist_ok=False)
 args=[py,'-m','vllm.entrypoints.cli.main','bench','serve','--backend','vllm','--base-url','http://127.0.0.1:29610','--endpoint','/v1/completions','--model',model,'--served-model-name','dsv4','--tokenizer',model,'--tokenizer-mode','deepseek_v4','--dataset-name','random','--random-input-len',str(a.input),'--random-output-len',str(a.output),'--random-range-ratio','0','--num-prompts',str(max(128,4*c)),'--num-warmups','8','--max-concurrency',str(c),'--request-rate','inf','--ignore-eos','--seed','42','--save-result','--save-detailed','--result-dir',str(d),'--result-filename','result.json','--percentile-metrics','ttft,tpot,itl,e2el','--metric-percentiles','50,90,95,99']
 (d/'command.json').write_text(json.dumps(args,indent=2));print('START',d.name,flush=True)
 start=time.time()
 with (d/'client.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 (d/'returncode').write_text(str(r.returncode));assert r.returncode==0,(d,r.returncode)
 result=json.loads((d/'result.json').read_text());assert result['completed']==max(128,4*c),(d,result.get('completed'))
 out=dict(label=a.label,logical_dies=a.chips,physical_packages=a.chips//2,input_tokens=a.input,output_tokens=a.output,concurrency=c,started=start,ended=time.time(),completed=result['completed'],output_throughput=result['output_throughput'],output_tok_s_die=result['output_throughput']/a.chips,output_tok_s_package=result['output_throughput']/(a.chips//2),result_path=str(d/'result.json'))
 (d/'summary.json').write_text(json.dumps(out,indent=2));print('COMPLETE',json.dumps(out),flush=True)
(b/'sweep-complete.json').write_text(json.dumps({'ok':True,'chips':a.chips}))
