"""CPU postprocess only; root must authorize both model terminals before use."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

BUNDLE = Path("/root/workspace/muxpd-target-early-logits-20261030")
sys.path.insert(0, str(BUNDLE))
import window_analysis_core_v1 as core


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def terminal(path):
    value = json.loads((path / "controller.json").read_text())
    assert value["finished_at"] and value["passed"] and value["exit_code"] == 0
    assert value["terminal_process_proven"]
    assert value["owned_members_after_cleanup"] == [] and not value["errors"]
    assert not value.get("cleanup_required") and not value.get("forced_termination")
    return value


def array(path, receipt, shape):
    assert path.name == receipt["file"] and not path.is_symlink()
    assert sha(path) == receipt["sha256"] and path.stat().st_size == receipt["bytes"]
    value = np.load(path, allow_pickle=False, mmap_mode="r")
    assert value.dtype == np.dtype("float32") and list(value.shape) == shape
    return value


def json_sha(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def token_sha(tokens):
    return hashlib.sha256(
        json.dumps(tokens, separators=(",", ":")).encode()
    ).hexdigest()


def own_input(value):
    row = value["row"]
    own = next(r for r in value["semantic_batch"] if r["case_id"] == core.TARGET)
    return {
        key: row[key]
        for key in (
            "prompt_token_ids",
            "output_prefix_token_ids",
            "input_token_ids",
            "num_computed_tokens",
            "num_tokens_no_spec",
        )
    } | {"scheduled_tokens": own["scheduled_tokens"]}


def load_targets(collection, files):
    report, path = collection["report"], collection["directory"]
    role = report["profile"].split("-")[0]
    assert report["schema"] == "muxpd-target-early-logits-run-v1"
    assert not any(k.startswith("layer_hook_") for k in report)
    assert not (path / "results/layer-observations").exists()
    for phase in ("worker_before", "worker_after"):
        workers = report[phase]
        assert len(workers) == 4 and {r["rank"] for r in workers} == set(range(4))
        for worker in workers:
            assert worker["external_observer_modules"] == {
                name: {
                    "path": str((path / "producer" / (name + ".py")).resolve()),
                    "sha256": files[name + ".py"],
                }
                for name in (
                    "window_numeric_diagnostics_v1",
                    "window_numeric_workers_v1",
                )
            }
    profile_path = path / "producer/target-capture-profile-v1.json"
    profile_sha = sha(profile_path)
    assert (
        profile_sha
        == "8e1d9af5546d8b98f8d578eecbfbc543bd10dcbfea146da1a6201c0c9dd42a43"
    )
    profile = json.loads(profile_path.read_text())
    plan = report["plan"]
    prompt = next(
        c["prompt_token_ids"] for c in plan["cases"] if c["case_id"] == core.TARGET
    )
    assert len(prompt) == 1340 and token_sha(prompt) == profile["target_prompt_sha256"]
    assert profile["extra_capture_token_indices_one_based"] == list(range(2, 200))
    assert (
        profile["regular_capture_token_indices_one_based"]
        == plan["capture_token_indices_one_based"]
        == [1, *range(200, 209)]
    )
    assert profile["capture_ranks"] == [0] and profile["vocab_size"] == 248320
    assert profile["source_plan"]["plan_sha256"] == plan["plan_sha256"]
    mapping = {
        r["internal"]: r["case_id"]
        for phase in report["admissions"]
        for r in phase["bindings"]
    }
    assert len(mapping) == 8 and len(set(mapping.values())) == 8
    prefix = collection["prefixes"][core.TARGET]["output_token_ids"]
    assert len(prefix) == 208
    regular = path / "results/worker-observations"
    extra = path / "results/target-extra-logits"
    lanes = {"native"} if role == "native" else {"prefill", "decode"}
    extra_lane = "native" if role == "native" else "decode"
    installed = set()
    contexts = {r: {} for r in range(4)}
    targets = {}
    extra_paths = set()
    clone_counts = 0
    for logfile in sorted(regular.glob("rank-*-*.jsonl")):
        with logfile.open() as stream:
            for line in stream:
                event = json.loads(line)
                rank = event["rank"]
                lane = event["lane"]
                assert rank in range(4) and lane in lanes
                assert logfile.name == f"rank-{rank}-{lane}.jsonl"
                if event["event"] == "observer-installed":
                    assert (rank, lane) not in installed
                    installed.add((rank, lane))
                    assert (
                        event["target_extra_profile"] == profile
                        and event["target_extra_profile_sha256"] == profile_sha
                    )
                    assert event["capture_token_indices_one_based"] == plan[
                        "capture_token_indices_one_based"
                    ] and event["capture_ranks"] == [0]
                    continue
                if event["event"] != "native-sample-observed":
                    continue
                semantic = [
                    {
                        "case_id": mapping[row["request_id"]],
                        **{
                            key: row[key]
                            for key in (
                                "row",
                                "prompt_token_ids",
                                "output_prefix_token_ids",
                                "num_computed_tokens",
                                "num_tokens_no_spec",
                                "input_token_ids",
                            )
                        },
                        "scheduled_tokens": event["schedule"][
                            "num_scheduled_tokens"
                        ].get(row["request_id"]),
                    }
                    for row in event["rows"]
                ]
                target_rows = [
                    r for r in event["rows"] if mapping[r["request_id"]] == core.TARGET
                ]
                assert len(target_rows) <= 1
                selected = rank == 0 and any(
                    r["output_token_index"] + 1
                    in plan["capture_token_indices_one_based"]
                    or (
                        mapping[r["request_id"]] == core.TARGET
                        and 2 <= r["output_token_index"] + 1 <= 199
                    )
                    for r in event["rows"]
                )
                clone = event.get("clone_receipt")
                if selected:
                    shape = [len(event["rows"]), 248320]
                    assert 1 <= shape[0] <= 8 and event["shape"] == shape
                    assert clone == {
                        "shape": shape,
                        "dtype": "torch.float32",
                        "numel": shape[0] * 248320,
                        "element_size": 4,
                        "bytes": shape[0] * 248320 * 4,
                        "clone_count": 1,
                        "original_greedy_completed": True,
                    }
                    assert clone["bytes"] <= 7946240
                    clone_counts += 1
                else:
                    assert clone is None
                for row in event["rows"]:
                    case = mapping[row["request_id"]]
                    position = row["output_token_index"] + 1
                    receipt = row.get("extra_logits")
                    eligible = (
                        rank == 0
                        and case == core.TARGET
                        and 2 <= position <= 199
                        and lane == extra_lane
                    )
                    assert bool(receipt) is eligible
                    if case != core.TARGET:
                        continue
                    assert position in range(1, 209) and position not in contexts[rank]
                    assert lane == (
                        "native"
                        if role == "native"
                        else ("prefill" if position == 1 else "decode")
                    )
                    index = position - 1
                    count = 1340 + index
                    assert (
                        event["rows"][row["row"]] == row
                        and event["native_greedy_calls"] == 1
                    )
                    assert row["prompt_token_ids"] == prompt and row[
                        "prompt_sha256"
                    ] == token_sha(prompt)
                    assert row["output_prefix_token_ids"] == prefix[:index] and row[
                        "output_prefix_sha256"
                    ] == token_sha(prefix[:index])
                    assert (
                        row["input_token_ids"] == prompt + prefix[:index]
                        and row["num_tokens_no_spec"] == count
                    )
                    assert row["num_computed_tokens"] == (
                        0 if position == 1 else count - 1
                    )
                    assert event["schedule"]["num_scheduled_tokens"][
                        row["request_id"]
                    ] == (1340 if position == 1 else 1)
                    assert (
                        row["sampled_token_ids"] == prefix[index : index + 1]
                        and row["discarded_by_native"] is False
                    )
                    context = {
                        "semantic_batch": semantic,
                        "batch_descriptor": event.get("batch_descriptor"),
                        "sequence": event["sequence"],
                        "lane": lane,
                    }
                    contexts[rank][position] = context
                    if rank != 0:
                        continue
                    original = collection["decisions"][(core.TARGET, index)]
                    assert original["row"] == row and all(
                        original[key] == value for key, value in context.items()
                    )
                    if receipt:
                        assert (
                            receipt["file"]
                            == f"rank-0-{lane}-target-{position:03d}.npy"
                        )
                        assert (
                            receipt["output_token_index_one_based"] == position
                            and receipt["profile_sha256"] == profile_sha
                        )
                        assert receipt["clone_receipt_sha256"] == json_sha(clone)
                        assert (
                            receipt["shape"] == [248320]
                            and receipt["dtype"] == "float32"
                            and receipt["all_finite"] is True
                        )
                        vector_path = extra / receipt["file"]
                        assert vector_path not in extra_paths
                        extra_paths.add(vector_path)
                    else:
                        assert (
                            position in plan["capture_token_indices_one_based"]
                            and original["receipt"]
                        )
                        receipt = original["receipt"]
                        vector_path = regular / receipt["file"]
                    values = array(vector_path, receipt, [248320])
                    assert np.isfinite(values).all()
                    argmax = int(np.argmax(values))
                    assert (
                        row["sampled_token_ids"] == [argmax]
                        and receipt["cpu_argmax"] == argmax
                    )
                    top = np.argsort(values, kind="stable")[-8:][::-1]
                    assert (
                        receipt["top_token_ids"] == top.tolist()
                        and receipt["top_values"] == values[top].tolist()
                    )
                    targets[position] = {
                        **original,
                        "values": values,
                        "receipt": receipt,
                        "source_path": str(vector_path),
                    }
    assert installed == {(rank, lane) for rank in range(4) for lane in lanes}
    assert all(set(c) == set(range(1, 209)) for c in contexts.values())
    assert all(c == contexts[0] for c in contexts.values())
    assert set(targets) == set(range(1, 209)) and len(extra_paths) == 198
    assert {p for p in extra.rglob("*") if p.is_file()} == extra_paths
    assert len(list(regular.glob("*.npy"))) == 80
    assert sum(targets[p]["values"].nbytes for p in range(2, 200)) == 196669440
    return targets, {
        "extra_vectors": 198,
        "ordinary_target_endpoints": 10,
        "all208_cpu_argmax_matches_native": True,
        "four_rank_actual_context_agreement": True,
        "original_ordinary_vector_files": 80,
        "union_clone_events": clone_counts,
        "profile_sha256": profile_sha,
    }


def verify(analysis):
    new = {
        role: BUNDLE / "runs-v1" / f"{role}-target-early-logits-observed-v1-01"
        for role in ("native", "prefix")
    }
    controllers = {role: terminal(path) for role, path in new.items()}
    # All controller terminals are checked before reading any child or NPY.
    primary = json.loads(analysis.read_text())
    assert primary["schema"] == "muxpd-target-early-logits-analysis-v1"
    assert primary["passed"] is True and primary["localization_allowed"] is True
    freeze_path = BUNDLE / "freeze-manifest-v1.json"
    assert (
        sha(freeze_path)
        == "36481b575815f7aa7591a99ee52899573750a93614f475b6e2dd05a166937066"
    )
    frozen = json.loads(freeze_path.read_text())
    files = frozen["files"]
    assert (
        len(files) == 25
        and json_sha(files)
        == "05055894d29f6d4e970f44cde127d24301e71f105e98c1ed3ff080ffa3f04bf1"
    )
    for name, digest in files.items():
        assert sha(BUNDLE / name) == digest
        for role, path in new.items():
            assert controllers[role]["files"] == files
            assert controllers[role]["freeze_manifest_sha256"] == sha(freeze_path)
            assert sha(path / "producer" / name) == digest
            assert sha(path / "producer/freeze-manifest-v1.json") == sha(freeze_path)
    references = json.loads((BUNDLE / "control-references-v1.json").read_text())
    observations, vectors, prefixes, targets, extra_checks = {}, {}, {}, {}, {}
    for role, path in new.items():
        control = Path(references["attempts"][role + "-observed"]["directory"])
        terminal(control)
        current, old = core.load_attempt(path), core.load_attempt(control)
        assert current["public"]["included_in_numerical_comparisons"]
        assert old["public"]["included_in_numerical_comparisons"]
        observations[role] = current
        plan = current["report"]["plan"]
        for field in ("plan", "sources", "launch_config"):
            assert current["report"][field] == old["report"][field]
        expected = {
            (case["case_id"], position - 1)
            for case in plan["cases"]
            for position in plan["capture_token_indices_one_based"]
        }
        assert len(expected) == 80
        for value in (current, old):
            assert {
                k for k, v in value["decisions"].items() if v["receipt"]
            } == expected
        vectors[role] = []
        for case, index in sorted(expected):
            a, b = [v["decisions"][(case, index)] for v in (current, old)]
            x, y = [
                array(
                    p / "results/worker-observations" / v["receipt"]["file"],
                    v["receipt"],
                    [plan["expected_vocabulary_size"]],
                )
                for p, v in zip((path, control), (a, b))
            ]
            assert x.tobytes() == y.tobytes()
            assert a["semantic_batch"] == b["semantic_batch"]
            assert a["batch_descriptor"] is not None
            assert a["batch_descriptor"] == b["batch_descriptor"]
            for field in (
                "prompt_token_ids",
                "output_prefix_token_ids",
                "sampled_token_ids",
            ):
                assert a["row"][field] == b["row"][field]
            vectors[role].append(
                {
                    "case_id": case,
                    "position_one_based": index + 1,
                    "sha256": a["receipt"]["sha256"],
                }
            )
        assert set(current["prefixes"]) == set(old["prefixes"])
        prefixes[role] = {}
        for case, value in current["prefixes"].items():
            assert (
                value["output_token_ids"] == old["prefixes"][case]["output_token_ids"]
            )
            prefixes[role][case] = len(value["output_token_ids"])
        targets[role], extra_checks[role] = load_targets(current, files)
    bplain = Path(references["attempts"]["b-plain"]["directory"])
    terminal(bplain)
    bp = json.loads((bplain / "results/run.json").read_text())["prefixes_before_abort"]
    assert all(
        v["output_token_ids"] == bp[k]["output_token_ids"]
        for k, v in observations["prefix"]["prefixes"].items()
    )
    primary_rows = {
        r["position_one_based"]: r for r in primary["target_comparison"]["positions"]
    }
    assert set(primary_rows) == set(range(1, 209))
    compared = []
    for position in range(1, 209):
        a, b = targets["native"][position], targets["prefix"][position]
        x, y = a["values"], b["values"]
        same = own_input(a) == own_input(b)
        byte_equal = x.tobytes(order="C") == y.tobytes(order="C")
        numeric_equal = bool(np.array_equal(x, y))
        own_prefix = (
            a["row"]["prompt_token_ids"] == b["row"]["prompt_token_ids"]
            and a["row"]["output_prefix_token_ids"]
            == b["row"]["output_prefix_token_ids"]
        )
        batch_equal = a["semantic_batch"] == b["semantic_batch"]
        descriptor_equal = (
            a["batch_descriptor"] is not None
            and a["batch_descriptor"] == b["batch_descriptor"]
        )
        metrics = {
            "position_one_based": position,
            "same_actual_target_input": same,
            "same_target_prompt_and_prefix": own_prefix,
            "same_entire_semantic_batch": batch_equal,
            "same_padded_graph_descriptor": descriptor_equal,
            "strict_full_context_match": own_prefix
            and batch_equal
            and descriptor_equal,
            "canonical_value_bytes_equal": byte_equal,
            "sampled_token_equal": a["row"]["sampled_token_ids"]
            == b["row"]["sampled_token_ids"],
            "left_sampled_token_ids": a["row"]["sampled_token_ids"],
            "right_sampled_token_ids": b["row"]["sampled_token_ids"],
            "left_source_sha256": a["receipt"]["sha256"],
            "right_source_sha256": b["receipt"]["sha256"],
            "logits_distances_computed": same,
            "unequal_entries": None,
            "max_abs_delta": None,
            "rms_delta": None,
        }
        if same:
            unequal = np.flatnonzero(x != y)
            delta = x.astype(np.float64) - y.astype(np.float64)
            metrics.update(
                unequal_entries=int(unequal.size),
                first_unequal_token_id=int(unequal[0]) if unequal.size else None,
                max_abs_delta=float(np.max(np.abs(delta))),
                rms_delta=float(np.sqrt(np.mean(delta * delta))),
            )
        for field, value in metrics.items():
            assert primary_rows[position][field] == value, (position, field)
        compared.append(
            {
                **metrics,
                "raw_numeric_equal_any_history": numeric_equal,
                "left_path": a["source_path"],
                "right_path": b["source_path"],
            }
        )
    first_numeric = next(
        (
            r["position_one_based"]
            for r in compared
            if r["same_actual_target_input"] and not r["raw_numeric_equal_any_history"]
        ),
        None,
    )
    first_byte = next(
        (
            r["position_one_based"]
            for r in compared
            if r["same_actual_target_input"] and not r["canonical_value_bytes_equal"]
        ),
        None,
    )
    summary = {
        "first_same_input_numeric_difference": first_numeric,
        "first_same_input_byte_difference": first_byte,
        "first_observed_byte_difference_any_history": next(
            (
                r["position_one_based"]
                for r in compared
                if not r["canonical_value_bytes_equal"]
            ),
            None,
        ),
        "first_sampled_token_difference": next(
            (r["position_one_based"] for r in compared if not r["sampled_token_equal"]),
            None,
        ),
        "same_input_numeric_equal_after_first_difference": [
            r["position_one_based"]
            for r in compared
            if first_numeric is not None
            and r["position_one_based"] > first_numeric
            and r["same_actual_target_input"]
            and r["raw_numeric_equal_any_history"]
        ],
        "same_input_byte_equal_after_first_difference": [
            r["position_one_based"]
            for r in compared
            if first_byte is not None
            and r["position_one_based"] > first_byte
            and r["same_actual_target_input"]
            and r["canonical_value_bytes_equal"]
        ],
    }
    for field, value in summary.items():
        assert primary["target_comparison"][field] == value, field
    return {
        "passed": True,
        "script_sha256": sha(Path(__file__)),
        "primary_analysis": {"path": str(analysis), "sha256": sha(analysis)},
        "freeze_manifest_sha256": sha(freeze_path),
        "canonical_files_sha256": json_sha(files),
        "current_children": {
            role: sha(path / "results/run.json") for role, path in new.items()
        },
        "current_controller_terminals": {
            role: value["finished_at"] for role, value in controllers.items()
        },
        "full_vocabulary_control_vectors": vectors,
        "full_prefix_lengths": prefixes,
        "b_plain_prefix_equal": True,
        "extra_capture_checks": extra_checks,
        "target_comparison_summary": summary,
        "target_vector_pairs": compared,
        "all208_target_vector_pairs_numeric_equal": all(
            r["raw_numeric_equal_any_history"] for r in compared
        ),
        "all208_target_vector_pairs_canonical_bytes_equal": all(
            r["canonical_value_bytes_equal"] for r in compared
        ),
        "scope": "Independent actual198-extra plus10-endpoint vector reads per role, argmax/context/source/control checks, and all208 per-position agreement with primary. Unmatched histories carry descriptive raw equality only, no same-input distance or operator attribution. No answer repair or performance qualification.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), "Preserve previous output"
    result = verify(args.analysis)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "passed": True,
                "output": str(args.output),
                "sha256": sha(args.output),
                "first_same_input_numeric_difference": result[
                    "target_comparison_summary"
                ]["first_same_input_numeric_difference"],
            }
        )
    )
