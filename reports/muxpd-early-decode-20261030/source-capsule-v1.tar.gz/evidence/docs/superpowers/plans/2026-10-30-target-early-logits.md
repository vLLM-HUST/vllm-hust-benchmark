# Target early decode logits implementation plan

> **For agentic workers:** Use superpowers:subagent-driven-development. Implement the observer and host analysis independently, then integrate and review before root freeze/device execution.

**Goal:** Identify the first full-logit difference for07338 after its qualified equal first-P hidden outputs and persistent states, without assuming token2 is already different.

**Architecture:** Preserve the original80-vector observer window and eight saved-prefix controls. Add a separate exact-target selector for output positions2–199 to the existing sampler observation path, reusing one original greedy call and one post-greedy full-batch clone. Store only the additional target rows in a separate directory/receipt field, so the original control loader remains byte-identical. No state hooks, graph taps, replay or numerical intervention.

**Tech stack:** Python, NumPy, installed vLLM/Ascend native sampler, CPU pytest, root-owned TP4 processes.

**Spec:** `/root/workspace/muxpd-target-prefill-next-20261030/first-target-d-boundary-v1.md` and the qualified state primary/independent results in `/root/workspace/muxpd-target-prefill-state-20261030`.

## Global constraints

- Work only in new isolated `/root/workspace/muxpd-target-early-logits-20261030`; frozen predecessors remain unchanged.
- Same original batch7 plan, prompts/order/admission, target208 cutoff, seed/native209 and prefix218 retained lengths, engine arguments, q4 policy, numeric math, sources and environment.
- Native then prefix, one declared attempt per role; physical3/4/5/6 subject to fresh root inventory. Root alone owns NPU/model lifecycle and GitHub.
- Keep original capture window `[1,200,201,202,203,204,205,206,207,208]`, its128-position validation limit and exactly80 ordinary NPYs unchanged.
- Additional selector: target prompt SHA `5d42eef6c9648f1d229e6cb6614fc93ef886342cb709be3af5b9f84a7bc483f1`, original1340 prompt tokens, output positions2–199 inclusive, rank0 only. Bind it to the original frozen plan and exact sidecar bytes.
- Extra payload198×248320×4=196,669,440 bytes/role. Existing sampler casts to FP32 before greedy; actual full8-row clone is7,946,240 bytes, not BF16 entry size. Preserve original post-greedy clone and post-bookkeeping D2H order; retain no simultaneous history on device.
- Extra files belong to `results/target-extra-logits`; existing event rows use separate `extra_logits` receipts. Ordinary `row.logits` and `results/worker-observations/*.npy` remain the old80 set.
- Full200 quality remains FAIL/NOT_TESTED here. No candidate or performance result follows from these observations.

## Review focus

- Never widen the selector to seven peers or duplicate a clone when an ordinary vector and extra target coincide in one batch.
- Tie each extra row to actual full prompt, output-prefix, sampled token, computed count, row and complete co-batch context; reject wrong target/off-by-one/duplicate/missing positions.
- Capture actual greedy-input dtype/shape/budget; `_sample` BF16 metadata is not the clone dtype. No extra greedy/model/collective invocation.
- Keep the original old80 loader and control functions byte-identical; files or receipts outside their declared sets must still be rejected.
- Compare logits only with explicit same-target-prefix/input context. Numeric divergence can precede token divergence and can reconverge; examine every position rather than binary-searching an assumed monotone property.

## Task1: Target-only observer extension (peer_p_helper)

**Files:** new bundle `window_numeric_diagnostics_v1.py`, `target-capture-profile-v1.json`, focused observer tests and literal-source proof/diff. Keep `window_numeric_workers_v1.py` unchanged unless an explicit integration necessity is reviewed first.

**Interface:** existing observer/RPC signatures remain. A new validated sidecar describes the198 target positions. `observer-installed` may add a profile identity receipt; existing required fields stay exact. Each selected rank0 target row records `extra_logits` with file basename, size/SHA, shape/dtype, one-based position and original clone receipt; file resolution is exclusively under the extra directory. Agree exact fields with harness before finalizing.

- [ ] Write and observe failing tests for wrong prompt/position/rank, unchanged old128 validator, regular+extra single-clone behavior, non-FP32 or over-budget clone, duplicate/missing extra exports and original call/return/bookkeeping order.
- [ ] Extend only clone selection and extra export. Do not replace or repeat greedy, mutate logits or sampled tokens, install graph hooks, change input batches or synchronize before original bookkeeping.
- [ ] Keep the original ordinary-vector serialization code and all unrelated functions byte-identical; prove the narrow changed portions explicitly. Record actual dtype and byte budget at capture.
- [ ] Run relevant CPU tests, including both real native/prefix sampler metadata fixtures. Stop source changes for integration review.

## Task2: Host/controller/early-logit analysis (peer_p_harness)

**Files:** new `probe_run_v1.py`, `probe_control_v1.py`, `analyze_early_logits_v1.py`, extra-receipt loader/tests, source/reference manifests and exact matrix. Copy original numeric workers, original plan, engine arguments, source adapters and control loader byte-for-byte.

- [ ] Start from the qualified driver; remove state-observer-only installation/snapshot/restore blocks. Prove original admission/step loops and normal model/sampler behavior unchanged.
- [ ] Write red tests using actual terminal old80/all8 controls and malformed extra receipts. Keep the original control loader literal bytes; verify extra files are disjoint from its original80 set.
- [ ] Validate exactly198 extra target vectors/rank0 per role, no other-rank/non-target extras, every raw file SHA/shape/finite/argmax, and four-rank decision agreement. Bind contexts to actual event rows/admissions rather than inferred global step numbers.
- [ ] Assemble target positions1–208 from the old10 target vectors plus198 extras. Report every per-position metric, first byte/numeric difference, sampled-token difference, own-input agreement and co-batch differences. Do not attribute post-token-divergence distances to same input.
- [ ] Require old80 full vectors/all8 saved prefixes per role and prefix B-plain bridge before numerical attribution. Preserve all old failed-attempt lineage and qualified state evidence as exact external references.
- [ ] Build the frozen-input list, two-role one-attempt matrix and dry-runs. Run integrated CPU tests using real helper serialization, not only hand-made receipt dictionaries.

## Task3: Review, run, interpret

- [ ] Independent review checks source/call order, all old80 loader bytes, sidecar/selector bounds, exact matrix and real fixtures. Root performs fresh source/idle preflight and immutable freeze.
- [ ] Root runs native once, proves terminal, analyzes old controls plus extra completeness. Prefix starts only after native qualification; prove terminal before reading its child/log/tensors.
- [ ] Primary and independent analyses reread actual full vectors. Keep failures and corrections explicit; no selected retry or frozen edit.
- [ ] Use the first measured same-input numerical difference to select a minimal D operator/graph boundary or a single-variable scheduling counterfactual. Existing source shows D uses the original communicator, not a separate decode sibling. No more P-state survey is justified by the current equal-state result.
