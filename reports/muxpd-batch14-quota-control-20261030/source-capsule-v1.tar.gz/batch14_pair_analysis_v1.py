"""Natural original-batch14 q4/q40 diagnostic; no candidate acceptance."""

import json
from collections import Counter
from pathlib import Path

import batch14_treatment_v1 as treatment
import candidate_checks_v1 as checks
import candidate_quality_analysis_v2 as legacy
import score_quality as original

require, read, sha = legacy.require, legacy.read, legacy.sha


def validate_schedule(report, receipts, batch, cases, arm):
    quota = treatment.treatment_receipt(arm)["layers_per_slice"]
    rounds = 40 // quota
    require(
        batch["batch_id"] == 14 and batch["case_ids"] == treatment.CASE_IDS,
        "Original batch14 differs",
    )
    require(
        len(receipts) % 2 == 0 and len(receipts) // 2 == report["answer_engine_steps"],
        "Unpaired serving records",
    )
    pairs = list(zip(receipts[::2], receipts[1::2], strict=True))
    require(
        len(pairs) > rounds + 1
        and [s["global_step"] for s, _ in pairs] == list(range(1, len(pairs) + 1)),
        "Fresh serving steps incomplete/reordered",
    )
    admissions = report["admissions"]
    require(len(admissions) == 2, "Exactly seed and peer admission required")
    seed, peers = admissions
    require(
        seed["batch_id"] == peers["batch_id"] == 14
        and seed["stage"] == "seed"
        and peers["stage"] == "peers"
        and seed["global_step"] == 0
        and peers["global_step"] == 1
        and peers["seed_output_tokens"] == 1
        and peers["seed_still_live"] is True
        and [b["case_id"] for b in seed["bindings"]] == batch["case_ids"][:1]
        and [b["case_id"] for b in peers["bindings"]] == batch["case_ids"][1:],
        "Original live-seed first-token ingress differs",
    )
    ids = {b["case_id"]: b["internal"] for a in admissions for b in a["bindings"]}
    require(len(set(ids.values())) == 8, "Duplicate request identities")
    by_case = {c["case_id"]: c for c in cases}
    by_id = {ids[c]: by_case[c] for c in ids}
    seed_id = ids[batch["case_ids"][0]]
    peer_ids = set(ids.values()) - {seed_id}
    previous = set()
    decode_sizes = []
    completed = []
    retirements = Counter()
    for ordinal, (s, r) in enumerate(pairs):
        p = {seed_id} if ordinal == 0 else peer_ids if ordinal <= rounds else set()
        new = p if ordinal in (0, 1) else set()
        before = 0 if ordinal in (0, 1) or ordinal > rounds else (ordinal - 1) * quota
        after = 40 if ordinal == 0 else ordinal * quota if ordinal <= rounds else 0
        ack = p if ordinal in (0, rounds) else set()
        d = {rid for rid, phase in s["phases_before"].items() if phase == "D"}
        require(
            s["event"] == "schedule"
            and r["event"] == "retirement"
            and s["batch_id"] == r["batch_id"] == 14
            and s["global_step"] == r["global_step"]
            and set(s["phases_before"]) <= set(ids.values())
            and set(s["phases_before"].values()) <= {"P", "D"}
            and {rid for rid, phase in s["phases_before"].items() if phase == "P"} == p
            and (
                not d
                if ordinal == 0
                else d == {seed_id}
                if ordinal <= rounds
                else bool(d) and d <= previous
            ),
            "Actual pending P/D population differs",
        )
        expected = {
            rid: len(by_id[rid]["prompt_token_ids"]) for rid in new
        } | dict.fromkeys(d, 1)
        require(
            s["scheduled_tokens"] == expected
            and set(s["new_prefill_ids"]) == new
            and len(s["new_prefill_ids"]) == len(new)
            and set(s["pending_prefill_ids"]) == p
            and len(s["pending_prefill_ids"]) == len(p)
            and s["prefill_layers_before"] == before
            and not s["preempted_req_ids"],
            "Actual scheduled/new/pending prompt progression differs",
        )
        require(
            set(r["completed_prefill_ids"]) == ack
            and len(r["completed_prefill_ids"]) == len(ack)
            and not r["cancelled_prefill_ids"]
            and r["prefill_layers_completed"] == after
            and r["actual_prefill_progress"] is bool(p)
            and r["mixed_pd_progress_and_retirement"] is bool(p and d)
            and r["native_mixed_scheduled_and_decode_retired"] is False
            and set(r["decode_retired_ids"]) == d
            and len(r["decode_retired_ids"]) == len(d),
            "Actual layer progress/final ACK/D retirement differs",
        )
        if 1 <= ordinal <= rounds:
            completed.append(r["prefill_layers_completed"])
        if d:
            decode_sizes.append(len(d))
            retirements.update(d)
        previous = p | d
    descriptors = Counter(
        next(n for n in (1, 2, 4, 8) if n >= size) for size in decode_sizes
    )
    return {
        "passed": True,
        "arm": arm,
        "quota": quota,
        "serving_steps": len(pairs),
        "decode_turns": len(decode_sizes),
        "prefill_model_forwards": 2,
        "seed_prefill_advancements": 1,
        "seed_completed_layers": 40,
        "peer_prefill_advancements": rounds,
        "peer_completed_layers": completed,
        "peer_ack_advancement": rounds,
        "mixed_progress_steps": rounds,
        "actual_decode_batch_size_histogram": dict(
            sorted(Counter(decode_sizes).items())
        ),
        "schedule_derived_descriptor_histogram": dict(sorted(descriptors.items())),
        "descriptor_scope": "Expected padding from actual scheduled D counts under frozen [1,2,4,8]; not an independently observed per-replay descriptor trace.",
        "per_case_decode_retirements": {
            case: retirements[rid] for case, rid in ids.items()
        },
    }


REFS_SHA = "d4f165c07b3d3e8803a6469937ab972ec1c71980363cb1d7bc17b2af487a2d3f"


def verify_references(bundle):
    bundle = Path(bundle)
    path = bundle / "batch14-pair-references-v1.json"
    require(sha(path) == REFS_SHA, "Frozen batch14 references changed")
    refs = read(path)
    require(
        refs["schema"] == "muxpd-batch14-natural-pair-references-v1"
        and refs["status"]
        == "qualified-external32-port-equality-with-builtin-quality-failure"
        and refs["full200_allowed"] is False,
        "Reference diagnostic role differs",
    )
    # Both modern reference controllers, then all historical controllers,
    # are validated before any reference child/log read.
    builtin_controller = legacy.terminal_controller(refs["builtin_q40_directory"])
    external_controller = legacy.terminal_controller(refs["external_directory"])
    _, histories, historical_proof = legacy.verify_histories(bundle)
    require(
        sha(refs["source_reference_identity"]["path"])
        == refs["source_reference_identity"]["sha256"]
        == treatment.SOURCE_REFERENCE_SHA,
        "Actual source-reference identity changed",
    )
    for item in refs["documents"].values():
        require(sha(item["path"]) == item["sha256"], "Reference document changed")
    for path, digest in refs["files"].items():
        require(sha(path) == digest, "Reference source/raw file changed: " + path)
    primary = read(refs["documents"]["external_primary"]["path"])
    independent = read(refs["documents"]["external_independent"]["path"])
    builtin = read(refs["documents"]["builtin_primary"]["path"])
    builtin_audit = read(refs["documents"]["builtin_independent"]["path"])
    require(
        primary["passed"] is True
        and primary["runtime_collection_qualified"] is True
        and primary["port_equivalence_passed"] is True
        and primary["comparison"]["complete_outputs"]["all_32_equal"] is True
        and primary["comparison"]["schedule"]["equal"] is True
        and all(
            row["equal"]
            for row in primary["comparison"]["per_rank_collective_geometry"]
        )
        and primary["comparison"]["answers"]["all_scores_equal"] is True,
        "Actual external32 equality prerequisite failed",
    )
    require(
        independent["passed"] is True
        and independent["collection_checks_passed"] is True
        and independent["port_equivalence_passed"] is True
        and independent["errors"] == []
        and independent["answer_quality_accepted"] is False
        and independent["full_quality_gate_attempted"] is False,
        "Independent external32 prerequisite failed",
    )
    require(
        builtin["passed"] is True
        and builtin["runtime_collection_qualified"] is True
        and builtin_audit["passed"] is True
        and builtin["answer_results"]["posterior32"]["relative_no_new_wrong"]
        == {
            "passed": False,
            "case_ids": ["mmlu-pro-01741"],
            "scope": "Posterior32 only",
        }
        and primary["comparison"]["answers"][
            "external_new_wrong_on_both_native_correct"
        ]
        == ["mmlu-pro-01741"],
        "Known builtin q40 quality failure must remain visible",
    )
    require(
        builtin["full_quality_gate_attempted"] is False
        and primary["full_quality_gate_attempted"] is False
        and primary["full_frozen_plan_passed"] is None,
        "No full200 authorization may be inferred",
    )
    require(
        read(refs["documents"]["external_root_terminal"]["path"])["controller_sha256"]
        == sha(Path(refs["external_directory"]) / "controller.json")
        and external_controller["terminal_assessment"]["child_sha256"]
        == primary["qualification"]["child_sha256"]
        and builtin_controller["terminal_assessment"]["child_sha256"]
        == builtin_audit["child_sha256"],
        "Reference terminal/child linkage changed",
    )
    require(
        Path(refs["historical_q4_directory"]).resolve()
        == Path(
            read(bundle / "candidate-quality-references-v1.json")["historical_runs"][
                "prefix"
            ]["directory"]
        ).resolve()
        and len(histories["prefix"]["outputs"]) == 200,
        "Original historical q4 source changed",
    )
    return refs, {
        "passed": True,
        "references_sha256": REFS_SHA,
        "external32_port_equivalence_passed": True,
        "external_primary_sha256": refs["documents"]["external_primary"]["sha256"],
        "external_independent_sha256": refs["documents"]["external_independent"][
            "sha256"
        ],
        "builtin_relative_no_new_wrong_passed": False,
        "builtin_new_wrong": ["mmlu-pro-01741"],
        "historical_strict_gate_passed": historical_proof[
            "historical_strict_gate_passed"
        ],
        "full200_allowed": False,
    }


def compare_eight(left, right):
    indexed = []
    for report in (left, right):
        require(
            len(report["outputs"]) == 8
            and {row["case_id"] for row in report["outputs"]}
            == set(treatment.CASE_IDS),
            "Exactly original8 complete outputs required",
        )
        indexed.append({row["case_id"]: row for row in report["outputs"]})
    rows = []
    for case in treatment.CASE_IDS:
        a, b = [r[case] for r in indexed]
        difference = None
        for index, (x, y) in enumerate(zip(a["token_ids"], b["token_ids"]), 1):
            if x != y:
                difference = {
                    "position_one_based": index,
                    "kind": "token",
                    "left": x,
                    "right": y,
                }
                break
        if difference is None and len(a["token_ids"]) != len(b["token_ids"]):
            index = min(len(a["token_ids"]), len(b["token_ids"]))
            difference = {
                "position_one_based": index + 1,
                "kind": "length",
                "left": a["token_ids"][index] if index < len(a["token_ids"]) else None,
                "right": b["token_ids"][index] if index < len(b["token_ids"]) else None,
            }
        fields = {
            key: a.get(key) == b.get(key)
            for key in ("text", "finish_reason", "stop_reason", "finished", "error")
        }
        rows.append(
            {
                "case_id": case,
                "equal": difference is None and all(fields.values()),
                "first_difference": difference,
                "left_tokens": len(a["token_ids"]),
                "right_tokens": len(b["token_ids"]),
                "left_finish": a["finish_reason"],
                "right_finish": b["finish_reason"],
                "field_equality": fields,
            }
        )
    return {
        "all8_equal": all(row["equal"] for row in rows),
        "rows": rows,
        "different_case_ids": [row["case_id"] for row in rows if not row["equal"]],
    }


def historical_report(refs, arm):
    directory = Path(
        refs["historical_q4_directory"]
        if arm == "q4"
        else refs["builtin_q40_directory"]
    )
    value = read(directory / "results/run.json")
    return {
        **value,
        "outputs": [
            row for row in value["outputs"] if row["case_id"] in treatment.CASE_IDS
        ],
    }


def audit_arm(
    directory, arm, bundle, controller, freeze, source, identity, refs, reference_proof
):
    import batch14_pair_control_v1 as control
    import run_quality
    from probe_control_v1 import inventory
    from probe_run_v1 import require_empty, require_empty_worker, tokenizer_identities

    directory, bundle = Path(directory), Path(bundle)
    declaration = freeze["declared_attempts"][arm]
    require(
        directory.resolve() == Path(declaration["directory"]).resolve()
        and directory.name
        == declaration["label"]
        == controller["label"]
        == treatment.LABELS[arm],
        "Arm outside frozen unique declaration",
    )
    require(
        controller["schema"] == "muxpd-q4-q40-batch14-controller-v1"
        and controller["scope"] == "batch14"
        and controller["arm"] == arm
        and controller["profile"] == "builtin-batch14-quota-diagnostic"
        and controller["bundle_frozen"] is True
        and controller["source_preflight"] == source
        and controller["references_qualification"] == reference_proof
        and controller["arm_treatment"] == treatment.treatment_receipt(arm, bundle),
        "Controller/source/arm/reference differs",
    )
    require(
        len(control.FILES) == len(set(control.FILES)) == 30,
        "Exactly30 unique producer files required",
    )
    actual = {name: sha(directory / "producer" / name) for name in control.FILES}
    require(
        actual
        == controller["files"]
        == freeze["files"]
        == {name: sha(bundle / name) for name in control.FILES},
        "Exact archived producer map changed",
    )
    require(
        sha(directory / "producer/freeze-manifest-v1.json")
        == controller["freeze_manifest_sha256"]
        == sha(bundle / "freeze-manifest-v1.json")
        and sha(directory / "producer/source-reference-identity-v1.json")
        == controller["source_reference_identity_sha256"]
        == treatment.SOURCE_REFERENCE_SHA,
        "Frozen source reference differs",
    )
    terminal = control.terminal_assessment(directory, controller)
    require(
        terminal == controller["terminal_assessment"],
        "Saved terminal assessment differs from actual child/log",
    )
    report = read(directory / "results/run.json")
    for when in ("before", "after"):
        require(
            inventory((directory / f"npu-{when}.txt").read_text())
            == controller["expected_physical"]
            == ["3", "4", "5", "6"],
            "Saved physical idle proof changed",
        )
    plan, cases, _ = original.load_frozen(bundle / "frozen-v2")
    batches = treatment.select_batches(plan, "batch14")
    require(
        report["schema"] == "muxpd-q4-q40-batch14-run-v1"
        and report["role"] == "raw"
        and report["profile"] == controller["profile"]
        and report["scope"] == "batch14"
        and report["arm"] == arm
        and report["arm_treatment"] == controller["arm_treatment"]
        and report["layout_mode"] == "prefix"
        and report["plan_sha256"] == checks.PLAN_SHA
        and report["selected_batch_ids"] == controller["selected_batch_ids"] == [14]
        and report["selected_case_ids"] == treatment.CASE_IDS
        and controller["selected_case_count"] == 8
        and not report.get("failure_cleanup")
        and not report["terminal_maintenance"]["aborted_internal_ids"],
        "Actual original8 diagnostic scope/lifecycle differs",
    )
    for field, name in {
        "producer_sha256": "batch14_pair_run_v1.py",
        "original_producer_sha256": "run_quality.py",
        "original_scorer_sha256": "score_quality.py",
        "source_manifest_sha256": "source-manifest-v1.json",
    }.items():
        require(report[field] == actual[name], "Child producer/scorer identity differs")
    require(
        report["layout_module_sha256"]
        == identity["runtime_files"]["src/vllm_muxpd/prefill_collective_layout.py"]
        and report["sources"] == source["sources"]
        and report["source_reference_identity"]
        == report["source_after_startup"]
        == report["sources_after_shutdown"]
        == source
        and "candidate_identity" not in report,
        "Actual builtin/source diagnostic identity differs",
    )
    raw = checks.original_manifest(bundle)["historical_runs"][
        "raw-quality-v2-hccl-true-01"
    ]["engine_args"]
    base = run_quality.validate("raw", read(bundle / "raw-engine-args-v1.json"), plan)
    launch = treatment.apply_arm_config(base, identity, arm)
    resolved = treatment.apply_arm_config(raw, identity, arm)
    require(
        report["base_engine_args"] == controller["launch_engine_args"] == launch
        and report["engine_args"] == resolved
        and report["effective"] == {k: resolved[k] for k in report["effective"]}
        and report["scheduler_class"] == resolved["scheduler_cls"]
        and report["engine_coordinator"] == "InprocClient",
        "Exact arm config differs beyond declared quota",
    )
    baseline = read(Path(refs["builtin_q40_directory"]) / "results/run.json")
    checks.validate_environment(
        report["runtime_environment"], baseline["runtime_environment"], identity
    )
    require(
        report["runtime_environment"] == baseline["runtime_environment"]
        and report["tokenizer_files"] == tokenizer_identities(plan),
        "Actual environment/tokenizer differs",
    )
    model = identity["model_config_identity"]
    require(
        sha(model["path"]) == model["sha256"]
        and report["model_config_before_startup"]
        == report["model_config_after_startup"]
        == model,
        "Actual model constructor receipt differs",
    )
    for when in ("worker_before", "worker_after"):
        treatment.validate_arm_workers(report[when], identity, arm)
        for row in report[when]:
            require_empty_worker(row)
    require(
        report["prefix_initial"]
        == [r["builtin_layout"] for r in report["worker_before"]]
        and report["prefix_final"]
        == [r["builtin_layout"] for r in report["worker_after"]],
        "Builtin snapshots differ from actual workers",
    )
    require_empty(report["final_state"], report["idle_baseline"])
    history = directory / "results/scheduler-receipts.jsonl"
    require(
        sha(history) == report["scheduler_receipts_sha256"],
        "Raw scheduler history changed",
    )
    receipts = [json.loads(line) for line in history.read_text().splitlines()]
    prefix = legacy.replay_prefixes(
        report, directory / "results", batches, cases, receipts
    )
    schedule = validate_schedule(report, receipts, batches[0], cases, arm)
    graph = legacy.validate_graphs(
        report, schedule["decode_turns"], schedule["prefill_model_forwards"]
    )
    mixed = original.verify_mixed_coverage(
        directory / "results/run.json", report, {**plan, "batches": batches}
    )
    require(
        mixed["passed"]
        and {int(k): v for k, v in report["mixed_coverage"]["steps_per_batch"].items()}
        == {14: schedule["mixed_progress_steps"]},
        "Actual quota-specific mixed progression differs",
    )
    outputs = legacy.validate_outputs(report, treatment.CASE_IDS, plan)
    outputs["admission_and_retirement_link"] = validate_output_retirement_link(
        report, schedule
    )
    require(
        report["warmup"]
        == "Existing LLM constructor warmup only; zero extra request warmups.",
        "Additional request warmup not allowed",
    )
    return {
        "directory": str(directory.resolve()),
        "controller": controller,
        "report": report,
        "receipts": receipts,
        "qualification": {
            "passed": True,
            "arm": arm,
            "controller_sha256": sha(directory / "controller.json"),
            "child_sha256": sha(directory / "results/run.json"),
            "terminal": terminal,
            "schedule": schedule,
            "graph": graph,
            "prefix": prefix,
            "mixed": mixed,
            "outputs": outputs,
            "model_config_constructor_receipts": model,
        },
    }


def qualify_arms(declared, bundle):
    from datetime import datetime
    from types import SimpleNamespace

    import batch14_pair_control_v1 as control

    bundle = Path(bundle)
    require(
        declared
        and len({arm for arm, _ in declared}) == len(declared)
        and all(arm in treatment.ARMS for arm, _ in declared),
        "Distinct declared arms required",
    )
    # Pair mode checks both terminal controllers before any arm child/log read.
    # Single q4 mode never opens or requires a future q40 attempt.
    controllers = {
        arm: legacy.terminal_controller(directory) for arm, directory in declared
    }
    freeze = read(bundle / "freeze-manifest-v1.json")
    require(
        freeze["status"] == "frozen"
        and set(freeze["declared_attempts"]) == set(treatment.ARMS)
        and freeze["source_reference_identity_sha256"]
        == treatment.SOURCE_REFERENCE_SHA,
        "Concrete two-arm freeze required",
    )
    if "q40" in controllers and "q4" not in controllers:
        controllers["q4"] = legacy.terminal_controller(
            freeze["declared_attempts"]["q4"]["directory"]
        )
    refs, reference_proof = verify_references(bundle)
    identity = read(bundle / "source-reference-identity-v1.json")
    require(
        sha(bundle / "source-reference-identity-v1.json")
        == treatment.SOURCE_REFERENCE_SHA,
        "Source reference bytes changed",
    )
    source = checks.source_guard(Path(identity["source_root"]), identity, bundle)
    values = {
        arm: audit_arm(
            directory,
            arm,
            bundle,
            controllers[arm],
            freeze,
            source,
            identity,
            refs,
            reference_proof,
        )
        for arm, directory in declared
    }
    chronology = None
    if "q4" in values:
        require(
            controllers["q4"]["predecessor_qualification"] is None,
            "q4 must be the first declared fresh arm",
        )
    if "q40" in values:
        value = values["q40"]
        directory = Path(value["directory"])
        predecessor = control.predecessor_gate(
            SimpleNamespace(arm="q40", output_root=directory.parent, command="run"),
            sha(bundle / "freeze-manifest-v1.json"),
        )
        require(
            value["controller"]["predecessor_qualification"] == predecessor,
            "Actual q4 predecessor proof changed",
        )
        prior = (
            values["q4"]["report"]
            if "q4" in values
            else read(
                Path(freeze["declared_attempts"]["q4"]["directory"])
                / "results/run.json"
            )
        )
        a, b = controllers["q4"], controllers["q40"]
        require(
            datetime.fromisoformat(b["started_at"])
            > datetime.fromisoformat(a["finished_at"])
            and a["controller_pid"] != b["controller_pid"]
            and a["process_group"] != b["process_group"]
            and prior["process_id"] != value["report"]["process_id"]
            and datetime.fromisoformat(value["report"]["started_at"])
            >= datetime.fromisoformat(b["started_at"]),
            "q40 must be a fresh process after q4 clean terminal",
        )
        chronology = {
            "passed": True,
            "q4_finished_at": a["finished_at"],
            "q40_started_at": b["started_at"],
            "historical_trajectory_equality_required": False,
        }
    return (
        {
            "passed": True,
            "source_reference_identity_sha256": treatment.SOURCE_REFERENCE_SHA,
            "freeze_manifest_sha256": sha(bundle / "freeze-manifest-v1.json"),
            "reference": reference_proof,
            "attempts": {arm: v["qualification"] for arm, v in values.items()},
            "fresh_chronology": chronology,
        },
        values,
        refs,
    )


def semantic_schedule(report, events):
    mapping = {
        b["internal"]: b["case_id"] for a in report["admissions"] for b in a["bindings"]
    }
    require(
        len(mapping) == 8 and set(mapping.values()) == set(treatment.CASE_IDS),
        "Actual complete8 admission mapping missing",
    )
    maps = {"scheduled_tokens", "phases_before"}
    lists = {
        "new_prefill_ids",
        "pending_prefill_ids",
        "preempted_req_ids",
        "completed_prefill_ids",
        "cancelled_prefill_ids",
        "decode_retired_ids",
    }
    result = []
    for event in events:
        row = dict(event)
        for key in maps & row.keys():
            require(set(row[key]) <= mapping.keys(), "Unknown semantic request map")
            row[key] = {mapping[rid]: value for rid, value in row[key].items()}
        for key in lists & row.keys():
            require(set(row[key]) <= mapping.keys(), "Unknown semantic request list")
            row[key] = [mapping[rid] for rid in row[key]]
        result.append(row)
    return result


def assess_values(values, refs, bundle):
    bundle = Path(bundle)
    plan, cases, extract = original.load_frozen(bundle / "frozen-v2")
    subset = [c for c in cases if c["case_id"] in treatment.CASE_IDS]
    arms = {}
    for arm, value in values.items():
        historic = historical_report(refs, arm)
        fresh = original.score(value["report"], plan, subset, extract)
        historical = original.score(historic, plan, subset, extract)
        comparison = compare_eight(historic, value["report"])
        arms[arm] = {
            "historical_trajectory": comparison,
            "fresh_score": fresh,
            "historical_score": historical,
            "scores_equal": fresh == historical,
            "historical_source_directory": refs["historical_q4_directory"]
            if arm == "q4"
            else refs["builtin_q40_directory"],
            "scope": "All8 complete natural outputs; prior full200/q4 or posterior32/q40 history differs from this fresh standalone batch.",
        }
    result = {
        "arms": arms,
        "all_requested_historical_trajectories_reproduced": all(
            v["historical_trajectory"]["all8_equal"] for v in arms.values()
        ),
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "original_scorer_sha256": sha(bundle / "score_quality.py"),
        "canonical_adapter_sha256": sha(bundle / "frozen-v2/canonical-adapter.py"),
    }
    if set(values) == set(treatment.ARMS):
        result["fresh_pair_outputs"] = compare_eight(
            values["q4"]["report"], values["q40"]["report"]
        )
        schedules = [
            semantic_schedule(values[arm]["report"], values[arm]["receipts"])
            for arm in treatment.ARMS
        ]
        first = next(
            (
                {"receipt_index_one_based": i + 1, "q4": a, "q40": b}
                for i, (a, b) in enumerate(zip(*schedules))
                if a != b
            ),
            None,
        )
        if first is None and len(schedules[0]) != len(schedules[1]):
            first = {
                "receipt_index_one_based": min(map(len, schedules)) + 1,
                "kind": "length",
            }
        result["fresh_pair_schedule"] = {
            "equal": first is None,
            "first_difference": first,
            "q4_receipts": len(schedules[0]),
            "q40_receipts": len(schedules[1]),
            "scope": "Original request IDs mapped through actual admission case IDs; quota progress and natural durations are retained as differences.",
        }
    result["interpretation"] = (
        "All requested old trajectories reproduced; a completed two-arm pair can establish a bounded same-source fresh-batch quota contrast, not the first numerical boundary or a faulty kernel."
        if result["all_requested_historical_trajectories_reproduced"]
        else "At least one old complete trajectory was not reproduced; prior-history/source differences remain unresolved. Valid collection and all actual answers are retained."
    )
    return result


def validate_output_retirement_link(report, schedule):
    bindings = {b["case_id"]: b for a in report["admissions"] for b in a["bindings"]}
    outputs = {row["case_id"]: row for row in report["outputs"]}
    require(
        set(bindings) == set(outputs) == set(treatment.CASE_IDS)
        and len(report["outputs"]) == 8
        and len({b["external"] for b in bindings.values()}) == 8,
        "Original8 unique output/admission mapping required",
    )
    rows = []
    for case in treatment.CASE_IDS:
        binding, row = bindings[case], outputs[case]
        require(
            row["request_id"] == binding["external"],
            "Actual output request does not match its admission case",
        )
        retired = schedule["per_case_decode_retirements"][case]
        require(
            len(row["token_ids"]) == 1 + retired,
            "Actual output length differs from one P token plus D retirements",
        )
        rows.append(
            {
                "case_id": case,
                "external_request_id": binding["external"],
                "internal_request_id": binding["internal"],
                "prefill_tokens": 1,
                "decode_retirements": retired,
                "output_tokens": len(row["token_ids"]),
            }
        )
    return {"count": 8, "all_token_counts_match": True, "rows": rows}
