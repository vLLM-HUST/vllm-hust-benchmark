# Fresh batch14 quota comparison

This bundle compares two fresh natural-answer runs on the same clean a050294 runtime. The original 200-case materialization remains byte-identical; only original batch14 is selected, in its original eight-request order. Both arms use builtin prefix and HCCL determinism. The q40 source-reference configuration is retained in one arm; the other explicitly changes only integer `layers_per_slice` from 40 to 4. The source identity is provenance, not a new accepted candidate.

The original collector's complete natural batch loop, sampling limit 8192, seed-one-token peer ingress, one per-batch snapshot RPC, final empty maintenance, original scorer and source/model/environment guards are retained. No observers, request warmups, operator changes or successful live-request cancellation are added. The original q40 candidate remains 29/32 with the 01741 new loss; full200 stays withheld.

Root must source `/root/workspace/runtime/env.sh`, verify the finalized producer map and reference gate, then freeze both exact attempts before running either. `run-matrix-v1.json` declares the sole q4 then q40 attempts and their offline analysis commands. q40 cannot launch before the predeclared q4 controller proves clean terminal collection and the same freeze. History equality is assessed separately and never becomes a reason for selecting a model retry. Both attempts retain workload10800/controller12600 bounds.

`host-source-proof-v1.json` verifies the unchanged original22 producers/inputs and natural-loop AST. `cpu-host-red-v1.log` records missing implementation; the focused source-reference binding negative initially failed, then passed with the exact-byte argument guard. `cpu-host-green-v2.log` records20 focused checks, including the actual clean-source prepare, whole-worker policy and failure-finalizer order. These CPU checks do not represent numerical or quality evidence.

Helper owns the final reference/scoring/schedule analysis. Its q4 schedule validation must retain actual seed40-layer completion plus peer ten4-layer advances, while q40 peer completes once. Both arms have two actual P eager entries and81 P reductions per cohort. Legitimate complete-output differences are reported, not erased; mismatch with historical trajectories leaves prior-history confounding unresolved.

Final CPU integration:31 checks passed in24.88s (host20, analyzer9, actual serializer/terminal fixture2). All30 producer bytes match `producer-map-v1.json`; Ruff check and format pass. `cpu-validation-v1.json` binds the final evidence. Synthetic fixtures are explicitly marked and are never candidate/model evidence.

Final revision: use `producer-map-v2.json` and `cpu-validation-v2.json`. A narrow review correction binds actual output request IDs and per-case token counts to admissions/retirements. Its2 focused checks and both terminal integration checks passed; original31-test v1 evidence remains intact. Only the analyzer changed among30 producers.
