"""Fresh natural batch14 quota diagnostic; source identity is provenance only."""

import argparse
import copy
import json
import os
import time
import traceback
from pathlib import Path

import run_quality as original
from batch14_treatment_v1 import (
    ARMS,
    SCOPES,
    apply_arm_config,
    select_batches,
    treatment_receipt,
    validate_arm_workers,
)
from candidate_checks_v1 import (
    BUNDLE,
    PLAN_SHA,
    PrefixTracker,
    original_manifest,
    save_batch_snapshot,
    source_guard,
    validate_environment,
    validate_final_snapshot,
    validate_model_config,
)
from candidate_checks_v1 import (
    candidate_worker_snapshot as worker_snapshot,
)
from probe_run_v1 import (
    abort_and_drain,
    file_sha,
    now,
    require_empty,
    require_empty_worker,
    save,
    scheduler_snapshot,
    tokenizer_identities,
)
from score_quality import load_frozen

MAX_CLEANUP_STEPS = 64


def prepare(scope, source, identity_path, arm, bundle=BUNDLE):
    receipt = treatment_receipt(arm, bundle)
    if file_sha(identity_path) != receipt["source_reference_identity_sha256"]:
        raise ValueError("Exact source reference bytes differ")
    candidate = json.loads(Path(identity_path).read_text())
    # This gate deliberately runs before frozen loading or any native import.
    identity = source_guard(source, candidate, bundle)
    manifest = original_manifest(bundle)
    manifest["candidate"] = candidate
    manifest["arm_treatment"] = receipt
    plan, cases, _ = load_frozen(bundle / "frozen-v2")
    batches = select_batches(plan, scope)
    base = original.validate(
        "raw", json.loads((bundle / "raw-engine-args-v1.json").read_text()), plan
    )
    config = apply_arm_config(base, candidate, arm)
    return plan, cases, batches, config, manifest, identity


def restore_receipts(scheduler, originals):
    if scheduler is not None and originals is not None:
        scheduler.schedule, scheduler.update_from_output = originals


def run(args):
    plan, cases, batches, config, manifest, identity = prepare(
        args.scope, args.source, args.identity, args.arm
    )
    args.output.mkdir(parents=True, exist_ok=False)
    forbidden = (
        "MUXPD_NUMERIC_OUTPUT",
        "MUXPD_PRESSURE_TRACE_DIR",
        "VLLM_TORCH_PROFILER_DIR",
    )
    if any(os.environ.get(key) for key in forbidden):
        raise ValueError("Remove unrelated observers/profilers")
    if os.environ.get("HCCL_DETERMINISTIC") != "true" or os.environ.get(
        "VLLM_BATCH_INVARIANT"
    ) not in (None, "0"):
        raise ValueError("Require original HCCL=true and batch invariance off")
    os.environ["VLLM_ENABLE_V1_MULTIPROCESSING"] = "0"
    report = {
        "schema": "muxpd-q4-q40-batch14-run-v1",
        "role": "raw",
        "profile": "builtin-batch14-quota-diagnostic",
        "scope": args.scope,
        "arm": args.arm,
        "arm_treatment": manifest["arm_treatment"],
        "layout_mode": "prefix",
        "plan_sha256": PLAN_SHA,
        "selected_batch_ids": [b["batch_id"] for b in batches],
        "selected_case_ids": [c for b in batches for c in b["case_ids"]],
        "process_id": os.getpid(),
        "started_at": now(),
        "engine_args": config,
        "base_engine_args": copy.deepcopy(config),
        "outputs": [],
        "admissions": [],
        "errors": [],
        "producer_sha256": file_sha(__file__),
        "original_producer_sha256": file_sha(BUNDLE / "run_quality.py"),
        "original_scorer_sha256": file_sha(BUNDLE / "score_quality.py"),
        "layout_module_sha256": manifest["candidate"]["runtime_files"][
            "src/vllm_muxpd/prefill_collective_layout.py"
        ],
        "source_manifest_sha256": file_sha(BUNDLE / "source-manifest-v1.json"),
        "source_reference_identity": identity,
        "sources": identity["sources"],
        "runtime_environment": original.runtime_environment(),
        "collection_complete": False,
        "terminal_lifecycle_verified": False,
        "prefix_batches": [],
        "shutdown_returned": False,
        "passed": False,
        "qualification_claim": "Collection-only fresh batch14 diagnostic. Source identity is provenance; candidate posterior32 quality remains FAIL and full200 is withheld.",
        "warmup": "Existing LLM constructor warmup only; zero extra request warmups.",
    }
    save(args.output / "run.json", report)
    llm, scheduler, originals, baseline = None, None, None, None
    tracker = None
    coverage, context = {}, {"global_step": 0, "batch_id": -1}
    by_id = {row["case_id"]: row for row in cases}
    try:
        validate_environment(
            report["runtime_environment"],
            manifest["historical_runs"]["raw-quality-v2-hccl-true-01"][
                "runtime_environment"
            ],
            manifest["candidate"],
        )
        from tokenizers import Tokenizer
        from vllm import LLM, SamplingParams
        from vllm.v1.engine.core_client import InprocClient

        report["tokenizer_files"] = tokenizer_identities(plan)
        decoder = Tokenizer.from_file(plan["tokenizer_files"]["tokenizer.json"]["path"])
        if original.source_identities() != identity["sources"]:
            raise RuntimeError("Imported source differs before LLM construction")
        report["model_config_before_startup"] = validate_model_config(
            manifest["candidate"]
        )
        save(args.output / "run.json", report)
        llm = LLM(**config)
        report["model_config_after_startup"] = validate_model_config(
            manifest["candidate"]
        )
        save(args.output / "run.json", report)
        engine = llm.llm_engine
        if not isinstance(engine.engine_core, InprocClient):
            raise TypeError("Actual coordinator is not InprocClient")
        core = engine.engine_core.engine_core
        scheduler = core.scheduler
        report["sources"] = original.source_identities()
        if report["sources"] != identity["sources"]:
            raise RuntimeError("Imported source differs from pinned preflight source")
        report["source_after_startup"] = source_guard(
            args.source, manifest["candidate"]
        )
        expected_config = manifest["historical_runs"]["raw-quality-v2-hccl-true-01"][
            "engine_args"
        ]
        expected_config = apply_arm_config(
            expected_config, manifest["candidate"], args.arm
        )
        if config != expected_config:
            raise RuntimeError(
                "Resolved engine launch configuration differs from original raw quality"
            )
        cfg = core.vllm_config
        report["effective"] = {
            "max_model_len": cfg.model_config.max_model_len,
            "max_num_seqs": cfg.scheduler_config.max_num_seqs,
            "max_num_batched_tokens": cfg.scheduler_config.max_num_batched_tokens,
            "enable_chunked_prefill": cfg.scheduler_config.enable_chunked_prefill,
            "tensor_parallel_size": cfg.parallel_config.tensor_parallel_size,
        }
        if report["effective"] != {k: config[k] for k in report["effective"]}:
            raise RuntimeError("Effective runtime differs from frozen launch arguments")
        report["scheduler_class"] = (
            type(scheduler).__module__ + "." + type(scheduler).__name__
        )
        report["engine_coordinator"] = type(engine.engine_core).__name__
        baseline = scheduler_snapshot(engine)
        require_empty(baseline, baseline)
        report["idle_baseline"] = baseline
        report["worker_before"] = llm.collective_rpc(worker_snapshot, timeout=60)
        validate_arm_workers(report["worker_before"], manifest["candidate"], args.arm)
        for row in report["worker_before"]:
            require_empty_worker(row)
        report["prefix_initial"] = [
            row["builtin_layout"] for row in report["worker_before"]
        ]
        tracker = PrefixTracker(
            report["prefix_initial"], report["layout_module_sha256"]
        )
        params = SamplingParams(**plan["sampling"])
        started = time.monotonic()
        with (args.output / "scheduler-receipts.jsonl").open(
            "x", buffering=1
        ) as receipts:
            originals = scheduler.schedule, scheduler.update_from_output
            original.install_receipts(scheduler, receipts, context, coverage)
            for batch in batches:
                context["batch_id"] = batch["batch_id"]
                members = [by_id[rid] for rid in batch["case_ids"]]
                mappings = original.enqueue_bound(llm, members[:1], params)
                seed = mappings[0]["internal"]
                admitted = {mappings[0]["external"]: members[0]}
                report["admissions"].append(
                    {**context, "stage": "seed", "bindings": mappings}
                )
                released, finished = False, set()
                while engine.has_unfinished_requests():
                    if (
                        context["global_step"] >= plan["maximum_engine_steps"]
                        or time.monotonic() - started > plan["maximum_wall_seconds"]
                    ):
                        raise RuntimeError(
                            "Original frozen bounded-work limit exceeded"
                        )
                    context["global_step"] += 1
                    outputs = engine.step()
                    seed_finished_tokens = None
                    for output in outputs:
                        if not output.finished:
                            continue
                        if (
                            output.request_id not in admitted
                            or output.request_id in finished
                            or len(output.outputs) != 1
                        ):
                            raise RuntimeError(
                                "Unknown, duplicate or multi-sample final output"
                            )
                        finished.add(output.request_id)
                        case, item = admitted[output.request_id], output.outputs[0]
                        if list(output.prompt_token_ids) != case["prompt_token_ids"]:
                            raise RuntimeError(
                                "Returned prompt differs from frozen token IDs"
                            )
                        tokens = list(map(int, item.token_ids))
                        report["outputs"].append(
                            {
                                "case_id": case["case_id"],
                                "request_id": output.request_id,
                                "finished": True,
                                "token_ids": tokens,
                                "text": decoder.decode(
                                    tokens, skip_special_tokens=True
                                ),
                                "finish_reason": item.finish_reason,
                                "stop_reason": item.stop_reason,
                            }
                        )
                        if case["case_id"] == batch["seed_case_id"]:
                            seed_finished_tokens = len(tokens)
                    if not released:
                        seed_request = scheduler.requests.get(seed)
                        count = (
                            seed_request.num_output_tokens
                            if seed_request is not None
                            else seed_finished_tokens
                        )
                        if count is None or count == 0:
                            if seed_request is None:
                                raise RuntimeError(
                                    "Seed completed without an observed output token"
                                )
                            continue
                        if count != 1:
                            raise RuntimeError(
                                "Missed exact first-output-token admission gate"
                            )
                        bindings = original.enqueue_bound(llm, members[1:], params)
                        admitted.update(
                            {
                                row["external"]: case
                                for row, case in zip(bindings, members[1:], strict=True)
                            }
                        )
                        report["admissions"].append(
                            {
                                **context,
                                "stage": "peers",
                                "bindings": bindings,
                                "seed_output_tokens": count,
                                "seed_still_live": seed_request is not None,
                            }
                        )
                        released = True
                if (
                    not released
                    or len(finished) != len(members)
                    or finished != set(admitted)
                ):
                    raise RuntimeError(
                        "Batch ended without every frozen request returning"
                    )
                save_batch_snapshot(llm, tracker, report, args.output, batch, cases)
                save(args.output / "run.json", report)
        restore_receipts(scheduler, originals)
        originals = None
        report["answer_engine_steps"] = context["global_step"]
        report["answer_seconds"] = time.monotonic() - started
        # No live request may be cancelled on the success path. A final empty
        # maintenance turn only flushes naturally finished IDs to the workers.
        if scheduler.requests or engine.has_unfinished_requests():
            raise RuntimeError("Natural full-answer collection retained live requests")
        report["terminal_maintenance"] = abort_and_drain(engine, MAX_CLEANUP_STEPS)
        if report["terminal_maintenance"]["aborted_internal_ids"]:
            raise RuntimeError("Success path cancelled live requests")
        report["final_state"] = scheduler_snapshot(engine)
        require_empty(report["final_state"], baseline)
        report["worker_after"] = llm.collective_rpc(worker_snapshot, timeout=60)
        validate_arm_workers(report["worker_after"], manifest["candidate"], args.arm)
        for row in report["worker_after"]:
            require_empty_worker(row)
        report["prefix_final"] = [
            row["builtin_layout"] for row in report["worker_after"]
        ]
        report["prefix_validation"] = validate_final_snapshot(
            report["prefix_final"], tracker
        )
        if tracker.total_cohorts != 2 * len(batches):
            raise RuntimeError("Incomplete cumulative builtin cohort history")
        report["collection_complete"] = len(report["outputs"]) == len(
            report["selected_case_ids"]
        ) and {x["case_id"] for x in report["outputs"]} == set(
            report["selected_case_ids"]
        )
    except BaseException:  # noqa: BLE001 -- keep the original failure and clean owned state
        report["errors"].append(traceback.format_exc())
    finally:
        restore_receipts(scheduler, originals)
        if llm is not None:
            if not report["collection_complete"]:
                try:
                    report["failure_cleanup"] = abort_and_drain(
                        llm.llm_engine, MAX_CLEANUP_STEPS
                    )
                    report["failure_final_state"] = scheduler_snapshot(llm.llm_engine)
                    if baseline is None:
                        raise RuntimeError("No baseline for safe cleanup verification")
                    require_empty(report["failure_final_state"], baseline)
                    report["failure_worker_state"] = llm.collective_rpc(
                        worker_snapshot, timeout=60
                    )
                    validate_arm_workers(
                        report["failure_worker_state"], manifest["candidate"], args.arm
                    )
                    for row in report["failure_worker_state"]:
                        require_empty_worker(row)
                except BaseException:  # noqa: BLE001 -- cleanup never promotes collection success
                    report["errors"].append(traceback.format_exc())
            try:
                llm.llm_engine.engine_core.shutdown()
                report["shutdown_returned"] = True
            except BaseException:  # noqa: BLE001 -- preserve shutdown failure
                report["errors"].append(traceback.format_exc())
        try:
            report["sources_after_shutdown"] = source_guard(
                args.source, manifest["candidate"]
            )
        except BaseException:  # noqa: BLE001 -- retain provenance failure
            report["errors"].append(traceback.format_exc())
        report["finished_at"] = now()
        report["mixed_coverage"] = {
            "steps_per_batch": coverage,
            "covered_batches": sorted(coverage),
            "uncovered_batches": [
                b["batch_id"] for b in batches if b["batch_id"] not in coverage
            ],
            "meaning": "Actual P layer progress plus D token retirement in one transaction; not physical kernel overlap",
        }
        receipt_path = args.output / "scheduler-receipts.jsonl"
        if receipt_path.exists():
            report["scheduler_receipts_sha256"] = file_sha(receipt_path)
        report["passed"] = bool(
            report["collection_complete"]
            and report["shutdown_returned"]
            and not report["errors"]
        )
        save(args.output / "run.json", report)
    print(
        json.dumps(
            {
                "passed": report["passed"],
                "scope": args.scope,
                "outputs": len(report["outputs"]),
                "errors": report["errors"],
            }
        )
    )
    return 0 if report["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("dry-run", "run"))
    parser.add_argument("--scope", choices=SCOPES, required=True)
    parser.add_argument("--arm", choices=ARMS, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--identity", type=Path, default=BUNDLE / "source-reference-identity-v1.json"
    )
    args = parser.parse_args()
    args.source = args.source.resolve()
    if args.command == "dry-run":
        plan, _, batches, _, manifest, identity = prepare(
            args.scope, args.source, args.identity, args.arm
        )
        print(
            json.dumps(
                {
                    "validated": True,
                    "scope": args.scope,
                    "plan_sha256": PLAN_SHA,
                    "batch_ids": [b["batch_id"] for b in batches],
                    "case_count": sum(len(b["case_ids"]) for b in batches),
                    "max_tokens": plan["sampling"]["max_tokens"],
                    "maximum_engine_steps": plan["maximum_engine_steps"],
                    "maximum_wall_seconds": plan["maximum_wall_seconds"],
                    "layout_module_sha256": manifest["candidate"]["runtime_files"][
                        "src/vllm_muxpd/prefill_collective_layout.py"
                    ],
                    "source_reference_identity": identity,
                },
                indent=2,
            )
        )
        return 0
    if args.output is None:
        parser.error("run requires a fresh --output directory")
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
