"""Explicit diagnostic quota treatment; never mutates the source identity."""

import copy
import json
from pathlib import Path

from candidate_checks_v1 import (
    BUNDLE,
    apply_policy_changes,
    file_sha,
    four,
    original_manifest,
    require,
)
from candidate_checks_v1 import (
    select_batches as original_select_batches,
)

ARMS = ("q4", "q40")
SCOPES = ("batch14",)
LABELS = {arm: f"builtin-{arm}-batch14-full-v1-01" for arm in ARMS}
SOURCE_REFERENCE_SHA = (
    "8d04890973c369a5412e80cc08c6cb55ef405e9360bd38e2bfafa9b5d65fe4fe"
)
CASE_IDS = [
    "mmlu-pro-" + x
    for x in ("01557", "01619", "01680", "01741", "01802", "01862", "01923", "01984")
]


def treatment_receipt(arm, bundle=BUNDLE):
    require(type(arm) is str and arm in ARMS, "Unknown diagnostic quota arm")
    path = bundle / "batch14-treatment-v1.json"
    profile = json.loads(path.read_text())
    require(
        profile["schema"] == "muxpd-batch14-quota-treatment-v1"
        and profile["quality_candidate"] is False
        and profile["scope"] == "batch14"
        and profile["batch_ids"] == [14]
        and profile["case_ids"] == CASE_IDS,
        "Treatment scope differs",
    )
    require(
        profile["source_commit"] == "a05029484b2c9bc21e4e6fd705cc396d111dfaa5"
        and profile["source_reference_identity_sha256"]
        == SOURCE_REFERENCE_SHA
        == file_sha(bundle / "source-reference-identity-v1.json"),
        "Source reference differs",
    )
    expected = {
        "q4": {
            "layers_per_slice": 4,
            "policy_overrides": [{"key": "layers_per_slice", "from": 40, "to": 4}],
        },
        "q40": {"layers_per_slice": 40, "policy_overrides": []},
    }
    require(
        json.dumps(profile["arms"], sort_keys=True)
        == json.dumps(expected, sort_keys=True),
        "Only exact integer quota40-to4 arm treatment is allowed",
    )
    return {
        "schema": "muxpd-batch14-arm-treatment-v1",
        "arm": arm,
        "treatment_profile_sha256": file_sha(path),
        "source_reference_identity_sha256": SOURCE_REFERENCE_SHA,
        "source_commit": profile["source_commit"],
        "quality_candidate": False,
        **copy.deepcopy(expected[arm]),
    }


def select_batches(plan, scope):
    require(scope == "batch14", "Only original batch14 is permitted")
    all_batches = original_select_batches(plan, "full")
    batch = all_batches[14]
    require(
        batch["batch_id"] == 14 and batch["case_ids"] == CASE_IDS,
        "Original batch14 order differs",
    )
    return [batch]


def apply_arm_config(base, source_reference, arm):
    receipt = treatment_receipt(arm)
    result = apply_policy_changes(base, source_reference)
    policy = result["batch_admission_policy_config"]
    require(
        type(policy["layers_per_slice"]) is int and policy["layers_per_slice"] == 40,
        "Require unchanged q40 source-reference configuration",
    )
    policy["layers_per_slice"] = receipt["layers_per_slice"]
    return result


def validate_arm_workers(rows, source_reference, arm):
    from probe_run_v1 import validate_workers

    four(rows)
    validate_workers(rows, "raw-layout-plain")
    historical = original_manifest()["historical_runs"]["raw-quality-v2-hccl-true-01"][
        "engine_args"
    ]
    expected = apply_arm_config(historical, source_reference, arm)[
        "batch_admission_policy_config"
    ]
    for row in rows:
        require(
            row["worker_source_path"]
            == str(
                Path(source_reference["source_root"])
                / "src/vllm_muxpd/decoupled_worker.py"
            )
            and not any(row["foreign_diagnostic_state"].values()),
            "Worker source/diagnostic state differs",
        )
        require(
            json.dumps(row["runtime"]["policy"], sort_keys=True, separators=(",", ":"))
            == json.dumps(expected, sort_keys=True, separators=(",", ":")),
            "Actual entire worker policy differs from declared diagnostic arm",
        )
