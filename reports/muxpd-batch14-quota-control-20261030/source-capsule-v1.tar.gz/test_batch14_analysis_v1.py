"""Source-backed schedule fixtures from actual terminal q4/q40 histories."""

import copy
import json
from pathlib import Path

import pytest

import batch14_pair_analysis_v1 as analysis

BUNDLE = Path(__file__).parent
ROOT = Path("/root/workspace/muxpd-runtime-quality-candidate-v2-20261030")


@pytest.fixture(scope="module")
def actual():
    refs = json.loads((ROOT / "candidate-quality-references-v1.json").read_text())
    paths = {
        "q4": Path(refs["historical_runs"]["prefix"]["directory"]),
        "q40": ROOT / "runs-v1/prefix-q40-runtime-posterior32-v1-01",
    }
    values = {}
    for arm, directory in paths.items():
        controller = json.loads((directory / "controller.json").read_text())
        assert (
            controller["passed"]
            and controller["exit_code"] == 0
            and controller["owned_members_after_cleanup"] == []
        )
        report = json.loads((directory / "results/run.json").read_text())
        history = []
        for line in (directory / "results/scheduler-receipts.jsonl").open():
            row = json.loads(line)
            if row["batch_id"] == 14:
                history.append(row)
        offset = history[0]["global_step"] - 1
        for row in history:
            row["global_step"] -= offset
        report["admissions"] = [r for r in report["admissions"] if r["batch_id"] == 14]
        for row in report["admissions"]:
            row["global_step"] -= offset
        report["answer_engine_steps"] = len(history) // 2
        report["outputs"] = [
            r for r in report["outputs"] if r["case_id"] in analysis.treatment.CASE_IDS
        ]
        values[arm] = (report, history)
    plan, cases, _ = analysis.original.load_frozen(BUNDLE / "frozen-v2")
    return values, analysis.treatment.select_batches(plan, "batch14")[0], cases


def test_real_q4_pending_ten_rounds_but_two_model_forwards(actual):
    values, batch, cases = actual
    result = analysis.validate_schedule(*values["q4"], batch, cases, "q4")
    assert result["peer_prefill_advancements"] == 10
    assert result["prefill_model_forwards"] == 2
    assert result["peer_completed_layers"] == list(range(4, 41, 4))
    assert result["peer_ack_advancement"] == 10


def test_real_q40_single_round(actual):
    values, batch, cases = actual
    result = analysis.validate_schedule(*values["q40"], batch, cases, "q40")
    assert result["peer_prefill_advancements"] == 1
    assert result["prefill_model_forwards"] == 2
    assert result["peer_completed_layers"] == [40]
    assert result["decode_turns"] == values["q40"][0]["answer_engine_steps"] - 1


def test_q4_early_ack_and_repeated_prompt_are_rejected(actual):
    values, batch, cases = actual
    report, history = values["q4"]
    changed = copy.deepcopy(history)
    changed[3]["completed_prefill_ids"] = list(changed[2]["pending_prefill_ids"])
    with pytest.raises(ValueError, match="progress|ACK"):
        analysis.validate_schedule(report, changed, batch, cases, "q4")
    changed = copy.deepcopy(history)
    changed[4]["scheduled_tokens"].update(
        {
            rid: n
            for rid, n in changed[2]["scheduled_tokens"].items()
            if rid in changed[2]["new_prefill_ids"]
        }
    )
    with pytest.raises(ValueError, match="scheduled"):
        analysis.validate_schedule(report, changed, batch, cases, "q4")


def test_q4_not_mislabeled_q40_and_seed_is_unsliced(actual):
    values, batch, cases = actual
    with pytest.raises(ValueError):
        analysis.validate_schedule(*values["q4"], batch, cases, "q40")
    report, history = values["q4"]
    changed = copy.deepcopy(history)
    changed[1]["prefill_layers_completed"] = 4
    with pytest.raises(ValueError, match="progress|ACK"):
        analysis.validate_schedule(report, changed, batch, cases, "q4")


def test_reference_gate_requires_actual_external32_pass():
    refs, proof = analysis.verify_references(BUNDLE)
    assert (
        proof["passed"] is True and proof["external32_port_equivalence_passed"] is True
    )
    assert proof["builtin_relative_no_new_wrong_passed"] is False
    assert refs["full200_allowed"] is False


def test_historical_full_eight_comparison_keeps_target_regression(actual):
    values, _, _ = actual
    result = analysis.compare_eight(values["q4"][0], values["q40"][0])
    assert result["all8_equal"] is False
    target = next(r for r in result["rows"] if r["case_id"] == "mmlu-pro-01741")
    assert target["first_difference"]["position_one_based"] == 58
    assert target["left_tokens"] == 590 and target["right_tokens"] == 5551
    assert len(result["rows"]) == 8


def test_single_q4_terminal_gate_never_reads_future_q40(tmp_path):
    (tmp_path / "controller.json").write_text(
        json.dumps({"terminal_process_proven": False, "passed": False})
    )
    with pytest.raises(ValueError, match="terminal"):
        analysis.qualify_arms([("q4", tmp_path)], BUNDLE)


def test_pair_checks_both_terminals_before_any_child(tmp_path):
    # First controller uses a real terminal record but has no child. A missing
    # second controller must be the first failing read, not the first child.
    q4 = tmp_path / "q4"
    q40 = tmp_path / "q40"
    q4.mkdir()
    q40.mkdir()
    source = ROOT / "runs-v1/prefix-q40-runtime-posterior32-v1-01/controller.json"
    (q4 / "controller.json").write_bytes(source.read_bytes())
    (q40 / "controller.json").write_text(
        json.dumps({"terminal_process_proven": False, "passed": False})
    )
    with pytest.raises(ValueError, match="terminal"):
        analysis.qualify_arms([("q4", q4), ("q40", q40)], BUNDLE)


def test_nonreproduced_history_retains_actual_original_scores(actual):
    values, _, _ = actual
    refs = analysis.read(BUNDLE / "batch14-pair-references-v1.json")
    # Explicit CPU comparison: use the actual q40 outcome as a different fresh
    # q4 trajectory, without claiming it was a q4 device attempt.
    result = analysis.assess_values(
        {"q4": {"report": values["q40"][0], "receipts": values["q40"][1]}}, refs, BUNDLE
    )
    assert result["all_requested_historical_trajectories_reproduced"] is False
    row = next(
        r
        for r in result["arms"]["q4"]["fresh_score"]["rows"]
        if r["case_id"] == "mmlu-pro-01741"
    )
    assert row["answer"] == "C" and row["correct"] is False and row["complete"] is True
    assert result["full_quality_gate_attempted"] is False


def test_real_outputs_bind_actual_admission_and_retirement(actual):
    values, batch, cases = actual
    for arm, (report, history) in values.items():
        schedule = analysis.validate_schedule(report, history, batch, cases, arm)
        proof = analysis.validate_output_retirement_link(report, schedule)
        assert proof["count"] == 8 and proof["all_token_counts_match"] is True


def test_output_wrong_external_request_and_missing_D_are_rejected(actual):
    values, batch, cases = actual
    report, history = values["q40"]
    schedule = analysis.validate_schedule(report, history, batch, cases, "q40")
    changed = copy.deepcopy(report)
    changed["outputs"][0]["request_id"] = changed["outputs"][1]["request_id"]
    with pytest.raises(ValueError, match="admission"):
        analysis.validate_output_retirement_link(changed, schedule)
    changed = copy.deepcopy(schedule)
    changed["per_case_decode_retirements"]["mmlu-pro-01741"] -= 1
    with pytest.raises(ValueError, match="retirements"):
        analysis.validate_output_retirement_link(report, changed)
