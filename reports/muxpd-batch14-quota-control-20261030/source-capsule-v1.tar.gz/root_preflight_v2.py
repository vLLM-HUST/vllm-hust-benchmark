"""Root read-only two-arm source/config/environment/device preflight."""
import copy
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from probe_control_v1 import inventory

BUNDLE = Path(__file__).resolve().parent
OUT = BUNDLE / "root-preflight-v2"
OUT.mkdir(exist_ok=False)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


matrix = json.loads((BUNDLE / "run-matrix-v1.json").read_text())
assert [arm["arm"] for arm in matrix["attempts"]] == ["q4", "q40"]
previews = {}
for arm in matrix["attempts"]:
    name = arm["arm"]
    result = subprocess.run(arm["dry_run_command"], capture_output=True)
    (OUT / f"{name}-dry-run.json").write_bytes(result.stdout)
    (OUT / f"{name}-dry-run.stderr").write_bytes(result.stderr)
    if result.returncode:
        raise SystemExit(f"{name} root dry-run failed; retained stdout/stderr")
    value = json.loads(result.stdout)
    assert value["arm"] == name and value["selected_batch_ids"] == [14]
    assert value["selected_case_count"] == 8
    assert value["runtime_environment_guard"]["passed"]
    assert value["references_qualification"]["passed"]
    assert len(value["files"]) == 30
    assert value["files"] == {p: sha(BUNDLE / p) for p in value["files"]}
    assert not Path(value["destination"]).exists()
    previews[name] = value
assert previews["q4"]["files"] == previews["q40"]["files"]
assert previews["q4"]["source_preflight"] == previews["q40"]["source_preflight"]
assert previews["q4"]["references_qualification"] == previews["q40"]["references_qualification"]
assert previews["q4"]["predecessor_qualification"] is None
assert previews["q40"]["predecessor_qualification"]["ready"] is False
adjusted = copy.deepcopy(previews["q4"]["launch_engine_args"])
assert adjusted["batch_admission_policy_config"]["layers_per_slice"] == 4
adjusted["batch_admission_policy_config"]["layers_per_slice"] = 40
assert adjusted == previews["q40"]["launch_engine_args"]
source = "/root/workspace/muxpd-prefix-q40-runtime"
head = subprocess.check_output(["git", "-C", source, "rev-parse", "HEAD"], text=True).strip()
status = subprocess.check_output(["git", "-C", source, "status", "--porcelain"], text=True)
assert head == "a05029484b2c9bc21e4e6fd705cc396d111dfaa5" and not status
devices = subprocess.check_output(["npu-smi", "info"], timeout=30)
(OUT / "npu-idle.txt").write_bytes(devices)
physical = inventory(devices.decode())
assert physical == ["3", "4", "5", "6"]
record = {
    "schema": "muxpd-batch14-fullpair-root-preflight-v1",
    "passed": True,
    "created_at": datetime.now(timezone.utc).isoformat(),
    "source_commit": head,
    "source_clean": True,
    "idle_physical": physical,
    "only_pair_config_difference": "layers_per_slice4/40",
    "producer_files": previews["q4"]["files"],
    "reference_identity_sha256": sha(BUNDLE / "source-reference-identity-v1.json"),
    "matrix_sha256": sha(BUNDLE / "run-matrix-v1.json"),
    "evidence": {p.name: sha(p) for p in OUT.iterdir()},
    "q40_requires_q4_clean_qualified_terminal": True,
    "historical_trajectory_equality_is_not_second_arm_gate": True,
    "full200_allowed": False,
}
with (OUT / "preflight.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({"passed": True, "sha256": sha(OUT / "preflight.json"), "physical": physical}))
