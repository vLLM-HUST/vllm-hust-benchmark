"""Independent fresh batch14 quota audit. No model/device operations.

Single-arm q4 mode never accesses the future q40 attempt directory.
Pair mode proves both controllers terminal before any attempted-run child/log.
Only immutable original scorer and candidate_checks/PrefixTracker/lifecycle
helpers are imported; no new batch14 analyzer/controller/treatment is imported.
Run only after root explicitly authorizes terminal data access.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

PHYSICAL = ["3", "4", "5", "6"]
IDENTITY_SHA = "8d04890973c369a5412e80cc08c6cb55ef405e9360bd38e2bfafa9b5d65fe4fe"
SCORER_SHA = "157b52ffdbae6d7f0f990bb27379c463df1807daeebf7298fd396968e96b17fd"
CHECKS_SHA = "ad5132f186e765ec3244f30891d37fc578c6272d2565db4745cf84b5f7164128"
CASE_IDS = [
    "mmlu-pro-" + x
    for x in ("01557", "01619", "01680", "01741", "01802", "01862", "01923", "01984")
]
LABELS = {arm: f"builtin-{arm}-batch14-full-v1-01" for arm in ("q4", "q40")}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def terminal(directory):
    # Controller is the only attempted-run artifact opened before this gate.
    row = read(directory / "controller.json")
    require(
        row.get("terminal_process_proven") is True
        and row.get("exit_code") == 0
        and row.get("owned_members_after_cleanup") == []
        and row.get("owned_members_before_cleanup") == []
        and not row.get("cleanup_required", False)
        and not row.get("forced_termination", False)
        and not row.get("timeout", False)
        and not row.get("errors")
        and row.get("passed") is True,
        "Both controllers must prove clean terminal process state before child/log reads",
    )
    require(
        row.get("expected_physical") == PHYSICAL
        and row.get("idle_physical_before") == PHYSICAL
        and row.get("idle_physical_after") == PHYSICAL,
        "Four-device terminal idle receipts differ",
    )
    return row


def load_original(path, name, expected):
    require(sha(path) == expected, f"Original module changed: {path.name}")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def four(rows):
    require(
        len(rows) == 4 and {r["rank"] for r in rows} == set(range(4)),
        "Four unique rank receipts required",
    )
    return {r["rank"]: r for r in rows}


def mapped(mapping, value):
    require(
        value in mapping, "Unknown request ID cannot be dropped during normalization"
    )
    return mapping[value]


def workers_and_graph(report, schedule_rows):
    before, after = four(report["worker_before"]), four(report["worker_after"])
    decode_turns = sum(
        row["event"] == "schedule"
        and any(
            phase == "D" and rid in row["scheduled_tokens"]
            for rid, phase in row["phases_before"].items()
        )
        for row in schedule_rows
    )
    policy = report["engine_args"]["batch_admission_policy_config"]
    deltas = []
    for rank in range(4):
        for row in (before[rank], after[rank]):
            require(
                not any(row["requests"].values())
                and not any(row["input_num_reqs"].values())
                and not any(row["input_req_id_to_index"].values())
                and not any(
                    rid is not None
                    for rows in row["input_rows"].values()
                    for rid in rows
                )
                and not row["prefill_task_present"]
                and row["prefill_cohort_id"] is None
                and not row["awaiting_sample"]
                and not row["pending_lanes"],
                "Worker request/iteration state not empty",
            )
            require(
                canonical(row["runtime"]["policy"]) == canonical(policy),
                "Actual full worker policy differs",
            )
            graph = row["decode_graph_snapshot"]
            require(
                graph["captured"]
                and not graph["failed"]
                and not graph["closed"]
                and graph["enabled"]
                and not graph["compile_full_prefill"],
                "Original D graph/P eager mode differs",
            )
        first, last = (
            before[rank]["decode_graph_snapshot"],
            after[rank]["decode_graph_snapshot"],
        )
        require(set(first) == set(last), "Graph snapshot fields changed")
        for key in first:
            if key not in ("decode_replay_calls", "prefill_forced_eager_calls"):
                require(
                    first[key] == last[key],
                    f"Graph state/capture/fallback/failure field changed: {key}",
                )
        require(
            first["captured_graph_entries"] > 0, "No actual captured D graph entries"
        )
        for worker in (before[rank], after[rank]):
            runtime = worker["runtime"]
            require(
                runtime["enable_npugraph_ex"] is False
                and runtime["enable_static_kernel"] is False
                and runtime["cudagraph_mode"] == "FULL_DECODE_ONLY"
                and runtime["cudagraph_capture_sizes"] == [1, 2, 4, 8]
                and runtime["async_scheduling"] is False
                and runtime["enable_chunked_prefill"] is False
                and runtime["tensor_parallel_size"] == 4
                and runtime["enable_expert_parallel"] is True,
                "Actual worker graph/backend configuration changed",
            )
        require(
            last["decode_replay_calls"] - first["decode_replay_calls"] == decode_turns
            and last["prefill_forced_eager_calls"] - first["prefill_forced_eager_calls"]
            == 2,
            "Actual graph/P forwards differ from schedule",
        )
        deltas.append(
            {
                "rank": rank,
                "decode_replay_calls": last["decode_replay_calls"]
                - first["decode_replay_calls"],
                "prefill_eager_calls": 2,
            }
        )
    state = report["final_state"]
    require(
        not any(
            state[k]
            for k in (
                "request_ids",
                "running_ids",
                "waiting_ids",
                "skipped_waiting_ids",
                "finished_req_ids",
                "client_request_ids",
                "cohort_present",
                "held_prefill_ids",
            )
        )
        and state["free_blocks"] == report["idle_baseline"]["free_blocks"],
        "Scheduler/KV state not fully returned",
    )
    return deltas


def first_difference(left, right):
    for index, (a, b) in enumerate(zip(left, right), 1):
        if a != b:
            return index
    return None if len(left) == len(right) else min(len(left), len(right)) + 1


def validate_outputs(report, selected, decoder, vocab_size):
    require(
        len(report["outputs"]) == len(selected) == 8
        and {r["case_id"] for r in report["outputs"]} == set(selected),
        "Complete8 output identities required",
    )
    result = {}
    for row in report["outputs"]:
        require(
            row["finished"] is True
            and not row.get("error")
            and row["finish_reason"] in ("stop", "length")
            and 0 < len(row["token_ids"]) <= 8192,
            "All8 must finish naturally or at original8192 cap",
        )
        require(
            all(type(t) is int and 0 <= t < vocab_size for t in row["token_ids"]),
            "Invalid complete token payload",
        )
        require(
            decoder.decode(row["token_ids"], skip_special_tokens=True) == row["text"],
            "Stored text differs from original tokenizer decode",
        )
        result[row["case_id"]] = row
    return result


def bind(report):
    admissions = report["admissions"]
    require(len(admissions) == 2, "Exactly two admissions required")
    all_ids = {}
    internal = {}
    external = {}
    for index, row in enumerate(admissions):
        expected = CASE_IDS[:1] if index == 0 else CASE_IDS[1:]
        require(
            row["batch_id"] == 14
            and row["global_step"] == index
            and row["stage"] == ("seed" if index == 0 else "peers")
            and [b["case_id"] for b in row["bindings"]] == expected,
            "Original fresh seed/peer order changed",
        )
        if index:
            require(
                row["seed_output_tokens"] == 1 and row["seed_still_live"] is True,
                "Exact live first-token peer admission required",
            )
        for b in row["bindings"]:
            require(
                b["internal"] not in all_ids
                and b["external"] not in all_ids
                and b["internal"] != b["external"],
                "Duplicate actual request binding",
            )
            all_ids[b["internal"]] = all_ids[b["external"]] = b["case_id"]
            internal[b["internal"]] = b["case_id"]
            external[b["case_id"]] = b["external"]
    return all_ids, internal, external


def quota_schedule(report, directory, arm, cases, internal):
    path = directory / "results/scheduler-receipts.jsonl"
    require(
        sha(path) == report["scheduler_receipts_sha256"], "Actual schedule file changed"
    )
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    require(
        len(rows) % 2 == 0 and len(rows) // 2 == report["answer_engine_steps"],
        "Unpaired actual serving records",
    )
    quota = 4 if arm == "q4" else 40
    peer_rounds = 40 // quota
    ids = {case: rid for rid, case in internal.items()}
    seed = ids[CASE_IDS[0]]
    peers = {ids[c] for c in CASE_IDS[1:]}
    prompts = {c["case_id"]: len(c["prompt_token_ids"]) for c in cases}
    accumulated = Counter()
    normalized = []
    sizes = []
    previous = set()
    actual_layers = []
    require(len(rows) // 2 > peer_rounds + 1, "Incomplete natural decode history")
    for step, (s, r) in enumerate(zip(rows[::2], rows[1::2], strict=True), 1):
        require(
            s["event"] == "schedule"
            and r["event"] == "retirement"
            and s["global_step"] == r["global_step"] == step
            and s["batch_id"] == r["batch_id"] == 14,
            "Serving event order/identity differs",
        )
        require(
            set(s["phases_before"]) <= internal.keys()
            and set(s["phases_before"].values()) <= {"P", "D"},
            "Unknown serving identity/phase",
        )
        p = {rid for rid, phase in s["phases_before"].items() if phase == "P"}
        d = {rid for rid, phase in s["phases_before"].items() if phase == "D"}
        expected_p = (
            {seed} if step == 1 else peers if step <= 1 + peer_rounds else set()
        )
        require(
            p == expected_p
            and (
                not d
                if step == 1
                else d == {seed}
                if step <= 1 + peer_rounds
                else bool(d) and d <= previous
            ),
            "Actual pending P/D population changed",
        )
        new = p if step <= 2 else set()
        before = 0 if step <= 2 or not p else (step - 2) * quota
        after = 40 if step == 1 else (step - 1) * quota if p else 0
        done = p if step in (1, 1 + peer_rounds) else set()
        scheduled = {rid: prompts[internal[rid]] for rid in new} | dict.fromkeys(d, 1)
        require(
            s["scheduled_tokens"] == scheduled
            and set(s["pending_prefill_ids"]) == p
            and len(s["pending_prefill_ids"]) == len(p)
            and set(s["new_prefill_ids"]) == new
            and len(s["new_prefill_ids"]) == len(new)
            and s["prefill_layers_before"] == before
            and not s["preempted_req_ids"],
            "Prompt admission/pending/quota progression changed",
        )
        require(
            set(r["completed_prefill_ids"]) == done
            and len(r["completed_prefill_ids"]) == len(done)
            and not r["cancelled_prefill_ids"]
            and r["prefill_layers_completed"] == after
            and r["actual_prefill_progress"] is bool(p)
            and r["mixed_pd_progress_and_retirement"] is bool(p and d)
            and r["native_mixed_scheduled_and_decode_retired"] is False,
            "Actual layer completion/ACK changed",
        )
        require(
            set(r["decode_retired_ids"]) == d
            and len(r["decode_retired_ids"]) == len(d),
            "Actual D retirement changed",
        )
        accumulated.update(internal[rid] for rid in d)
        if d:
            sizes.append(len(d))
        if step > 1 and p:
            actual_layers.append(after)
        previous = p | d
        for event in (s, r):
            value = copy.deepcopy(event)
            for key in ("scheduled_tokens", "phases_before"):
                if key in value:
                    value[key] = {
                        mapped(internal, rid): n for rid, n in value[key].items()
                    }
            for key in (
                "pending_prefill_ids",
                "new_prefill_ids",
                "preempted_req_ids",
                "completed_prefill_ids",
                "cancelled_prefill_ids",
                "decode_retired_ids",
            ):
                if key in value:
                    value[key] = [mapped(internal, rid) for rid in value[key]]
            normalized.append(value)
    require(
        {int(k): v for k, v in report["mixed_coverage"]["steps_per_batch"].items()}
        == {14: peer_rounds}
        and report["mixed_coverage"]["covered_batches"] == [14]
        and report["mixed_coverage"]["uncovered_batches"] == [],
        "Actual mixed-progress coverage differs",
    )
    return (
        rows,
        normalized,
        {
            "passed": True,
            "turns": len(rows) // 2,
            "decode_turns": len(sizes),
            "seed_advances": 1,
            "seed_layers": 40,
            "peer_advances": peer_rounds,
            "peer_layers": actual_layers,
            "ack_after_peer_advance": peer_rounds,
            "prefill_model_forwards": 2,
            "per_case_decode_retirements": dict(accumulated),
            "actual_decode_sizes": dict(Counter(sizes)),
            "expected_descriptor_histogram": dict(
                Counter(next(n for n in (1, 2, 4, 8) if n >= v) for v in sizes)
            ),
            "descriptor_scope": "Derived from actual D counts and frozen padding sizes; not direct per-replay tracing.",
        },
    )


def compare(left, right):
    a = {r["case_id"]: r for r in left["outputs"]}
    b = {r["case_id"]: r for r in right["outputs"]}
    require(
        set(a) == set(b) == set(CASE_IDS), "Complete8 comparison cardinality differs"
    )
    rows = []
    for case in CASE_IDS:
        x, y = a[case], b[case]
        equal = {
            k: x.get(k) == y.get(k)
            for k in (
                "token_ids",
                "text",
                "finish_reason",
                "stop_reason",
                "finished",
                "error",
            )
        }
        rows.append(
            {
                "case_id": case,
                "equal": all(equal.values()),
                "fields": equal,
                "first_token_difference": first_difference(
                    x["token_ids"], y["token_ids"]
                ),
                "historical_or_left_tokens": len(x["token_ids"]),
                "fresh_or_right_tokens": len(y["token_ids"]),
            }
        )
    return {"all8_equal": all(r["equal"] for r in rows), "rows": rows}


def original_prefix(report, directory, batch, cases, events, checks):
    for key, workers in (
        ("prefix_initial", "worker_before"),
        ("prefix_final", "worker_after"),
    ):
        require(
            report[key] == [r["builtin_layout"] for r in report[workers]],
            "Worker/snapshot disagreement",
        )
    tracker = checks.PrefixTracker(
        report["prefix_initial"], report["layout_module_sha256"]
    )
    require(
        len(report["prefix_batches"]) == 1, "Exactly one per-batch snapshot required"
    )
    item = report["prefix_batches"][0]
    path = directory / "results/prefix-batch-14.json"
    require(
        {p.name for p in (directory / "results").glob("prefix-batch-*.json")}
        == {path.name}
        and Path(item["path"]).resolve() == path.resolve()
        and sha(path) == item["sha256"],
        "Original single snapshot path/hash differs",
    )
    snapshot = read(path)
    require(snapshot["batch_id"] == item["batch_id"] == 14, "Snapshot batch differs")
    actual = tracker.append(
        snapshot["rows"], batch, report["admissions"], events, cases
    )
    require(
        actual == item["validation"]
        and checks.validate_final_snapshot(report["prefix_final"], tracker)
        == report["prefix_validation"]
        and tracker.total_cohorts == 2,
        "Original PrefixTracker replay differs",
    )
    proof = {
        "terminal_process_proven": True,
        "exit_code": 0,
        "owned_processes": [],
        "controller_forced_cleanup": False,
        "forced_termination": False,
        "devices_idle": True,
    }
    life = checks.audit_terminal(
        directory / "process.log",
        proof,
        report["prefix_final"],
        report["layout_module_sha256"],
    )
    return {
        "passed": True,
        "cohorts": 2,
        "original_reductions_each": 81,
        "single_snapshot_sha256": sha(path),
        "lifecycle": life,
    }


def reference_terminal(path, modern):
    if modern:
        return terminal(path)
    row = read(path / "controller.json")
    require(
        row.get("passed") is True
        and row.get("exit_code") == 0
        and row.get("owned_members_after_cleanup") == []
        and not row.get("errors")
        and not row.get("forced_termination", False),
        "Legacy q4 reference not terminal clean",
    )
    return row


def audit(bundle, declared):
    # No access to omitted attempt paths: q4-only does not stat or read q40.
    require(
        [a for a, _ in declared] in (["q4"], ["q4", "q40"]),
        "Only q4 single or ordered complete pair supported",
    )
    controllers = {arm: terminal(directory) for arm, directory in declared}
    freeze = read(bundle / "freeze-manifest-v1.json")
    require(
        freeze["status"] == "frozen"
        and len(freeze["files"]) == 30
        and set(freeze["declared_attempts"]) == {"q4", "q40"}
        and freeze["source_reference_identity_sha256"] == IDENTITY_SHA,
        "Exact frozen two-arm declaration required",
    )
    for arm, directory in declared:
        c = controllers[arm]
        declaration = freeze["declared_attempts"][arm]
        require(
            directory.resolve() == Path(declaration["directory"]).resolve()
            and directory.name == declaration["label"] == LABELS[arm] == c["label"],
            "Unexpected attempt or selected retry",
        )
        require(
            c["schema"] == "muxpd-q4-q40-batch14-controller-v1"
            and c["arm"] == arm
            and c["scope"] == "batch14"
            and c["files"] == freeze["files"]
            and c["source_reference_identity_sha256"] == IDENTITY_SHA,
            "Controller role/producer map changed",
        )
        for name, digest_value in freeze["files"].items():
            require(
                sha(bundle / name)
                == sha(directory / "producer" / name)
                == digest_value,
                "Actual30 producer bytes changed: " + name,
            )
        require(
            sha(bundle / "freeze-manifest-v1.json")
            == sha(directory / "producer/freeze-manifest-v1.json")
            == c["freeze_manifest_sha256"],
            "Archived freeze changed",
        )
        require(
            c["terminal_assessment"]["passed"] is True
            and c["terminal_assessment"]["child_sha256"]
            == sha(directory / "results/run.json"),
            "Controller/actual child SHA disagreement",
        )
    refs = read(bundle / "batch14-pair-references-v1.json")
    builtin_dir = Path(refs["builtin_q40_directory"])
    reference_terminal(builtin_dir, True)
    historical_dirs = {
        arm: Path(refs["historical_q4_directory"]) if arm == "q4" else builtin_dir
        for arm, _ in declared
    }
    for arm, path in historical_dirs.items():
        reference_terminal(path, arm == "q40")
    # Historical references are immutable predecessors, never future attempts.
    for item in refs["documents"].values():
        require(sha(item["path"]) == item["sha256"], "Reference document changed")
    for path, expected in refs["files"].items():
        require(sha(path) == expected, "Frozen historical source/raw bytes changed")
    independent = read(refs["documents"]["external_independent"]["path"])
    primary = read(refs["documents"]["external_primary"]["path"])
    require(
        independent["passed"]
        and independent["port_equivalence_passed"]
        and primary["passed"]
        and primary["port_equivalence_passed"],
        "External32 bridge prerequisite missing",
    )
    require(
        refs["full200_allowed"] is False
        and independent["answer_quality_accepted"] is False,
        "Diagnostic cannot become full-quality acceptance",
    )
    require(
        sha(bundle / "source-reference-identity-v1.json") == IDENTITY_SHA,
        "Source identity bytes changed",
    )
    identity = read(bundle / "source-reference-identity-v1.json")
    runtime = Path(identity["source_root"])
    git = lambda *args: subprocess.check_output(
        ["git", "-C", str(runtime), *args], text=True
    ).strip()
    require(
        git("rev-parse", "HEAD")
        == identity["candidate_commit"]
        == "a05029484b2c9bc21e4e6fd705cc396d111dfaa5"
        and not git("status", "--porcelain"),
        "Runtime source not exact clean reference",
    )
    require(
        {n: sha(runtime / n) for n in git("ls-files", "--", "src").splitlines()}
        == identity["runtime_files"],
        "Actual complete runtime src bytes changed",
    )
    review = identity["reviewed_diff"]
    diff = subprocess.check_output(
        [
            "git",
            "-C",
            str(runtime),
            "diff",
            "--binary",
            review["base_commit"],
            identity["candidate_commit"],
        ]
    )
    require(
        hashlib.sha256(diff).hexdigest() == review["sha256"]
        and Path(review["path"]).read_bytes() == diff,
        "Runtime reviewed diff changed",
    )
    sys.path.insert(0, str(bundle))
    checks = load_original(
        bundle / "candidate_checks_v1.py", "independent_frozen_checks", CHECKS_SHA
    )
    scorer = load_original(
        bundle / "score_quality.py", "independent_frozen_scorer", SCORER_SHA
    )
    from probe_control_v1 import inventory
    from tokenizers import Tokenizer

    baseline = read(builtin_dir / "results/run.json")
    for name in ("vllm", "vllm_ascend"):
        require(
            checks.repository_identity(baseline["sources"][name]["path"])
            == baseline["sources"][name],
            "Actual fixed native/Ascend identity changed",
        )
    model = identity["model_config_identity"]
    require(sha(model["path"]) == model["sha256"], "Model bytes changed")
    plan, cases, extract = scorer.load_frozen(bundle / "frozen-v2")
    batch = plan["batches"][14]
    require(
        plan["case_count"] == 200
        and batch["case_ids"] == CASE_IDS
        and batch["batch_id"] == 14
        and plan["sampling"]["max_tokens"] == 8192,
        "Original batch14/materialization changed",
    )
    selected = [c for c in cases if c["case_id"] in CASE_IDS]
    tokenfile = plan["tokenizer_files"]["tokenizer.json"]
    require(sha(tokenfile["path"]) == tokenfile["sha256"], "Tokenizer changed")
    decoder = Tokenizer.from_file(tokenfile["path"])
    vocab = decoder.get_vocab_size()
    reports = {}
    result = {
        "schema": "muxpd-batch14-independent-terminal-v1",
        "passed": True,
        "collection_checks_passed": True,
        "analysis_arms": [arm for arm, _ in declared],
        "arms": {},
        "answer_quality_accepted": False,
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "known_builtin_new_wrong": ["mmlu-pro-01741"],
        "errors": [],
        "scope": "Independent natural complete8 diagnostic. History mismatches are valid results, not collection failure; no posterior32/full200 acceptance.",
    }
    for arm, directory in declared:
        c = controllers[arm]
        r = read(directory / "results/run.json")
        reports[arm] = r
        require(
            r["schema"] == "muxpd-q4-q40-batch14-run-v1"
            and r["profile"] == "builtin-batch14-quota-diagnostic"
            and r["arm"] == arm
            and r["scope"] == "batch14"
            and r["selected_batch_ids"] == [14]
            and r["selected_case_ids"] == CASE_IDS
            and r["passed"]
            and r["collection_complete"]
            and r["shutdown_returned"]
            and not r["errors"]
            and not r.get("failure_cleanup")
            and not r["terminal_maintenance"]["aborted_internal_ids"],
            "Actual collection/scope/lifecycle differs",
        )
        require(
            "candidate_identity" not in r
            and r["source_reference_identity"]
            == r["source_after_startup"]
            == r["sources_after_shutdown"]
            == c["source_preflight"]
            == baseline["candidate_identity"]
            and r["source_reference_identity"]["candidate_manifest"] == identity,
            "Source reference provenance differs",
        )
        require(
            r["model_config_before_startup"] == r["model_config_after_startup"] == model
            and r["runtime_environment"] == baseline["runtime_environment"]
            and r["tokenizer_files"] == baseline["tokenizer_files"],
            "Actual environment/model receipts differ",
        )
        quota = 4 if arm == "q4" else 40
        for key in ("base_engine_args", "engine_args"):
            expected = copy.deepcopy(baseline[key])
            expected["batch_admission_policy_config"]["layers_per_slice"] = quota
            require(
                canonical(r[key]) == canonical(expected),
                "Configuration changed beyond quota40-to4",
            )
        require(
            r["base_engine_args"] == c["launch_engine_args"]
            and type(
                r["engine_args"]["batch_admission_policy_config"]["layers_per_slice"]
            )
            is int,
            "Launch/resolved quota differs",
        )
        require(
            r["arm_treatment"] == c["arm_treatment"]
            and r["arm_treatment"]["layers_per_slice"] == quota
            and r["arm_treatment"]["quality_candidate"] is False
            and r["arm_treatment"]["policy_overrides"]
            == (
                [{"key": "layers_per_slice", "from": 40, "to": 4}]
                if arm == "q4"
                else []
            )
            and r["arm_treatment"]["treatment_profile_sha256"]
            == sha(bundle / "batch14-treatment-v1.json"),
            "Explicit arm receipt differs",
        )
        for name, field in (
            ("batch14_pair_run_v1.py", "producer_sha256"),
            ("run_quality.py", "original_producer_sha256"),
            ("score_quality.py", "original_scorer_sha256"),
            ("source-manifest-v1.json", "source_manifest_sha256"),
        ):
            require(
                r[field] == freeze["files"][name],
                "Actual producer/scorer receipt differs",
            )
        require(
            r["layout_module_sha256"]
            == identity["runtime_files"]["src/vllm_muxpd/prefill_collective_layout.py"],
            "Builtin module identity differs",
        )
        for side in ("before", "after"):
            require(
                inventory((directory / f"npu-{side}.txt").read_text()) == PHYSICAL,
                "Saved idle-device receipt differs",
            )
        all_ids, internal, external = bind(r)
        events, semantic, scheduled = quota_schedule(r, directory, arm, cases, internal)
        outputs = validate_outputs(r, CASE_IDS, decoder, vocab)
        for case, row in outputs.items():
            require(
                row["request_id"] == external[case]
                and mapped(all_ids, row["request_id"]) == case,
                "Actual output request ID/case binding differs",
            )
            require(
                len(row["token_ids"])
                == 1 + scheduled["per_case_decode_retirements"].get(case, 0),
                "Actual generated tokens differ from one P token plus D retirements",
            )
            require(
                row["finish_reason"] != "length" or len(row["token_ids"]) == 8192,
                "Length stop before original cap",
            )
        graph = workers_and_graph(r, events)
        for stage in ("worker_before", "worker_after"):
            for w in r[stage]:
                require(
                    w["worker_source_path"]
                    == str(runtime / "src/vllm_muxpd/decoupled_worker.py")
                    and not any(w["foreign_diagnostic_state"].values()),
                    "Foreign observer/worker source differs",
                )
        prefix = original_prefix(r, directory, batch, cases, events, checks)
        history = read(historical_dirs[arm] / "results/run.json")
        history["outputs"] = [
            row for row in history["outputs"] if row["case_id"] in CASE_IDS
        ]
        validate_outputs(history, CASE_IDS, decoder, vocab)
        historical_score = scorer.score(history, plan, selected, extract)
        fresh_score = scorer.score(r, plan, selected, extract)
        result["arms"][arm] = {
            "passed": True,
            "controller_sha256": sha(directory / "controller.json"),
            "child_sha256": sha(directory / "results/run.json"),
            "history_directory": str(historical_dirs[arm]),
            "history_comparison": compare(history, r),
            "historical_score": historical_score,
            "fresh_score": fresh_score,
            "scores_equal": historical_score == fresh_score,
            "schedule": scheduled,
            "semantic_schedule_sha256": digest(semantic),
            "graph": graph,
            "prefix": prefix,
            "actual_output_request_and_retirement_binding": True,
        }
    result["all_requested_historical_trajectories_reproduced"] = all(
        v["history_comparison"]["all8_equal"] for v in result["arms"].values()
    )
    if len(declared) == 2:
        a, b = controllers["q4"], controllers["q40"]
        ra, rb = reports["q4"], reports["q40"]
        require(
            datetime.fromisoformat(b["started_at"])
            > datetime.fromisoformat(a["finished_at"])
            and a["controller_pid"] != b["controller_pid"]
            and a["process_group"] != b["process_group"]
            and ra["process_id"] != rb["process_id"],
            "New pair not two sequential fresh processes",
        )
        predecessor = b["predecessor_qualification"]
        require(
            a["predecessor_qualification"] is None
            and predecessor["ready"] is True
            and predecessor["controller_sha256"]
            == sha(dict(declared)["q4"] / "controller.json")
            and predecessor["child_sha256"]
            == sha(dict(declared)["q4"] / "results/run.json"),
            "q40 predecessor binding differs",
        )
        result["fresh_pair_comparison"] = compare(ra, rb)
        result["fresh_process_chronology_passed"] = True
    else:
        require(
            controllers["q4"]["predecessor_qualification"] is None,
            "q4 cannot depend on future q40",
        )
        result["future_q40_directory_accessed"] = False
    result["provenance"] = {
        "script_sha256": sha(__file__),
        "freeze_manifest_sha256": sha(bundle / "freeze-manifest-v1.json"),
        "producer_count": 30,
        "source_reference_identity_sha256": IDENTITY_SHA,
        "scorer_sha256": SCORER_SHA,
        "original_checks_sha256": CHECKS_SHA,
        "references_sha256": sha(bundle / "batch14-pair-references-v1.json"),
    }
    result["interpretation"] = (
        "Complete old trajectories reproduced for all requested arms; only a completed pair establishes the bounded fresh-batch quota contrast."
        if result["all_requested_historical_trajectories_reproduced"]
        else "At least one old trajectory differs; retain all results and the unresolved history/source confound."
    )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--q4", type=Path, required=True)
    parser.add_argument("--q40", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Never overwrite original independent assessment")
    declared = [("q4", args.q4)] + ([("q40", args.q40)] if args.q40 else [])
    try:
        result = audit(args.bundle, declared)
    except (
        OSError,
        ValueError,
        KeyError,
        TypeError,
        RuntimeError,
        subprocess.SubprocessError,
    ) as error:
        result = {
            "schema": "muxpd-batch14-independent-terminal-v1",
            "passed": False,
            "collection_checks_passed": False,
            "analysis_arms": [a for a, _ in declared],
            "answer_quality_accepted": False,
            "full_quality_gate_attempted": False,
            "errors": [f"{type(error).__name__}: {error}"],
        }
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                k: result.get(k)
                for k in (
                    "passed",
                    "collection_checks_passed",
                    "analysis_arms",
                    "all_requested_historical_trajectories_reproduced",
                    "answer_quality_accepted",
                    "full_quality_gate_attempted",
                    "errors",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
