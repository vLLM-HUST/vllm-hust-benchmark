"""Actual terminal metadata through real serializers; explicitly CPU synthetic.

The fixture is not model evidence. Real q4/q40 complete batch14 outputs and
scheduler records are re-rooted into a fresh temporary two-arm declaration.
Builtin geometry comes from real builtin batch14 snapshots; original mapper,
serializer, lifecycle parser, scorer and terminal analyzer are exercised.
"""

import copy
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from tokenizers import Tokenizer

import analyze_batch14_pair_v1 as entry
import batch14_pair_analysis_v1 as analysis
import batch14_pair_control_v1 as control
import batch14_pair_run_v1 as driver
import batch14_treatment_v1 as treatment
import candidate_checks_v1 as checks

BUNDLE = Path(__file__).parent
BUILTIN = Path(
    "/root/workspace/muxpd-runtime-quality-candidate-v2-20261030/runs-v1/prefix-q40-runtime-posterior32-v1-01"
)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def replace_ids(value, mapping):
    if isinstance(value, dict):
        return {mapping.get(k, k): replace_ids(v, mapping) for k, v in value.items()}
    if isinstance(value, list):
        return [replace_ids(v, mapping) for v in value]
    return mapping.get(value, value) if isinstance(value, str) else value


@pytest.fixture(scope="module")
def fixture(tmp_path_factory):
    refs, refproof = analysis.verify_references(BUNDLE)
    source_paths = {"q4": Path(refs["historical_q4_directory"]), "q40": BUILTIN}
    # Every source controller is checked before either source child is opened.
    for directory in source_paths.values():
        c = analysis.read(directory / "controller.json")
        assert (
            c["passed"]
            and c["exit_code"] == 0
            and c["owned_members_after_cleanup"] == []
        )
    root = tmp_path_factory.mktemp("explicit-cpu-synthetic-batch14-pair")
    bundle = root / "bundle"
    bundle.mkdir()
    for name in control.FILES:
        p = bundle / name
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(BUNDLE / name, p)
    directories = {arm: root / "runs" / treatment.LABELS[arm] for arm in treatment.ARMS}
    files = {name: analysis.sha(bundle / name) for name in control.FILES}
    freeze = {
        "status": "frozen",
        "files": files,
        "source_reference_identity_sha256": treatment.SOURCE_REFERENCE_SHA,
        "declared_attempts": {
            arm: {"directory": str(d), "label": treatment.LABELS[arm]}
            for arm, d in directories.items()
        },
        "fixture_only": True,
    }
    save(bundle / "freeze-manifest-v1.json", freeze)
    raw = analysis.read(BUILTIN / "results/run.json")
    base_controller = analysis.read(BUILTIN / "controller.json")
    builtin_admissions = [a for a in raw["admissions"] if a["batch_id"] == 14]
    builtin_ids = {
        b["case_id"]: b["internal"] for a in builtin_admissions for b in a["bindings"]
    }
    final_templates = analysis.read(BUILTIN / "results/prefix-batch-14.json")["rows"]
    original_final = []
    for line in (BUILTIN / "process.log").read_text().splitlines():
        marker = "MuxPD prefix layout final "
        if marker in line:
            original_final.append(json.loads(line.split(marker, 1)[1]))
    assert len(original_final) == 4
    start = datetime.fromisoformat(base_controller["finished_at"]) + timedelta(
        seconds=10
    )
    for i, arm in enumerate(treatment.ARMS):
        directory = directories[arm]
        results = directory / "results"
        results.mkdir(parents=True)
        historic = analysis.read(source_paths[arm] / "results/run.json")
        receipts = [
            json.loads(line)
            for line in (source_paths[arm] / "results/scheduler-receipts.jsonl")
            .read_text()
            .splitlines()
        ]
        receipts = [r for r in receipts if r["batch_id"] == 14]
        offset = receipts[0]["global_step"] - 1
        for row in receipts:
            row["global_step"] -= offset
        admissions = copy.deepcopy(
            [a for a in historic["admissions"] if a["batch_id"] == 14]
        )
        for row in admissions:
            row["global_step"] -= offset
        ids = {b["case_id"]: b["internal"] for a in admissions for b in a["bindings"]}
        mapping = {rid: ids[case] for case, rid in builtin_ids.items()}
        _plan, cases, batches, config, manifest, source = driver.prepare(
            "batch14",
            Path("/root/workspace/muxpd-prefix-q40-runtime"),
            bundle / "source-reference-identity-v1.json",
            arm,
            bundle,
        )
        report = copy.deepcopy(raw)
        report.pop("candidate_identity")
        report.update(
            schema="muxpd-q4-q40-batch14-run-v1",
            profile="builtin-batch14-quota-diagnostic",
            scope="batch14",
            arm=arm,
            arm_treatment=treatment.treatment_receipt(arm, bundle),
            source_reference_identity=source,
            selected_batch_ids=[14],
            selected_case_ids=treatment.CASE_IDS,
            prefix_batches=[],
            outputs=[
                r for r in historic["outputs"] if r["case_id"] in treatment.CASE_IDS
            ],
            admissions=admissions,
            answer_engine_steps=len(receipts) // 2,
            base_engine_args=config,
            producer_sha256=analysis.sha(bundle / "batch14_pair_run_v1.py"),
            cpu_synthetic_fixture=True,
        )
        resolved = checks.original_manifest(bundle)["historical_runs"][
            "raw-quality-v2-hccl-true-01"
        ]["engine_args"]
        report["engine_args"] = treatment.apply_arm_config(
            resolved, manifest["candidate"], arm
        )
        report["process_id"] += 1000000 + i
        moment = start + timedelta(seconds=10 * i)
        report["started_at"] = moment.isoformat()
        report["finished_at"] = (moment + timedelta(seconds=2)).isoformat()
        report["mixed_coverage"].update(
            steps_per_batch={"14": 10 if arm == "q4" else 1},
            covered_batches=[14],
            uncovered_batches=[],
        )
        final = copy.deepcopy(final_templates)
        for row in final:
            row["recent_cohorts"] = replace_ids(row["recent_cohorts"][-2:], mapping)
            for ordinal, cohort in enumerate(row["recent_cohorts"], 1):
                cohort["cohort_id"] = ordinal
            row["stats"] = {
                "admitted": 2,
                "closed": 2,
                "admission_failed": 0,
                "treated": 1,
                "transformed_calls": 81,
                "zero_d_calls": 81,
            }
            row["treated_cohorts"] = 1
            row["history_is_complete"] = True
        report["prefix_final"] = final
        for rank in range(4):
            for key in ("worker_before", "worker_after"):
                report[key][rank]["runtime"]["policy"] = copy.deepcopy(
                    report["engine_args"]["batch_admission_policy_config"]
                )
            report["worker_after"][rank]["builtin_layout"] = copy.deepcopy(final[rank])
            before = report["worker_before"][rank]["decode_graph_snapshot"]
            after = copy.deepcopy(before)
            after["decode_replay_calls"] += len(receipts) // 2 - 1
            after["prefill_forced_eager_calls"] += 2
            report["worker_after"][rank]["decode_graph_snapshot"] = after
        history_path = results / "scheduler-receipts.jsonl"
        history_path.write_text("".join(json.dumps(row) + "\n" for row in receipts))
        report["scheduler_receipts_sha256"] = analysis.sha(history_path)
        tracker = checks.PrefixTracker(
            report["prefix_initial"], report["layout_module_sha256"]
        )
        calls = []

        def rpc(*args, captured_calls=calls, snapshot=final, **kwargs):
            captured_calls.append((args, kwargs))
            return copy.deepcopy(snapshot)

        checks.save_batch_snapshot(
            SimpleNamespace(collective_rpc=rpc),
            tracker,
            report,
            results,
            batches[0],
            cases,
        )
        assert len(calls) == 1 and calls[0][0][0] is checks.builtin_snapshot
        report["prefix_validation"] = checks.validate_final_snapshot(final, tracker)
        lines = ["Explicit CPU synthetic fixture; no model executed."]
        lines += [
            "MuxPD prefix layout startup " + json.dumps(r)
            for r in report["prefix_initial"]
        ]
        for original in original_final:
            item = copy.deepcopy(original)
            item["stats"] = copy.deepcopy(final[item["rank"]]["stats"])
            item["retained_history_size"] = 2
            item["history_is_complete"] = True
            lines.append("MuxPD prefix layout final " + json.dumps(item))
        (directory / "process.log").write_text("\n".join(lines) + "\n")
        for name in ("npu-before.txt", "npu-after.txt"):
            shutil.copyfile(BUILTIN / name, directory / name)
        shutil.copytree(bundle, directory / "producer")
        controller = copy.deepcopy(base_controller)
        controller.update(
            schema="muxpd-q4-q40-batch14-controller-v1",
            scope="batch14",
            arm=arm,
            profile="builtin-batch14-quota-diagnostic",
            label=treatment.LABELS[arm],
            destination=str(directory),
            arm_treatment=report["arm_treatment"],
            source_preflight=source,
            source_reference_identity_sha256=treatment.SOURCE_REFERENCE_SHA,
            source_reference_identity_path=str(
                bundle / "source-reference-identity-v1.json"
            ),
            references_qualification=refproof,
            files=files,
            freeze_manifest_sha256=analysis.sha(bundle / "freeze-manifest-v1.json"),
            bundle_frozen=True,
            selected_batch_ids=[14],
            selected_case_count=8,
            launch_engine_args=config,
            started_at=report["started_at"],
            finished_at=report["finished_at"],
            predecessor_qualification=None,
            cpu_synthetic_fixture=True,
        )
        controller["controller_pid"] += 1000000 + i
        controller["process_group"] += 1000000 + i
        if arm == "q40":
            controller["predecessor_qualification"] = control.predecessor_gate(
                SimpleNamespace(arm=arm, output_root=directory.parent, command="run"),
                analysis.sha(bundle / "freeze-manifest-v1.json"),
            )
        save(results / "run.json", report)
        controller["terminal_assessment"] = control.terminal_assessment(
            directory, controller
        )
        save(directory / "controller.json", controller)
    return bundle, directories


def test_both_real_serializers_through_terminal_analyzer(fixture):
    bundle, dirs = fixture
    result = entry.analyze(
        list(dirs.items()), bundle, bundle / "analysis-pair-fixture-v1.json"
    )
    assert result["errors"] == []
    assert result["passed"] is True and result["runtime_collection_qualified"] is True
    assert (
        result["comparison"]["all_requested_historical_trajectories_reproduced"] is True
    )
    assert result["comparison"]["fresh_pair_outputs"]["all8_equal"] is False
    schedules = result["qualification"]["attempts"]
    assert schedules["q4"]["schedule"]["peer_prefill_advancements"] == 10
    assert schedules["q40"]["schedule"]["peer_prefill_advancements"] == 1
    assert result["full_quality_gate_attempted"] is False


def test_q4_trajectory_mismatch_remains_qualified_collection(fixture):
    bundle, dirs = fixture
    directory = dirs["q4"]
    path = directory / "results/run.json"
    report = analysis.read(path)
    target = next(r for r in report["outputs"] if r["case_id"] == "mmlu-pro-01741")
    target["token_ids"][57] += 1
    tokenizer = Tokenizer.from_file(report["tokenizer_files"]["tokenizer.json"]["path"])
    target["text"] = tokenizer.decode(target["token_ids"], skip_special_tokens=True)
    save(path, report)
    controller = analysis.read(directory / "controller.json")
    controller["terminal_assessment"] = control.terminal_assessment(
        directory, controller
    )
    save(directory / "controller.json", controller)
    result = entry.analyze(
        [("q4", directory)], bundle, bundle / "analysis-q4-mismatch-fixture-v1.json"
    )
    assert result["errors"] == [] and result["runtime_collection_qualified"] is True
    assert result["passed"] is True
    assert (
        result["comparison"]["all_requested_historical_trajectories_reproduced"]
        is False
    )
    assert result["comparison"]["arms"]["q4"]["historical_trajectory"][
        "different_case_ids"
    ] == ["mmlu-pro-01741"]
    assert result["full_quality_gate_attempted"] is False
