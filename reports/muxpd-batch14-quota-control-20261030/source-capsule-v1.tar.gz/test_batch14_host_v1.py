import ast
import copy
import importlib
import json
from pathlib import Path

import pytest

BUNDLE = Path(__file__).resolve().parent


def treatment():
    return importlib.import_module("batch14_treatment_v1")


def inputs():
    import candidate_checks_v1 as old

    identity = json.loads((BUNDLE / "source-reference-identity-v1.json").read_text())
    history = old.original_manifest()["historical_runs"]["raw-quality-v2-hccl-true-01"][
        "engine_args"
    ]
    return old, identity, history


@pytest.mark.parametrize("arm,quota", [("q4", 4), ("q40", 40)])
def test_arm_only_changes_declared_quota(arm, quota):
    old, identity, history = inputs()
    initial = copy.deepcopy(history)
    expected = old.apply_policy_changes(history, identity)
    actual = treatment().apply_arm_config(history, identity, arm)
    assert history == initial
    assert actual["batch_admission_policy_config"]["layers_per_slice"] == quota
    actual["batch_admission_policy_config"]["layers_per_slice"] = 40
    assert actual == expected
    receipt = treatment().treatment_receipt(arm)
    assert receipt["arm"] == arm
    assert receipt["quality_candidate"] is False
    assert receipt["policy_overrides"] == (
        [{"key": "layers_per_slice", "from": 40, "to": 4}] if arm == "q4" else []
    )


@pytest.mark.parametrize("arm", ["Q4", "full", "", 4, None])
def test_unknown_arm_rejected(arm):
    _, identity, history = inputs()
    with pytest.raises(ValueError):
        treatment().apply_arm_config(history, identity, arm)


@pytest.mark.parametrize("quota", [4.0, True, 40])
def test_reference_config_cannot_be_reinterpreted(quota):
    _, identity, history = inputs()
    history["batch_admission_policy_config"]["layers_per_slice"] = quota
    with pytest.raises(ValueError):
        treatment().apply_arm_config(history, identity, "q4")


def test_only_original_batch14_is_selected():
    from score_quality import load_frozen

    plan, _, _ = load_frozen(BUNDLE / "frozen-v2")
    selected = treatment().select_batches(plan, "batch14")
    assert [b["batch_id"] for b in selected] == [14]
    assert selected[0]["case_ids"] == [
        "mmlu-pro-" + x
        for x in (
            "01557",
            "01619",
            "01680",
            "01741",
            "01802",
            "01862",
            "01923",
            "01984",
        )
    ]
    for scope in ("full", "posterior32"):
        with pytest.raises(ValueError):
            treatment().select_batches(plan, scope)
    plan["batches"][14]["case_ids"].reverse()
    with pytest.raises(ValueError):
        treatment().select_batches(plan, "batch14")


def test_collector_natural_batch_loop_is_original_ast():
    def run(path):
        return next(
            n
            for n in ast.parse(path.read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == "run"
        )

    old = run(BUNDLE / "candidate_run_v1.py")
    new = run(BUNDLE / "batch14_pair_run_v1.py")
    loops = lambda n: [
        ast.dump(x, include_attributes=False)
        for x in ast.walk(n)
        if isinstance(x, ast.While)
    ]
    assert loops(old) == loops(new)
    batch = lambda n: next(
        x
        for x in ast.walk(n)
        if isinstance(x, ast.For)
        and isinstance(x.target, ast.Name)
        and x.target.id == "batch"
    )
    assert ast.dump(batch(old), include_attributes=False) == ast.dump(
        batch(new), include_attributes=False
    )


def test_controller_terminal_first(tmp_path, monkeypatch):
    c = importlib.import_module("batch14_pair_control_v1")

    def forbidden(*args, **kwargs):
        raise AssertionError("Nonterminal child read")

    monkeypatch.setattr(Path, "read_text", forbidden)
    with pytest.raises(ValueError, match="terminal proof"):
        c.terminal_assessment(tmp_path, {"terminal_process_proven": False})


@pytest.mark.parametrize("arm", ["q4", "q40"])
def test_actual_source_prepare_and_worker_policy(arm):
    from batch14_pair_run_v1 import prepare

    _, _, batches, config, manifest, identity = prepare(
        "batch14",
        Path("/root/workspace/muxpd-prefix-q40-runtime"),
        BUNDLE / "source-reference-identity-v1.json",
        arm,
    )
    assert [b["batch_id"] for b in batches] == [14]
    assert (
        identity["sources"]["vllm_muxpd"]["commit"]
        == "a05029484b2c9bc21e4e6fd705cc396d111dfaa5"
    )
    assert manifest["arm_treatment"] == treatment().treatment_receipt(arm)
    report = json.loads(
        Path(
            "/root/workspace/muxpd-runtime-quality-candidate-v2-20261030/runs-v1/prefix-q40-runtime-posterior32-v1-01/results/run.json"
        ).read_text()
    )
    rows = copy.deepcopy(report["worker_before"])
    for row in rows:
        row["runtime"]["policy"] = copy.deepcopy(
            config["batch_admission_policy_config"]
        )
    treatment().validate_arm_workers(rows, manifest["candidate"], arm)
    rows[0]["runtime"]["policy"]["layers_per_slice"] = float(
        config["batch_admission_policy_config"]["layers_per_slice"]
    )
    with pytest.raises(ValueError):
        treatment().validate_arm_workers(rows, manifest["candidate"], arm)


def test_worker_four_rank_gate():
    _, identity, _ = inputs()
    with pytest.raises(ValueError):
        treatment().validate_arm_workers([], identity, "q4")


def test_prepare_binds_exact_source_reference_bytes(tmp_path):
    from batch14_pair_run_v1 import prepare

    path = tmp_path / "different-serialization.json"
    path.write_text(
        json.dumps(
            json.loads((BUNDLE / "source-reference-identity-v1.json").read_text()),
            separators=(",", ":"),
        )
    )
    with pytest.raises(ValueError, match="source reference bytes"):
        prepare("batch14", Path("/root/workspace/muxpd-prefix-q40-runtime"), path, "q4")


def test_predecessor_pending_and_terminal_first(tmp_path, monkeypatch):
    from types import SimpleNamespace

    import batch14_pair_control_v1 as c

    args = SimpleNamespace(arm="q40", output_root=tmp_path, command="dry-run")
    assert c.predecessor_gate(args, None)["ready"] is False
    args.command = "run"
    with pytest.raises(ValueError, match="terminal controller"):
        c.predecessor_gate(args, None)
    root = tmp_path / c.LABELS["q4"]
    root.mkdir()
    (root / "controller.json").write_text(
        json.dumps({"terminal_process_proven": False})
    )

    def forbidden(*args, **kwargs):
        raise AssertionError("Nonterminal predecessor child read")

    monkeypatch.setattr(c, "terminal_assessment", forbidden)
    with pytest.raises(ValueError, match="terminal proof"):
        c.predecessor_gate(args, None)


def test_predecessor_accepts_collection_without_history_equality(tmp_path, monkeypatch):
    from types import SimpleNamespace

    import batch14_pair_control_v1 as c

    root = tmp_path / c.LABELS["q4"]
    root.mkdir()
    assessment = {
        "passed": True,
        "child_sha256": "child",
        "quality_qualification": False,
    }
    row = {
        "terminal_process_proven": True,
        "schema": "muxpd-q4-q40-batch14-controller-v1",
        "arm": "q4",
        "label": c.LABELS["q4"],
        "passed": True,
        "destination": str(root),
        "freeze_manifest_sha256": "freeze",
        "terminal_assessment": assessment,
    }
    (root / "controller.json").write_text(json.dumps(row))
    monkeypatch.setattr(c, "terminal_assessment", lambda *args: assessment)
    args = SimpleNamespace(arm="q40", output_root=tmp_path, command="run")
    assert c.predecessor_gate(args, "freeze")["ready"] is True
    with pytest.raises(ValueError, match="declaration"):
        c.predecessor_gate(args, "different-freeze")


def test_failure_finally_restores_hooks_before_abort_and_shutdown():
    # Exercise the unchanged actual finalizer with CPU spies; no runtime import.
    import batch14_pair_run_v1 as run

    source = ast.parse(Path(run.__file__).read_text())
    fn = next(
        n for n in source.body if isinstance(n, ast.FunctionDef) and n.name == "run"
    )
    final = next(n.finalbody for n in fn.body if isinstance(n, ast.Try))
    # Only the restore and llm cleanup block, before source/timestamp serialization.
    module = ast.fix_missing_locations(ast.Module(body=final[:2], type_ignores=[]))
    from types import SimpleNamespace

    order = []
    scheduler = SimpleNamespace(schedule="hook1", update_from_output="hook2")
    engine = SimpleNamespace(
        engine_core=SimpleNamespace(shutdown=lambda: order.append("shutdown"))
    )
    report = {"collection_complete": False, "errors": []}

    def abort(*args):
        assert (scheduler.schedule, scheduler.update_from_output) == (
            "original1",
            "original2",
        )
        order.append("abort")
        return {}

    def rpc(*args, **kwargs):
        order.append("rpc")
        return []

    ns = vars(run).copy()
    ns.update(
        scheduler=scheduler,
        originals=("original1", "original2"),
        llm=SimpleNamespace(llm_engine=engine, collective_rpc=rpc),
        report=report,
        baseline={},
        manifest={"candidate": {}},
        args=SimpleNamespace(arm="q4"),
        abort_and_drain=abort,
        scheduler_snapshot=lambda e: {},
        require_empty=lambda a, b: None,
        validate_arm_workers=lambda *a: (_ for _ in ()).throw(
            ValueError("partial ranks")
        ),
    )
    exec(compile(module, "<actual-finalizer>", "exec"), ns)  # noqa: S102 -- execute the reviewed CPU-only finalizer AST
    assert order == ["abort", "rpc", "shutdown"]
    assert report["shutdown_returned"] is True
    assert len(report["errors"]) == 1 and "partial ranks" in report["errors"][0]
