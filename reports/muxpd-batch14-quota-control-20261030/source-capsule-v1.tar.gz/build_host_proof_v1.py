import ast
import difflib
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent
BASE = Path('/root/workspace/muxpd-runtime-quality-candidate-v2-20261030')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def functions(p):
    return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n, ast.FunctionDef)}

def dump(n):
    return ast.dump(n, include_attributes=False)

old = functions(BASE/'candidate_run_v1.py')
new = functions(B/'batch14_pair_run_v1.py')
loops = lambda n: [dump(x) for x in ast.walk(n) if isinstance(x, ast.While)]
batch = lambda n: next(x for x in ast.walk(n) if isinstance(x, ast.For) and isinstance(x.target, ast.Name) and x.target.id == 'batch')
assert dump(batch(old['run'])) == dump(batch(new['run']))
assert loops(old['run']) == loops(new['run'])
assert dump(old['restore_receipts']) == dump(new['restore_receipts'])
cold = functions(BASE/'candidate_control_v1.py')
cnew = functions(B/'batch14_pair_control_v1.py')
assert dump(cold['environment']) == dump(cnew['environment'])
assert loops(cold['execute']) == loops(cnew['execute'])
assert (B/'candidate_checks_v1.py').read_bytes() == (BASE/'candidate_checks_v1.py').read_bytes()
files = ast.literal_eval(next(n.value for n in ast.parse((BASE/'candidate_control_v1.py').read_text()).body if isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'FILES' for t in n.targets)))
assert len(files) == 22
for name in files:
    assert (B/name).read_bytes() == (BASE/name).read_bytes(), name
proof = {
 'schema':'muxpd-batch14-host-source-proof-v1','passed':True,
 'base_bundle':str(BASE),'new_bundle':str(B),
 'baseline22_literal_equal':{name:sha(B/name) for name in files},
 'original_natural_batch_loop_ast_equal':True,
 'all_collector_while_loops_ast_equal':True,
 'controller_lifecycle_while_loops_ast_equal':True,
 'controller_environment_function_ast_equal':True,
 'scheduler_hook_restore_function_ast_equal':True,
 'prefix_tracker_and_snapshot_rpc_literal_equal':True,
 'original_collector_and_scorer_literal_equal':True,
 'changed_driver_functions':[name for name in old if dump(old[name]) != dump(new[name])],
 'changed_controller_functions':[name for name in cold if dump(cold[name]) != dump(cnew[name])],
 'producer_files':{name:sha(B/name) for name in ('batch14_pair_run_v1.py','batch14_pair_control_v1.py','batch14_treatment_v1.py','batch14-treatment-v1.json')},
 'scope':'Read-only source identity/model/env checks retained. New explicit batch14/arm config and truthful diagnostic metadata; no model math, runtime source, sampling, ingress, loop, warmup, per-batch RPC cadence or scorer change.',
}
(B/'host-source-proof-v1.json').write_text(json.dumps(proof,indent=2)+'\n')
for before,after in [('candidate_run_v1.py','batch14_pair_run_v1.py'),('candidate_control_v1.py','batch14_pair_control_v1.py')]:
    (B/(after+'.diff')).write_text(''.join(difflib.unified_diff((BASE/before).read_text().splitlines(keepends=True),(B/after).read_text().splitlines(keepends=True),fromfile=str(BASE/before),tofile=str(B/after))))
print('Source proof PASS; original22, natural loops and snapshot cadence preserved')
