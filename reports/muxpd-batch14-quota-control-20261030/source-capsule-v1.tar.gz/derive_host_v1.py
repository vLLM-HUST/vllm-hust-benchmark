import ast
import json
from pathlib import Path

B = Path(__file__).resolve().parent
sidecar = {
 'schema':'muxpd-batch14-quota-treatment-v1',
 'source_commit':'a05029484b2c9bc21e4e6fd705cc396d111dfaa5',
 'source_reference_identity_sha256':'8d04890973c369a5412e80cc08c6cb55ef405e9360bd38e2bfafa9b5d65fe4fe',
 'scope':'batch14', 'batch_ids':[14],
 'case_ids':['mmlu-pro-'+x for x in ('01557','01619','01680','01741','01802','01862','01923','01984')],
 'arms':{'q4':{'layers_per_slice':4,'policy_overrides':[{'key':'layers_per_slice','from':40,'to':4}]},'q40':{'layers_per_slice':40,'policy_overrides':[]}},
 'quality_candidate':False,
 'interpretation':'Fresh same-source batch14 quota contrast; no posterior32/full200 quality acceptance or performance claim.',
}
(B/'batch14-treatment-v1.json').write_text(json.dumps(sidecar,indent=2)+'\n')

s=(B/'candidate_run_v1.py').read_text()
s=s[s.index('import argparse'):]
s='"""Fresh natural batch14 quota diagnostic; source identity is provenance only."""\n\n'+s
s=s.replace('    SCOPES,\n','').replace('    apply_policy_changes,\n','').replace('    select_batches,\n','').replace('    validate_candidate_workers,\n','')
anchor='from score_quality import load_frozen\n'
s=s.replace(anchor,anchor+'from batch14_treatment_v1 import (ARMS, SCOPES, apply_arm_config, select_batches, treatment_receipt, validate_arm_workers)\n')
s=s.replace('def prepare(scope, source, identity_path, bundle=BUNDLE):','def prepare(scope, source, identity_path, arm, bundle=BUNDLE):')
s=s.replace('    manifest["candidate"] = candidate\n','    manifest["candidate"] = candidate\n    manifest["arm_treatment"] = treatment_receipt(arm, bundle)\n')
s=s.replace('apply_policy_changes(base, candidate)','apply_arm_config(base, candidate, arm)')
s=s.replace('args.scope, args.source, args.identity\n','args.scope, args.source, args.identity, args.arm\n')
s=s.replace('"muxpd-runtime-candidate-quality-run-v1"','"muxpd-q4-q40-batch14-run-v1"').replace('"canonical-runtime-candidate-prefix"','"builtin-batch14-quota-diagnostic"')
s=s.replace('        "scope": args.scope,\n','        "scope": args.scope,\n        "arm": args.arm,\n        "arm_treatment": manifest["arm_treatment"],\n',1)
s=s.replace('"candidate_identity": identity','"source_reference_identity": identity')
s=s.replace('"qualification_claim": "Collection only; posterior32 is a posterior diagnostic. Terminal lifecycle and unchanged scoring require independent validation; historical native completeness remains FAIL."','"qualification_claim": "Collection-only fresh batch14 diagnostic. Source identity is provenance; candidate posterior32 quality remains FAIL and full200 is withheld."')
s=s.replace('apply_policy_changes(expected_config, manifest["candidate"])','apply_arm_config(expected_config, manifest["candidate"], args.arm)')
s=s.replace('validate_candidate_workers(report["worker_before"], manifest["candidate"])','validate_arm_workers(report["worker_before"], manifest["candidate"], args.arm)')
s=s.replace('validate_candidate_workers(report["worker_after"], manifest["candidate"])','validate_arm_workers(report["worker_after"], manifest["candidate"], args.arm)')
s=s.replace('validate_candidate_workers(\n                        report["failure_worker_state"], manifest["candidate"]\n','validate_arm_workers(\n                        report["failure_worker_state"], manifest["candidate"], args.arm\n')
s=s.replace('    parser.add_argument("--scope", choices=SCOPES, required=True)\n','    parser.add_argument("--scope", choices=SCOPES, required=True)\n    parser.add_argument("--arm", choices=ARMS, required=True)\n')
s=s.replace('BUNDLE / "candidate-identity-template-v1.json"','BUNDLE / "source-reference-identity-v1.json"')
(B/'batch14_pair_run_v1.py').write_text(s)

s=(B/'candidate_control_v1.py').read_text()
s=s.replace('from candidate_run_v1 import BUNDLE, SCOPES, file_sha, now, prepare, save','from batch14_pair_run_v1 import BUNDLE, SCOPES, file_sha, now, prepare, save\nfrom batch14_treatment_v1 import ARMS, LABELS, treatment_receipt')
tree=ast.parse(s)
node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FILES' for t in n.targets))
files=ast.literal_eval(node.value)+('batch14_pair_run_v1.py','batch14_pair_control_v1.py','batch14_treatment_v1.py','batch14-treatment-v1.json','source-reference-identity-v1.json','batch14_pair_analysis_v1.py','analyze_batch14_pair_v1.py','batch14-pair-references-v1.json')
lines=s.splitlines(keepends=True); lines[node.lineno-1:node.end_lineno]=['FILES = '+repr(files)+'\n'];s=''.join(lines)
s=s.replace('child["candidate_identity"]','child["source_reference_identity"]')
s=s.replace('        child["passed"]\n','        child["schema"] == "muxpd-q4-q40-batch14-run-v1"\n        and child["arm"] == record["arm"]\n        and child["arm_treatment"] == record["arm_treatment"]\n        and child["passed"]\n')
s=s.replace('args.scope, args.source, args.identity, args.bundle','args.scope, args.source, args.identity, args.arm, args.bundle')
s=s.replace('    destination = args.output_root / args.label\n','    require(args.label == LABELS[args.arm], "Only the predeclared one-attempt arm label is permitted")\n    require(expected == ["3", "4", "5", "6"], "Declared physical placement changed")\n    destination = args.output_root / args.label\n')
s=s.replace('"candidate_identity_sha256"','"source_reference_identity_sha256"').replace('"candidate_identity_path"','"source_reference_identity_path"')
s=s.replace('    deadline = manifest["controller_deadline_seconds"]\n','    if frozen:\n        declared = json.loads(freeze.read_text())["declared_attempts"]\n        require(declared == {arm: {"directory": str((args.output_root / label).resolve()), "label": label} for arm, label in LABELS.items()}, "Frozen pair attempt paths differ")\n    from batch14_pair_analysis_v1 import verify_references\n    _, references = verify_references(args.bundle)\n    predecessor = predecessor_gate(args, file_sha(freeze) if frozen else None)\n    deadline = manifest["controller_deadline_seconds"]\n')
s=s.replace('"muxpd-runtime-candidate-quality-controller-v1"','"muxpd-q4-q40-batch14-controller-v1"').replace('"canonical-runtime-candidate-prefix"','"builtin-batch14-quota-diagnostic"')
s=s.replace('        "scope": args.scope,\n','        "scope": args.scope,\n        "arm": args.arm,\n        "arm_treatment": treatment_receipt(args.arm, args.bundle),\n        "references_qualification": references,\n        "predecessor_qualification": predecessor,\n',1)
s=s.replace('str(destination / "producer/candidate_run_v1.py")','str(destination / "producer/batch14_pair_run_v1.py")')
s=s.replace('            "--scope",\n','            "--arm",\n            args.arm,\n            "--scope",\n')
s=s.replace('producer/candidate-identity-v1.json','producer/source-reference-identity-v1.json')
s=s.replace('"qualification_claim": "Collection/lifecycle only; scoring is separate. Selected loss batches cannot pass the full200 gate."','"qualification_claim": "Fresh diagnostic only. Source identity is provenance, current q40 posterior32 quality remains FAIL; no full200 acceptance."')
s=s.replace('    parser.add_argument("--scope", choices=SCOPES, required=True)\n','    parser.add_argument("--scope", choices=SCOPES, required=True)\n    parser.add_argument("--arm", choices=ARMS, required=True)\n')
s=s.replace('BUNDLE / "candidate-identity-template-v1.json"','BUNDLE / "source-reference-identity-v1.json"').replace('BUNDLE / "candidate-runs-v1"','BUNDLE / "runs-v1"')
insert='''def predecessor_gate(args, freeze_sha):
    if args.arm == "q4":
        return None
    root = args.output_root / LABELS["q4"]
    path = root / "controller.json"
    if not path.exists() and args.command == "dry-run":
        return {"ready": False, "reason": "Predeclared q4 attempt has not run"}
    require(path.exists(), "q40 requires the predeclared q4 terminal controller")
    record = json.loads(path.read_text())
    require(record.get("terminal_process_proven") is True, "q4 terminal proof required before any predecessor child/log read")
    require(record.get("schema") == "muxpd-q4-q40-batch14-controller-v1" and record.get("arm") == "q4" and record.get("label") == LABELS["q4"] and record.get("passed") is True and record.get("destination") == str(root.resolve()) and record.get("freeze_manifest_sha256") == freeze_sha, "q4 predecessor declaration differs")
    assessment = terminal_assessment(root, record)
    require(record["terminal_assessment"] == assessment, "q4 saved terminal assessment changed")
    return {"ready": True, "controller_path": str(path.resolve()), "controller_sha256": file_sha(path), "child_sha256": assessment["child_sha256"], "historical_trajectory_equality_required": False}


'''
s=s.replace('def preview(args):\n',insert+'def preview(args):\n')
(B/'batch14_pair_control_v1.py').write_text(s)
print('Derived host; producer files',len(files))
