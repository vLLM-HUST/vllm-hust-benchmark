"""Terminal-only original batch14 natural q4/q40 diagnostic assessment."""

import argparse
import json
from pathlib import Path

import batch14_pair_analysis_v1 as core


def analyze(declared, bundle, output):
    core.require(not output.exists(), "Refuse to overwrite a prior assessment")
    result = {
        "schema": "muxpd-q4-q40-batch14-analysis-v1",
        "passed": False,
        "runtime_collection_qualified": False,
        "analysis_arms": [arm for arm, _ in declared],
        "full_quality_gate_attempted": False,
        "full_frozen_plan_passed": None,
        "errors": [],
        "scope": "Natural full8 quota diagnostic only. Collection success does not require historical reproduction or accept the failed q40 quality candidate.",
    }
    try:
        proof, values, refs = core.qualify_arms(declared, bundle)
        result["qualification"] = proof
        result["runtime_collection_qualified"] = True
        result["comparison"] = core.assess_values(values, refs, bundle)
        result["passed"] = True
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=("q4", "q40"))
    parser.add_argument("--run", type=Path)
    parser.add_argument("--q4", type=Path)
    parser.add_argument("--q40", type=Path)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.arm or args.run:
        if not (args.arm and args.run) or args.q4 or args.q40:
            parser.error("Single-arm mode requires only --arm and --run")
        declared = [(args.arm, args.run)]
    else:
        if not (args.q4 and args.q40):
            parser.error("Pair mode requires both --q4 and --q40")
        declared = [("q4", args.q4), ("q40", args.q40)]
    result = analyze(declared, args.bundle, args.output)
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "passed",
                    "runtime_collection_qualified",
                    "analysis_arms",
                    "full_quality_gate_attempted",
                    "errors",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
