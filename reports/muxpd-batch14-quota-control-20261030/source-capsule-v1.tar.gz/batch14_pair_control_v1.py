"""Root-owned full-answer controller. dry-run never queries or opens an NPU."""

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import time
import traceback
from pathlib import Path

from batch14_pair_run_v1 import BUNDLE, SCOPES, file_sha, now, prepare, save
from batch14_treatment_v1 import ARMS, LABELS, treatment_receipt
from candidate_checks_v1 import audit_terminal, require, validate_launch_environment
from probe_control_v1 import environment as original_environment
from probe_control_v1 import inventory, members

FILES = (
    "candidate_run_v1.py",
    "candidate_control_v1.py",
    "candidate_checks_v1.py",
    "quality_tables_v1.py",
    "candidate_quality_analysis_v2.py",
    "analyze_candidate_quality_v2.py",
    "candidate-quality-references-v1.json",
    "run_quality.py",
    "score_quality.py",
    "probe_run_v1.py",
    "probe_control_v1.py",
    "raw-engine-args-v1.json",
    "source-manifest-v1.json",
    "original-reuse-v1.json",
    "candidate-identity-template-v1.json",
    "frozen-v2/canonical-adapter.py",
    "frozen-v2/cases.jsonl",
    "frozen-v2/gold-source-rows.jsonl",
    "frozen-v2/initial_prompt.txt",
    "frozen-v2/materialized.200.cases.json",
    "frozen-v2/materialized.200.jsonl",
    "frozen-v2/plan.json",
    "batch14_pair_run_v1.py",
    "batch14_pair_control_v1.py",
    "batch14_treatment_v1.py",
    "batch14-treatment-v1.json",
    "source-reference-identity-v1.json",
    "batch14_pair_analysis_v1.py",
    "analyze_batch14_pair_v1.py",
    "batch14-pair-references-v1.json",
)


def environment(source, destination, candidate):
    env = original_environment(source, destination)
    overrides = candidate["environment_overrides"]
    require(
        set(overrides) <= {"ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES"},
        "Only explicitly declared placement environment overrides are permitted",
    )
    for key, value in overrides.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    return env


def terminal_assessment(root, record):
    require(
        record.get("terminal_process_proven") is True,
        "Process terminal proof required before child/log reads",
    )
    proof = {
        "terminal_process_proven": True,
        "exit_code": record.get("exit_code"),
        "owned_processes": record.get("owned_members_after_cleanup"),
        "controller_forced_cleanup": record.get("cleanup_required", False),
        "forced_termination": record.get("forced_termination", False),
        "devices_idle": record.get("idle_physical_after")
        == record.get("expected_physical")
        and len(record.get("expected_physical", [])) == 4,
    }
    require(
        proof["exit_code"] == 0
        and proof["owned_processes"] == []
        and not proof["controller_forced_cleanup"]
        and not proof["forced_termination"]
        and proof["devices_idle"]
        and not record["errors"],
        "Unclean candidate controller terminal state",
    )
    child = json.loads((root / "results/run.json").read_text())
    require(
        child["schema"] == "muxpd-q4-q40-batch14-run-v1"
        and child["arm"] == record["arm"]
        and child["arm_treatment"] == record["arm_treatment"]
        and child["passed"]
        and child["collection_complete"]
        and child["shutdown_returned"]
        and not child["errors"]
        and child["scope"] == record["scope"]
        and child["source_reference_identity"] == record["source_preflight"]
        and child["source_after_startup"] == record["source_preflight"]
        and child["sources_after_shutdown"] == record["source_preflight"],
        "Candidate collection/source/lifecycle differs",
    )
    require(
        child["selected_batch_ids"] == record["selected_batch_ids"]
        and len(child["outputs"]) == record["selected_case_count"]
        and child["prefix_validation"]["total_cohorts"]
        == 2 * len(record["selected_batch_ids"]),
        "Original selected case/batch cardinality differs",
    )
    lifecycle = audit_terminal(
        root / "process.log",
        proof,
        child["prefix_final"],
        child["layout_module_sha256"],
    )
    return {
        "passed": True,
        "child_sha256": file_sha(root / "results/run.json"),
        "lifecycle": lifecycle,
        "quality_qualification": False,
        "scope": "Collection/lifecycle only; original scorer and relative quality acceptance remain separate.",
    }


def predecessor_gate(args, freeze_sha):
    if args.arm == "q4":
        return None
    root = args.output_root / LABELS["q4"]
    path = root / "controller.json"
    if not path.exists() and args.command == "dry-run":
        return {"ready": False, "reason": "Predeclared q4 attempt has not run"}
    require(path.exists(), "q40 requires the predeclared q4 terminal controller")
    record = json.loads(path.read_text())
    require(
        record.get("terminal_process_proven") is True,
        "q4 terminal proof required before any predecessor child/log read",
    )
    require(
        record.get("schema") == "muxpd-q4-q40-batch14-controller-v1"
        and record.get("arm") == "q4"
        and record.get("label") == LABELS["q4"]
        and record.get("passed") is True
        and record.get("destination") == str(root.resolve())
        and record.get("freeze_manifest_sha256") == freeze_sha,
        "q4 predecessor declaration differs",
    )
    assessment = terminal_assessment(root, record)
    require(
        record["terminal_assessment"] == assessment,
        "q4 saved terminal assessment changed",
    )
    return {
        "ready": True,
        "controller_path": str(path.resolve()),
        "controller_sha256": file_sha(path),
        "child_sha256": assessment["child_sha256"],
        "historical_trajectory_equality_required": False,
    }


def preview(args):
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]+", args.label):
        raise ValueError("Require safe fresh label")
    expected = sorted(args.expected_physical.split(","), key=int)
    if len(expected) != 4 or len(set(expected)) != 4:
        raise ValueError("Require four distinct root-selected physical devices")
    require(
        args.label == LABELS[args.arm],
        "Only the predeclared one-attempt arm label is permitted",
    )
    require(expected == ["3", "4", "5", "6"], "Declared physical placement changed")
    destination = args.output_root / args.label
    if destination.exists():
        raise FileExistsError(destination)
    plan, _, batches, config, manifest, identity = prepare(
        args.scope, args.source, args.identity, args.arm, args.bundle
    )
    hashes = {name: file_sha(args.bundle / name) for name in FILES}
    freeze = args.bundle / "freeze-manifest-v1.json"
    frozen = freeze.exists()
    if frozen and json.loads(freeze.read_text())["files"] != hashes:
        raise ValueError("Reviewed frozen bundle bytes changed")
    if frozen and json.loads(freeze.read_text()).get(
        "source_reference_identity_sha256"
    ) != file_sha(args.identity):
        raise ValueError("Candidate identity differs from concrete root freeze")
    if args.command == "run" and not frozen:
        raise ValueError(
            "Root/reviewer must freeze this concrete bundle before device execution"
        )
    if frozen:
        declared = json.loads(freeze.read_text())["declared_attempts"]
        require(
            declared
            == {
                arm: {
                    "directory": str((args.output_root / label).resolve()),
                    "label": label,
                }
                for arm, label in LABELS.items()
            },
            "Frozen pair attempt paths differ",
        )
    from batch14_pair_analysis_v1 import verify_references

    _, references = verify_references(args.bundle)
    predecessor = predecessor_gate(args, file_sha(freeze) if frozen else None)
    deadline = manifest["controller_deadline_seconds"]
    if deadline != 12600 or deadline < plan["maximum_wall_seconds"] + 1800:
        raise ValueError(
            "Controller cannot truncate the original full-answer work bound"
        )
    env = environment(args.source, destination, manifest["candidate"])
    environment_guard = validate_launch_environment(
        env,
        manifest["historical_runs"]["raw-quality-v2-hccl-true-01"][
            "runtime_environment"
        ],
        manifest["candidate"],
    )
    return {
        "schema": "muxpd-q4-q40-batch14-controller-v1",
        "label": args.label,
        "scope": args.scope,
        "arm": args.arm,
        "arm_treatment": treatment_receipt(args.arm, args.bundle),
        "references_qualification": references,
        "predecessor_qualification": predecessor,
        "profile": "builtin-batch14-quota-diagnostic",
        "destination": str(destination),
        "source": str(args.source),
        "source_preflight": identity,
        "runtime_environment_guard": environment_guard,
        "selected_batch_ids": [b["batch_id"] for b in batches],
        "selected_case_count": sum(len(b["case_ids"]) for b in batches),
        "command": [
            str(args.python),
            str(destination / "producer/batch14_pair_run_v1.py"),
            "run",
            "--arm",
            args.arm,
            "--scope",
            args.scope,
            "--source",
            str(args.source),
            "--output",
            str(destination / "results"),
            "--identity",
            str(destination / "producer/source-reference-identity-v1.json"),
        ],
        "launch_engine_args": config,
        "files": hashes,
        "source_reference_identity_path": str(args.identity.resolve()),
        "source_reference_identity_sha256": file_sha(args.identity),
        "bundle_frozen": frozen,
        "freeze_manifest_sha256": file_sha(freeze) if frozen else None,
        "timeout_seconds": deadline,
        "deadline_reason": manifest["deadline_reason"],
        "expected_physical": expected,
        "environment": {
            k: env.get(k)
            for k in (
                "ASCEND_RT_VISIBLE_DEVICES",
                "HCCL_DETERMINISTIC",
                "VLLM_BATCH_INVARIANT",
                "VLLM_USE_V2_MODEL_RUNNER",
                "VLLM_ENABLE_V1_MULTIPROCESSING",
                "PYTHONPATH",
                "PYTHONDONTWRITEBYTECODE",
                "OMP_NUM_THREADS",
                "VLLM_CACHE_ROOT",
            )
        },
        "qualification_claim": "Fresh diagnostic only. Source identity is provenance, current q40 posterior32 quality remains FAIL; no full200 acceptance.",
    }


def execute(args, record):
    root = Path(record["destination"])
    root.mkdir(parents=True, exist_ok=False)
    for name, digest in record["files"].items():
        target = root / "producer" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(args.bundle / name, target)
        if file_sha(target) != digest:
            raise RuntimeError("Producer changed during immutable run copy")
    shutil.copyfile(
        args.bundle / "freeze-manifest-v1.json",
        root / "producer/freeze-manifest-v1.json",
    )
    shutil.copyfile(args.identity, root / "producer/source-reference-identity-v1.json")
    if (
        file_sha(root / "producer/source-reference-identity-v1.json")
        != record["source_reference_identity_sha256"]
    ):
        raise RuntimeError("Candidate identity changed during immutable copy")
    record.update(
        started_at=now(),
        controller_pid=os.getpid(),
        errors=[],
        passed=False,
        terminal_process_proven=False,
    )
    process = None
    save(root / "controller.json", record)
    try:
        before = subprocess.check_output(["npu-smi", "info"], timeout=30)
        (root / "npu-before.txt").write_bytes(before)
        record["idle_physical_before"] = inventory(before.decode())
        if record["idle_physical_before"] != record["expected_physical"]:
            raise RuntimeError(
                "Idle device allocation differs from root-selected inventory"
            )
        with (root / "process.log").open("x") as log:
            process = subprocess.Popen(
                record["command"],
                cwd=args.source,
                env=environment(
                    args.source, root, record["source_preflight"]["candidate_manifest"]
                ),
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            record["pid"] = record["process_group"] = process.pid
            record["owned_members_after_spawn"] = members(process.pid)
            save(root / "controller.json", record)
            start, notice = time.monotonic(), 0
            while process.poll() is None:
                elapsed = time.monotonic() - start
                if elapsed > record["timeout_seconds"]:
                    record["timeout"] = True
                    raise TimeoutError(
                        "Full-answer collection exceeded finite total deadline"
                    )
                if elapsed >= notice:
                    print(
                        f"{args.label}: pid={process.pid} running {elapsed:.0f}s",
                        flush=True,
                    )
                    notice = elapsed + 30
                time.sleep(1)
    except BaseException:  # noqa: BLE001 -- only owned process group is cleaned
        record["errors"].append(traceback.format_exc())
    finally:
        if process is not None:
            record["owned_members_before_cleanup"] = members(process.pid)
            if record["owned_members_before_cleanup"]:
                record["cleanup_required"] = True
                try:
                    os.killpg(process.pid, signal.SIGINT)
                    deadline = time.monotonic() + 45
                    while members(process.pid) and time.monotonic() < deadline:
                        time.sleep(1)
                    if members(process.pid):
                        record["forced_termination"] = True
                        os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                record["errors"].append("Owned producer did not exit after cleanup")
            record["exit_code"] = process.returncode
            record["owned_members_after_cleanup"] = members(process.pid)
            record["terminal_process_proven"] = (
                process.returncode is not None
                and not record["owned_members_after_cleanup"]
            )
        try:
            after = subprocess.check_output(["npu-smi", "info"], timeout=30)
            (root / "npu-after.txt").write_bytes(after)
            record["idle_physical_after"] = inventory(after.decode())
            if record["idle_physical_after"] != record.get("idle_physical_before"):
                raise RuntimeError("Physical allocation differs across run")
        except Exception:  # noqa: BLE001 -- retain idle guard failure
            record["errors"].append(traceback.format_exc())
        try:
            record["terminal_assessment"] = terminal_assessment(root, record)
            record["passed"] = record["terminal_assessment"]["passed"]
        except Exception:  # noqa: BLE001 -- preserve failed terminal/child/lifecycle evidence
            record["errors"].append(traceback.format_exc())
        record["finished_at"] = now()
        save(root / "controller.json", record)
    print(
        json.dumps(
            {
                "label": args.label,
                "passed": record["passed"],
                "scope": args.scope,
                "output": str(root),
            }
        ),
        flush=True,
    )
    return 0 if record["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("dry-run", "run"))
    parser.add_argument("--scope", choices=SCOPES, required=True)
    parser.add_argument("--arm", choices=ARMS, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--expected-physical", required=True)
    parser.add_argument("--bundle", type=Path, default=BUNDLE)
    parser.add_argument(
        "--identity", type=Path, default=BUNDLE / "source-reference-identity-v1.json"
    )
    parser.add_argument("--output-root", type=Path, default=BUNDLE / "runs-v1")
    parser.add_argument(
        "--python",
        type=Path,
        default=Path("/root/workspace/.muxpd-ecpa-runtime/bin/python"),
    )
    args = parser.parse_args()
    for key in ("source", "bundle", "output_root", "identity"):
        setattr(args, key, getattr(args, key).resolve())
    args.python = args.python.absolute()
    record = preview(args)
    if args.command == "dry-run":
        print(json.dumps(record, indent=2))
        return 0
    return execute(args, record)


if __name__ == "__main__":
    raise SystemExit(main())
