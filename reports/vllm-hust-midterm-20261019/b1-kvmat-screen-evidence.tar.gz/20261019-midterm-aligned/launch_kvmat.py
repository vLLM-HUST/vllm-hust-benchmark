"""E16/R36 plus isolated, source-pinned recompute controller."""
import hashlib
import inspect
import json
import os
from pathlib import Path
from betterscale.models.qwen35.launch import prepare
import vllm_kv_materialization.school_vllm_028 as adapter

ROOT = Path(__file__).resolve().parent
out = Path(os.environ['KVMAT_RUN_DIR']).resolve()
assert out.parent == ROOT
source = Path(inspect.getfile(adapter)).resolve()
assert source.is_relative_to(ROOT / 'kvmat-payload-r3')
command, env = prepare(
    model=Path('/models/Qwen3.5-35B-A3B'), devices='0,1', port=18390,
    cache_dir=Path('/workspace/midterm-b1-kvmat-e16-r36-20261019'),
    runtime_dir=ROOT / 'runtime', context_tokens=65536,
    state_budget_bytes=21474836480, served_model_name='qwen3.5-35b',
    distributed_port=29670, execution_seats=16, resident_seats=36,
    mtp_tokens=2, max_images=0,
)
assert Path(command[1]).name == 'serve.sh'
command[1] = str(ROOT / 'serve-kvmat.sh')
env['VLLM_KV_MATERIALIZATION_LOG_PATH'] = str(out / 'kvmat-policy.jsonl')
env['VLLM_KV_MATERIALIZATION_RUNTIME_EVENT_LOG_PATH'] = str(out / 'kvmat-engine.jsonl')
(out / 'kvmat-import.json').write_text(json.dumps({
    'source_commit': 'b1680f2365f3468a062a0530bd50dba3d8f80046', 'adapter_import': str(source),
    'adapter_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'scope': 'recompute only; no eligible reuse anchors in original workload',
}, indent=2) + '\n')
(ROOT / 'launch-kvmat-command.json').write_text(json.dumps(command, indent=2) + '\n')
os.execvpe(command[0], command, env)
