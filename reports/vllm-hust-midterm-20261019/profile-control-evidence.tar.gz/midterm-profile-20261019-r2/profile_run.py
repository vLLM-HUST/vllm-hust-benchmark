"""Capture a bounded real-model C8 replay after a separate warmup."""
import asyncio
import hashlib
import json
from pathlib import Path
import time
from measure import ENGINE

ROOT=Path(__file__).resolve().parent


async def main():
    from vllm import SamplingParams
    from vllm.engine.arg_utils import AsyncEngineArgs
    from vllm.v1.engine.async_llm import AsyncLLM
    inputs=json.loads((ROOT/'inputs.json').read_text())
    config={**ENGINE,'worker_cls':'observer.Worker'}
    (ROOT/'profile-plan.json').write_text(json.dumps({'engine':config,'C':8,
        'warmup_max_tokens':8,'profile_max_tokens':32,
        'input_sha256':hashlib.sha256(json.dumps(inputs).encode()).hexdigest(),
        'reason':'capture actual operation shapes/FLOP coverage; no performance verdict'},indent=2)+'\n')
    llm=None
    try:
        llm=AsyncLLM.from_engine_args(AsyncEngineArgs(**config))
        async def one(i,phase,cap):
            last=None
            async for output in llm.generate({'prompt_token_ids':inputs[i],
                'cache_salt':f'profile-lane-{i}'},SamplingParams(temperature=0,max_tokens=cap,seed=17),f'{phase}-{i}'):
                last=output
            assert last is not None and last.finished
            return {'id':f'{phase}-{i}','input_tokens':len(last.prompt_token_ids),
                    'output_tokens':len(last.outputs[0].token_ids)}
        await asyncio.wait_for(asyncio.gather(*(one(i,'warmup',8) for i in range(8))),180)
        await llm.start_profile()
        begin=time.monotonic()
        rows=await asyncio.wait_for(asyncio.gather(*(one(i,'profile',32) for i in range(8))),180)
        end=time.monotonic()
        await llm.stop_profile()
        (ROOT/'requests.json').write_text(json.dumps({'start':begin,'end':end,'requests':rows},indent=2)+'\n')
        print('REAL_MODEL_PROFILE_COMPLETE',flush=True)
    finally:
        if llm is not None:llm.shutdown()


if __name__=='__main__':asyncio.run(main())
