"""Profiler-only worker; keep numerical model and graph execution unchanged."""
import json
from pathlib import Path
import time
import torch_npu
from vllm_ascend.worker.worker import NPUWorker


class Worker(NPUWorker):
    def profile(self, is_start=True, profile_prefix=None):
        root = Path('/root/midterm-profile-20261019/traces')
        root.mkdir(exist_ok=True)
        if is_start:
            self.midterm_profiler = torch_npu.profiler.profile(
                activities=[torch_npu.profiler.ProfilerActivity.CPU,
                            torch_npu.profiler.ProfilerActivity.NPU],
                record_shapes=True, with_flops=True, with_stack=False,
                profile_memory=False,
                experimental_config=torch_npu.profiler._ExperimentalConfig(
                    export_type=torch_npu.profiler.ExportType.Text,
                    profiler_level=torch_npu.profiler.ProfilerLevel.Level2,
                    aic_metrics=torch_npu.profiler.AiCMetrics.PipeUtilization,
                    op_attr=True, record_op_args=True, data_simplification=False),
                on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(
                    str(root), worker_name=f'rank-{self.rank}'))
            self.midterm_profiler.start()
            self.midterm_started = time.time()
        else:
            ended = time.time()
            self.midterm_profiler.stop()
            (root/f'rank-{self.rank}-receipt.json').write_text(json.dumps({
                'rank': self.rank, 'started_wall': self.midterm_started,
                'stopped_wall': ended, 'record_shapes': True, 'with_flops': True,
                'numerical_worker_parent': 'vllm_ascend.worker.worker.NPUWorker',
                'scope': 'diagnostic profile; not a throughput acceptance run'},indent=2)+'\n')
