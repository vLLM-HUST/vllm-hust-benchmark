"""Run clean checkpoint-page advice once both owned worker loads have finished."""
import json
from pathlib import Path
import re

from reclaim_checkpoint_cache import reclaim


def loaded_workers(log):
    matches = re.findall(
        r"Worker_TP([01]) pid=(\d+).*Model runner load_model total time:", log)
    workers = {int(rank): int(pid) for rank, pid in matches}
    return workers if set(workers) == {0, 1} and len(set(workers.values())) == 2 else {}


def maybe_prepare(out):
    out = Path(out)
    destination = out / "checkpoint-cache-post-load.json"
    if destination.exists():
        return
    log_path = out / "service.log"
    workers = loaded_workers(log_path.read_text())
    if not workers:
        return
    result = reclaim()
    result["loaded_worker_pids"] = workers
    result["scope"] += " Triggered only after both worker weight-load completion records."
    with destination.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
