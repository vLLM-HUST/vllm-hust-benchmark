"""Stronger admission after r22 pinned-memory failure; serving contract unchanged."""
import hashlib
import json
from pathlib import Path
import time

from prepare_checkpoint_headroom import check_headroom
from reclaim_checkpoint_cache import reclaim

ROOT = Path(__file__).resolve().parent
MIN_HEADROOM = 40 * 1024 ** 3


def prepare(out):
    destination = Path(out) / 'checkpoint-cache-pre-request.json'
    assert not destination.exists(), 'Pre-request preparation already recorded'
    audit_path = ROOT / 'r22-failure-audit.json'
    audit = json.loads(audit_path.read_text())
    assert audit['status'] == 'failed_run_excluded_primary_pinned_host_allocation_failure'
    result = reclaim()
    result.update(minimum_headroom_bytes=MIN_HEADROOM, finished_monotonic=time.monotonic(),
                  admission_basis='Prospective 40 GiB floor after r22 failed with 35.74 GB headroom and r21 observed roughly 39.13 GB growth. Not a proven bound on future peak memory; no retrospective reclassification.',
                  source_sha256={str(ROOT / name): hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                 for name in ('prepare_checkpoint_headroom_v2.py',
                                              'prepare_checkpoint_headroom.py', 'reclaim_checkpoint_cache.py',
                                              'r22-failure-audit.json')})
    try:
        result['headroom_bytes'] = check_headroom(result['after'], minimum=MIN_HEADROOM)
        result['status'] = 'admitted_before_benchmark_client'
    except ValueError:
        result['status'] = 'rejected_before_benchmark_client'
        raise
    finally:
        with destination.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    return result
