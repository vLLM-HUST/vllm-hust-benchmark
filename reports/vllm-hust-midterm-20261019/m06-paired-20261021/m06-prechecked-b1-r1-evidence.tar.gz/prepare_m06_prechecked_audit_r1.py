"""Derive the corrected-pair verifier; require observed prechecks on both arms."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
text = (ROOT / 'audit_m06_pair_r1.py').read_text()
text = text.replace('m06-pair-plan-r1.json', 'm06-prechecked-pair-plan-r1.json')
text = text.replace('m01-recovery-model-m06-', 'm01-recovery-model-m06-prechecked-')
text = text.replace('m06-pair-result-r1.json', 'm06-prechecked-pair-result-r1.json')
text = text.replace('m06-paired-lifecycle-result/v1', 'm06-prechecked-lifecycle-result/v1')
old = "        log = (out / 'service.log').read_text()"
assert text.count(old) == 1
text = text.replace(old, old + """
        client_log = (out / 'bench.log').read_text()
        assert client_log.count('Initial test run completed.') == 1
        assert 'Skipping endpoint ready check.' not in client_log
        assert sum('POST /v1/chat/completions HTTP/1.1\\" 200 OK' in line for line in log.splitlines()) == 201
        for line in (out / 'SHA256SUMS').read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert hashlib.sha256((out / name).read_bytes()).hexdigest() == digest
        if arm == 'b1':
            policy = [json.loads(line) for line in (out / 'kvmat-policy.jsonl').read_text().splitlines()]
            engine = [json.loads(line) for line in (out / 'kvmat-engine.jsonl').read_text().splitlines()]
            assert len(policy) == len(engine) == 201
            assert len({row['request_id'] for row in policy}) == 201
            assert len({row['cache_salt_sha256'] for row in engine}) == 201
            assert all(row['event'] == 'school028_request_salt_admitted' for row in engine)
""")
old = "        'order': plan['order'], 'repetitions': 1, 'quality_scored': False,"
assert text.count(old) == 1
text = text.replace(old, old + "\n        'original_prechecked_protocol_confirmation': True,\n        'precheck_requests_per_arm': 1,")
destination = ROOT / 'audit_m06_prechecked_pair_r1.py'
with destination.open('x') as stream:
    stream.write(text)
print('Prepared verifier with actual precheck/201 request guards; no results generated')
