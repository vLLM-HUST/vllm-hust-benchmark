"""Run the recovered candidate with observation disabled for full-answer scoring."""
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parent
os.environ['HUST_TOKEN_OBSERVER'] = '0'
out = Path(os.environ['KVMAT_RUN_DIR']).resolve()
assert out.parent == ROOT and out.name == 'm01-recovery-model-m06-prechecked-b1-r1'
modules = {}
for name in ('torch', 'torch_npu', 'vllm', 'vllm_ascend', 'triton',
             'betterscale', 'hust_prefill_microflow', 'vllm_kv_materialization'):
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    modules[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                     'version_attribute': str(getattr(module, '__version__', 'unavailable'))}
with (out / 'quality-runtime-imports.json').open('x') as stream:
    json.dump({'modules': modules, 'observer_enabled': False,
               'launcher_sha256': hashlib.sha256((ROOT / 'launch_model_m06_prechecked_b1_r1.py').read_bytes()).hexdigest()}, stream, indent=2)
    stream.write('\n')
runpy.run_path(str(ROOT / 'launch_model_m06_prechecked_b1_r1.py'), run_name='__main__')
