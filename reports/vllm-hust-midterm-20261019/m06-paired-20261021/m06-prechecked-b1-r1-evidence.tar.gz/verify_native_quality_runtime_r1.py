"""Verify the complete isolated native runtime, not only package entry points."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def verify():
    manifest = json.loads((ROOT / 'native-quality-runtime-r1.json').read_text())
    package = Path(manifest['native_root']) / 'vllm_ascend'
    actual = {str(p.relative_to(package)) for p in package.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts}
    assert actual == set(manifest['files'])
    for name, digest in manifest['files'].items():
        path = package / name
        assert not path.is_symlink()
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == digest, name
    for name, entry in manifest['restored'].items():
        assert manifest['files'][name] == entry['native_sha256']
    return {'manifest_sha256': hashlib.sha256((ROOT / 'native-quality-runtime-r1.json').read_bytes()).hexdigest(),
            'root': str(package), 'files_checked': len(actual), 'restored': manifest['restored']}


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
