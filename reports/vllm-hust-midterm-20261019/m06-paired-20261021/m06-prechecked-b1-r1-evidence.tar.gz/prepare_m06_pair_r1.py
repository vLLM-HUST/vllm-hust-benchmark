"""Freeze one reversed-order MMLU lifecycle pair after shutdown qualification."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VLLM = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm')


def once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def create(name, text):
    path = ROOT / name
    with path.open('x') as stream:
        stream.write(text)
    return path


def main():
    produced = []
    # Preserve the original serving benchmark arguments, replacing only its lost runtime.
    bench = (ROOT / 'bench.sh').read_text()
    bench = once(bench, 'PYTHON=/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python',
        '''PYTHON=/workspace/state-commit-recovery-venv-r3/bin/python
export PYTHONPATH=$ROOT/compat:/root/gennova-runtime/m01-triton-recovery-dev20261007-r2:/workspace/native-quality-recovery-runtime-r1:/root/modcost-runtime-028-20261017/vllm-workspace/vllm:/workspace/state-commit-recovery-site-r2${PYTHONPATH:+:$PYTHONPATH}''')
    produced.append(create('bench-m06-recovery-r1.sh', bench))
    for arm in ('b1', 'b0'):
        oldrun = f'm01-recovery-model-shutdown-{arm}-r1'
        newrun = f'm01-recovery-model-m06-{arm}-r1'
        names = [f'launch_shutdown_{arm}_r1.py', f'measure_shutdown_{arm}_r1.py']
        if arm == 'b1':
            names.append('launch_model_shutdown_b1_r1.py')
        else:
            names.append('runtime-shutdown-b0-r1.sh')
        replacements = {name: name.replace('shutdown', 'm06') for name in names}
        replacements.update({oldrun: newrun, f'shutdown-{arm}-plan-r1.json': 'm06-pair-plan-r1.json'})
        for source in names:
            text = (ROOT / source).read_text()
            for old, new in replacements.items():
                text = text.replace(old, new)
            if source.startswith('measure_'):
                text = once(text, "['/root/agentx-bench/.venv/bin/python', str(ROOT / 'shutdown_probe_client_r1.py'), str(out)]",
                    "['bash', str(ROOT / 'bench-m06-recovery-r1.sh'), str(out)]")
                text = once(text, "result['completed'] == 1", "result['completed'] == 200")
                text = once(text, 'deadline = time.monotonic() + 240\n', 'deadline = time.monotonic() + 900\n')
                text = once(text, "started=time.time(), allocated_cards", "started=time.time(), started_monotonic=time.monotonic(), allocated_cards")
                text = once(text, 'record.update(ended=time.time(), all_devices_released=',
                    'record.update(ended=time.time(), ended_monotonic=time.monotonic(), all_devices_released=')
                if arm == 'b1':
                    text = once(text, 'len(policy) == 1', 'len(policy) == 201')
                    text = once(text, "for e in engine)) == 1", "for e in engine)) == 201")
                    text = text.replace('One short request; shutdown diagnosis only; no performance or MMLU scoring',
                        'MMLU original 200 request burst, output cap256, infinite arrival; one initial client precheck; full cold lifecycle')
                else:
                    text = once(text, '(signal.SIGINT, 90)', '(signal.SIGINT, 120)')
                    text = once(text, "    assert args.arm == 'b0' and args.mode == 'off'", """    assert args.arm == 'b0' and args.mode == 'off'
    previous = json.loads((ROOT / 'm01-recovery-model-m06-b1-r1/receipt.json').read_text())
    assert previous['status'] == 'measured' and previous['all_devices_released']""")
                    text = text.replace('Single short request; explicit 60 second shutdown; not performance or MMLU scoring',
                        'MMLU original 200 request burst, output cap256, infinite arrival; one initial client precheck; full cold lifecycle')
                    text = text.replace('Native shutdown qualification on recovered runtime',
                        'Native recovered runtime; paired lifecycle confirmation')
            produced.append(create(replacements[source], text))
    sources = [*produced, Path(__file__), ROOT / 'materialized.200.jsonl', ROOT / 'runtime-gdn-recovery-r2.sh',
               ROOT / 'verify_native_quality_runtime_r1.py', ROOT / 'native-quality-runtime-r1.json',
               ROOT / 'prepare_after_weight_load.py', ROOT / 'prepare_checkpoint_headroom_v2.py',
               Path('/root/extension-manager/src/vllm_hust_ext/process_supervisor.py'),
               Path('/root/extension-manager/src/vllm_hust_ext/cli.py'),
               VLLM / 'vllm/benchmarks/serve.py',
               Path('/root/vllm-hust-benchmark/reports/mmlu-pro-qwen35-b0-precheck-20261012/reproduction/b0_35b.profile.json')]
    plan = {
        'schema': 'm06-paired-lifecycle/v1', 'order': ['b1', 'b0'], 'repetitions': 1,
        'role': 'Independent confirmation, not new candidate selection',
        'b1': 'Preselected current best E24/R36 + Microflow + KV recompute, same recovered runtime as quality pair',
        'b0': 'Original Native profile on verified isolated recovered native runtime',
        'workload': {'dataset': 'MMLU-Pro', 'requests': 200, 'output_cap': 256, 'temperature': 0,
                     'client_seed': 0, 'arrival_rate': 'inf', 'shuffle': False,
                     'sha256': hashlib.sha256((ROOT / 'materialized.200.jsonl').read_bytes()).hexdigest()},
        'precheck': 'Retain original client one-request ready check; include its time in lifecycle, exclude its tokens from measured burst denominator; no extra warmup. This is within-run activity, not cross-run cache reuse.',
        'cache': 'Each arm new empty compilation/cache directory and new service; no previous run intermediates or cache seed',
        'reservation': {'all_devices': [4,5,6,7], 'service_devices': [4,5]},
        'shutdown': {'inner_seconds_both': 60, 'b1_manager_seconds': 90, 'outer_seconds_both': 120,
                     'known_errors': 'Keep worker termination and EngineDeadError observations; report real signal escalation and release.'},
        'cost': 'q=k*(release-confirmation-start)/sum(successful measured output tokens); k4 reservation primary, k2 service secondary; request interval separate; no subtracted startup/drain or assumed amortization',
        'gate': 'Equal-rate lifecycle cost reduction >=10%; publish pass/fail and quality references, no claim from output256 answers',
        'stop': 'One pair only; no retries, profile/concurrency changes or duration extension to seek pass; if B1 fails stop before B0 and retain evidence',
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
    }
    with (ROOT / 'm06-pair-plan-r1.json').open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    print('Prepared frozen B1 -> B0 pair; original client settings; complete lifecycle')


if __name__ == '__main__':
    main()
