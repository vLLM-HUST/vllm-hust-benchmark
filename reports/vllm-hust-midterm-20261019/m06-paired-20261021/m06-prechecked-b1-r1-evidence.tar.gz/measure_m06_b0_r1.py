"""Run isolated original-profile B0/B1 bursts with complete lifecycle sampling."""
from prepare_after_weight_load import maybe_prepare
from prepare_checkpoint_headroom_v2 import prepare as prepare_checkpoint_headroom
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import time
import urllib.request
ROOT = Path(__file__).resolve().parent
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

def descendant(pid, ancestors):
    seen = set()
    while pid > 1 and pid not in seen:
        if pid in ancestors:
            return True
        seen.add(pid)
        try:
            fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
            pid = int(fields[1])
        except FileNotFoundError:
            return False
    return False

def stop(child):
    if child is None:
        return None
    for sig, seconds in [(signal.SIGINT, 120), (signal.SIGTERM, 20), (signal.SIGKILL, 10)]:
        try:
            os.killpg(child.pid, sig)
        except ProcessLookupError:
            break
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            child.poll()
            try:
                os.killpg(child.pid, 0)
            except ProcessLookupError:
                break
            time.sleep(1)
        else:
            continue
        break
    return child.wait(timeout=10)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('arm', choices=['b0', 'b1'])
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--mode', choices=['off', 'on'], default='on')
    args = parser.parse_args()
    assert args.arm == 'b0' and args.mode == 'off'
    previous = json.loads((ROOT / 'm01-recovery-model-m06-b1-r1/receipt.json').read_text())
    assert previous['status'] == 'measured' and previous['all_devices_released']
    assert args.run_id == 'm01-recovery-model-m06-b0-r1'
    plan = json.loads((ROOT / 'm06-pair-plan-r1.json').read_text())
    for name, digest in plan['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
    assert not Path('/workspace/m01-recovery-model-m06-b0-r1-cache').exists()
    out = ROOT / args.run_id
    out.mkdir(exist_ok=False)
    record = dict(arm=args.arm, status='admitting', started=time.time(), started_monotonic=time.monotonic(), allocated_cards=2, reserved_cards=4, simultaneous_other_services=0, protocol='MMLU original 200 request burst, output cap256, infinite arrival; one initial client precheck; full cold lifecycle', measurement_role='Native recovered runtime; paired lifecycle confirmation', input_hashes=json.loads((ROOT / 'm06-pair-plan-r1.json').read_text())['source_sha256'])
    children = []
    locks = []

    def save():
        (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    try:
        assert hashlib.sha256((ROOT / 'materialized.200.jsonl').read_bytes()).hexdigest() == 'fb79b6fa98f232282a948e4a17f404f80c03dc2bae05af57b95b9cc0651b3506'
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for _ in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            assert all((f'No running processes found in NPU {i}' in smi for i in range(4, 8)))
            time.sleep(2)
        (out / 'npu-before.txt').write_text(smi)
        assert shutil.disk_usage(ROOT).free > 5 * 1024 ** 3
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', 18390))
        with (out / 'service.log').open('x') as log, (out / 'bench.log').open('x') as bench_log, (out / 'device-samples.jsonl').open('x') as samples:
            server = subprocess.Popen(['bash', str(ROOT / 'runtime-m06-b0-r1.sh')], env={**os.environ, 'KVMAT_RUN_DIR': str(out)}, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append(server)
            record.update(status='starting', service_pid=server.pid)
            save()
            deadline = time.monotonic() + 2400
            bench = None
            quiet_samples = 0
            while True:
                assert server.poll() is None, f'Service exited {server.returncode}'
                assert time.monotonic() < deadline, 'Stage timeout'
                assert shutil.disk_usage(ROOT).free > 2 * 1024 ** 3, 'Disk reserve exhausted'
                t0 = time.monotonic()
                raw = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps(dict(wall_time=time.time(), start_monotonic=t0, end_monotonic=time.monotonic(), phase=record['status'], raw=raw)) + '\n')
                samples.flush()
                owned_groups = {p.pid for p in children}
                foreign = []
                for line in raw.splitlines():
                    match = re.match('\\|\\s*[4-7]\\s+0\\s*\\|\\s*(\\d+)\\s*\\|', line)
                    if match:
                        try:
                            group = os.getpgid(int(match[1]))
                        except ProcessLookupError:
                            continue
                        if group not in owned_groups and (not descendant(int(match[1]), owned_groups)):
                            foreign.append(int(match[1]))
                if foreign:
                    record.setdefault('startup_foreign_context_observations', []).append({'time': time.time(), 'pids': foreign, 'phase': record['status']})
                    save()
                    assert bench is None, 'Unrelated NPU process appeared during measurement; no result admitted'
                    quiet_samples = 0
                else:
                    quiet_samples += 1
                if bench is None:
                    maybe_prepare(out)
                    try:
                        with OPENER.open('http://127.0.0.1:18390/health', timeout=1) as response:
                            ready = response.status == 200
                    except OSError:
                        ready = False
                    if ready and quiet_samples >= 3:
                        prepare_checkpoint_headroom(out)
                        identity = json.loads((out / 'quality-runtime-imports.json').read_text())
                        assert identity['plugins'] == 'ascend,ascend_model,ascend_model_loader,ascend_kv_connector'
                        reference = json.loads((ROOT / 'm01-recovery-model-quality-r1/quality-runtime-imports.json').read_text())
                        assert all((value == reference['modules'][name] for name, value in identity['modules'].items() if name != 'vllm_ascend'))
                        from verify_native_quality_runtime_r1 import verify
                        assert identity['native_runtime'] == verify()
                        assert identity['modules']['vllm_ascend']['path'] == identity['native_runtime']['root'] + '/__init__.py'
                        record.update(status='benchmark_client', bench_started_wall=time.time(), bench_started_monotonic=time.monotonic())
                        save()
                        bench = subprocess.Popen(['bash', str(ROOT / 'bench-m06-recovery-r1.sh'), str(out)], stdout=bench_log, stderr=subprocess.STDOUT, start_new_session=True)
                        children.append(bench)
                        deadline = time.monotonic() + 900
                elif bench.poll() is not None:
                    record.update(bench_exit_code=bench.returncode, bench_ended_wall=time.time(), bench_ended_monotonic=time.monotonic())
                    assert bench.returncode == 0, f'Bench exited {bench.returncode}'
                    result = json.loads((out / 'mmlu-pro.json').read_text())
                    assert result['completed'] == 200 and result['failed'] == 0
                    record.update(status='measured', output_throughput=result['output_throughput'])
                    break
                time.sleep(max(0, 1 - (time.monotonic() - t0)))
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['child_exit_codes'] = [stop(child) for child in reversed(children)]
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (out / 'npu-after.txt').write_text(smi)
        record.update(ended=time.time(), ended_monotonic=time.monotonic(), all_devices_released=all((f'No running processes found in NPU {i}' in smi for i in range(4, 8))))
        save()
        for stream in locks:
            stream.close()
        files = [p for p in out.iterdir() if p.is_file() and p.name != 'SHA256SUMS']
        (out / 'SHA256SUMS').write_text(''.join((hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in files)))
    print(json.dumps(record, indent=2))
    return 0 if record['status'] == 'measured' and record['all_devices_released'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
