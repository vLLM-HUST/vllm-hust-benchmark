"""Cold-cache recovery candidate; original model/workload arguments are unchanged."""
import hashlib
import inspect
import json
import os
from pathlib import Path

from betterscale.models.qwen35.launch import prepare
import vllm_kv_materialization.school_vllm_028 as adapter

ROOT = Path(__file__).resolve().parent
out = Path(os.environ['KVMAT_RUN_DIR']).resolve()
assert out.parent == ROOT and out.name.startswith('m01-recovery-model-')
cache = Path('/workspace') / (out.name + '-cache')
assert not cache.exists() and not cache.is_symlink(), 'Run cache must be new'
cache.mkdir()
arm = 'on'
os.environ.update(HUST_MICROFLOW_CACHE_ROOT=str(cache), HUST_MICROFLOW_EVENT_DIR=str(out),
                  VLLM_CACHE_ROOT=str(cache / arm / 'vllm'),
                  TRITON_CACHE_DIR=str(cache / arm / 'triton'),
                  TORCHINDUCTOR_CACHE_DIR=str(cache / arm / 'inductor'))
(out / 'compiler-cache-initialization.json').write_text(json.dumps({
    'policy': 'fresh empty caches; no prior run or compile seed imported',
    'destination': str(cache), 'initial_entries': list(cache.iterdir()),
    'startup_excluded_from_measurement': True}, indent=2) + '\n')
source = Path(inspect.getfile(adapter)).resolve()
assert source.is_relative_to(ROOT / 'kvmat-managed-payload-r1')
command, env = prepare(model=Path('/models/Qwen3.5-35B-A3B'), devices='0,1', port=18390,
    cache_dir=cache / arm / 'vllm', runtime_dir=ROOT / 'runtime', context_tokens=65536,
    state_budget_bytes=21474836480, served_model_name='qwen3.5-35b', distributed_port=29670,
    execution_seats=24, resident_seats=36, mtp_tokens=2, max_images=0)
assert command[2:] == json.loads((ROOT / 'mmlu-b1-microflow-fa-on-r10/launch-command.json').read_text())[2:]
command[1] = str(ROOT / 'serve-token-accounting-v20.sh')
env['VLLM_KV_MATERIALIZATION_LOG_PATH'] = str(out / 'kvmat-policy.jsonl')
env['VLLM_KV_MATERIALIZATION_RUNTIME_EVENT_LOG_PATH'] = str(out / 'kvmat-engine.jsonl')
(out / 'kvmat-import.json').write_text(json.dumps({
    'source_commit': json.loads((ROOT / 'kvmat-managed-source-receipt.json').read_text())['source_commit'],
    'adapter_import': str(source), 'adapter_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'scope': 'recompute only; no eligible reuse anchors in original workload'}, indent=2) + '\n')
(out / 'launch-command.json').write_text(json.dumps(command, indent=2) + '\n')
os.environ.update(env)
from vllm_hust_ext.cli import main
assert command[command.index('--shutdown-timeout') + 1] == '60'
import vllm_hust_ext.process_supervisor as supervisor
def trace_signal(name, original):
    def traced(process, signum):
        event = dict(event=name, pid=process.pid, signal=int(signum))
        os.write(2, ('M06_MANAGER_SIGNAL ' + json.dumps(event) + '\n').encode())
        return original(process, signum)
    return traced
supervisor._signal_launch_tree = trace_signal('launch_tree', supervisor._signal_launch_tree)
supervisor._signal_launch_leader = trace_signal('launch_leader', supervisor._signal_launch_leader)
raise SystemExit(main(['run', '--shutdown-grace-seconds', '90', '--', *command]))
