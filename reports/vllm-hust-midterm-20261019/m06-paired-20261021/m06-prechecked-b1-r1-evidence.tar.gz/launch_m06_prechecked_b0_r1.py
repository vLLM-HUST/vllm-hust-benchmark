"""Original native profile on recovered base runtime, without candidate plugins."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PROFILE = Path('/root/vllm-hust-benchmark/reports/mmlu-pro-qwen35-b0-precheck-20261012/reproduction/b0_35b.profile.json')
RUN = 'm01-recovery-model-m06-prechecked-b0-r1'


def command():
    profile = json.loads(PROFILE.read_text())
    args = list(profile['serve_args'])
    assert '--shutdown-timeout' not in args
    args += ['--shutdown-timeout', '60']
    args[args.index('--port') + 1] = '18390'
    return [sys.executable, '-m', 'vllm.entrypoints.cli.main', 'serve', profile['model']['path'], *args]


def main():
    from verify_native_quality_runtime_r1 import verify
    native = verify()
    modules = {}
    for name in ('torch', 'torch_npu', 'vllm', 'vllm_ascend', 'triton'):
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        modules[name] = dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                             version_attribute=str(getattr(module, '__version__', 'unavailable')))
    importlib.import_module('acl')
    importlib.import_module('vllm_ascend.worker.worker')
    runner = importlib.import_module('vllm_ascend.worker.model_runner_v1')
    runner_path = Path(runner.__file__).resolve()
    assert runner_path == Path(native['root']) / 'worker/model_runner_v1.py'
    assert hashlib.sha256(runner_path.read_bytes()).hexdigest() == native['restored']['worker/model_runner_v1.py']['native_sha256']
    identity = dict(native_runtime=native, modules=modules, plugins=os.environ['VLLM_PLUGINS'], observer_enabled=False,
                    command=command(), profile_sha256=hashlib.sha256(PROFILE.read_bytes()).hexdigest())
    assert os.environ['HUST_TOKEN_OBSERVER'] == '0'
    assert os.environ['VLLM_PLUGINS'] == 'ascend,ascend_model,ascend_model_loader,ascend_kv_connector'
    if sys.argv[1:] == ['--inspect']:
        print(json.dumps(identity, indent=2))
        return
    assert not sys.argv[1:]
    out = Path(os.environ['KVMAT_RUN_DIR']).resolve()
    assert out == ROOT / RUN
    cache = Path('/workspace') / (RUN + '-cache')
    assert not cache.exists() and not cache.is_symlink()
    cache.mkdir()
    os.environ.update(VLLM_CACHE_ROOT=str(cache / 'vllm'), TRITON_CACHE_DIR=str(cache / 'triton'),
                      TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'))
    for filename, content in [('quality-runtime-imports.json', identity),
                               ('launch-command.json', command()),
                               ('compiler-cache-initialization.json', dict(destination=str(cache), initial_entries=[],
                                policy='fresh empty caches; no prior run or compile seed imported'))]:
        with (out / filename).open('x') as stream:
            json.dump(content, stream, indent=2)
            stream.write('\n')
    os.execv(sys.executable, command())


if __name__ == '__main__':
    main()
