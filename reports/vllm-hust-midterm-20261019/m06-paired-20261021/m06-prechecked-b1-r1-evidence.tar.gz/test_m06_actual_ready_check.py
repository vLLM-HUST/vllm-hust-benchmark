"""Exercise actual vLLM readiness code and branch against a local HTTP fixture.

This is a CPU protocol test, not model execution or benchmark evidence.
"""
import ast
import asyncio
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
from pathlib import Path
import threading
import time
from types import SimpleNamespace

import aiohttp
import pytest
from tqdm.asyncio import tqdm

BASE = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/benchmarks')


def actual_code():
    ready_tree = ast.parse((BASE / 'lib/ready_checker.py').read_text())
    function = next(n for n in ready_tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'wait_for_endpoint')
    namespace = {'asyncio': asyncio, 'time': time, 'aiohttp': aiohttp, 'tqdm': tqdm,
                 'logger': logging.getLogger('m06-protocol-test'), 'RequestFuncOutput': SimpleNamespace}
    future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future, function], type_ignores=[]))
    exec(compile(module, str(BASE / 'lib/ready_checker.py'), 'exec'), namespace)
    serve_tree = ast.parse((BASE / 'serve.py').read_text())
    branches = [n for n in ast.walk(serve_tree) if isinstance(n, ast.If)
                and ast.unparse(n.test) == 'ready_check_timeout_sec > 0']
    assert len(branches) == 1
    wrapper = ast.parse('async def actual_branch():\n    pass\n').body[0]
    wrapper.body = [branches[0]]
    exec(compile(ast.fix_missing_locations(ast.Module(body=[wrapper], type_ignores=[])),
                 str(BASE / 'serve.py'), 'exec'), namespace)
    return namespace


@pytest.mark.parametrize('timeout,expected_requests', [(0, 0), (60, 1)])
def test_actual_ready_branch_makes_expected_http_requests(timeout, expected_requests):
    seen = []
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            seen.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
            body = b'{"success":true}'
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_args):
            pass

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        namespace = actual_code()
        async def run():
            async with aiohttp.ClientSession() as session:
                async def request_func(request_func_input, session):
                    async with session.post(f'http://127.0.0.1:{server.server_port}/probe', json=request_func_input) as response:
                        return SimpleNamespace(**await response.json())
                namespace.update(ready_check_timeout_sec=timeout, session=session,
                                 request_func=request_func, test_input={'kind': 'CPU protocol fixture'})
                await namespace['actual_branch']()
        asyncio.run(run())
        assert len(seen) == expected_requests
        assert all(item == {'kind': 'CPU protocol fixture'} for item in seen)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
