#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH LD_PRELOAD HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy OPENAI_API_KEY
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
ROOT=/root/gennova-evidence/20261019-midterm-aligned
export PYTHONPATH=$ROOT/compat:/root/gennova-runtime/m01-triton-recovery-dev20261007-r2:/workspace/native-quality-recovery-runtime-r1:/root/modcost-runtime-028-20261017/vllm-workspace/vllm:/workspace/state-commit-recovery-site-r2${PYTHONPATH:+:$PYTHONPATH}
export ASCEND_RT_VISIBLE_DEVICES=0,1
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector
export VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ENABLE_V1_MULTIPROCESSING=1
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 TASK_QUEUE_ENABLE=0 HCCL_OP_EXPANSION_MODE=AIV
export HUST_TOKEN_OBSERVER=0 HUST_MICROFLOW_ARM=off VLLM_KV_ENABLE_SCHOOL_028=0
unset VLLM_HUST_EXT_CONFIG BETTERSCALE_QWEN35_RUNTIME
exec /workspace/state-commit-recovery-venv-r3/bin/python "$ROOT/launch_m06_prechecked_b0_r1.py" "$@"
