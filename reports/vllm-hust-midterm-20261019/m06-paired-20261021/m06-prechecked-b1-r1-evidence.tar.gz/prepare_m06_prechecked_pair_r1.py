"""Restore the original prechecked protocol explicitly; retain the deviating pair."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
old_plan = json.loads((ROOT / 'm06-pair-plan-r1.json').read_text())
names = ['bench-m06-recovery-r1.sh', 'launch_m06_b0_r1.py', 'runtime-m06-b0-r1.sh',
         'measure_m06_b0_r1.py', 'launch_m06_b1_r1.py', 'launch_model_m06_b1_r1.py',
         'measure_m06_b1_r1.py']
mapping = {n: n.replace('m06', 'm06_prechecked') if n.endswith('.py')
           else n.replace('m06-', 'm06-prechecked-') for n in names}
mapping['m06-pair-plan-r1.json'] = 'm06-prechecked-pair-plan-r1.json'
for arm in ['b1', 'b0']:
    mapping[f'm01-recovery-model-m06-{arm}-r1'] = f'm01-recovery-model-m06-prechecked-{arm}-r1'
produced = []
for source in names:
    text = (ROOT / source).read_text()
    for old, new in mapping.items():
        text = text.replace(old, new)
    if source.startswith('bench-'):
        old = '--temperature 0 --seed 0 --save-result --save-detailed'
        assert text.count(old) == 1
        text = text.replace(old, '--temperature 0 --seed 0 --ready-check-timeout-sec 60 --save-result --save-detailed')
    if source.startswith('measure_'):
        marker = "                    assert result['completed'] == 200 and result['failed'] == 0"
        assert text.count(marker) == 1
        text = text.replace(marker, marker + "\n                    client_log = (out / 'bench.log').read_text()\n                    assert 'Initial test run completed.' in client_log, 'Required precheck missing'\n                    assert 'Skipping endpoint ready check.' not in client_log, 'Precheck was skipped'")
    destination = ROOT / mapping[source]
    with destination.open('x') as stream:
        stream.write(text)
    produced.append(destination)
plan = {k:v for k,v in old_plan.items() if k != 'source_sha256'}
plan['schema'] = 'm06-prechecked-lifecycle/v1'
plan['run_ids'] = [mapping[f'm01-recovery-model-m06-{arm}-r1'] for arm in ['b1', 'b0']]
plan['precheck'] = 'Explicit --ready-check-timeout-sec 60 on both arms; require actual successful precheck log and no skipped-check log. Exactly200 measured requests; B1 expected201 policy and engine events including the successful precheck. Lifecycle includes precheck time, measured output denominator excludes its tokens.'
plan['restoration'] = 'Prior no-precheck pair retained as protocol-deviation evidence. Restore the originally intended precheck, not retune candidate/workload/order/gates or choose results.'
plan['stop'] = 'One protocol-corrected pair B1 then B0; preserve all results and errors; no automatic retries after a failed arm.'
sources = {Path(p) for p in old_plan['source_sha256']} | set(produced) | {
    Path(__file__), ROOT / 'test_m06_actual_ready_check.py',
    Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/benchmarks/lib/ready_checker.py')}
plan['source_sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(sources)}
with (ROOT / 'm06-prechecked-pair-plan-r1.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
    stream.write('\n')
print(json.dumps({'prepared': [p.name for p in produced], 'started': False}, indent=2))
