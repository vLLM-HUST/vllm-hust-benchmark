#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH LD_PRELOAD HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy OPENAI_API_KEY
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
ROOT=/root/gennova-evidence/20261019-midterm-aligned
SITE=/workspace/state-commit-recovery-site-r2
TRITON=/root/gennova-runtime/m01-triton-recovery-dev20261007-r2
export PYTHONPATH=$ROOT/token-observer-recovery-r1:$ROOT/microflow-recovery-payload-r2:/root/extension-manager/src:$ROOT/kvmat-managed-payload-r1:$ROOT/recovery-model-payload-r1:$ROOT/compat:$TRITON:$ROOT/runtime:/root/modcost-runtime-028-20261017/vllm-workspace/vllm:$SITE${PYTHONPATH:+:$PYTHONPATH}
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export BETTERSCALE_FIA_METADATA=owned BETTERSCALE_STATE_CACHE_HOST_BYTES=8589934592
export BETTERSCALE_GDN_LIBRARY=/root/gennova-runtime/betterscale-dist/extracted/vllm_betterscale-0.5.1/src/betterscale/patches/qwen_gdn/libbs_gdn.so
export BETTERSCALE_GDN_HOST_LIBRARY=$ROOT/build/libbs_gdn_host_cann91.so
export BETTERSCALE_CP_LIBRARY=$ROOT/recovery-fia-build-r1/artifact/libbs_fia_cp.so
export VLLM_HUST_EXT_CONFIG=$ROOT/manager-recovery-r2/manager.json
export VLLM_KV_ENABLE_SCHOOL_028=1 VLLM_KV_POLICY_MODE=controller
export HUST_MICROFLOW_ARM=on HUST_TOKEN_OBSERVER=1
exec /workspace/state-commit-recovery-venv-r3/bin/python "$@"
