"""Archive a terminal arm without rewriting originals or requiring a positive result."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('arm', choices=['b0', 'b1'])
    args = parser.parse_args()
    run = ROOT / f'm01-recovery-model-m06-{args.arm}-r1'
    receipt = json.loads((run / 'receipt.json').read_text())
    assert 'ended' in receipt and receipt['all_devices_released']
    plan = json.loads((ROOT / 'm06-pair-plan-r1.json').read_text())
    for name, expected in plan['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
    for line in (run / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256((run / name).read_bytes()).hexdigest() == digest
    paths = [*run.rglob('*'), *(Path(p) for p in plan['source_sha256']),
             ROOT / 'm06-pair-plan-r1.json', ROOT / 'test_m06_pair_plan_r1.py',
             ROOT / 'audit_m06_pair_r1.py', ROOT / 'test_m06_accounting_r1.py', Path(__file__)]
    if args.arm == 'b1':
        paths += [ROOT / 'audit_m06_b1_admission_r1.py', ROOT / 'm06-b1-admission-r1.json']
    archive = Path(f'/workspace/m06-pair-{args.arm}-r1-evidence.tar.gz')
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(set(paths)):
            if path.is_dir():
                continue
            assert path.is_file() and not path.is_symlink()
            name = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else 'external/' + str(path).lstrip('/')
            tar.add(path, arcname=name, recursive=False)
    result = {'arm': args.arm, 'status': receipt['status'], 'archive': str(archive),
              'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
    with (ROOT / f'm06-pair-{args.arm}-archive-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
