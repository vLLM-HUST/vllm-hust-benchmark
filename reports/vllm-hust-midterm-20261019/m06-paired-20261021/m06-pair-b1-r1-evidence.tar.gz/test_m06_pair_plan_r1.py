"""Frozen pair identity, workload, order and accounting guards."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_all_frozen_sources_match():
    plan = json.loads((ROOT / 'm06-pair-plan-r1.json').read_text())
    for name, digest in plan['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name


def test_original_benchmark_arguments_unchanged():
    marker = 'exec "$PYTHON" -m vllm.entrypoints.cli.main bench serve \\\n'
    old = (ROOT / 'bench.sh').read_text().split(marker)
    new = (ROOT / 'bench-m06-recovery-r1.sh').read_text().split(marker)
    assert len(old) == len(new) == 2
    assert old[1] == new[1]


def test_frozen_order_and_boundaries():
    plan = json.loads((ROOT / 'm06-pair-plan-r1.json').read_text())
    assert plan['order'] == ['b1', 'b0'] and plan['repetitions'] == 1
    assert plan['workload']['requests'] == 200 and plan['workload']['output_cap'] == 256
    for arm in ['b1', 'b0']:
        text = (ROOT / f'measure_m06_{arm}_r1.py').read_text()
        ast.parse(text)
        assert '(signal.SIGINT, 120)' in text
        assert 'started_monotonic=time.monotonic()' in text
        assert 'ended_monotonic=time.monotonic()' in text
        assert "result['completed'] == 200" in text
        assert 'shutdown_probe_client' not in text
    assert "previous['all_devices_released']" in (ROOT / 'measure_m06_b0_r1.py').read_text()
    assert 'len(policy) == 201' in (ROOT / 'measure_m06_b1_r1.py').read_text()
