"""Separate a wrong post-run event-count assertion from valid request evidence."""
import hashlib
import json
from pathlib import Path
from audit_m06_pair_r1 import metrics

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'm01-recovery-model-m06-b1-r1'
receipt = json.loads((RUN / 'receipt.json').read_text())
assert receipt['status'] == 'failed' and receipt['error'] == 'AssertionError: '
assert receipt['bench_exit_code'] == 0 and receipt['child_exit_codes'] == [0, 130]
assert receipt['all_devices_released']
for name, expected in receipt['input_hashes'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
for line in (RUN / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert hashlib.sha256((RUN / name).read_bytes()).hexdigest() == digest
benchlog = (RUN / 'bench.log').read_text()
assert benchlog.count('Skipping endpoint ready check.') == 1
assert 'Initial test run completed.' not in benchlog
log = (RUN / 'service.log').read_text()
assert sum('POST /v1/chat/completions HTTP/1.1" 200 OK' in line for line in log.splitlines()) == 200
bench = json.loads((RUN / 'mmlu-pro.json').read_text())
policy = [json.loads(line) for line in (RUN / 'kvmat-policy.jsonl').read_text().splitlines()]
engine = [json.loads(line) for line in (RUN / 'kvmat-engine.jsonl').read_text().splitlines()]
assert len(policy) == len(engine) == 200
assert len({r['request_id'] for r in policy}) == 200
assert len({r['cache_salt_sha256'] for r in engine}) == 200
assert {int(r['request_id'].rsplit('-', 1)[1]) for r in policy} == set(range(200))
for row in policy:
    index = int(row['request_id'].rsplit('-', 1)[1])
    assert row['prompt_tokens'] == bench['input_lens'][index]
    assert row['output_tokens'] == 256
    matches = [e for e in engine if e['request_id'].startswith('chatcmpl-' + row['request_id'] + '-')]
    assert len(matches) == 1 and matches[0]['prompt_tokens'] == row['prompt_tokens']
    assert matches[0]['event'] == 'school028_request_salt_admitted'
    assert hashlib.sha256(row['runtime_cache_salt'].encode()).hexdigest() == matches[0]['cache_salt_sha256']
signals = [json.loads(line.split('M06_MANAGER_SIGNAL ', 1)[1]) for line in log.splitlines() if 'M06_MANAGER_SIGNAL ' in line]
assert signals and all(e['signal'] != 9 for e in signals)
assert 'Application shutdown complete.' in log
# This in-memory projection only lets the arithmetic verifier run; the receipt stays failed.
computed = metrics({**receipt, 'status': 'measured'}, bench)
result = {
    'run_id': RUN.name, 'admitted': True, 'original_controller_status': receipt['status'],
    'correction': 'Controller expected 201 events, but actual frozen client defaults ready-check timeout to zero; 200 requests and 200 uniquely matched control events are complete.',
    'original_receipt_sha256': hashlib.sha256((RUN / 'receipt.json').read_bytes()).hexdigest(),
    'original_manifest_sha256': hashlib.sha256((RUN / 'SHA256SUMS').read_bytes()).hexdigest(),
    'request_count': 200, 'precheck_requests': 0, 'policy_events': 200, 'engine_events': 200,
    'arithmetic': computed, 'scope': 'Independent admission correction, not a rerun or claim of paired gain',
}
with (ROOT / 'm06-b1-admission-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
