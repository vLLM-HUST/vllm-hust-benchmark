"""Correct admission metadata before B0; never rerun or rewrite the B1 arm."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
old = ROOT / 'measure_m06_b0_r1.py'
text = old.read_text()
guard = """    previous = json.loads((ROOT / 'm01-recovery-model-m06-b1-r1/receipt.json').read_text())
    assert previous['status'] == 'measured' and previous['all_devices_released']"""
replacement = """    previous_path = ROOT / 'm01-recovery-model-m06-b1-r1/receipt.json'
    previous = json.loads(previous_path.read_text())
    admission = json.loads((ROOT / 'm06-b1-admission-r1.json').read_text())
    assert previous['status'] == 'failed' and previous['all_devices_released']
    assert admission['admitted'] is True and admission['request_count'] == 200
    assert admission['original_receipt_sha256'] == hashlib.sha256(previous_path.read_bytes()).hexdigest()"""
assert text.count(guard) == 1
text = text.replace(guard, replacement)
assert text.count('m06-pair-plan-r1.json') == 2
text = text.replace('m06-pair-plan-r1.json', 'm06-pair-plan-r2.json')
new = ROOT / 'measure_m06_b0_r2.py'
with new.open('x') as stream:
    stream.write(text)
base = ROOT / 'm06-pair-plan-r1.json'
plan = json.loads(base.read_text())
plan['amendment'] = {
    'original_plan_sha256': hashlib.sha256(base.read_bytes()).hexdigest(),
    'scope': 'Admission/description correction only after B1 and before B0; unchanged client, serving configurations, workload, order, gates and accounting',
    'reason': 'Frozen client default ready-check timeout is zero; 200—not 201—control events expected. Preserve failed B1 controller receipt and independent admission audit.',
    'b1_rerun': False, 'b0_run_id_unchanged': 'm01-recovery-model-m06-b0-r1',
    'b0_controller': new.name,
}
plan['precheck'] = 'Actual frozen client skips ready check (default timeout0); exactly200 requests, no additional precheck or warmup. Same unmodified client for B0 and B1.'
plan['stop'] = 'No B1 rerun; B0 admitted only against hash-bound independent B1 audit. No workload/configuration/duration tuning. Publish all original failures and any negative outcome.'
for path in [new, Path(__file__), ROOT / 'audit_m06_b1_admission_r1.py',
             ROOT / 'm06-b1-admission-r1.json', ROOT / 'audit_m06_pair_r1.py']:
    plan['source_sha256'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
with (ROOT / 'm06-pair-plan-r2.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
    stream.write('\n')
print('Amendment prepared; original B1 and original plan unchanged; no B0 execution yet')
