"""Audit both arms with an explicit, hash-bound B1 admission correction."""
import hashlib
import json
from pathlib import Path
from audit_m06_pair_r1 import metrics

ROOT = Path(__file__).resolve().parent


def main():
    plans = {arm: json.loads((ROOT / f'm06-pair-plan-r{version}.json').read_text())
             for arm, version in [('b1', 1), ('b0', 2)]}
    admission = json.loads((ROOT / 'm06-b1-admission-r1.json').read_text())
    assert admission['admitted'] and admission['precheck_requests'] == 0
    arms, inputs, receipts = {}, {}, {}
    for arm in ['b1', 'b0']:
        out = ROOT / f'm01-recovery-model-m06-{arm}-r1'
        path = out / 'receipt.json'
        receipt = json.loads(path.read_text())
        if arm == 'b1':
            assert receipt['status'] == 'failed' and receipt['error'] == 'AssertionError: '
            assert hashlib.sha256(path.read_bytes()).hexdigest() == admission['original_receipt_sha256']
        else:
            assert receipt['status'] == 'measured'
        for line in (out / 'SHA256SUMS').read_text().splitlines():
            digest, name = line.split('  ', 1)
            assert hashlib.sha256((out / name).read_bytes()).hexdigest() == digest
        for name, expected in plans[arm]['source_sha256'].items():
            assert receipt['input_hashes'][name] == expected
            assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
        assert receipt['child_exit_codes'] == ([0, 130] if arm == 'b1' else [0, 0])
        bench = json.loads((out / 'mmlu-pro.json').read_text())
        assert 'Skipping endpoint ready check.' in (out / 'bench.log').read_text()
        log = (out / 'service.log').read_text()
        assert sum('POST /v1/chat/completions HTTP/1.1" 200 OK' in line for line in log.splitlines()) == 200
        assert 'timeout=60s' in log and 'Application shutdown complete.' in log
        signals = [json.loads(line.split('M06_MANAGER_SIGNAL ', 1)[1])
                   for line in log.splitlines() if 'M06_MANAGER_SIGNAL ' in line]
        if arm == 'b1':
            assert signals and all(e['signal'] != 9 for e in signals)
        # Preserve original receipt; only project the independently audited admission for arithmetic.
        arms[arm] = metrics({**receipt, 'status': 'measured'}, bench)
        arms[arm]['original_controller_status'] = receipt['status']
        arms[arm]['shutdown'] = {
            'manager_signals': signals,
            'engine_timeout_force_kill': 'force killing remaining process EngineCore' in log,
            'engine_dead_error_logged': 'EngineDeadError' in log,
            'api_shutdown_complete': True,
        }
        inputs[arm] = bench['input_lens']
        receipts[arm] = receipt
    assert inputs['b0'] == inputs['b1']
    assert receipts['b1']['ended_monotonic'] < receipts['b0']['started_monotonic']
    b0, b1 = arms['b0'], arms['b1']
    cost = 100*(1-b1['lifecycle_reservation_card_s_per_token']/b0['lifecycle_reservation_card_s_per_token'])
    result = {
        'schema': 'm06-paired-lifecycle-result/v2', 'arms': arms,
        'b1_admission_correction': admission['correction'],
        'original_prechecked_protocol_confirmation': False,
        'protocol_deviation': 'Both arms actually skipped the initial client ready check. Preserve original receipts including their inaccurate one-precheck description; this is a disclosed no-precheck paired follow-up, not a reproduction of the old prechecked protocol.',
        'lifecycle_cost_reduction_percent': cost, 'm06_lifecycle_gate_pass': cost >= 10,
        'request_cost_reduction_percent': 100*(1-b1['request_reservation_card_s_per_token']/b0['request_reservation_card_s_per_token']),
        'throughput_change_percent': 100*(b1['output_tok_per_s']/b0['output_tok_per_s']-1),
        'mean_ttft_reduction_percent': 100*(1-b1['mean_ttft_s']/b0['mean_ttft_s']),
        'mean_tpot_reduction_percent': 100*(1-b1['mean_tpot_s']/b0['mean_tpot_s']),
        'order': ['b1', 'b0'], 'repetitions': 1, 'quality_scored': False,
        'limitations': [
            'Output256 performance only, not task correctness.',
            'Same frozen client skips precheck on both arms; original plan description and B1 post-run count assertion were wrong and separately corrected.',
            'Complete new-service/empty-compile-cache lifecycle; host OS file cache not globally flushed.',
            'Four reserved cards primary, two service cards secondary; equal-rate resource cost, not currency expense.',
            'One reversed-order pair; no statistical certainty or assumed amortization; retain all shutdown errors.',
        ],
    }
    with (ROOT / 'm06-pair-result-r2.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
