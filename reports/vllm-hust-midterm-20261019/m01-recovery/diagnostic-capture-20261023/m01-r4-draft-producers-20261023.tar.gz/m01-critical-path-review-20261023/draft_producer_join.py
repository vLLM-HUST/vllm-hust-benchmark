"""Recover previous-batch draft ownership, not cache lifetime or FLOPs."""
from collections import Counter


def join(scheduler, worker):
    waves = [event['identity']['wave'] for event in worker['events']
             if event['event'] == 'sample_begin']
    if waves != sorted(set(waves)):
        raise ValueError('Sampling waves are not strictly ordered')
    previous = dict(zip(waves[1:], waves[:-1]))
    slots = {}
    for record in worker['draft_device_lengths']['records']:
        metadata = record['metadata']
        wave, step = metadata['identity']['wave'], metadata['draft_step']
        for row, key in enumerate(metadata['request_keys']):
            identity = (wave, key, step)
            if identity in slots:
                raise ValueError('Duplicate producer slot')
            slots[identity] = row
    frames = {event['frame']: event['identity']['wave']
              for event in scheduler['events'] if event['event'] == 'delivery'}
    records, counts, used = [], Counter(), set()
    for event in scheduler['events']:
        if event['event'] not in ('output_update', 'not_updated') or not event['drafts']:
            continue
        wave, key = frames[event['frame']], event['request_key']
        producer = previous.get(wave)
        identities = [(producer, key, step) for step in range(event['drafts'])]
        if any(identity not in slots for identity in identities):
            raise ValueError('Consumer lacks matching previous-batch producer')
        if any(identity in used for identity in identities):
            raise ValueError('Producer consumed more than once')
        used.update(identities)
        observation = event.get('observation')
        retained = observation['retained_drafts'] if observation else 0
        if not isinstance(retained, int) or not 0 <= retained <= event['drafts']:
            raise ValueError('Invalid retained draft count')
        counts['consuming_rows'] += 1
        counts['scheduled_draft_slots'] += event['drafts']
        counts['retained_draft_slots'] += retained
        counts['nonretained_draft_slots'] += event['drafts'] - retained
        counts[event['event']] += 1
        records.append(dict(producer_wave=producer, consumer_wave=wave, request_key=key,
                            producer_row=slots[identities[0]], scheduled_drafts=event['drafts'],
                            retained_drafts=retained, consumer_status=event['event']))
    counts['producer_slots_without_scheduled_consumer'] = len(set(slots) - used)
    return dict(counts=dict(counts), records=records)
