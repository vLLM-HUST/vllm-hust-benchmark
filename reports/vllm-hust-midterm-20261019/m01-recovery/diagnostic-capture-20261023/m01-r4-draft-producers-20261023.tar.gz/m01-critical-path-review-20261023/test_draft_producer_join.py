from copy import deepcopy

import pytest

from draft_producer_join import join


def fixture():
    worker = dict(events=[dict(event='sample_begin', identity=dict(wave=w)) for w in (0, 2)],
                  draft_device_lengths=dict(records=[
                      dict(metadata=dict(identity=dict(wave=0), draft_step=s,
                                         request_keys=['a', 'b'])) for s in (0, 1)]))
    scheduler = dict(events=[dict(event='delivery', frame=5, identity=dict(wave=2)),
        dict(event='output_update', frame=5, request_key='b', drafts=2,
             observation=dict(retained_drafts=1))])
    return scheduler, worker


def test_previous_sample_batch_and_reordered_row():
    scheduler, worker = fixture()
    result = join(scheduler, worker)
    assert result['records'][0]['producer_wave'] == 0
    assert result['records'][0]['producer_row'] == 1
    assert result['counts']['retained_draft_slots'] == 1
    assert result['counts']['producer_slots_without_scheduled_consumer'] == 2


def test_missing_previous_batch_is_not_replaced_by_request_history():
    scheduler, worker = fixture()
    worker['events'].insert(1, dict(event='sample_begin', identity=dict(wave=1)))
    with pytest.raises(ValueError, match='previous-batch'):
        join(scheduler, worker)


def test_duplicate_consumption_fails():
    scheduler, worker = fixture()
    scheduler['events'].append(deepcopy(scheduler['events'][-1]))
    with pytest.raises(ValueError, match='more than once'):
        join(scheduler, worker)


def test_terminal_unupdated_work_is_not_retained():
    scheduler, worker = fixture()
    scheduler['events'][-1]['event'] = 'not_updated'
    del scheduler['events'][-1]['observation']
    result = join(scheduler, worker)
    assert result['counts']['retained_draft_slots'] == 0
    assert result['counts']['nonretained_draft_slots'] == 2
