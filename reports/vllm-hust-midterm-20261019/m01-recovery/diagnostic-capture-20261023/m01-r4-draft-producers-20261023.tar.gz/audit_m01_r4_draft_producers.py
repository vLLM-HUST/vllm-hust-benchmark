"""Bind the recovered previous-batch topology to frozen sources and raw r4 data."""
import hashlib
import json
from pathlib import Path
import sys

HERE = Path('/workspace/m01-critical-path-review-20261023')
ROOT = Path('/workspace/m01-capture-b1-r4')
sys.path.insert(0, str(HERE))
from draft_producer_join import join


def main():
    hashes = {}

    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw

    plan = json.loads(read(HERE / 'capture-execution-plan-r7.json'))
    paths = [
        '/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/v1/worker/gpu_model_runner.py',
        '/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/v1/core/sched/async_scheduler.py',
        '/root/gennova-evidence/20261019-midterm-aligned/runtime/vllm_ascend/worker/model_runner_v1.py',
        '/root/gennova-evidence/20261019-midterm-aligned/recovery-model-payload-r1/betterscale/models/qwen35/state_address.py',
        '/root/gennova-evidence/20261019-midterm-aligned/recovery-model-payload-r1/betterscale/models/qwen35/input_reuse.py',
    ]
    for name in paths:
        read(Path(name))
        if hashes[name] != plan['source_sha256'][name]:
            raise ValueError('Runtime source changed since capture: ' + name)
    scheduler = json.loads(read(ROOT / 'scheduler-894022.json'))
    workers = [json.loads(read(ROOT / f'worker-{pid}.json')) for pid in (894394, 894395)]
    if scheduler['run_id'] != 'capture-b1-r4':
        raise ValueError('Wrong run')
    result = join(scheduler, workers[0])
    if result != join(scheduler, workers[1]):
        raise ValueError('Rank disagreement')
    read(HERE / 'draft_producer_join.py')
    read(HERE / 'test_draft_producer_join.py')
    read(Path(__file__))
    report = dict(status='same_run_previous_batch_producer_topology_reconciled',
                  run_id=scheduler['run_id'], rank_equal=True, **result,
                  source_sha256=hashes, effective_flops=None, reference_seconds=None,
                  limitations=[
                      'Source-bound batch topology, not token-ID equality or dynamic branch attestation.',
                      'Nonretained and unconsumed slots do not establish that all associated context work is useless.',
                      'Useful persistent context/cache attribution and full arithmetic remain separate.',
                      'No original stream qualification or timing field is changed.'])
    destination = Path('/workspace/m01-r4-draft-producers.json')
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=report['status'], counts=report['counts'])))


if __name__ == '__main__':
    main()
