"""Allow one diagnostic export RPC in addition to the frozen boundary protocol."""
import json

from boundary_transport import BoundaryTransport


class CaptureTransport(BoundaryTransport):
    async def __call__(self, path, payload):
        approved = dict(method='hust_m01_export_wave_capture', args=[], timeout=90)
        if path != '/collective_rpc' or payload != approved:
            return await super().__call__(path, payload)
        import aiohttp
        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout, trust_env=False) as session:
            async with session.post(self.base_url + path, json=payload, allow_redirects=False) as response:
                if response.status != 200:
                    raise RuntimeError(f'Capture export endpoint returned HTTP {response.status}')
                chunks = bytearray()
                async for block in response.content.iter_chunked(4096):
                    chunks.extend(block)
                    if len(chunks) > 65536:
                        raise ValueError('Oversized capture export response')
                result = json.loads(chunks)
                if not isinstance(result, dict):
                    raise ValueError('Capture export response must be an object')
                return result
