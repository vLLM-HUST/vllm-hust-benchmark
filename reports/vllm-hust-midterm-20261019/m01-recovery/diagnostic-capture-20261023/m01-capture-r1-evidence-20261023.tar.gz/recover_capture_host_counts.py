"""Recover bounded host counts from the failed capture, never a full M01 result."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def recover(scheduler, boundary):
    if not scheduler['complete'] or scheduler['errors'] or scheduler['dropped']:
        raise ValueError('Incomplete scheduler ledger')
    if scheduler['run_id'] != boundary['run_id']:
        raise ValueError('Cross-run boundary')
    calls = boundary['calls']
    if [c['path'] for c in calls] != ['/pause?mode=wait&clear_cache=false',
        '/collective_rpc', '/resume', '/pause?mode=wait&clear_cache=false', '/collective_rpc']:
        raise ValueError('Unexpected failed export boundary')
    start = calls[2]['clock_after']
    end = calls[3]['clock_before']
    if not (start['host'] == end['host'] == scheduler['host']) or start['pid'] != end['pid']:
        raise ValueError('Host clock identity mismatch')
    low, high = start['perf_after_ns'], end['perf_before_ns']
    if high <= low:
        raise ValueError('Reversed client interval')
    events = [e for e in scheduler['events'] if low <= e['perf_ns'] <= high]
    updates = [e for e in events if e['event'] == 'output_update']
    outputs = Counter()
    for row in updates:
        obs = row['observation']
        if obs['status'] != 'accepted_prefix_then_bonus_host_counts' or obs['is_stale']:
            raise ValueError('Unclassified output update')
        outputs[row['request_key']] += obs['appended_count']
    if len(outputs) != 200 or set(outputs.values()) != {256}:
        raise ValueError('Host output population differs from fixed workload')
    raw = sum(e['observation']['raw_accepted_drafts'] for e in updates)
    kept = sum(e['observation']['retained_drafts'] for e in updates)
    return dict(status='partial_host_counts_recovered_from_failed_capture',
        run_id=scheduler['run_id'], requests=len(outputs), appended_output_tokens=sum(outputs.values()),
        raw_accepted_drafts=raw, retained_drafts=kept, terminal_trimmed_drafts=raw-kept,
        retained_first_drafts=sum(e['observation']['retained_first_draft'] for e in updates),
        retained_second_drafts=sum(e['observation']['retained_second_draft'] for e in updates),
        output_updates=len(updates), event_counts=dict(Counter(e['event'] for e in events)),
        unclassified_scheduled_rows=sum(e['event'] == 'not_updated' for e in events),
        low_perf_ns=low, high_perf_ns=high, effective_flops=None, reference_time=None, m01_attainment=None,
        limitations=['Worker exports missing because export RPC was rejected by client whitelist',
            'No benchmark result JSON: hook failure occurred before result serialization',
            'Counts describe retained host outputs, not all useful device work or full FLOPs',
            'Not-updated scheduled rows require separate lifecycle classification',
            'Host perf-counter interval; no claim of uninstrumented timing or task-quality acceptance'])


def main():
    root = Path('/workspace/m01-capture-b1-r1')
    paths = [root / 'scheduler-712941.json', root / 'boundary.jsonl']
    raw = [p.read_bytes() for p in paths]
    result = recover(*(json.loads(b) for b in raw))
    result['source_sha256'] = {str(p): hashlib.sha256(b).hexdigest() for p, b in zip(paths, raw)}
    destination = Path(__file__).with_name('capture-r1-host-count-recovery.json')
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
