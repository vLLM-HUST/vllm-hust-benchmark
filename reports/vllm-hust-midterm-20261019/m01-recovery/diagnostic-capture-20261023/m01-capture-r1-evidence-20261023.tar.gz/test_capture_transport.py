import asyncio
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import threading

import pytest

from capture_transport import CaptureTransport
from capture_boundary import CaptureBoundary
from test_capture_boundary import files
from test_synchronized_boundary import fences


def test_real_loopback_pause_fences_resume_and_export(tmp_path):
    calls = []
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def do_POST(self):
            raw_request = self.rfile.read(int(self.headers.get('Content-Length', '0')))
            payload = json.loads(raw_request) if raw_request else None
            calls.append((self.path, payload))
            if payload and payload['method'] == 'hust_m01_export_wave_capture':
                result = files(tmp_path)
            elif payload:
                result = fences(payload['args'][0])
            else:
                result = {'status': 'resumed' if self.path == '/resume' else 'paused'}
            raw = json.dumps(result).encode()
            self.send_response(200)
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
    server = HTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever)
    thread.start()
    try:
        boundary = CaptureBoundary(CaptureTransport(server.server_port), tmp_path, 'capture-r1')
        async def run():
            await boundary.begin()
            await boundary.end()
        asyncio.run(run())
        assert boundary.state == 'completed'
        assert len(calls) == 6
        assert calls[-1][1]['method'] == 'hust_m01_export_wave_capture'
        assert len(boundary.export_receipts) == 2
    finally:
        server.shutdown()
        thread.join()
        server.server_close()


@pytest.mark.parametrize('payload', [dict(method='arbitrary', args=[], timeout=90),
    dict(method='hust_m01_export_wave_capture', args=['unexpected'], timeout=90),
    dict(method='hust_m01_export_wave_capture', args=[], timeout=900)])
def test_other_rpc_still_rejected_before_network(payload):
    with pytest.raises(ValueError, match='Unapproved'):
        asyncio.run(CaptureTransport(18390)('/collective_rpc', payload))
