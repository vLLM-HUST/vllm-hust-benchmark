from copy import deepcopy

import pytest

from audit_draft_inputs import validate


def sample():
    identity = dict(run_id='r', wave=3)
    records = [dict(metadata=dict(kind='draft_inputs', identity=identity, request_keys=['a', 'b']),
                    values=dict(sample_indices=[1, 4], step0_slots=list(range(6)), step1_slots=[2, 5]))]
    lengths = []
    for step in (0, 1):
        metadata = dict(identity=identity, request_keys=['a', 'b'], draft_step=step)
        records.append(dict(metadata=dict(metadata, kind='owned_read_table'),
                            values=dict(block_table=[[10, 11], [20, 21]])))
        lengths.append(dict(metadata=metadata, device_query_lengths=[3, 6] if step == 0 else [1, 2],
                            device_kv_lengths=[130, 200]))
    return dict(draft_device_inputs=dict(complete=True, errors=[], records=records),
                draft_device_lengths=dict(records=lengths))


def test_complete_paired_inputs():
    assert validate(sample())['table_publications'] == 2


def test_missing_second_table_rejected():
    worker = sample()
    worker['draft_device_inputs']['records'].pop()
    with pytest.raises(ValueError, match='Missing or extra'):
        validate(worker)


def test_duplicate_record_rejected():
    worker = sample()
    worker['draft_device_inputs']['records'].append(deepcopy(worker['draft_device_inputs']['records'][0]))
    with pytest.raises(ValueError, match='Duplicate'):
        validate(worker)


def test_actual_device_envelope_must_fit_captured_table():
    worker = sample()
    worker['draft_device_lengths']['records'][0]['device_kv_lengths'][0] = 257
    with pytest.raises(ValueError, match='truncates actual'):
        validate(worker)


def test_sample_index_cannot_cross_request_row():
    worker = sample()
    worker['draft_device_inputs']['records'][0]['values']['sample_indices'][0] = 3
    with pytest.raises(ValueError, match='outside request'):
        validate(worker)
