"""Bind existing device-length journal slots to diagnostic draft waves."""
import copy
import hashlib
import importlib.util
from pathlib import Path

JOURNAL = Path('/root/gennova-evidence/20261019-midterm-aligned/token-observer-recovery-r1/hust_token_observer/owned_fia_device_journal.py')
JOURNAL_SHA256 = 'cfba326a35bb9e4f25e4183368fb582063fce4b6ce5f81145f904940fc6bb636'


def load_journal():
    if hashlib.sha256(JOURNAL.read_bytes()).hexdigest() != JOURNAL_SHA256:
        raise ValueError('Device journal source changed')
    spec = importlib.util.spec_from_file_location('_m01_device_lengths', JOURNAL)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.DeviceLengthJournal


class DraftLengthBridge:
    def __init__(self, journal, context, request_ids, capturing, table_recorder=None):
        self.journal = journal
        self.context = context
        self.request_ids = request_ids
        self.capturing = capturing
        self.table_recorder = table_recorder
        self.keys = set()
        self.errors = []

    def record(self, query, kv, table, tiling, fields):
        context = self.context()
        if context is None or fields['role'] != 'draft':
            return None
        try:
            if self.capturing():
                raise ValueError('Active workload unexpectedly capturing a graph')
            tag = context['identity']
            if context['phase'] not in ('execute', 'sample'):
                raise ValueError('Unknown worker phase')
            step = fields['draft_step']
            if type(step) is not int or step not in (0, 1):
                raise ValueError('Only MTP2 is qualified')
            ids = list(self.request_ids())
            if not ids or len(ids) != len(set(ids)) or any(not isinstance(i,str) for i in ids):
                raise ValueError('Invalid live request identities')
            if query.shape[0] < len(ids) or kv.shape[0] != query.shape[0]:
                raise ValueError('Frame cannot cover live requests')
            key = (tag['run_id'],tag['wave'],step)
            if key in self.keys:
                raise ValueError('Duplicate draft publication in one wave')
            metadata = dict(identity=copy.deepcopy(tag),phase=context['phase'],draft_step=step,
                bank=fields['bank'],frame_tokens=fields['tokens'],live_requests=len(ids),
                request_keys=[hashlib.sha256((tag['run_id']+'\0'+rid).encode()).hexdigest() for rid in ids])
            slot = self.journal.record(query,kv,metadata)
            if self.table_recorder is not None:
                self.table_recorder(table, fields, context, metadata['request_keys'])
            self.keys.add(key)
            return slot
        except Exception as error:
            self.errors.append(dict(error_type=type(error).__name__))
            raise

    def finish(self, synchronize):
        result = self.journal.finish(synchronize)
        result['binding_errors'] = list(self.errors)
        result['journal_source_sha256'] = JOURNAL_SHA256
        if self.errors:
            result['status'] = 'capture_errors'
        result['stream_order_qualified'] = False
        result['effective_flops'] = None
        return result
