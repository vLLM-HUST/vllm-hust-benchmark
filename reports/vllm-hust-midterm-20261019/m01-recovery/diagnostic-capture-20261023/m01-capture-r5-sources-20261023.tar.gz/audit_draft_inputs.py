"""Require same-wave indices, write slots and both consumed read tables."""


def validate(worker):
    data = worker.get('draft_device_inputs')
    if not data or not data['complete'] or data['errors']:
        raise ValueError('Missing or incomplete draft input export')
    lengths = worker['draft_device_lengths']['records']
    expected = {}
    for record in lengths:
        m = record['metadata']
        key = (m['identity']['run_id'], m['identity']['wave'], m['draft_step'])
        if key in expected:
            raise ValueError('Duplicate length identity')
        expected[key] = record
    inputs, tables = {}, {}
    for record in data['records']:
        m = record['metadata']
        key = (m['identity']['run_id'], m['identity']['wave'])
        if m['kind'] == 'draft_inputs':
            dest, identity = inputs, key
        elif m['kind'] == 'owned_read_table':
            dest, identity = tables, (*key, m['draft_step'])
        else:
            raise ValueError('Unknown input capture record')
        if identity in dest:
            raise ValueError('Duplicate input publication')
        dest[identity] = record
    if set(tables) != set(expected) or set(inputs) != {key[:2] for key in expected}:
        raise ValueError('Missing or extra per-wave input/table publication')
    for key, record in expected.items():
        m, values = record['metadata'], record
        source, table = inputs[key[:2]], tables[key]
        keys = m['request_keys']
        if keys != source['metadata']['request_keys'] or keys != table['metadata']['request_keys']:
            raise ValueError('Request row identity mismatch')
        block_table = table['values']['block_table']
        if len(block_table) != len(keys):
            raise ValueError('Wrong owned table row extent')
        for row, length in zip(block_table, values['device_kv_lengths'][:len(keys)]):
            if len(row) * 128 < length:
                raise ValueError('Owned table truncates actual device read length')
        if key[2] == 0:
            fields = source['values']
            if len(fields['sample_indices']) != len(keys):
                raise ValueError('Wrong sample index extent')
            previous = 0
            for index, end in zip(fields['sample_indices'], values['device_query_lengths']):
                if not previous <= index < end:
                    raise ValueError('Sample index outside request query')
                previous = end
            if len(fields['step0_slots']) != previous or len(fields['step1_slots']) != len(keys):
                raise ValueError('Write-slot extent does not match live queries')
    return dict(waves=len(inputs), table_publications=len(tables),
                complete=True, stream_order_qualified=False, effective_flops=None)
