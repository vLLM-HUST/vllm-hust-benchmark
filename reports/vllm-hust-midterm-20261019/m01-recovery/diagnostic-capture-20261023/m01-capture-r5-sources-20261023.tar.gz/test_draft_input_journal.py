from types import SimpleNamespace as NS

import pytest
import torch

from draft_input_journal import DraftInputJournal, ObservedDraftRunnable, input_fields, record_owned_table


def test_snapshot_survives_mutation_and_sync_precedes_export():
    journal = DraftInputJournal(torch, 'cpu', capacity=16)
    value = torch.tensor([[1, 2], [3, 4]], dtype=torch.int32)
    journal.record({'wave': 1}, {'slots': value})
    value.fill_(99)
    sync = []
    output = journal.finish(lambda: sync.append(True))
    assert sync == [True]
    assert output['records'][0]['values']['slots'] == [[1, 2], [3, 4]]
    assert output['complete'] and not output['stream_order_qualified']
    with pytest.raises(ValueError, match='Already exported'):
        journal.finish(lambda: None)


def test_overflow_is_atomic_and_invalidates_capture():
    journal = DraftInputJournal(torch, 'cpu', capacity=2)
    with pytest.raises(OverflowError):
        journal.record({}, {'slots': torch.arange(3)})
    assert journal.cursor == 0
    assert not journal.finish(lambda: None)['complete']


def test_float_field_rejected():
    journal = DraftInputJournal(torch, 'cpu', capacity=2)
    with pytest.raises(ValueError, match='dtype'):
        journal.record({}, {'slots': torch.ones(1)})


def fixture():
    def metadata():
        return NS(slot_mapping=torch.arange(8), seq_lens_list=[130, 200],
                  block_tables=torch.arange(16).reshape(2, 8))
    proposer = NS(_get_positions=lambda n: torch.arange(n))
    kwargs = dict(num_tokens=6, num_input_tokens=8, batch_size=2,
                  token_indices_to_sample=torch.tensor([1, 4]),
                  multi_steps_attn_metadata=[{'mtp': metadata()}, {'mtp': metadata()}])
    return proposer, kwargs


def test_fields_exclude_padding_but_preserve_cache_read_envelope():
    proposer, kwargs = fixture()
    fields = input_fields(proposer, kwargs, 2)
    assert fields['first_positions'].shape == (6,)
    assert fields['step0_slots'].shape == (6,)
    assert fields['step1_slots'].shape == (2,)
    assert fields['step1_native_block_table'].shape == (2, 2)
    assert fields['sample_indices'].tolist() == [1, 4]


def test_insufficient_cache_table_fails():
    proposer, kwargs = fixture()
    kwargs['multi_steps_attn_metadata'][0]['mtp'].seq_lens_list = [2000, 2000]
    with pytest.raises(ValueError, match='Read table'):
        input_fields(proposer, kwargs, 2)


def test_outer_wrapper_preserves_frames_and_observes_before_mutation():
    proposer, kwargs = fixture()
    proposer.runner = NS(input_batch=NS(req_ids=['a', 'b'], num_reqs=2))
    journal = DraftInputJournal(torch, 'cpu', capacity=100)

    class Inner:
        frames = {'frame': 1}

        def __call__(self, **kw):
            kw['token_indices_to_sample'].fill_(99)
            return 'native_result'

    context = dict(identity=dict(run_id='r', wave=1))
    observed = ObservedDraftRunnable(Inner(), proposer, journal, lambda: context, lambda: False)
    assert observed.frames == {'frame': 1}
    assert observed(**kwargs) == 'native_result'
    with pytest.raises(ValueError, match='Duplicate'):
        observed(**kwargs)
    report = journal.finish(lambda: None)
    assert report['records'][0]['values']['sample_indices'] == [1, 4]
    assert report['records'][0]['metadata']['request_keys'][0] != 'a'


def test_warmup_bypasses_journal():
    inner = lambda **kw: 'warmup'
    observed = ObservedDraftRunnable(inner, None, None, lambda: None, lambda: True)
    assert observed() == 'warmup'


def test_owned_table_is_separate_from_native_input_table():
    journal = DraftInputJournal(torch, 'cpu', capacity=100)
    fields = dict(role='draft', draft_step=1,
                  host_planning_kv_lengths=dict(host_values=[129, 130], tensor=None))
    table = torch.tensor([[10, 11, 12], [20, 21, 22]])
    record_owned_table(journal, table, fields, {'identity': {'run_id': 'r', 'wave': 1}}, ['a', 'b'])
    table.fill_(99)
    result = journal.finish(lambda: None)['records'][0]
    assert result['metadata']['kind'] == 'owned_read_table'
    assert result['values']['block_table'] == [[10, 11], [20, 21]]
