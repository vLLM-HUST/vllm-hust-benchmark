"""Bounded integer snapshots before draft replay; no per-wave host readback."""
from copy import deepcopy
import hashlib


class DraftInputJournal:
    def __init__(self, torch, device, *, capacity=4_000_000, max_records=4096):
        if type(capacity) is not int or type(max_records) is not int or min(capacity, max_records) <= 0:
            raise ValueError('Positive integer bounds required')
        self.torch = torch
        self.storage = torch.empty(capacity, dtype=torch.int64, device=device)
        self.capacity, self.max_records = capacity, max_records
        self.cursor, self.records, self.errors, self.closed = 0, [], [], False

    def record(self, metadata, tensors):
        try:
            if self.closed or len(self.records) >= self.max_records:
                raise ValueError('Journal closed or record capacity exceeded')
            if not tensors:
                raise ValueError('No input tensors')
            size = 0
            for value in tensors.values():
                if value.device != self.storage.device or value.dtype not in (self.torch.int32, self.torch.int64):
                    raise ValueError('Input device/dtype mismatch')
                if value.numel() == 0:
                    raise ValueError('Empty input tensor')
                size += value.numel()
            if self.cursor + size > self.capacity:
                raise OverflowError('Integer storage capacity exceeded')
            fields = {}
            for name, value in tensors.items():
                start, count = self.cursor, value.numel()
                self.storage[start:start + count].copy_(value.reshape(-1), non_blocking=True)
                fields[name] = dict(offset=start, count=count, shape=list(value.shape))
                self.cursor += count
            self.records.append(dict(metadata=deepcopy(metadata), fields=fields))
        except Exception as error:
            self.errors.append(type(error).__name__)
            raise

    def finish(self, synchronize):
        if self.closed:
            raise ValueError('Already exported')
        self.closed = True
        synchronize()
        values = self.storage[:self.cursor].cpu()
        records = []
        for entry in self.records:
            fields = {}
            for name, field in entry['fields'].items():
                start, count = field['offset'], field['count']
                fields[name] = values[start:start + count].reshape(field['shape']).tolist()
            records.append(dict(metadata=entry['metadata'], values=fields))
        return dict(records=records, errors=list(self.errors), integers_used=self.cursor,
                    capacity=self.capacity, complete=bool(records) and not self.errors,
                    stream_order_qualified=False, effective_flops=None)


def input_fields(proposer, kwargs, live_requests):
    """Select live slots/positions and native tables, not owned FIA read tables."""
    n, tokens = live_requests, kwargs['num_tokens']
    if type(n) is not int or type(tokens) is not int or not 0 < n <= tokens <= kwargs['num_input_tokens']:
        raise ValueError('Invalid live draft extent')
    if kwargs['batch_size'] != n or len(kwargs['multi_steps_attn_metadata']) != 2:
        raise ValueError('Only live MTP2 batch is supported')
    indices = kwargs['token_indices_to_sample']
    if tuple(indices.shape) != (n,):
        raise ValueError('Unexpected sampling index shape')
    positions = proposer._get_positions(kwargs['num_input_tokens'])
    if positions.ndim not in (1, 2) or positions.shape[-1] < tokens:
        raise ValueError('Unexpected position tensor')
    tensors = dict(sample_indices=indices, first_positions=positions[..., :tokens])
    for step, entries in enumerate(kwargs['multi_steps_attn_metadata']):
        if len(entries) != 1:
            raise ValueError('Expected one Qwen MTP attention layer')
        m = next(iter(entries.values()))
        rows = tokens if step == 0 else n
        if m.slot_mapping.ndim != 1 or m.slot_mapping.numel() < rows:
            raise ValueError('Incomplete slot mapping')
        if not isinstance(m.seq_lens_list, list) or len(m.seq_lens_list) < n:
            raise ValueError('Missing host read envelope')
        lengths = m.seq_lens_list[:n]
        if any(type(length) is not int or length <= 0 for length in lengths):
            raise ValueError('Invalid read envelope')
        columns = (max(lengths) + 127) // 128
        if m.block_tables.ndim != 2 or m.block_tables.shape[0] < n or m.block_tables.shape[1] < columns:
            raise ValueError('Read table cannot cover envelope')
        tensors[f'step{step}_slots'] = m.slot_mapping[:rows]
        tensors[f'step{step}_native_block_table'] = m.block_tables[:n, :columns]
    return tensors


class ObservedDraftRunnable:
    """Wrap the outer runnable, preserving its frame lookup and return value."""
    def __init__(self, inner, proposer, journal, context, capturing):
        self.inner, self.proposer, self.journal = inner, proposer, journal
        self.context, self.capturing = context, capturing
        self.seen = set()

    def __getattr__(self, name):
        return getattr(self.inner, name)

    def __call__(self, **kwargs):
        context = self.context()
        if context is None:
            return self.inner(**kwargs)
        if self.capturing():
            raise ValueError('Live workload is capturing a graph')
        identity = context['identity']
        key = (identity['run_id'], identity['wave'])
        if key in self.seen:
            raise ValueError('Duplicate input publication')
        batch = self.proposer.runner.input_batch
        ids = list(batch.req_ids[:batch.num_reqs])
        if not ids or len(ids) != len(set(ids)):
            raise ValueError('Invalid request identities')
        fields = input_fields(self.proposer, kwargs, len(ids))
        metadata = dict(kind='draft_inputs', identity=deepcopy(identity),
                        request_keys=[hashlib.sha256((key[0] + '\0' + rid).encode()).hexdigest()
                                      for rid in ids])
        self.journal.record(metadata, fields)
        self.seen.add(key)
        return self.inner(**kwargs)


def record_owned_table(journal, table, fields, context, request_keys):
    """Called after outer Frame.prepare, where the consumed table is published."""
    if fields['role'] != 'draft':
        return
    n = len(request_keys)
    host_values = fields['host_planning_kv_lengths']['host_values']
    if host_values is None:
        raise ValueError('Missing owned read envelope')
    lengths = host_values[:n]
    if len(lengths) != n or not n or any(type(x) is not int or x <= 0 for x in lengths):
        raise ValueError('Missing owned read envelope')
    columns = (max(lengths) + 127) // 128
    if table.ndim != 2 or table.shape[0] < n or table.shape[1] < columns:
        raise ValueError('Incomplete owned read table')
    journal.record(dict(kind='owned_read_table', identity=deepcopy(context['identity']),
                        draft_step=fields['draft_step'], request_keys=list(request_keys)),
                   dict(block_table=table[:n, :columns]))
