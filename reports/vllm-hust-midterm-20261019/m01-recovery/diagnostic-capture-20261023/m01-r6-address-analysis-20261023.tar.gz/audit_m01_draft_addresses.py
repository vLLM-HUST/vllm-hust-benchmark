"""Check observed slot writes against the published per-request read tables."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

HERE = Path('/workspace/m01-critical-path-review-20261023')
sys.path.insert(0, str(HERE))
from audit_draft_inputs import validate


def audit_worker(worker):
    validate(worker)
    inputs, tables = {}, {}
    for r in worker['draft_device_inputs']['records']:
        m = r['metadata']
        wave = m['identity']['wave']
        if m['kind'] == 'draft_inputs':
            inputs[wave] = r
        else:
            tables[wave, m['draft_step']] = r['values']['block_table']
    lengths = {(r['metadata']['identity']['wave'], r['metadata']['draft_step']): r
               for r in worker['draft_device_lengths']['records']}
    counts, mismatches = Counter(), []
    for wave, record in inputs.items():
        values = record['values']
        positions = values['first_positions']
        if isinstance(positions[0], list):
            if any(axis != positions[0] for axis in positions[1:]):
                raise ValueError('Non-text multidimensional positions need separate interpretation')
            positions = positions[0]
        start = 0
        for row, key in enumerate(record['metadata']['request_keys']):
            end = lengths[wave, 0]['device_query_lengths'][row]
            chosen = values['sample_indices'][row]
            if not start <= chosen < end:
                raise ValueError('Selected index leaves its request')
            checks = [(0, i, positions[i], values['step0_slots'][i]) for i in range(start, end)]
            checks.append((1, row, positions[chosen] + 1, values['step1_slots'][row]))
            for step, index, position, slot in checks:
                table = tables[wave, step][row]
                if position < 0 or position // 128 >= len(table):
                    raise ValueError('Write position outside captured read table')
                expected = table[position // 128] * 128 + position % 128
                counts[f'step{step}_writes'] += 1
                if slot != expected:
                    mismatches.append(dict(wave=wave, request_key=key, step=step,
                        index=index, position=position, slot=slot, expected=expected))
            start = end
        if start != len(positions):
            raise ValueError('Position extent disagrees with live queries')
    return dict(counts=dict(counts), mismatches=mismatches,
                status='observed_slot_positions_match' if not mismatches else 'slot_position_mismatches')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    hashes = {}
    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)
    receipt = read(args.run / 'receipt.json')
    if receipt['status'] != 'diagnostic_capture_joined' or not receipt['all_devices_released']:
        raise ValueError('Capture not completed/released')
    plan = read(args.run / 'execution-plan.json')
    for name in ('audit_draft_inputs.py',):
        path = HERE / name
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != plan['source_sha256'][str(path)]:
            raise ValueError('Frozen validator changed')
        hashes[str(path)] = digest
    results = []
    for path in sorted(args.run.glob('worker-*.json')):
        worker = read(path)
        results.append(dict(rank=worker['rank'], **audit_worker(worker)))
    if len(results) != 2:
        raise ValueError('TP2 exports required')
    hashes[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report = dict(run_id=receipt['run_id'], ranks=results, source_sha256=hashes,
                  effective_flops=None, reference_seconds=None,
                  scope='Observed write-slot and published read-table identity only; useful cache lifetime is separate.')
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps([dict(rank=r['rank'], status=r['status'], counts=r['counts'],
                           mismatch_count=len(r['mismatches'])) for r in results]))


if __name__ == '__main__':
    main()
