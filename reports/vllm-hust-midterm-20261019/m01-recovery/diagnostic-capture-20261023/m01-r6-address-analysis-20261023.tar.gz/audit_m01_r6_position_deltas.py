"""Describe observed RoPE/write-position deltas without correcting raw data."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/m01-capture-b1-r6')


def main():
    hashes = {}
    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)
    scheduler = read(ROOT / 'scheduler-961957.json')
    frames = {e['frame']: e['identity']['wave'] for e in scheduler['events'] if e['event'] == 'delivery'}
    prior, rows = {}, {}
    for event in scheduler['events']:
        if event['event'] not in ('output_update', 'not_updated'):
            continue
        key = event['request_key']
        rows[frames[event['frame']], key] = dict(prior_rejections=prior.get(key, 0), event=event['event'])
        if event['event'] == 'output_update':
            prior[key] = event['drafts'] + 1 - event['observation']['raw_count'] if event['drafts'] else 0
    ranks = []
    for pid in (962244, 962245):
        worker = read(ROOT / f'worker-{pid}.json')
        table = {(r['metadata']['identity']['wave'], r['metadata']['draft_step']): r['values']['block_table']
                 for r in worker['draft_device_inputs']['records'] if r['metadata']['kind'] == 'owned_read_table'}
        lengths = {(r['metadata']['identity']['wave'], r['metadata']['draft_step']): r
                   for r in worker['draft_device_lengths']['records']}
        counts, details = Counter(), []
        for record in worker['draft_device_inputs']['records']:
            if record['metadata']['kind'] != 'draft_inputs':
                continue
            wave = record['metadata']['identity']['wave']
            value = record['values']
            axes = value['first_positions']
            if isinstance(axes[0], list):
                assert all(axis == axes[0] for axis in axes)
                positions = axes[0]
            else:
                positions = axes
            start = 0
            for row, key in enumerate(record['metadata']['request_keys']):
                end = lengths[wave, 0]['device_query_lengths'][row]
                kv = lengths[wave, 0]['device_kv_lengths'][row]
                blocks = table[wave, 0][row][:(kv + 127) // 128]
                inverse = {block: i for i, block in enumerate(blocks)}
                assert len(inverse) == len(blocks)
                deltas = []
                for index in range(start, end):
                    slot = value['step0_slots'][index]
                    logical = inverse[slot // 128] * 128 + slot % 128
                    deltas.append(positions[index] - logical)
                unique = sorted(set(deltas))
                counts['request_rows'] += 1
                counts['position_tokens'] += end - start
                counts['nonzero_position_tokens'] += sum(delta != 0 for delta in deltas)
                fact = rows[wave, key]
                counts['uniform_row_delta'] += len(unique) == 1
                if unique == [0]:
                    counts['zero_delta_rows'] += 1
                else:
                    counts['nonzero_delta_rows'] += 1
                    counts['nonzero_matches_prior_rejections'] += unique == [fact['prior_rejections']]
                    details.append(dict(wave=wave, request_key=key, deltas=unique, **fact))
                start = end
        ranks.append(dict(rank=worker['rank'], counts=dict(counts), nonzero_rows=details))
    hashes[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report = dict(status='observed_position_write_deltas_not_corrected', ranks=ranks,
                  source_sha256=hashes, effective_flops=None, reference_seconds=None,
                  limitations=['Physical slot addresses are inverted through the observed owned table.',
                      'A position delta is not by itself proof of a kernel error or stream race.',
                      'No original position, source, validity flag or output is modified.'])
    with Path('/workspace/m01-r6-position-deltas.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps([dict(rank=r['rank'], counts=r['counts']) for r in ranks]))


if __name__ == '__main__':
    main()
