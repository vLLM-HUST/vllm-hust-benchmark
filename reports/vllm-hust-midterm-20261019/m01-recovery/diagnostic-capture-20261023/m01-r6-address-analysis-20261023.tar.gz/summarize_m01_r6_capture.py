from collections import Counter
import hashlib
import json
from pathlib import Path

root = Path('/workspace/m01-capture-b1-r6')
hashes = {}
workers = []
for path in sorted(root.glob('worker-*.json')):
    raw = path.read_bytes()
    hashes[str(path)] = hashlib.sha256(raw).hexdigest()
    workers.append(json.loads(raw))
assert len(workers) == 2
left, right = [w['draft_device_inputs']['records'] for w in workers]
assert len(left) == len(right)
differences = Counter()
for a, b in zip(left, right, strict=True):
    assert a['metadata'] == b['metadata']
    assert set(a['values']) == set(b['values'])
    for key in a['values']:
        differences[key] += a['values'][key] != b['values'][key]
report = dict(status='capture_complete_with_observed_cross_rank_position_differences',
    ranks=[dict(rank=w['rank'], input_records=len(w['draft_device_inputs']['records']),
                length_records=len(w['draft_device_lengths']['records']),
                integers_used=w['draft_device_inputs']['integers_used'],
                input_errors=w['draft_device_inputs']['errors']) for w in workers],
    differing_record_count_by_field=dict(differences), metadata_equal=True,
    source_sha256=hashes, effective_flops=None, reference_seconds=None,
    limitation='Position and second-step slot differences require source/stream diagnosis; no kernel-error or attainment conclusion.')
report['source_sha256'][str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
with Path('/workspace/m01-r6-capture-summary.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(report['differing_record_count_by_field']))
