import sys

sys.path.insert(0, '/workspace/m01-critical-path-review-20261023')
from test_audit_draft_inputs import sample
from audit_m01_draft_addresses import audit_worker


def fixture():
    worker = sample()
    values = worker['draft_device_inputs']['records'][0]['values']
    values['first_positions'] = [0, 1, 2, 128, 129, 130]
    values['step0_slots'] = [1280, 1281, 1282, 2688, 2689, 2690]
    values['step1_slots'] = [1282, 2690]
    return worker


def test_positions_and_slots_match_across_page_boundary():
    result = audit_worker(fixture())
    assert result['mismatches'] == []
    assert result['counts'] == dict(step0_writes=6, step1_writes=2)


def test_second_write_uses_selected_position_not_kv_envelope():
    worker = fixture()
    worker['draft_device_inputs']['records'][0]['values']['step1_slots'][0] = 1409
    result = audit_worker(worker)
    assert len(result['mismatches']) == 1
    assert result['mismatches'][0]['expected'] == 1282
