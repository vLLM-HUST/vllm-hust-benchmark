"""Reconcile observed draft device lengths with same-run request progress."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT=Path('/workspace/m01-capture-b1-r4')


def main():
    hashes={}
    def read(name):
        raw=(ROOT/name).read_bytes();hashes[name]=hashlib.sha256(raw).hexdigest()
        return json.loads(raw)
    scheduler=read('scheduler-894022.json')
    workers=[read(f'worker-{pid}.json') for pid in (894394,894395)]
    def rows(worker):
        result={}
        for record in worker['draft_device_lengths']['records']:
            m=record['metadata']; previous=0
            for i,key in enumerate(m['request_keys']):
                identity=(m['identity']['wave'],key,m['draft_step'])
                assert identity not in result
                end=record['device_query_lengths'][i]
                result[identity]=(end-previous,record['device_kv_lengths'][i])
                previous=end
        return result
    device=rows(workers[0]);assert device==rows(workers[1])
    frames={e['frame']:e['identity']['wave'] for e in scheduler['events'] if e['event']=='delivery'}
    prefill,output,counts=Counter(),Counter(),Counter()
    seen=set(); retained=0
    for e in scheduler['events']:
        if e['event'] not in ('output_update','not_updated'):continue
        key=e['request_key'];wave=frames[e['frame']]
        if e['drafts']==0:prefill[key]+=e['scheduled_tokens']
        first=(wave,key,0);second=(wave,key,1)
        if first in device:
            seen.update((first,second))
            q0,kv0=device[first];q1,kv1=device[second]
            assert q0==e['scheduled_tokens'] and q1==1 and kv1==kv0+1
            difference=kv0-(prefill[key]+output[key]+e['drafts'])
            if e['event']=='output_update':
                assert difference==0
                counts['updated_progress_matches']+=1
            elif difference==0:
                counts['skipped_progress_matches']+=1
            else:
                assert difference==1 and output[key]==256
                counts['post_budget_skips_with_extra_slot']+=1
        else:
            counts['rows_without_draft_snapshot']+=1
        if e['event']=='output_update':
            obs=e['observation'];output[key]+=obs['appended_count'];retained+=obs['retained_drafts']
            if first in device and e['drafts']+1-obs['raw_count']>0:
                counts['rejection_subtracted_step1_hypothesis_mismatches']+=1
    assert seen==set(device)
    assert sum(prefill.values())==282265 and len(output)==200 and set(output.values())=={256}
    report=dict(status='same_run_device_lengths_request_progress_reconciled',counts=dict(counts),
        input_tokens=sum(prefill.values()),output_tokens=sum(output.values()),retained_drafts=retained,
        rank_device_values_equal=True,source_sha256=hashes,effective_flops=None,reference_seconds=None,
        findings=['All updated rows match accumulated prefill plus prior retained outputs plus scheduled drafts.',
          'Second-step live query length is one; KV length is first-step KV length plus one.',
          'Post-budget extra-slot rows are retained as separate non-output work, not erased.',
          'Rejection-adjusted selected positions are not the same as published KV lengths.'],
        limitations=['Length consistency does not establish useful draft-cache lifetime or full arithmetic.',
          'No original stream_order_qualified field changed; no timing transfer or acceptance claim.'])
    with Path('/workspace/m01-r4-length-progress.json').open('x') as stream:
        json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps(report))


if __name__=='__main__':main()
