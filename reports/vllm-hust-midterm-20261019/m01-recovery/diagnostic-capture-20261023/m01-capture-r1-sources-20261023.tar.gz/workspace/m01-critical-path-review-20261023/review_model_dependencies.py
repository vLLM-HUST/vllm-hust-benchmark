"""Bind partial source-level dependencies to the measured B1 inventory."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-worker-r1')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    inventories = []
    for path in sorted(RUN.glob('token-accounting-*.jsonl')):
        with path.open() as stream:
            for line in stream:
                event = json.loads(line)
                if event.get('event') == 'loaded_model_inventory':
                    inventories.append(event['target'])
                    break
    if len(inventories) != 2:
        raise ValueError('Expected two worker inventories')
    selected = {}
    for name, expected in inventories[0]['source_sha256'].items():
        if not name.endswith(('/models/qwen3_5.py', '/models/qwen3_next.py', '/runtime/school028_attention.py')):
            continue
        path = Path(name)
        if inventories[1]['source_sha256'].get(name) != expected or sha(path) != expected:
            raise ValueError('Source identity mismatch: ' + name)
        tree = ast.parse(path.read_text())
        selected[name] = {'sha256': expected, 'functions': [
            {'name': n.name, 'line': n.lineno, 'end_line': n.end_lineno}
            for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)
            and n.name in ('prefix', 'layer_forward', 'admitted', 'install')
        ]}
    if len(selected) != 3:
        raise ValueError('Expected source set not found')
    layer_counts = []
    for inv in inventories:
        layers = [m for m in inv['modules'] if m['type'].endswith('.Qwen3_5DecoderLayer')]
        if len(layers) != 40:
            raise ValueError('Unexpected target layer count')
        if not all(m['methods']['forward']['file'].endswith('/runtime/school028_attention.py') for m in layers):
            raise ValueError('Unexpected decoder forward binding')
        layer_counts.append(dict(Counter(m['scalars']['layer_type'] for m in layers)))
    log_counts = {}
    for path in sorted(RUN.glob('microflow-*.jsonl')):
        counts, splits = Counter(), Counter()
        for line in path.open():
            row = json.loads(line)
            counts[row['event']] += 1
            if row['event'] == 'prefix':
                splits[str(row.get('split'))] += 1
        log_counts[path.name] = {'sha256': sha(path), 'events': dict(counts),
                                 'prefix_split': dict(splits)}
    result = {
        'status': 'partial_source_dependencies_bound_to_loaded_inventory',
        'sources': selected, 'target_layer_counts_by_worker': layer_counts,
        'microflow_logs': log_counts,
        'dependency_rules': [
            'For each admitted prefix partition, its input norm produces the input of that partition QKV projection.',
            'The vector-stream norm records a ready event consumed by the cube stream before the partition projection.',
            'Each partition projection records a done event consumed by the vector stream before its post-processing.',
            'These edges permit pipelining between partitions; they do not imply all norms then all projections execute serially.',
            'Admitted full-attention path consumes prefix q/k/v in attention, then output gating, output projection, post-attention normalization and MLP.',
            'Non-admitted layers delegate to the pinned inherited decoder forward; they cannot be assigned the admitted prefix graph.'
        ],
        'limitations': [
            'Prefix logs include capture/warmup; Python log counts are not device graph replay invocation counts.',
            'Stream join implementation, graph replay mapping, collective dependencies and independent per-stage reference weights remain to be joined.',
            'These are source-proven data dependencies, not a complete recovered hardware schedule.',
            'HBM time is not added again to independently measured kernels that already include their memory accesses.'
        ],
        'critical_path_seconds': None, 'efficiency_percent': None,
    }
    with (ROOT / 'model-dependency-review-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'source_count': len(selected),
                      'layer_counts': layer_counts, 'efficiency_percent': None}))


if __name__ == '__main__':
    main()
