import unittest
from derive_target_gdn_candidate import decode_counts


class GdnCandidateTests(unittest.TestCase):
    def test_prefill_only_output(self):
        result = decode_counts(12, 1, 1)
        self.assertEqual(result['recurrent_basic_flops'], 0)
        self.assertGreater(result['preprocess_basic_flops'], 0)

    def test_actual_decode_extent(self):
        self.assertEqual(decode_counts(282265, 51200, 200)['necessary_decode_rows'], 51000)

    def test_disjoint_additivity(self):
        a, b, combined = decode_counts(12, 3, 1), decode_counts(7, 2, 1), decode_counts(19, 5, 2)
        for key in ('recurrent_basic_flops', 'preprocess_basic_flops'):
            self.assertEqual(a[key] + b[key], combined[key])

    def test_invalid_output(self):
        with self.assertRaises(ValueError):
            decode_counts(12, 1, 2)
