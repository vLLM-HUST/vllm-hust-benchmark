"""Join exact existing reference shapes to the split-prefix dependency schedule."""
import hashlib
import json
from pathlib import Path
from statistics import mean
from prefix_reference_schedule import schedule


def select_case(cases, shape):
    matches = [c for c in cases if all(c['shape'].get(k) == v for k, v in shape.items())]
    if len(matches) != 1:
        raise ValueError(f'Expected unique exact reference shape: {shape}')
    case = matches[0]
    checks = case.get('checks', [case.get('check')])
    if not checks or any(not c or c.get('finite') is not True or c.get('close') is not True for c in checks):
        raise ValueError('Unqualified numerical reference')
    timings = case['timings']
    if not timings or len({t['repetition'] for t in timings}) != len(timings):
        raise ValueError('Missing or duplicate timing repetition')
    seconds = []
    for timing in timings:
        if timing['replays'] <= 0 or timing['device_ms'] <= 0:
            raise ValueError('Invalid reference timing')
        seconds.append(timing['device_ms'] / (1000 * timing['replays']))
    return dict(shape=case['shape'], samples_seconds=seconds, mean_seconds=mean(seconds))


def main():
    here = Path(__file__).resolve().parent
    verified = {}
    roots = {}
    for kind in ('linear', 'aux'):
        root = here / f'{kind}-restored-r1'
        roots[kind] = root
        manifest = root / f'workspace/m01-worker-{kind}-reference-manifest.json'
        data = json.loads(manifest.read_text())
        for source, expected in data['source_sha256'].items():
            path = root / source.lstrip('/')
            assert path.resolve().is_relative_to(root.resolve())
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            assert actual == expected, source
            verified[str(path)] = actual
        verified[str(manifest)] = hashlib.sha256(manifest.read_bytes()).hexdigest()
    rows = []
    for rank in (0, 1):
        files = dict(
            dense=roots['linear'] / f'workspace/m01-dense-reference-recovery-r1/results/rank-{rank}.json',
            norm=roots['aux'] / f'root/gennova-evidence/20261019-midterm-aligned/norm-reference-r2/rank-{rank}.json',
            post=roots['aux'] / f'root/gennova-evidence/20261019-midterm-aligned/rope-reference-r2/rank-{rank}.json')
        cases = {}
        for name, path in files.items():
            assert str(path) in verified
            data = json.loads(path.read_text())
            assert data['rank'] == rank
            cases[name] = data['cases']
        for tokens, pieces in ((1024, 2), (2048, 2), (4096, 4)):
            size = tokens // pieces
            norm = select_case(cases['norm'], dict(kind='hidden_residual', rows=size, width=2048))
            qkv = select_case(cases['dense'], dict(m=size, n=4608, k=2048))
            post = [select_case(cases['post'], dict(kind='partitioned', rows=size,
                    cos_tokens=tokens, offset=i*size)) for i in range(pieces)]
            result = schedule([norm['mean_seconds']]*pieces, [qkv['mean_seconds']]*pieces,
                              [p['mean_seconds'] for p in post])
            rows.append(dict(rank=rank, tokens=tokens, pieces=pieces, norm=norm, qkv=qkv, post=post,
                             schedule=result))
    for path in (Path(__file__), here / 'prefix_reference_schedule.py'):
        verified[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    result = dict(status='exact_shape_independent_component_join_overlap_applicability_pending',
        rows=rows, model_reference_seconds=None, efficiency_percent=None, source_sha256=verified,
        limitations=['Only split FA prefixes with residual input; no full-model invocation weighting.',
                     'All independent repetitions retained; component means are not falsely paired by repetition index.',
                     'Uncongested queue schedule requires overlap/interference and event/launch-cost validation.',
                     'Copy/allocation/residual movement not separately calibrated here; do not claim an end-to-end prefix latency.',
                     'References include each kernel memory accesses; no additional global HBM term.'])
    with (here / 'prefix-reference-join-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([dict(rank=r['rank'], tokens=r['tokens'],
        dependency_us=r['schedule']['prefix_reference_seconds']*1e6,
        serial_us=r['schedule']['serial_phase_sum']*1e6) for r in rows]))


if __name__ == '__main__':
    main()
