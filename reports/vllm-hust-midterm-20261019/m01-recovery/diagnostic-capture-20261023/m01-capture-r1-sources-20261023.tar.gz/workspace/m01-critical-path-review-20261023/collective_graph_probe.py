"""Graph probe core. Caller must own device admission and distributed lifecycle."""
import math
import time


def memory_bytes(shape, batch):
    if batch not in (1, 8, 32):
        raise ValueError('Unplanned graph batch')
    n = shape['input_bytes_per_call']
    if type(n) is not int or n <= 0:
        raise ValueError('Invalid input allocation')
    if shape['kind'] not in ('all_reduce', 'all_gather'):
        raise ValueError('Unsupported collective')
    return n * batch * (3 if shape['kind'] == 'all_gather' else 1)


def captured_calls(dist, kind, inputs, outputs):
    # This function alone is captured: no reset, synchronization, or validation.
    for index, tensor in enumerate(inputs):
        if kind == 'all_reduce':
            dist.all_reduce(tensor)
        elif kind == 'all_gather':
            dist.all_gather(outputs[index], tensor)
        else:
            raise ValueError('Unsupported collective')


def timed_replay(npu, graph, prepare, validate, rendezvous, clock=time.perf_counter):
    prepare()
    npu.synchronize()
    rendezvous()
    npu.synchronize()
    start, end = npu.Event(enable_timing=True), npu.Event(enable_timing=True)
    t0 = clock()
    start.record()
    graph.replay()
    end.record()
    end.synchronize()
    npu.synchronize()
    seconds = clock() - t0
    device_ms = start.elapsed_time(end)
    if not math.isfinite(seconds) or seconds <= 0 or not math.isfinite(device_ms) or device_ms < 0:
        raise ValueError('Invalid clock sample')
    validate()
    return {'synchronized_wall_seconds': seconds, 'device_ms': device_ms,
            'numerics_passed': True}


def measure_shape(torch, dist, shape, batch, rank, rendezvous, emit, samples=16):
    if rank not in (0, 1) or dist.get_world_size() != 2:
        raise ValueError('Probe requires TP2')
    if type(samples) is not int or samples != 16:
        raise ValueError('Expected frozen 16 samples per repetition')
    allocation = memory_bytes(shape, batch)
    if allocation > 2 * 1024**3:
        raise ValueError('Per-shape tensor budget exceeded')
    dtype = {'BFP16': torch.bfloat16, 'INT64': torch.int64}[shape['dtype']]
    inputs = [torch.full((shape['elements'],), rank + 1, dtype=dtype, device=f'npu:{rank}')
              for _ in range(batch)]
    if inputs[0].numel() * inputs[0].element_size() != shape['input_bytes_per_call']:
        raise ValueError('Tensor does not match frozen payload')
    outputs = [[torch.empty_like(tensor) for _ in range(2)] for tensor in inputs] if shape['kind'] == 'all_gather' else []

    def prepare():
        for tensor in inputs:
            tensor.fill_(rank + 1)

    def validate():
        values = [(tensor, 3) for tensor in inputs] if shape['kind'] == 'all_reduce' else [
            (tensor, peer + 1) for group in outputs for peer, tensor in enumerate(group)]
        if not all(bool(torch.all(tensor == expected).item()) for tensor, expected in values):
            raise ValueError('Collective numerical validation failed')

    for _ in range(5):
        prepare()
        captured_calls(dist, shape['kind'], inputs, outputs)
        torch.npu.synchronize()
        validate()
    prepare()
    torch.npu.synchronize()
    rendezvous()
    graph = torch.npu.NPUGraph()
    with torch.npu.graph(graph):
        captured_calls(dist, shape['kind'], inputs, outputs)
    # Capture behavior can vary; reset before each replay and never reuse reductions.
    rows = []
    for repetition in range(3):
        for _ in range(3):
            prepare()
            torch.npu.synchronize()
            rendezvous()
            graph.replay()
            torch.npu.synchronize()
            validate()
        for sample in range(samples):
            row = timed_replay(torch.npu, graph, prepare, validate, rendezvous)
            row = dict(row, repetition=repetition, sample=sample, calls=batch)
            emit(dict(row, shape=shape, batch=batch, rank=rank))
            rows.append(row)
    return {'shape': shape, 'batch': batch, 'rank': rank, 'allocated_tensor_bytes': allocation,
            'samples': rows, 'scope': 'Graph-batch calibration including graph-boundary synchronization; not whole-model efficiency.'}


if __name__ == '__main__':
    raise SystemExit('Not a standalone launcher: validated device admission and lifecycle controller required.')
