import unittest
from reconstruct_acceptance_epochs import reconstruct


def prefill():
    return dict(metadata=dict(prefill_ids=[0], verify_ids=[]),
                device_fields=dict(cu=[[0], [10]], prefill_conv=[[0]], initial=[[False]], verify_slots=[]))


def verify(feedback):
    return dict(metadata=dict(prefill_ids=[], verify_ids=[0]),
                device_fields=dict(cu=[[0], [3]], verify_slots=[[0, 1, 2]], verify_accepted=[[feedback]]))


class EpochTests(unittest.TestCase):
    def test_next_feedback_and_tail(self):
        epochs = reconstruct([prefill(), verify(1), verify(2)], 4)
        self.assertEqual([x['committed_outputs'] for x in epochs[0]['verification_steps']], [2, 1])
        self.assertEqual(epochs[0]['useful_accepted_draft_tokens'], 1)

    def test_seat_reuse(self):
        epochs = reconstruct([prefill(), verify(1), prefill(), verify(1)], 4)
        self.assertEqual(len(epochs), 2)
        self.assertEqual([e['verification_steps'][0]['committed_outputs'] for e in epochs], [3, 3])

    def test_orphan(self):
        with self.assertRaises(ValueError): reconstruct([verify(1)], 4)

    def test_impossible_budget(self):
        with self.assertRaises(ValueError): reconstruct([prefill(), verify(1)], 10)


if __name__ == '__main__':
    unittest.main()
