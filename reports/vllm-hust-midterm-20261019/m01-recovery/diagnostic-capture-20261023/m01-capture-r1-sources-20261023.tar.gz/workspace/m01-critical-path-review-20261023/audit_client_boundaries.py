"""Reconcile existing detailed request timings with their own run envelopes."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def reconcile(data, receipt):
    starts, latencies = data['start_times'], data['latencies']
    if len(starts) != 200 or len(latencies) != 200:
        raise ValueError('Incomplete request timing population')
    if any(not math.isfinite(x) or x < 0 for x in starts + latencies):
        raise ValueError('Invalid request timing')
    duration = data['duration']
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('Invalid duration')
    first = min(starts)
    last = max(s + t for s, t in zip(starts, latencies))
    span = last - first
    if span > duration + 1e-6:
        raise ValueError('Request span exceeds recorded measurement')
    if not receipt['bench_started_monotonic'] <= first <= last <= receipt['bench_ended_monotonic']:
        raise ValueError('Request timings escape client process envelope')
    return {'request_span_s': span, 'recorded_duration_s': duration,
            'duration_minus_request_span_s': duration - span,
            'first_request_monotonic': first, 'last_response_monotonic': last,
            'client_process_envelope_s': receipt['bench_ended_monotonic'] - receipt['bench_started_monotonic']}


def main():
    hashes, rows = {}, {}
    for i in (9, 10, 11):
        name = f'mmlu-b1-microflow-fa-on-r{i}'
        documents = []
        for filename in ('mmlu-pro.json', 'receipt.json'):
            path = ROOT / name / filename
            raw = path.read_bytes()
            hashes[str(path)] = hashlib.sha256(raw).hexdigest()
            documents.append(json.loads(raw))
        data, receipt = documents
        assert (data['completed'], data['failed']) == (200, 0)
        assert receipt['status'] == 'measured' and receipt['all_devices_released']
        rows[name] = reconcile(data, receipt)
    hashes[str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result = {'status': 'existing_client_timings_reconciled', 'runs': rows,
              'source_sha256': hashes,
              'conclusions': [
                  'The approximately 62-second measurements enclose all 200 recorded request latencies.',
                  'They are not the approximately 93-second client process lifetime including startup.',
                  'No interval is subtracted from published timing.',
                  'This arithmetic reconciliation does not establish device synchronization or historical client source identity.',
                  'No new inference run is required solely to reproduce these client timing extents.'
              ],
              'remaining_boundary_question': 'Establish whether response completion includes all in-scope device work; distinguish necessary finalization from out-of-scope service teardown.'}
    with Path(__file__).with_name('client-boundary-audit-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(rows, indent=2))


if __name__ == '__main__':
    main()
