"""Opt-in qualification bridge; no plugin installation or device synchronization."""
from contextvars import ContextVar
from copy import deepcopy
import time
from types import SimpleNamespace

from scheduler_output_ledger import SchedulerOutputLedger
from worker_wave_identity import attach, validate

ACTIVE_WAVE = ContextVar('m01_active_wave', default=None)


def check_run_label(run_id):
    attach(SimpleNamespace(num_scheduled_tokens={}, scheduled_spec_decode_tokens={},
                           total_num_scheduled_tokens=0), run_id=run_id, wave=0)


class SchedulerWaveCapture(SchedulerOutputLedger):
    def enable_wave_capture(self, *, run_id, max_events, max_requests):
        check_run_label(run_id)
        self.enable_output_ledger(max_events=max_events, max_requests=max_requests)
        self._wave_run_id = run_id
        self._next_wave = 0

    def schedule(self, *args, **kwargs):
        output = super().schedule(*args, **kwargs)
        if hasattr(self, '_wave_run_id'):
            tag = attach(output, run_id=self._wave_run_id, wave=self._next_wave)
            self._next_wave += 1
            self._ledger_emit('scheduled', identity=tag)
        return output

    def update_from_output(self, scheduler_output, model_runner_output):
        if hasattr(self, '_wave_run_id'):
            tag = validate(scheduler_output, run_id=self._wave_run_id)
            self._ledger_emit('delivery', identity=tag, frame=self._output_ledger['next_frame'])
        return super().update_from_output(scheduler_output, model_runner_output)


class WorkerWaveCapture:
    def enable_wave_capture(self, *, run_id, max_events):
        if hasattr(self, '_wave_events'):
            raise ValueError('Capture already enabled')
        check_run_label(run_id)
        if type(max_events) is not int or max_events <= 0:
            raise ValueError('Explicit positive buffer limit required')
        self._wave_run_id, self._wave_limit = run_id, max_events
        self._wave_events, self._wave_errors, self._wave_dropped = [], 0, 0
        self._pending_wave = None

    def _wave_emit(self, event, **fields):
        if len(self._wave_events) >= self._wave_limit:
            self._wave_dropped += 1
        else:
            self._wave_events.append(dict(event=event, perf_ns=time.perf_counter_ns(), **fields))

    def _in_wave(self, phase, tag, call):
        context = ACTIVE_WAVE.set(dict(identity=tag, phase=phase, recorder=self))
        self._wave_emit(phase + '_begin', identity=tag)
        try:
            return call()
        except BaseException:
            self._wave_errors += 1
            raise
        finally:
            self._wave_emit(phase + '_end', identity=tag)
            ACTIVE_WAVE.reset(context)

    def execute_model(self, scheduler_output):
        if not hasattr(self, '_wave_events'):
            return super().execute_model(scheduler_output)
        if self._pending_wave is not None:
            self._wave_errors += 1
            raise ValueError('Previous sampling phase not completed')
        tag = validate(scheduler_output, run_id=self._wave_run_id)
        native = super().execute_model
        output = self._in_wave('execute', tag, lambda: native(scheduler_output))
        # In this pinned PP1 runner, deferred sampling owns an explicit state.
        if self.model_runner.execute_model_state is not None:
            self._pending_wave = tag
        return output

    def sample_tokens(self, grammar_output):
        if not hasattr(self, '_wave_events'):
            return super().sample_tokens(grammar_output)
        if self._pending_wave is None:
            self._wave_errors += 1
            raise ValueError('Sampling without a matching execute wave')
        tag = self._pending_wave
        native = super().sample_tokens
        try:
            return self._in_wave('sample', tag, lambda: native(grammar_output))
        finally:
            self._pending_wave = None

    def wave_capture_snapshot(self):
        return dict(events=deepcopy(self._wave_events), errors=self._wave_errors,
                    dropped=self._wave_dropped, pending=self._pending_wave is not None,
                    complete=not (self._wave_errors or self._wave_dropped or self._pending_wave),
                    effective_flops=None,
                    scope='Host execution dispatch and deferred sampling, not device completion times')


def record_host_prefill(groups):
    context = ACTIVE_WAVE.get()
    if context is None:
        raise ValueError('Host prefill record has no active worker wave')
    context['recorder']._wave_emit('host_prefill', identity=context['identity'],
                                  phase=context['phase'], groups=deepcopy(groups))
