"""Prepare observed collective shapes; never admits or starts a device job."""
import hashlib
import json
from pathlib import Path

SOURCE = Path('/root/vllm-hust-benchmark/reports/vllm-hust-midterm-20261019/m01-recovery/worker-model-20261022/m01-worker-collective-reference-joined.json')


def grid(rows):
    seen, result = set(), []
    for row in rows:
        item = row['observed']
        kind, dtype, n, ranks = (item[k] for k in ('kind', 'dtype', 'elements', 'rank_size'))
        if kind not in ('all_gather', 'all_reduce') or dtype not in ('BFP16', 'INT64') or ranks != 2:
            raise ValueError('Unexpected collective contract')
        if type(n) is not int or n <= 0 or type(item['calls']) is not int or item['calls'] <= 0:
            raise ValueError('Invalid shape or count')
        width = 2 if dtype == 'BFP16' else 8
        if item['input_bytes_per_call'] != n * width:
            raise ValueError('Payload bytes disagree with dtype and elements')
        key = (kind, dtype, n, ranks)
        if key in seen:
            raise ValueError('Duplicate collective shape')
        seen.add(key)
        result.append({k: item[k] for k in ('kind', 'dtype', 'elements', 'rank_size', 'input_bytes_per_call', 'calls')})
    return sorted(result, key=lambda x: (x['kind'], x['dtype'], x['elements']))


def main():
    raw = SOURCE.read_bytes()
    data = json.loads(raw)
    rows = grid(data['shapes'])
    assert len(rows) == 75 and sum(r['calls'] for r in rows) == 83096
    result = {
        'status': 'offline_preparation_not_admitted_for_execution',
        'purpose': 'Independently measure graph-compatible collective references without per-operation host synchronization.',
        'source_sha256': {str(SOURCE): hashlib.sha256(raw).hexdigest(),
                          str(Path(__file__)): hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
        'shapes': rows, 'participating_chips': 2,
        'repetitions': 3,
        'graph_batch_sizes_for_boundary_sensitivity': [1, 8, 32],
        'reference_selection': 'Retain all batch sizes. Map dispatch boundaries to model execution before selecting a reference; never choose by resulting efficiency.',
        'input_buffers': 'Independent per operation; initialize outside timed replay. Reset all_reduce inputs before every replay to prevent repeated reduction growth.',
        'timing': 'Synchronize before and after whole graph; retain both synchronized wallclock and device-event time. No synchronization or fill inside captured operations.',
        'validation': 'Check full outputs for every shape, rank and measured replay after timing; input and output checks cannot be placed inside the timed graph.',
        'reuse_scope': 'Payload and link-counter evidence remains valid. Old call counts describe the observed run, not automatically useful-work reference multiplicities.',
        'admission_required': [
            'Finish existing FS solver and judge and verify device release; acquire shared experiment locks.',
            'Pin actual runtime, transport and collective implementation against B1; qualify graph capture and completion semantics.',
            'Review executor, timeout cleanup and per-shape memory bounds before freezing launch plan.',
            'Preserve all numerical/capture failures; do not silently fall back to eager execution.',
        ],
        'execution_started': False, 'new_efficiency_percent': None,
    }
    path = Path(__file__).with_name('collective-graph-grid-preparation-r1.json')
    with path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'shapes': len(rows), 'observed_calls_per_rank': sum(r['calls'] for r in rows),
                      'largest_input_bytes': max(r['input_bytes_per_call'] for r in rows), 'execution_started': False}))


if __name__ == '__main__':
    main()
