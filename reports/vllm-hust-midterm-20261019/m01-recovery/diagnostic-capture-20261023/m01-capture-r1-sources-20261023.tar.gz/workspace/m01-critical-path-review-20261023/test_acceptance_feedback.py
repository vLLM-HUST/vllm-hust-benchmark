import unittest
from audit_acceptance_feedback import summarize
from reconcile_acceptance_aggregate import partition


class FeedbackTests(unittest.TestCase):
    def record(self):
        return dict(metadata=dict(live=2, verify_count=1, prefill_ids=[0], verify_ids=[1]),
                    device_fields=dict(cu=[[0], [10], [13]], initial=[[False], [True]],
                        accepted=[[1], [2]], verify_accepted=[[2]], verify_slots=[[-1, -1, -1]]))

    def test_feedback(self):
        result = summarize([self.record()])
        self.assertEqual(result['feedback_minus_mandatory_one'], 1)

    def test_wrong_feedback_selection(self):
        record = self.record()
        record['device_fields']['verify_accepted'] = [[3]]
        with self.assertRaises(ValueError): summarize([record])

    def test_terminal_partition(self):
        result = partition([self.record()])
        self.assertEqual(result['prefill_rows'], 10)
        self.assertEqual(result['terminal_verify_rows'], 3)
        self.assertEqual(result['active_verify_rows'], 0)

    def test_overlap_rejected(self):
        record = self.record()
        record['metadata']['prefill_ids'] = [0, 1]
        with self.assertRaises(ValueError): partition([record])


if __name__ == '__main__':
    unittest.main()
