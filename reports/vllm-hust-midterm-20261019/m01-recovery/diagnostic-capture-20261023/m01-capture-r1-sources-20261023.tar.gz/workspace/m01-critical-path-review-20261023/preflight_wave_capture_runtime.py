"""Exercise real runtime classes without model construction; imports may initialize NPU."""
import hashlib
import inspect
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace as NS
from unittest.mock import patch

import torch
import wave_capture_runtime as runtime


def main():
    initialized_on_import = torch.npu.is_initialized()
    with tempfile.TemporaryDirectory(prefix='m01-runtime-preflight-', dir='/workspace') as directory:
        env = dict(HUST_M01_CAPTURE_RUN_ID='offline-preflight', HUST_M01_CAPTURE_DIR=directory,
                   HUST_M01_CAPTURE_MAX_EVENTS='32', HUST_M01_CAPTURE_MAX_REQUESTS='8')
        with patch.dict(os.environ, env):
            worker = object.__new__(runtime.CaptureWorker)
            worker.model_runner = object.__new__(runtime.NPUModelRunner)
            worker.vllm_config = NS(parallel_config=NS(pipeline_parallel_size=1, tensor_parallel_size=2))
            with patch.object(runtime.MicroflowWorker, 'load_model', return_value='native-load-not-executed'):
                assert worker.load_model() == 'native-load-not-executed'
            assert type(worker.model_runner) is runtime.CaptureRunner
            assert worker._pending_wave is None
            assert worker.wave_capture_snapshot()['complete']
            worker._wave_emit('preflight_only')
            with patch.object(torch.npu, 'synchronize') as fence, patch.object(torch.distributed, 'get_rank', return_value=0):
                receipt = worker.hust_m01_export_wave_capture()
                fence.assert_called_once_with()
            assert receipt['capture_complete']
            assert json.loads((Path(directory) / receipt['file']).read_text())['measurement_role'] == 'diagnostic_qualification'
            scheduler = object.__new__(runtime.CaptureScheduler)
            scheduler._capture_directory = Path(directory)
            scheduler.requests = {}
            scheduler.enable_wave_capture(run_id='offline-preflight', max_events=32, max_requests=8)
            with patch.object(runtime.LiveStateScheduler, 'shutdown') as cleanup:
                scheduler.shutdown()
                cleanup.assert_called_once_with()
            record = json.loads(next(Path(directory).glob('scheduler-*.json')).read_text())
            assert record['active_requests'] == 0 and record['complete']
    initialized_at_end = torch.npu.is_initialized()
    here = Path(__file__).resolve().parent
    paths = [Path(__file__), Path(inspect.getfile(runtime.NPUModelRunner)),
             Path(inspect.getfile(runtime.LiveStateScheduler)), Path(inspect.getfile(runtime.MicroflowWorker))]
    paths += [here / name for name in ('wave_capture_runtime.py', 'wave_capture_bridge.py',
        'worker_wave_identity.py', 'host_prefill_wave_capture.py', 'scheduler_output_ledger.py',
        'retained_output_observation.py', 'capture_export.py', 'dual_clock_boundary.py')]
    result = dict(status='real_runtime_classes_offline_preflight_passed', model_loaded=False,
        npu_context_initialized_on_import=initialized_on_import,
        npu_context_initialized_at_end=initialized_at_end,
        native_load_and_device_fence_mocked=True,
        runner_class_reassignment_passed=True, scheduler_and_worker_export_passed=True,
        qualification_passed=False, effective_flops=None, m01_attainment=None,
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (here / 'wave-runtime-preflight-r2.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'source_sha256'}))


if __name__ == '__main__':
    main()
