"""Distributed worker; requires a hash-bound plan from an admitted controller."""
import argparse
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import time

from collective_graph_probe import measure_shape
from prepare_collective_graph_grid import grid


def validate_plan(plan):
    here = Path(__file__).resolve().parent
    required = [here / name for name in ('collective_graph_worker.py', 'collective_graph_probe.py',
                                         'prepare_collective_graph_grid.py')]
    if any(str(path) not in plan['source_sha256'] for path in required):
        raise ValueError('Missing executable source identity')
    if plan['status'] != 'frozen_for_qualification':
        raise ValueError('Plan is not frozen for qualification')
    if plan['runtime_versions'] != {'torch': '2.13.0+cpu', 'torch_npu': '2.13.0.rc1'}:
        raise ValueError('Unexpected calibrated runtime')
    if plan['batch_sizes'] != [1, 8, 32] or plan['samples'] != 16 or plan['repetitions'] != 3:
        raise ValueError('Measurement protocol changed')
    if not 1024 <= plan['port'] <= 65535:
        raise ValueError('Invalid local rendezvous port')
    if grid([{'observed': row} for row in plan['shapes']]) != plan['shapes']:
        raise ValueError('Unsorted or invalid shapes')
    if len(plan['shapes']) != 75:
        raise ValueError('Expected complete observed grid')
    for name, expected in plan['source_sha256'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Source mismatch: {name}')


def worker(rank, plan, output):
    os.environ['HUST_TOKEN_OBSERVER'] = '0'
    import torch
    import torch.distributed as dist
    import torch_npu

    out = Path(output)
    record = {'rank': rank, 'status': 'starting', 'started': time.time(),
              'runtime_versions': {'torch': torch.__version__, 'torch_npu': torch_npu.__version__},
              'runtime_paths': {'torch': torch.__file__, 'torch_npu': torch_npu.__file__},
              'pid': os.getpid(), 'completed_shapes': 0, 'fallback': False}

    def save():
        (out / f'rank-{rank}.json').write_text(json.dumps(record, indent=2) + '\n')

    save()
    try:
        if record['runtime_versions'] != plan['runtime_versions']:
            raise ValueError('Runtime differs from pinned previous calibration')
        for name, module in [('torch', torch), ('torch_npu', torch_npu)]:
            expected = plan['runtime_modules'][name]
            path = Path(module.__file__).resolve()
            if str(path) != expected['path'] or hashlib.sha256(path.read_bytes()).hexdigest() != expected['sha256']:
                raise ValueError(f'Actual runtime import mismatch: {name}')
        torch.npu.set_device(rank)
        dist.init_process_group('hccl', rank=rank, world_size=2, timeout=timedelta(seconds=180))

        def rendezvous():
            dist.barrier()

        with (out / f'samples-{rank}.jsonl').open('x') as samples:
            def emit(row):
                samples.write(json.dumps(row) + '\n')
                samples.flush()

            for index, shape in enumerate(plan['shapes']):
                record.update(status='measuring', shape_index=index, shape=shape)
                save()
                for batch in plan['batch_sizes']:
                    record['batch'] = batch
                    save()
                    measure_shape(torch, dist, shape, batch, rank, rendezvous, emit,
                                  samples=plan['samples'])
                record['completed_shapes'] += 1
                save()
        torch.npu.synchronize()
        dist.barrier()
        record['status'] = 'collected_pending_joint_audit'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        record['ended'] = time.time()
        save()
        if dist.is_initialized():
            dist.destroy_process_group()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    validate_plan(plan)
    if args.check:
        print('PASS: frozen inputs and protocol; no device job started')
        return
    admission = args.output / 'admission.json'
    data = json.loads(admission.read_text())
    if data['plan_sha256'] != hashlib.sha256(args.plan.read_bytes()).hexdigest():
        raise ValueError('Controller admission is for another plan')
    if data['controller_pid'] != os.getppid():
        raise ValueError('Must be launched directly by admitted controller')
    os.environ['MASTER_ADDR'] = '127.0.0.1'
    os.environ['MASTER_PORT'] = str(plan['port'])
    os.environ['HUST_TOKEN_OBSERVER'] = '0'
    import torch.multiprocessing as mp
    mp.spawn(worker, args=(plan, str(args.output)), nprocs=2, join=True)


if __name__ == '__main__':
    main()
