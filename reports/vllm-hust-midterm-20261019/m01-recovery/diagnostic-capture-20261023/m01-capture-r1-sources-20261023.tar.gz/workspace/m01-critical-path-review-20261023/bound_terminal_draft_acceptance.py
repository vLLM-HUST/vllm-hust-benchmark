"""Correct the mandatory-token subtraction when final output is clipped."""
import hashlib
import json
from pathlib import Path


def clipped_request_bounds(final_histogram, excess):
    one, two = final_histogram.get(1, 0), final_histogram.get(2, 0)
    if any(type(x) is not int or x < 0 for x in (one, two, excess)):
        raise ValueError('Nonnegative integer extents required')
    possibilities = []
    for raw_three_at_one in range(one + 1):
        for raw_two_at_one in range(one - raw_three_at_one + 1):
            raw_three_at_two = excess - 2 * raw_three_at_one - raw_two_at_one
            if 0 <= raw_three_at_two <= two:
                possibilities.append(raw_three_at_one + raw_two_at_one + raw_three_at_two)
    if not possibilities:
        raise ValueError('No terminal sampler allocation satisfies aggregate excess')
    return min(possibilities), max(possibilities)


def main():
    here = Path(__file__).resolve().parent
    paths = [here / 'acceptance-epoch-reconstruction-r1.json', here / 'acceptance-aggregate-reconciliation-r1.json']
    epoch, aggregate = [json.loads(p.read_text()) for p in paths]
    histogram = {int(k): v for k, v in epoch['final_committed_histogram'].items()}
    low, high = clipped_request_bounds(histogram, aggregate['implied_output_boundary_excess'])
    mandatory_subtracted = sum(s['committed_outputs'] - 1 for e in epoch['epochs'] for s in e['verification_steps'])
    assert mandatory_subtracted == 31899
    paths.append(Path(__file__))
    result = dict(status='terminal_clipping_interpretation_corrected_interval_not_point_estimate',
        supersedes_interpretation='The useful_accepted_draft_tokens field in acceptance-epoch-reconstruction-r1.json was mislabeled: it is committed output minus one per verification, not exact useful draft acceptance at clipped final steps.',
        committed_minus_one_per_verification=mandatory_subtracted,
        final_committed_histogram=histogram, aggregate_clipped_output_tokens=aggregate['implied_output_boundary_excess'],
        clipped_final_requests_lower=low, clipped_final_requests_upper=high,
        useful_accepted_draft_tokens_lower=mandatory_subtracted+low,
        useful_accepted_draft_tokens_upper=mandatory_subtracted+high,
        effective_flops=None, efficiency_percent=None,
        reasoning='Sampler output is an accepted draft prefix followed by one correction/bonus token. Final budget truncation can discard that last token; subtracting one for every clipped final step therefore undercounts useful drafts by one per clipped request.',
        assumptions=['Two proposed drafts per active verification; raw accepted aggregate and reconstructed requests have matching scope.',
                     'Only final output budget truncation accounts for the aggregate 206 excess; no unrecorded stop-string or external abort.',
                     'No individual final raw sampler outcome is inferred uniquely.'],
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (here / 'terminal-draft-acceptance-bounds-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','committed_minus_one_per_verification',
        'useful_accepted_draft_tokens_lower','useful_accepted_draft_tokens_upper')}))


if __name__ == '__main__':
    main()
