#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH LD_PRELOAD HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy OPENAI_API_KEY
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
REC=/root/frontierscience-recovery-20261022
export PYTHONPATH="$REC/filtered-site"
export ASCEND_RT_VISIBLE_DEVICES=0,1 TASK_QUEUE_ENABLE=0
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
export HUST_TOKEN_OBSERVER=0
exec "$REC/venv/bin/python" "$@"
