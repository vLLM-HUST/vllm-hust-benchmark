"""Boundary-only synchronization for an isolated, externally owned TP2 service."""
import os
import socket
import time


class WorkerBoundary:
    def hust_m01_sync_boundary(self, phase):
        if phase not in ('begin', 'end'):
            raise ValueError('Invalid boundary phase')
        import torch
        start = time.monotonic_ns()
        torch.npu.synchronize()
        end = time.monotonic_ns()
        from vllm_ascend.ascend_config import get_ascend_config
        config = get_ascend_config()
        runtime_configuration = {name: getattr(config, name) for name in
            ('multistream_overlap_shared_expert', 'enable_shared_expert_dp')}
        return dict(rank=torch.distributed.get_rank(), pid=os.getpid(), host=socket.gethostname(),
                    device=str(self.device), phase=phase, sync_start_ns=start,
                    sync_end_ns=end, device_sync_completed=True,
                    runtime_configuration=runtime_configuration)


def validate_fences(response, phase, expected_identity=None):
    records = response.get('results')
    if not isinstance(records, list) or len(records) != 2:
        raise ValueError('Exactly two worker acknowledgements required')
    identity = {}
    for row in records:
        rank = row.get('rank')
        if type(rank) is not int or rank not in (0, 1) or rank in identity:
            raise ValueError('Invalid or duplicate worker rank')
        if row.get('phase') != phase or row.get('device_sync_completed') is not True:
            raise ValueError('Missing completed boundary fence')
        if any(type(row.get(k)) is not int or row[k] < 0 for k in ('sync_start_ns', 'sync_end_ns')):
            raise ValueError('Invalid worker timing')
        if row['sync_end_ns'] < row['sync_start_ns']:
            raise ValueError('Reversed worker timing')
        if type(row.get('pid')) is not int or row['pid'] <= 0 or not row.get('host') or not row.get('device'):
            raise ValueError('Missing worker identity')
        identity[rank] = (row['pid'], row['host'], row['device'])
    if expected_identity is not None and identity != expected_identity:
        raise ValueError('Worker identity changed during measurement')
    return identity


class ClientBoundary:
    def __init__(self, post):
        self.post = post
        self.identity = None
        self.state = 'new'
        self.calls = []

    async def call(self, path, payload=None):
        start = time.monotonic_ns()
        response = await self.post(path, payload)
        self.calls.append(dict(path=path, request=payload, start_ns=start,
                               end_ns=time.monotonic_ns(), response=response))
        return response

    async def begin(self):
        if self.state != 'new':
            raise ValueError('Boundary already used')
        self.state = 'starting'
        if (await self.call('/pause?mode=wait&clear_cache=false')).get('status') != 'paused':
            raise ValueError('Service did not acknowledge pause')
        response = await self.call('/collective_rpc', dict(method='hust_m01_sync_boundary', args=['begin'], timeout=90))
        self.identity = validate_fences(response, 'begin')
        if (await self.call('/resume')).get('status') != 'resumed':
            raise ValueError('Service did not acknowledge resume')
        self.state = 'running'

    async def end(self):
        if self.state != 'running':
            raise ValueError('No active measurement')
        self.state = 'ending'
        if (await self.call('/pause?mode=wait&clear_cache=false')).get('status') != 'paused':
            raise ValueError('Service did not acknowledge drain pause')
        response = await self.call('/collective_rpc', dict(method='hust_m01_sync_boundary', args=['end'], timeout=90))
        validate_fences(response, 'end', self.identity)
        self.state = 'completed'
