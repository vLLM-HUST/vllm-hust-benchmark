"""Persist diagnostic captures without overwriting prior evidence."""
import hashlib
import json
import os
from pathlib import Path
import re
import uuid


def export_snapshot(directory, name, snapshot):
    if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9_-]+\.json', name):
        raise ValueError('Simple JSON evidence filename required')
    if not isinstance(snapshot, dict) or type(snapshot.get('complete')) is not bool:
        raise ValueError('Snapshot must explicitly declare capture completeness')
    if snapshot.get('effective_flops') is not None:
        raise ValueError('Capture export is not an effective FLOP calculation')
    directory = Path(directory)
    if not directory.is_dir():
        raise ValueError('Controller must create the evidence directory')
    raw = (json.dumps(snapshot, sort_keys=True, allow_nan=False, separators=(',', ':')) + '\n').encode()
    destination = directory / name
    temporary = directory / (name + '.partial-' + uuid.uuid4().hex)
    # Hard-link publication is atomic and refuses an existing destination.
    with temporary.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(temporary, destination)
    except BaseException:
        # Keep the uniquely named partial copy for failure diagnosis.
        raise
    temporary.unlink()
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return dict(file=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                capture_complete=snapshot['complete'],
                status='diagnostic_capture_saved', effective_flops=None,
                m01_attainment=None)
