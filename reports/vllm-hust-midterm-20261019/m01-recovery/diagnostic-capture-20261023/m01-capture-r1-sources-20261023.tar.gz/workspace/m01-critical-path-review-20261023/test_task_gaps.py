import unittest
from locate_task_gaps import largest_gaps


class GapTests(unittest.TestCase):
    def test_overlap_and_largest_selection(self):
        self.assertEqual(largest_gaps([(2,4),(3,5),(8,9)],0,12,2),[(3,9,12),(3,5,8)])

    def test_zero_duration_does_not_split_gap(self):
        self.assertEqual(largest_gaps([(3,3)],0,10),[(10,0,10)])

    def test_full_coverage_and_empty(self):
        self.assertEqual(largest_gaps([(-1,12)],0,10),[])
        self.assertEqual(largest_gaps([],0,10),[(10,0,10)])

    def test_invalid_inputs(self):
        for rows,lo,hi in [([(3,2)],0,10),([(3,4),(1,2)],0,10),([],0,0)]:
            with self.assertRaises(ValueError):
                largest_gaps(rows,lo,hi)


if __name__ == '__main__':
    unittest.main()
