import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import threading
import unittest
from boundary_transport import BoundaryTransport
from synchronized_boundary import ClientBoundary


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        self.server.seen.append(self.path)
        raw = self.rfile.read(int(self.headers.get('Content-Length', 0)))
        payload = json.loads(raw) if raw else None
        status = self.server.reply_status
        if self.path == '/collective_rpc':
            result = dict(results=[dict(rank=r, pid=100+r, host='test-host', device=f'npu:{r}',
                          phase=payload['args'][0], sync_start_ns=1, sync_end_ns=2,
                          device_sync_completed=True) for r in (0, 1)])
        else:
            result = dict(status='resumed' if self.path == '/resume' else 'paused')
        body = json.dumps(result).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        if status == 302:
            self.send_header('Location', 'http://127.0.0.1:1/do-not-follow')
        self.end_headers()
        self.wfile.write(body)


class TransportTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.seen = []
        self.server.reply_status = 200
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.transport = BoundaryTransport(self.server.server_port)

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)

    async def test_real_http_roundtrip(self):
        client = ClientBoundary(self.transport)
        await client.begin()
        await client.end()
        self.assertEqual(client.state, 'completed')
        self.assertEqual(len(self.server.seen), 5)

    async def test_no_retry_or_redirect(self):
        for status in (500, 302):
            self.server.reply_status = status
            with self.assertRaises(RuntimeError):
                await self.transport('/resume', None)
        self.assertEqual(self.server.seen, ['/resume', '/resume'])

    async def test_unapproved_rpc_never_sent(self):
        with self.assertRaises(ValueError):
            await self.transport('/collective_rpc', dict(method='other'))
        self.assertEqual(self.server.seen, [])
