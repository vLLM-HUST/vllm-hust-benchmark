import unittest
from derive_target_nonmatrix_candidate import calculate


class TargetNonmatrixTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(calculate(0, 0)['basic_subtotal'], 0)

    def test_target_only(self):
        result = calculate(3, 6)
        self.assertEqual(result['scalar']['draft_valid_rows'], 0)
        self.assertTrue(all(e['name'].startswith('target.') for e in result['norm_entries']))
        self.assertEqual(result['basic_subtotals']['attention_softmax'], (3 * 6 - 3) * 160)

    def test_additivity_for_disjoint_requests(self):
        a, b, combined = calculate(3, 6), calculate(2, 3), calculate(5, 9)
        for key in a['basic_subtotals']:
            self.assertEqual(a['basic_subtotals'][key] + b['basic_subtotals'][key], combined['basic_subtotals'][key])

    def test_invalid_pairs(self):
        with self.assertRaises(ValueError):
            calculate(3, 2)
