import unittest
from continue_after_fs import dependency_state, process_live
import os
from pathlib import Path


class QueueTests(unittest.TestCase):
    def test_live_even_completed_receipt_waits(self):
        self.assertEqual(dependency_state({}, dict(status='completed', sessions_drained=True,
            all_devices_released=True), True), 'waiting_for_owned_controller')

    def test_dead_failed_or_unreleased_stops(self):
        for receipt in ({'status': 'judge'}, dict(status='completed', sessions_drained=False,
                                                all_devices_released=True)):
            with self.assertRaises(RuntimeError):
                dependency_state({}, receipt, False)

    def test_completed_released_allows_further_admission(self):
        self.assertEqual(dependency_state({}, dict(status='completed', sessions_drained=True,
            all_devices_released=True), False), 'ready_for_seal_and_device_admission')

    def test_pid_reuse_does_not_count_as_live(self):
        pid = os.getpid()
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        self.assertTrue(process_live(pid, fields[19]))
        self.assertFalse(process_live(pid, '-1'))


if __name__ == '__main__':
    unittest.main()
