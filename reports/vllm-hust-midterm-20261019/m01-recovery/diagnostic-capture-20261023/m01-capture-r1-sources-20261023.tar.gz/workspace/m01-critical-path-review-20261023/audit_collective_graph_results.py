"""Require complete paired samples; retain all batches, never select a winner."""
import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import mean


def shape_key(shape):
    return tuple(shape[k] for k in ('kind', 'dtype', 'elements', 'rank_size'))


def audit_rows(plan, rank_rows):
    shapes = {shape_key(row): row for row in plan['shapes']}
    expected = {(key, batch, rep, sample) for key in shapes for batch in plan['batch_sizes']
                for rep in range(plan['repetitions']) for sample in range(plan['samples'])}
    if set(rank_rows) != {0, 1}:
        raise ValueError('Both ranks required')
    indexed = {}
    for rank, rows in rank_rows.items():
        found = {}
        for row in rows:
            key = (shape_key(row['shape']), row['batch'], row['repetition'], row['sample'])
            if key not in expected or key in found:
                raise ValueError('Unknown or duplicate sample')
            if row['shape'] != shapes[key[0]] or row['rank'] != rank or row['calls'] != row['batch']:
                raise ValueError('Sample identity mismatch')
            if row['numerics_passed'] is not True:
                raise ValueError('Numerical validation missing or failed')
            wall, device = row['synchronized_wall_seconds'], row['device_ms']
            if any(type(v) not in (int, float) or not math.isfinite(v) or v <= 0 for v in (wall, device)):
                raise ValueError('Invalid timing')
            found[key] = row
        if set(found) != expected:
            raise ValueError('Incomplete sample population')
        indexed[rank] = found
    summaries = []
    for key, shape in shapes.items():
        for batch in plan['batch_sizes']:
            repetitions = []
            for rep in range(plan['repetitions']):
                walls, devices = [], []
                for sample in range(plan['samples']):
                    identity = (key, batch, rep, sample)
                    pair = [indexed[rank][identity] for rank in (0, 1)]
                    walls.append(max(r['synchronized_wall_seconds'] for r in pair) / batch)
                    devices.append(max(r['device_ms'] for r in pair) / (1000 * batch))
                repetitions.append(dict(repetition=rep, mean_max_rank_wall_seconds_per_call=mean(walls),
                                        mean_max_rank_device_seconds_per_call=mean(devices)))
            summaries.append(dict(shape=shape, batch=batch, repetitions=repetitions))
    return dict(status='complete_numerically_valid_paired_collective_samples',
                samples_per_rank=len(expected), summaries=summaries,
                reference_selection=None, model_reference_seconds=None, m01_efficiency_percent=None,
                limitation='Graph-batch reference only. Model dependency mapping and useful-work multiplicities remain separate; no fastest-batch selection.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.run.resolve()
    if args.output.resolve().is_relative_to(root):
        raise ValueError('Derived audit must not modify sealed run')
    manifest = root / 'SHA256SUMS'
    sealed = {}
    for line in manifest.read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = (root / name).resolve()
        if not path.is_relative_to(root) or name in sealed:
            raise ValueError('Invalid seal path')
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Seal mismatch: {name}')
        sealed[name] = digest
    required = {'receipt.json', 'execution-plan.json', 'admission.json', 'rank-0.json', 'rank-1.json',
                'samples-0.jsonl', 'samples-1.jsonl'}
    if not required <= sealed.keys():
        raise ValueError('Seal omits required evidence')
    receipt = json.loads((root / 'receipt.json').read_text())
    if not (receipt['status'] == 'collected_pending_joint_audit' and receipt['worker_exit_code'] == 0
            and receipt['sessions_drained'] and receipt['all_devices_released'] and receipt['fallback'] is False):
        raise ValueError('Lifecycle not qualified')
    plan = json.loads((root / 'execution-plan.json').read_text())
    if (plan['status'] != 'frozen_for_qualification' or len(plan['shapes']) != 75
            or plan['batch_sizes'] != [1, 8, 32] or plan['samples'] != 16 or plan['repetitions'] != 3):
        raise ValueError('Unexpected frozen protocol')
    admission = json.loads((root / 'admission.json').read_text())
    if admission['plan_sha256'] != sealed['execution-plan.json']:
        raise ValueError('Admission and actual plan disagree')
    rows = {}
    for rank in (0, 1):
        result = json.loads((root / f'rank-{rank}.json').read_text())
        if (result['status'] != 'collected_pending_joint_audit' or result['rank'] != rank
                or result['completed_shapes'] != len(plan['shapes']) or result['fallback'] is not False
                or result['runtime_versions'] != plan['runtime_versions']):
            raise ValueError('Rank result not qualified')
        rows[rank] = [json.loads(line) for line in (root / f'samples-{rank}.jsonl').read_text().splitlines()]
    result = audit_rows(plan, rows)
    result['source_sha256'] = {str(root / name): sealed[name] for name in sorted(required)}
    result['source_sha256'][str(manifest)] = hashlib.sha256(manifest.read_bytes()).hexdigest()
    result['source_sha256'][str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'samples_per_rank', 'm01_efficiency_percent')}))


if __name__ == '__main__':
    main()
