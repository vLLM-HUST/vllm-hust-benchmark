"""One-shot queue after the owned FS controller; no retries or fallback runs."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from run_collective_graph import completed_dependencies, LIFECYCLE

HERE = Path(__file__).resolve().parent
FS_START = LIFECYCLE / 'fs018-judge-r5-start.json'
FS_RECEIPT = LIFECYCLE.parent / 'frontierscience-native018-judge-r1/receipt.json'


def process_live(pid, start_ticks):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        return False
    return fields[19] == str(start_ticks) and fields[0] not in ('Z', 'X')


def dependency_state(start, receipt, live):
    if live:
        return 'waiting_for_owned_controller'
    if (receipt.get('status') == 'completed' and receipt.get('sessions_drained')
            and receipt.get('all_devices_released')):
        return 'ready_for_seal_and_device_admission'
    raise RuntimeError('Owned FS controller ended without a completed released receipt')


def commands(output):
    python = sys.executable
    graph = Path('/workspace/m01-collective-graph-r1')
    return [
        ('fs_quality_audit', [python, str(LIFECYCLE / 'audit_fs018_quality.py'),
            '--output', str(output / 'fs018-quality-audit.json')]),
        ('collective_graph', [python, str(HERE / 'run_collective_graph.py'),
            '--plan', str(HERE / 'collective-graph-execution-plan-r1.json'), '--output', str(graph)]),
        ('collective_audit', [python, str(HERE / 'audit_collective_graph_results.py'),
            '--run', str(graph), '--output', str(output / 'collective-graph-audit.json')]),
        ('b1_boundary', [python, str(HERE / 'run_boundary_b1.py'),
            '--plan', str(HERE / 'boundary-execution-plan-r6.json')]),
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir()
    record = dict(status='waiting', pid=os.getpid(), started=time.time(), stages=[],
                  measurement_complete=False, m01_attainment=None)
    start = json.loads(FS_START.read_text())
    record['wait_for'] = start

    def save():
        temporary = output / 'receipt.tmp'
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(output / 'receipt.json')

    with open('/tmp/m01-post-fs-continuation.lock', 'a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        save()
        try:
            deadline = time.monotonic() + 6 * 3600
            transient_reads = 0
            while True:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Owned FS completion wait exceeded six hours')
                live = process_live(start['pid'], start['start_ticks'])
                try:
                    receipt = json.loads(FS_RECEIPT.read_text())
                    transient_reads = 0
                except json.JSONDecodeError:
                    transient_reads += 1
                    if transient_reads >= 6:
                        raise
                    time.sleep(5)
                    continue
                state = dependency_state(start, receipt, live)
                record.update(status=state, last_verified=time.time(), dependency_live=live)
                save()
                if not live:
                    completed_dependencies()
                    break
                time.sleep(30)
            environment = dict(HOME='/root', LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1',
                PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                LD_LIBRARY_PATH='/usr/local/Ascend/driver/lib64/driver:/usr/local/Ascend/driver/lib64/common')
            for name, command in commands(output):
                record['status'] = name
                stage = dict(name=name, command=command, started=time.time())
                record['stages'].append(stage)
                with (output / (name + '.log')).open('x') as log:
                    child = subprocess.Popen(command, env=environment, stdin=subprocess.DEVNULL,
                        stdout=log, stderr=subprocess.STDOUT)
                    stage['pid'] = child.pid
                    save()
                    stage['exit_code'] = child.wait()
                stage['ended'] = time.time()
                save()
                if stage['exit_code'] != 0:
                    raise RuntimeError(f'{name} failed; no retry or fallback')
            record['status'] = 'supplements_collected_pending_joint_M01_audit'
        except BaseException as error:
            record.update(status='stopped', error=f'{type(error).__name__}: {error}')
        record['ended'] = time.time()
        save()
    print(json.dumps(record))
    return 0 if record['status'] == 'supplements_collected_pending_joint_M01_audit' else 1


if __name__ == '__main__':
    raise SystemExit(main())
