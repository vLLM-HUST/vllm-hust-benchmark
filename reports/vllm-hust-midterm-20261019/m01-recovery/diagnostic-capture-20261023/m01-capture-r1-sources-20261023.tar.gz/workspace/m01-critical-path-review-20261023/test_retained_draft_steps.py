import unittest
from itertools import product
from recover_retained_draft_steps import bounds


def epochs(finals):
    return [{'verification_steps':[{'committed_outputs':v}]} for v in finals]


class RetainedDraftStepTests(unittest.TestCase):
    def test_uncut(self):
        result = bounds(epochs([1, 2, 3]), 0)
        self.assertEqual((result['first_retained_lower'], result['second_retained_lower']), (2, 1))

    def test_exhaustive_small_final_allocations(self):
        for final in product((1, 2, 3), repeat=3):
            expected = {}
            for raw in product(*(range(n, 4) for n in final)):
                excess = sum(a-b for a,b in zip(raw, final))
                retained = [min(a-1, b) for a,b in zip(raw, final)]
                expected.setdefault(excess, []).append((sum(n>=1 for n in retained), sum(n>=2 for n in retained)))
            for excess, pairs in expected.items():
                result = bounds(epochs(final), excess)
                for name, column in [('first', 0), ('second', 1)]:
                    self.assertEqual(result[f'{name}_retained_lower'], min(p[column] for p in pairs))
                    self.assertEqual(result[f'{name}_retained_upper'], max(p[column] for p in pairs))
                self.assertEqual(result['joint_total_lower'], min(sum(p) for p in pairs))
                self.assertEqual(result['joint_total_upper'], max(sum(p) for p in pairs))

    def test_nonterminal_steps_counted(self):
        result = bounds([{'verification_steps':[{'committed_outputs':3}, {'committed_outputs':1}]}], 0)
        self.assertEqual(result['joint_total_lower'], 2)
