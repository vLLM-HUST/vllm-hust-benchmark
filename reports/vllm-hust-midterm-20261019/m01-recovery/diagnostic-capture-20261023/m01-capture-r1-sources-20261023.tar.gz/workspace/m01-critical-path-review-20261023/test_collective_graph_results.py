import copy
import unittest
from audit_collective_graph_results import audit_rows


class ResultsTests(unittest.TestCase):
    def setUp(self):
        shape = dict(kind='all_reduce', dtype='BFP16', elements=24, rank_size=2, calls=10, input_bytes_per_call=48)
        self.plan = dict(shapes=[shape], batch_sizes=[1, 8], repetitions=3, samples=2)
        self.rows = {rank: [dict(shape=shape, rank=rank, batch=batch, calls=batch, repetition=rep,
            sample=sample, numerics_passed=True, synchronized_wall_seconds=(rank + 1) * .001 * batch,
            device_ms=.5 * batch) for batch in [1, 8] for rep in range(3) for sample in range(2)] for rank in (0, 1)}

    def test_complete(self):
        result = audit_rows(self.plan, self.rows)
        self.assertEqual(result['samples_per_rank'], 12)
        self.assertEqual(len(result['summaries']), 2)
        self.assertEqual(result['summaries'][0]['repetitions'][0]['mean_max_rank_wall_seconds_per_call'], .002)
        self.assertIsNone(result['m01_efficiency_percent'])

    def test_missing(self):
        self.rows[1].pop()
        with self.assertRaises(ValueError): audit_rows(self.plan, self.rows)

    def test_duplicate(self):
        self.rows[0].append(self.rows[0][0])
        with self.assertRaises(ValueError): audit_rows(self.plan, self.rows)

    def test_invalid(self):
        for key, value in [('rank', 1), ('numerics_passed', False), ('synchronized_wall_seconds', float('nan')), ('calls', 9)]:
            rows = copy.deepcopy(self.rows)
            rows[0][0][key] = value
            with self.assertRaises(ValueError): audit_rows(self.plan, rows)


if __name__ == '__main__':
    unittest.main()
