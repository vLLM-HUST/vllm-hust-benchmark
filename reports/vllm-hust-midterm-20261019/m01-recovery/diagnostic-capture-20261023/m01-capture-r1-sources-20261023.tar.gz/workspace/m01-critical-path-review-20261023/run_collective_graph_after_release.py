"""Versioned admission for an independent reference after a sealed FS failure."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import run_collective_graph as controller

HERE = Path(__file__).resolve().parent
POLICY = 'sealed-fs-disk-failure-released-independent-m01-v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def released_dependencies(plan):
    if set(plan['dependency_receipt_sha256']) != {
            'frontierscience-native018-solver-r1', 'frontierscience-native018-judge-r1'}:
        raise RuntimeError('Both dependency identities required')
    for name, expected in plan['dependency_receipt_sha256'].items():
        directory = controller.ROOT / name
        receipt = directory / 'receipt.json'
        if digest(receipt) != expected:
            raise RuntimeError('Dependency receipt changed')
        data = json.loads(receipt.read_text())
        if not data.get('sessions_drained') or not data.get('all_devices_released'):
            raise RuntimeError('Dependency not released')
        if name.endswith('solver-r1'):
            if data.get('status') != 'completed':
                raise RuntimeError('Solver incomplete')
        elif data.get('status') != 'failed' or data.get('error') != 'AssertionError: Disk reserve exhausted':
            raise RuntimeError('Not the documented disk failure')
        subprocess.run(['sha256sum', '-c', 'SHA256SUMS', '--quiet'], cwd=directory, check=True)


def freeze():
    source = HERE / 'collective-graph-execution-plan-r1.json'
    plan = json.loads(source.read_text())
    controller.validate_plan(plan)
    plan['parent_plan_sha256'] = digest(source)
    plan['admission_policy'] = POLICY
    plan['dependency_receipt_sha256'] = {
        name: digest(controller.ROOT / name / 'receipt.json')
        for name in ('frontierscience-native018-solver-r1', 'frontierscience-native018-judge-r1')}
    plan['source_sha256'][str(Path(__file__).resolve())] = digest(Path(__file__))
    released_dependencies(plan)
    output = HERE / 'collective-graph-execution-plan-r3.json'
    with output.open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    print(output, digest(output))


def main():
    if sys.argv[1:] == ['--freeze']:
        freeze()
        return 0
    path = Path(sys.argv[sys.argv.index('--plan') + 1])
    plan = json.loads(path.read_text())
    if plan.get('admission_policy') != POLICY:
        raise RuntimeError('Explicit release policy required')
    if plan['source_sha256'].get(str(Path(__file__).resolve())) != digest(Path(__file__)):
        raise RuntimeError('Admission source is not bound')
    controller.completed_dependencies = lambda: released_dependencies(plan)
    return controller.main()


if __name__ == '__main__':
    raise SystemExit(main())
