"""Locate observed gaps and overlapping APIs without claiming causality."""
import heapq
import json
import sqlite3
from pathlib import Path

from audit_task_intervals import BOUNDARIES, ROOT, interval_union


def largest_gaps(rows, lo, hi, limit=3):
    if hi <= lo or limit < 1:
        raise ValueError('Invalid window or limit')
    cursor, prior = lo, None
    gaps = []
    def add(left, right):
        if right > left:
            heapq.heappush(gaps, (right - left, left, right))
            if len(gaps) > limit:
                heapq.heappop(gaps)
    for start, end in rows:
        if end < start or (prior is not None and start < prior):
            raise ValueError('Invalid interval sequence')
        prior = start
        if end == start or end <= lo or start >= hi:
            continue
        start, end = max(start, lo), min(end, hi)
        if end <= cursor:
            continue
        add(cursor, start)
        cursor = end
    add(cursor, hi)
    return sorted(gaps, reverse=True)


def main():
    boundary = json.loads(BOUNDARIES.read_text())
    lo, hi = boundary['request_start_ns'], boundary['request_end_ns']
    kinds = ('KERNEL_AIVEC', 'KERNEL_AICORE', 'AI_CORE', 'KERNEL_MIX_AIV', 'KERNEL_MIX_AIC', 'MEMCPY_ASYNC')
    result = {'scope': 'Longest compute/copy interval gaps and temporal overlap only', 'ranks': [],
              'limitations': ['Overlapping API durations can be nested; their sum is not a time decomposition.',
                              'Temporal coincidence does not establish observer overhead or removable time.',
                              'Communication OP duration may include waits, not only active transfer.'],
              'new_efficiency_percent': None}
    for rank in (0, 1):
        path = next((ROOT / 'offline-export-r1' / f'rank-{rank}').rglob('msprof_*.db'))
        gaps = []
        with sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True) as db:
            sql = ('select t.startNs,t.endNs from TASK t join STRING_IDS s on s.id=t.taskType '
                   'where s.value in (' + ','.join('?' for _ in kinds) + ') order by t.startNs,t.endNs')
            for length, left, right in largest_gaps(db.execute(sql, kinds), lo, hi):
                api = db.execute('''select s.value,count(*),sum(min(a.endNs,?)-max(a.startNs,?))
                    from CANN_API a join STRING_IDS s on s.id=a.name
                    where a.endNs>? and a.startNs<?
                    group by s.value order by 3 desc limit 8''', (right, left, left, right)).fetchall()
                comm = interval_union(db.execute('select startNs,endNs from COMMUNICATION_OP where endNs>? and startNs<? order by startNs,endNs', (left, right)), left, right)
                gaps.append({'start_ns': left, 'end_ns': right, 'seconds': length / 1e9,
                             'start_offset_seconds': (left-lo)/1e9,
                             'end_offset_seconds': (right-lo)/1e9,
                             'communication_overlap': comm,
                             'top_api_overlap': [{'name': n, 'count': c, 'clipped_sum_ns_not_union': d} for n,c,d in api]})
        result['ranks'].append({'rank': rank, 'gaps': gaps})
    with (ROOT / 'task-gap-locations-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
