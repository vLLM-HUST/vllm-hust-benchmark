import pickle
from types import SimpleNamespace as NS

import pytest

from test_scheduler_output_ledger import Native, request, schedule
from wave_capture_bridge import ACTIVE_WAVE, SchedulerWaveCapture, WorkerWaveCapture, record_host_prefill
from worker_wave_identity import request_key


class SchedulerNative(Native):
    def schedule(self):
        result = schedule('a')
        result.total_num_scheduled_tokens = 3
        return result


class Scheduler(SchedulerWaveCapture, SchedulerNative):
    pass


class WorkerNative:
    def __init__(self):
        self.model_runner = NS(execute_model_state=None)

    def execute_model(self, output):
        record_host_prefill([{'length': 3, 'initial': False}])
        self.model_runner.execute_model_state = output
        return None

    def sample_tokens(self, grammar):
        assert ACTIVE_WAVE.get()['phase'] == 'sample'
        self.model_runner.execute_model_state = None
        return [1, 2, 3]


class Worker(WorkerWaveCapture, WorkerNative):
    pass


def setup():
    s, w = Scheduler(), Worker()
    s.enable_wave_capture(run_id='r1', max_events=100, max_requests=10)
    w.enable_wave_capture(run_id='r1', max_events=100)
    return s, w


def test_schedule_pickle_worker_sample_and_delivery_join():
    s, w = setup()
    output = s.schedule()
    remote = pickle.loads(pickle.dumps(output))
    assert w.execute_model(remote) is None
    assert w.wave_capture_snapshot()['pending']
    assert ACTIVE_WAVE.get() is None
    tokens = w.sample_tokens(None)
    s.update_from_output(output, {'a': (request('a'), tokens)})
    assert ACTIVE_WAVE.get() is None
    ws, ss = w.wave_capture_snapshot(), s.output_ledger_snapshot()
    assert ws['complete'] and ss['retained_count_complete']
    identities = [e['identity'] for e in ws['events']]
    identities += [e['identity'] for e in ss['events'] if 'identity' in e]
    assert all(tag == identities[0] for tag in identities)
    assert identities[0]['wave'] == 0
    update = next(e for e in ss['events'] if e['event'] == 'output_update')
    assert update['request_key'] == request_key('r1', 'a')


def test_out_of_order_execute_and_orphan_sample_rejected():
    s, w = setup()
    with pytest.raises(ValueError, match='Sampling without'):
        w.sample_tokens(None)
    w.execute_model(s.schedule())
    with pytest.raises(ValueError, match='Previous sampling'):
        w.execute_model(s.schedule())
    assert not w.wave_capture_snapshot()['complete']


def test_no_wave_no_prefill_record():
    with pytest.raises(ValueError, match='no active'):
        record_host_prefill([])


def test_native_failure_clears_context():
    s, w = setup()
    with pytest.MonkeyPatch.context() as patch:
        def fail(self, output):
            raise RuntimeError('native execution failure')
        patch.setattr(WorkerNative, 'execute_model', fail)
        with pytest.raises(RuntimeError):
            w.execute_model(s.schedule())
    assert ACTIVE_WAVE.get() is None
    assert not w.wave_capture_snapshot()['complete']
