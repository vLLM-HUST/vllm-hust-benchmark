from pathlib import Path
import tempfile
import unittest
from launch_boundary_b1 import reserve_cache


class CacheTests(unittest.TestCase):
    def test_fresh_then_refuse_reuse(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'cache'
            reserve_cache(path)
            self.assertEqual(list(path.iterdir()), [])
            with self.assertRaises(FileExistsError):
                reserve_cache(path)

    def test_dangling_link_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'cache'
            path.symlink_to(Path(directory) / 'missing')
            with self.assertRaises(FileExistsError):
                reserve_cache(path)


if __name__ == '__main__':
    unittest.main()
