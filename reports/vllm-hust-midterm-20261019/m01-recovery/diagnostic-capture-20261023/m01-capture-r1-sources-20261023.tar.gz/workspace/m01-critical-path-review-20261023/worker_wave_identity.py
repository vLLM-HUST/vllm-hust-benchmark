"""Opt-in identities on final scheduler outputs before executor serialization."""
import hashlib
import json
import re

ATTRIBUTE = '_hust_m01_wave_identity'


def request_key(run_id, request_id):
    if not isinstance(run_id, str) or not isinstance(request_id, str):
        raise ValueError('Expected host run and request identities')
    return hashlib.sha256((run_id + '\0' + request_id).encode()).hexdigest()


def layout_digest(output):
    scheduled = output.num_scheduled_tokens
    drafts = output.scheduled_spec_decode_tokens
    if not isinstance(scheduled, dict) or not isinstance(drafts, dict):
        raise ValueError('Expected native host schedule dictionaries')
    if any(not isinstance(k, str) or type(v) is not int or v <= 0
           for k, v in scheduled.items()):
        raise ValueError('Invalid request extent')
    if set(drafts) - set(scheduled):
        raise ValueError('Drafts outside scheduled population')
    if type(output.total_num_scheduled_tokens) is not int or output.total_num_scheduled_tokens != sum(scheduled.values()):
        raise ValueError('Batch token total mismatch')
    if any(not isinstance(v, list) for v in drafts.values()):
        raise ValueError('Draft vectors must already be host lists')
    rows = [(rid, count, len(drafts.get(rid, []))) for rid, count in sorted(scheduled.items())]
    # Only a digest is exported; no request IDs, prompts or token values in the tag.
    return hashlib.sha256(json.dumps(rows, separators=(',', ':')).encode()).hexdigest()


def attach(output, *, run_id, wave):
    if not isinstance(run_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', run_id):
        raise ValueError('Explicit nonsecret run label required')
    if type(wave) is not int or wave < 0:
        raise ValueError('Nonnegative wave ordinal required')
    if hasattr(output, ATTRIBUTE):
        raise ValueError('Schedule object already tagged; do not reuse it')
    value = dict(protocol='m01-worker-wave/v1', run_id=run_id, wave=wave,
                 layout_sha256=layout_digest(output))
    setattr(output, ATTRIBUTE, value)
    return dict(value)


def validate(output, *, run_id):
    value = getattr(output, ATTRIBUTE, None)
    if not isinstance(value, dict) or set(value) != {'protocol', 'run_id', 'wave', 'layout_sha256'}:
        raise ValueError('Missing or invalid wave identity')
    if value['protocol'] != 'm01-worker-wave/v1' or value['run_id'] != run_id:
        raise ValueError('Wrong run or protocol')
    if type(value['wave']) is not int or value['wave'] < 0:
        raise ValueError('Invalid wave ordinal')
    if value['layout_sha256'] != layout_digest(output):
        raise ValueError('Schedule layout changed after identity creation')
    return dict(value)
