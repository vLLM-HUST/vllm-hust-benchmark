"""Keep the B1 measurement unchanged while admitting a released FS failure."""
import json
from pathlib import Path
import sys

import run_boundary_b1 as controller
import run_collective_graph_after_release as gate

HERE = Path(__file__).resolve().parent


def main():
    if sys.argv[1:] == ['--freeze']:
        source = HERE / 'boundary-execution-plan-r6.json'
        plan = controller.validate_plan(json.loads(source.read_text()))
        admission = json.loads((HERE / 'collective-graph-execution-plan-r3.json').read_text())
        gate.released_dependencies(admission)
        plan['parent_plan_sha256'] = gate.digest(source)
        for field in ('admission_policy', 'dependency_receipt_sha256'):
            plan[field] = admission[field]
        for path in (Path(__file__).resolve(), Path(gate.__file__).resolve()):
            plan['source_sha256'][str(path)] = gate.digest(path)
        output = HERE / 'boundary-execution-plan-r7.json'
        with output.open('x') as stream:
            json.dump(plan, stream, indent=2)
            stream.write('\n')
        print(output, gate.digest(output))
        return 0
    plan = json.loads(Path(sys.argv[sys.argv.index('--plan') + 1]).read_text())
    if plan.get('admission_policy') != gate.POLICY:
        raise RuntimeError('Explicit release policy required')
    for path in (Path(__file__).resolve(), Path(gate.__file__).resolve()):
        if plan['source_sha256'].get(str(path)) != gate.digest(path):
            raise RuntimeError('Admission source is not bound')
    controller.completed_dependencies = lambda: gate.released_dependencies(plan)
    return controller.main()


if __name__ == '__main__':
    raise SystemExit(main())
