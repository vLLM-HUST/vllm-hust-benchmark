"""Recompute length-dependent families without importing old prefill work."""
import hashlib
import json
from pathlib import Path

from derive_target_nonmatrix_candidate import calculate
from derive_target_vocab_conv_candidate import convolution_counts
from derive_target_gdn_candidate import decode_counts

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def demand(inputs, outputs):
    if len(inputs) != len(outputs) or not inputs:
        raise ValueError('Paired nonempty requests required')
    if any(type(x) is not int or x <= 0 for x in inputs + outputs):
        raise ValueError('Positive integer token extents required')
    lengths = [i + o - 1 for i, o in zip(inputs, outputs, strict=True)]
    rows = sum(lengths)
    pairs = sum(n*(n+1)//2 for n in lengths)
    scalar = calculate(rows, pairs)
    conv = convolution_counts(lengths)
    gdn = decode_counts(sum(inputs), sum(outputs), len(inputs))
    pieces = dict(scalar['basic_subtotals'])
    pieces['causal_convolution'] = conv['convolution_multiply'] + conv['convolution_add']
    pieces['gdn_decode_recurrence'] = gdn['recurrent_basic_flops']
    pieces['gdn_preprocessing'] = gdn['preprocess_basic_flops']
    return dict(positions=rows, causal_pairs=pairs, basic_parts=pieces,
                basic_subtotal=sum(pieces.values()), nonmatrix_detail=scalar,
                convolution_detail=conv, gdn_decode_and_preprocessing_detail=gdn)


def main():
    paths = [Path('/workspace/m01-boundary-b1-r1/mmlu-pro.json'),
             HERE / 'boundary-matrix-demand-r1.json', Path('/models/Qwen3.5-35B-A3B/config.json')]
    bench, matrix, config = [json.loads(p.read_text()) for p in paths]
    c = config['text_config']
    expected = dict(hidden_size=2048, num_attention_heads=16, head_dim=256,
        num_hidden_layers=40, linear_key_head_dim=128, linear_value_head_dim=128,
        linear_num_key_heads=16, linear_num_value_heads=32, linear_conv_kernel_dim=4,
        num_experts=256, num_experts_per_tok=8)
    if any(c[k] != v for k,v in expected.items()) or c['layer_types'].count('linear_attention') != 30:
        raise ValueError('Helper accounting does not apply to model dimensions')
    counts = demand(bench['input_lens'], bench['output_lens'])
    paths += [HERE / name for name in ('derive_target_nonmatrix_candidate.py',
        'derive_target_vocab_conv_candidate.py', 'derive_target_gdn_candidate.py')]
    paths += [ROOT / name for name in ('audit_norm_accounting.py',
        'derive_recovery_model_worker_r1_scalar.py', 'derive_r12_softmax_semantics.py',
        'audit_conv_accounting.py', 'audit_gdn_preprocess_semantics.py', 'audit_gdn_recurrence_r9.py')]
    paths.append(Path(__file__))
    result = dict(status='recomputed_target_arithmetic_excluding_prefill_gdn_and_draft', **counts,
        matrix_subtotal=matrix['partial_target_matrix_flops'],
        listed_target_subtotal=matrix['partial_target_matrix_flops']+counts['basic_subtotal'],
        inherited_prefill_gdn_flops=False, effective_flops=None, efficiency_percent=None,
        assumptions=['Length-derived semantic target work under the validated fixed model dimensions.',
                     'No reused request prefix; each request begins with structural zero convolution history.',
                     'Global TP2 arithmetic counted once; special functions stay separately enumerated.'],
        remaining=['Actual prefill GDN chunk algorithm and initial-state work for this run.',
                   'Useful retained draft context arithmetic and source/runtime applicability.',
                   'Independent stage dependency reference, not global resource maximum.'],
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (HERE / 'boundary-scalar-demand-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','basic_parts','listed_target_subtotal','effective_flops')}))


if __name__ == '__main__':
    main()
