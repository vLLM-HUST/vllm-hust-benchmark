import copy
import hashlib
import json
from pathlib import Path
import unittest
from collective_graph_worker import validate_plan


class WorkerTests(unittest.TestCase):
    def setUp(self):
        here = Path(__file__).resolve().parent
        prepared = json.loads((here / 'collective-graph-grid-preparation-r1.json').read_text())
        sources = [here / name for name in ('collective_graph_worker.py', 'collective_graph_probe.py',
                                            'prepare_collective_graph_grid.py')]
        self.plan = dict(status='frozen_for_qualification',
                         runtime_versions={'torch': '2.13.0+cpu', 'torch_npu': '2.13.0.rc1'},
                         batch_sizes=[1, 8, 32], samples=16, repetitions=3, port=18517,
                         shapes=prepared['shapes'],
                         source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})

    def test_valid_cpu_only(self):
        validate_plan(self.plan)

    def test_changed_protocol(self):
        for key, value in [('samples', 1), ('batch_sizes', [32]), ('port', 0), ('status', 'draft')]:
            plan = copy.deepcopy(self.plan)
            plan[key] = value
            with self.assertRaises(ValueError):
                validate_plan(plan)

    def test_no_source_identity(self):
        self.plan['source_sha256'] = {}
        with self.assertRaises(ValueError):
            validate_plan(self.plan)

    def test_modified_source(self):
        key = next(iter(self.plan['source_sha256']))
        self.plan['source_sha256'][key] = '0' * 64
        with self.assertRaises(ValueError):
            validate_plan(self.plan)


if __name__ == '__main__':
    unittest.main()
