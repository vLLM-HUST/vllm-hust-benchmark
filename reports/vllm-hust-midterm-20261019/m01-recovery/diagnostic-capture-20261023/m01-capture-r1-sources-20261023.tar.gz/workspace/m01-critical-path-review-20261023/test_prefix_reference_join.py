import unittest
from join_prefix_reference import select_case


def case():
    return dict(shape=dict(rows=512, width=2048), check=dict(finite=True, close=True),
                timings=[dict(repetition=0, replays=100, device_ms=2),
                         dict(repetition=1, replays=100, device_ms=4)])


class PrefixJoinTests(unittest.TestCase):
    def test_all_samples_mean_not_fastest(self):
        result = select_case([case()], dict(rows=512, width=2048))
        self.assertAlmostEqual(result['mean_seconds'], 0.00003)
        self.assertEqual(len(result['samples_seconds']), 2)

    def test_missing_shape_not_interpolated(self):
        with self.assertRaises(ValueError):
            select_case([case()], dict(rows=1024, width=2048))

    def test_duplicate_shape_not_arbitrarily_selected(self):
        with self.assertRaises(ValueError):
            select_case([case(), case()], dict(rows=512))

    def test_failed_numerics_rejected(self):
        row = case()
        row['check']['close'] = False
        with self.assertRaises(ValueError):
            select_case([row], dict(rows=512))

    def test_duplicate_repetition_rejected(self):
        row = case()
        row['timings'][1]['repetition'] = 0
        with self.assertRaises(ValueError):
            select_case([row], dict(rows=512))
