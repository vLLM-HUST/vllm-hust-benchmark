"""Union task intervals in the original request window; not utilization."""
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parent
BOUNDARIES = Path('/root/vllm-hust-benchmark/reports/vllm-hust-midterm-20261019/m01-recovery/request-assessment-20261022/m01-request-task-boundaries.json')


def interval_union(rows, lo, hi):
    if hi <= lo:
        raise ValueError('Invalid observation interval')
    end = lo
    total = 0
    prior = None
    count = 0
    largest_gap = 0
    for start, stop in rows:
        if stop < start or (prior is not None and start < prior):
            raise ValueError('Invalid or unsorted task intervals')
        prior = start
        if stop == start or stop <= lo or start >= hi:
            continue
        left, right = max(start, lo), min(stop, hi)
        count += 1
        if right <= end:
            continue
        largest_gap = max(largest_gap, left - end)
        total += right - max(left, end)
        end = right
    largest_gap = max(largest_gap, hi - end)
    return {'intersecting_intervals': count, 'covered_ns': total,
            'uncovered_ns': hi - lo - total, 'largest_uncovered_gap_ns': largest_gap}


def main():
    source = json.loads(BOUNDARIES.read_text())
    lo, hi = source['request_start_ns'], source['request_end_ns']
    groups = {
        'compute_task_intervals': ('KERNEL_AIVEC', 'KERNEL_AICORE', 'AI_CORE', 'KERNEL_MIX_AIV', 'KERNEL_MIX_AIC'),
        'copy_task_intervals': ('MEMCPY_ASYNC',),
        'compute_or_copy_task_intervals': ('KERNEL_AIVEC', 'KERNEL_AICORE', 'AI_CORE', 'KERNEL_MIX_AIV', 'KERNEL_MIX_AIC', 'MEMCPY_ASYNC'),
    }
    result = {'request_start_ns': lo, 'request_end_ns': hi, 'ranks': [],
              'scope': 'Task interval coverage, not productive FLOPs, hardware utilization or a critical path',
              'limitations': ['Kernel intervals may include stalls and observer work.',
                              'Uncovered time is not proven removable or caused by instrumentation.',
                              'Wait, notification, graph wrapper and profiler marker tasks are excluded.',
                              'No cross-run time correction or new efficiency score is derived.']}
    for rank in (0, 1):
        path = next((ROOT / 'offline-export-r1' / f'rank-{rank}').rglob('msprof_*.db'))
        row = {'rank': rank, 'database': str(path), 'groups': {}}
        with sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True) as db:
            for label, types in groups.items():
                sql = ('select t.startNs,t.endNs from TASK t join STRING_IDS s on s.id=t.taskType '
                       'where s.value in (' + ','.join('?' for _ in types) + ') order by t.startNs,t.endNs')
                values = interval_union(db.execute(sql, types), lo, hi)
                values['covered_seconds'] = values['covered_ns'] / 1e9
                values['coverage_percent'] = 100 * values['covered_ns'] / (hi - lo)
                row['groups'][label] = values
        result['ranks'].append(row)
    with (ROOT / 'task-interval-coverage-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
