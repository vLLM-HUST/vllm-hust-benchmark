import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from audit_boundary_mods import audit


def write_rows(path, rows):
    path.write_text('\n'.join(json.dumps(row) for row in rows))


class ModTests(unittest.TestCase):
    def fixture(self, root, active=True):
        for rank in (0, 1):
            write_rows(root / f'microflow-{rank}.jsonl', [
                dict(event='model_loaded', active=active, rank=rank),
                *[dict(event='partition_equivalence', tokens=n, exact=[True]*5, rank=rank) for n in (1024, 2048, 4096)],
                dict(event='prefix', split=True),
                dict(event='graph_replay', active=True, target=True, speculative_enabled=True)])
        write_rows(root / 'kvmat-policy.jsonl', [dict(runtime_control_path='request_scoped_prefix_cache_bypass',
            runtime_effective_decision='recompute', runtime_decision_supported=True, reused_tokens=0,
            runtime_cache_salt=str(i), prompt_tokens=100) for i in range(200)])
        write_rows(root / 'kvmat-engine.jsonl', [dict(event='school028_request_salt_admitted',
            cache_salt_sha256=hashlib.sha256(str(i).encode()).hexdigest(), prompt_tokens=100) for i in range(200)])

    def test_exercised_not_efficiency(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.fixture(root)
            result = audit(root)
            self.assertEqual(result['kvmat']['request_scoped_recompute_admissions'], 200)
            self.assertIsNone(result['efficiency_percent'])

    def test_import_only_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.fixture(root, active=False)
            with self.assertRaises(ValueError):
                audit(root)

    def test_missing_engine_ack_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.fixture(root)
            write_rows(root / 'kvmat-engine.jsonl', [])
            with self.assertRaises(ValueError):
                audit(root)


if __name__ == '__main__':
    unittest.main()
