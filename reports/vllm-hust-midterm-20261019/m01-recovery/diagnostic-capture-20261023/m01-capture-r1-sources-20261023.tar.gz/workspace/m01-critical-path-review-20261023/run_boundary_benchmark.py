"""Client entrypoint; service ownership and device admission belong to controller."""
import argparse
import json
import os
from pathlib import Path

from benchmark_boundary_hook import install
from boundary_transport import BoundaryTransport
from synchronized_boundary import ClientBoundary


def validate_args(args, port):
    expected = {
        'base_url': f'http://127.0.0.1:{port}',
        'backend': 'openai-chat', 'endpoint': '/v1/chat/completions',
        'num_prompts': 200, 'custom_output_len': 256,
        'request_rate': float('inf'), 'temperature': 0, 'seed': 0,
        'disable_shuffle': True, 'save_result': True, 'save_detailed': True,
        'num_warmups': 0, 'profile': False,
    }
    for name, value in expected.items():
        if getattr(args, name, None) != value:
            raise ValueError(f'Unexpected M01 benchmark parameter: {name}')


def execute(module, args, port, source_sha, receipt):
    validate_args(args, port)
    boundary = ClientBoundary(BoundaryTransport(port))
    # Reserve the receipt before any network operation; never replace evidence.
    with Path(receipt).open('x', encoding='utf-8') as output:
        def emit(record):
            output.write(json.dumps(record, sort_keys=True) + '\n')
            output.flush()
            os.fsync(output.fileno())

        try:
            install(module, boundary, source_sha, emit)
            result = module.main(args)
            if boundary.state != 'completed':
                raise RuntimeError('Benchmark returned without both device fences')
            return result
        except BaseException as error:
            emit(dict(protocol='m01-boundary-client-failure/v1',
                      exception_type=type(error).__name__, state=boundary.state,
                      calls=boundary.calls, effective_flops=None,
                      efficiency_percent=None))
            raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--receipt', required=True)
    parser.add_argument('benchmark_args', nargs=argparse.REMAINDER)
    options = parser.parse_args()
    from vllm.benchmarks import serve
    from vllm.utils.argparse_utils import FlexibleArgumentParser
    bench_parser = FlexibleArgumentParser()
    serve.add_cli_args(bench_parser)
    argv = options.benchmark_args
    if argv[:1] == ['--']:
        argv = argv[1:]
    args = bench_parser.parse_args(argv)
    execute(serve, args, options.port, options.source_sha256, options.receipt)


if __name__ == '__main__':
    main()
