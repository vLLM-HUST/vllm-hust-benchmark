import unittest
from audit_reference_scope import operation_calls


class ScopeTests(unittest.TestCase):
    def test_nested(self):
        self.assertEqual(operation_calls('def worker():\n def operation():\n  tensor.fill_(1)\n  torch.npu.synchronize()\n'),
                         ['tensor.fill_', 'torch.npu.synchronize'])

    def test_missing(self):
        with self.assertRaises(ValueError):
            operation_calls('pass')

    def test_ambiguous(self):
        with self.assertRaises(ValueError):
            operation_calls('def operation(): pass\ndef operation(): pass')


if __name__ == '__main__':
    unittest.main()
