"""Insert boundary-only hooks in a hash-pinned benchmark without editing vLLM."""
import ast
import hashlib
import inspect
from pathlib import Path
import time


def guard(values):
    if values.get('profile') is not False or values.get('probe_request_rate', 0) != 0:
        raise ValueError('Profiling and competing probe traffic are forbidden')
    if values.get('self_timed', False) or values.get('ramp_up_strategy') is not None:
        raise ValueError('Fixed burst timing required')


def instrument(source):
    tree = ast.parse(source)
    matches = [n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'benchmark']
    if len(matches) != 1:
        raise ValueError('Expected one async benchmark function')
    function = matches[0]
    if function.decorator_list:
        raise ValueError('Unexpected benchmark decorator')
    body = ast.parse('__m01_guard(locals())').body
    found = []
    for statement in function.body:
        name = None
        if isinstance(statement, ast.Assign) and len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name):
            name = statement.targets[0].id
        if name == 'benchmark_start_time':
            if ast.unparse(statement.value) != 'time.perf_counter()':
                raise ValueError('Changed start clock')
            body.extend(ast.parse('await __m01_boundary.begin()').body)
            found.append('start')
        body.append(statement)
        if name == 'benchmark_duration':
            if ast.unparse(statement.value) != 'time.perf_counter() - benchmark_start_time':
                raise ValueError('Changed duration formula')
            body.extend(ast.parse('await __m01_boundary.end()\n__m01_finish(benchmark_start_time, benchmark_duration)').body)
            found.append('end')
    if found != ['start', 'end']:
        raise ValueError('Ambiguous benchmark timing boundaries')
    function.body = body
    return ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))


def install(module, boundary, expected_sha256, emit):
    path = Path(inspect.getsourcefile(module.benchmark))
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_sha256:
        raise ValueError('Benchmark source identity mismatch')
    if any(name in module.__dict__ for name in ('__m01_boundary', '__m01_finish', '__m01_guard')):
        raise ValueError('Boundary already installed')

    def finish(start, client_duration):
        if boundary.state != 'completed':
            raise ValueError('Incomplete synchronized boundary')
        end = time.perf_counter()
        synchronized_duration = end - start
        if synchronized_duration < client_duration:
            raise ValueError('Synchronized envelope excludes client work')
        emit(dict(protocol='m01-unprofiled-client-synchronized-boundary/v1',
            benchmark_source_sha256=actual, client_duration_seconds=client_duration,
            synchronized_duration_seconds=synchronized_duration,
            start_perf_counter=start, end_perf_counter=end, calls=boundary.calls,
            includes_end_pause_drain_rpc_overhead=True,
            instrumentation='boundary-only; no per-request or per-token hooks',
            effective_flops=None, efficiency_percent=None))

    module.__dict__.update(__m01_boundary=boundary, __m01_finish=finish, __m01_guard=guard)
    exec(compile(instrument(raw.decode()), str(path), 'exec'), module.__dict__)
