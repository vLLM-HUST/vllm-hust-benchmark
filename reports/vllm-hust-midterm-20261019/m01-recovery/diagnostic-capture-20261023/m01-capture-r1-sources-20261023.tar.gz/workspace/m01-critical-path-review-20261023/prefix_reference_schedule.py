"""Reference schedule for the pinned split FA prefix, not a full-model DAG."""
import math


def schedule(norm_seconds, projection_seconds, post_seconds):
    sequences = (norm_seconds, projection_seconds, post_seconds)
    count = len(norm_seconds)
    if count == 0 or any(len(values) != count for values in sequences):
        raise ValueError('One timing for every phase of each partition required')
    if any(type(v) not in (float, int) or not math.isfinite(v) or v < 0
           for values in sequences for v in values):
        raise ValueError('Finite nonnegative independent reference durations required')
    rows = []
    vector_end = cube_end = 0.0
    norm_ends, cube_ends = [], []
    for index, (norm, projection) in enumerate(zip(norm_seconds, projection_seconds)):
        start = vector_end
        vector_end += norm
        norm_ends.append(vector_end)
        rows.append(dict(node=f'norm.{index}', start=start, end=vector_end,
                         predecessors=[] if index == 0 else [f'norm.{index-1}']))
        start = max(vector_end, cube_end)
        cube_end = start + projection
        cube_ends.append(cube_end)
        rows.append(dict(node=f'qkv.{index}', start=start, end=cube_end,
                         predecessors=[f'norm.{index}'] + ([] if index == 0 else [f'qkv.{index-1}'])))
    for index, post in enumerate(post_seconds):
        start = max(vector_end, cube_ends[index])
        vector_end = start + post
        rows.append(dict(node=f'post.{index}', start=start, end=vector_end,
                         predecessors=[f'qkv.{index}', f'norm.{count-1}' if index == 0 else f'post.{index-1}']))
    return dict(nodes=rows, prefix_reference_seconds=vector_end,
                serial_phase_sum=sum(map(sum, sequences)),
                scope='Independent reference durations under pinned vector/cube queue dependencies; not measured model time',
                limitations=['Durations must match partition shapes and precision, including each kernel memory cost.',
                             'Concurrent-resource interference and necessary launch/event costs require applicability checks.',
                             'Do not use this uncongested schedule as attainable hardware time without validating overlap.',
                             'No separately added global HBM term and no efficiency inferred.'])
