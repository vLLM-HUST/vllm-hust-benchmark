import hashlib
from pathlib import Path
import tempfile
import unittest
from audit_boundary_evidence import check_details, verify_seal, same_json_record


class EvidenceTests(unittest.TestCase):
    def test_serialized_rank_keys_match(self):
        self.assertTrue(same_json_record({'microflow': {'0': {'events': 130}}},
                                        {'microflow': {0: {'events': 130}}}))
        self.assertFalse(same_json_record({'microflow': {'0': {'events': 130}}},
                                         {'microflow': {0: {'events': 129}}}))

    def test_valid_request_details(self):
        data = dict(input_lens=[1400]*199+[3665], output_lens=[256]*200,
                    start_times=[1.0]*200, ttfts=[0.1]*200, itls=[[]]*200, errors=['']*200)
        check_details(data)
        data['output_lens'][0] = 255
        with self.assertRaises(ValueError):
            check_details(data)

    def test_incomplete_fields_rejected(self):
        with self.assertRaises(ValueError):
            check_details({})

    def test_seal_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'data').write_bytes(b'changed')
            (root / 'SHA256SUMS').write_text(hashlib.sha256(b'original').hexdigest() + '  data\n')
            with self.assertRaisesRegex(ValueError, 'Seal mismatch'):
                verify_seal(root)

    def test_seal_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'SHA256SUMS').write_text('0'*64 + '  ../outside\n')
            with self.assertRaisesRegex(ValueError, 'escaping'):
                verify_seal(root)


if __name__ == '__main__':
    unittest.main()
