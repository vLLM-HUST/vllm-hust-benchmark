"""Explicit runtime classes for diagnostic qualification, not a performance arm."""
import os
from pathlib import Path
import socket

from betterscale.models.qwen35.seat_scheduler import LiveStateScheduler
from hust_prefill_microflow.school028.worker import Worker as MicroflowWorker
from vllm_ascend.worker.model_runner_v1 import NPUModelRunner

from capture_export import export_snapshot
from dual_clock_boundary import DualClockWorkerBoundary
from host_prefill_wave_capture import HostPrefillWaveCapture
from wave_capture_bridge import SchedulerWaveCapture, WorkerWaveCapture, check_run_label


def settings():
    run_id = os.environ['HUST_M01_CAPTURE_RUN_ID']
    check_run_label(run_id)
    directory = Path(os.environ['HUST_M01_CAPTURE_DIR'])
    if not directory.is_absolute() or not directory.is_dir():
        raise ValueError('Controller-created absolute evidence directory required')
    limits = {key: int(os.environ[key]) for key in
              ('HUST_M01_CAPTURE_MAX_EVENTS', 'HUST_M01_CAPTURE_MAX_REQUESTS')}
    if any(n <= 0 for n in limits.values()):
        raise ValueError('Positive capture limits required')
    return run_id, directory, limits


class CaptureRunner(HostPrefillWaveCapture, NPUModelRunner):
    pass


class CaptureScheduler(SchedulerWaveCapture, LiveStateScheduler):
    def __init__(self, *args, **kwargs):
        run_id, directory, limits = settings()
        super().__init__(*args, **kwargs)
        self._capture_directory = directory
        self.enable_wave_capture(run_id=run_id, max_events=limits['HUST_M01_CAPTURE_MAX_EVENTS'],
                                 max_requests=limits['HUST_M01_CAPTURE_MAX_REQUESTS'])

    def shutdown(self):
        try:
            return super().shutdown()
        finally:
            if hasattr(self, '_output_ledger'):
                snapshot = self.output_ledger_snapshot()
                active = len(self.requests)
                snapshot.update(host=socket.gethostname(), pid=os.getpid(),
                                run_id=self._wave_run_id, active_requests=active,
                                measurement_role='diagnostic_qualification')
                snapshot['complete'] = snapshot['complete'] and active == 0
                snapshot['retained_count_complete'] = snapshot['retained_count_complete'] and active == 0
                export_snapshot(self._capture_directory, f'scheduler-{os.getpid()}.json', snapshot)


class CaptureWorker(DualClockWorkerBoundary, WorkerWaveCapture, MicroflowWorker):
    def load_model(self, *args, **kwargs):
        run_id, directory, limits = settings()
        result = super().load_model(*args, **kwargs)
        if type(self.model_runner) is not NPUModelRunner:
            raise ValueError('Unqualified runner class; do not replace a custom runner')
        parallel = self.vllm_config.parallel_config
        if parallel.pipeline_parallel_size != 1 or parallel.tensor_parallel_size != 2:
            raise ValueError('Capture qualified only for TP2/PP1')
        self.model_runner.__class__ = CaptureRunner
        self.model_runner.enable_host_prefill_capture(expected_layers=30)
        self.enable_wave_capture(run_id=run_id, max_events=limits['HUST_M01_CAPTURE_MAX_EVENTS'])
        self._capture_directory = directory
        self._capture_exported = False
        return result

    def execute_model(self, scheduler_output):
        if getattr(self, '_capture_exported', False):
            raise RuntimeError('Capture already exported; start a fresh qualification process')
        return super().execute_model(scheduler_output)

    def hust_m01_export_wave_capture(self):
        if self._capture_exported:
            raise ValueError('Worker capture already exported')
        if self._pending_wave is not None:
            raise ValueError('Drain deferred sampling before exporting')
        import torch
        torch.npu.synchronize()
        snapshot = self.wave_capture_snapshot()
        snapshot.update(host=socket.gethostname(), pid=os.getpid(),
                        rank=torch.distributed.get_rank(), run_id=self._wave_run_id,
                        measurement_role='diagnostic_qualification')
        receipt = export_snapshot(self._capture_directory, f'worker-{os.getpid()}.json', snapshot)
        self._capture_exported = True
        return receipt


def register():
    """Diagnostic plugin, loaded after Microflow in every engine/worker process."""
    if os.environ.get('HUST_M01_WAVE_CAPTURE') != '1':
        return
    settings()
    import betterscale.qwen35_worker as worker_module
    import betterscale.models.qwen35.seat_scheduler as scheduler_module
    if worker_module.Worker is CaptureWorker and scheduler_module.LiveStateScheduler is CaptureScheduler:
        return
    if worker_module.Worker is not MicroflowWorker or scheduler_module.LiveStateScheduler is not LiveStateScheduler:
        raise ValueError('Expected Microflow worker and original State scheduler before capture registration')
    # Preserve the public paths enforced by the pinned State configuration.
    worker_module.Worker = CaptureWorker
    scheduler_module.LiveStateScheduler = CaptureScheduler
