import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import run_collective_graph_after_release as gate


class ReleaseAdmissionTests(unittest.TestCase):
    def test_missing_dependency_rejected(self):
        with self.assertRaises(RuntimeError):
            gate.released_dependencies({'dependency_receipt_sha256': {}})

    def check_case(self, released=True, error='AssertionError: Disk reserve exhausted'):
        with tempfile.TemporaryDirectory() as tmp, patch.object(gate.controller, 'ROOT', Path(tmp)):
            plan = {'dependency_receipt_sha256': {}}
            for role in ('solver', 'judge'):
                name = 'frontierscience-native018-' + role + '-r1'
                directory = Path(tmp) / name
                directory.mkdir()
                receipt = directory / 'receipt.json'
                receipt.write_text(json.dumps(dict(status='completed' if role == 'solver' else 'failed',
                    sessions_drained=True, all_devices_released=released, error=error)))
                plan['dependency_receipt_sha256'][name] = gate.digest(receipt)
                (directory / 'SHA256SUMS').write_text(gate.digest(receipt) + '  receipt.json\n')
            gate.released_dependencies(plan)

    def test_sealed_disk_failure_allowed(self):
        self.check_case()

    def test_unreleased_rejected(self):
        with self.assertRaises(RuntimeError):
            self.check_case(released=False)

    def test_other_failure_rejected(self):
        with self.assertRaises(RuntimeError):
            self.check_case(error='unexplained')
