import hashlib
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


class CandidateTests(unittest.TestCase):
    def setUp(self):
        self.result = json.loads((HERE / 'target-useful-candidate-r1.json').read_text())
        self.bench = json.loads((ROOT / 'm01-recovery-model-worker-r1/mmlu-pro.json').read_text())

    def test_source_identity(self):
        for name, digest in self.result['source_sha256'].items():
            self.assertEqual(hashlib.sha256(Path(name).read_bytes()).hexdigest(), digest, name)

    def test_counts_independently(self):
        rows = pairs = 0
        for inputs, outputs in zip(self.bench['input_lens'], self.bench['output_lens'], strict=True):
            rows += inputs + outputs - 1
            pairs += inputs * (inputs + 1) // 2
            pairs += sum(inputs + step for step in range(1, outputs))
        self.assertEqual(rows, self.result['candidate_target_rows'])
        self.assertEqual(pairs, self.result['candidate_causal_pairs'])
        self.assertEqual(self.result['observed_target_valid_rows'] - rows, self.result['observed_extra_rows'])

    def test_not_promoted_to_score(self):
        self.assertIsNone(self.result['effective_flops'])
        self.assertIsNone(self.result['efficiency_percent'])
        self.assertEqual(self.result['candidate_target_matrix_subtotal'],
                         self.result['candidate_target_projection_flops'] + self.result['candidate_target_qk_av_flops'])


if __name__ == '__main__':
    unittest.main()
