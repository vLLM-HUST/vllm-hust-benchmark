"""Conditional useful vocabulary and causal-convolution work, globally counted."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
sys.path.insert(0, str(ROOT))
from audit_vocab_projection_recovery_model_worker_r1 import projection
from audit_conv_accounting import operations


def convolution_counts(lengths, channels=8192, layers=30):
    totals = {}
    for length in lengths:
        for key, value in operations(length, False, channels=channels).items():
            totals[key] = totals.get(key, 0) + value * layers
    return totals


def build():
    here = Path(__file__).resolve().parent
    hashes = {}

    def read(path, expected=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f'Source mismatch: {path}')
        hashes[str(path)] = digest
        return raw

    parent = json.loads(read(here / 'target-nonmatrix-candidate-r2.json'))
    for name, digest in parent['source_sha256'].items():
        read(Path(name), digest)
    for filename in ('recovery_model_worker_r1-device-gdn-ledger.json',
                     'vocab-projection-summary-recovery_model_worker_r1.json'):
        ledger = json.loads(read(ROOT / filename))
        for name, digest in ledger['source_sha256'].items():
            read(Path(name), digest)
    summary = ledger
    assert {r['rank'] for r in summary['ranks']} == {0, 1}
    shapes = [r['loaded_head_shapes']['target'] for r in summary['ranks']]
    run = ROOT / 'm01-recovery-model-worker-r1'
    bench = json.loads(read(run / 'mmlu-pro.json'))
    assert bench['completed'] == 200 and bench['failed'] == 0
    lengths = [i + o - 1 for i, o in zip(bench['input_lens'], bench['output_lens'], strict=True)]
    assert sum(lengths) == parent['candidate_target_rows']
    assert sum(bench['output_lens']) == bench['total_output_tokens']
    for trace in sorted(run.glob('token-accounting-*.jsonl')):
        inventory = next(json.loads(line) for line in read(trace).splitlines()
                         if json.loads(line)['event'] == 'loaded_model_inventory')
        convs = [m for m in inventory['target']['modules'] if m['name'].endswith('.linear_attn.conv1d')]
        assert len(convs) == 30
        assert all(m['parameters']['weight']['shape'] == [4096, 1, 4] for m in convs)
    conv = convolution_counts(lengths)
    vocab = projection(bench['total_output_tokens'], shapes)
    for path in (Path(__file__), ROOT / 'audit_conv_accounting.py',
                 ROOT / 'audit_vocab_projection_recovery_model_worker_r1.py'):
        read(path)
    basic_conv = conv['convolution_multiply'] + conv['convolution_add']
    return dict(status='conditional_target_vocab_convolution_candidate_not_full_effective_flops',
        candidate_vocabulary_rows=bench['total_output_tokens'],
        observed_vocabulary_rows=summary['ranks'][0]['rows']['target'],
        candidate_vocabulary_projection_flops=vocab,
        convolution_operations=conv, candidate_convolution_basic_flops=basic_conv,
        combined_target_partial_subtotal=parent['combined_target_partial_subtotal'] + vocab + basic_conv,
        effective_flops=None, efficiency_percent=None, source_sha256=hashes,
        assumptions=[
            'Necessary target logits are one full vocabulary projection for each returned output token.',
            'Each request begins with zero convolution history and no reused prefix, as established in the parent candidate.',
            'Two TP partitions of 4096 channels form 8192 global channels across 30 GDN layers; count each once.',
            'Convolution taps on structural zero history are excluded; SiLU evaluations are separate.'],
        limitations=[
            'Inherits conditional semantic target extents, not exact per-token output provenance.',
            'Draft work, GDN recurrence, GDN prefill and preprocessing remain unaccounted in this partial sum.',
            'No special-function FLOP conversion, measured timing or efficiency is assigned.',
            'Physical rejected, padded and terminal work is not useful arithmetic.'])


if __name__ == '__main__':
    result = build()
    with Path(__file__).with_name('target-vocab-conv-candidate-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('candidate_vocabulary_projection_flops',
        'candidate_convolution_basic_flops','combined_target_partial_subtotal')}))
