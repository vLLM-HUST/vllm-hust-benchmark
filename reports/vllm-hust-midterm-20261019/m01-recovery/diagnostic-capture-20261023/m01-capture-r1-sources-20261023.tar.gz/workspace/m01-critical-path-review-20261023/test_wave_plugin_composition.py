import importlib.util
from pathlib import Path
from types import SimpleNamespace as NS

import pytest


def plugin():
    path = Path(__file__).with_name('wave-plugin-src') / 'm01_capture_plugin.py'
    spec = importlib.util.spec_from_file_location('capture_plugin_test', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def env(monkeypatch):
    monkeypatch.setenv('HUST_M01_WAVE_CAPTURE', '1')
    monkeypatch.setenv('HUST_MICROFLOW_SCHOOL028_FA', '1')
    monkeypatch.setenv('VLLM_PLUGINS', 'ascend,hust_m01_wave_capture')


def test_default_off_does_not_import_runtime(monkeypatch):
    p = plugin()
    monkeypatch.delenv('HUST_M01_WAVE_CAPTURE', raising=False)
    monkeypatch.setattr(p.importlib, 'import_module', lambda name: pytest.fail('unexpected runtime import'))
    p.register()


def test_explicit_order_and_idempotence(monkeypatch):
    p = plugin()
    env(monkeypatch)
    order = []
    worker, scheduler = NS(Worker=object()), NS(LiveStateScheduler=object())
    runtime = NS(CaptureWorker=object(), CaptureScheduler=object())
    def capture():
        order.append('capture')
        worker.Worker, scheduler.LiveStateScheduler = runtime.CaptureWorker, runtime.CaptureScheduler
    runtime.register = capture
    modules = {'wave_capture_runtime': runtime, 'betterscale.qwen35_worker': worker,
               'betterscale.models.qwen35.seat_scheduler': scheduler,
               'hust_prefill_microflow.school028': NS(register=lambda: order.append('microflow'))}
    monkeypatch.setattr(p.importlib, 'import_module', modules.__getitem__)
    p.register()
    p.register()
    assert order == ['microflow', 'capture']


@pytest.mark.parametrize('plugins', ['hust_microflow_school028_fa,hust_m01_wave_capture', 'ascend'])
def test_ambiguous_allowlist_rejected(monkeypatch, plugins):
    env(monkeypatch)
    monkeypatch.setenv('VLLM_PLUGINS', plugins)
    with pytest.raises(ValueError):
        plugin().register()
