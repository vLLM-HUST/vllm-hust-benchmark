import asyncio
from unittest.mock import patch

import pytest

from dual_clock_boundary import (
    DualClockClientBoundary, DualClockWorkerBoundary, capture_anchor,
    clock_offset_envelope, offset_interval,
)


def anchor(start=100, offset=1000, pid=1):
    return dict(protocol='m01-clock-bracket/v1', host='test', pid=pid,
                wall_ns=start+offset+5, perf_before_ns=start,
                perf_after_ns=start+10, monotonic_before_ns=start+1,
                monotonic_after_ns=start+9)


def test_distinct_clock_domains_and_bounds():
    a = anchor()
    assert offset_interval(a, 'perf') == (995, 1005)
    assert offset_interval(a, 'monotonic') == (996, 1004)
    assert clock_offset_envelope(a, anchor(200), 'perf', max_drift_ns=0)['offset_min_ns'] == 995


def test_real_capture_order_and_integer_precision():
    a = capture_anchor()
    for clock in ('perf', 'monotonic'):
        lo, hi = offset_interval(a, clock)
        assert lo <= hi


@pytest.mark.parametrize('end,drift', [(anchor(200, 1100), 10), (anchor(200, pid=2), 0),
                                     (anchor(105), 0), (anchor(200), -1)])
def test_reject_unsupported_alignment(end, drift):
    with pytest.raises(ValueError):
        clock_offset_envelope(anchor(), end, 'perf', max_drift_ns=drift)


def test_reject_float_and_unknown_clock():
    a = anchor()
    a['wall_ns'] = float(a['wall_ns'])
    with pytest.raises(ValueError):
        offset_interval(a, 'perf')
    with pytest.raises(ValueError):
        offset_interval(anchor(), 'wall')


def test_client_keeps_original_transport_payload():
    calls = []
    async def post(path, payload):
        calls.append((path, payload))
        return {'status': 'paused'}
    boundary = DualClockClientBoundary(post)
    result = asyncio.run(boundary.call('/pause', {'mode': 'wait'}))
    assert result == {'status': 'paused'}
    assert calls == [('/pause', {'mode': 'wait'})]
    row = boundary.calls[0]
    assert row['start_ns'] <= row['end_ns']
    for name in ('clock_before', 'clock_after'):
        offset_interval(row[name], 'perf')


def test_worker_keeps_fence_ack_without_device_call():
    with patch('dual_clock_boundary.WorkerBoundary.hust_m01_sync_boundary',
               return_value={'phase': 'end', 'device_sync_completed': True}) as method:
        result = DualClockWorkerBoundary().hust_m01_sync_boundary('end')
    method.assert_called_once_with('end')
    assert result['device_sync_completed'] is True
    assert result['clock_before']['pid'] == result['clock_after']['pid']
