from types import SimpleNamespace as NS

import pytest

from scheduler_output_ledger import SchedulerOutputLedger


class Native:
    num_sampled_tokens_per_step = 1

    def update_from_output(self, schedule, output):
        results = []
        for rid in schedule.num_scheduled_tokens:
            if rid not in output:
                continue
            request, tokens = output[rid]
            results.append(self._update_request_with_output(request, tokens))
        return results

    def _update_request_with_output(self, request, tokens, is_stale=False):
        del tokens[request.keep:]
        request._output_token_ids.extend(tokens)
        return tokens, request.keep < 3


class Observed(SchedulerOutputLedger, Native):
    pass


def setup(events=100, requests=10):
    s = Observed()
    s.enable_output_ledger(max_events=events, max_requests=requests)
    return s


def schedule(*ids):
    return NS(num_scheduled_tokens={rid: 3 for rid in ids},
              scheduled_spec_decode_tokens={rid: [5, 6] for rid in ids})


def request(rid, keep=1):
    return NS(request_id=rid, keep=keep, _output_token_ids=[])


def test_frame_and_request_mapping_without_token_or_id_export():
    s = setup()
    r = request('private-id')
    assert s.update_from_output(schedule('private-id'), {'private-id': (r, [7, 8, 9])}) == [([7], True)]
    s.update_from_output(schedule('private-id'), {'private-id': (r, [2, 3, 4])})
    result = s.output_ledger_snapshot()
    rows = [e for e in result['events'] if e['event'] == 'output_update']
    assert [e['frame'] for e in rows] == [0, 1]
    assert [e['request'] for e in rows] == [0, 0]
    assert [e['observation']['retained_drafts'] for e in rows] == [1, 1]
    assert 'private-id' not in str(result)
    assert result['complete']


def test_finished_request_not_invented_as_zero_acceptance():
    s = setup()
    s.update_from_output(schedule('finished'), {})
    rows = s.output_ledger_snapshot()['events']
    skipped = [e for e in rows if e['event'] == 'not_updated']
    assert len(skipped) == 1 and 'observation' not in skipped[0]
    assert not s.output_ledger_snapshot()['retained_count_complete']


@pytest.mark.parametrize('events,requests', [(1, 10), (100, 1)])
def test_capacity_failure_does_not_change_native_output(events, requests):
    s = setup(events, requests)
    result = s.update_from_output(schedule('a', 'b'),
                                 {k: (request(k), [1, 2, 3]) for k in ('a', 'b')})
    assert result == [([1], True), ([1], True)]
    assert not s.output_ledger_snapshot()['complete']


def test_native_failure_and_frame_cleanup():
    s = setup()
    with pytest.raises(AttributeError):
        s.update_from_output(schedule('a'), {'a': (object(), [1])})
    result = s.output_ledger_snapshot()
    assert result['open_frames'] == 0 and not result['complete']


def test_disabled_is_native():
    s = Observed()
    assert s.update_from_output(schedule('a'), {'a': (request('a'), [1, 2, 3])}) == [([1], True)]
    assert not hasattr(s, '_output_ledger')


def test_nested_frame_restores_parent():
    class NestedNative(Native):
        def update_from_output(self, sched, output):
            if 'outer' in sched.num_scheduled_tokens:
                self.update_from_output(schedule('inner'), {'inner': (request('inner', 2), [1, 2, 3])})
            return super().update_from_output(sched, output)
    class Nested(SchedulerOutputLedger, NestedNative):
        pass
    s = Nested()
    s.enable_output_ledger(max_events=100, max_requests=10)
    s.update_from_output(schedule('outer'), {'outer': (request('outer'), [1, 2, 3])})
    result = s.output_ledger_snapshot()
    rows = [e for e in result['events'] if e['event'] == 'output_update']
    assert [(e['frame'], e['observation']['retained_drafts']) for e in rows] == [(1, 2), (0, 1)]
    assert result['retained_count_complete']
    rows[0]['observation']['retained_drafts'] = 99
    fresh = [e for e in s.output_ledger_snapshot()['events'] if e['event'] == 'output_update']
    assert fresh[0]['observation']['retained_drafts'] == 2
