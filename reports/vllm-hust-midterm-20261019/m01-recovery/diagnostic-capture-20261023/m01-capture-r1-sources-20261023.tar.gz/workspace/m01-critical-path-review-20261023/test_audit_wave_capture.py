from copy import deepcopy

import pytest

from audit_wave_capture import audit
from test_wave_capture_bridge import setup, Worker, request


def exports():
    scheduler, worker0 = setup()
    worker1 = Worker()
    worker1.enable_wave_capture(run_id='r1', max_events=100)
    output = scheduler.schedule()
    for worker in (worker0, worker1):
        worker.execute_model(deepcopy(output))
        tokens = worker.sample_tokens(None)
    scheduler.update_from_output(output, {'a': (request('a'), tokens)})
    s = scheduler.output_ledger_snapshot()
    s.update(run_id='r1', active_requests=0, measurement_role='diagnostic_qualification')
    workers = []
    for rank, worker in enumerate((worker0, worker1)):
        w = worker.wave_capture_snapshot()
        w.update(run_id='r1', rank=rank, measurement_role='diagnostic_qualification')
        workers.append(w)
    return s, workers


def test_actual_mixin_exports_join_without_claiming_m01():
    result = audit(*exports())
    assert result['status'] == 'joined', result
    assert result['retained_count_complete']
    assert result['m01_attainment'] is None


def test_real_host_snapshot_event_is_supported():
    from test_host_prefill_wave_capture import setup as runner_setup
    from wave_capture_bridge import ACTIVE_WAVE
    s, ws = exports()
    runner = runner_setup()
    core = runner.metadata['layer.0']
    runner.metadata = {f'layer.{i}': core for i in range(30)}
    runner._host_prefill_layers = 30
    worker = Worker()
    worker.enable_wave_capture(run_id='r1', max_events=100)
    tag = ws[0]['events'][0]['identity']
    token = ACTIVE_WAVE.set(dict(identity=tag, recorder=worker, phase='execute'))
    try:
        runner._build_attention_metadata(5, 2, 3)
    finally:
        ACTIVE_WAVE.reset(token)
    event = worker.wave_capture_snapshot()['events'][0]
    event['perf_ns'] = ws[0]['events'][1]['perf_ns']
    ws[0]['events'].insert(1, event)
    assert audit(s, ws)['status'] == 'joined'
    event['groups'][0]['cu'] = [0]
    assert audit(s, ws)['status'] == 'incomplete'


@pytest.mark.parametrize('fault', ['missing_rank', 'duplicate_rank', 'other_run',
    'missing_end', 'duplicate_execute', 'wrong_digest', 'missing_delivery',
    'open_frame', 'dropped', 'pending', 'clock_reversal'])
def test_incomplete_or_mixed_evidence_rejected(fault):
    s, ws = exports()
    if fault == 'missing_rank': ws.pop()
    elif fault == 'duplicate_rank': ws[1]['rank'] = 0
    elif fault == 'other_run': ws[1]['run_id'] = 'r2'
    elif fault == 'missing_end': ws[1]['events'].pop()
    elif fault == 'duplicate_execute': ws[1]['events'] *= 2
    elif fault == 'wrong_digest': ws[1]['events'][0]['identity']['layout_sha256'] = 'wrong'
    elif fault == 'missing_delivery': s['events'] = [e for e in s['events'] if e['event'] != 'delivery']
    elif fault == 'open_frame': s['events'] = [e for e in s['events'] if e['event'] != 'frame_end']
    elif fault == 'dropped': ws[1]['dropped'] = 1
    elif fault == 'pending': ws[1]['pending'] = True
    elif fault == 'clock_reversal': ws[1]['events'][-1]['perf_ns'] = 0
    assert audit(s, ws)['status'] == 'incomplete'
