import unittest
from prefix_reference_schedule import schedule


class PrefixReferenceTests(unittest.TestCase):
    def test_one_partition_serial(self):
        self.assertEqual(schedule([2], [3], [4])['prefix_reference_seconds'], 9)

    def test_real_overlap_not_sum_or_global_max(self):
        result = schedule([1, 1], [4, 4], [1, 1])
        self.assertEqual(result['prefix_reference_seconds'], 10)
        self.assertEqual(result['serial_phase_sum'], 12)
        self.assertNotEqual(result['prefix_reference_seconds'], max(4, 8))

    def test_post_waits_for_all_frontloaded_norms(self):
        result = schedule([10, 10], [1, 1], [1, 1])
        first_post = next(n for n in result['nodes'] if n['node'] == 'post.0')
        self.assertEqual(first_post['start'], 20)
        self.assertEqual(result['prefix_reference_seconds'], 22)

    def test_all_dependencies_satisfied(self):
        result = schedule([1, 3, 2, 1], [2, 1, 4, 2], [3, 1, 2, 1])
        ends = {n['node']: n['end'] for n in result['nodes']}
        for node in result['nodes']:
            for predecessor in node['predecessors']:
                self.assertGreaterEqual(node['start'], ends[predecessor])

    def test_invalid_inputs(self):
        for values in (([], [], []), ([1], [1, 2], [1]), ([float('nan')], [1], [1]), ([-1], [1], [1])):
            with self.assertRaises(ValueError):
                schedule(*values)
