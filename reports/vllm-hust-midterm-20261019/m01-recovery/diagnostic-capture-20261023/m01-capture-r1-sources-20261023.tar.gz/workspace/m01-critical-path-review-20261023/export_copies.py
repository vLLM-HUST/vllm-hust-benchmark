"""Re-export archived worker captures, preserving original capture bytes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'workspace/m01-worker-r1-profiler'
OUT = ROOT / 'offline-export-r1'


def inventory(path):
    result = {}
    for file in sorted(path.rglob('*')):
        if file.is_file():
            with file.open('rb') as stream:
                result[str(file.relative_to(path))] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return result


def main():
    OUT.mkdir(exist_ok=False)
    receipt = {'status': 'exporting', 'started_unix': time.time(), 'ranks': [],
               'purpose': 'Offline dependency inspection; no new inference or efficiency score'}
    try:
        for rank in (0, 1):
            sources = list(RAW.glob(f'rank-{rank}-pid-*'))
            if len(sources) != 1:
                raise ValueError('Ambiguous capture source')
            source = sources[0]
            hashes = inventory(source)
            if not hashes:
                raise ValueError('Empty capture')
            target = OUT / f'rank-{rank}'
            shutil.copytree(source, target)
            if inventory(target) != hashes:
                raise ValueError('Copy mismatch')
            profiles = [p for p in target.rglob('PROF_*') if p.is_dir()]
            if len(profiles) != 1:
                raise ValueError('Ambiguous profiler directory')
            cmd = ['nice', '-n', '19', '/usr/local/Ascend/cann-9.1.0/bin/msprof',
                   '--export=on', '--type=db', f'--output={profiles[0]}']
            row = {'rank': rank, 'source': str(source), 'target': str(target),
                   'source_sha256': hashes, 'command': cmd}
            receipt['ranks'].append(row)
            env = dict(os.environ, OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
            with (OUT / f'rank-{rank}.log').open('x') as log:
                proc = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT,
                                      timeout=1800)
            row['exit_code'] = proc.returncode
            row['source_unchanged'] = inventory(source) == hashes
            if proc.returncode != 0 or not row['source_unchanged']:
                raise RuntimeError('Export failed or original changed')
            print(json.dumps({'rank': rank, 'exit_code': proc.returncode,
                              'source_unchanged': row['source_unchanged']}), flush=True)
        receipt['status'] = 'exported_pending_dependency_audit'
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        receipt['ended_unix'] = time.time()
        with (OUT / 'receipt.json').open('x') as stream:
            json.dump(receipt, stream, indent=2)
            stream.write('\n')


if __name__ == '__main__':
    main()
