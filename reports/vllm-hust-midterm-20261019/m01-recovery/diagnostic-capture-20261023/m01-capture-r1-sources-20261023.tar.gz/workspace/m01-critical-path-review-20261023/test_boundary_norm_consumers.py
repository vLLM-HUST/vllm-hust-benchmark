import pytest

from review_boundary_norm_consumers import sensitivity


def test_norm_sensitivity_is_not_all_layer_work():
    assert sum(sensitivity(333265, 51200).values()) == 282065 * 10241


def test_all_positions_sampled():
    assert sum(sensitivity(8, 8).values()) == 0


@pytest.mark.parametrize('target,output', [(1, 2), (-1, 0), (True, 0)])
def test_invalid_extents(target, output):
    with pytest.raises(ValueError):
        sensitivity(target, output)
