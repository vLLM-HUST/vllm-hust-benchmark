import json
from pathlib import Path
import unittest


class DraftArithmeticSensitivityTests(unittest.TestCase):
    def test_envelope_arithmetic(self):
        result = json.loads(Path(__file__).with_name('draft-arithmetic-sensitivity-r1.json').read_text())
        lower, upper = result['listed_family_lower'], result['listed_family_upper']
        self.assertEqual(result['draft_upper_all_observed_valid_work'], sum(result['observed_draft_family_upper_parts'].values()))
        self.assertEqual(lower, result['target_candidate'] + result['draft_lower_retained_vocab_only'])
        self.assertEqual(upper, result['target_candidate'] + result['draft_upper_all_observed_valid_work'])
        self.assertAlmostEqual(result['interval_width_percent_of_lower'], 100 * (upper-lower) / lower)

    def test_no_admission_or_reference_claim(self):
        result = json.loads(Path(__file__).with_name('draft-arithmetic-sensitivity-r1.json').read_text())
        self.assertIsNone(result['effective_flops'])
        self.assertIsNone(result['efficiency_percent'])
        self.assertTrue(any('does not bound reference time' in s for s in result['limitations']))
