"""Candidate nonredundant target matrix demand; not a complete effective F."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def main():
    hashes = {}
    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw
    run = ROOT / 'm01-recovery-model-worker-r1'
    bench = json.loads(read(run / 'mmlu-pro.json'))
    policy = [json.loads(line) for line in read(run / 'kvmat-policy.jsonl').splitlines()]
    engine = [json.loads(line) for line in read(run / 'kvmat-engine.jsonl').splitlines()]
    assert len(policy) == len(engine) == bench['completed'] == 200 and bench['failed'] == 0
    assert len({p['request_id'] for p in policy}) == 200
    # Policy and engine use different request ID namespaces; bind by propagated salt.
    policy_by_salt = {hashlib.sha256(p['runtime_cache_salt'].encode()).hexdigest(): p['prompt_tokens'] for p in policy}
    engine_by_salt = {e['cache_salt_sha256']: e['prompt_tokens'] for e in engine}
    assert len(policy_by_salt) == len(engine_by_salt) == 200 and policy_by_salt == engine_by_salt
    assert all(p['runtime_effective_decision'] == 'recompute' and p['runtime_target_reuse_tokens'] == 0
               and p['reused_tokens'] == 0 for p in policy)
    assert len({e['cache_salt_sha256'] for e in engine}) == 200
    assert sorted(p['prompt_tokens'] for p in policy) == sorted(bench['input_lens'])
    lengths = [i + o - 1 for i, o in zip(bench['input_lens'], bench['output_lens'], strict=True)]
    assert all(type(x) is int and x > 0 for x in lengths)
    useful_rows = sum(lengths)
    causal_pairs = sum(n * (n + 1) // 2 for n in lengths)
    matrix = json.loads(read(ROOT / 'recovery_model_worker_r1-matrix-accounting.json'))
    for name, expected in matrix['source_sha256'].items():
        read(Path(name))
        assert hashes[name] == expected
    cohort = matrix['cohorts']['inside_request_under_clock_tolerance']
    old_rows = cohort['valid_tokens']['target']
    coefficients = {}
    for name, value in cohort['projection_entries_global']['target'].items():
        coefficient, remainder = divmod(value, old_rows)
        assert remainder == 0
        coefficients[name] = coefficient
    config = json.loads(read(Path('/models/Qwen3.5-35B-A3B/config.json')))['text_config']
    full_layers = config['layer_types'].count('full_attention')
    attention = 4 * config['num_attention_heads'] * config['head_dim'] * full_layers * causal_pairs
    projection = sum(coefficients.values()) * useful_rows
    read(Path(__file__))
    result = dict(status='candidate_nonredundant_target_matrix_demand_not_full_effective_flops',
                  input_tokens=bench['total_input_tokens'], output_tokens=bench['total_output_tokens'],
                  requests=200, candidate_target_rows=useful_rows, observed_target_valid_rows=old_rows,
                  observed_extra_rows=old_rows-useful_rows, candidate_causal_pairs=causal_pairs,
                  target_projection_coefficients_per_row=coefficients,
                  candidate_target_projection_flops=projection, candidate_target_qk_av_flops=attention,
                  candidate_target_matrix_subtotal=projection+attention,
                  effective_flops=None, efficiency_percent=None,
                  convention='For each completed autoregressive request with I input and O output tokens, necessary target positions are I+O-1; the final emitted token is not needed as a next-step input.',
                  limitations=[
                      'A candidate semantic demand, not an accepted new M01 numerator.',
                      'Assumes exact client token extents and ordinary causal continuation; verify against token identity before final adoption.',
                      'No-cache policy and unique request salts support the absence of cross-request APC reuse; policy evidence is not a device cache counter.',
                      'Includes only target projection and causal QK/AV; excludes draft, vocabulary, GDN, convolution, normalization and other arithmetic.',
                      'Observed extra rows are not attributed entirely to rejected draft tokens; no aggregate acceptance-rate scaling.',
                      'No candidate count is divided by another run timing.'
                  ], source_sha256=hashes)
    with Path(__file__).with_name('target-useful-candidate-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status','candidate_target_rows','observed_extra_rows',
        'candidate_causal_pairs','candidate_target_matrix_subtotal','effective_flops')}))


if __name__ == '__main__':
    main()
