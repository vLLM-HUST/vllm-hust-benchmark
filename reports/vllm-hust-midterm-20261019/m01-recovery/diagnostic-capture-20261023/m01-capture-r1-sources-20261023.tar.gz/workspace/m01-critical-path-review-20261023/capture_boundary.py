"""Drain and verify diagnostic worker exports before service shutdown."""
import hashlib
import json
from pathlib import Path

from dual_clock_boundary import DualClockClientBoundary


def verify_exports(response, directory, identity, run_id):
    receipts = response.get('results')
    if not isinstance(receipts, list) or len(receipts) != 2:
        raise ValueError('Exactly two export receipts required')
    snapshots, seen = [], set()
    for receipt in receipts:
        name = receipt.get('file')
        if name not in {f'worker-{pid}.json' for pid, host, device in identity.values()} or name in seen:
            raise ValueError('Missing, foreign or duplicate worker export')
        seen.add(name)
        path = Path(directory) / name
        if path.is_symlink():
            raise ValueError('Worker export must not be a symlink')
        raw = path.read_bytes()
        if len(raw) != receipt.get('bytes') or hashlib.sha256(raw).hexdigest() != receipt.get('sha256'):
            raise ValueError('Worker export content differs from receipt')
        snapshot = json.loads(raw)
        rank = snapshot.get('rank')
        if type(rank) is not int or rank not in identity:
            raise ValueError('Invalid exported rank')
        pid, host, device = identity[rank]
        if (snapshot.get('pid'), snapshot.get('host'), name) != (pid, host, f'worker-{pid}.json'):
            raise ValueError('Export worker differs from boundary worker')
        if snapshot.get('run_id') != run_id:
            raise ValueError('Export run differs from client run')
        if (receipt.get('capture_complete') is not True or snapshot.get('complete') is not True
                or snapshot.get('pending') is not False or snapshot.get('errors') != 0
                or snapshot.get('dropped') != 0):
            raise ValueError('Worker capture incomplete')
        if snapshot.get('measurement_role') != 'diagnostic_qualification':
            raise ValueError('Unexpected capture role')
        snapshots.append(snapshot)
    if {s['rank'] for s in snapshots} != {0, 1}:
        raise ValueError('Missing unique TP2 exports')
    return receipts


class CaptureBoundary(DualClockClientBoundary):
    def __init__(self, post, directory, run_id):
        super().__init__(post)
        self.directory, self.run_id = directory, run_id
        self.export_receipts = None

    async def end(self):
        await super().end()
        self.state = 'exporting'
        response = await self.call('/collective_rpc', dict(
            method='hust_m01_export_wave_capture', args=[], timeout=90))
        self.export_receipts = verify_exports(response, self.directory, self.identity, self.run_id)
        self.state = 'completed'


def diagnostic_record(record, boundary):
    if record.get('protocol') != 'm01-unprofiled-client-synchronized-boundary/v1':
        raise ValueError('Unexpected source boundary protocol')
    if boundary.state != 'completed' or boundary.export_receipts is None:
        raise ValueError('Diagnostic worker exports not verified')
    result = dict(record)
    result.update(protocol='m01-diagnostic-capture-boundary/v1',
                  measurement_role='diagnostic_qualification', run_id=boundary.run_id,
                  instrumentation='host wave, output retention and GDN metadata capture',
                  includes_worker_export_overhead=True,
                  worker_export_receipts=boundary.export_receipts,
                  scheduler_export_verified=False,
                  performance_acceptance=False)
    return result
