import unittest
from audit_task_intervals import interval_union


class IntervalTests(unittest.TestCase):
    def test_overlap_is_counted_once(self):
        result = interval_union([(1, 5), (2, 3), (4, 8)], 0, 10)
        self.assertEqual(result['covered_ns'], 7)
        self.assertEqual(result['uncovered_ns'], 3)
        self.assertEqual(result['largest_uncovered_gap_ns'], 2)

    def test_clips_both_boundaries(self):
        self.assertEqual(interval_union([(-5, 3), (7, 12)], 0, 10)['covered_ns'], 6)

    def test_empty_and_zero_duration(self):
        self.assertEqual(interval_union([], 0, 10)['largest_uncovered_gap_ns'], 10)
        self.assertEqual(interval_union([(3, 3)], 0, 10)['covered_ns'], 0)
        self.assertEqual(interval_union([(3, 3)], 0, 10)['largest_uncovered_gap_ns'], 10)

    def test_rejects_invalid_inputs(self):
        for rows, lo, hi in [([(3, 2)], 0, 10), ([(5, 6), (2, 3)], 0, 10), ([], 1, 1)]:
            with self.assertRaises(ValueError):
                interval_union(rows, lo, hi)


if __name__ == '__main__':
    unittest.main()
