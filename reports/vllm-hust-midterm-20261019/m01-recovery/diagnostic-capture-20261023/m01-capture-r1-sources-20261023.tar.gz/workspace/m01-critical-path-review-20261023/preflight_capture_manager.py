"""Exercise real Manager checks and its actual child, without model loading."""
import os
from pathlib import Path
import sys
import tempfile

from launch_boundary_b1 import prepare_command


def main():
    here = Path(__file__).resolve().parent
    receipt = here / 'wave-manager-preflight-r1.json'
    if receipt.exists():
        raise FileExistsError('Preflight receipt already exists')
    with tempfile.TemporaryDirectory(prefix='m01-manager-preflight-', dir='/workspace') as temporary:
        out = Path(temporary)
        command, env, original = prepare_command(out, out / 'cache')
        if command[-2:] != ['--worker-extension-cls', 'synchronized_boundary.WorkerBoundary']:
            raise ValueError('Unexpected original boundary extension')
        args = command[3:-2]
        if args[0] != 'serve':
            raise ValueError('Unexpected service entrypoint')
        env.update(HUST_M01_WAVE_CAPTURE='1', HUST_M01_CAPTURE_RUN_ID='manager-preflight',
                   HUST_M01_CAPTURE_DIR=temporary, HUST_M01_CAPTURE_MAX_EVENTS='32',
                   HUST_M01_CAPTURE_MAX_REQUESTS='8')
        env['PYTHONPATH'] = str(here / 'wave-plugin-installed-r1') + os.pathsep + os.environ['PYTHONPATH']
        os.environ.update(env)
        from vllm_hust_ext.cli import main as manager_main
        return manager_main(['run', '--', sys.executable, str(here / 'capture_service_entry.py'),
                             '--preflight-receipt', str(receipt), *args])


if __name__ == '__main__':
    raise SystemExit(main())
