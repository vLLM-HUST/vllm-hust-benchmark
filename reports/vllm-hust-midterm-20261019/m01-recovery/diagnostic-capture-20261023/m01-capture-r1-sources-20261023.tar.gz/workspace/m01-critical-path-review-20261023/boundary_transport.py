"""Narrow loopback-only transport for an externally admitted M01 service."""
import json


class BoundaryTransport:
    def __init__(self, port, timeout_seconds=120):
        if type(port) is not int or not 1024 <= port <= 65535:
            raise ValueError('Explicit nonprivileged loopback port required')
        self.base_url = f'http://127.0.0.1:{port}'
        self.timeout_seconds = timeout_seconds

    async def __call__(self, path, payload):
        if path in ('/pause?mode=wait&clear_cache=false', '/resume'):
            if payload is not None:
                raise ValueError('Unexpected control payload')
        elif path == '/collective_rpc':
            if payload not in [dict(method='hust_m01_sync_boundary', args=[phase], timeout=90)
                               for phase in ('begin', 'end')]:
                raise ValueError('Unapproved collective RPC')
        else:
            raise ValueError('Unapproved control endpoint')
        import aiohttp
        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout, trust_env=False) as session:
            async with session.post(self.base_url + path, json=payload, allow_redirects=False) as response:
                if response.status != 200:
                    raise RuntimeError(f'Boundary endpoint returned HTTP {response.status}')
                chunks = bytearray()
                async for block in response.content.iter_chunked(4096):
                    chunks.extend(block)
                    if len(chunks) > 65536:
                        raise ValueError('Oversized boundary response')
                result = json.loads(chunks)
                if not isinstance(result, dict):
                    raise ValueError('Boundary response must be an object')
                return result
