"""Reconcile aggregate speculative work, without inventing per-request joins."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def partition(records):
    totals = dict(prefill_rows=0, active_verify_rows=0, terminal_verify_rows=0,
                  initial_prefill_sequences=0, continuing_prefill_sequences=0,
                  active_verify_sequences=0, terminal_verify_sequences=0)
    for record in records:
        fields, metadata = record['device_fields'], record['metadata']
        cu = [x[0] for x in fields['cu']]
        pre, verify = metadata['prefill_ids'], metadata['verify_ids']
        if set(pre) & set(verify) or set(pre) | set(verify) != set(range(metadata['live'])):
            raise ValueError('Rows not partitioned exactly')
        for index in pre:
            totals['prefill_rows'] += cu[index + 1] - cu[index]
            totals['continuing_prefill_sequences' if fields['initial'][index][0] else 'initial_prefill_sequences'] += 1
        for index, slots in zip(verify, fields['verify_slots'], strict=True):
            terminal = slots == [-1, -1, -1]
            if not terminal and (len(slots) != 3 or slots[0] < 0 or slots != list(range(slots[0], slots[0] + 3))):
                raise ValueError('Invalid candidate slots')
            extent = cu[index + 1] - cu[index]
            if extent != 3:
                raise ValueError('Unexpected verification width')
            key = 'terminal' if terminal else 'active'
            totals[key + '_verify_rows'] += extent
            totals[key + '_verify_sequences'] += 1
    return totals


def main():
    hashes = {}
    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw
    run = ROOT / 'm01-recovery-model-worker-r1'
    receipt = json.loads(read(run / 'receipt.json'))
    for name in ('state_slots.py', 'state_commit.py', 'state_address.py'):
        path = ROOT / 'recovery-model-payload-r1/betterscale/models/qwen35' / name
        read(path)
        assert hashes[str(path)] == receipt['input_hashes'][str(path.relative_to(ROOT))]
    partitions = [partition(json.loads(read(p))['records']) for p in sorted(run.glob('gdn-publication-*.json'))]
    assert len(partitions) == 2 and partitions[0] == partitions[1]
    p = partitions[0]
    bench = json.loads(read(run / 'mmlu-pro.json'))
    candidate = json.loads(read(Path(__file__).with_name('target-useful-candidate-r1.json')))
    feedback = json.loads(read(Path(__file__).with_name('acceptance-feedback-audit-r1.json')))
    assert p['initial_prefill_sequences'] == bench['completed'] == 200
    assert p['prefill_rows'] == bench['total_input_tokens']
    assert p['active_verify_sequences'] == bench['spec_decode_num_drafts']
    rejected = bench['spec_decode_draft_tokens'] - bench['spec_decode_accepted_tokens']
    implied_excess = p['initial_prefill_sequences'] + p['active_verify_sequences'] + bench['spec_decode_accepted_tokens'] - bench['total_output_tokens']
    assert implied_excess >= 0
    observed = p['prefill_rows'] + p['active_verify_rows'] + p['terminal_verify_rows']
    assert observed == candidate['observed_target_valid_rows']
    assert observed - candidate['candidate_target_rows'] == rejected + p['terminal_verify_rows'] + implied_excess
    assert implied_excess == feedback['client_minus_feedback_count']
    read(Path(__file__))
    result = dict(status='aggregate_identity_closed_per_request_epoch_mapping_pending', partition=p,
        observed_target_rows=observed, candidate_useful_target_rows=candidate['candidate_target_rows'],
        rejected_draft_tokens=rejected, implied_output_boundary_excess=implied_excess,
        aggregate_identity='339916 - 333265 = 6097 + 348 + 206',
        feedback_difference_matches_implied_excess=True,
        effective_flops=None, efficiency_percent=None,
        interpretation='State commit code clips accepted output by remaining budget; device slot publication marks terminal queued frames. Aggregates agree with these mechanisms, but no per-request final-acceptance assignment is asserted.',
        remaining=['Join feedback to the correct previous verification and resident request lifetime.',
                   'Separate useful draft processing from rejected speculative work using the verified mapping.',
                   'Complete non-matrix work and independent reference applicability.'], source_sha256=hashes)
    with Path(__file__).with_name('acceptance-aggregate-reconciliation-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status','partition','aggregate_identity','effective_flops')}))


if __name__ == '__main__':
    main()
