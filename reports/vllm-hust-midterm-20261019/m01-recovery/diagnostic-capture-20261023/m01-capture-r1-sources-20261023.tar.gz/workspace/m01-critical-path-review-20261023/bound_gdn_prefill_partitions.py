"""Conditional partition bounds, not a reconstruction of the current schedule."""
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from audit_gdn_ho_accounting import operations
from audit_gdn_wy_accounting import arithmetic
from gdn_inverse_accounting import inverse_arithmetic


@lru_cache(None)
def cost(n, state):
    return sum(value for part in (operations(n, state), arithmetic(n), inverse_arithmetic(n))
               for key, value in part.items()
               if not key.endswith(('exp_evaluations', 'clamp_comparisons')))


def bounds(lengths):
    if not lengths or any(type(n) is not int or n <= 0 for n in lengths):
        raise ValueError('Positive integer sequence lengths required')
    size = max(lengths)
    # Stateful suffix tables cover every ordered composition into lengths 1..64.
    low, high = [0] * (size + 1), [0] * (size + 1)
    for n in range(1, size + 1):
        low[n] = min(cost(c, True) + low[n-c] for c in range(1, min(n, 64)+1))
        high[n] = max(cost(c, True) + high[n-c] for c in range(1, min(n, 64)+1))
    per_request = []
    for n in lengths:
        choices = range(1, min(n, 64)+1)
        per_request.append(dict(length=n,
            minimum=min(cost(c, False)+low[n-c] for c in choices),
            maximum=max(cost(c, False)+high[n-c] for c in choices)))
    return per_request


def main():
    bench_path = Path('/workspace/m01-boundary-b1-r1/mmlu-pro.json')
    bench = json.loads(bench_path.read_text())
    rows = bounds(bench['input_lens'])
    factor = 30 * 32
    low = sum(r['minimum'] for r in rows) * factor
    high = sum(r['maximum'] for r in rows) * factor
    paths = [bench_path, Path(__file__)] + [ROOT / name for name in
        ('audit_gdn_ho_accounting.py', 'audit_gdn_wy_accounting.py', 'gdn_inverse_accounting.py')]
    result = dict(status='conditional_partition_bounds_not_observed_prefill_flops',
        input_tokens=sum(bench['input_lens']), requests=len(rows),
        global_heads=32, linear_layers=30, minimum_basic_flops=low,
        maximum_basic_flops=high, interval_width=high-low,
        per_request_single_head_layer=rows,
        conditions=[
            'Each prompt token processed once, with no initial cached state at the first chunk.',
            'Every chunk has length 1..64 and follows the imported H/O, WY and inverse convention.',
            'Later chunks consume the preceding state; no repeated or omitted prompt work.',
            'All compositions are allowed, a superset of scheduler-feasible partitions.',
        ],
        limitations=[
            'No current-run per-request chunk/state log is available in microflow events.',
            'These bounds do not identify the actual partition or validate every listed operation as useful.',
            'No old-run chunk multiplicity is reused; no midpoint is substituted for missing observations.',
            'Reference timing, retained draft work and runtime applicability remain separate.',
        ],
        effective_flops=None, efficiency_percent=None,
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (HERE / 'boundary-gdn-prefill-partition-bounds-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'minimum_basic_flops', 'maximum_basic_flops', 'interval_width')}))


if __name__ == '__main__':
    main()
