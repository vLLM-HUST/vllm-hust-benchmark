import hashlib
import json

import pytest

from capture_export import export_snapshot


def test_exact_bytes_and_no_attainment(tmp_path):
    snapshot = dict(complete=True, events=[{'wave': 1}], effective_flops=None)
    receipt = export_snapshot(tmp_path, 'worker-0.json', snapshot)
    raw = (tmp_path / receipt['file']).read_bytes()
    assert json.loads(raw) == snapshot
    assert hashlib.sha256(raw).hexdigest() == receipt['sha256']
    assert receipt['m01_attainment'] is None
    assert not list(tmp_path.glob('*.partial-*'))


def test_existing_evidence_never_overwritten(tmp_path):
    path = tmp_path / 'worker-0.json'
    path.write_bytes(b'original evidence')
    with pytest.raises(FileExistsError):
        export_snapshot(tmp_path, path.name, dict(complete=True))
    assert path.read_bytes() == b'original evidence'
    assert len(list(tmp_path.glob('*.partial-*'))) == 1


def test_invalid_capture_is_still_saved_as_evidence(tmp_path):
    receipt = export_snapshot(tmp_path, 'failed-worker.json',
                              dict(complete=False, errors=1, events=[]))
    assert not receipt['capture_complete']
    assert (tmp_path / receipt['file']).exists()


@pytest.mark.parametrize('name,snapshot', [('../outside.json', {'complete': True}),
    ('worker.json', {}), ('worker.json', {'complete': True, 'effective_flops': 123}),
    ('worker.json', {'complete': True, 'value': float('nan')})])
def test_bad_export_rejected_before_writing(tmp_path, name, snapshot):
    with pytest.raises(ValueError):
        export_snapshot(tmp_path, name, snapshot)
    assert not list(tmp_path.iterdir())
