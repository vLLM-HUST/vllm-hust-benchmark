"""Recover deferred device acceptance feedback, without mislabeling its epoch."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def summarize(records):
    accepted, verify = Counter(), Counter()
    for row in records:
        fields, meta = row['device_fields'], row['metadata']
        values = [x[0] for x in fields['accepted']]
        verified = [x[0] for x in fields['verify_accepted']]
        if len(values) != meta['live'] or len(verified) != meta['verify_count']:
            raise ValueError('Acceptance extent mismatch')
        if any(type(x) is not int or x not in (1, 2, 3) for x in values + verified):
            raise ValueError('Unexpected MTP feedback')
        if [values[i] for i in meta['verify_ids']] != verified:
            raise ValueError('Verification feedback disagrees with live-row selection')
        accepted.update(values)
        verify.update(verified)
    return dict(records=len(records), live_rows=sum(accepted.values()),
                accepted_histogram=dict(sorted(accepted.items())),
                verify_accepted_histogram=dict(sorted(verify.items())),
                feedback_minus_mandatory_one=sum((k-1)*v for k,v in accepted.items()))


def main():
    hashes, documents, counts = {}, [], []
    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw
    for path in sorted((ROOT / 'm01-recovery-model-worker-r1').glob('gdn-publication-*.json')):
        document = json.loads(read(path))
        assert not document['errors']
        source = document['publication_source']
        read(Path(source['path']))
        assert hashes[source['path']] == source['sha256']
        counts.append(summarize(document['records']))
        documents.append(document)
    assert len(documents) == 2 and counts[0] == counts[1]
    assert counts[0]['records'] == 884
    for left, right in zip(documents[0]['records'], documents[1]['records'], strict=True):
        for name in ('accepted', 'verify_accepted', 'verify_slots', 'cu'):
            assert left['device_fields'][name] == right['device_fields'][name], name
    bench = json.loads(read(ROOT / 'm01-recovery-model-worker-r1/mmlu-pro.json'))
    read(Path(__file__))
    result = dict(status='paired_device_acceptance_feedback_recovered_epoch_mapping_pending',
                  per_rank=counts, client_accepted_draft_tokens=bench['spec_decode_accepted_tokens'],
                  client_minus_feedback_count=bench['spec_decode_accepted_tokens']-counts[0]['feedback_minus_mandatory_one'],
                  effective_flops=None,
                  limitations=[
                      'Acceptance feedback is consumed for state restoration and is not the outcome of the current forward.',
                      'Request remapping, initial rows and final completed requests must be accounted for before joining feedback to draft work.',
                      'Feedback and client aggregate differ; no ratio correction or silent reconciliation is applied.',
                      'Both rank traces agree; agreement does not alone prove semantic mapping.'
                  ], source_sha256=hashes)
    with Path(__file__).with_name('acceptance-feedback-audit-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','per_rank','client_minus_feedback_count')}))


if __name__ == '__main__':
    main()
