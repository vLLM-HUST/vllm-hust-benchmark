"""Architecture-derived semantic matrix demand; not total effective work."""
import hashlib
import json
from pathlib import Path


def coefficients(c):
    h, layers = c['hidden_size'], c['num_hidden_layers']
    full = c['layer_types'].count('full_attention')
    linear = c['layer_types'].count('linear_attention')
    if full + linear != layers or c['attention_bias'] or not c['attn_output_gate']:
        raise ValueError('Unsupported architecture')
    q = c['num_attention_heads'] * c['head_dim']
    kv = c['num_key_value_heads'] * c['head_dim']
    lk = c['linear_num_key_heads'] * c['linear_key_head_dim']
    lv = c['linear_num_value_heads'] * c['linear_value_head_dim']
    shared = c['shared_expert_intermediate_size']
    return {
        '.self_attn.qkv_proj': 2*h*(2*q+2*kv)*full,
        '.self_attn.o_proj': 2*q*h*full,
        '.shared_expert.gate_up_proj': 2*h*(2*shared)*layers,
        '.shared_expert.down_proj': 2*shared*h*layers,
        '.mlp.gate': 2*h*c['num_experts']*layers,
        '.mlp.shared_expert_gate': 2*h*layers,
        '.linear_attn.in_proj_qkvz': 2*h*(2*lk+2*lv)*linear,
        '.linear_attn.in_proj_ba': 2*h*(2*c['linear_num_value_heads'])*linear,
        '.linear_attn.out_proj': 2*lv*h*linear,
        'routed_expert_projection': 6*h*c['moe_intermediate_size']*c['num_experts_per_tok']*layers,
    }


def main():
    here = Path(__file__).resolve().parent
    paths = [Path('/models/Qwen3.5-35B-A3B/config.json'), here / 'boundary-workload-join-r1.json',
             here / 'target-useful-candidate-r1.json', Path('/workspace/m01-boundary-b1-r1/mmlu-pro.json')]
    c, join, previous, bench = [json.loads(p.read_text()) for p in paths]
    c = c['text_config']
    coeff = coefficients(c)
    assert coeff == previous['target_projection_coefficients_per_row']
    projection = sum(coeff.values()) * join['candidate_target_positions']
    attention = 4*c['num_attention_heads']*c['head_dim']*c['layer_types'].count('full_attention')*join['candidate_causal_pairs']
    vocabulary = 2*c['hidden_size']*c['vocab_size']*bench['total_output_tokens']
    paths.append(Path(__file__))
    result = dict(status='architecture_checked_target_matrix_semantic_demand_only',
        coefficients_per_position=coeff, coefficients_match_previous_loaded_shape_derivation=True,
        target_projection_flops=projection, causal_qk_av_flops=attention,
        target_output_vocabulary_flops=vocabulary, partial_target_matrix_flops=projection+attention+vocabulary,
        effective_flops=None, reference_seconds=None, efficiency_percent=None,
        scope='Global TP2 demand counted once; 2MNK, activated experts only, no padding or rejected draft work.',
        assumptions=['Necessary target positions I+O-1; causal attention evaluated over those semantic positions.',
                     'One necessary target vocabulary projection per emitted output token.',
                     'Configured architecture matches executed dense and routed matrix structure; no weight sparsity or altered expert count.'],
        missing=['GDN and convolution arithmetic, norms and scalar operations must be reconciled separately.',
                 'Retained draft context work is not included.',
                 'This semantic demand is not a physical execution schedule or full F; no timing division.'],
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (here / 'boundary-matrix-demand-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','target_projection_flops','causal_qk_av_flops',
                                         'target_output_vocabulary_flops','partial_target_matrix_flops')}))


if __name__ == '__main__':
    main()
