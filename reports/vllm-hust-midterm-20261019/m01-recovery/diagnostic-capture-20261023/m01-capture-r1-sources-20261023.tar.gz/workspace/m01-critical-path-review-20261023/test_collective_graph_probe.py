import unittest
from collective_graph_probe import captured_calls, memory_bytes, timed_replay


class ProbeTests(unittest.TestCase):
    def test_memory(self):
        self.assertEqual(memory_bytes(dict(kind='all_gather', input_bytes_per_call=17879040), 32), 1716387840)
        with self.assertRaises(ValueError):
            memory_bytes(dict(kind='all_reduce', input_bytes_per_call=2), 4)

    def test_capture_has_only_collectives(self):
        calls = []
        class Dist:
            def all_reduce(self, x): calls.append(x)
        captured_calls(Dist(), 'all_reduce', [1, 2, 3], [])
        self.assertEqual(calls, [1, 2, 3])

    def test_timing_order(self):
        events = []
        class Event:
            def record(self): events.append('event')
            def synchronize(self): events.append('event_sync')
            def elapsed_time(self, other): return .5
        class Npu:
            def synchronize(self): events.append('sync')
            def Event(self, **kwargs): return Event()
        class Graph:
            def replay(self): events.append('replay')
        times = iter([1., 1.001])
        result = timed_replay(Npu(), Graph(), lambda: events.append('prepare'),
                              lambda: events.append('validate'), lambda: events.append('barrier'), lambda: next(times))
        self.assertEqual(events, ['prepare', 'sync', 'barrier', 'sync', 'event', 'replay', 'event', 'event_sync', 'sync', 'validate'])
        self.assertAlmostEqual(result['synchronized_wall_seconds'], .001)

    def test_validation_failure_not_success(self):
        class Event:
            def record(self): pass
            def synchronize(self): pass
            def elapsed_time(self, other): return 1.
        class Npu:
            def synchronize(self): pass
            def Event(self, **kwargs): return Event()
        class Graph:
            def replay(self): pass
        def fail(): raise ValueError('bad output')
        times = iter([1., 2.])
        with self.assertRaises(ValueError):
            timed_replay(Npu(), Graph(), lambda: None, fail, lambda: None, lambda: next(times))


if __name__ == '__main__':
    unittest.main()
