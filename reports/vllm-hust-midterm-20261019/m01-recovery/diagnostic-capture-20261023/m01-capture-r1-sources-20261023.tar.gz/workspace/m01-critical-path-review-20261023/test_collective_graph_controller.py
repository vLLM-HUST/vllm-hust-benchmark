import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import run_collective_graph as controller


class AdmissionTests(unittest.TestCase):
    def test_missing_experiment(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(controller, 'ROOT', Path(directory)):
            with self.assertRaises(RuntimeError):
                controller.completed_dependencies()

    def test_active_or_unreleased_rejected(self):
        for field, value in [('status', 'solver'), ('sessions_drained', False), ('all_devices_released', False)]:
            with tempfile.TemporaryDirectory() as directory, patch.object(controller, 'ROOT', Path(directory)):
                data = dict(status='completed', sessions_drained=True, all_devices_released=True)
                data[field] = value
                path = Path(directory) / 'frontierscience-native018-solver-r1'
                path.mkdir()
                (path / 'receipt.json').write_text(json.dumps(data))
                (path / 'SHA256SUMS').touch()
                with self.assertRaises(RuntimeError):
                    controller.completed_dependencies()

    def test_both_completed(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(controller, 'ROOT', Path(directory)):
            for name in ('frontierscience-native018-solver-r1', 'frontierscience-native018-judge-r1'):
                path = Path(directory) / name
                path.mkdir()
                (path / 'receipt.json').write_text(json.dumps(dict(status='completed', sessions_drained=True, all_devices_released=True)))
                (path / 'SHA256SUMS').touch()
            controller.completed_dependencies()


if __name__ == '__main__':
    unittest.main()
