"""CPU-only terminal accounting helper for a future pinned scheduler hook."""


def classify(*, draft_count, sampled_per_step, raw_count, kept_count,
             before_count, after_count, is_stale):
    values = (draft_count, sampled_per_step, raw_count, kept_count, before_count, after_count)
    if any(type(v) is not int or v < 0 for v in values):
        raise ValueError('Nonnegative integer host counts required')
    if type(is_stale) is not bool:
        raise ValueError('Explicit stale-output state required')
    if kept_count > raw_count or after_count < before_count:
        raise ValueError('Inconsistent output trimming')
    result = dict(draft_count=draft_count, raw_count=raw_count, kept_count=kept_count,
                  appended_count=after_count-before_count, is_stale=is_stale,
                  raw_accepted_drafts=None, retained_drafts=None,
                  retained_first_draft=None, retained_second_draft=None)
    if is_stale:
        return dict(result, status='stale_output_not_classified')
    if sampled_per_step != 1 or draft_count not in (0, 1, 2):
        return dict(result, status='unsupported_sampling_contract')
    if after_count-before_count != kept_count:
        return dict(result, status='append_and_return_count_mismatch')
    if raw_count == 0:
        return dict(result, status='empty_output_not_verification')
    if raw_count > draft_count + 1:
        raise ValueError('Raw output exceeds scheduled drafts plus bonus')
    accepted = raw_count - 1 if draft_count else 0
    retained = min(accepted, kept_count)
    result.update(raw_accepted_drafts=accepted, retained_drafts=retained,
                  retained_first_draft=int(retained >= 1),
                  retained_second_draft=int(retained >= 2))
    return dict(result, status='accepted_prefix_then_bonus_host_counts')


def observe_update(update, request, tokens, *, draft_count, sampled_per_step, is_stale=False):
    """Invoke native trimming once; return original result plus a separate observation.

    This helper is not installed by importing it. Callers must bind the exact pinned
    schedule/frame and handle observation errors without changing native behavior.
    """
    raw_count = len(tokens)
    before_count = len(request._output_token_ids)
    result = update(request, tokens, is_stale=is_stale)
    kept, _ = result
    try:
        observation = classify(draft_count=draft_count, sampled_per_step=sampled_per_step,
            raw_count=raw_count, kept_count=len(kept), before_count=before_count,
            after_count=len(request._output_token_ids), is_stale=is_stale)
    except (ValueError, TypeError, AttributeError):
        observation = dict(status='observation_invalid', retained_drafts=None)
    return result, observation
