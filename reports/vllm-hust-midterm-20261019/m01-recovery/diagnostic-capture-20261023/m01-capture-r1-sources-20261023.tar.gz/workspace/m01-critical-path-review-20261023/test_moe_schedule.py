import unittest
from audit_moe_schedule import configured_overlap, default_bool


class ScheduleTests(unittest.TestCase):
    def test_default_serial(self):
        self.assertEqual(configured_overlap(['--additional-config', '{}'],
            'class Config:\n    multistream_overlap_shared_expert: bool = False'),
            dict(donor_multistream=False, betterscale_shared_overlap_patch=False))

    def test_explicit_overlap(self):
        self.assertTrue(configured_overlap(['--additional-config',
            '{"multistream_overlap_shared_expert": true, "betterscale_shared_expert_overlap": true}'],
            'multistream_overlap_shared_expert: bool = False')['donor_multistream'])

    def test_invalid_combination(self):
        with self.assertRaises(ValueError):
            configured_overlap(['--additional-config', '{"betterscale_shared_expert_overlap": true}'],
                'multistream_overlap_shared_expert: bool = False')

    def test_missing_default_rejected(self):
        with self.assertRaises(ValueError):
            default_bool('different: bool = False', 'multistream_overlap_shared_expert')


if __name__ == '__main__':
    unittest.main()
