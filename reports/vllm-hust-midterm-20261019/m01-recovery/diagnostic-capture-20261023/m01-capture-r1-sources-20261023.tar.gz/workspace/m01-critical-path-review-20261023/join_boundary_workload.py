"""Match semantic extents, not execution traces or full effective FLOPs."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def retained_bounds(requests, outputs, rounds, accepted, drafts):
    values = (requests, outputs, rounds, accepted, drafts)
    if any(type(x) is not int or x < 0 for x in values) or requests == 0:
        raise ValueError('Nonnegative integer counts and positive requests required')
    if drafts != 2 * rounds or accepted > drafts:
        raise ValueError('Not the frozen two-draft protocol')
    excess = requests + rounds + accepted - outputs
    if not 0 <= excess <= 2 * requests:
        raise ValueError('Terminal clipping alone cannot explain counts')
    # A clipped final prefix loses its one correction/bonus token first.
    clipped_min = (excess + 1) // 2
    clipped_max = min(excess, requests)
    low, high = accepted - excess + clipped_min, accepted - excess + clipped_max
    if not 0 <= low <= high <= min(accepted, outputs):
        raise ValueError('Impossible retained count')
    return dict(implied_terminal_excess=excess, clipped_requests_min=clipped_min,
                clipped_requests_max=clipped_max, retained_draft_min=low,
                retained_draft_max=high)


def main():
    paths = [ROOT / 'm01-recovery-model-worker-r1/mmlu-pro.json',
             Path('/workspace/m01-boundary-b1-r1/mmlu-pro.json'),
             Path('/workspace/m01-boundary-b1-r1/execution-plan.json'),
             HERE / 'boundary-b1-audit-r1.json', HERE / 'target-useful-candidate-r1.json',
             Path(__file__)]
    old, new, plan, audit, target = [json.loads(p.read_text()) for p in paths[:-1]]
    benchmark = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/benchmarks/serve.py')
    if hashlib.sha256(benchmark.read_bytes()).hexdigest() != plan['benchmark_sha256']:
        raise ValueError('Benchmark metric source changed')
    paths.append(benchmark)
    assert audit['status'] == 'sealed_synchronized_B1_measurement_audited'
    assert old['input_lens'] == new['input_lens']
    assert old['output_lens'] == new['output_lens'] == [256] * 200
    assert new['completed'] == 200 and new['failed'] == 0
    lengths = [i + o - 1 for i, o in zip(new['input_lens'], new['output_lens'], strict=True)]
    assert sum(lengths) == target['candidate_target_rows']
    pairs = sum(n * (n + 1) // 2 for n in lengths)
    assert pairs == target['candidate_causal_pairs']
    bounds = retained_bounds(new['completed'], new['total_output_tokens'],
        new['spec_decode_num_drafts'], new['spec_decode_accepted_tokens'], new['spec_decode_draft_tokens'])
    positions = [round(r * new['spec_decode_num_drafts'])
                 for r in new['spec_decode_per_position_acceptance_rates']]
    assert sum(positions) == new['spec_decode_accepted_tokens']
    result = dict(status='semantic_extent_match_with_conditional_current_run_draft_bounds',
        requests=200, ordered_input_lengths_equal=True, ordered_output_lengths_equal=True,
        identical_output_texts=sum(a == b for a, b in zip(old['generated_texts'], new['generated_texts'], strict=True)),
        candidate_target_positions=sum(lengths), candidate_causal_pairs=pairs,
        current_raw_accepted=new['spec_decode_accepted_tokens'], current_raw_accepted_per_position=positions,
        current_draft_bounds=bounds, old_raw_accepted=old['spec_decode_accepted_tokens'],
        old_draft_count_reused=False, old_execution_shape_counts_reused=False,
        effective_flops=None, reference_seconds=None, efficiency_percent=None,
        assumptions=[
            'Each request emits one initial target token, then two-draft verification rounds emit an accepted prefix and one correction/bonus token.',
            'Benchmark before/after counters cover the same 200 completed requests.',
            'Only final output-budget clipping removes outputs; no stop-string removal or unrecorded retry.',
            'Semantic target extent I+O-1 is a candidate needed-position convention, not measured execution work.'],
        limitations=[
            'Length equality does not establish equal generated tokens, routing or physical schedules.',
            'Draft bounds are aggregate conditional bounds, not per-request terminal reconstruction.',
            'No inherited full F, timing division or M01 attainment is performed.',
            'Actual model coefficients, retained draft context work and dependency reference applicability still require mapping.'],
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (HERE / 'boundary-workload-join-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'identical_output_texts', 'candidate_target_positions',
        'candidate_causal_pairs', 'current_draft_bounds')}))


if __name__ == '__main__':
    main()
