import pytest

from capture_service_entry import BUNDLES, compose_environment


def environment():
    return dict(HUST_M01_WAVE_CAPTURE='1', HUST_MICROFLOW_SCHOOL028_FA='1',
                VLLMHUST_EXT_ENABLED_BUNDLES=','.join(sorted(BUNDLES)),
                VLLM_PLUGINS='ascend,kv_materialization,hust_microflow_school028_fa',
                unrelated='preserved')


def test_only_diagnostic_entry_changes():
    env = environment()
    result = compose_environment(env)
    assert result.pop('VLLM_PLUGINS') == 'ascend,kv_materialization,hust_m01_wave_capture'
    env.pop('VLLM_PLUGINS')
    assert result == env


@pytest.mark.parametrize('key,value', [('HUST_M01_WAVE_CAPTURE', '0'),
    ('HUST_MICROFLOW_SCHOOL028_FA', '0'), ('VLLMHUST_EXT_ENABLED_BUNDLES', ''),
    ('VLLM_PLUGINS', 'hust_microflow_school028_fa,hust_m01_wave_capture'),
    ('VLLM_PLUGINS', 'hust_microflow_school028_fa,hust_microflow_school028_fa')])
def test_missing_activation_or_ambiguous_composition_fails(key, value):
    env = environment()
    env[key] = value
    with pytest.raises(ValueError):
        compose_environment(env)
