"""Audit existing aggregate MTP counters without reclassifying raw FLOPs."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
OUTLINE = Path('/root/gennova-evidence/20261023-outline-v525/vLLM-HUST-midterm-V5.25.docx')
OUTLINE_SHA = '4c9b16a3551ec7e1d9d27e230be5ef1f4c61c3d4540065fa29e3dca87e1b0a5f'
RUNS = ['m01-recovery-model-worker-r1'] + [f'mmlu-b1-microflow-fa-on-r{i}' for i in (9, 10, 11)]


def counters(data):
    proposed = data['spec_decode_draft_tokens']
    accepted = data['spec_decode_accepted_tokens']
    rounds = data['spec_decode_num_drafts']
    if any(type(v) is not int or v < 0 for v in (proposed, accepted, rounds)):
        raise ValueError('Expected nonnegative integer counters')
    if accepted > proposed or proposed != 2 * rounds or proposed == 0:
        raise ValueError('Inconsistent two-token MTP counters')
    if abs(data['spec_decode_acceptance_rate'] - accepted / proposed * 100) > 1e-7:
        raise ValueError('Acceptance percentage disagrees with counters')
    return dict(proposed=proposed, accepted=accepted, rejected=proposed-accepted)


def build():
    hashes = {}

    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw

    read(OUTLINE)
    assert hashes[str(OUTLINE)] == OUTLINE_SHA
    runs = {}
    for name in RUNS:
        data = json.loads(read(ROOT / name / 'mmlu-pro.json'))
        assert (data['completed'], data['failed']) == (200, 0)
        runs[name] = {'counters': counters(data), 'client_duration_s': data['duration'],
                      'input_tokens': data['total_input_tokens'],
                      'output_tokens': data['total_output_tokens']}
    matrix = json.loads(read(ROOT / 'recovery_model_worker_r1-matrix-accounting.json'))
    cohort = matrix['cohorts']['inside_request_under_clock_tolerance']
    read(Path(__file__))
    return {
        'status': 'aggregate_mtp_counters_validated_useful_flop_mapping_pending',
        'method': 'V5.25', 'participating_chips': 2, 'runs': runs,
        'old_matrix_valid_rows': cohort['valid_tokens'],
        'old_draft_projection_flops': sum(cohort['projection_entries_global']['draft'].values()),
        'effective_flops': None, 'reference_time_s': None, 'efficiency_percent': None,
        'findings': [
            'Valid tensor rows are not equivalent to accepted speculative output tokens.',
            'Draft step zero includes processing of target hidden-state rows, not only proposed output positions.',
            'Aggregate acceptance cannot be used to scale all target/draft/attention FLOPs uniformly.',
            'Counters are preserved per run; no instrumented FLOPs are spliced into another run timing.',
            'Timing values are client measurements; synchronized M01 boundary applicability remains to be established.',
        ],
        'next_required_mapping': [
            'Separate necessary draft state preparation from rejected speculative work and duplicate target verification.',
            'Map accepted positions and context lengths where they affect useful attention work; quantify uncertainty if only aggregates exist.',
            'Bind useful workload and independent dependency-aware reference to the applicable uninstrumented timing.',
        ],
        'source_sha256': hashes,
    }


if __name__ == '__main__':
    result = build()
    path = Path(__file__).with_name('useful-draft-counts-r1.json')
    with path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'runs': result['runs']}))
