"""Opt-in host output ledger mixin; not an installed runtime plugin."""
import time
from copy import deepcopy

from retained_output_observation import observe_update
from worker_wave_identity import request_key


class SchedulerOutputLedger:
    def enable_output_ledger(self, *, max_events, max_requests):
        if hasattr(self, '_output_ledger'):
            raise ValueError('Ledger already enabled')
        if any(type(n) is not int or n <= 0 for n in (max_events, max_requests)):
            raise ValueError('Explicit positive buffer limits required')
        self._output_ledger = dict(events=[], identities={}, stack=[], next_frame=0,
                                   max_events=max_events, max_requests=max_requests,
                                   dropped=0, errors=0)

    def _ledger_emit(self, event, **fields):
        ledger = self._output_ledger
        if len(ledger['events']) >= ledger['max_events']:
            ledger['dropped'] += 1
            return
        ledger['events'].append(dict(event=event, perf_ns=time.perf_counter_ns(), **fields))

    def _ledger_request(self, request_id):
        ledger = self._output_ledger
        identities = ledger['identities']
        if request_id not in identities:
            if len(identities) >= ledger['max_requests']:
                raise ValueError('Request identity capacity exceeded')
            identities[request_id] = len(identities)
        return identities[request_id]

    def output_ledger_snapshot(self):
        ledger = self._output_ledger
        complete = not (ledger['dropped'] or ledger['errors'] or ledger['stack'])
        unclassified = sum(row['event'] == 'not_updated' for row in ledger['events'])
        return dict(protocol='m01-host-output-ledger/v1',
                    events=deepcopy(ledger['events']),
                    dropped=ledger['dropped'], errors=ledger['errors'],
                    open_frames=len(ledger['stack']),
                    complete=complete, unclassified_requests=unclassified,
                    retained_count_complete=complete and not unclassified,
                    effective_flops=None,
                    scope='CPU output delivery frames; not worker execution waves or GDN state')

    def update_from_output(self, scheduler_output, model_runner_output):
        if not hasattr(self, '_output_ledger'):
            return super().update_from_output(scheduler_output, model_runner_output)
        ledger = self._output_ledger
        frame = None
        try:
            index = ledger['next_frame']
            ledger['next_frame'] += 1
            rows = {rid: dict(request=self._ledger_request(rid), scheduled_tokens=count,
                             drafts=len(scheduler_output.scheduled_spec_decode_tokens.get(rid, ())))
                    for rid, count in scheduler_output.num_scheduled_tokens.items()}
            if hasattr(self, '_wave_run_id'):
                for rid, row in rows.items():
                    row['request_key'] = request_key(self._wave_run_id, rid)
            frame = dict(index=index, rows=rows, visited=set())
            self._ledger_emit('frame_begin', frame=index, requests=len(rows))
        except Exception:
            ledger['errors'] += 1
        # A sentinel prevents failed nested frame setup from borrowing its parent.
        ledger['stack'].append(frame)
        try:
            result = super().update_from_output(scheduler_output, model_runner_output)
        except BaseException:
            ledger['errors'] += 1
            raise
        finally:
            ledger['stack'].pop()
            if frame is not None:
                for rid in frame['rows'].keys() - frame['visited']:
                    self._ledger_emit('not_updated', frame=frame['index'],
                                      **frame['rows'][rid])
                self._ledger_emit('frame_end', frame=frame['index'])
        return result

    def _update_request_with_output(self, request, new_token_ids, is_stale=False):
        ledger = getattr(self, '_output_ledger', None)
        if ledger is None:
            return super()._update_request_with_output(request, new_token_ids, is_stale=is_stale)
        frame = ledger['stack'][-1] if ledger['stack'] else None
        row = frame['rows'].get(request.request_id) if frame else None
        if row is None:
            ledger['errors'] += 1
            return super()._update_request_with_output(request, new_token_ids, is_stale=is_stale)
        if request.request_id in frame['visited']:
            ledger['errors'] += 1
        frame['visited'].add(request.request_id)
        result, observation = observe_update(super()._update_request_with_output,
            request, new_token_ids, draft_count=row['drafts'],
            sampled_per_step=self.num_sampled_tokens_per_step, is_stale=is_stale)
        if observation['retained_drafts'] is None:
            ledger['errors'] += 1
        self._ledger_emit('output_update', frame=frame['index'], **row, observation=observation)
        return result
