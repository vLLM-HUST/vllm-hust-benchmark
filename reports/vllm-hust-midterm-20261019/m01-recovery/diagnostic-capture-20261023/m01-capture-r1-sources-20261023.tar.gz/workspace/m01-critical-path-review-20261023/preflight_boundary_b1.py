"""CPU-only import and benchmark parser receipt; not a device qualification."""
import argparse
import hashlib
import importlib
import importlib.metadata
import json
from pathlib import Path

from run_boundary_benchmark import validate_args

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    options = parser.parse_args()
    modules = {}
    for name in ('torch', 'torch_npu', 'vllm', 'vllm_ascend', 'triton',
                 'betterscale.qwen35_worker', 'vllm_kv_materialization.school_vllm_028',
                 'hust_prefill_microflow.school028', 'synchronized_boundary'):
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        modules[name] = dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                             version=str(getattr(module, '__version__', 'unavailable')))
    from vllm.benchmarks import serve
    from vllm.utils.argparse_utils import FlexibleArgumentParser
    benchmark_parser = FlexibleArgumentParser()
    serve.add_cli_args(benchmark_parser)
    argv = ['--backend', 'openai-chat', '--base-url', 'http://127.0.0.1:18390',
            '--endpoint', '/v1/chat/completions', '--model', 'qwen3.5-35b',
            '--tokenizer', '/models/Qwen3.5-35B-A3B', '--dataset-name', 'custom',
            '--dataset-path', str(ROOT / 'materialized.200.jsonl'), '--disable-shuffle',
            '--custom-output-len', '256', '--num-prompts', '200', '--request-rate', 'inf',
            '--temperature', '0', '--seed', '0', '--save-result', '--save-detailed',
            '--percentile-metrics', 'ttft,tpot,itl,e2el', '--metric-percentiles', '50,95,99',
            '--ready-check-timeout-sec', '0', '--num-warmups', '0']
    validate_args(benchmark_parser.parse_args(argv), 18390)
    entries = importlib.metadata.entry_points(group='vllm.general_plugins')
    selected = {entry.name: entry.value for entry in entries if entry.name in
                ('kv_materialization', 'hust_microflow_school028_fa')}
    if len(selected) != 2:
        raise ValueError('Missing optimization plugin entrypoint')
    from benchmark_boundary_hook import instrument
    path = Path(serve.__file__).resolve()
    compile(instrument(path.read_text()), str(path), 'exec')
    receipt = dict(status='passed', scope='CPU imports/parser only; no service or inference',
                   modules=modules, plugins=selected, benchmark_args=argv,
                   benchmark_source=str(path), benchmark_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                   input_sha256=hashlib.sha256((ROOT / 'materialized.200.jsonl').read_bytes()).hexdigest(),
                   service_started=False, device_qualification=False)
    with options.output.open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', service_started=False,
                          module_count=len(modules), plugins=selected)))


if __name__ == '__main__':
    main()
