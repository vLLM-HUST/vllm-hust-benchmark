"""Close target GDN families conditionally; draft and timing remain separate."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
sys.path.insert(0, str(ROOT))
from audit_gdn_preprocess_semantics import operations as preprocess, basic
from audit_gdn_recurrence_r9 import operations as recurrence


def decode_counts(input_tokens, output_tokens, requests):
    if any(type(x) is not int or x < 0 for x in (input_tokens, output_tokens, requests)):
        raise ValueError('Nonnegative integer extents required')
    if output_tokens < requests:
        raise ValueError('Each completed request must emit at least one token')
    rows = output_tokens - requests
    all_rows = input_tokens + rows
    prep = {key: value * 2 for key, value in preprocess(all_rows * 30).items()}
    per_head = recurrence(128, 128, 32)
    return dict(necessary_decode_rows=rows,
                recurrent_basic_flops=rows * 30 * 32 * per_head['semantic_basic_flops'],
                recurrent_exp_evaluations=rows * 30 * 32,
                preprocess_operations=prep, preprocess_basic_flops=basic(prep))


def build():
    here = Path(__file__).resolve().parent
    hashes = {}

    def read(path, expected=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f'Source mismatch: {path}')
        hashes[str(path)] = digest
        return raw

    def ledger(path):
        record = json.loads(read(path))
        for name, digest in record['source_sha256'].items():
            read(Path(name), digest)
        return record

    parent = ledger(here / 'target-vocab-conv-candidate-r1.json')
    target = ledger(here / 'target-useful-candidate-r1.json')
    aggregate = ledger(here / 'acceptance-aggregate-reconciliation-r1.json')
    prefill = ledger(ROOT / 'recovery_model_worker_r1-device-gdn-prefill.json')
    ledger(ROOT / 'recovery_model_worker_r1-gdn-preprocess-semantics.json')
    assert aggregate['partition']['prefill_rows'] == target['input_tokens']
    cohort = 'inside_request_under_clock_tolerance'
    assert len(prefill['ranks']) == 2
    assert prefill['ranks'][0]['cohorts'] == prefill['ranks'][1]['cohorts']
    for rank in prefill['ranks']:
        rows = sum(x['length'] * x['chunk_layers'] for x in rank['cohorts'][cohort]['chunk_catalog'])
        assert rows == target['input_tokens'] * 30
    prefill_basic = sum(rank['cohorts'][cohort]['basic_arithmetic_subtotal'] for rank in prefill['ranks'])
    counts = decode_counts(target['input_tokens'], target['output_tokens'], target['requests'])
    assert target['input_tokens'] + counts['necessary_decode_rows'] == target['candidate_target_rows']
    for path in (Path(__file__), ROOT / 'audit_gdn_preprocess_semantics.py', ROOT / 'audit_gdn_recurrence_r9.py'):
        read(path)
    subtotal = parent['combined_target_partial_subtotal'] + prefill_basic + counts['recurrent_basic_flops'] + counts['preprocess_basic_flops']
    return dict(status='conditional_target_family_candidate_draft_and_timing_unresolved', **counts,
        prefill_basic_flops=prefill_basic, target_family_candidate_subtotal=subtotal,
        observed_active_verify_rows=aggregate['partition']['active_verify_rows'],
        excluded_active_verify_rows=aggregate['partition']['active_verify_rows'] - counts['necessary_decode_rows'],
        effective_flops=None, efficiency_percent=None, source_sha256=hashes,
        limitations=[
            'Inherits conditional necessary target token extents from preceding ledgers.',
            'Prefill reuses actual chunked algorithm accounting with observed initial state; it is not replaced by decode recurrence.',
            'Existing prefill algorithm arithmetic remains subject to review for redundant work under the new useful-work convention.',
            'Decode recurrence excludes rejected and budget-truncated rows; special functions stay separate.',
            'This covers the currently inventoried target families, not a certificate of complete model F.',
            'Useful draft work, output provenance, synchronized timing and independently applicable reference time remain unresolved.'])


if __name__ == '__main__':
    result = build()
    with Path(__file__).with_name('target-gdn-candidate-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('necessary_decode_rows', 'excluded_active_verify_rows',
        'prefill_basic_flops', 'recurrent_basic_flops', 'preprocess_basic_flops', 'target_family_candidate_subtotal')}))
