import types
import unittest
from unittest.mock import MagicMock, patch
from synchronized_boundary import WorkerBoundary


class WorkerConfigTests(unittest.TestCase):
    def test_fence_returns_selected_actual_configuration_only(self):
        config = types.SimpleNamespace(multistream_overlap_shared_expert=False,
                                       enable_shared_expert_dp=False, irrelevant='not exported')
        torch = types.SimpleNamespace(npu=types.SimpleNamespace(synchronize=MagicMock()),
            distributed=types.SimpleNamespace(get_rank=lambda: 0))
        with patch.dict('sys.modules', torch=torch, **{
            'vllm_ascend.ascend_config': types.SimpleNamespace(get_ascend_config=lambda: config)}):
            result = WorkerBoundary.hust_m01_sync_boundary(types.SimpleNamespace(device='npu:0'), 'begin')
        torch.npu.synchronize.assert_called_once()
        self.assertEqual(result['runtime_configuration'],
            dict(multistream_overlap_shared_expert=False, enable_shared_expert_dp=False))
        self.assertTrue(result['device_sync_completed'])


if __name__ == '__main__':
    unittest.main()
