"""Recover configured MoE scheduling constraints, without fitting reference time."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
HERE = Path(__file__).resolve().parent


def default_bool(source, name):
    values = [node.value.value for node in ast.walk(ast.parse(source))
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name)
        and node.target.id == name and isinstance(node.value, ast.Constant)
        and type(node.value.value) is bool]
    if len(values) != 1:
        raise ValueError('Ambiguous configuration default')
    return values[0]


def configured_overlap(command, config_source):
    if command.count('--additional-config') != 1:
        raise ValueError('Expected one explicit additional config')
    config = json.loads(command[command.index('--additional-config') + 1])
    donor = config.get('multistream_overlap_shared_expert',
                       default_bool(config_source, 'multistream_overlap_shared_expert'))
    patch = config.get('betterscale_shared_expert_overlap', False)
    if type(donor) is not bool or type(patch) is not bool:
        raise ValueError('Nonboolean overlap option')
    if patch and not donor:
        raise ValueError('Invalid shared overlap combination')
    return dict(donor_multistream=donor, betterscale_shared_overlap_patch=patch)


def main():
    config_path = ROOT / 'runtime/vllm_ascend/ascend_config.py'
    runner_path = ROOT / 'runtime/vllm_ascend/ops/fused_moe/fused_moe.py'
    shared_path = ROOT / 'runtime/vllm_ascend/ops/fused_moe/shared_experts.py'
    patch_path = ROOT / 'recovery-model-payload-r1/betterscale/models/qwen35/moe_overlap.py'
    sources = [Path(__file__), config_path, runner_path, shared_path, patch_path]
    findings = {}
    for run in ('m01-recovery-model-worker-r1', 'mmlu-b1-microflow-fa-on-r9',
                'mmlu-b1-microflow-fa-on-r10', 'mmlu-b1-microflow-fa-on-r11'):
        path = ROOT / run / 'launch-command.json'
        sources.append(path)
        findings[run] = configured_overlap(json.loads(path.read_text()), config_path.read_text())
    inventory = []
    for path in sorted((ROOT / 'm01-recovery-model-worker-r1').glob('token-accounting-*.jsonl')):
        with path.open() as stream:
            event = next(json.loads(line) for line in stream
                         if json.loads(line).get('event') == 'loaded_model_inventory')
        target = event['target']
        if target['source_sha256'][str(runner_path)] != hashlib.sha256(runner_path.read_bytes()).hexdigest():
            raise ValueError('Loaded MoE runner source mismatch')
        modules = [m for m in target['modules'] if m['type'].endswith('.AscendMoERunner')]
        if len(modules) != 40:
            raise ValueError('Unexpected target MoE layer count')
        modes = [m['objects']['moe_config']['scalars'] for m in modules]
        if any(m['tp_size'] != 2 or m['ep_size'] != 1 or m['is_sequence_parallel'] for m in modes):
            raise ValueError('Unexpected MoE parallelism')
        inventory.append(dict(file=str(path), layers=40, tp_size=2, ep_size=1, sequence_parallel=False))
        sources.append(path)
    if len(inventory) != 2:
        raise ValueError('Expected both loaded worker inventories')
    result = dict(status='configured_schedule_constraints_recovered', runs=findings,
        loaded_inventory=inventory, reference_rules=[
            'For these configured arms, do not assume shared and routed experts run on independent streams.',
            'Shared/routed projections, activation and final combination must retain actual dependencies.',
            'The separate Microflow full-attention prefix overlap remains applicable only to its admitted partitions.',
            'Independent kernel times already include kernel memory accesses; do not add global HBM time again.',
            'Do not add historical host-synchronized collective totals; use the planned graph collective calibration.'],
        evidence_scope='Launch options plus current pinned source defaults; runner identity and TP/EP/SP bound to recorded loaded inventory',
        limitations=['No recorded runtime value of AscendSharedExperts.multistream_overlap; configuration inference is not a measured stream trace.',
                     'No weighted necessary-work reference time is derived by this audit.'],
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        reference_seconds=None, efficiency_percent=None)
    output = HERE / 'moe-schedule-constraints-r1.json'
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=result['status'], runs=findings, loaded_workers=len(inventory))))


if __name__ == '__main__':
    main()
