"""Freeze CPU-verifiable inputs; does not claim device admission."""
import hashlib
import json
from pathlib import Path

from collective_graph_worker import validate_plan

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def main():
    prepared_path = HERE / 'collective-graph-grid-preparation-r1.json'
    prepared = json.loads(prepared_path.read_text())
    paths = [HERE / name for name in ('collective_graph_probe.py', 'collective_graph_worker.py',
             'run_collective_graph.py', 'runtime_collective_graph.sh', 'prepare_collective_graph_grid.py',
             'freeze_collective_graph_plan.py')]
    paths += [prepared_path, ROOT / 'runtime-lifecycle-r3/run_fs018_solver.py',
              ROOT / 'runtime-lifecycle-r3/process_group_drain.py',
              ROOT / 'v018-runtime-recovery-20261022/run_quality018_r2.py']
    outline = Path('/root/gennova-evidence/20261023-outline-v526/vLLM-HUST-midterm-V5.26.docx')
    paths.append(outline)
    assert hashlib.sha256(outline.read_bytes()).hexdigest() == 'e3726dc18554d7cb2ead94dc70a6881f9b8709563af1a9eb7446795ccbe0100f'
    old = json.loads((ROOT / 'm01-recovery-model-fs-paired-b1-judge-r1/quality-runtime-imports.json').read_text())
    modules = {}
    for name in ('torch', 'torch_npu'):
        path = Path('/root/frontierscience-recovery-20261022/filtered-site') / name / '__init__.py'
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == old['modules'][name]['sha256']
        modules[name] = dict(path=str(path.resolve()), sha256=digest)
        paths.append(path)
    paths.append(Path('/root/frontierscience-recovery-20261022/venv/bin/python').resolve())
    result = dict(status='frozen_for_qualification', method='V5.26',
                  runtime_versions={'torch': '2.13.0+cpu', 'torch_npu': '2.13.0.rc1'},
                  runtime_modules=modules, shapes=prepared['shapes'], batch_sizes=[1, 8, 32],
                  samples=16, repetitions=3, port=18517,
                  scope='Independent collective graph reference; not a whole-model M01 result',
                  source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    validate_plan(result)
    output = HERE / 'collective-graph-execution-plan-r1.json'
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(path=str(output), sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                         status=result['status'], device_admission=False)))


if __name__ == '__main__':
    main()
