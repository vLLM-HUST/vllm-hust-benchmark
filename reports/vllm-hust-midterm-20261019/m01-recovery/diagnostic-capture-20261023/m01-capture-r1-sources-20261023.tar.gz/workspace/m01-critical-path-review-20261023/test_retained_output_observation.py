from types import SimpleNamespace

import pytest

from retained_output_observation import classify, observe_update


@pytest.mark.parametrize('raw,kept,expected', [
    (1, 1, 0), (2, 1, 1), (2, 2, 1), (3, 1, 1), (3, 2, 2), (3, 3, 2),
])
def test_terminal_prefix_before_bonus(raw, kept, expected):
    result = classify(draft_count=2, sampled_per_step=1, raw_count=raw,
                      kept_count=kept, before_count=0, after_count=kept, is_stale=False)
    assert result['retained_drafts'] == expected


def test_native_mutation_not_lost_and_called_once():
    request = SimpleNamespace(_output_token_ids=[9])
    tokens = [1, 2, 3]
    calls = []
    def update(req, values, *, is_stale):
        calls.append(1)
        del values[1:]
        req._output_token_ids.extend(values)
        return values, True
    result, event = observe_update(update, request, tokens, draft_count=2, sampled_per_step=1)
    assert calls == [1] and result[0] is tokens and result[1] is True
    assert event['raw_count'] == 3 and event['kept_count'] == 1
    assert event['retained_drafts'] == 1
    assert 'tokens' not in event


@pytest.mark.parametrize('stale,sampled,after', [(True, 1, 1), (False, 0, 1), (False, 1, 0)])
def test_no_false_exact_count(stale, sampled, after):
    event = classify(draft_count=2, sampled_per_step=sampled, raw_count=3,
                     kept_count=1, before_count=0, after_count=after, is_stale=stale)
    assert event['retained_drafts'] is None


def test_native_exception_propagates():
    def update(*args, **kwargs):
        raise RuntimeError('native failure')
    with pytest.raises(RuntimeError, match='native failure'):
        observe_update(update, SimpleNamespace(_output_token_ids=[]), [1],
                       draft_count=0, sampled_per_step=1)


def test_invalid_observation_does_not_replace_native_result():
    request = SimpleNamespace(_output_token_ids=[])
    def update(req, values, **kwargs):
        req._output_token_ids.extend(values)
        return values, False
    result, event = observe_update(update, request, [1, 2, 3, 4],
                                   draft_count=2, sampled_per_step=1)
    assert result == ([1, 2, 3, 4], False)
    assert event['status'] == 'observation_invalid'
