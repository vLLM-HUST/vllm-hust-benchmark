"""Transport check on pinned dataclass definitions, without loading NPU modules."""
import ast
import dataclasses
import hashlib
import json
import pickle
import sys
import types
from pathlib import Path

from worker_wave_identity import attach, validate


def test_pinned_state_schedule_retains_wave_attribute():
    here = Path(__file__).resolve().parent
    plan = json.loads((here / 'boundary-execution-plan-r7.json').read_text())
    specs = [
        ('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/v1/core/sched/output.py', 'SchedulerOutput'),
        ('/root/gennova-evidence/20261019-midterm-aligned/recovery-model-payload-r1/betterscale/models/qwen35/seat_scheduler.py', 'StateSchedule'),
    ]
    body = ast.parse('from __future__ import annotations').body
    for name, cls_name in specs:
        raw = Path(name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == plan['source_sha256'][name]
        body.append(next(node for node in ast.parse(raw).body
                         if isinstance(node, ast.ClassDef) and node.name == cls_name))
    module_name = '_m01_pinned_schedule_transport_test'
    module = types.ModuleType(module_name)
    module.__dict__.update(dataclass=dataclasses.dataclass, field=dataclasses.field)
    assert module_name not in sys.modules
    sys.modules[module_name] = module
    try:
        exec(compile(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[])),
                     '<pinned-schedule-classes>', 'exec'), module.__dict__)
        output = module.StateSchedule(scheduled_new_reqs=[], scheduled_cached_reqs=None,
            num_scheduled_tokens={'request': 3}, total_num_scheduled_tokens=3,
            scheduled_spec_decode_tokens={'request': [11, 12]}, scheduled_encoder_inputs={},
            num_common_prefix_blocks=[], finished_req_ids=set(), free_encoder_mm_hashes=[],
            resident_leases={'request': (0, 1)})
        before = dataclasses.asdict(output)
        tag = attach(output, run_id='r1', wave=7)
        received = pickle.loads(pickle.dumps(('execute_model', (output,), {}, 0),
                                            protocol=pickle.HIGHEST_PROTOCOL))[1][0]
        assert validate(received, run_id='r1') == tag
        assert type(received) is module.StateSchedule
        assert dataclasses.asdict(received) == before
    finally:
        del sys.modules[module_name]
