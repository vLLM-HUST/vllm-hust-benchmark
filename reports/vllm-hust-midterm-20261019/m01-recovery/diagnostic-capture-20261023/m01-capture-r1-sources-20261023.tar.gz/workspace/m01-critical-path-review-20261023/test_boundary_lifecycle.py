from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch

import run_boundary_b1 as controller


class LifecycleTests(unittest.TestCase):
    def exercise(self, client_code=0, drain_failure=False):
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            root = Path(directory)
            output = root / 'output'
            plan = dict(protocol='m01-boundary-supplement/v1', source_sha256={},
                participating=[0, 1], reserved=[0, 1, 6, 7], status='frozen_for_execution',
                model_weight_identity=dict(files=[], directory=directory),
                output=str(output), cache=str(root / 'cache'),
                benchmark_sha256='test-only', benchmark_args=[])
            plan_path = root / 'plan.json'
            plan_path.write_text(json.dumps(plan))
            idle = '\n'.join(f'No running processes found in NPU {i}' for i in (0, 1, 6, 7))
            server = types.SimpleNamespace(pid=123456, poll=lambda: None, returncode=None)
            client = types.SimpleNamespace(pid=123457, poll=lambda: client_code, returncode=client_code)
            runtime = types.SimpleNamespace(npu_info=MagicMock(return_value=idle),
                owned=MagicMock(return_value=True), stop=MagicMock(return_value=0))
            opener = MagicMock()
            opener.open.return_value.__enter__.return_value.status = 200
            lifecycle = types.SimpleNamespace(runtime=runtime, OPENER=opener, seal_if_released=MagicMock())
            drain = MagicMock(side_effect=RuntimeError('test drain failure') if drain_failure else None)
            stack.enter_context(patch.dict('sys.modules', run_fs018_solver=lifecycle,
                process_group_drain=types.SimpleNamespace(wait_session_drained=drain)))
            stack.enter_context(patch.object(controller.sys, 'argv', ['test', '--plan', str(plan_path)]))
            stack.enter_context(patch.object(controller, 'completed_dependencies'))
            stack.enter_context(patch.object(controller.fcntl, 'flock'))
            stack.enter_context(patch.object(controller.socket, 'socket'))
            stack.enter_context(patch.object(controller.time, 'sleep'))
            stack.enter_context(patch.object(controller.shutil, 'disk_usage', return_value=types.SimpleNamespace(free=100*1024**3)))
            spawn = stack.enter_context(patch.object(controller.subprocess, 'Popen', side_effect=[server, client]))
            result = stack.enter_context(patch.object(controller, 'check_result', return_value=dict(completed=200)))
            stack.enter_context(patch.object(controller, 'audit_mods', return_value=dict(status='test-only')))
            real_open = open
            def open_test_lock(path, *args, **kwargs):
                if str(path) == '/tmp/inference-project-container-model.lock' or str(path).startswith('/tmp/gennova-device-leases/'):
                    return real_open(root / ('lock-' + Path(path).name), *args, **kwargs)
                return real_open(path, *args, **kwargs)
            stack.enter_context(patch('builtins.open', side_effect=open_test_lock))
            code = controller.main()
            receipt = json.loads((output / 'receipt.json').read_text())
            self.assertEqual(spawn.call_count, 2)
            self.assertEqual([c.args[0].pid for c in runtime.stop.call_args_list], [client.pid, server.pid])
            self.assertEqual(drain.call_count, 2)
            self.assertEqual(receipt['all_devices_released'], True)
            return code, receipt, result.call_count

    def test_success_cleans_both_sessions(self):
        code, receipt, audits = self.exercise()
        self.assertEqual(code, 0)
        self.assertEqual(receipt['status'], 'collected_pending_audit')
        self.assertTrue(receipt['sessions_drained'])
        self.assertEqual(audits, 1)

    def test_client_failure_preserved_and_cleaned(self):
        code, receipt, audits = self.exercise(client_code=1)
        self.assertEqual(code, 1)
        self.assertEqual(receipt['status'], 'failed')
        self.assertEqual(receipt['client_exit_code'], 1)
        self.assertEqual(audits, 0)

    def test_cleanup_failure_prevents_success(self):
        code, receipt, _ = self.exercise(drain_failure=True)
        self.assertEqual(code, 1)
        self.assertFalse(receipt['sessions_drained'])
        self.assertEqual(len(receipt['cleanup_errors']), 2)


if __name__ == '__main__':
    unittest.main()
