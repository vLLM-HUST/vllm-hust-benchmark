import unittest
from audit_useful_draft_counts import counters


class CounterTests(unittest.TestCase):
    def data(self, proposed=20, accepted=17):
        return dict(spec_decode_draft_tokens=proposed, spec_decode_accepted_tokens=accepted,
                    spec_decode_num_drafts=10, spec_decode_acceptance_rate=85.0)

    def test_rejections(self):
        self.assertEqual(counters(self.data())['rejected'], 3)

    def test_inconsistent(self):
        for data in (self.data(19), self.data(20, 21), self.data(20, -1), self.data(20, True)):
            with self.assertRaises(ValueError):
                counters(data)

    def test_rate(self):
        data = self.data()
        data['spec_decode_acceptance_rate'] = 90
        with self.assertRaises(ValueError):
            counters(data)


if __name__ == '__main__':
    unittest.main()
