import unittest
from prepare_collective_graph_grid import grid


class GridTests(unittest.TestCase):
    def row(self):
        return {'observed': dict(kind='all_gather', dtype='BFP16', elements=24, rank_size=2,
                                 input_bytes_per_call=48, calls=12)}

    def test_valid(self):
        self.assertEqual(grid([self.row()])[0]['calls'], 12)

    def test_duplicate(self):
        with self.assertRaises(ValueError):
            grid([self.row(), self.row()])

    def test_bad_contract(self):
        for key, value in [('dtype', 'FP16'), ('rank_size', 4), ('elements', 0), ('input_bytes_per_call', 49)]:
            row = self.row()
            row['observed'][key] = value
            with self.assertRaises(ValueError):
                grid([row])


if __name__ == '__main__':
    unittest.main()
