"""Verify restored reference custody and inventory weights without composing Tref."""
import hashlib
import json
from pathlib import Path
from statistics import mean


def main():
    here = Path(__file__).resolve().parent
    archive = here / 'm01-worker-resource-terms-20261022.tar.gz'
    expected = '0e57723036698d8b3e5885a32b8c5c018c6f15bd07b79d8545bc0c2f65fb6de0'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
    restored = here / 'resource-terms-restored-r1'
    manifest_path = restored / 'workspace/m01-worker-resource-term-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    checked = {}
    for name, entry in manifest['files'].items():
        path = restored / name.lstrip('/')
        assert path.resolve().is_relative_to(restored.resolve())
        raw = path.read_bytes()
        assert len(raw) == entry['bytes']
        assert hashlib.sha256(raw).hexdigest() == entry['sha256']
        checked[name] = entry['sha256']
    term_path = restored / 'workspace/m01-worker-resource-terms.json'
    terms = json.loads(term_path.read_text())
    for name, digest in terms['source_sha256'].items():
        assert checked[name] == digest
    components = {}
    for row in terms['compute_components']:
        component = components.setdefault(row['component'], {})
        assert row['rank'] not in component
        component[row['rank']] = mean(row['weighted_repetition_ms']) / 1000
    assert len(components) == 18
    rows = []
    for name, ranks in components.items():
        assert set(ranks) == {0, 1}
        rows.append(dict(component=name, rank_mean_seconds=ranks,
                         max_rank_mean_seconds=max(ranks.values())))
    rows.sort(key=lambda r:r['max_rank_mean_seconds'], reverse=True)
    result = dict(status='restored_reference_custody_verified_stage_composition_pending',
        verified_member_count=len(checked), components=rows,
        model_reference_seconds=None, efficiency_percent=None,
        source_sha256={str(archive):expected, str(manifest_path):hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
                       str(Path(__file__)):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
        reuse_decisions=[
            'Existing shape-specific kernel references are retained, not discarded for needing phase mapping.',
            'Weighted observed/padded multiplicities are not yet necessary-work multiplicities.',
            'Kernel reference elapsed time already includes its memory accesses; do not add the whole HBM term again.',
            'Component rank maxima are an inventory ordering, not a critical path or summed model reference.',
            'MoE and auxiliary graph probes are not automatically classified as eager solely because the host synchronizes after timing.',
            'The separate collective graph qualification remains pending device release.'])
    with (here / 'restored-component-reference-audit-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'verified_members':len(checked), 'component_count':len(rows), 'largest_components':rows[:4]}))


if __name__ == '__main__':
    main()
