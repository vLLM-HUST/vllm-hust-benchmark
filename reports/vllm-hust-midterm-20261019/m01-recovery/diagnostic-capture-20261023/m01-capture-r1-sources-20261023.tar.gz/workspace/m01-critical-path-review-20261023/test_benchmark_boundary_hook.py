import ast
import types
import unittest
from benchmark_boundary_hook import guard, instrument


SOURCE = '''
async def benchmark(profile=False, probe_request_rate=0):
    events.append("prepare")
    benchmark_start_time = time.perf_counter()
    events.append("requests")
    benchmark_duration = time.perf_counter() - benchmark_start_time
    events.append("metrics")
    return benchmark_duration
'''


class HookTests(unittest.IsolatedAsyncioTestCase):
    async def test_client_duration_unchanged_and_hooks_outside(self):
        events = []
        class Boundary:
            async def begin(self): events.append('begin')
            async def end(self): events.append('end')
        times = iter([10, 12])
        scope = dict(events=events, time=types.SimpleNamespace(perf_counter=lambda:next(times)),
                     __m01_guard=guard, __m01_boundary=Boundary(),
                     __m01_finish=lambda start,duration:events.append(('finish',start,duration)))
        exec(compile(instrument(SOURCE), '<test>', 'exec'), scope)
        self.assertEqual(await scope['benchmark'](), 2)
        self.assertEqual(events, ['prepare','begin','requests','end',('finish',10,2),'metrics'])

    def test_changed_clock_rejected(self):
        with self.assertRaises(ValueError):
            instrument(SOURCE.replace('time.perf_counter()', 'time.time()'))

    def test_missing_boundary_rejected(self):
        with self.assertRaises(ValueError):
            instrument(SOURCE.replace('benchmark_duration =', 'other_duration ='))

    def test_competing_probes_rejected(self):
        for values in (dict(profile=True), dict(profile=False, probe_request_rate=1),
                       dict(profile=False, self_timed=True)):
            with self.assertRaises(ValueError): guard(values)

    def test_real_source_compiles_without_importing_runtime(self):
        from pathlib import Path
        path = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/benchmarks/serve.py')
        tree = instrument(path.read_text())
        compile(tree, str(path), 'exec')
        calls = [n for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == '__m01_finish']
        self.assertEqual(len(calls), 1)
