import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from run_boundary_b1 import validate_plan, check_result


class ControllerTests(unittest.TestCase):
    def test_changed_source_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'source'
            source.write_bytes(b'original')
            plan = dict(protocol='m01-boundary-supplement/v1', participating=[0, 1],
                reserved=[0, 1, 6, 7], source_sha256={str(source): hashlib.sha256(b'original').hexdigest()})
            validate_plan(plan)
            source.write_bytes(b'changed')
            with self.assertRaises(ValueError):
                validate_plan(plan)

    def test_partial_workload_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            (output / 'mmlu-pro.json').write_text(json.dumps(dict(completed=199)))
            with self.assertRaisesRegex(ValueError, 'completed'):
                check_result(output)

    def test_successful_workload_without_fences_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            (output / 'mmlu-pro.json').write_text(json.dumps(dict(completed=200, failed=0,
                total_input_tokens=282265, total_output_tokens=51200, duration=62)))
            (output / 'boundary.jsonl').write_text(json.dumps(dict(
                protocol='m01-unprofiled-client-synchronized-boundary/v1',
                client_duration_seconds=62, synchronized_duration_seconds=63, calls=[])))
            with self.assertRaisesRegex(ValueError, 'control sequence'):
                check_result(output)


if __name__ == '__main__':
    unittest.main()
