import itertools
import unittest
from join_boundary_workload import retained_bounds


class BoundsTests(unittest.TestCase):
    def test_current_counts(self):
        result = retained_bounds(200, 51200, 19013, 32173, 38026)
        self.assertEqual(result['implied_terminal_excess'], 186)
        self.assertEqual((result['retained_draft_min'], result['retained_draft_max']), (32080, 32173))

    def test_enumerated_terminal_prefixes(self):
        choices = [(a, keep) for a in range(3) for keep in range(1, a + 2)]
        for cases in itertools.product(choices, repeat=3):
            accepted = sum(a for a, keep in cases)
            outputs = 3 + sum(keep for a, keep in cases)
            useful = sum(min(a, keep) for a, keep in cases)
            bounds = retained_bounds(3, outputs, 3, accepted, 6)
            self.assertLessEqual(bounds['retained_draft_min'], useful)
            self.assertGreaterEqual(bounds['retained_draft_max'], useful)

    def test_inconsistent_counts_rejected(self):
        for values in [(2, 100, 1, 2, 2), (2, 2, 1, 2, 3), (0, 0, 0, 0, 0)]:
            with self.assertRaises(ValueError):
                retained_bounds(*values)
