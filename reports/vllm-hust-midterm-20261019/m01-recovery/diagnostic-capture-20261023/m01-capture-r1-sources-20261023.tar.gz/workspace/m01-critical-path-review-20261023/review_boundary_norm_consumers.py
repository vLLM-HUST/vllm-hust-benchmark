"""Pin a source-path review; consumption is not proof of useful draft work."""
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
VLLM = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm')
sys.path.insert(0, str(ROOT))
from audit_norm_accounting import rms_operations


def sensitivity(target_rows, output_rows, width=2048):
    if any(type(v) is not int or v < 0 for v in (target_rows, output_rows)):
        raise ValueError('Nonnegative integer rows required')
    if output_rows > target_rows:
        raise ValueError('Output positions exceed target positions')
    ops = rms_operations(target_rows - output_rows, width, residual=True)
    return {k: v for k, v in ops.items() if not k.endswith('_evaluations')}


def build():
    plan_path = HERE / 'boundary-execution-plan-r7.json'
    plan = json.loads(plan_path.read_text())
    checks = [
        (VLLM / 'model_executor/models/qwen3_5.py',
         'class Qwen3_5Model(Qwen3NextModel):', 'Qwen3.5 inherits target forward'),
        (VLLM / 'model_executor/models/qwen3_next.py',
         'hidden_states, _ = self.norm(hidden_states, residual)', 'Target final norm'),
        (ROOT / 'runtime/vllm_ascend/worker/model_runner_v1.py',
         'target_hidden_states = hidden_states[:num_scheduled_tokens]',
         'Non-spec-metadata branch sends scheduled target states to drafter'),
        (ROOT / 'runtime/vllm_ascend/spec_decode/llm_base_proposer.py',
         'self.hidden_states[:num_tokens] = target_hidden_states.view(num_tokens, -1)',
         'First pass copies full supplied target state extent'),
        (ROOT / 'runtime/vllm_ascend/spec_decode/llm_base_proposer.py',
         'model_hidden_states = self.hidden_states[:num_input_tokens]',
         'Draft model input is not restricted to sampled logits positions'),
        (ROOT / 'runtime/vllm_ascend/patch/worker/patch_qwen3_5.py',
         'hidden_states = self.pre_fc_norm_hidden(hidden_states)',
         'MTP normalizes and projects target hidden-state input'),
    ]
    reviewed = []
    for path, fragment, meaning in checks:
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if plan['source_sha256'].get(str(path)) != digest:
            raise ValueError(f'Run-frozen source mismatch: {path}')
        lines = raw.decode().splitlines()
        matches = [i + 1 for i, line in enumerate(lines) if fragment in line]
        if not matches:
            raise ValueError(f'Reviewed source anchor absent: {path}')
        reviewed.append(dict(path=str(path), sha256=digest, lines=matches,
                             fragment=fragment, interpretation=meaning))
    bench_path = Path('/workspace/m01-boundary-b1-r1/mmlu-pro.json')
    bench = json.loads(bench_path.read_text())
    target = sum(bench['input_lens']) + sum(bench['output_lens']) - bench['completed']
    output = sum(bench['output_lens'])
    ops = sensitivity(target, output)
    return dict(
        status='source_review_rejects_logits_only_norm_exclusion',
        target_rows=target, output_rows=output, disputed_rows=target-output,
        hypothetical_logits_only_exclusion_basic_flops=sum(ops.values()),
        hypothetical_exclusion_operations=ops, applied_exclusion_flops=0,
        reviewed_source_edges=reviewed,
        interpretation=[
            'Logits selection alone cannot establish that other final-norm outputs are unused.',
            'The reviewed MTP source path consumes target states to construct draft context.',
            'Source existence is not per-request runtime liveness or retained-draft provenance.',
            'Do not subtract this sensitivity, or certify every consumed row as useful, without that provenance.',
        ],
        effective_flops=None, reference_seconds=None, efficiency_percent=None,
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in (plan_path, bench_path, Path(__file__), ROOT / 'audit_norm_accounting.py')})


if __name__ == '__main__':
    result = build()
    with (HERE / 'boundary-norm-consumers-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'disputed_rows',
        'hypothetical_logits_only_exclusion_basic_flops', 'applied_exclusion_flops')}))
