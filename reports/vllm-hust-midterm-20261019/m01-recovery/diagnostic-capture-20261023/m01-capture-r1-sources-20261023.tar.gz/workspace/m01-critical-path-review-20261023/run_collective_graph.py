"""Admit one isolated collective calibration after the active FS experiment."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import time

from collective_graph_worker import validate_plan

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
LIFECYCLE = ROOT / 'runtime-lifecycle-r3'
DEVICES = (0, 1, 6, 7)


def completed_dependencies():
    for name in ('frontierscience-native018-solver-r1', 'frontierscience-native018-judge-r1'):
        path = ROOT / name / 'receipt.json'
        if not path.exists():
            raise RuntimeError(f'Waiting for {name}')
        data = json.loads(path.read_text())
        if not (data.get('status') == 'completed' and data.get('sessions_drained')
                and data.get('all_devices_released') and (path.parent / 'SHA256SUMS').is_file()):
            raise RuntimeError(f'Experiment not completed and released: {name}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    validate_plan(plan)
    if args.check:
        print('PASS: CPU plan validation only; device admission has not run')
        return 0
    completed_dependencies()
    sys.path.insert(0, str(LIFECYCLE))
    import run_fs018_solver as lifecycle
    from process_group_drain import wait_session_drained

    locks, child, created_output = [], None, False
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError('Refusing to reuse output or compiler cache')
    record = dict(status='admitting', started=time.time(), reserved=list(DEVICES),
                  participating=[0, 1], fallback=False)
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in DEVICES]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        completed_dependencies()
        output.mkdir()
        created_output = True

        def observe(event):
            with (output / 'monitor.jsonl').open('a') as stream:
                stream.write(json.dumps(event) + '\n')

        for _ in range(3):
            raw = lifecycle.runtime.npu_info(observe)
            if not all(f'No running processes found in NPU {i}' in raw for i in DEVICES):
                raise RuntimeError('Devices are not idle')
            time.sleep(2)
        (output / 'npu-before.txt').write_text(raw)
        if shutil.disk_usage(output).free < 5 * 1024**3:
            raise RuntimeError('Insufficient evidence/cache space')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', plan['port']))
        shutil.copyfile(args.plan, output / 'execution-plan.json')
        cache = output / 'cache'
        cache.mkdir()
        (output / 'admission.json').write_text(json.dumps(dict(controller_pid=os.getpid(),
            plan_sha256=hashlib.sha256(args.plan.read_bytes()).hexdigest(), initial_cache_entries=[])))
        env = dict(HOME='/root', PATH='/usr/local/bin:/usr/bin:/bin', LANG='C.UTF-8',
                   ASCEND_RT_VISIBLE_DEVICES='0,1', TASK_QUEUE_ENABLE='0',
                   XDG_CACHE_HOME=str(cache / 'xdg'), TRITON_CACHE_DIR=str(cache / 'triton'),
                   TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'), VLLM_CACHE_ROOT=str(cache / 'vllm'))
        command = ['bash', str(HERE / 'runtime_collective_graph.sh'), str(HERE / 'collective_graph_worker.py'),
                   '--plan', str(args.plan.resolve()), '--output', str(output)]
        with (output / 'worker.log').open('x') as log:
            child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            record.update(status='running', child_pid=child.pid)
            (output / 'receipt.json').write_text(json.dumps(record, indent=2))
            deadline = time.monotonic() + 7200
            while child.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Calibration deadline exceeded')
                raw = lifecycle.runtime.npu_info(observe)
                observe(dict(wall=time.time(), npu=raw))
                for line in raw.splitlines():
                    match = re.match(r'\|\s*(?:0|1|6|7)\s+0\s*\|\s*(\d+)\s*\|', line)
                    if match and Path(f'/proc/{match[1]}').exists():
                        if not lifecycle.runtime.owned(int(match[1]), {child.pid}):
                            raise RuntimeError('Foreign device load detected')
                time.sleep(2)
            record['worker_exit_code'] = child.returncode
            if child.returncode != 0:
                raise RuntimeError('Graph worker failed; no eager fallback')
            for rank in (0, 1):
                result = json.loads((output / f'rank-{rank}.json').read_text())
                if result['status'] != 'collected_pending_joint_audit' or result['completed_shapes'] != 75:
                    raise RuntimeError('Incomplete rank result')
            record['status'] = 'collected_pending_joint_audit'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['sessions_drained'] = child is None
        if child is not None:
            try:
                record['cleanup_exit_code'] = lifecycle.runtime.stop(child)
                wait_session_drained(child.pid, timeout=180, observe=observe)
                record['sessions_drained'] = True
            except BaseException as error:
                record['cleanup_error'] = str(error)
        if created_output:
            try:
                deadline = time.monotonic() + 120
                while True:
                    raw = lifecycle.runtime.npu_info(observe)
                    record['all_devices_released'] = all(f'No running processes found in NPU {i}' in raw for i in DEVICES)
                    if record['all_devices_released'] or time.monotonic() >= deadline:
                        break
                    time.sleep(2)
                (output / 'npu-after.txt').write_text(raw)
            except BaseException as error:
                record.update(all_devices_released=False, observation_error=str(error))
            record['ended'] = time.time()
            (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
            lifecycle.seal_if_released(output, record)
        for stream in locks:
            stream.close()
    print(json.dumps(record))
    return 0 if record['status'] == 'collected_pending_joint_audit' and record.get('all_devices_released') and record['sessions_drained'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
