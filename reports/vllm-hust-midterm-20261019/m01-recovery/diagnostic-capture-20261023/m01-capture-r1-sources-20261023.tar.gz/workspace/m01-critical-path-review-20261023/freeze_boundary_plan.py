"""Freeze identities for a boundary-only supplement, without starting devices."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--ready', action='store_true', help='Mark reviewed plan ready for device admission, not successful measurement')
    parser.add_argument('--preflight', type=Path, default=HERE / 'boundary-b1-import-preflight-r2.json')
    args = parser.parse_args()
    preflight_path = args.preflight.resolve()
    preflight = json.loads(preflight_path.read_text())
    if preflight['status'] != 'passed' or preflight['service_started']:
        raise ValueError('Expected successful CPU-only preflight')
    sources = {path for path in HERE.glob('*.py')}
    sources.update([HERE / 'runtime_boundary_b1.sh', preflight_path,
        ROOT / 'materialized.200.jsonl', ROOT / 'manager-recovery-r2/manager.json',
        ROOT / 'mmlu-b1-microflow-fa-on-r10/launch-command.json',
        ROOT / 'build/libbs_gdn_host_cann91.so',
        ROOT / 'recovery-fia-build-r1/artifact/libbs_fia_cp.so',
        ROOT / 'v018-runtime-recovery-20261022/run_quality018_r2.py',
        Path('/root/gennova-runtime/betterscale-dist/extracted/vllm_betterscale-0.5.1/src/betterscale/patches/qwen_gdn/libbs_gdn.so'),
        Path('/root/gennova-evidence/20261023-outline-v527/vLLM-HUST-midterm-V5.27.docx')])
    roots = [ROOT / name for name in ('microflow-recovery-payload-r2', 'kvmat-managed-payload-r1',
        'recovery-model-payload-r1', 'runtime', 'compat', 'runtime-lifecycle-r3')]
    roots.extend([Path('/root/extension-manager/src'),
        Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm')])
    for root in roots:
        if not root.is_dir():
            raise ValueError(f'Missing runtime source tree: {root}')
        sources.update(path for path in root.rglob('*') if path.is_file()
                       and path.suffix in ('.py', '.json', '.so') and '__pycache__' not in path.parts)
    for row in preflight['modules'].values():
        path = Path(row['path'])
        if digest(path) != row['sha256']:
            raise ValueError('Module changed since import preflight')
        sources.add(path)
    for name in ('config.json', 'tokenizer_config.json', 'model.safetensors.index.json'):
        sources.add(Path('/models/Qwen3.5-35B-A3B') / name)
    checkpoint_path = ROOT / 'm01-recovery-model-worker-r1/checkpoint-cache-pre-request.json'
    checkpoint = json.loads(checkpoint_path.read_text())
    model = Path(checkpoint['model_directory'])
    if digest(model / 'model.safetensors.index.json') != checkpoint['index_sha256']:
        raise ValueError('Checkpoint index changed')
    for row in checkpoint['files']:
        stat = (model / row['name']).stat()
        if (stat.st_size, stat.st_ino, stat.st_mtime_ns) != (row['size'], row['inode'], row['mtime_ns']):
            raise ValueError('Mounted checkpoint identity changed')
    sources.add(checkpoint_path)
    plan = dict(protocol='m01-boundary-supplement/v1', method='V5.27',
        status='frozen_for_execution' if args.ready else 'prepared_pending_controller_review_and_device_admission',
        output='/workspace/m01-boundary-b1-r1', cache='/workspace/m01-boundary-b1-r1-cache',
        participating=[0, 1], reserved=[0, 1, 6, 7],
        benchmark_args=preflight['benchmark_args'], benchmark_sha256=preflight['benchmark_sha256'],
        source_sha256={str(path): digest(path) for path in sorted(sources)},
        scope='Unprofiled synchronized timing supplement; not an effective-compute result',
        model_weight_identity=dict(evidence=str(checkpoint_path), directory=str(model),
            files=checkpoint['files'], index_sha256=checkpoint['index_sha256'],
            scope='Same mounted checkpoint continuity by index SHA and shard stat tuples; not a new full weight-content hash'),
        effective_flops=None, efficiency_percent=None)
    with args.output.open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=plan['status'], pinned_files=len(sources),
                          plan_sha256=digest(args.output), device_started=False)))


if __name__ == '__main__':
    main()
