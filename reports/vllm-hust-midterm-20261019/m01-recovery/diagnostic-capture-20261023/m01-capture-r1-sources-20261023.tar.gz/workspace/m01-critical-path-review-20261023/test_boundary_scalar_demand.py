import unittest
from derive_boundary_scalar_demand import demand


class ScalarDemandTests(unittest.TestCase):
    def test_additive_request_arithmetic(self):
        one = demand([4], [3])
        two = demand([4, 4], [3, 3])
        self.assertEqual(two['positions'], 12)
        self.assertEqual(two['causal_pairs'], 42)
        self.assertEqual(two['basic_subtotal'], 2*one['basic_subtotal'])
        self.assertNotIn('gdn_prefill', two['basic_parts'])

    def test_no_decode_for_single_output(self):
        result = demand([4], [1])
        self.assertEqual(result['basic_parts']['gdn_decode_recurrence'], 0)

    def test_bad_extents_rejected(self):
        for inputs, outputs in [([], []), ([1], []), ([0], [1]), ([True], [1])]:
            with self.assertRaises(ValueError):
                demand(inputs, outputs)
