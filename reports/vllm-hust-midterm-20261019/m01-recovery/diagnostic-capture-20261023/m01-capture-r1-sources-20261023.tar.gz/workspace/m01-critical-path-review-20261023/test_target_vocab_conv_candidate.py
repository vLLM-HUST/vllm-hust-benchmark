import unittest
from derive_target_vocab_conv_candidate import convolution_counts, projection


class VocabConvTests(unittest.TestCase):
    def test_zero_history_taps(self):
        result = convolution_counts([1, 2, 4], channels=1, layers=1)
        self.assertEqual(result['convolution_multiply'], 1 + 3 + 10)
        self.assertEqual(result['convolution_add'], 0 + 1 + 6)

    def test_history_reset_per_request(self):
        split = convolution_counts([2, 2], channels=1, layers=1)
        joined = convolution_counts([4], channels=1, layers=1)
        self.assertLess(split['convolution_multiply'], joined['convolution_multiply'])

    def test_vocabulary_global_once(self):
        self.assertEqual(projection(1, [[124160, 2048], [124160, 2048]]), 2 * 248320 * 2048)
