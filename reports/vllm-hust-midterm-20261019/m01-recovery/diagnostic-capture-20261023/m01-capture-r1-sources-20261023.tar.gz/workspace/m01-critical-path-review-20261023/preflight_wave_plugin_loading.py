"""Exercise installed general-plugin discovery in the fixed runtime, no model load."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import tempfile


def main():
    here = Path(__file__).resolve().parent
    installed = here / 'wave-plugin-installed-r1'
    sys.path.insert(0, str(installed))
    original = 'hust_microflow_school028_fa'
    selected = os.environ['VLLM_PLUGINS'].split(',')
    if original not in selected:
        raise ValueError('Original Microflow plugin selection absent')
    selected = [name for name in selected if name != original] + ['hust_m01_wave_capture']
    os.environ['VLLM_PLUGINS'] = ','.join(selected)
    with tempfile.TemporaryDirectory(prefix='m01-plugin-preflight-', dir='/workspace') as temporary:
        root = Path(temporary)
        os.environ.update(HUST_M01_WAVE_CAPTURE='1', HUST_MICROFLOW_SCHOOL028_FA='1',
            HUST_M01_CAPTURE_RUN_ID='plugin-preflight', HUST_M01_CAPTURE_DIR=temporary,
            HUST_M01_CAPTURE_MAX_EVENTS='32', HUST_M01_CAPTURE_MAX_REQUESTS='8',
            HUST_MICROFLOW_CACHE_ROOT=str(root / 'cache'), HUST_MICROFLOW_EVENT_DIR=temporary,
            VLLM_CACHE_ROOT=str(root / 'cache/on/vllm'), TRITON_CACHE_DIR=str(root / 'cache/on/triton'),
            TORCHINDUCTOR_CACHE_DIR=str(root / 'cache/on/inductor'))
        from vllm.plugins import load_general_plugins
        load_general_plugins()
        import wave_capture_runtime as runtime
        import betterscale.qwen35_worker as worker
        import betterscale.models.qwen35.seat_scheduler as scheduler
        assert worker.Worker is runtime.CaptureWorker
        assert scheduler.LiveStateScheduler is runtime.CaptureScheduler
        entries = [e for e in importlib.metadata.entry_points(group='vllm.general_plugins')
                   if e.name == 'hust_m01_wave_capture']
        assert len(entries) == 1
        entries[0].load()()
        assert worker.Worker is runtime.CaptureWorker
        assert scheduler.LiveStateScheduler is runtime.CaptureScheduler
        import torch
        result = dict(status='installed_general_plugin_loading_passed', model_loaded=False,
            npu_context_initialized=torch.npu.is_initialized(), explicit_composition_order=['microflow', 'capture'],
            selected_plugins=selected, entrypoint=entries[0].value,
            public_worker_alias='betterscale.qwen35_worker.Worker',
            public_scheduler_alias='betterscale.models.qwen35.seat_scheduler.LiveStateScheduler',
            worker_implementation=runtime.CaptureWorker.__module__ + '.' + runtime.CaptureWorker.__name__,
            scheduler_implementation=runtime.CaptureScheduler.__module__ + '.' + runtime.CaptureScheduler.__name__,
            repeated_registration_preserved_aliases=True, device_qualification=False,
            effective_flops=None, m01_attainment=None,
            source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                (Path(__file__), here / 'wave_capture_runtime.py', installed / 'm01_capture_plugin.py',
                 installed / 'hust_m01_wave_capture-0.0.1.dist-info/entry_points.txt')})
    with (here / 'wave-plugin-loading-preflight-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k,v in result.items() if k != 'source_sha256'}))


if __name__ == '__main__':
    main()
