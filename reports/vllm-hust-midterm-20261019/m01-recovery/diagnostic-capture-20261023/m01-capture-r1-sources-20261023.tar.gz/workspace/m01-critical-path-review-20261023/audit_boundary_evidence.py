"""Read-only final audit of a sealed B1 synchronized timing supplement."""
import argparse
import hashlib
import json
import math
from pathlib import Path

from audit_boundary_mods import audit as audit_mods
from run_boundary_b1 import check_result


def verify_seal(root):
    root = Path(root).resolve()
    sealed = {}
    for line in (root / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = (root / name).resolve()
        if name in sealed or not path.is_relative_to(root):
            raise ValueError('Duplicate or escaping sealed path')
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Seal mismatch: {name}')
        sealed[name] = digest
    required = {'receipt.json', 'execution-plan.json', 'launch-command.json',
        'compiler-cache-initialization.json', 'boundary.jsonl', 'mmlu-pro.json',
        'kvmat-engine.jsonl', 'kvmat-policy.jsonl', 'npu-before.txt', 'npu-after.txt',
        'service.log', 'bench.log', 'monitor.jsonl'}
    required.update(p.name for p in root.glob('microflow-*.jsonl'))
    if not required <= sealed.keys():
        raise ValueError('Required evidence omitted from seal')
    return sealed


def check_details(result):
    for name in ('input_lens', 'output_lens', 'start_times', 'ttfts', 'itls', 'errors'):
        if len(result.get(name, [])) != 200:
            raise ValueError(f'Incomplete detailed request field: {name}')
    if sum(result['input_lens']) != 282265 or any(x != 256 for x in result['output_lens']):
        raise ValueError('Per-request token totals differ from fixed workload')
    if any(result['errors']):
        raise ValueError('Request errors present')
    for name in ('start_times', 'ttfts'):
        if any(type(x) not in (int, float) or not math.isfinite(x) or x < 0 for x in result[name]):
            raise ValueError('Invalid per-request timing')


def same_json_record(stored, calculated):
    return stored == json.loads(json.dumps(calculated, allow_nan=False))


def audit(root):
    root = Path(root).resolve()
    sealed = verify_seal(root)
    receipt = json.loads((root / 'receipt.json').read_text())
    if (receipt.get('status') != 'collected_pending_audit' or receipt.get('client_exit_code') != 0
            or receipt.get('sessions_drained') is not True or receipt.get('all_devices_released') is not True):
        raise ValueError('Lifecycle not completed and released')
    plan = json.loads((root / 'execution-plan.json').read_text())
    if plan.get('status') != 'frozen_for_execution' or plan.get('participating') != [0, 1]:
        raise ValueError('Unexpected admitted plan')
    cache = json.loads((root / 'compiler-cache-initialization.json').read_text())
    if cache.get('initial_entries') != [] or cache.get('destination') != plan['cache']:
        raise ValueError('Cache initialization does not match plan')
    result = json.loads((root / 'mmlu-pro.json').read_text())
    check_details(result)
    measurement = check_result(root)
    mods = audit_mods(root)
    if not same_json_record(receipt['measurement'], measurement) or not same_json_record(receipt['mod_control'], mods):
        raise ValueError('Final evidence differs from controller audit')
    boundary = json.loads((root / 'boundary.jsonl').read_text())
    if boundary['benchmark_source_sha256'] != plan['benchmark_sha256']:
        raise ValueError('Benchmark source does not match plan')
    return dict(status='sealed_synchronized_B1_measurement_audited', measurement=measurement,
        mod_control=mods, participating_chips=2,
        scope='Fixed MMLU-Pro 200-request timing supplement; no quality or effective-compute verdict',
        limitations=['Synchronized duration includes end pause/drain/RPC overhead; none subtracted.',
                     'Effective work and independent reference must be mapped before M01 evaluation.'],
        source_sha256={str(root / name): digest for name, digest in sealed.items()},
        seal_sha256=hashlib.sha256((root / 'SHA256SUMS').read_bytes()).hexdigest(),
        audit_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        effective_flops=None, reference_seconds=None, efficiency_percent=None, m01_attainment=None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve().is_relative_to(args.run.resolve()):
        raise ValueError('Derived audit must not modify sealed evidence')
    result = audit(args.run)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=result['status'], measurement=result['measurement'])))


if __name__ == '__main__':
    main()
