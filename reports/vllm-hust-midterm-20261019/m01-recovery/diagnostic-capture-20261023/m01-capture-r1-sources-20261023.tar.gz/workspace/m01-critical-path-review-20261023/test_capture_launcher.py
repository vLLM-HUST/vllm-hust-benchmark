from pathlib import Path
import sys

import pytest

import launch_capture_b1 as launcher


def test_preserves_all_serving_arguments_and_manager_plugin_selection(monkeypatch):
    arguments = ['serve', '/model', '--tensor-parallel-size', '2']
    monkeypatch.setenv('PYTHONPATH', '/fixed/runtime')
    monkeypatch.setattr(launcher, 'prepare_command', lambda out, cache: (
        [sys.executable, '-m', 'vllm.entrypoints.cli.main', *arguments,
         '--worker-extension-cls', 'synchronized_boundary.WorkerBoundary'],
        {'VLLM_PLUGINS': 'ascend,hust_microflow_school028_fa'}, Path('/original')))
    command, env, original = launcher.prepare(Path('/out'), Path('/cache'), 'capture-r1')
    assert command[2:] == arguments
    assert env['VLLM_PLUGINS'] == 'ascend,hust_microflow_school028_fa'
    assert env['HUST_M01_CAPTURE_MAX_REQUESTS'] == '256'
    assert env['PYTHONPATH'].endswith(':/fixed/runtime')
    assert env['HUST_M01_CAPTURE_DIR'] == '/out'
    assert original == Path('/original')


def test_nested_cache_rejected():
    with pytest.raises(ValueError, match='independent'):
        launcher.prepare(Path('/out'), Path('/out/cache'), 'capture-r1')
