"""Count explicit target replays without treating wrapper logs as device events."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = Path('/root/gennova-evidence/20261019-midterm-aligned')
RUN = EVIDENCE / 'm01-recovery-model-worker-r1'
PREFIX = 'microflow-recovery-payload-r2/hust_prefill_microflow/'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    receipt = json.loads((RUN / 'receipt.json').read_text())
    sources = {}
    for suffix in ('runtime/microflow.py', 'runtime/microflow_streams.py', 'school028/worker.py'):
        key = PREFIX + suffix
        path = EVIDENCE / key
        actual = sha(path)
        if receipt['input_hashes'].get(key) != actual:
            raise ValueError('Frozen source mismatch: ' + key)
        sources[key] = actual
    tree = ast.parse((EVIDENCE / (PREFIX + 'runtime/microflow.py')).read_text())
    partition = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'partition')
    assignment = next(n for n in partition.body if isinstance(n, ast.Assign))
    pieces = ast.literal_eval(assignment.value.func.value)
    if not isinstance(pieces, dict) or any(type(k) is not int or type(v) is not int for k, v in pieces.items()):
        raise ValueError('Unexpected split policy')
    lo, hi = receipt['bench_started_wall'], receipt['bench_ended_wall']
    rows = []
    for path in sorted(RUN.glob('microflow-*.jsonl')):
        target, other = Counter(), Counter()
        outside = 0
        for line in path.open():
            event = json.loads(line)
            if event['event'] != 'graph_replay':
                continue
            if not lo <= event['time'] <= hi:
                outside += 1
                continue
            if event.get('target') is True and event.get('draft') is False:
                target[event['tokens']] += 1
            else:
                other[event['tokens']] += 1
        rows.append({'log': path.name, 'sha256': sha(path),
                     'explicit_target_by_tokens': dict(sorted(target.items())),
                     'other_wrappers_by_tokens': dict(sorted(other.items())),
                     'target_replays_at_split_sizes': sum(n for tokens, n in target.items() if tokens in pieces),
                     'outside_client_wall_interval': outside})
    result = {'sources': sources, 'partition_policy': pieces, 'worker_logs': rows,
              'scope': 'Host graph-replay receipts inside client wall bounds, not per-layer device execution counts',
              'join_rule': 'Helper streams wait on caller at entry; caller waits on all helper streams at exit.',
              'limitations': ['Unknown-wrapper records are not relabeled as target or draft.',
                              'Eligible replay shape does not alone prove every layer took the admitted branch.',
                              'No device graph-ID, stage-duration or collective matching is inferred.'],
              'critical_path_seconds': None, 'efficiency_percent': None}
    with (ROOT / 'microflow-replay-review-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'target_replays_at_split_sizes': [r['target_replays_at_split_sizes'] for r in rows],
                      'source_count': len(sources), 'efficiency_percent': None}))


if __name__ == '__main__':
    main()
