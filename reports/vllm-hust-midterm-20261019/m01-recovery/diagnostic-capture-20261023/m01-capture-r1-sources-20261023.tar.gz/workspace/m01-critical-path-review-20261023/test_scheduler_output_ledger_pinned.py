"""Execute pinned native trim methods on CPU, without importing the NPU stack."""
import ast
import hashlib
from pathlib import Path
from types import SimpleNamespace as NS

from scheduler_output_ledger import SchedulerOutputLedger

BASE = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/v1/core/sched')


def native_classes():
    methods = []
    specs = [('scheduler.py', 'Scheduler',
              '50e7cea25eea05fa192bdd99f30e990f45c499eb327c42b247bf61220d7b64b7'),
             ('async_scheduler.py', 'AsyncScheduler',
              'e586a0ef3c6778be56a93e7f9bb712d4de9de6e7d7fe7e3e1d51dae83ecfc508')]
    for filename, name, expected in specs:
        raw = (BASE / filename).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        cls = next(n for n in ast.parse(raw).body if isinstance(n, ast.ClassDef) and n.name == name)
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef)
                      and n.name == '_update_request_with_output')
        base = ast.parse(f'class {name}({"object" if name == "Scheduler" else "Scheduler"}): pass').body[0]
        base.body = [method]
        methods.append(base)
    namespace = dict(Request=object, RequestStatus=NS(RUNNING='running'),
                     check_stop=lambda request, maximum: len(request._output_token_ids) >= request.limit)
    exec(compile(ast.fix_missing_locations(ast.Module(body=methods, type_ignores=[])),
                 '<pinned-native-output-methods>', 'exec'), namespace)
    return namespace['AsyncScheduler']


def test_pinned_async_native_trimming_and_placeholders():
    Native = native_classes()
    class Driver(Native):
        num_sampled_tokens_per_step = 1
        max_model_len = 65536
        def update_from_output(self, schedule, output):
            return self._update_request_with_output(*output)
    class Observed(SchedulerOutputLedger, Driver):
        pass
    for limit in (1, 2, 3):
        cached = []
        s = Observed()
        s.kv_cache_manager = NS(cache_blocks=lambda request, cursor: cached.append(cursor))
        s.enable_output_ledger(max_events=16, max_requests=1)
        request = NS(request_id='request', status='running', _output_token_ids=[],
                     num_output_placeholders=3, num_computed_tokens=10, limit=limit)
        request.append_output_token_ids = request._output_token_ids.append
        sched = NS(num_scheduled_tokens={'request': 3},
                   scheduled_spec_decode_tokens={'request': [10, 11]})
        result = s.update_from_output(sched, (request, [10, 11, 12]))
        assert result == ([10, 11, 12][:limit], True)
        assert request.num_output_placeholders == 3-limit
        assert cached == [7+limit]
        ledger = s.output_ledger_snapshot()
        row = next(e for e in ledger['events'] if e['event'] == 'output_update')
        assert row['observation']['retained_drafts'] == min(2, limit)
        assert ledger['retained_count_complete']
