"""Audit actual activation/control events; counts include service qualification."""
import hashlib
import json
from pathlib import Path


def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def audit(output):
    ranks = {}
    for path in sorted(Path(output).glob('microflow-*.jsonl')):
        events = rows(path)
        loaded = [row for row in events if row.get('event') == 'model_loaded']
        if len(loaded) != 1 or loaded[0].get('active') is not True:
            raise ValueError('Missing active Microflow worker')
        rank = loaded[0].get('rank')
        if type(rank) is not int or rank not in (0, 1) or rank in ranks:
            raise ValueError('Invalid or duplicate Microflow rank')
        equivalence = [row for row in events if row.get('event') == 'partition_equivalence']
        if {row['tokens'] for row in equivalence} != {1024, 2048, 4096}:
            raise ValueError('Incomplete Microflow partition qualification')
        if any(row.get('rank') != rank or row.get('exact') != [True] * 5 for row in equivalence):
            raise ValueError('Microflow numerical equivalence failed')
        split = sum(row.get('event') == 'prefix' and row.get('split') is True for row in events)
        replay = sum(row.get('event') == 'graph_replay' and row.get('active') is True
                     and row.get('target') is True and row.get('speculative_enabled') is True for row in events)
        if not split or not replay:
            raise ValueError('Microflow not exercised or target MTP graph not replayed')
        ranks[rank] = dict(split_prefix_events=split, target_mtp_graph_replays=replay)
    if set(ranks) != {0, 1}:
        raise ValueError('Both Microflow ranks required')
    policies = rows(Path(output) / 'kvmat-policy.jsonl')
    admissions = rows(Path(output) / 'kvmat-engine.jsonl')
    salts = {}
    for row in policies:
        if (row.get('runtime_control_path') != 'request_scoped_prefix_cache_bypass'
                or row.get('runtime_effective_decision') != 'recompute'
                or row.get('runtime_decision_supported') is not True
                or row.get('reused_tokens') != 0):
            raise ValueError('Unexpected KV materialization action')
        salt = hashlib.sha256(row['runtime_cache_salt'].encode()).hexdigest()
        if salt in salts:
            raise ValueError('Duplicate request-scoped salt')
        salts[salt] = row['prompt_tokens']
    admitted = {}
    for row in admissions:
        if row.get('event') != 'school028_request_salt_admitted':
            raise ValueError('Unexpected KV engine event')
        salt = row['cache_salt_sha256']
        if salt in admitted:
            raise ValueError('Duplicate engine admission')
        admitted[salt] = row['prompt_tokens']
    if len(salts) < 200 or salts != admitted:
        raise ValueError('Policy/engine admission linkage incomplete')
    return dict(status='exercised', microflow=ranks,
        kvmat=dict(request_scoped_recompute_admissions=len(salts), reused_tokens=0,
                   scope='Actual recompute/bypass action; not a cache-hit benefit'),
        count_scope='Whole service run including qualification/warmup; not window-only FLOP counts',
        effective_flops=None, efficiency_percent=None)
