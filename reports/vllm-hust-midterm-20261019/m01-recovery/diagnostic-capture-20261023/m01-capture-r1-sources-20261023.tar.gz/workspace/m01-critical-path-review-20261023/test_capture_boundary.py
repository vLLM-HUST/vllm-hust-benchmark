import asyncio
import json

import pytest

from capture_boundary import CaptureBoundary, diagnostic_record, verify_exports
from capture_export import export_snapshot
from test_synchronized_boundary import fences


def files(directory):
    receipts = []
    for rank in (0, 1):
        snapshot = dict(rank=rank, pid=100+rank, host='host', run_id='capture-r1',
                        complete=True, errors=0, dropped=0, pending=False,
                        measurement_role='diagnostic_qualification')
        receipts.append(export_snapshot(directory, f'worker-{100+rank}.json', snapshot))
    return dict(results=receipts)


def test_export_only_after_drain_and_end_fences(tmp_path):
    calls = []
    async def post(path, payload):
        calls.append((path, payload))
        if payload and payload['method'] == 'hust_m01_export_wave_capture':
            assert calls[-2][1]['args'] == ['end']
            return files(tmp_path)
        return fences(payload['args'][0]) if payload else {
            'status': 'resumed' if path == '/resume' else 'paused'}
    boundary = CaptureBoundary(post, tmp_path, 'capture-r1')
    async def run():
        await boundary.begin()
        await boundary.end()
    asyncio.run(run())
    assert boundary.state == 'completed'
    assert len(boundary.export_receipts) == 2
    result = diagnostic_record(dict(protocol='m01-unprofiled-client-synchronized-boundary/v1'), boundary)
    assert result['protocol'] == 'm01-diagnostic-capture-boundary/v1'
    assert not result['performance_acceptance']
    assert not result['scheduler_export_verified']
    assert calls[-1][0] == '/collective_rpc'
    assert len([c for c in calls if c[0] == '/resume']) == 1


@pytest.mark.parametrize('fault', ['missing', 'duplicate', 'hash', 'bytes', 'run', 'identity', 'incomplete', 'symlink'])
def test_unusable_export_rejected(tmp_path, fault):
    response = files(tmp_path)
    identity = {r: (100+r, 'host', f'npu:{r}') for r in (0, 1)}
    run = 'capture-r1'
    if fault == 'missing': response['results'].pop()
    elif fault == 'duplicate': response['results'][1] = response['results'][0]
    elif fault == 'hash': response['results'][0]['sha256'] = 'wrong'
    elif fault == 'bytes': response['results'][0]['bytes'] += 1
    elif fault == 'run': run = 'other'
    elif fault == 'identity': identity[0] = (100, 'otherhost', 'npu:0')
    elif fault == 'incomplete': response['results'][0]['capture_complete'] = False
    elif fault == 'symlink':
        file = tmp_path / 'worker-100.json'
        file.rename(tmp_path / 'original.json')
        file.symlink_to(tmp_path / 'original.json')
    with pytest.raises(ValueError):
        verify_exports(response, tmp_path, identity, run)


def test_export_failure_never_leaves_completed_state(tmp_path):
    async def post(path, payload):
        if payload and payload['method'] == 'hust_m01_export_wave_capture':
            return {'results': []}
        return fences(payload['args'][0]) if payload else {
            'status': 'resumed' if path == '/resume' else 'paused'}
    boundary = CaptureBoundary(post, tmp_path, 'capture-r1')
    async def run():
        await boundary.begin()
        await boundary.end()
    with pytest.raises(ValueError):
        asyncio.run(run())
    assert boundary.state == 'exporting'
    with pytest.raises(ValueError):
        diagnostic_record(dict(protocol='m01-unprofiled-client-synchronized-boundary/v1'), boundary)
