"""Bind draft input/sampling semantics and bound only retained output projections."""
import ast
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
sys.path.insert(0, str(ROOT))
from audit_vocab_projection_recovery_model_worker_r1 import projection


def method_lines(source, names):
    tree = ast.parse(source)
    found = {n.name: [n.lineno, n.end_lineno] for n in ast.walk(tree)
             if isinstance(n, ast.FunctionDef) and n.name in names}
    if set(found) != set(names):
        raise ValueError('Missing required draft methods')
    return found


def build():
    here = Path(__file__).resolve().parent
    hashes = {}

    def read(path, expected=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f'Source mismatch: {path}')
        hashes[str(path)] = digest
        return raw

    summary = json.loads(read(ROOT / 'vocab-projection-summary-recovery_model_worker_r1.json'))
    for path, digest in summary['source_sha256'].items():
        read(Path(path), digest)
    proposer = ROOT / 'runtime/vllm_ascend/spec_decode/llm_base_proposer.py'
    assert str(proposer) in summary['source_sha256']
    source = read(proposer, summary['source_sha256'][str(proposer)]).decode()
    locations = method_lines(source, {'set_inputs_first_pass', '_run_merged_draft', 'prepare_inputs_padded'})
    for expression in ('self.hidden_states[:num_tokens] = target_hidden_states.view(num_tokens, -1)',
                       'sample_hidden_states = last_hidden_states[token_indices_to_sample]',
                       'model_hidden_states = self.hidden_states[:num_input_tokens]'):
        assert expression in source
    bounds = json.loads(read(here / 'terminal-draft-acceptance-bounds-r1.json'))
    for path, digest in bounds['source_sha256'].items():
        read(Path(path), digest)
    shapes = [r['loaded_head_shapes']['draft'] for r in summary['ranks']]
    low = bounds['useful_accepted_draft_tokens_lower']
    high = bounds['useful_accepted_draft_tokens_upper']
    read(Path(__file__))
    return dict(status='draft_scope_source_bound_retained_vocabulary_interval_only',
        proposer_method_lines=locations,
        retained_draft_vocab_rows_lower=low, retained_draft_vocab_rows_upper=high,
        retained_draft_vocab_flops_lower=projection(low, shapes),
        retained_draft_vocab_flops_upper=projection(high, shapes),
        effective_flops=None, efficiency_percent=None, source_sha256=hashes,
        findings=[
            'The first draft model pass consumes input-position hidden states before selecting per-request rows for logits.',
            'A retained draft token count cannot replace first-pass context rows or attention pairs.',
            'The output-only vocabulary interval inherits terminal-clipping assumptions; it does not certify total useful draft work.',
            'Source binding proves the pinned implementation, not which conditional branches ran on each request.'],
        unresolved=[
            'Map draft first-pass context/cache rows and later-step attention pairs to retained outputs.',
            'Separate necessary reusable context preparation from rejected/terminal work without blanket scaling.',
            'Bind terminal sampler ordering to actual runtime identity, or recover exact final raw outputs.',
            'If existing captures cannot resolve this mapping, collect only the missing per-step map in an isolated matched run.'])


if __name__ == '__main__':
    result = build()
    with Path(__file__).with_name('useful-draft-scope-audit-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('status','retained_draft_vocab_flops_lower','retained_draft_vocab_flops_upper')}))
