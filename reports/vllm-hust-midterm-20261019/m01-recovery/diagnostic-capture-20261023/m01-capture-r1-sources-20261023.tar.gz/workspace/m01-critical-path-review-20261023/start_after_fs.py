"""Start one visible continuation controller with a durable PID identity."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

from continue_after_fs import HERE, FS_START, FS_RECEIPT, process_live, dependency_state


def main():
    output = Path('/workspace/m01-post-fs-continuation-r1')
    receipt_path = HERE / 'post-fs-continuation-start-r1.json'
    log_path = HERE / 'post-fs-continuation-r1.log'
    if any(p.exists() for p in (output, receipt_path, log_path)):
        raise FileExistsError('Continuation already created; inspect it instead of restarting')
    start = json.loads(FS_START.read_text())
    state = dependency_state(start, json.loads(FS_RECEIPT.read_text()),
                             process_live(start['pid'], start['start_ticks']))
    environment = dict(HOME='/root', LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1',
        PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        LD_LIBRARY_PATH='/usr/local/Ascend/driver/lib64/driver:/usr/local/Ascend/driver/lib64/common')
    for command in [
        [sys.executable, str(HERE / 'run_collective_graph.py'), '--plan',
         str(HERE / 'collective-graph-execution-plan-r1.json'), '--output', '/workspace/m01-collective-graph-r1', '--check'],
        [sys.executable, str(HERE / 'run_boundary_b1.py'), '--plan', str(HERE / 'boundary-execution-plan-r6.json'), '--check']]:
        subprocess.run(command, env=environment, check=True)
    with log_path.open('x') as log:
        child = subprocess.Popen([sys.executable, str(HERE / 'continue_after_fs.py'), '--output', str(output)],
            env=environment, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    fields = Path(f'/proc/{child.pid}/stat').read_text().rsplit(')', 1)[1].split()
    record = dict(pid=child.pid, start_ticks=fields[19], started=time.time(),
        initial_dependency_state=state, output=str(output), log=str(log_path),
        source_sha256={str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (
            Path(__file__), HERE / 'continue_after_fs.py', FS_START,
            HERE / 'collective-graph-execution-plan-r1.json', HERE / 'boundary-execution-plan-r6.json')},
        status='controller_started_not_measurement_complete')
    with receipt_path.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
