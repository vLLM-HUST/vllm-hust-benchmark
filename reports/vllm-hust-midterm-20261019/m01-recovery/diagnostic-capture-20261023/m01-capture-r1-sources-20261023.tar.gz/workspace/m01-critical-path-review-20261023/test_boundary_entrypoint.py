import argparse
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import run_boundary_benchmark as entry


def arguments():
    return argparse.Namespace(base_url='http://127.0.0.1:18390',
        backend='openai-chat', endpoint='/v1/chat/completions', num_prompts=200,
        custom_output_len=256, request_rate=float('inf'), temperature=0,
        seed=0, disable_shuffle=True, save_result=True, save_detailed=True,
        num_warmups=0, profile=False)


class EntryTests(unittest.TestCase):
    def test_wrong_endpoint_rejected(self):
        args = arguments()
        args.base_url = 'http://example.com:18390'
        with self.assertRaises(ValueError):
            entry.validate_args(args, 18390)

    def test_failure_persisted_without_claiming_success(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'receipt.jsonl'
            with patch.object(entry, 'install', side_effect=ValueError('hash mismatch')):
                with self.assertRaises(ValueError):
                    entry.execute(None, arguments(), 18390, 'invalid', path)
            record = json.loads(path.read_text())
            self.assertEqual(record['state'], 'new')
            self.assertIsNone(record['efficiency_percent'])
            self.assertEqual(record['exception_type'], 'ValueError')

    def test_existing_receipt_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'receipt.jsonl'
            path.touch()
            with patch.object(entry, 'install') as install:
                with self.assertRaises(FileExistsError):
                    entry.execute(None, arguments(), 18390, 'unused', path)
                install.assert_not_called()


if __name__ == '__main__':
    unittest.main()
