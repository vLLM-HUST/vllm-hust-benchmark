"""Optional future boundary anchors; never retrofit old measurement receipts."""
import os
import socket
import time

from synchronized_boundary import ClientBoundary, WorkerBoundary


def capture_anchor():
    perf_before = time.perf_counter_ns()
    mono_before = time.monotonic_ns()
    wall = time.time_ns()
    mono_after = time.monotonic_ns()
    perf_after = time.perf_counter_ns()
    return dict(protocol='m01-clock-bracket/v1', host=socket.gethostname(),
                pid=os.getpid(), wall_ns=wall,
                monotonic_before_ns=mono_before, monotonic_after_ns=mono_after,
                perf_before_ns=perf_before, perf_after_ns=perf_after)


def offset_interval(anchor, clock):
    if clock not in ('perf', 'monotonic'):
        raise ValueError('Explicit clock domain required')
    if anchor.get('protocol') != 'm01-clock-bracket/v1':
        raise ValueError('Unsupported anchor protocol')
    fields = ('wall_ns', f'{clock}_before_ns', f'{clock}_after_ns')
    if any(type(anchor.get(k)) is not int or anchor[k] < 0 for k in fields):
        raise ValueError('Nonnegative integer nanosecond readings required')
    wall, before, after = (anchor[k] for k in fields)
    if after < before:
        raise ValueError('Reversed clock bracket')
    if not anchor.get('host') or type(anchor.get('pid')) is not int or anchor['pid'] <= 0:
        raise ValueError('Missing anchor identity')
    return wall-after, wall-before


def clock_offset_envelope(begin, end, clock, *, max_drift_ns):
    """Conditional envelope: endpoints cannot rule out an interior wall-clock jump."""
    if type(max_drift_ns) is not int or max_drift_ns < 0:
        raise ValueError('Explicit nonnegative drift allowance required')
    low0, high0 = offset_interval(begin, clock)
    low1, high1 = offset_interval(end, clock)
    if (begin['host'], begin['pid']) != (end['host'], end['pid']):
        raise ValueError('Anchor process changed')
    if end[f'{clock}_before_ns'] < begin[f'{clock}_after_ns']:
        raise ValueError('Overlapping or reversed measurement anchors')
    distance = max(0, low1-high0, low0-high1)
    if distance > max_drift_ns:
        raise ValueError('Clock offset change exceeds declared tolerance')
    return dict(clock=clock, offset_min_ns=min(low0, low1)-max_drift_ns,
                offset_max_ns=max(high0, high1)+max_drift_ns,
                max_drift_ns=max_drift_ns,
                limitation='Conditional on no unobserved interior clock excursion; prefer same-clock event timestamps.')


class DualClockClientBoundary(ClientBoundary):
    async def call(self, path, payload=None):
        before = capture_anchor()
        response = await super().call(path, payload)
        self.calls[-1]['clock_before'] = before
        self.calls[-1]['clock_after'] = capture_anchor()
        return response


class DualClockWorkerBoundary(WorkerBoundary):
    def hust_m01_sync_boundary(self, phase):
        before = capture_anchor()
        result = super().hust_m01_sync_boundary(phase)
        result['clock_before'] = before
        result['clock_after'] = capture_anchor()
        return result
