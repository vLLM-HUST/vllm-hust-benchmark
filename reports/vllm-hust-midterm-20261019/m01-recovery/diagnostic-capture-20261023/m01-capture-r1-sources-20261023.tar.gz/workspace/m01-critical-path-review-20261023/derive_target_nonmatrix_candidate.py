"""Extend the conditional target ledger without promoting it to full-model F."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
sys.path.insert(0, str(ROOT))
from audit_norm_accounting import catalog
from derive_recovery_model_worker_r1_scalar import operations
from derive_r12_softmax_semantics import softmax_counts


def calculate(rows, pairs):
    norms = [e for e in catalog(rows, 0) if e['name'].startswith('target.')]
    scalar = operations(rows, 0)
    softmax = softmax_counts(pairs, rows, 16, 10)
    subtotals = {
        'normalization_residual_gate': sum(e['basic_arithmetic_subtotal'] for e in norms),
        'rope_moe_router_attention_gate': scalar['basic_subtotal'],
        'attention_softmax': sum(softmax[k] for k in
            ('score_scale_multiply', 'stability_subtract', 'denominator_add')),
    }
    return dict(norm_entries=norms, scalar=scalar, softmax=softmax,
                basic_subtotals=subtotals, basic_subtotal=sum(subtotals.values()))


def build():
    here = Path(__file__).resolve().parent
    hashes = {}

    def verify(path, expected=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError(f'Source identity mismatch: {path}')
        hashes[str(path)] = digest
        return raw

    candidate = json.loads(verify(here / 'target-useful-candidate-r1.json'))
    for name, digest in candidate['source_sha256'].items():
        verify(Path(name), digest)
    for name in ('norm', 'scalar'):
        ledger = json.loads(verify(ROOT / f'recovery_model_worker_r1-{name}-semantics.json'))
        for key in ('source_sha256', 'run_pinned_callsite_sha256'):
            for source, digest in ledger.get(key, {}).items():
                verify(Path(source), digest)
    for name in ('audit_norm_accounting.py', 'derive_recovery_model_worker_r1_scalar.py',
                 'audit_moe_scalar_sources.py', 'audit_rope_reference.py',
                 'audit_router_gate_reference.py', 'derive_r12_softmax_semantics.py'):
        verify(ROOT / name)
    verify(Path(__file__))
    rows, pairs = candidate['candidate_target_rows'], candidate['candidate_causal_pairs']
    counts = calculate(rows, pairs)
    return dict(status='conditional_target_nonmatrix_candidate_not_full_effective_flops',
                candidate_target_rows=rows, candidate_causal_pairs=pairs, **counts,
                target_matrix_subtotal=candidate['candidate_target_matrix_subtotal'],
                combined_target_partial_subtotal=candidate['candidate_target_matrix_subtotal'] + counts['basic_subtotal'],
                effective_flops=None, efficiency_percent=None, source_sha256=hashes,
                parent_matrix_limitations=candidate['limitations'],
                limitations=[s for s in candidate['limitations']
                             if not s.startswith('Includes only target projection')] + [
                    'This adds target RMS/residual/gates, RoPE, MoE scalar and canonical attention softmax only.',
                    'Draft, vocabulary projection, GDN recurrence/preprocessing and convolution remain excluded.',
                    'Special functions, division and comparison counts remain separate with no arbitrary FLOP conversion.',
                    'Semantic work is counted once globally, not once per TP rank; this is not physical instruction counting.',
                    'No timing or reference denominator is combined with this conditional partial numerator.'])


if __name__ == '__main__':
    result = build()
    with Path(__file__).with_name('target-nonmatrix-candidate-r2.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'basic_subtotals', 'combined_target_partial_subtotal')}))
