"""Record installed decoder fields without importing accelerator packages."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/usr/local/Ascend/cann/tools/profiler/profiler_tool/analysis')
FILES = (
    'profiling_bean/stars/acsq_task.py',
    'profiling_bean/stars/stars_common.py',
    'msparser/stars/log_base_parser.py',
    'profiling_bean/struct_info/api_data_bean.py',
    'profiling_bean/struct_info/event_data_bean.py',
    'msparser/api_event/api_event_parser.py',
    'msparser/data_struct_size_constant.py',
)


def main():
    result = {'scope': 'Installed parser source review; not a raw-format completeness proof',
              'sources': {}, 'classes': {}, 'critical_path_seconds': None}
    for name in FILES:
        path = SOURCE / name
        raw = path.read_bytes()
        result['sources'][name] = hashlib.sha256(raw).hexdigest()
        tree = ast.parse(raw.decode())
        for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
            if cls.name not in ('AcsqTask', 'ApiDataBean', 'EventDataBean'):
                continue
            fields = set()
            for method in cls.body:
                if isinstance(method, ast.FunctionDef) and method.name == '__init__':
                    for node in ast.walk(method):
                        if isinstance(node, ast.Assign):
                            for target in node.targets:
                                if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id == 'self':
                                    fields.add(target.attr)
            result['classes'][cls.name] = {'file': name, 'line': cls.lineno,
                                         'initialized_fields': sorted(fields)}
    if set(result['classes']) != {'AcsqTask', 'ApiDataBean', 'EventDataBean'}:
        raise ValueError('Unexpected parser layout')
    result['findings'] = [
        'AcsqTask exposes task/stream IDs and timing, not an explicit event handle with creation generation.',
        'ApiDataBean exposes API identity, thread and timing; it does not decode API call argument values.',
        'EventDataBean request_id/item_id must not be assumed to mean an ACL event handle without a verified mapping.',
        'LogBaseParser matches task start/end by task and stream; this is not a cross-stream dependency matching algorithm.',
        'No undocumented raw bytes or unused structure fields are assigned event semantics in this review.',
        'Source-proven mandatory model dependencies may support a partial reference without requiring a full recovered device DAG; their coverage still needs validation.'
    ]
    target = ROOT / 'parser-source-review-r1.json'
    with target.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result['classes'], indent=2))


if __name__ == '__main__':
    main()
