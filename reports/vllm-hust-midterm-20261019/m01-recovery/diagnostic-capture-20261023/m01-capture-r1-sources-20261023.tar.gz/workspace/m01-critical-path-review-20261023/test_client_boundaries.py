import unittest
from audit_client_boundaries import reconcile


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.data = dict(start_times=[10.] * 200, latencies=[2.] * 200, duration=2.01)
        self.receipt = dict(bench_started_monotonic=9., bench_ended_monotonic=14.)

    def test_valid(self):
        self.assertAlmostEqual(reconcile(self.data, self.receipt)['duration_minus_request_span_s'], .01)

    def test_invalid_duration(self):
        self.data['duration'] = 1
        with self.assertRaises(ValueError):
            reconcile(self.data, self.receipt)

    def test_outside(self):
        self.receipt['bench_ended_monotonic'] = 11
        with self.assertRaises(ValueError):
            reconcile(self.data, self.receipt)

    def test_nonfinite(self):
        self.data['latencies'][0] = float('nan')
        with self.assertRaises(ValueError):
            reconcile(self.data, self.receipt)


if __name__ == '__main__':
    unittest.main()
