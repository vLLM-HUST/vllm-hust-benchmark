"""Explicit Microflow-then-capture composition, default off."""
import importlib
import os


def register():
    flag = os.environ.get('HUST_M01_WAVE_CAPTURE', '0')
    if flag == '0':
        return
    if flag != '1':
        raise ValueError('Capture flag must be 0 or 1')
    plugins = set(os.environ.get('VLLM_PLUGINS', '').split(','))
    if 'hust_m01_wave_capture' not in plugins or 'hust_microflow_school028_fa' in plugins:
        raise ValueError('Select exactly the composed capture entrypoint, not both Microflow entries')
    if os.environ.get('HUST_MICROFLOW_SCHOOL028_FA') != '1':
        raise ValueError('Extension Manager must enable the original Microflow adapter')
    runtime = importlib.import_module('wave_capture_runtime')
    worker = importlib.import_module('betterscale.qwen35_worker')
    scheduler = importlib.import_module('betterscale.models.qwen35.seat_scheduler')
    if worker.Worker is runtime.CaptureWorker and scheduler.LiveStateScheduler is runtime.CaptureScheduler:
        return
    microflow = importlib.import_module('hust_prefill_microflow.school028')
    microflow.register()
    runtime.register()
