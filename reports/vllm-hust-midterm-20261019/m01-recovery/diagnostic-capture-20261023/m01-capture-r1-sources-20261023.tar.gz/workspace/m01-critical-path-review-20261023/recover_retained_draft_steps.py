"""Recover per-position retained MTP2 bounds without choosing terminal outcomes."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def bounds(epochs, excess):
    if type(excess) is not int or excess < 0:
        raise ValueError('Invalid aggregate truncation')
    before = Counter()
    finals = Counter()
    for epoch in epochs:
        steps = epoch['verification_steps']
        if not steps:
            raise ValueError('Missing verification history')
        values = [s['committed_outputs'] for s in steps]
        if any(type(v) is not int or v not in (1, 2, 3) for v in values):
            raise ValueError('Invalid MTP2 committed length')
        before.update(values[:-1])
        finals[values[-1]] += 1
    fixed_first = before[2] + before[3] + finals[2] + finals[3]
    fixed_second = before[3] + finals[3]
    feasible = []
    for raw_three_at_one in range(finals[1] + 1):
        for raw_two_at_one in range(finals[1] - raw_three_at_one + 1):
            raw_three_at_two = excess - 2 * raw_three_at_one - raw_two_at_one
            if 0 <= raw_three_at_two <= finals[2]:
                feasible.append((fixed_first + raw_three_at_one + raw_two_at_one,
                                 fixed_second + raw_three_at_two))
    if not feasible:
        raise ValueError('No feasible terminal assignment')
    return dict(nonterminal_committed_histogram=dict(before), final_committed_histogram=dict(finals),
                first_retained_lower=min(a for a, b in feasible),
                first_retained_upper=max(a for a, b in feasible),
                second_retained_lower=min(b for a, b in feasible),
                second_retained_upper=max(b for a, b in feasible),
                joint_total_lower=min(a+b for a, b in feasible),
                joint_total_upper=max(a+b for a, b in feasible),
                feasible_aggregate_assignments=len(feasible))


def main():
    here = Path(__file__).resolve().parent
    paths = [here / 'acceptance-epoch-reconstruction-r1.json',
             here / 'terminal-draft-acceptance-bounds-r1.json', Path(__file__)]
    epochs, terminal = [json.loads(p.read_text()) for p in paths[:2]]
    result = bounds(epochs['epochs'], terminal['aggregate_clipped_output_tokens'])
    assert result['joint_total_lower'] == terminal['useful_accepted_draft_tokens_lower']
    assert result['joint_total_upper'] == terminal['useful_accepted_draft_tokens_upper']
    result.update(status='conditional_per_draft_position_bounds_not_context_work',
        effective_flops=None, efficiency_percent=None,
        assumptions=terminal['assumptions'],
        limitations=['Position intervals are correlated; do not add independent endpoints.',
                     'A retained draft is not a count of all prerequisite context rows or attention pairs.',
                     'Sampler runtime identity and final raw outcomes remain unconfirmed.'],
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with (here / 'retained-draft-step-bounds-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
