"""Check collective calibration scope and provenance without executing NPU code."""
import ast
from collections import Counter
import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
JOINED = Path('/root/vllm-hust-benchmark/reports/vllm-hust-midterm-20261019/m01-recovery/worker-model-20261022/m01-worker-collective-reference-joined.json')


def operation_calls(source):
    tree = ast.parse(source)
    operations = [node for node in ast.walk(tree)
                  if isinstance(node, ast.FunctionDef) and node.name == 'operation']
    if len(operations) != 1:
        raise ValueError('Expected one calibration operation')
    return sorted({ast.unparse(node.func) for node in ast.walk(operations[0])
                   if isinstance(node, ast.Call)})


def main():
    hashes = {}

    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw

    joined = json.loads(read(JOINED))
    grouped = Counter()
    shapes = Counter()
    for row in joined['shapes']:
        source = row['reference']['source']
        grouped[source] += row['observed']['calls']
        shapes[source] += 1
    assert sum(grouped.values()) == joined['calls_per_rank'] == 83096
    checks = []
    for directory, filename in [('collective-grid-control-r1', 'collective_grid_probe_v1.py'),
                                ('recovery-logits-collective-control-r1', 'recovery_logits_collective_probe_r1.py')]:
        summary = ROOT / directory / ('summary-v2.json' if directory == 'collective-grid-control-r1' else 'summary.json')
        read(summary)
        assert hashes[str(summary)] == joined['source_sha256'][str(summary)]
        receipt = json.loads(read(ROOT / directory / 'receipt.json'))
        code = read(ROOT / filename)
        assert hashes[str(ROOT / filename)] == receipt['input_hashes'][filename]
        calls = operation_calls(code)
        assert {'torch.npu.synchronize', 'tensor.fill_', 'dist.all_reduce', 'dist.all_gather'} <= set(calls)
        checks.append({'summary': str(summary), 'probe': filename, 'probe_receipt_hash_matches': True,
                       'calls_per_rank': grouped[str(summary)], 'shapes': shapes[str(summary)],
                       'operation_calls': calls, 'scope': 'per-operation synchronous dispatch; all_reduce additionally fills input'})
    archive = Path(__file__).with_name('m01-worker-collective-reference-20261022.tar.gz')
    read(archive)
    assert hashes[str(archive)] == 'e482d8b1067ae33bf1256c3d14aeb99d94ce6279e55059c72312e1b79caa2da3'
    with tarfile.open(archive, 'r:gz') as bundle:
        def member(name):
            raw = bundle.extractfile(name).read()
            hashes[f'{archive}!{name}'] = hashlib.sha256(raw).hexdigest()
            return raw
        summary_name = 'workspace/m01-collective-reference-worker-r1/control/summary.json'
        summary = member(summary_name)
        source = '/' + summary_name
        assert hashlib.sha256(summary).hexdigest() == joined['source_sha256'][source]
        receipt = json.loads(member('workspace/m01-collective-reference-worker-r1/control/receipt.json'))
        filename = 'worker_collective_probe_r1.py'
        code = member('root/gennova-evidence/20261019-midterm-aligned/' + filename)
        assert hashlib.sha256(code).hexdigest() == receipt['input_hashes'][filename]
        calls = operation_calls(code)
        assert {'torch.npu.synchronize', 'tensor.fill_', 'dist.all_reduce', 'dist.all_gather'} <= set(calls)
        checks.append({'summary': source, 'probe': filename, 'probe_receipt_hash_matches': True,
                       'calls_per_rank': grouped[source], 'shapes': shapes[source],
                       'operation_calls': calls, 'scope': 'per-operation synchronous dispatch; all_reduce additionally fills input'})
    assert sum(x['calls_per_rank'] for x in checks) == 83096
    read(Path(__file__))
    result = {
        'status': 'synchronous_collective_reference_scope_verified_for_all_three_sources',
        'verified_sources': checks,
        'remaining_sources': [],
        'old_total_calls_per_rank': 83096,
        'old_weighted_synchronous_seconds': joined['weighted_synchronous_reference_seconds'],
        'decision': 'Do not substitute synchronous-call weighted duration for graph-mode necessary communication critical-path time.',
        'reuse': ['Existing per-shape payload identities and counter qualification remain evidence.',
                  'Original resource-max assessment remains unchanged.'],
        'minimal_followup': ['First search existing graph-compatible collective calibrations.',
                             'If absent, independently calibrate required shapes with timed graph replay or matched dispatch boundaries, preserving three repeats and numerical checks.',
                             'Separate input preparation and avoid per-collective host synchronization unless required by the model; do not estimate and subtract its cost.',
                             'Use necessary collective counts and dependency overlap, not merely old total physical traffic.'],
        'new_reference_seconds': None, 'new_efficiency_percent': None,
        'source_sha256': hashes,
    }
    with Path(__file__).with_name('reference-scope-audit-r2.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'verified_calls_per_rank': sum(x['calls_per_rank'] for x in checks),
                      'remaining_calls_per_rank': 0}))


if __name__ == '__main__':
    main()
