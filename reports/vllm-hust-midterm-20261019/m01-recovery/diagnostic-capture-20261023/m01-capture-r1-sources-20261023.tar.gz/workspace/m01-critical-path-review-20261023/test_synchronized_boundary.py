import unittest
from synchronized_boundary import ClientBoundary, validate_fences


def fences(phase):
    return dict(results=[dict(rank=r, pid=100+r, host='host', device=f'npu:{r}', phase=phase,
                             sync_start_ns=1, sync_end_ns=2, device_sync_completed=True) for r in (0, 1)])


class BoundaryTests(unittest.IsolatedAsyncioTestCase):
    async def test_order_and_no_cache_clear(self):
        async def post(path, payload):
            return fences(payload['args'][0]) if payload else {'status':'resumed' if path == '/resume' else 'paused'}
        client = ClientBoundary(post)
        await client.begin()
        await client.end()
        self.assertEqual(client.state, 'completed')
        self.assertEqual([c['path'] for c in client.calls], [
            '/pause?mode=wait&clear_cache=false', '/collective_rpc', '/resume',
            '/pause?mode=wait&clear_cache=false', '/collective_rpc'])
        with self.assertRaises(ValueError):
            await client.begin()

    async def test_changed_worker_fails(self):
        async def post(path, payload):
            if not payload:
                return {'status':'resumed' if path == '/resume' else 'paused'}
            result = fences(payload['args'][0])
            if payload['args'][0] == 'end':
                result['results'][0]['pid'] += 10
            return result
        client = ClientBoundary(post)
        await client.begin()
        with self.assertRaises(ValueError):
            await client.end()
        self.assertNotEqual(client.state, 'completed')

    async def test_partial_ack_does_not_resume(self):
        async def post(path, payload):
            return {'results':[]} if payload else {'status':'paused'}
        client = ClientBoundary(post)
        with self.assertRaises(ValueError):
            await client.begin()
        self.assertNotIn('/resume', [c['path'] for c in client.calls])

    def test_duplicate_rank(self):
        result = fences('begin')
        result['results'][1]['rank'] = 0
        with self.assertRaises(ValueError):
            validate_fences(result, 'begin')
