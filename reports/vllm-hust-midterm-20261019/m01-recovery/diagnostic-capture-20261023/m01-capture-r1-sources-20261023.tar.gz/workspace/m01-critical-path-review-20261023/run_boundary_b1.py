"""Own one isolated B1 boundary supplement, preserving failed-run evidence."""
import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import time

from run_collective_graph import completed_dependencies, LIFECYCLE, DEVICES
from synchronized_boundary import validate_fences
from audit_boundary_mods import audit as audit_mods

HERE = Path(__file__).resolve().parent


def validate_plan(plan):
    if plan['protocol'] != 'm01-boundary-supplement/v1':
        raise ValueError('Unexpected supplement protocol')
    for path, expected in plan['source_sha256'].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Changed pinned source: {path}')
    if plan['participating'] != [0, 1] or plan['reserved'] != list(DEVICES):
        raise ValueError('Unexpected device allocation')
    identity = plan.get('model_weight_identity')
    if isinstance(identity, dict):
        for row in identity['files']:
            stat = (Path(identity['directory']) / row['name']).stat()
            if (stat.st_size, stat.st_ino, stat.st_mtime_ns) != (row['size'], row['inode'], row['mtime_ns']):
                raise ValueError('Checkpoint changed after plan preparation')
    return plan


def check_result(output):
    data = json.loads((output / 'mmlu-pro.json').read_text())
    for field, expected in [('completed', 200), ('failed', 0),
                            ('total_input_tokens', 282265), ('total_output_tokens', 51200)]:
        if data.get(field) != expected:
            raise ValueError(f'Workload result mismatch: {field}')
    rows = [json.loads(line) for line in (output / 'boundary.jsonl').read_text().splitlines()]
    if len(rows) != 1 or rows[0]['protocol'] != 'm01-unprofiled-client-synchronized-boundary/v1':
        raise ValueError('Missing unique successful boundary receipt')
    if abs(rows[0]['client_duration_seconds'] - data['duration']) > 1e-9:
        raise ValueError('Boundary and benchmark clocks do not match')
    client, synchronized = rows[0]['client_duration_seconds'], rows[0]['synchronized_duration_seconds']
    if not all(math.isfinite(x) and x > 0 for x in (client, synchronized)) or synchronized < client:
        raise ValueError('Invalid measurement duration')
    calls = rows[0]['calls']
    if [call['path'] for call in calls] != ['/pause?mode=wait&clear_cache=false',
            '/collective_rpc', '/resume', '/pause?mode=wait&clear_cache=false', '/collective_rpc']:
        raise ValueError('Incomplete boundary control sequence')
    identity = validate_fences(calls[1]['response'], 'begin')
    validate_fences(calls[4]['response'], 'end', identity)
    for call in (calls[1], calls[4]):
        for row in call['response']['results']:
            if row.get('runtime_configuration') != dict(multistream_overlap_shared_expert=False,
                                                       enable_shared_expert_dp=False):
                raise ValueError('Runtime MoE scheduling differs from measured B1 configuration')
    return dict(completed=200, failed=0, client_seconds=data['duration'],
                synchronized_seconds=rows[0]['synchronized_duration_seconds'],
                effective_flops=None, efficiency_percent=None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    plan = validate_plan(json.loads(args.plan.read_text()))
    if args.check:
        print('PASS: pinned supplement plan only; device admission not performed')
        return 0
    if plan.get('status') != 'frozen_for_execution':
        raise RuntimeError('Plan remains pending review/provenance; execution is not admitted')
    if not isinstance(plan.get('model_weight_identity'), dict):
        raise RuntimeError('Missing checkpoint continuity evidence')
    completed_dependencies()
    sys.path.insert(0, str(LIFECYCLE))
    import run_fs018_solver as lifecycle
    from process_group_drain import wait_session_drained
    output, cache = Path(plan['output']), Path(plan['cache'])
    if any(p.exists() or p.is_symlink() for p in (output, cache)):
        raise FileExistsError('Output and cache must both be new')
    children, locks, created_output = [], [], False
    record = dict(status='admitting', started=time.time(), participating=[0, 1],
                  reserved=list(DEVICES), effective_flops=None, efficiency_percent=None)

    def observe(event):
        with (output / 'monitor.jsonl').open('a') as stream:
            stream.write(json.dumps(event) + '\n')

    def save():
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in DEVICES]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        completed_dependencies()
        output.mkdir()
        created_output = True
        for _ in range(3):
            raw = lifecycle.runtime.npu_info(observe)
            if not all(f'No running processes found in NPU {i}' in raw for i in DEVICES):
                raise RuntimeError('Devices not idle')
            time.sleep(2)
        (output / 'npu-before.txt').write_text(raw)
        if shutil.disk_usage(output).free < 20 * 1024**3:
            raise RuntimeError('Insufficient evidence/cache space')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 18390))
        shutil.copyfile(args.plan, output / 'execution-plan.json')
        environment = dict(HOME='/root', PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                           LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', KVMAT_RUN_DIR=str(output))
        runtime = ['bash', str(HERE / 'runtime_boundary_b1.sh')]
        with (output / 'service.log').open('x') as service_log, (output / 'bench.log').open('x') as bench_log:
            server = subprocess.Popen([*runtime, str(HERE / 'launch_boundary_b1.py'),
                '--output', str(output), '--cache', str(cache)], env=environment,
                stdout=service_log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append(server)
            record.update(status='starting', service_pid=server.pid)
            save()
            client, deadline = None, time.monotonic() + 3600
            while True:
                if server.poll() is not None:
                    raise RuntimeError(f'Service exited {server.returncode}')
                if time.monotonic() >= deadline:
                    raise TimeoutError('Supplement stage timed out')
                raw = lifecycle.runtime.npu_info(observe)
                observe(dict(time=time.time(), status=record['status'], npu=raw))
                for line in raw.splitlines():
                    match = re.match(r'\|\s*(?:0|1|6|7)\s+0\s*\|\s*(\d+)\s*\|', line)
                    if match and Path(f'/proc/{match[1]}').exists():
                        if not lifecycle.runtime.owned(int(match[1]), {p.pid for p in children}):
                            raise RuntimeError('Foreign NPU load')
                if client is None:
                    try:
                        with lifecycle.OPENER.open('http://127.0.0.1:18390/health', timeout=2) as response:
                            ready = response.status == 200
                    except OSError:
                        ready = False
                    if ready:
                        command = [*runtime, str(HERE / 'run_boundary_benchmark.py'), '--port', '18390',
                            '--source-sha256', plan['benchmark_sha256'], '--receipt', str(output / 'boundary.jsonl'),
                            '--', *plan['benchmark_args'], '--result-dir', str(output), '--result-filename', 'mmlu-pro.json']
                        client = subprocess.Popen(command, env=environment, stdout=bench_log,
                            stderr=subprocess.STDOUT, start_new_session=True)
                        children.append(client)
                        record.update(status='measuring', client_pid=client.pid)
                        save()
                        deadline = time.monotonic() + 1800
                elif client.poll() is not None:
                    record['client_exit_code'] = client.returncode
                    if client.returncode != 0:
                        raise RuntimeError('Benchmark or device boundary failed')
                    record.update(status='collected_pending_audit', measurement=check_result(output),
                                  mod_control=audit_mods(output))
                    break
                time.sleep(5)
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['sessions_drained'] = True
        for child in reversed(children):
            try:
                code = lifecycle.runtime.stop(child)
                record.setdefault('exit_codes', []).append(dict(pid=child.pid, code=code))
                wait_session_drained(child.pid, timeout=180, observe=observe)
            except BaseException as error:
                record['sessions_drained'] = False
                record.setdefault('cleanup_errors', []).append(str(error))
        if created_output:
            try:
                deadline = time.monotonic() + 120
                while True:
                    raw = lifecycle.runtime.npu_info(observe)
                    record['all_devices_released'] = all(f'No running processes found in NPU {i}' in raw for i in DEVICES)
                    if record['all_devices_released'] or time.monotonic() >= deadline:
                        break
                    time.sleep(2)
                (output / 'npu-after.txt').write_text(raw)
            except BaseException as error:
                record.update(all_devices_released=False, observation_error=str(error))
            record['ended'] = time.time()
            save()
            lifecycle.seal_if_released(output, record)
        for stream in locks:
            stream.close()
    print(json.dumps(record))
    return 0 if record['status'] == 'collected_pending_audit' and record.get('all_devices_released') and record['sessions_drained'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
