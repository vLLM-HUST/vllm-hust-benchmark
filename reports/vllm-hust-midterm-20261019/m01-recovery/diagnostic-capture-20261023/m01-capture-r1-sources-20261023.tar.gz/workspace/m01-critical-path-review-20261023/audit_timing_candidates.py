"""Inventory reusable timing runs without splicing their time into another run."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = Path('/root/gennova-evidence/20261019-midterm-aligned')
RUNS = ('mmlu-b1-microflow-fa-on-r9', 'mmlu-b1-microflow-fa-on-r10',
        'mmlu-b1-microflow-fa-on-r11', 'm01-recovery-model-worker-r1')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    rows = []
    for name in RUNS:
        directory = EVIDENCE / name
        receipt_path, bench_path = directory / 'receipt.json', directory / 'mmlu-pro.json'
        receipt, bench = (json.loads(p.read_text()) for p in (receipt_path, bench_path))
        if receipt['status'] != 'measured' or bench['completed'] != 200 or bench['failed'] != 0:
            raise ValueError('Unexpected candidate completion state')
        histograms = []
        hashes = {str(p): sha(p) for p in (receipt_path, bench_path)}
        for path in sorted(directory.glob('microflow-*.jsonl')):
            counts = Counter()
            for line in path.open():
                event = json.loads(line)
                if event.get('event') == 'graph_replay' and event.get('target') is True:
                    counts[event['tokens']] += 1
            histograms.append(counts)
            hashes[str(path)] = sha(path)
        if len(histograms) != 2 or histograms[0] != histograms[1]:
            raise ValueError('Worker target replay histograms disagree')
        histogram = histograms[0]
        rows.append({
            'run': name, 'client_duration_seconds': bench['duration'],
            'completed': bench['completed'], 'failed': bench['failed'],
            'input_tokens': bench['total_input_tokens'], 'output_tokens': bench['total_output_tokens'],
            'target_graph_replays_per_worker': sum(histogram.values()),
            'target_padded_graph_slots_per_worker': sum(k*v for k,v in histogram.items()),
            'target_replay_histogram': dict(sorted(histogram.items())),
            'instrumented': name == 'm01-recovery-model-worker-r1',
            'source_sha256': hashes,
        })
    result = {
        'status': 'existing_timing_candidates_preserved_mapping_pending',
        'method_handoff': {'absolute_tflops': 'F/(k*T*1e12)',
                           'realizable_efficiency_percent': '100*T_reference/T',
                           'threshold_percent': 50,
                           'final_outline_version': 'awaiting V5.25 handoff and hash'},
        'runs': rows,
        'reusable_now': ['Published performance outcomes for all three independent B1 starts.',
                         'Original request/output extents and per-worker graph-size histograms.',
                         'Existing component references for matching shapes, subject to their existing limitations.'],
        'minimal_mapping_questions': [
            'Map useful target/draft work and stage weights to the selected timing run, or derive justified bounds; equal output token totals alone are not that mapping.',
            'Check requested synchronized boundary semantics against existing client/server records; do not relabel client wall time as a device-synchronized interval without evidence.',
            'Derive an independently weighted stage-dependency reference with appropriate overlap; exclude avoidable waits and do not double-count kernel memory access.',
            'Assess actual impact of cache/runtime differences rather than automatically rejecting existing results.'
        ],
        'limitations': ['Padded graph slots are not useful FLOPs or a complete workload count.',
                        'Histogram differences do not by themselves invalidate a timing result or mandate rerunning.',
                        'No observed instrumentation gap is subtracted from elapsed time.',
                        'Original 30.25 percent instrumented resource-max result remains a separate historical metric.'],
        'new_absolute_tflops': None, 'new_efficiency_percent': None,
    }
    with (ROOT / 'timing-candidate-audit-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{k:r[k] for k in ('run', 'client_duration_seconds',
                      'target_graph_replays_per_worker', 'target_padded_graph_slots_per_worker')} for r in rows], indent=2))


if __name__ == '__main__':
    main()
