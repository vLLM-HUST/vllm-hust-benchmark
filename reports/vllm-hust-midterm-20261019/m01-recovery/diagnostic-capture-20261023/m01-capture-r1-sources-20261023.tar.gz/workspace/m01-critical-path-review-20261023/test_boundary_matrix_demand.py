import unittest
from derive_boundary_matrix_demand import coefficients


class MatrixDemandTests(unittest.TestCase):
    def config(self):
        return dict(hidden_size=2, num_hidden_layers=2, layer_types=['full_attention','linear_attention'],
            attention_bias=False, attn_output_gate=True, num_attention_heads=2, head_dim=2,
            num_key_value_heads=1, linear_num_key_heads=1, linear_key_head_dim=2,
            linear_num_value_heads=2, linear_value_head_dim=2, shared_expert_intermediate_size=3,
            num_experts=4, moe_intermediate_size=3, num_experts_per_tok=2)

    def test_shapes_and_active_experts(self):
        c = self.config()
        result = coefficients(c)
        self.assertEqual(result['.self_attn.qkv_proj'], 48)
        self.assertEqual(result['.linear_attn.in_proj_qkvz'], 48)
        self.assertEqual(result['routed_expert_projection'], 144)
        c['num_experts'] *= 2
        self.assertEqual(coefficients(c)['routed_expert_projection'], 144)
        self.assertEqual(coefficients(c)['.mlp.gate'], 2*result['.mlp.gate'])

    def test_unsupported_gate_rejected(self):
        c = self.config()
        c['attn_output_gate'] = False
        with self.assertRaises(ValueError):
            coefficients(c)
