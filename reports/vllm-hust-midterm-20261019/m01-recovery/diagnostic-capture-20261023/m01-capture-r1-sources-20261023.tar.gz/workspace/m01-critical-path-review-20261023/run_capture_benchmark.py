"""Diagnostic-only client with verified worker exports; not a performance arm."""
import argparse
import json
import os
from pathlib import Path

from benchmark_boundary_hook import install
from boundary_transport import BoundaryTransport
from capture_boundary import CaptureBoundary, diagnostic_record
from run_boundary_benchmark import validate_args
from wave_capture_bridge import check_run_label


def execute(module, args, port, source_sha, receipt, directory, run_id):
    validate_args(args, port)
    check_run_label(run_id)
    if not Path(directory).is_absolute() or not Path(directory).is_dir():
        raise ValueError('Controller-created absolute capture directory required')
    boundary = CaptureBoundary(BoundaryTransport(port), directory, run_id)
    with Path(receipt).open('x', encoding='utf-8') as output:
        def emit(record):
            output.write(json.dumps(record, sort_keys=True, allow_nan=False) + '\n')
            output.flush()
            os.fsync(output.fileno())

        try:
            install(module, boundary, source_sha,
                    lambda record: emit(diagnostic_record(record, boundary)))
            result = module.main(args)
            if boundary.state != 'completed' or boundary.export_receipts is None:
                raise RuntimeError('Benchmark returned without verified worker exports')
            return result
        except BaseException as error:
            emit(dict(protocol='m01-diagnostic-capture-client-failure/v1', run_id=run_id,
                      exception_type=type(error).__name__, state=boundary.state,
                      calls=boundary.calls, effective_flops=None, efficiency_percent=None))
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--receipt', required=True)
    parser.add_argument('--capture-dir', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('benchmark_args', nargs=argparse.REMAINDER)
    options = parser.parse_args()
    from vllm.benchmarks import serve
    from vllm.utils.argparse_utils import FlexibleArgumentParser
    bench_parser = FlexibleArgumentParser()
    serve.add_cli_args(bench_parser)
    argv = options.benchmark_args
    if argv[:1] == ['--']:
        argv = argv[1:]
    args = bench_parser.parse_args(argv)
    execute(serve, args, options.port, options.source_sha256, options.receipt,
            options.capture_dir, options.run_id)


if __name__ == '__main__':
    main()
