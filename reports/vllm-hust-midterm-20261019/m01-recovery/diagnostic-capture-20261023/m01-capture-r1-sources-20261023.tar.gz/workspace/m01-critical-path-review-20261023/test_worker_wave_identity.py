from dataclasses import dataclass
import pickle

import pytest

from worker_wave_identity import attach, validate


@dataclass
class Schedule:
    num_scheduled_tokens: dict
    scheduled_spec_decode_tokens: dict
    total_num_scheduled_tokens: int


def schedule():
    return Schedule({'private-request': 3}, {'private-request': [11, 12]}, 3)


def test_pickle_rpc_tuple_preserves_identity():
    output = schedule()
    tag = attach(output, run_id='qualification-r1', wave=8)
    payload = ('execute_model', (output,), {}, 0)
    method, args, kwargs, rank = pickle.loads(pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL))
    assert (method, kwargs, rank) == ('execute_model', {}, 0)
    assert validate(args[0], run_id='qualification-r1') == tag
    assert 'private-request' not in str(tag)
    assert output.num_scheduled_tokens == args[0].num_scheduled_tokens


def test_changed_layout_and_retag_rejected():
    output = schedule()
    attach(output, run_id='r1', wave=0)
    with pytest.raises(ValueError):
        attach(output, run_id='r1', wave=1)
    output.num_scheduled_tokens['private-request'] = 2
    output.total_num_scheduled_tokens = 2
    with pytest.raises(ValueError, match='layout changed'):
        validate(output, run_id='r1')


def test_cross_run_and_missing_identity_rejected():
    output = schedule()
    with pytest.raises(ValueError):
        validate(output, run_id='r1')
    attach(output, run_id='r1', wave=0)
    with pytest.raises(ValueError):
        validate(output, run_id='r2')


@pytest.mark.parametrize('run,wave', [('', 0), ('bad label', 1), ('r1', True), ('r1', -1)])
def test_invalid_identity(run, wave):
    with pytest.raises(ValueError):
        attach(schedule(), run_id=run, wave=wave)


def test_empty_schedule_is_explicit_not_invented_work():
    output = Schedule({}, {}, 0)
    attach(output, run_id='r1', wave=0)
    assert validate(output, run_id='r1')['wave'] == 0
