"""Read-only schema and event coverage audit; never infer causal edges."""
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'offline-export-r1'
BOUNDARIES = Path('/root/vllm-hust-benchmark/reports/vllm-hust-midterm-20261019/m01-recovery/request-assessment-20261022/m01-request-task-boundaries.json')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def connect(path):
    return sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)


def main():
    export = json.loads((OUT / 'receipt.json').read_text())
    if export['status'] != 'exported_pending_dependency_audit':
        raise ValueError('Export incomplete')
    original = json.loads(BOUNDARIES.read_text())
    result = {'scope': 'Exported schema and event evidence, not a complete dependency graph',
              'ranks': [], 'source_sha256': {str(BOUNDARIES): sha(BOUNDARIES)},
              'critical_path_seconds': None, 'new_efficiency_percent': None}
    for rank in (0, 1):
        root = OUT / f'rank-{rank}'
        dbs = list(root.rglob('msprof_*.db'))
        if len(dbs) != 1:
            raise ValueError('Ambiguous exported database')
        path = dbs[0]
        result['source_sha256'][str(path)] = sha(path)
        row = {'rank': rank, 'schemas': {}}
        with connect(path) as db:
            tables = [r[0] for r in db.execute("select name from sqlite_master where type='table'")]
            row['tables'] = tables
            for table in ('TASK', 'CANN_API', 'COMMUNICATION_TASK_INFO'):
                row['schemas'][table] = [r[1] for r in db.execute(f'pragma table_info({table})')]
            row['task_types'] = dict(db.execute('select s.value,count(*) from TASK t left join STRING_IDS s on s.id=t.taskType group by t.taskType'))
            row['event_api_counts'] = dict(db.execute("select s.value,count(*) from CANN_API a join STRING_IDS s on s.id=a.name where lower(s.value) like '%event%' or lower(s.value) like '%wait%' or lower(s.value) like '%synchron%' group by s.value"))
            expected = next(r for r in original['ranks'] if r['rank'] == rank)
            row['task_count'] = db.execute('select count(*) from TASK').fetchone()[0]
            row['original_task_count'] = expected['tables']['TASK']['nominal']['total']
            if row['task_count'] != row['original_task_count']:
                raise ValueError('Re-export task count differs from original')
        for name in ('ascend_task.db', 'rts_track.db', 'runtime.db', 'api_event.db', 'stream_info.db'):
            path = next(root.rglob(name))
            with connect(path) as db:
                for (table,) in db.execute("select name from sqlite_master where type='table'").fetchall():
                    escaped = table.replace('"', '""')
                    row['schemas'][name + ':' + table] = [r[1] for r in db.execute(f'pragma table_info("{escaped}")')]
        result['ranks'].append(row)
    result['limitations'] = [
        'The inspected TASK/CANN_API and intermediate runtime tables do not directly expose an event handle plus generation for matching record/wait lifecycles.',
        'COMMUNICATION_TASK_INFO includes notifyId and peer ranks; matching generations and cross-rank causality have not been verified.',
        'Event/task counts or temporal ordering alone do not establish a complete dependency graph.',
        'Raw capture parser coverage still needs inspection; absence of fields in these tables does not prove the raw capture cannot recover them.',
        'No reference time or 90 percent acceptance result is inferred from this audit.'
    ]
    target = ROOT / 'dependency-evidence-r1.json'
    with target.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'inspected', 'task_counts': [r['task_count'] for r in result['ranks']],
                      'critical_path_seconds': None, 'output': str(target)}))


if __name__ == '__main__':
    main()
