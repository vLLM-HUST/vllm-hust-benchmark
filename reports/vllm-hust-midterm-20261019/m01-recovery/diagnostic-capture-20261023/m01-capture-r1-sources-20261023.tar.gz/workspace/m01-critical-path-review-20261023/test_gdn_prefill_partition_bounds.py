import pytest

from bound_gdn_prefill_partitions import bounds, cost


def compositions(n):
    if n == 0:
        yield ()
    for first in range(1, min(n, 64)+1):
        for tail in compositions(n-first):
            yield (first, *tail)


def test_exact_small_enumeration():
    for n in range(1, 10):
        values = [sum(cost(c, i > 0) for i, c in enumerate(parts))
                  for parts in compositions(n)]
        result = bounds([n])[0]
        assert result['minimum'] == min(values)
        assert result['maximum'] == max(values)


def test_full_chunks_and_singletons_enclosed():
    n = 130
    result = bounds([n])[0]
    for parts in ((64, 64, 2), (1,) * n, (2, 64, 64)):
        value = sum(cost(c, i > 0) for i, c in enumerate(parts))
        assert result['minimum'] <= value <= result['maximum']


@pytest.mark.parametrize('lengths', [[], [0], [-1], [True], [1.5]])
def test_invalid(lengths):
    with pytest.raises(ValueError):
        bounds(lengths)
