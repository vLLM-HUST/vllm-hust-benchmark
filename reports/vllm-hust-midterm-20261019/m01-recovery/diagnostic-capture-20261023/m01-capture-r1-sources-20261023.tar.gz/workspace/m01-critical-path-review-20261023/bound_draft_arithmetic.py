"""Sensitivity envelope for listed draft families, not a full-model certificate."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')
sys.path.insert(0, str(ROOT))
from audit_norm_accounting import catalog
from derive_recovery_model_worker_r1_scalar import operations


def build():
    here = Path(__file__).resolve().parent
    hashes = {}

    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        result = json.loads(raw)
        for source, expected in result.get('source_sha256', {}).items():
            actual = hashlib.sha256(Path(source).read_bytes()).hexdigest()
            if actual != expected:
                raise ValueError(f'Source identity mismatch: {source}')
            hashes[source] = actual
        return result

    cohort = 'inside_request_under_clock_tolerance'
    matrix = read(ROOT / 'recovery_model_worker_r1-matrix-accounting.json')['cohorts'][cohort]
    attention = read(ROOT / 'recovery_model_worker_r1-request-attention.json')['cohorts'][cohort]
    softmax = read(ROOT / 'recovery_model_worker_r1-softmax-semantics.json')['cohorts'][cohort]
    vocab = read(ROOT / 'recovery_model_worker_r1-vocab-window.json')['semantic_projection_flops_by_window']
    target = read(here / 'target-gdn-candidate-r1.json')
    retained = read(here / 'useful-draft-scope-audit-r1.json')
    rows = matrix['valid_tokens']['draft']
    assert rows == sum(attention[role]['valid_query_tokens'] for role in ('draft_step0', 'draft_step1'))
    parts = dict(
        projections=sum(matrix['projection_entries_global']['draft'].values()),
        qk_av=sum(attention[role]['semantic_qk_av_arithmetic'] for role in ('draft_step0', 'draft_step1')),
        normalization=sum(e['basic_arithmetic_subtotal'] for e in catalog(0, rows) if e['name'].startswith('draft.')),
        scalar=operations(0, rows)['basic_subtotal'],
        softmax=sum(softmax['roles'][role][key] for role in ('draft_step0', 'draft_step1')
                    for key in ('score_scale_multiply', 'stability_subtract', 'denominator_add')),
        vocabulary=sum(vocab[role]['inside'] for role in ('draft_step0', 'draft_step1')),
    )
    upper = sum(parts.values())
    lower = retained['retained_draft_vocab_flops_lower']
    assert 0 <= lower <= upper
    base = target['target_family_candidate_subtotal']
    for path in (Path(__file__), ROOT / 'audit_norm_accounting.py',
                 ROOT / 'derive_recovery_model_worker_r1_scalar.py'):
        hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return dict(status='conditional_listed_family_arithmetic_sensitivity_not_attainment',
        observed_draft_family_upper_parts=parts,
        draft_lower_retained_vocab_only=lower, draft_upper_all_observed_valid_work=upper,
        target_candidate=base, listed_family_lower=base+lower, listed_family_upper=base+upper,
        interval_width_percent_of_lower=100*(upper-lower)/(base+lower),
        effective_flops=None, efficiency_percent=None, source_sha256=hashes,
        interpretation='All observed valid draft work is an upper envelope, not all useful work. Retained vocabulary alone is a lower subset, not full context cost.',
        limitations=[
            'Conditional on target semantic accounting and retained-token assumptions; does not bound unlisted arithmetic families.',
            'Special functions remain outside this basic-arithmetic convention.',
            'A narrow arithmetic interval does not bound reference time: memory, communication and dependencies require their own evidence.',
            'Do not publish either endpoint as a measured F or divide it by an unrelated timing run.',
            'Use this sensitivity to prioritize unresolved reference/timing work instead of pursuing an exact draft point estimate first.'])


if __name__ == '__main__':
    result = build()
    with Path(__file__).with_name('draft-arithmetic-sensitivity-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:result[k] for k in ('draft_lower_retained_vocab_only',
        'draft_upper_all_observed_valid_work', 'interval_width_percent_of_lower')}))
