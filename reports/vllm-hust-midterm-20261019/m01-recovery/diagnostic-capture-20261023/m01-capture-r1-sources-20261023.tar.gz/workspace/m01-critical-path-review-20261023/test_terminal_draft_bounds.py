import unittest
from itertools import product
from bound_terminal_draft_acceptance import clipped_request_bounds


class TerminalBoundsTests(unittest.TestCase):
    def test_no_clipping(self):
        self.assertEqual(clipped_request_bounds({1: 2, 2: 1}, 0), (0, 0))

    def test_two_tokens_can_clip_one_or_two_requests(self):
        self.assertEqual(clipped_request_bounds({1: 2, 2: 1}, 2), (1, 2))

    def test_actual_bounds(self):
        self.assertEqual(clipped_request_bounds({1: 84, 2: 73, 3: 43}, 206), (122, 157))

    def test_impossible(self):
        with self.assertRaises(ValueError): clipped_request_bounds({1: 1}, 3)

    def test_exhaustive_small_request_allocations(self):
        # Enumerate actual per-request sampler lengths independently of the solver.
        for ones in range(4):
            for twos in range(4):
                committed = [1] * ones + [2] * twos + [3]
                by_excess = {}
                for raw in product(*(range(n, 4) for n in committed)):
                    excess = sum(r - n for r, n in zip(raw, committed))
                    clipped = sum(r > n for r, n in zip(raw, committed))
                    by_excess.setdefault(excess, []).append(clipped)
                for excess, counts in by_excess.items():
                    self.assertEqual(
                        clipped_request_bounds({1: ones, 2: twos, 3: 1}, excess),
                        (min(counts), max(counts)),
                    )

    def test_prefix_clipping_keeps_drafts_before_bonus(self):
        for raw_length in (1, 2, 3):
            for committed in range(1, raw_length + 1):
                retained_drafts = min(raw_length - 1, committed)
                corrected = committed - 1 + int(raw_length > committed)
                self.assertEqual(retained_drafts, corrected)


if __name__ == '__main__':
    unittest.main()
