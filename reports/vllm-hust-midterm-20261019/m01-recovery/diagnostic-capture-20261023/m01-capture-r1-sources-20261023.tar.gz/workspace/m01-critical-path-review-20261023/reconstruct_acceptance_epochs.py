"""Reconstruct resident lifetimes and useful committed output counts."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/root/gennova-evidence/20261019-midterm-aligned')


def reconstruct(records, output_limit):
    active, completed = {}, []

    def finish(epoch):
        steps = epoch['verification_steps']
        if not steps:
            raise ValueError('Request has no verification history')
        remainder = output_limit - 1 - sum(s['committed_outputs'] for s in steps[:-1])
        if remainder not in (1, 2, 3):
            raise ValueError('Final output remainder inconsistent with MTP2')
        steps[-1].update(committed_outputs=remainder, count_source='fixed_output_budget_remainder')
        epoch['useful_accepted_draft_tokens'] = sum(s['committed_outputs'] - 1 for s in steps)
        completed.append(epoch)

    for frame, record in enumerate(records):
        fields, meta = record['device_fields'], record['metadata']
        cu = [x[0] for x in fields['cu']]
        for row in meta['prefill_ids']:
            seat = fields['prefill_conv'][row][0]
            initial_state = fields['initial'][row][0]
            if not initial_state:
                if seat in active:
                    finish(active.pop(seat))
                active[seat] = dict(seat=seat, first_frame=frame, prompt_rows=0, verification_steps=[])
            if seat not in active or active[seat]['verification_steps']:
                raise ValueError('Orphan prefill or unsupported verification-to-prefill transition')
            active[seat]['prompt_rows'] += cu[row + 1] - cu[row]
        for j, row in enumerate(meta['verify_ids']):
            slots = fields['verify_slots'][j]
            if slots == [-1, -1, -1]:
                continue
            if slots[0] % 3 or slots != list(range(slots[0], slots[0] + 3)):
                raise ValueError('Unrecognized resident candidate layout')
            seat = slots[0] // 3
            if seat not in active:
                raise ValueError('Verification without initial prefill')
            steps = active[seat]['verification_steps']
            feedback = fields['verify_accepted'][j][0]
            if feedback not in (1, 2, 3):
                raise ValueError('Invalid feedback')
            if steps:
                steps[-1].update(committed_outputs=feedback, count_source='next_active_frame_device_feedback')
            elif feedback != 1:
                raise ValueError('First verification must follow initial prefill output')
            steps.append(dict(frame=frame, row=row, committed_outputs=None))
    for epoch in active.values():
        finish(epoch)
    return sorted(completed, key=lambda x: (x['first_frame'], x['seat']))


def main():
    hashes = {}
    def read(path):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        return raw
    run = ROOT / 'm01-recovery-model-worker-r1'
    bench = json.loads(read(run / 'mmlu-pro.json'))
    assert bench['completed'] == 200 and bench['failed'] == 0 and set(bench['output_lens']) == {256}
    ranks = [reconstruct(json.loads(read(p))['records'], 256) for p in sorted(run.glob('gdn-publication-*.json'))]
    assert len(ranks) == 2 and ranks[0] == ranks[1]
    epochs = ranks[0]
    assert len(epochs) == 200
    assert sorted(e['prompt_rows'] for e in epochs) == sorted(bench['input_lens'])
    steps = [step for e in epochs for step in e['verification_steps']]
    assert len(steps) == bench['spec_decode_num_drafts'] == 19101
    assert sum(s['committed_outputs'] for s in steps) + 200 == bench['total_output_tokens']
    read(Path(__file__))
    result = dict(status='paired_resident_lifetimes_reconstructed_final_counts_budget_derived',
        lifetimes=len(epochs), active_verification_steps=len(steps),
        directly_mapped_previous_steps=sum(s['count_source']=='next_active_frame_device_feedback' for s in steps),
        budget_derived_final_steps=sum(s['count_source']=='fixed_output_budget_remainder' for s in steps),
        final_committed_histogram=dict(Counter(e['verification_steps'][-1]['committed_outputs'] for e in epochs)),
        useful_accepted_draft_tokens=sum(e['useful_accepted_draft_tokens'] for e in epochs),
        client_raw_accepted_draft_tokens=bench['spec_decode_accepted_tokens'],
        epochs=epochs, effective_flops=None, efficiency_percent=None,
        scope='All 200 resident lifetimes and prompt-length multiset match. 18901 step outcomes use next active device feedback; 200 final outcomes use the observed fixed 256-output budget, not direct final sampler capture.',
        limitations=['Resident epochs are not joined to external request IDs; equal prompt lengths can remain identity-ambiguous.',
                     'This recovers useful committed counts, not raw pre-clipping final sampler counts.',
                     'Auxiliary draft work, non-matrix work and reference dependency mapping remain separate.'],
        source_sha256=hashes)
    with Path(__file__).with_name('acceptance-epoch-reconstruction-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status','lifetimes','active_verification_steps',
        'directly_mapped_previous_steps','budget_derived_final_steps','final_committed_histogram','useful_accepted_draft_tokens')}))


if __name__ == '__main__':
    main()
