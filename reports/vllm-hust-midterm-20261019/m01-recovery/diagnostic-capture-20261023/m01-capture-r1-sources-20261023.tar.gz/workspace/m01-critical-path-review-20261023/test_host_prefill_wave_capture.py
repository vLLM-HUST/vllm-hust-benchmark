from types import SimpleNamespace as NS

import numpy as np

from host_prefill_wave_capture import HostPrefillWaveCapture, request_key
from wave_capture_bridge import ACTIVE_WAVE


class Native:
    def _build_attention_metadata(self, num_tokens, num_reqs, max_query_len,
                                  for_cudagraph_capture=False):
        return self.metadata, None


class Runner(HostPrefillWaveCapture, Native):
    pass


class Recorder:
    def __init__(self):
        self.events, self._wave_errors = [], 0
    def _wave_emit(self, event, **fields):
        self.events.append(dict(event=event, **fields))


def setup():
    runner = Runner()
    runner.input_batch = NS(req_ids=['private-a', 'private-b'])
    h = NS(cu=np.array([0, 3, 5]), verify_ids=np.array([1]),
           initial=np.array([False, True]))
    p, v = NS(cu=np.array([0, 3])), NS(cu=np.array([0, 2]), slots=np.array([[0, 1, 2]]))
    host = NS(h=h, p=p, v=v, indices={64: np.array([[0, 0], [2, 0]])})
    core = NS(host_metadata=host, live=2, verify_count=1, capacity=8,
              tokens=8, width=3, requests=2, decode=False)
    runner.metadata = {'layer.0': NS(owned=core), 'layer.1': NS(owned=core)}
    runner.enable_host_prefill_capture(expected_layers=2)
    return runner


def test_pinned_numpy_snapshot_with_wave_and_order():
    runner, recorder = setup(), Recorder()
    token = ACTIVE_WAVE.set(dict(identity={'run_id': 'r1', 'wave': 3}, recorder=recorder, phase='execute'))
    try:
        result = runner._build_attention_metadata(5, 2, 3)
    finally:
        ACTIVE_WAVE.reset(token)
    assert result[0] is runner.metadata and recorder._wave_errors == 0
    event = recorder.events[0]
    assert event['event'] == 'host_gdn_metadata'
    assert event['request_keys'] == [request_key('r1', key) for key in runner.input_batch.req_ids]
    assert event['groups'][0]['initial'] == [False, True]
    assert 'private-a' not in str(event)
    runner.metadata['layer.0'].owned.host_metadata.h.cu[1] = 99
    assert event['groups'][0]['cu'] == [0, 3, 5]


def test_no_context_warmup_and_capture_not_counted():
    runner, recorder = setup(), Recorder()
    runner._build_attention_metadata(5, 2, 3)
    assert not recorder.events
    token = ACTIVE_WAVE.set(dict(identity={'run_id': 'r1'}, recorder=recorder, phase='execute'))
    try:
        runner._build_attention_metadata(5, 2, 3, for_cudagraph_capture=True)
    finally:
        ACTIVE_WAVE.reset(token)
    assert [e['event'] for e in recorder.events] == ['graph_capture_excluded']


def test_bad_mapping_preserves_native_result_but_invalidates_capture():
    runner, recorder = setup(), Recorder()
    runner.input_batch.req_ids = ['a']
    token = ACTIVE_WAVE.set(dict(identity={'run_id': 'r1'}, recorder=recorder, phase='execute'))
    try:
        result = runner._build_attention_metadata(5, 2, 3)
    finally:
        ACTIVE_WAVE.reset(token)
    assert result[0] is runner.metadata
    assert recorder._wave_errors == 1
    assert recorder.events[0]['event'] == 'host_gdn_metadata_invalid'
