"""Optional diagnostic device snapshots using the source-pinned owned FIA hook."""
import hashlib
import importlib
from pathlib import Path
import sys
import types

from m01_draft_length_bridge import DraftLengthBridge, load_journal
from wave_capture_bridge import ACTIVE_WAVE

OBSERVER = Path('/root/gennova-evidence/20261019-midterm-aligned/token-observer-recovery-r1/hust_token_observer')
PAYLOAD = Path('/root/gennova-evidence/20261019-midterm-aligned/recovery-model-payload-r1/betterscale')
HASHES = {
    'owned_fia_snapshot.py':'814507b8533ee32351837468299c02a2a1c0ebfd9fc33acdef1f3038bb6856f7',
    'fia_graph_snapshot.py':'1b2648dd493e50b9b02aa38ced3261949bd929f58e4b6fadf763e7c15fc28b0d',
}
PAYLOAD_HASHES = {
    str(PAYLOAD / 'patches/qwen_fia/wave.py'):'cddaeb1abbf9db5644171551e910f3946f47207b34d691d97456d800fa502bee',
    str(PAYLOAD / 'patches/qwen_fia/owned.py'):'c94f38f3fd666bc187257716f2796780f9d9c79a868df0e88a8f4dbb74fda546',
    str(PAYLOAD / 'models/qwen35/draft_fia.py'):'8ca998cf2a2749862bd3c104d9f28a1427ed1cac65bf8007100ddd86bb1388bb',
}


def load_snapshot():
    for name,expected in HASHES.items():
        if hashlib.sha256((OBSERVER/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('Owned snapshot source changed')
    name='_m01_owned_length_observer'
    if name not in sys.modules:
        package=types.ModuleType(name)
        package.__path__=[str(OBSERVER)]
        sys.modules[name]=package
    elif sys.modules[name].__path__ != [str(OBSERVER)]:
        raise ValueError('Observer package path changed')
    return importlib.import_module(name+'.owned_fia_snapshot')


def install(worker):
    import torch
    runner=worker.model_runner
    journal=load_journal()(torch,worker.device,capacity=8192,max_rows=32)
    bridge=DraftLengthBridge(journal,ACTIVE_WAVE.get,
        lambda:list(runner.input_batch.req_ids[:runner.input_batch.num_reqs]),
        torch.npu.is_current_stream_capturing)

    def emit(kind,**fields):
        if kind=='owned_fia_snapshot_error':
            worker._wave_errors+=1
            context=ACTIVE_WAVE.get()
            if context is not None:
                worker._wave_emit('draft_length_capture_error',identity=context['identity'],
                                  error_type=fields['error_type'])

    load_snapshot().install(runner,runner.drafter,emit,
        lambda:ACTIVE_WAVE.get() is not None,PAYLOAD_HASHES,capture=bridge)
    worker._draft_length_bridge=bridge


def finish(worker,synchronize):
    result=worker._draft_length_bridge.finish(synchronize)
    result['complete']=(not result['errors'] and not result['binding_errors'] and bool(result['records']))
    return result
