"""Classify host non-updates without changing the original ledger verdict."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def classify(events, expected_output=256):
    final = Counter()
    for event in events:
        if event['event'] == 'output_update':
            final[event['request_key']] += event['observation']['appended_count']
    prefix, classes = Counter(), Counter()
    for event in events:
        if event['event'] not in ('output_update', 'not_updated'):
            continue
        key = event['request_key']
        if event['event'] == 'output_update':
            prefix[key] += event['observation']['appended_count']
            continue
        if final[key] != expected_output:
            classes['unresolved'] += 1
        elif event['drafts'] == 0 and prefix[key] == 0:
            classes['before_first_output_no_drafts'] += 1
        elif event['drafts'] == 2 and prefix[key] == expected_output:
            classes['after_complete_output_budget'] += 1
        else:
            classes['unresolved'] += 1
    return dict(classes= dict(classes), unclassified=classes['unresolved'],
                retained_output_addition_from_nonupdates=0 if not classes['unresolved'] else None,
                limitation='Host output-retention classification only. Before-output rows may contain useful prefill work; no device FLOP classification.')


def main():
    source = Path('/workspace/m01-capture-b1-r1/scheduler-712941.json')
    raw = source.read_bytes()
    ledger = json.loads(raw)
    if ledger['complete'] is not True or ledger['errors'] or ledger['dropped']:
        raise ValueError('Incomplete ledger cannot support skipped-row recovery')
    result = classify(ledger['events'])
    result.update(source=str(source), source_sha256=hashlib.sha256(raw).hexdigest(),
                  original_retained_count_complete=ledger['retained_count_complete'],
                  effective_flops=None, m01_attainment=None)
    with Path(__file__).with_name('capture-r1-skipped-row-classification.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
