"""Reuse pinned NumPy-only snapshots at the runner metadata build boundary."""
import hashlib
import importlib.util
from pathlib import Path

from wave_capture_bridge import ACTIVE_WAVE
from worker_wave_identity import request_key
from pinned_metadata_signature import load_signature

SOURCE = Path('/root/gennova-evidence/20261019-midterm-aligned/token-observer-recovery-r1/hust_token_observer/gdn.py')
SOURCE_SHA256 = 'f288c3b5f247a6ea07477085b3be4018d62f2771abaae72057040a288a08f1b9'


def load_snapshot():
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
        raise ValueError('Pinned host-only snapshot source changed')
    spec = importlib.util.spec_from_file_location('_m01_host_gdn_snapshot', SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.snapshot


def validate_groups(groups, requests, expected_layers):
    layers = [name for group in groups for name in group['layers']]
    if len(layers) != expected_layers or len(set(layers)) != expected_layers:
        raise ValueError('GDN layer population mismatch')
    for group in groups:
        n = group['live']
        if type(n) is not int or n != len(requests):
            raise ValueError('Request order cannot be assigned to GDN rows')
        cu, verify = group['cu'], group['verify_ids']
        if not isinstance(cu, list) or len(cu) != n+1 or cu[0] != 0:
            raise ValueError('Incomplete host cumulative lengths')
        if any(type(v) is not int for v in cu) or any(a >= b for a, b in zip(cu, cu[1:])):
            raise ValueError('Invalid host cumulative lengths')
        if not isinstance(verify, list) or len(set(verify)) != len(verify):
            raise ValueError('Invalid host verification indices')
        if any(type(i) is not int or not 0 <= i < n for i in verify):
            raise ValueError('Verification index outside live requests')
        if len(verify) != group['verify_count']:
            raise ValueError('Verification count mismatch')
        if group['decode_only'] is False:
            initial = group.get('initial')
            if not isinstance(initial, list) or len(initial) != n or any(type(v) is not bool for v in initial):
                raise ValueError('Missing host initial-state flags')
        elif group['decode_only'] is not True:
            raise ValueError('Unknown GDN execution mode')


class HostPrefillWaveCapture:
    def enable_host_prefill_capture(self, *, expected_layers):
        if hasattr(self, '_host_prefill_snapshot'):
            raise ValueError('Host snapshot already enabled')
        if type(expected_layers) is not int or expected_layers <= 0:
            raise ValueError('Explicit model layer count required')
        self._host_prefill_snapshot = load_snapshot()
        self._host_prefill_layers = expected_layers
        self._host_prefill_signature = load_signature()

    def _build_attention_metadata(self, *args, **kwargs):
        result = super()._build_attention_metadata(*args, **kwargs)
        context = ACTIVE_WAVE.get()
        if context is None or not hasattr(self, '_host_prefill_snapshot'):
            return result
        recorder, tag = context['recorder'], context['identity']
        stage = 'bind_native_arguments'
        try:
            bound = self._host_prefill_signature.bind(*args, **kwargs)
            bound.apply_defaults()
            if bound.arguments.get('for_cudagraph_capture', False):
                recorder._wave_emit('graph_capture_excluded', identity=tag)
                return result
            count = bound.arguments['num_reqs']
            ids = list(self.input_batch.req_ids[:count])
            if len(ids) != count or len(set(ids)) != count:
                raise ValueError('Incomplete or duplicate request order')
            metadata, _ = result
            if not isinstance(metadata, dict):
                raise ValueError('Microbatch metadata needs a separate row mapping')
            stage = 'snapshot_host_metadata'
            groups = self._host_prefill_snapshot(metadata)
            stage = 'validate_host_metadata'
            validate_groups(groups, ids, self._host_prefill_layers)
            recorder._wave_emit('host_gdn_metadata', identity=tag, phase=context['phase'],
                request_keys=[request_key(tag['run_id'], rid) for rid in ids], groups=groups,
                snapshot_source_sha256=SOURCE_SHA256,
                scope='Host metadata; not device-final verify slots or accepted state')
        except Exception as error:
            recorder._wave_errors += 1
            recorder._wave_emit('host_gdn_metadata_invalid', identity=tag,
                                error_type=type(error).__name__, error_stage=stage)
        return result
