from types import SimpleNamespace as NS

from host_prefill_wave_capture import HostPrefillWaveCapture
from pinned_metadata_signature import load_signature
from test_host_prefill_wave_capture import setup, Recorder
from wave_capture_bridge import ACTIVE_WAVE


def test_native_argument_binding_survives_opaque_wrapper():
    reference = setup()
    class OpaqueNative:
        def _build_attention_metadata(self, *args, **kwargs):
            return self.metadata, None
    class Runner(HostPrefillWaveCapture, OpaqueNative):
        pass
    runner, recorder = Runner(), Recorder()
    runner.input_batch = NS(req_ids=['a', 'b'])
    runner.metadata = reference.metadata
    runner.enable_host_prefill_capture(expected_layers=2)
    token = ACTIVE_WAVE.set(dict(identity={'run_id': 'r1'}, recorder=recorder, phase='execute'))
    try:
        runner._build_attention_metadata(num_tokens=5, num_reqs=2, max_query_len=3)
        runner._build_attention_metadata(5, 2, 3)
    finally:
        ACTIVE_WAVE.reset(token)
    assert recorder._wave_errors == 0
    assert [e['event'] for e in recorder.events] == ['host_gdn_metadata'] * 2
    assert recorder.events[0]['groups'] == recorder.events[1]['groups']


def test_native_optional_position_and_keyword_bindings():
    signature = load_signature()
    bound = signature.bind(5, 2, 3, for_cudagraph_capture=True)
    bound.apply_defaults()
    assert bound.arguments['num_reqs'] == 2
    assert bound.arguments['for_cudagraph_capture'] is True
    assert bound.arguments['num_tokens_padded'] is None
