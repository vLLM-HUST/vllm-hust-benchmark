from classify_capture_skips import classify


def test_zero_output_addition_does_not_mean_zero_work():
    events = [dict(event='not_updated', request_key='a', drafts=0),
              dict(event='output_update', request_key='a', observation={'appended_count': 256}),
              dict(event='not_updated', request_key='a', drafts=2)]
    result = classify(events)
    assert result['classes'] == {'before_first_output_no_drafts': 1, 'after_complete_output_budget': 1}
    assert result['retained_output_addition_from_nonupdates'] == 0
    assert 'useful prefill' in result['limitation']


def test_partial_request_does_not_prove_classification():
    events = [dict(event='not_updated', request_key='a', drafts=0),
              dict(event='output_update', request_key='a', observation={'appended_count': 128})]
    assert classify(events)['unclassified'] == 1
    assert classify(events)['retained_output_addition_from_nonupdates'] is None
