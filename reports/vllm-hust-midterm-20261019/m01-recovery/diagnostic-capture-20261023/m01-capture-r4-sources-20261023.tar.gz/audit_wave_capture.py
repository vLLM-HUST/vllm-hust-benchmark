"""Join diagnostic exports; this does not qualify effective FLOPs or timing."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from host_prefill_wave_capture import SOURCE_SHA256, validate_groups


def audit(scheduler, workers):
    errors = []
    run = scheduler.get('run_id')
    if not isinstance(run, str) or not run:
        errors.append('missing scheduler run identity')
    ranks = [worker.get('rank') for worker in workers]
    if len(ranks) != 2 or any(type(rank) is not int for rank in ranks) or set(ranks) != {0, 1}:
        errors.append('expected exactly TP2 ranks 0 and 1')
    for source in [scheduler, *workers]:
        if source.get('run_id') != run:
            errors.append('cross-run export')
        if source.get('complete') is not True or source.get('errors') != 0 or source.get('dropped') != 0:
            errors.append('incomplete source export')
        if source.get('measurement_role') != 'diagnostic_qualification':
            errors.append('unexpected measurement role')
    if scheduler.get('active_requests') != 0 or scheduler.get('open_frames') != 0:
        errors.append('scheduler not drained')

    scheduled, deliveries, frames = {}, {}, {}

    def identity(event):
        tag = event.get('identity', {})
        wave = tag.get('wave')
        if (tag.get('run_id') != run or tag.get('protocol') != 'm01-worker-wave/v1'
                or type(wave) is not int or wave < 0):
            errors.append('invalid wave identity')
            return None
        return wave

    for event in scheduler.get('events', []):
        kind = event.get('event')
        if kind in ('scheduled', 'delivery'):
            wave = identity(event)
            target = scheduled if kind == 'scheduled' else deliveries
            if wave in target:
                errors.append('duplicate scheduler ' + kind)
            target[wave] = event.get('identity')
            if kind == 'delivery':
                frame = event.get('frame')
                if type(frame) is not int or frame in frames:
                    errors.append('invalid or reused delivery frame')
                frames[frame] = wave
    if not scheduled:
        errors.append('no scheduled waves')
    if scheduled != deliveries:
        errors.append('scheduled/delivered wave mismatch')
    frame_begins = Counter(e.get('frame') for e in scheduler.get('events', []) if e.get('event') == 'frame_begin')
    frame_ends = Counter(e.get('frame') for e in scheduler.get('events', []) if e.get('event') == 'frame_end')
    if frame_begins != Counter({f: 1 for f in frames}) or frame_ends != frame_begins:
        errors.append('delivery frames not closed exactly once')

    for worker in workers:
        if 'draft_device_lengths' in worker:
            try:
                from audit_draft_lengths import validate
                validate(worker)
            except (KeyError, TypeError, ValueError):
                errors.append('invalid or incomplete draft device lengths')
        if worker.get('pending') is not False:
            errors.append('worker sampling not drained')
        executed = {}
        active = None
        finished = set()
        sampled = set()
        previous_ns = -1
        for event in worker.get('events', []):
            wave = identity(event)
            tag = event.get('identity')
            kind = event.get('event', '')
            stamp = event.get('perf_ns')
            if type(stamp) is not int or stamp < previous_ns:
                errors.append('invalid worker event clock order')
            else:
                previous_ns = stamp
            if tag != scheduled.get(wave):
                errors.append('worker/scheduler wave identity mismatch')
            if kind in ('execute_begin', 'sample_begin'):
                phase = kind.removesuffix('_begin')
                if active is not None:
                    errors.append('overlapping worker phases')
                active = (phase, wave)
                if phase == 'execute':
                    if wave in executed:
                        errors.append('duplicate worker execution')
                    executed[wave] = tag
                else:
                    if wave not in finished or wave in sampled:
                        errors.append('orphan or duplicate sampling')
                    sampled.add(wave)
            elif kind in ('execute_end', 'sample_end'):
                phase = kind.removesuffix('_end')
                if active != (phase, wave):
                    errors.append('unmatched worker phase end')
                active = None
                if phase == 'execute':
                    finished.add(wave)
            elif kind in ('host_prefill', 'host_gdn_metadata'):
                if active != (event.get('phase'), wave):
                    errors.append('prefill outside matching worker phase')
                if kind == 'host_gdn_metadata':
                    try:
                        keys = event['request_keys']
                        if len(set(keys)) != len(keys) or any(
                            not isinstance(key, str) or len(key) != 64
                            or any(c not in '0123456789abcdef' for c in key) for key in keys
                        ):
                            raise ValueError('invalid request keys')
                        validate_groups(event['groups'], keys, expected_layers=30)
                        if event['snapshot_source_sha256'] != SOURCE_SHA256:
                            raise ValueError('unknown snapshot implementation')
                    except (KeyError, TypeError, ValueError):
                        errors.append('invalid host GDN metadata')
            elif kind == 'graph_capture_excluded':
                if active is None or active[1] != wave:
                    errors.append('graph capture outside matching worker phase')
            else:
                errors.append('unsupported worker event: ' + kind)
        if active is not None or executed != scheduled:
            errors.append('worker wave coverage incomplete')
    return dict(status='joined' if not errors else 'incomplete', errors=sorted(set(errors)),
                run_id=run, scheduled_waves=len(scheduled), worker_ranks=ranks,
                retained_count_complete=scheduler.get('retained_count_complete') is True,
                scope='Diagnostic transport and phase closure only; no FLOPs or timing acceptance',
                effective_flops=None, reference_time=None, m01_attainment=None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    schedulers = sorted(args.directory.glob('scheduler-*.json'))
    workers = sorted(args.directory.glob('worker-*.json'))
    if len(schedulers) != 1:
        parser.error('exactly one scheduler export required')
    paths = schedulers + workers
    contents = [p.read_bytes() for p in paths]
    result = audit(json.loads(contents[0]), [json.loads(b) for b in contents[1:]])
    result['sources'] = [dict(path=str(p), sha256=hashlib.sha256(b).hexdigest())
                         for p, b in zip(paths, contents)]
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))
    return 0 if result['status'] == 'joined' else 1


if __name__ == '__main__':
    raise SystemExit(main())
