import asyncio
import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

from capture_request_checkpoint import OUTPUT_FIELDS, checkpoint, checkpoint_tree


def test_observations_saved_before_failing_end(tmp_path):
    source = '''
async def benchmark(profile=False):
    benchmark_start_time = time.perf_counter()
    benchmark_duration = time.perf_counter() - benchmark_start_time
    raise AssertionError("should not reach later result serialization")
'''
    requests = [NS(request_id='one', prompt='question', prompt_len=1,
                   expected_output_len=2, chat_messages=None)]
    values = dict.fromkeys(OUTPUT_FIELDS, 0)
    values.update(generated_text='answer', success=True, itl=[0.1], error='')
    outputs = [NS(**values)]
    class Boundary:
        async def begin(self): pass
        async def end(self): raise ValueError('export unavailable')
    scope = dict(time=NS(perf_counter=lambda: 1), input_requests=requests, outputs=outputs,
                 __m01_guard=lambda values: None, __m01_boundary=Boundary(),
                 __m01_finish=lambda *args: None,
                 __m01_checkpoint=lambda *args: checkpoint(tmp_path, 'r1', *args))
    exec(compile(checkpoint_tree(source), '<test>', 'exec'), scope)
    with pytest.raises(ValueError, match='export unavailable'):
        asyncio.run(scope['benchmark']())
    raw = (tmp_path / 'request-checkpoint.json').read_bytes()
    saved = json.loads(raw)
    assert saved['requests'][0]['output']['generated_text'] == 'answer'
    assert saved['requests'][0]['output']['itl'] == [0.1]
    assert saved['m01_attainment'] is None
    with pytest.raises(FileExistsError):
        checkpoint(tmp_path, 'r1', requests, outputs, 1, 0)
    assert (tmp_path / 'request-checkpoint.json').read_bytes() == raw


def test_real_source_checkpoint_order():
    source = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/benchmarks/serve.py').read_text()
    tree = checkpoint_tree(source)
    import ast
    text = ast.unparse(tree)
    assert text.index('outputs: list[RequestFuncOutput]') < text.index('__m01_checkpoint(')
    assert text.index('__m01_checkpoint(') < text.index('await __m01_boundary.end()')
    compile(tree, '<pinned benchmark>', 'exec')
