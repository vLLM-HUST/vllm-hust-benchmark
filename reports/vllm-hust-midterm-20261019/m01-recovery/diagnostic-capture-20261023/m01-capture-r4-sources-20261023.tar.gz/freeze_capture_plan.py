"""Extend unchanged measured-B1 identities for a diagnostic-only supplement."""
import argparse
import hashlib
import json
from pathlib import Path

from run_boundary_b1 import validate_plan as validate_original
from run_capture_b1 import validate_plan

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--output-directory', type=Path, required=True)
    parser.add_argument('--cache-directory', type=Path, required=True)
    parser.add_argument('--ready', action='store_true')
    parser.add_argument('--draft-lengths', action='store_true')
    args = parser.parse_args()
    original = HERE / 'boundary-execution-plan-r7.json'
    plan = validate_original(json.loads(original.read_text()))
    preflight = HERE / 'wave-manager-preflight-r1.json'
    result = json.loads(preflight.read_text())
    if result.get('status') != 'manager_child_composition_passed' or result.get('model_loaded') is not False:
        raise ValueError('Missing complete manager child preflight')
    if result['adapter_sha256'] != digest(HERE / 'capture_service_entry.py'):
        raise ValueError('Adapter changed after actual preflight')
    sources = set(HERE.glob('*.py')) | {original, preflight}
    installed = HERE / 'wave-plugin-installed-r1'
    sources.update(p for p in installed.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    sources.add(Path('/root/gennova-evidence/20261023-milestone-v15-project4/project4-v1.5.txt'))
    sources.add(Path('/root/gennova-evidence/20261019-midterm-aligned/token-observer-recovery-r1/hust_token_observer/gdn.py'))
    if args.draft_lengths:
        from draft_length_runtime import OBSERVER, HASHES, PAYLOAD_HASHES
        from m01_draft_length_bridge import JOURNAL
        sources.update(OBSERVER / name for name in HASHES)
        sources.update(Path(name) for name in PAYLOAD_HASHES)
        sources.add(JOURNAL)
    plan['source_sha256'].update({str(p): digest(p) for p in sorted(sources)})
    plan.update(protocol='m01-diagnostic-capture/v1', method='Milestone V1.5 project 4',
        status='frozen_for_execution' if args.ready else 'prepared_pending_review',
        run_id=args.run_id, output=str(args.output_directory.absolute()),
        cache=str(args.cache_directory.absolute()), measurement_role='diagnostic_qualification',
        scope='Same configured 200-request workload; retained outputs and host GDN wave attribution',
        performance_acceptance=False, unprofiled_timing=False,
        limitation='Diagnostic trace does not establish full effective FLOPs or transfer counts to another run',
        baseline_identity='B1 only; not the official 0.18/0.18 B0',
        original_plan_sha256=digest(original))
    plan['capture_draft_lengths'] = args.draft_lengths
    if any(p.exists() or p.is_symlink() for p in (args.output_directory, args.cache_directory)):
        raise FileExistsError('Never freeze a retry against an existing run or cache directory')
    validate_plan(plan)
    with args.plan.open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=plan['status'], sources=len(plan['source_sha256']),
                          sha256=digest(args.plan), model_started=False)))


if __name__ == '__main__':
    main()
