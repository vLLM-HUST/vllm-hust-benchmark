"""Diagnostic B1 launch; controller owns exclusive device admission and shutdown."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

from launch_boundary_b1 import prepare_command, reserve_cache
from wave_capture_bridge import check_run_label

HERE = Path(__file__).resolve().parent


def prepare(out, cache, run_id):
    check_run_label(run_id)
    if cache == out or cache in out.parents or out in cache.parents:
        raise ValueError('Evidence and cache must be independent directories')
    command, env, original = prepare_command(out, cache)
    if command[:4] != [sys.executable, '-m', 'vllm.entrypoints.cli.main', 'serve']:
        raise ValueError('Unexpected pinned service entrypoint')
    if command[-2:] != ['--worker-extension-cls', 'synchronized_boundary.WorkerBoundary']:
        raise ValueError('Unexpected pinned boundary extension')
    command = [sys.executable, str(HERE / 'capture_service_entry.py'), *command[3:-2]]
    env.update(HUST_M01_WAVE_CAPTURE='1', HUST_M01_CAPTURE_RUN_ID=run_id,
               HUST_M01_CAPTURE_DIR=str(out), HUST_M01_CAPTURE_MAX_EVENTS='200000',
               HUST_M01_CAPTURE_MAX_REQUESTS='256')
    env['PYTHONPATH'] = str(HERE / 'wave-plugin-installed-r1') + os.pathsep + os.environ['PYTHONPATH']
    return command, env, original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cache', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    args = parser.parse_args()
    out, cache = args.output.absolute(), args.cache.absolute()
    command, env, original = prepare(out, cache, args.run_id)
    if not out.is_dir():
        raise ValueError('Controller must create admitted output directory')
    reserve_cache(cache)
    receipt = dict(policy='fresh empty caches; no previous run or compile seed imported',
                   destination=str(cache), initial_entries=[], measurement_role='diagnostic_qualification',
                   original_command_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
                   startup_excluded_from_measurement=True, performance_acceptance=False)
    for name, value in [('compiler-cache-initialization.json', receipt), ('launch-command.json', command)]:
        with (out / name).open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')
    os.environ.update(env)
    from vllm_hust_ext.cli import main as manager_main
    raise SystemExit(manager_main(['run', '--shutdown-grace-seconds', '75', '--', *command]))


if __name__ == '__main__':
    main()
