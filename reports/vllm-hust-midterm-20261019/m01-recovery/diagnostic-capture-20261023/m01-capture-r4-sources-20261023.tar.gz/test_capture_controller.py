from contextlib import ExitStack
import json
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import MagicMock, patch

import pytest

import run_capture_b1 as controller
from test_audit_wave_capture import exports


def test_final_audit_requires_all_exports(tmp_path):
    with pytest.raises(ValueError, match='Missing'):
        controller.check_final(tmp_path)
    scheduler, workers = exports()
    (tmp_path / 'scheduler-1.json').write_text(json.dumps(scheduler))
    for rank, worker in enumerate(workers):
        (tmp_path / f'worker-{rank}.json').write_text(json.dumps(worker))
    with pytest.raises(ValueError, match='Requested draft'):
        controller.check_final(tmp_path, require_draft_lengths=True)
    result = controller.check_final(tmp_path)
    assert result['status'] == 'joined'
    assert len(result['sources']) == 3
    with pytest.raises(FileExistsError):
        controller.check_final(tmp_path)


@pytest.mark.parametrize('failure', [None, 'client', 'drain', 'final'])
@pytest.mark.parametrize('draft_lengths', [False, True])
def test_owned_lifecycle_and_post_shutdown_audit(tmp_path, failure, draft_lengths):
    output = tmp_path / 'out'
    plan = dict(protocol='m01-diagnostic-capture/v1', source_sha256={},
        run_id='test-r1', measurement_role='diagnostic_qualification',
        participating=[0, 1], reserved=[0, 1, 6, 7], status='frozen_for_execution',
        model_weight_identity=dict(files=[], directory=str(tmp_path)),
        output=str(output), cache=str(tmp_path / 'cache'), benchmark_sha256='test', benchmark_args=[],
        capture_draft_lengths=draft_lengths)
    plan_path = tmp_path / 'plan.json'
    plan_path.write_text(json.dumps(plan))
    idle = '\n'.join(f'No running processes found in NPU {i}' for i in (0, 1, 6, 7))
    server = NS(pid=123456, poll=lambda: None, returncode=None)
    client = NS(pid=123457, poll=lambda: 1 if failure == 'client' else 0,
                returncode=1 if failure == 'client' else 0)
    runtime = NS(npu_info=MagicMock(return_value=idle), owned=MagicMock(return_value=True),
                 stop=MagicMock(return_value=0))
    opener = MagicMock()
    opener.open.return_value.__enter__.return_value.status = 200
    lifecycle = NS(runtime=runtime, OPENER=opener, seal_if_released=MagicMock())
    drain = MagicMock(side_effect=RuntimeError('drain') if failure == 'drain' else None)
    def final(directory, *, require_draft_lengths=False):
        assert require_draft_lengths == draft_lengths
        assert runtime.stop.call_count == 2
        assert drain.call_count == 2
        if failure == 'final':
            raise ValueError('missing scheduler')
        return dict(status='joined')
    real_open = open
    def open_lock(path, *args, **kwargs):
        if str(path).startswith('/tmp/'):
            return real_open(tmp_path / Path(path).name, *args, **kwargs)
        return real_open(path, *args, **kwargs)
    with ExitStack() as stack:
        stack.enter_context(patch.dict('sys.modules', run_fs018_solver=lifecycle,
            process_group_drain=NS(wait_session_drained=drain)))
        stack.enter_context(patch.object(controller.sys, 'argv', ['test', '--plan', str(plan_path)]))
        stack.enter_context(patch.object(controller.fcntl, 'flock'))
        stack.enter_context(patch.object(controller.socket, 'socket'))
        stack.enter_context(patch.object(controller.time, 'sleep'))
        stack.enter_context(patch.object(controller.shutil, 'disk_usage', return_value=NS(free=100*1024**3)))
        spawn = stack.enter_context(patch.object(controller.subprocess, 'Popen', side_effect=[server, client]))
        stack.enter_context(patch.object(controller, 'check_client', return_value=dict(completed=200)))
        audit = stack.enter_context(patch.object(controller, 'check_final', side_effect=final))
        stack.enter_context(patch('builtins.open', side_effect=open_lock))
        code = controller.main()
    receipt = json.loads((output / 'receipt.json').read_text())
    assert code == (0 if failure is None else 1)
    assert receipt['status'] == ('diagnostic_capture_joined' if failure is None else 'failed')
    assert [call.args[0].pid for call in runtime.stop.call_args_list] == [client.pid, server.pid]
    assert audit.call_count == (0 if failure in ('client', 'drain') else 1)
    assert lifecycle.seal_if_released.call_count == 1
    assert spawn.call_count == 2
    assert spawn.call_args_list[0].kwargs['env'].get('HUST_M01_DRAFT_LENGTHS') == ('1' if draft_lengths else None)
    assert 'run_capture_benchmark.py' in ' '.join(spawn.call_args_list[1].args[0])
