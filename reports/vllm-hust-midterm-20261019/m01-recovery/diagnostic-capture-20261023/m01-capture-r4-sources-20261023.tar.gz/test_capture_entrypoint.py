import json
from types import SimpleNamespace

import pytest

import run_capture_benchmark as entry
from test_boundary_entrypoint import arguments


def test_failure_is_diagnostic_and_exclusive(tmp_path, monkeypatch):
    def reject(*args):
        raise ValueError('bad source')
    monkeypatch.setattr(entry, 'install', reject)
    receipt = tmp_path / 'receipt.jsonl'
    with pytest.raises(ValueError):
        entry.execute(None, arguments(), 18390, 'bad', receipt, tmp_path, 'r1')
    result = json.loads(receipt.read_text())
    assert result['protocol'] == 'm01-diagnostic-capture-client-failure/v1'
    original = receipt.read_bytes()
    with pytest.raises(FileExistsError):
        entry.execute(None, arguments(), 18390, 'bad', receipt, tmp_path, 'r1')
    assert receipt.read_bytes() == original


def test_success_cannot_publish_unprofiled_protocol(tmp_path, monkeypatch):
    def install(module, boundary, source_sha, emit, save_checkpoint):
        def main(args):
            boundary.state = 'completed'
            boundary.export_receipts = [{'test_only': True}]
            emit(dict(protocol='m01-unprofiled-client-synchronized-boundary/v1'))
        module.main = main
    monkeypatch.setattr(entry, 'install', install)
    receipt = tmp_path / 'receipt.jsonl'
    entry.execute(SimpleNamespace(), arguments(), 18390, 'test', receipt, tmp_path, 'r1')
    result = json.loads(receipt.read_text())
    assert result['protocol'] == 'm01-diagnostic-capture-boundary/v1'
    assert not result['performance_acceptance']
    assert result['includes_worker_export_overhead']
