import ast
import os
from pathlib import Path
import socket

import pytest

from capture_export import export_snapshot


def scheduler_class(namespace):
    source = Path(__file__).with_name('wave_capture_runtime.py').read_text()
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.ClassDef) and n.name == 'CaptureScheduler')
    exec(compile(ast.Module(body=[node], type_ignores=[]), '<actual CaptureScheduler>', 'exec'), namespace)
    return namespace['CaptureScheduler']


@pytest.mark.parametrize('export_fails', [False, True])
def test_export_precedes_native_shutdown_and_cleanup_always_runs(tmp_path, export_fails):
    calls = []
    class Ledger:
        def output_ledger_snapshot(self):
            return dict(complete=True, retained_count_complete=True, effective_flops=None)
    class Native:
        def shutdown(self):
            calls.append('native_shutdown')
            if not export_fails:
                assert (tmp_path / f'scheduler-{os.getpid()}.json').is_file()
    def exporting(*args):
        calls.append('export')
        if export_fails:
            raise OSError('test disk error')
        return export_snapshot(*args)
    cls = scheduler_class(dict(SchedulerWaveCapture=Ledger, LiveStateScheduler=Native,
                               os=os, socket=socket, export_snapshot=exporting))
    obj = object.__new__(cls)
    obj._output_ledger = {}
    obj.requests = {}
    obj._capture_directory = tmp_path
    obj._wave_run_id = 'test'
    if export_fails:
        with pytest.raises(OSError, match='test disk error'):
            obj.shutdown()
    else:
        obj.shutdown()
    assert calls == ['export', 'native_shutdown']
