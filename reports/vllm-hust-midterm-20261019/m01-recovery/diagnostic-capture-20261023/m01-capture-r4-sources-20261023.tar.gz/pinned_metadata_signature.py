"""Recover the pinned native ABI hidden by transparent plugin wrappers."""
import ast
import hashlib
import inspect
from pathlib import Path

SOURCE = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm-ascend/vllm_ascend/worker/model_runner_v1.py')
SHA256 = 'ceabfc9db30c9d8bf8dc7c9bddf523c4a8d5ef04165994635dca3b94a8e929f4'


def load_signature():
    raw = SOURCE.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SHA256:
        raise ValueError('Pinned runner ABI source changed')
    classes = [n for n in ast.parse(raw).body if isinstance(n, ast.ClassDef) and n.name == 'NPUModelRunner']
    methods = [n for cls in classes for n in cls.body if isinstance(n, ast.FunctionDef)
               and n.name == '_build_attention_metadata']
    if len(methods) != 1:
        raise ValueError('Ambiguous native metadata ABI')
    args = methods[0].args
    if args.posonlyargs or args.kwonlyargs or args.vararg or args.kwarg or args.args[0].arg != 'self':
        raise ValueError('Unqualified native metadata signature structure')
    required = len(args.args) - len(args.defaults)
    params = []
    for index, arg in enumerate(args.args[1:], start=1):
        default = inspect.Parameter.empty if index < required else ast.literal_eval(args.defaults[index-required])
        params.append(inspect.Parameter(arg.arg, inspect.Parameter.POSITIONAL_OR_KEYWORD, default=default))
    return inspect.Signature(params)
