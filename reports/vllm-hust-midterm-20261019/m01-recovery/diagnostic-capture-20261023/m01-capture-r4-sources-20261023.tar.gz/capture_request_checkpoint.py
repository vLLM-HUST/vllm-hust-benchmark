"""Save client observations before a diagnostic export can fail."""
import ast
import hashlib
import inspect
from pathlib import Path

from benchmark_boundary_hook import install as install_boundary, instrument
from capture_export import export_snapshot

OUTPUT_FIELDS = ('generated_text', 'success', 'latency', 'output_tokens', 'ttft',
                 'itl', 'tpot', 'prompt_len', 'error', 'start_time', 'client_queue_time')


def checkpoint(directory, run_id, requests, outputs, start, duration):
    if len(requests) != len(outputs) or not outputs:
        raise ValueError('Request/output checkpoint population mismatch')
    rows = []
    for index, (request, output) in enumerate(zip(requests, outputs)):
        rows.append(dict(index=index, request_id=request.request_id,
                         prompt=request.prompt, prompt_len=request.prompt_len,
                         expected_output_len=request.expected_output_len,
                         chat_messages=request.chat_messages,
                         output={name: getattr(output, name) for name in OUTPUT_FIELDS}))
    snapshot = dict(protocol='m01-diagnostic-request-checkpoint/v1', complete=True,
                    run_id=run_id, requests=rows, client_start_perf=start,
                    client_duration_seconds=duration, measurement_role='diagnostic_qualification',
                    effective_flops=None, m01_attainment=None,
                    scope='Client observations saved before end fence/export; not acceptance')
    return export_snapshot(directory, 'request-checkpoint.json', snapshot)


def checkpoint_tree(source):
    tree = instrument(source)
    body = tree.body[0].body
    matches = [i for i, node in enumerate(body) if isinstance(node, ast.Expr)
               and ast.unparse(node) == 'await __m01_boundary.end()']
    if len(matches) != 1:
        raise ValueError('Expected one diagnostic end boundary')
    body[matches[0]:matches[0]] = ast.parse(
        '__m01_checkpoint(input_requests, outputs, benchmark_start_time, benchmark_duration)').body
    return ast.fix_missing_locations(tree)


def install(module, boundary, expected_sha256, emit, save_checkpoint):
    path = Path(inspect.getsourcefile(module.benchmark))
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError('Benchmark changed before checkpoint installation')
    if '__m01_checkpoint' in module.__dict__:
        raise ValueError('Checkpoint already installed')
    install_boundary(module, boundary, expected_sha256, emit)
    module.__dict__['__m01_checkpoint'] = save_checkpoint
    exec(compile(checkpoint_tree(raw.decode()), str(path), 'exec'), module.__dict__)
