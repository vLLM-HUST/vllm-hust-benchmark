from types import SimpleNamespace as NS
import pytest
from m01_draft_length_bridge import DraftLengthBridge, load_journal


class Journal:
    def __init__(self):
        self.records=[]
    def record(self,q,kv,metadata):
        self.records.append(metadata)
        return len(self.records)-1
    def finish(self,sync):
        sync()
        return dict(status='captured_pending_stream_qualification',records=self.records)


def setup():
    ctx=dict(identity=dict(run_id='r',wave=7),phase='sample')
    journal=Journal()
    return DraftLengthBridge(journal,lambda:ctx,lambda:['a','b'],lambda:False),journal,ctx


def test_two_steps_bound_without_request_plaintext():
    bridge,journal,ctx=setup()
    q=NS(shape=(3,))
    fields=dict(role='draft',bank=0,tokens=80,draft_step=0)
    assert bridge.record(q,q,None,None,fields)==0
    fields['draft_step']=1
    assert bridge.record(q,q,None,None,fields)==1
    ctx['identity']['wave']=8
    assert journal.records[0]['identity']['wave']==7
    assert all(len(k)==64 for k in journal.records[0]['request_keys'])
    calls=[]
    result=bridge.finish(lambda:calls.append('sync'))
    assert calls==['sync'] and result['effective_flops'] is None
    assert result['stream_order_qualified'] is False


def test_duplicate_fails_and_marks_export():
    bridge,_,_=setup()
    q=NS(shape=(3,)); fields=dict(role='draft',bank=0,tokens=80,draft_step=0)
    bridge.record(q,q,None,None,fields)
    with pytest.raises(ValueError,match='Duplicate'):
        bridge.record(q,q,None,None,fields)
    assert bridge.finish(lambda:None)['status']=='capture_errors'


def test_capturing_is_not_a_workload_snapshot():
    bridge,_,_=setup()
    bridge.capturing=lambda:True
    with pytest.raises(ValueError,match='capturing'):
        bridge.record(NS(shape=(3,)),NS(shape=(3,)),None,None,dict(role='draft'))


def test_target_and_startup_are_not_captured():
    bridge,journal,_=setup()
    assert bridge.record(None,None,None,None,dict(role='target')) is None
    bridge.context=lambda:None
    assert bridge.record(None,None,None,None,dict(role='draft')) is None
    assert not journal.records


def test_load_pinned_existing_journal():
    assert load_journal().__name__=='DeviceLengthJournal'
