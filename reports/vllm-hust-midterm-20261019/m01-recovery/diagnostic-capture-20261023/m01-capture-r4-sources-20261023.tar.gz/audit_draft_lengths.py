"""Validate per-wave device-length exports without asserting stream qualification."""


def validate(worker):
    capture=worker['draft_device_lengths']
    if not capture['complete'] or capture['errors'] or capture['binding_errors']:
        raise ValueError('Incomplete draft device lengths')
    expected={(e['identity']['wave'],step) for e in worker['events']
              if e['event']=='sample_begin' for step in (0,1)}
    observed=set()
    for record in capture['records']:
        metadata=record['metadata']
        tag=metadata['identity']
        if tag['run_id']!=worker['run_id']:
            raise ValueError('Cross-run draft snapshot')
        key=(tag['wave'],metadata['draft_step'])
        if key not in expected or key in observed:
            raise ValueError('Unexpected or duplicate draft snapshot')
        observed.add(key)
        live=metadata['live_requests']
        keys=metadata['request_keys']
        q,kv=record['device_query_lengths'],record['device_kv_lengths']
        if (type(live) is not int or live<=0 or len(keys)!=live or len(set(keys))!=live
                or len(q)!=len(kv) or len(q)<live):
            raise ValueError('Invalid live snapshot extent')
        previous=0
        for end,length in zip(q[:live],kv[:live]):
            if type(end) is not int or type(length) is not int or end<=previous or length<end-previous:
                raise ValueError('Invalid device query/KV length')
            previous=end
    if not expected or observed!=expected:
        raise ValueError('Missing draft step coverage')
    return dict(status='device_length_values_covered_stream_qualification_separate',
                records=len(observed),stream_order_qualified=capture['stream_order_qualified'],
                effective_flops=None)
