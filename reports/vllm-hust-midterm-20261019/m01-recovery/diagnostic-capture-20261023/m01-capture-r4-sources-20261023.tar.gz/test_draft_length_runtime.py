from types import SimpleNamespace as NS
import pytest
from draft_length_runtime import finish, load_snapshot
from audit_draft_lengths import validate


def test_source_pinned_snapshot_load():
    assert callable(load_snapshot().install)


@pytest.mark.parametrize('records,errors,complete', [([],[],False),([{}],[],True),([{}],[{}],False)])
def test_export_requires_nonempty_clean_capture(records,errors,complete):
    class Bridge:
        def finish(self,sync):
            sync()
            return dict(records=records,errors=errors,binding_errors=[])
    calls=[]
    assert finish(NS(_draft_length_bridge=Bridge()),lambda:calls.append(1))['complete'] is complete
    assert calls==[1]


def sample():
    return dict(run_id='r',events=[dict(event='sample_begin',identity=dict(wave=1))],
        draft_device_lengths=dict(complete=True,errors=[],binding_errors=[],stream_order_qualified=False,
            records=[dict(metadata=dict(identity=dict(run_id='r',wave=1),draft_step=s,
                live_requests=1,request_keys=['key']),device_query_lengths=[3,80],
                device_kv_lengths=[100,0]) for s in (0,1)]))


def test_two_steps_and_padding_not_claimed_useful():
    result=validate(sample())
    assert result['records']==2 and result['stream_order_qualified'] is False
    assert result['effective_flops'] is None


def test_missing_step_fails():
    worker=sample()
    worker['draft_device_lengths']['records'].pop()
    with pytest.raises(ValueError,match='Missing'):
        validate(worker)


def test_short_kv_fails():
    worker=sample()
    worker['draft_device_lengths']['records'][0]['device_kv_lengths'][0]=2
    with pytest.raises(ValueError,match='query/KV'):
        validate(worker)
