"""Summarize a sealed diagnostic capture without changing its acceptance status."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, '/workspace/m01-critical-path-review-20261023')
from classify_capture_skips import classify


def main():
    root = Path('/workspace/m01-capture-b1-r3')
    hashes = {}

    def read(path):
        raw = path.read_bytes()
        hashes[path.name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    receipt = read(root / 'receipt.json')
    assert receipt['status'] == 'diagnostic_capture_joined'
    assert receipt['sessions_drained'] and receipt['all_devices_released']
    scheduler = read(next(root.glob('scheduler-*.json')))
    boundary = read(root / 'boundary.jsonl')
    result = read(root / 'mmlu-pro.json')
    calls = boundary['calls']
    assert len(calls) == 6 and calls[2]['path'] == '/resume'
    low = calls[2]['clock_after']['perf_after_ns']
    high = calls[3]['clock_before']['perf_before_ns']
    assert high > low
    assert calls[2]['clock_after']['host'] == scheduler['host'] == calls[3]['clock_before']['host']
    assert scheduler['complete'] and scheduler['errors'] == scheduler['dropped'] == 0
    events = [e for e in scheduler['events'] if low <= e['perf_ns'] <= high]
    updates = [e for e in events if e['event'] == 'output_update']
    outputs = Counter()
    for event in updates:
        obs = event['observation']
        assert obs['status'] == 'accepted_prefix_then_bonus_host_counts' and not obs['is_stale']
        outputs[event['request_key']] += obs['appended_count']
    assert len(outputs) == result['completed'] == 200
    assert set(outputs.values()) == {256}
    assert sum(outputs.values()) == result['total_output_tokens'] == 51200
    workers = []
    for path in sorted(root.glob('worker-*.json')):
        data = read(path)
        assert data['complete'] and data['errors'] == data['dropped'] == 0
        workers.append(dict(rank=data['rank'], events=dict(Counter(e['event'] for e in data['events']))))
    summary = dict(run_id=receipt['run_id'], status='diagnostic_counts_reconciled_not_m01_acceptance',
        requests=len(outputs), output_tokens=sum(outputs.values()), input_tokens=result['total_input_tokens'],
        retained_drafts=sum(e['observation']['retained_drafts'] for e in updates),
        raw_accepted_drafts=sum(e['observation']['raw_accepted_drafts'] for e in updates),
        retained_first_drafts=sum(e['observation']['retained_first_draft'] for e in updates),
        retained_second_drafts=sum(e['observation']['retained_second_draft'] for e in updates),
        skipped_rows=classify(events), workers=workers,
        original_retained_count_complete=scheduler['retained_count_complete'],
        source_sha256=hashes, effective_flops=None, reference_time=None, m01_attainment=None,
        limitations=['Host metadata is not device-final state.',
            'Diagnostic counts cannot be transferred to a different uninstrumented run.',
            'Retained output reconciliation does not close useful prefill/draft FLOPs or reference time.'])
    path = Path('/workspace/m01-capture-r3-derived-summary.json')
    with path.open('x') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
