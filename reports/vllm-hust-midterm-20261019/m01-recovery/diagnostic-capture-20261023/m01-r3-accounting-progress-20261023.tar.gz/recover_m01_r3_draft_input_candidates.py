"""Join observed rows and derive conditional padded-input sampling indices."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/m01-capture-b1-r3')


def local_index(scheduled, drafts, raw):
    if any(type(v) is not int for v in (scheduled,drafts,raw)):
        raise ValueError('Integer extents required')
    if scheduled <= 0 or not 0 <= drafts <= 2 or not 1 <= raw <= drafts+1:
        raise ValueError('Unsupported verification extent')
    rejected = drafts + 1 - raw if drafts else 0
    index = scheduled - 1 - rejected
    if index < 0:
        raise ValueError('Selected index outside request')
    return index, rejected


def main():
    hashes = {}

    def read(name):
        raw = (ROOT / name).read_bytes()
        hashes[name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    scheduler = read('scheduler-805337.json')
    frames = {e['frame']:e['identity']['wave'] for e in scheduler['events'] if e['event']=='delivery'}
    workers = []
    for name in ('worker-805910.json','worker-805911.json'):
        data = read(name)
        rows = {}
        for e in data['events']:
            if e['event'] != 'host_gdn_metadata':
                continue
            assert len(e['groups']) == 1
            g = e['groups'][0]
            for i,key in enumerate(e['request_keys']):
                identity = (e['identity']['wave'],key)
                assert identity not in rows
                rows[identity] = dict(length=g['cu'][i+1]-g['cu'][i],
                                      offset=g['cu'][i], verification=i in g['verify_ids'])
        workers.append(rows)
    assert workers[0] == workers[1]
    records, counts, matched = [], Counter(), set()
    for e in scheduler['events']:
        if e['event'] not in ('output_update','not_updated'):
            continue
        identity = (frames[e['frame']],e['request_key'])
        assert identity not in matched
        matched.add(identity)
        row = workers[0][identity]
        assert row['length'] == e['scheduled_tokens']
        counts[e['event']] += 1
        if e['event'] == 'not_updated':
            continue
        obs = e['observation']
        assert obs['status'] == 'accepted_prefix_then_bonus_host_counts'
        index,rejected = local_index(row['length'],e['drafts'],obs['raw_count'])
        counts['conditional_rejected_padding_rows'] += rejected
        records.append(dict(wave=identity[0],request_key=identity[1],
                            local_sample_index=index, global_sample_index=row['offset']+index,
                            rejected_rows=rejected, scheduled_rows=row['length']))
    assert matched == set(workers[0])
    report = dict(status='target_rows_joined_conditional_draft_indices_only',
        counts=dict(counts), records=records, source_sha256=hashes,
        effective_flops=None, limitations=[
            'Index algebra follows prepare_inputs_padded; actual draft branch selection is not captured.',
            'Skipped rows have no raw sample count and no reconstructed draft index.',
            'Raw target output counts precede terminal trimming; retained drafts are not draft input rows.',
            'Does not prove draft cache lifetime, subsequent-step positions or useful context work.'])
    with Path('/workspace/m01-r3-draft-input-candidates.json').open('x') as stream:
        json.dump(report,stream,indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=report['status'],counts=report['counts'],matched_rows=len(matched))))


if __name__ == '__main__':
    main()
