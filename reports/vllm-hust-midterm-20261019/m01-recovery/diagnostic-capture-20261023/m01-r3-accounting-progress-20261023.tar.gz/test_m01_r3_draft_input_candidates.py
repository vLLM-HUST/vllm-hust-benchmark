import pytest
from recover_m01_r3_draft_input_candidates import local_index


@pytest.mark.parametrize('raw,expected',[(1,(0,2)),(2,(1,1)),(3,(2,0))])
def test_two_draft_verification(raw,expected):
    assert local_index(3,2,raw) == expected


def test_prefill_keeps_last_input_index():
    assert local_index(1562,0,1) == (1561,0)


@pytest.mark.parametrize('args',[(0,0,1),(1,2,1),(3,2,0),(3,2,4),(3,3,1)])
def test_invalid_extents_rejected(args):
    with pytest.raises(ValueError):
        local_index(*args)
