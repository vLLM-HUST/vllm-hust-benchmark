"""Small real-NPU event qualification, never a model throughput measurement."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/gennova-measurements/publication-fence-v1-qualification')

def child():
    from publication_fence_probe_v1 import run
    run(OUT)

def main():
    OUT.mkdir(exist_ok=False)
    locks = []
    receipt = {'status': 'admitting', 'performance_publication': False}
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for index in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            (OUT / f'npu-before-{index}.txt').write_text(smi)
            assert all((f'No running processes found in NPU {i}' in smi for i in range(4, 8)))
            time.sleep(2)
        cache = OUT / 'runtime-cache'
        cache.mkdir(exist_ok=False)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TRITON_CACHE_DIR=str(cache / 'triton'), TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'), VLLM_CACHE_ROOT=str(cache / 'vllm'))
        with (OUT / 'child.log').open('x') as log:
            completed = subprocess.run([sys.executable, str(Path(__file__)), '--child'], env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        receipt['exit_code'] = completed.returncode
        assert completed.returncode == 0
        receipt['status'] = 'passed'
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (OUT / 'npu-after.txt').write_text(smi)
        receipt['all_four_idle_after'] = all((f'No running processes found in NPU {i}' in smi for i in range(4, 8)))
        with (OUT / 'receipt.json').open('x') as stream:
            json.dump(receipt, stream, indent=2)
            stream.write('\n')
        for stream in locks:
            stream.close()
    print(json.dumps(receipt))
if __name__ == '__main__':
    child() if sys.argv[1:] == ['--child'] else main()
