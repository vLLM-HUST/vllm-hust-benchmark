import pytest
import hashlib
import json
from pathlib import Path

from assemble_r19_accounted_families import subtotal


def entry(name, amount, scope='already_global'):
    return {'family': name, 'global_basic_operations': amount, 'counting_scope': scope}


def test_shards_are_already_summed_not_multiplied_again():
    assert subtotal([entry('global', 10), entry('shards', 14, 'sum_two_tp_shards')]) == 24


def test_duplicate_family_rejected():
    with pytest.raises(AssertionError, match='Duplicate'):
        subtotal([entry('prefix_scan', 10), entry('prefix_scan', 10)])


@pytest.mark.parametrize('amount', [-1, 1.5, True, None])
def test_invalid_amount_rejected(amount):
    with pytest.raises(AssertionError):
        subtotal([entry('family', amount)])


def test_ambiguous_counting_scope_rejected():
    with pytest.raises(AssertionError):
        subtotal([entry('family', 10, 'unknown')])


def test_real_r19_source_ledgers_and_no_full_model_claim():
    root = Path(__file__).resolve().parent
    result = json.loads((root / 'r19-accounted-families.json').read_text())
    for name, digest in result['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    actual = {item['family']: item['global_basic_operations'] for item in result['families']}
    inside = 'inside_request_under_clock_tolerance'

    def read(name):
        return json.loads((root / name).read_text())

    matrix = read('r19-matrix-accounting.json')['cohorts'][inside]
    expected = {
        'linear_and_expert_projections': matrix['projection_semantic_subtotal'],
        'causal_attention_qk_av': matrix['causal_qk_av_semantic_subtotal'],
        'vocabulary_projection': read('r19-vocab-window.json')['inside_projection_subtotal'],
        'rms_residual_and_gdn_output_norm': read('r19-norm-semantics.json')['cohorts'][inside]['basic_arithmetic_subtotal'],
        'attention_softmax_basic': read('r19-softmax-semantics.json')['cohorts'][inside]['canonical_add_subtract_multiply_count'],
        'rope_moe_router_and_full_attention_gate': read('r19-scalar-semantics.json')['cohorts'][inside]['basic_subtotal'],
        'gdn_prefill_kkt_wy_inverse_ho_and_prefix_scan': sum(
            row['cohorts'][inside]['basic_arithmetic_subtotal'] for row in read('r19-device-gdn-prefill.json')['ranks']),
        'gdn_qk_l2_and_preprocess_gate_valid_rows': sum(
            row['cohorts'][inside]['scopes']['logical_valid_rows']['basic_arithmetic_subtotal']
            for row in read('r19-gdn-preprocess-semantics.json')['ranks']),
    }
    ranks = read('r19-device-gdn-ledger.json')['ranks']
    expected['gdn_convolution'] = sum(row['cohorts'][inside]['convolution_basic_arithmetic'] for row in ranks)
    expected['gdn_active_recurrence'] = sum(row['cohorts'][inside]['recurrent_basic_arithmetic'] for row in ranks)
    assert actual == expected
    assert sum(expected.values()) == result['accounted_basic_operation_subtotal']
    assert result['model_effective_flops'] is result['m01_attainment'] is None
    assert {item['id'] for item in result['remaining_checks']} == {
        'gdn_preprocess_mapping', 'stream_dependencies', 'numerical_coverage', 'matched_capacity'}
