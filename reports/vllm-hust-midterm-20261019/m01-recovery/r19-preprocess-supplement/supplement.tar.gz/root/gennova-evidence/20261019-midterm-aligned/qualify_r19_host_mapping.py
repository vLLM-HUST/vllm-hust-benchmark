"""Replay pinned CPU metadata construction on r19 partitions, without inference."""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from audit_r19_gdn_publications import join

ROOT = Path(__file__).resolve().parent
RUN = Path('/workspace/gennova-measurements/microflow-token-accounting-r19')


def check_maps(lengths, roles, capacity, pre, verify, restore):
    offsets = np.concatenate(([0], np.cumsum(lengths)))
    expected = [np.concatenate([np.arange(offsets[i], offsets[i + 1])
                for i, role in enumerate(roles) if role == selected])
                if any(role == selected for role in roles) else np.array([], dtype=np.int64)
                for selected in (False, True)]
    for mapping, wanted, base in zip((pre, verify), expected, (0, capacity), strict=True):
        assert np.array_equal(mapping[:len(wanted)], wanted)
        assert np.all(mapping[len(wanted):] == 0)
        assert np.array_equal(restore[wanted], base + np.arange(len(wanted)))
    combined = np.concatenate(expected)
    assert np.array_equal(np.sort(combined), np.arange(sum(lengths)))
    return len(expected[0]), len(expected[1])


def replay(constructor, group, record):
    meta, fields = record['metadata'], record['device_fields']
    cu = [row[0] for row in fields['cu']]
    assert cu == meta['host_cu'] == group['cu']
    lengths = np.diff(cu).tolist()
    roles = [i in meta['verify_ids'] for i in range(len(lengths))]
    assert [i for i, role in enumerate(roles) if not role] == meta['prefill_ids']
    requests, capacity, width = group['requests'], group['capacity'], group['width']
    assert width == 3 and meta['tokens'] == group['tokens'] == capacity

    def zeros(*shape, dtype=torch.int64):
        return torch.zeros(shape, dtype=dtype)

    # Real CPU tensors provide the pinned implementation's numpy views.
    core = SimpleNamespace(capacity=capacity, width=width, decode=meta['decode_only'],
        requests=requests, cu=zeros(requests + 2, dtype=torch.int32),
        prefill_conv=zeros(requests + 1, 1, dtype=torch.int32),
        verify_conv=zeros(requests + 1, 1, dtype=torch.int32),
        initial=zeros(requests + 1, dtype=torch.bool), accepted=zeros(requests + 1, dtype=torch.int32),
        prefill_map=zeros(capacity), verify_map=zeros(requests * width), restore=zeros(capacity),
        verify_ids=zeros(requests + 1),
        prefill=SimpleNamespace(cu=zeros(requests + 2, dtype=torch.int32), state=zeros(requests + 1, 2),
            indices={size: zeros(capacity // size + requests + 1, 2) for size in (64, 256)}),
        verify=SimpleNamespace(cu=zeros(requests + 2, dtype=torch.int32), slots=zeros(requests + 1, width),
            accepted=zeros(requests + 1, dtype=torch.int32)))
    host = constructor(core)
    slots = np.zeros((len(lengths), width), dtype=np.int64)
    for j, i in enumerate(meta['verify_ids']):
        slots[i] = fields['verify_slots'][j]
    for j, i in enumerate(meta['prefill_ids']):
        slots[i] = fields['prefill_state'][j][0]
    initial = np.array([row[0] for row in fields['initial']], dtype=bool)
    host.prepare(lengths, roles, slots, initial)
    assert np.array_equal(host.h.cu[:len(cu)], cu)
    if core.decode:
        assert all(roles) and np.array_equal(host.v.cu[:len(cu)], cu)
        return {'direct_tokens': sum(lengths), 'mapped_prefill_tokens': 0, 'mapped_verify_tokens': 0}
    pre, verify = check_maps(lengths, roles, capacity, host.h.prefill_map, host.h.verify_map, host.h.restore)
    return {'direct_tokens': 0, 'mapped_prefill_tokens': pre, 'mapped_verify_tokens': verify}


def main():
    receipt_path = RUN / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    payload_path = ROOT / 'payload-receipt.json'
    assert hashlib.sha256(payload_path.read_bytes()).hexdigest() == receipt['input_hashes']['payload-receipt.json']
    source = ROOT / 'payload/betterscale/models/qwen35/host_metadata.py'
    digest = json.loads(payload_path.read_text())['payload_hashes']['models/qwen35/host_metadata.py']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
    spec = importlib.util.spec_from_file_location('qualified_host_metadata', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    paths = [Path(__file__), ROOT / 'audit_r19_gdn_publications.py', receipt_path, payload_path, source]
    ranks = []
    for item in receipt['gdn_publication_exports']:
        pid = item['pid']
        publication = RUN / f'gdn-publication-{pid}.json'
        capture = RUN / f'moe-deferred-{pid}.json'
        assert hashlib.sha256(publication.read_bytes()).hexdigest() == item['sha256']
        capture_digest = next(row['sha256'] for row in receipt['deferred_exports'] if row['pid'] == pid)
        assert hashlib.sha256(capture.read_bytes()).hexdigest() == capture_digest
        counts = {'direct_tokens': 0, 'mapped_prefill_tokens': 0, 'mapped_verify_tokens': 0}
        calls = 0
        for frame, groups in join(json.loads(capture.read_text())['frames'], json.loads(publication.read_text())['records']):
            for group, record in groups:
                for name, value in replay(module.HostMetadata, group, record).items():
                    counts[name] += value
                calls += 1
        ranks.append({'pid': pid, 'publications': calls, 'tokens': counts})
        paths.extend((publication, capture))
    result = {'status': 'pinned_cpu_mapping_replayed_on_all_r19_partitions', 'ranks': ranks,
              'actual_device_map_contents_observed': False,
              'model_effective_flops': None, 'm01_attainment': None,
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              'limitations': ['CPU reconstruction qualifies mapping construction and observed host/device query lengths, not actual device map contents or publication-stream completion.',
                             'Slots are replay fixtures from final device fields; no historical model state or output tensor is reconstructed.',
                             'Counts include tail publications and are not request-window performance results.']}
    with (ROOT / 'r19-host-mapping-qualification.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(ranks))


if __name__ == '__main__':
    main()
