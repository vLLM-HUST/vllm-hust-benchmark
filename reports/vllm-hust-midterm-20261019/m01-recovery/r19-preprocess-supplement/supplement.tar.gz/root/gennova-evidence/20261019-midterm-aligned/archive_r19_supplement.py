"""Archive incremental checks while pinning unchanged r19 evidence by digest."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
BASE = Path('/workspace/r19-publication-evidence/archive.json')
OUT = Path('/workspace/r19-supplement-evidence')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    base = json.loads(BASE.read_text())
    assert base['archive_sha256'] == 'd5886d402bf34dfbc884ac5aa28769a3b7e18b97e81ce273d4ab2fd75a0d0fdc'
    prior = {item['name']: item for item in base['members']}
    names = [
        'audit_gdn_preprocess_semantics.py', 'derive_r19_gdn_preprocess.py',
        'r19-gdn-preprocess-semantics.json', 'test_gdn_preprocess_semantics.py',
        'assemble_r19_accounted_families.py', 'r19-accounted-families.json',
        'test_r19_accounted_families.py', 'qualify_r19_host_mapping.py',
        'r19-host-mapping-qualification.json', 'test_r19_host_mapping.py',
        'publication_fence_probe_v1.py', 'prepare_publication_fence_probe.py',
        'qualify_publication_fence_v1.py', 'test_publication_fence_evidence.py',
        'r19-supplement-tests.xml', Path(__file__).name,
    ]
    paths = {ROOT / name for name in names}
    probe = Path('/workspace/gennova-measurements/publication-fence-v1-qualification')
    paths.update(path for path in probe.iterdir() if path.is_file())
    for path in list(paths):
        if path.suffix != '.json':
            continue
        record = json.loads(path.read_text())
        for source, digest in record.get('source_sha256', {}).items():
            target = Path(source)
            assert sha(target) == digest
            paths.add(target)
    OUT.mkdir(exist_ok=False)
    references, members = [], []
    packed = OUT / 'supplement.tar.gz'
    with tarfile.open(packed, 'w:gz') as archive:
        for path in sorted(paths):
            assert path.is_file() and not path.is_symlink()
            name = str(path).lstrip('/')
            item = {'name': name, 'bytes': path.stat().st_size, 'sha256': sha(path)}
            if name in prior:
                assert item == prior[name], 'Existing raw evidence changed'
                references.append(item)
            else:
                archive.add(path, arcname=name, recursive=False)
                members.append(item)
    result = {'archive': packed.name, 'archive_sha256': sha(packed),
              'archive_bytes': packed.stat().st_size, 'members': members,
              'base_archive_sha256': base['archive_sha256'],
              'base_manifest_sha256': sha(BASE), 'base_references': references,
              'scope': 'GDN preprocessing and source-semantic subtotal, CPU partition replay and bounded NPU publication-fence qualification; not full M01 attainment.'}
    with (OUT / 'archive.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'members': len(members), 'base_references': len(references),
                      'archive_bytes': result['archive_bytes'], 'sha256': result['archive_sha256']}))


if __name__ == '__main__':
    main()
