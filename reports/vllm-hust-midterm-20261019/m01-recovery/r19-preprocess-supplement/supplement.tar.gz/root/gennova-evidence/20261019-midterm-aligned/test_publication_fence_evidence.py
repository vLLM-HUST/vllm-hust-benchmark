"""Check provenance and scope of the real-NPU publication qualification."""
import hashlib
import json
from pathlib import Path

OUT = Path('/workspace/gennova-measurements/publication-fence-v1-qualification')


def test_real_device_result_and_source_pins():
    result = json.loads((OUT / 'device-result.json').read_text())
    receipt = json.loads((OUT / 'receipt.json').read_text())
    assert receipt['status'] == 'passed' and receipt['exit_code'] == 0
    assert receipt['all_four_idle_after'] is True
    assert result['model_run'] is False and result['performance_publication'] is False
    for name, digest in result['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    after = (OUT / 'npu-after.txt').read_text()
    assert all(f'No running processes found in NPU {i}' in after for i in range(4, 8))


def test_contended_single_bank_and_uncontended_double_bank_are_distinguished():
    cases = json.loads((OUT / 'device-result.json').read_text())['cases']
    assert [case['banks'] for case in cases] == [1, 2]
    for case in cases:
        assert case['publications'] == 129 and case['payload_bytes'] == 65536
        assert case['all_payload_bytes_matched'] is True
        assert case['reused_bank_publications'] == 129 - case['banks']
        assert len(set(case['publication_streams'])) == case['banks']
        assert case['compute_stream'] not in case['publication_streams']
    assert cases[0]['pending_uploads_observed_before_acquire'] > 0
    assert cases[0]['pending_consumers_observed_before_reuse'] > 0
    assert cases[1]['pending_uploads_observed_before_acquire'] == 0
    assert cases[1]['pending_consumers_observed_before_reuse'] == 0
