from pathlib import Path

import pytest

from audit_gdn_preprocess_semantics import basic, operations, verify_source

ROOT = Path(__file__).resolve().parent


def test_one_row_and_scope_scaling():
    counts = operations(1)
    assert basic(counts) == 2 * 8 * (128 + 127 + 1 + 128) + 16 * 3 == 6192
    assert counts['inverse_sqrt_evaluations'] == 16
    assert counts['sigmoid_evaluations'] == 16
    assert operations(0) == {key: 0 for key in counts}
    assert operations(30) == {key: value * 30 for key, value in counts.items()}


@pytest.mark.parametrize('value', [-1, 1.5, True, None])
def test_bad_extents(value):
    with pytest.raises(ValueError):
        operations(value)


def test_actual_source_and_changed_formula_rejected():
    source = (ROOT / 'payload/betterscale/models/qwen35/preprocess.py').read_text()
    verify_source(source)
    with pytest.raises(AssertionError):
        verify_source(source.replace('1.0e-6', '1.0e-5'))
