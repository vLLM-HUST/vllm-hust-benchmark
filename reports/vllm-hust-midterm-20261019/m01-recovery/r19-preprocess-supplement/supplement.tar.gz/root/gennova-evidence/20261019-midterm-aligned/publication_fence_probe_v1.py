"""Exercise pinned metadata publication methods on real NPU streams."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_methods(source):
    frame = next(node for node in ast.parse(source).body
                 if isinstance(node, ast.ClassDef) and node.name == 'Frame')
    methods = [node for node in frame.body if isinstance(node, ast.FunctionDef)
               and node.name in ('acquire', 'publish', 'release')]
    assert {node.name for node in methods} == {'acquire', 'publish', 'release'}
    tree = ast.Module(body=[ast.ClassDef(name='QualifiedFrame', bases=[], keywords=[],
                      body=methods, decorator_list=[])], type_ignores=[])
    namespace = {}
    exec(compile(ast.fix_missing_locations(tree), '<pinned-publication-methods>', 'exec'), namespace)
    return namespace['QualifiedFrame']


def run(out):
    import torch
    import torch_npu  # noqa: F401

    receipt_path = Path('/workspace/gennova-measurements/microflow-token-accounting-r19/receipt.json')
    payload_path = ROOT / 'payload-receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert hashlib.sha256(payload_path.read_bytes()).hexdigest() == receipt['input_hashes']['payload-receipt.json']
    source = ROOT / 'payload/betterscale/patches/qwen_gdn/publication.py'
    expected = json.loads(payload_path.read_text())['payload_hashes']['patches/qwen_gdn/publication.py']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    frame_type = load_methods(source.read_text())
    torch.npu.set_device(0)
    rows, size = 129, 65536
    compute = torch.npu.current_stream()
    matrix = torch.ones((256, 256), device='npu', dtype=torch.bfloat16)
    scratch = torch.empty_like(matrix)
    torch.mm(matrix, matrix, out=scratch)
    torch.npu.synchronize()
    cases = []
    for bank_count in (1, 2):
        banks = []
        for _ in range(bank_count):
            frame = frame_type()
            frame.stream = torch.npu.Stream()
            frame.stream.wait_stream(compute)
            frame.uploaded, frame.consumed = torch.npu.Event(), torch.npu.Event()
            frame.has_upload = frame.has_consumer = False
            frame.host = torch.empty(size, dtype=torch.uint8, pin_memory=True)
            frame.device = torch.empty(size, dtype=torch.uint8, device='npu')
            assert frame.stream.npu_stream != compute.npu_stream
            banks.append(frame)
        observed = torch.empty((rows, size), dtype=torch.uint8, device='npu')
        pending_uploads, pending_consumers = 0, 0
        expected_patterns = []
        for index in range(rows):
            frame = banks[index % bank_count]
            pending_uploads += int(frame.has_upload and not frame.uploaded.query())
            pending_consumers += int(frame.has_consumer and not frame.consumed.query())
            frame.acquire()
            pattern = (index * 37 + 11) % 251
            expected_patterns.append(pattern)
            frame.host.fill_(pattern)
            frame.publish()
            # Queue compute before the metadata read to exercise device reuse fencing.
            for _ in range(4):
                torch.mm(matrix, matrix, out=scratch)
            observed[index].copy_(frame.device)
            frame.release()
        torch.npu.synchronize()
        actual = observed.cpu()
        for index, pattern in enumerate(expected_patterns):
            assert torch.all(actual[index] == pattern).item(), f'Publication mismatch at {index}'
        cases.append({'banks': bank_count, 'publications': rows, 'payload_bytes': size,
                      'reused_bank_publications': rows - bank_count,
                      'pending_uploads_observed_before_acquire': pending_uploads,
                      'pending_consumers_observed_before_reuse': pending_consumers,
                      'all_payload_bytes_matched': True,
                      'compute_stream': compute.npu_stream,
                      'publication_streams': [frame.stream.npu_stream for frame in banks]})
    paths = [Path(__file__), ROOT / 'qualify_publication_fence_v1.py', source, payload_path, receipt_path]
    result = {'status': 'real_npu_publication_fence_qualification_passed', 'cases': cases,
              'model_run': False, 'performance_publication': False,
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              'limitations': [
                  'Uses unmodified acquire/publish/release method ASTs with real pinned-host and NPU buffer fixtures; not full MTPFrame initialization.',
                  'Validates bounded publication ordering, not historical device map contents, all model streams or graph replay.',
                  'No tensor-valued model weights, KV or Mamba state from an earlier run is used.',
              ]}
    with (out / 'device-result.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
