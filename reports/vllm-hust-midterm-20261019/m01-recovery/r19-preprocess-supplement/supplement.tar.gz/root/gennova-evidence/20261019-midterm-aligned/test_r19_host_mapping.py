import numpy as np
import pytest

from qualify_r19_host_mapping import check_maps


def test_interleaved_role_partition_and_restore():
    assert check_maps([2, 1, 3], [False, True, False], 8,
                     np.array([0, 1, 3, 4, 5, 0, 0, 0]), np.array([2, 0, 0]),
                     np.array([0, 1, 8, 2, 3, 4, 0, 0])) == (5, 1)


@pytest.mark.parametrize('fault', ['duplicate', 'wrong_restore', 'dirty_padding'])
def test_invalid_maps_rejected(fault):
    pre, verify, restore = np.array([0, 1, 0, 0]), np.array([2, 0, 0]), np.array([0, 1, 4, 0])
    if fault == 'duplicate':
        pre[1] = 0
    elif fault == 'wrong_restore':
        restore[2] = 0
    else:
        verify[2] = 1
    with pytest.raises(AssertionError):
        check_maps([2, 1], [False, True], 4, pre, verify, restore)
