"""Reuse the qualified exclusive-device runner with a new bounded probe."""
import ast
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent


if __name__ == '__main__':
    path = ROOT / 'qualify_logits_device_v1.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == '9a9230da86d7bd39075e63b71e4db4d15543ed8bf32dabad70e977313bf83549'
    tree = ast.parse(path.read_text().replace('logits-device-v1-qualification', 'publication-fence-v1-qualification'))
    replacement = ast.parse('def child():\n    from publication_fence_probe_v1 import run\n    run(OUT)\n').body[0]
    matched = 0
    for index, node in enumerate(tree.body):
        if isinstance(node, ast.FunctionDef) and node.name == 'child':
            tree.body[index] = replacement
            matched += 1
    assert matched == 1
    with (ROOT / 'qualify_publication_fence_v1.py').open('x') as stream:
        stream.write(ast.unparse(ast.fix_missing_locations(tree)) + '\n')
