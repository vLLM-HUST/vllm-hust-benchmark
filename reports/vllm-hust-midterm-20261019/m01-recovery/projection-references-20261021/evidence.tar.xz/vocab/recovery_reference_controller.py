"""Shared reservation and custody for bounded recovered-runtime calibrations."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
from measure_microflow import descendant, stop

ROOT = Path(__file__).resolve().parent


def run(out, probe_name, source_names, timeout=900):
    out = Path(out)
    out.mkdir(exist_ok=False)
    names = set(source_names) | {Path(__file__).name, probe_name, 'runtime-gdn-recovery-r2.sh', 'measure_microflow.py'}
    receipt = {'status': 'admitting', 'started': time.time(), 'prior_cache_imported': False,
        'reserved_devices': [4, 5, 6, 7], 'computing_devices': [4, 5],
        'source_sha256': {str(ROOT / n): hashlib.sha256((ROOT / n).read_bytes()).hexdigest() for n in sorted(names)}}
    locks, child = [], None
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for index in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            (out / f'npu-before-{index}.txt').write_text(smi)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
            time.sleep(2)
        cache = out / 'cache'
        cache.mkdir()
        env = dict(os.environ, ASCEND_RT_VISIBLE_DEVICES='0,1', TASK_QUEUE_ENABLE='0',
            TRITON_CACHE_DIR=str(cache / 'triton'), VLLM_CACHE_ROOT=str(cache / 'vllm'),
            TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'), XDG_CACHE_HOME=str(cache / 'xdg'))
        receipt['command'] = ['bash', str(ROOT / 'runtime-gdn-recovery-r2.sh'), str(ROOT / probe_name)]
        with (out / 'child.log').open('x') as log, (out / 'npu-samples.jsonl').open('x') as samples:
            child = subprocess.Popen(receipt['command'], env=env, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            receipt['child_pid'] = child.pid
            deadline = time.monotonic() + timeout
            results = out / 'results'
            while child.poll() is None:
                assert time.monotonic() < deadline, 'Calibration timeout'
                if not (results / 'go').exists() and all((results / f'ready-{r}.json').exists() for r in (0, 1)):
                    (results / 'go').write_text(str(time.time()) + '\n')
                smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps({'wall': time.time(), 'raw': smi}) + '\n')
                samples.flush()
                for match in re.finditer(r'\|\s*[4-7]\s+0\s*\|\s*(\d+)\s*\|', smi):
                    pid = int(match[1])
                    try:
                        owned = os.getpgid(pid) == child.pid or descendant(pid, {child.pid})
                    except ProcessLookupError:
                        continue
                    assert owned, 'Foreign NPU process; no admission'
                time.sleep(1)
        receipt['probe_exit_code'] = child.returncode
        assert child.returncode == 0
        receipt['status'] = 'completed_pending_independent_audit'
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        receipt['cleanup_exit_code'] = stop(child)
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (out / 'npu-after.txt').write_text(smi)
        receipt['all_four_idle_after'] = all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
        receipt['ended'] = time.time()
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        for stream in locks:
            stream.close()
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['status'] == 'completed_pending_independent_audit' and receipt['all_four_idle_after'] else 1
