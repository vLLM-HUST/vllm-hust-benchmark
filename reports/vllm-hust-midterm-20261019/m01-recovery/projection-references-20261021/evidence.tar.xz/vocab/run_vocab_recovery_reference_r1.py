from pathlib import Path
from recovery_reference_controller import run

if __name__ == '__main__':
    raise SystemExit(run('/workspace/m01-vocab-reference-recovery-r1', 'vocab_recovery_reference_r1.py',
        [Path(__file__).name, 'vocab_reference_probe.py', 'recovery-vocab-reference-plan-r1.json']))
