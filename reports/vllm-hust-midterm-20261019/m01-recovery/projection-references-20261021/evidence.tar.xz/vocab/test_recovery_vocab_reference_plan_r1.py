from prepare_recovery_vocab_reference_r1 import histogram


def test_target_and_mtp_cohorts_not_conflated():
    raw = {'anchor_host_bracket': [100, 100],
           'target_logits': {'records': [{'start_ms': 10, 'end_ms': 20, 'rows': 8}]},
           'frames': [{'role': 'draft', 'start_ms': 30, 'end_ms': 40,
                       'fields': {'draft_steps': [{'actual_tokens': 12}, {'actual_tokens': 4}]}}]}
    hist = histogram(raw, {'start_wall': 100, 'end_wall': 100.035})
    assert hist == {8: {'target:inside': 1}, 4: {'draft:crosses_boundary': 2}}
