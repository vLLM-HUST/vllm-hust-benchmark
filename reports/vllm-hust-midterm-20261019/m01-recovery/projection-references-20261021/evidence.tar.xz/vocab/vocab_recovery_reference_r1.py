"""Run the existing vocabulary reference in the recovered runtime."""
import hashlib
import json
import os
from pathlib import Path

os.environ['HUST_TOKEN_OBSERVER'] = '0'
import vocab_reference_probe as probe

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/m01-vocab-reference-recovery-r1')
probe.OUT = OUT / 'results'
probe.PLAN = ROOT / 'recovery-vocab-reference-plan-r1.json'


def worker(rank, barrier):
    probe.worker(rank, barrier)
    path = probe.OUT / f'rank-{rank}.json'
    data = json.loads(path.read_text())
    data['runtime_paths'] = {'torch': probe.torch.__file__, 'torch_npu': probe.torch_npu.__file__}
    data['probe_sha256'] = hashlib.sha256(Path(probe.__file__).read_bytes()).hexdigest()
    path.write_text(json.dumps(data, indent=2) + '\n')


if __name__ == '__main__':
    probe.OUT.mkdir(exist_ok=False)
    probe.mp.spawn(worker, args=(probe.mp.get_context('spawn').Barrier(2),), nprocs=2, join=True)
