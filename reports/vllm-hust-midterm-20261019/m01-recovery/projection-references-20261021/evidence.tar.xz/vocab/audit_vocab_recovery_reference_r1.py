"""Verify vocabulary samples and all repetitions before cohort weighting."""
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
from audit_moe_reference import check_samples

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/m01-vocab-reference-recovery-r1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def weighted(cases):
    cohorts = defaultdict(lambda: {'calls': 0, 'rows': 0, 'weighted_repetition_ms': [0.0] * 3,
                                   'sum_case_medians_weighted_ms': 0.0})
    for case in cases:
        assert len(case['timings']) == 3
        values = []
        for i, row in enumerate(case['timings']):
            assert row['repetition'] == i and row['replays'] == 10
            value = row['device_ms'] / 10
            assert math.isfinite(value) and value > 0
            values.append(value)
        for category, calls in case['shape']['cohorts'].items():
            assert type(calls) is int and calls > 0
            item = cohorts[category]
            item['calls'] += calls
            item['rows'] += case['shape']['m'] * calls
            item['sum_case_medians_weighted_ms'] += statistics.median(values) * calls
            for i, value in enumerate(values):
                item['weighted_repetition_ms'][i] += value * calls
    for item in cohorts.values():
        item['repetition_sample_stdev_ms'] = statistics.stdev(item['weighted_repetition_ms'])
    return dict(cohorts)


def main():
    receipt_path = OUT / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'completed_pending_independent_audit'
    assert receipt['probe_exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_four_idle_after'] and receipt['prior_cache_imported'] is False
    for name, digest in receipt['source_sha256'].items():
        assert sha(Path(name)) == digest
    plan_path = ROOT / 'recovery-vocab-reference-plan-r1.json'
    plan = json.loads(plan_path.read_text())
    for name, digest in plan['source_sha256'].items():
        assert sha(Path(name)) == digest
    ranks = []
    for rank in (0, 1):
        path = OUT / 'results' / f'rank-{rank}.json'
        raw = json.loads(path.read_text())
        assert raw['status'] == 'qualified_component_timings' and raw['rank'] == rank
        assert raw['plan_sha256'] == sha(plan_path)
        assert raw['probe_sha256'] == sha(ROOT / 'vocab_reference_probe.py')
        assert len(raw['cases']) == len(plan['cases'])
        max_abs = 0.0
        for actual, expected in zip(raw['cases'], plan['cases'], strict=True):
            assert actual['case'] == expected['case'] and actual['shape'] == expected
            max_abs = max(max_abs, check_samples([actual['check']], plan))
            for timing in actual['timings']:
                assert receipt['started'] <= timing['start_wall'] < timing['end_wall'] <= receipt['ended']
                assert math.isfinite(timing['host_seconds']) and timing['host_seconds'] > 0
        ranks.append({'rank': rank, 'shapes': len(raw['cases']), 'sampled_cpu_max_abs_error': max_abs,
                      'cohorts': weighted(raw['cases']), 'runtime_paths': raw['runtime_paths'],
                      'torch_version': raw['torch_version'], 'torch_npu_version': raw['torch_npu_version'],
                      'raw_sha256': sha(path)})
    result = {'status': 'recovered_runtime_vocabulary_reference_measured', 'ranks': ranks,
              'request_phase': plan['request_phase'], 'all_four_idle_after': True,
              'source_sha256': {str(p): sha(p) for p in (Path(__file__), ROOT / 'audit_moe_reference.py', plan_path, receipt_path)},
              'limitations': plan['limitations'], 'model_effective_flops': None, 'm01_attainment': None}
    with (ROOT / 'vocab-recovery-reference-summary-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
