"""Derive r7 vocabulary reference shapes with explicit device-window cohorts."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import tarfile
from integrate_r18_hardware import classify

ROOT = Path(__file__).resolve().parent


def histogram(data, phase):
    a, b = data['anchor_host_bracket']
    assert a <= b
    hist = defaultdict(Counter)
    for role, records in (('target', data['target_logits']['records']),
                          ('draft', [f for f in data['frames'] if f['role'] == 'draft'])):
        for item in records:
            assert 0 <= item['start_ms'] <= item['end_ms']
            category = classify([a + item['start_ms'] / 1000 - .002, b + item['start_ms'] / 1000 + .002],
                                [a + item['end_ms'] / 1000 - .002, b + item['end_ms'] / 1000 + .002], phase)
            if role == 'target':
                rows, calls = item['rows'], 1
            else:
                steps = item['fields']['draft_steps']
                assert len(steps) == 2
                # Existing replay-input audit establishes one batch-sized projection per MTP step.
                rows, calls = steps[1]['actual_tokens'], 2
            assert type(rows) is int and rows > 0
            hist[rows][f'{role}:{category}'] += calls
    return hist


def main():
    manifest_path = ROOT / 'completed-model-r7-archive.json'
    manifest = json.loads(manifest_path.read_text())
    archive_path = Path('/workspace/m01-completed-model-r7.tar.gz')
    with archive_path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == manifest['sha256']
    summary_path = ROOT / 'vocab-projection-summary-recovery_model_r7.json'
    summary = json.loads(summary_path.read_text())
    window_path = ROOT / 'recovery_model_r7-vocab-window.json'
    window = json.loads(window_path.read_text())
    expected_pids = (372631, 372632)
    wanted = {f'm01-recovery-model-r7/moe-deferred-{pid}.json': pid for pid in expected_pids}
    ranks, hashes = {}, {}
    with tarfile.open(archive_path, 'r|gz') as archive:
        for member in archive:
            if member.name not in wanted:
                continue
            raw = archive.extractfile(member).read()
            digest = hashlib.sha256(raw).hexdigest()
            assert digest == manifest['members'][member.name]['sha256']
            hashes[member.name] = digest
            ranks[wanted[member.name]] = histogram(json.loads(raw), summary['request_phase'])
    assert set(ranks) == set(expected_pids)
    assert ranks[expected_pids[0]] == ranks[expected_pids[1]]
    hist = ranks[expected_pids[0]]
    target_rows = sum(m * sum(v for k, v in counts.items() if k.startswith('target:')) for m, counts in hist.items())
    draft_rows = sum(m * sum(v for k, v in counts.items() if k.startswith('draft:')) for m, counts in hist.items())
    for rank in summary['ranks']:
        assert rank['rows']['target'] == target_rows
        assert rank['rows']['draft_step0'] + rank['rows']['draft_step1'] == draft_rows
        assert all(shape == [124160, 2048] for shape in rank['loaded_head_shapes'].values())
    inside_rows = sum(m * sum(v for k, v in counts.items() if k.endswith(':inside')) for m, counts in hist.items())
    assert 4 * inside_rows * 124160 * 2048 == window['inside_projection_subtotal']
    template_path = ROOT / 'vocab-reference-plan-r1.json'
    plan = json.loads(template_path.read_text())
    plan.pop('source_hashes')
    plan.update(scope='Recovered r7 vocabulary shapes with request-device-window weights.',
        request_phase=summary['request_phase'],
        cases=[{'case': i, 'm': m, 'n': 124160, 'k': 2048, 'cohorts': dict(hist[m])}
               for i, m in enumerate(sorted(hist))],
        archive_sha256=manifest['sha256'], member_sha256=hashes,
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
            (Path(__file__), summary_path, window_path, template_path, ROOT / 'integrate_r18_hardware.py')})
    plan['limitations'].append('Draft projections inherit enclosing frame bounds and the previously verified batch-sized MTP2 replay mapping.')
    with (ROOT / 'recovery-vocab-reference-plan-r1.json').open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'shapes': len(hist), 'target_rows': target_rows, 'draft_rows': draft_rows,
                      'inside_rows': inside_rows, 'calls': sum(sum(v.values()) for v in hist.values())}))


if __name__ == '__main__':
    main()
