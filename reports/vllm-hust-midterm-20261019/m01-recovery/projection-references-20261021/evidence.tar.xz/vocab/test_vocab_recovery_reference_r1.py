import pytest
from audit_vocab_recovery_reference_r1 import weighted


def sample():
    return {'shape': {'m': 4, 'cohorts': {'target:inside': 2, 'draft:after': 1}},
            'timings': [{'repetition': i, 'replays': 10, 'device_ms': v}
                        for i, v in enumerate((10, 20, 30))]}


def test_window_counts_and_median():
    result = weighted([sample()])
    assert result['target:inside']['rows'] == 8
    assert result['target:inside']['weighted_repetition_ms'] == [2, 4, 6]
    assert result['target:inside']['sum_case_medians_weighted_ms'] == 4
    assert result['draft:after']['rows'] == 4


def test_missing_repeat_rejected():
    row = sample()
    row['timings'].pop()
    with pytest.raises(AssertionError):
        weighted([row])
