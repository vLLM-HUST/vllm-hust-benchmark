import json
import pytest
from audit_moe_recovery_reference_r1 import load_timings, weighted


def plan():
    return {'operators': [{'name': 'w13', 'k': 2, 'n': 3}], 'cases': [
        {'case': 0, 'rows': 8, 'cohorts_by_pid': {'1': {'inside': 2, 'crosses_boundary': 1}}}]}


def lines():
    return [json.dumps({'operator': 'w13', 'case': 0, 'replays': 1, 'repetition': i,
        'device_ms': i + 1, 'host_seconds': 1, 'start_wall': 2, 'end_wall': 3}) for i in range(3)]


def test_cohorts_kept_separate_and_median_used():
    p = plan()
    values = load_timings(lines(), p, {'started': 1, 'ended': 4})
    result = weighted(p, values, 1)[0]['cohorts']
    assert result['inside']['weighted_repetition_ms'] == [2, 4, 6]
    assert result['inside']['sum_case_medians_weighted_ms'] == 4
    assert result['crosses_boundary']['calls'] == 1
    assert result['inside']['physical_matrix_operations_including_padding'] == 192


def test_duplicate_rejected():
    with pytest.raises(AssertionError, match='Duplicate timing'):
        load_timings(lines() + lines()[:1], plan(), {'started': 1, 'ended': 4})


def test_missing_repeat_rejected():
    with pytest.raises(AssertionError):
        load_timings(lines()[:2], plan(), {'started': 1, 'ended': 4})
