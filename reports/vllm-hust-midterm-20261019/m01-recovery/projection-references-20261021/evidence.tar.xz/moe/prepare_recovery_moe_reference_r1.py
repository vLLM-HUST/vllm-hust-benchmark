"""Freeze retained r7 GMM distributions, with request-window cohorts."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import tarfile
from integrate_r18_hardware import classify

ROOT = Path(__file__).resolve().parent


def catalog(data, phase):
    roles = {role: [frame for frame in data['frames'] if frame['role'] == role]
             for role in ('target', 'draft')}
    a, b = data['anchor_host_bracket']
    assert a <= b
    counts = defaultdict(Counter)
    layer_counts = []
    for layer in data['layers']:
        contexts = []
        for frame in roles[layer['role']]:
            assert 0 <= frame['start_ms'] <= frame['end_ms']
            category = classify([a + frame['start_ms'] / 1000 - .002,
                                 b + frame['start_ms'] / 1000 + .002],
                                [a + frame['end_ms'] / 1000 - .002,
                                 b + frame['end_ms'] / 1000 + .002], phase)
            steps = frame['fields']['draft_steps'] if layer['role'] == 'draft' else [None]
            assert steps
            contexts.extend((category, frame['fields']['padded_tokens']) for _ in steps)
        assert len(contexts) == len(layer['group_counts']) == layer['calls']
        per_layer = Counter()
        for (category, padded), distribution in zip(contexts, layer['group_counts'], strict=True):
            assert len(distribution) == 256
            assert all(type(n) is int and n >= 0 for n in distribution)
            assert sum(distribution) == 8 * padded
            counts[tuple(distribution)][category] += 1
            per_layer[category] += 1
        layer_counts.append({'role': layer['role'], 'name': layer['name'], 'cohorts': dict(per_layer)})
    return counts, layer_counts


def main():
    archive_path = Path('/workspace/m01-completed-model-r7.tar.gz')
    manifest = json.loads((ROOT / 'completed-model-r7-archive.json').read_text())
    with archive_path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == manifest['sha256']
    phase_path = ROOT / 'recovery_model_r7-matrix-accounting.json'
    phase = json.loads(phase_path.read_text())['request_phase']
    wanted = {f'm01-recovery-model-r7/moe-deferred-{pid}.json': pid for pid in (372631, 372632)}
    ranks, catalogs, hashes = [], {}, {}
    with tarfile.open(archive_path, 'r|gz') as archive:
        for member in archive:
            if member.name not in wanted:
                continue
            raw = archive.extractfile(member).read()
            digest = hashlib.sha256(raw).hexdigest()
            assert digest == manifest['members'][member.name]['sha256']
            hashes[member.name] = digest
            data = json.loads(raw)
            counts, layers = catalog(data, phase)
            pid = wanted[member.name]
            catalogs[pid] = counts
            cohorts = Counter()
            for values in counts.values():
                cohorts.update(values)
            ranks.append({'pid': pid, 'layers': layers, 'cohorts': dict(cohorts),
                          'distinct_distributions': len(counts), 'calls': sum(cohorts.values())})
    assert set(catalogs) == {372631, 372632}
    all_shapes = set().union(*[set(values) for values in catalogs.values()])
    ordered = sorted(all_shapes, key=lambda row: (sum(row), row))
    template_path = ROOT / 'moe-reference-plan-r2.json'
    template = json.loads(template_path.read_text())
    plan = {key: template[key] for key in ('operators', 'experts', 'group_list_type', 'split_item',
        'group_type', 'weight_layout', 'warmups', 'repetitions', 'timed_replays', 'seed', 'atol', 'rtol')}
    plan.update(status='frozen_before_measurement', request_phase=phase,
        scope='All retained r7 physical GMM distributions; per-rank request cohorts retained separately.',
        cases=[{'case': i, 'group_counts': list(row), 'rows': sum(row),
                'observed_calls': sum(catalogs[372631].get(row, {}).values()),
                'cohorts_by_pid': {str(pid): dict(catalogs[pid].get(row, {})) for pid in sorted(catalogs)}}
               for i, row in enumerate(ordered)],
        ranks=sorted(ranks, key=lambda item: item['pid']),
        archive_sha256=manifest['sha256'], member_sha256=hashes,
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (Path(__file__), phase_path, template_path, ROOT / 'integrate_r18_hardware.py')},
        limitations=template['limitations'] + [
            'Cohorts use enclosing current-stream frame events and existing 2 ms mapping tolerance.',
            'Draft steps inherit their enclosing frame; no finer per-step device interval is inferred.',
            'Retain all cohorts; do not silently include crossing or outside calls in request-only totals.'],
        model_effective_flops=None, m01_attainment=None)
    with (ROOT / 'recovery-moe-reference-plan-r1.json').open('x') as stream:
        json.dump(plan, stream, separators=(',', ':'))
        stream.write('\n')
    print(json.dumps({'cases': len(ordered), 'ranks': [{k: v for k, v in rank.items() if k != 'layers'}
                                                    for rank in plan['ranks']]}))


if __name__ == '__main__':
    main()
