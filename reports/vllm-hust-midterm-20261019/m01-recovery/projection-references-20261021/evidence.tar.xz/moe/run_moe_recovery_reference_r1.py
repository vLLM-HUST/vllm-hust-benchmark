"""Exclusive bounded calibration, fresh caches, with owned-process cleanup."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
from measure_microflow import descendant, stop

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/m01-moe-reference-recovery-r1')
NAMES = ('run_moe_recovery_reference_r1.py', 'moe_recovery_reference_r1.py',
         'moe_reference_full.py', 'recovery-moe-reference-plan-r1.json',
         'runtime-gdn-recovery-r2.sh', 'measure_microflow.py')


def main():
    OUT.mkdir(exist_ok=False)
    receipt = {'status': 'admitting', 'started': time.time(), 'prior_cache_imported': False,
               'reserved_devices': [4, 5, 6, 7], 'computing_devices': [4, 5],
               'source_sha256': {str(ROOT / name): hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                 for name in NAMES}}
    locks, child = [], None
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for index in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            (OUT / f'npu-before-{index}.txt').write_text(smi)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
            time.sleep(2)
        cache = OUT / 'cache'
        cache.mkdir()
        env = dict(os.environ, ASCEND_RT_VISIBLE_DEVICES='0,1', TASK_QUEUE_ENABLE='0',
                   TRITON_CACHE_DIR=str(cache / 'triton'), VLLM_CACHE_ROOT=str(cache / 'vllm'),
                   TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'), XDG_CACHE_HOME=str(cache / 'xdg'))
        receipt['command'] = ['bash', str(ROOT / 'runtime-gdn-recovery-r2.sh'), str(ROOT / 'moe_recovery_reference_r1.py')]
        with (OUT / 'child.log').open('x') as log, (OUT / 'npu-samples.jsonl').open('x') as samples:
            child = subprocess.Popen(receipt['command'], env=env, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            receipt['child_pid'] = child.pid
            deadline = time.monotonic() + 1200
            run = OUT / 'results'
            while child.poll() is None:
                assert time.monotonic() < deadline, 'Calibration timeout'
                if not (run / 'go').exists() and all((run / f'ready-{rank}.json').exists() for rank in (0, 1)):
                    (run / 'go').write_text(str(time.time()) + '\n')
                smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps({'wall': time.time(), 'raw': smi}) + '\n')
                samples.flush()
                for match in re.finditer(r'\|\s*[4-7]\s+0\s*\|\s*(\d+)\s*\|', smi):
                    pid = int(match[1])
                    try:
                        owned = os.getpgid(pid) == child.pid or descendant(pid, {child.pid})
                    except ProcessLookupError:
                        continue
                    assert owned, 'Foreign NPU process; no admission'
                time.sleep(1)
        receipt['probe_exit_code'] = child.returncode
        assert child.returncode == 0
        receipt['status'] = 'completed_pending_independent_audit'
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        receipt['cleanup_exit_code'] = stop(child)
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (OUT / 'npu-after.txt').write_text(smi)
        receipt['all_four_idle_after'] = all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
        receipt['ended'] = time.time()
        (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        for stream in locks:
            stream.close()
    print(json.dumps(receipt), flush=True)
    return 0 if receipt['status'] == 'completed_pending_independent_audit' and receipt['all_four_idle_after'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
