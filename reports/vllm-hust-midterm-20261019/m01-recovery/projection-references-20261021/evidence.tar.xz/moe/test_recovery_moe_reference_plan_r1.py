import pytest
from prepare_recovery_moe_reference_r1 import catalog


def fixture(role='target'):
    return {'anchor_host_bracket': [100, 100], 'frames': [
        {'role': role, 'start_ms': 10, 'end_ms': 20,
         'fields': {'padded_tokens': 1, 'draft_steps': [{}, {}]}}],
        'layers': [{'role': role, 'name': 'layer', 'calls': 1,
                    'group_counts': [[8] + [0] * 255]}]}


def test_inside_and_crossing_are_separate():
    raw = fixture()
    counts, _ = catalog(raw, {'start_wall': 100, 'end_wall': 101})
    assert list(counts.values()) == [{'inside': 1}]
    counts, _ = catalog(raw, {'start_wall': 100.01, 'end_wall': 101})
    assert list(counts.values()) == [{'crosses_boundary': 1}]


def test_draft_uses_recorded_steps():
    raw = fixture('draft')
    raw['layers'][0]['calls'] = 2
    raw['layers'][0]['group_counts'] *= 2
    counts, _ = catalog(raw, {'start_wall': 100, 'end_wall': 101})
    assert list(counts.values()) == [{'inside': 2}]


def test_mismatched_routing_count_rejected():
    raw = fixture()
    raw['layers'][0]['group_counts'][0][0] = 7
    with pytest.raises(AssertionError):
        catalog(raw, {'start_wall': 100, 'end_wall': 101})
