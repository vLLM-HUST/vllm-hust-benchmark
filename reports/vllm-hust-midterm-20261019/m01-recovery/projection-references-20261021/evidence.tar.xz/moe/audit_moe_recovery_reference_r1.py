"""Audit all GMM samples and timings; weight by retained request cohorts."""
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
from audit_moe_reference import check_samples

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/m01-moe-reference-recovery-r1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_timings(lines, plan, receipt):
    values = defaultdict(dict)
    operators = {op['name'] for op in plan['operators']}
    for line in lines:
        row = json.loads(line)
        assert row['operator'] in operators and 0 <= row['case'] < len(plan['cases'])
        assert row['replays'] == 1 and row['repetition'] in (0, 1, 2)
        assert math.isfinite(row['device_ms']) and row['device_ms'] > 0
        assert math.isfinite(row['host_seconds']) and row['host_seconds'] > 0
        assert receipt['started'] <= row['start_wall'] < row['end_wall'] <= receipt['ended']
        key = row['operator'], row['case']
        assert row['repetition'] not in values[key], 'Duplicate timing'
        values[key][row['repetition']] = row['device_ms']
    assert set(values) == {(op, case['case']) for op in operators for case in plan['cases']}
    assert all(set(repeats) == {0, 1, 2} for repeats in values.values())
    return values


def weighted(plan, values, pid):
    result = []
    for op in plan['operators']:
        cohorts = defaultdict(lambda: {'weighted_repetition_ms': [0.0] * 3,
            'sum_case_medians_weighted_ms': 0.0, 'calls': 0, 'physical_matrix_operations_including_padding': 0})
        for case in plan['cases']:
            timings = values[op['name'], case['case']]
            for name, calls in case['cohorts_by_pid'][str(pid)].items():
                assert type(calls) is int and calls >= 0
                row = cohorts[name]
                row['calls'] += calls
                row['physical_matrix_operations_including_padding'] += 2 * case['rows'] * op['k'] * op['n'] * calls
                row['sum_case_medians_weighted_ms'] += statistics.median(timings.values()) * calls
                for i in range(3):
                    row['weighted_repetition_ms'][i] += timings[i] * calls
        for row in cohorts.values():
            row['repetition_sample_stdev_ms'] = statistics.stdev(row['weighted_repetition_ms'])
        result.append({'operator': op['name'], 'cohorts': dict(cohorts)})
    return result


def main():
    receipt_path = OUT / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'completed_pending_independent_audit'
    assert receipt['probe_exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_four_idle_after'] and receipt['prior_cache_imported'] is False
    for name, digest in receipt['source_sha256'].items():
        assert sha(Path(name)) == digest
    plan_path = ROOT / 'recovery-moe-reference-plan-r1.json'
    plan = json.loads(plan_path.read_text())
    for name, digest in plan['source_sha256'].items():
        assert sha(Path(name)) == digest
    buckets = defaultdict(list)
    for index, case in enumerate(plan['cases']):
        assert case['case'] == index and case['rows'] == sum(case['group_counts'])
        buckets[case['rows']].append(index)
    ranks = []
    for rank, pid in enumerate((372631, 372632)):
        raw_path = OUT / 'results' / f'rank-{rank}.json'
        raw = json.loads(raw_path.read_text())
        assert raw['rank'] == rank and raw['status'] == 'qualified_component_timings'
        assert raw['plan_sha256'] == sha(plan_path)
        assert raw['probe_sha256'] == sha(ROOT / 'moe_reference_full.py')
        assert len(raw['buckets']) == len(buckets) * len(plan['operators'])
        seen, max_abs = set(), 0.0
        for bucket in raw['buckets']:
            op = bucket['operator']
            assert op in plan['operators']
            ids = buckets[bucket['rows']]
            key = op['name'], bucket['rows']
            assert key not in seen
            seen.add(key)
            assert bucket['cases'] == len(ids) and bucket['timed_cases'] == len(ids) * 3
            assert bucket['weight_format'] == 2
            assert bucket['weight_stride'] == [op['k'] * op['n'], op['n'], 1]
            assert [item['case'] for item in bucket['checks']] == sorted({ids[0], ids[-1]})
            for item in bucket['checks']:
                max_abs = max(max_abs, check_samples(item['samples'], plan))
        timing_path = OUT / 'results' / f'timings-{rank}.jsonl'
        with timing_path.open() as stream:
            values = load_timings(stream, plan, receipt)
        ranks.append({'rank': rank, 'pid': pid, 'sampled_cpu_max_abs_error': max_abs,
            'timings': sum(len(item) for item in values.values()), 'operators': weighted(plan, values, pid),
            'runtime_paths': raw['runtime_paths'], 'torch_version': raw['torch_version'],
            'torch_npu_version': raw['torch_npu_version'], 'raw_sha256': sha(raw_path),
            'timings_sha256': sha(timing_path)})
    result = {'status': 'recovered_runtime_all_retained_gmm_distributions_measured',
        'request_phase': plan['request_phase'], 'ranks': ranks, 'all_four_idle_after': True,
        'source_sha256': {str(path): sha(path) for path in (Path(__file__), ROOT / 'audit_moe_reference.py', plan_path, receipt_path)},
        'limitations': plan['limitations'], 'model_effective_flops': None, 'm01_attainment': None}
    with (ROOT / 'moe-recovery-reference-summary-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
