"""Recompute exact group coverage, sampled checks and all reference timings."""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_samples(checks, plan):
    maximum = 0.0
    assert checks
    for check in checks:
        assert check["finite"] and check["close"]
        actual = [v for row in check["actual"] for v in row]
        expected = [v for row in check["cpu_fp32"] for v in row]
        assert len(actual) == len(expected) == len(check["rows"]) * len(check["columns"])
        assert all(math.isfinite(v) for v in actual + expected)
        assert all(abs(a - e) <= plan["atol"] + plan["rtol"] * abs(e)
                   for a, e in zip(actual, expected))
        difference = max(abs(a - e) for a, e in zip(actual, expected))
        assert abs(difference - check["max_abs"]) < 1e-7
        maximum = max(maximum, difference)
    return maximum


def audit(root):
    plan_path = root / "moe-reference-plan-r2.json"
    plan = json.loads(plan_path.read_text())
    control = json.loads((root / "moe-reference-control-r2/receipt.json").read_text())
    assert control["probe_exit_code"] == control["cleanup_exit_code"] == 0
    assert control["all_devices_released"] and not control["sampler_errors"]
    for name, sha in control["input_hashes"].items():
        assert digest(root / name) == sha, name
    expected = {tuple(c["group_counts"]): c["observed_calls"] for c in plan["cases"]}
    assert len(expected) == len(plan["cases"]) == 37128
    for name, sha in plan["source_events_sha256"].items():
        path = root / "microflow-token-accounting-r9" / name
        assert digest(path) == sha
        observed = Counter()
        for line in path.read_text().splitlines():
            event = json.loads(line)
            if event["event"] == "moe_device_counts" and (
                plan["request_phase"]["start_wall"] <= event["wall"] <= plan["request_phase"]["end_wall"]
            ):
                observed.update(tuple(row) for layer in event["layers"] for row in layer["group_counts"])
        assert observed == expected
    buckets = defaultdict(list)
    for index, case in enumerate(plan["cases"]):
        assert case["case"] == index and case["rows"] == sum(case["group_counts"])
        assert len(case["group_counts"]) == 256
        assert all(type(n) is int and n >= 0 for n in case["group_counts"])
        buckets[case["rows"]].append(case["case"])
    assert plan["repetitions"] == 3 and plan["timed_replays"] == 1
    ranks = []
    for rank in (0, 1):
        raw_path = root / f"moe-reference-r2/rank-{rank}.json"
        raw = json.loads(raw_path.read_text())
        assert raw["rank"] == rank and raw["status"] == "qualified_component_timings"
        assert raw["plan_sha256"] == digest(plan_path)
        assert len(raw["buckets"]) == 2 * len(buckets)
        seen_buckets = set()
        max_abs = 0.0
        for bucket in raw["buckets"]:
            op = bucket["operator"]
            assert op in plan["operators"]
            ids = buckets[bucket["rows"]]
            identity = (op["name"], bucket["rows"])
            assert identity not in seen_buckets
            seen_buckets.add(identity)
            assert bucket["cases"] == len(ids)
            assert bucket["timed_cases"] == 3 * len(ids)
            assert bucket["weight_format"] == 2
            assert bucket["weight_stride"] == [op["k"] * op["n"], op["n"], 1]
            assert [c["case"] for c in bucket["checks"]] == sorted({ids[0], ids[-1]})
            for checks in bucket["checks"]:
                max_abs = max(max_abs, check_samples(checks["samples"], plan))
        timings_path = root / f"moe-reference-r2/timings-{rank}.jsonl"
        timings = defaultdict(dict)
        for line in timings_path.read_text().splitlines():
            row = json.loads(line)
            assert row["replays"] == 1 and row["repetition"] in (0, 1, 2)
            assert 0 <= row["case"] < len(plan["cases"])
            assert row["operator"] in {op["name"] for op in plan["operators"]}
            assert row["device_ms"] > 0 and row["host_seconds"] > 0
            assert control["started"] <= row["start_wall"] < row["end_wall"] <= control["ended"]
            key = row["operator"], row["case"]
            assert row["repetition"] not in timings[key]
            timings[key][row["repetition"]] = row["device_ms"]
        assert len(timings) == len(plan["cases"]) * 2
        operators = []
        for op in plan["operators"]:
            totals = [0., 0., 0.]
            median_total = 0.
            arithmetic = 0
            for case in plan["cases"]:
                times = timings[op["name"], case["case"]]
                assert set(times) == {0, 1, 2}
                weight = case["observed_calls"]
                for repetition in range(3):
                    totals[repetition] += times[repetition] * weight
                median_total += statistics.median(times.values()) * weight
                arithmetic += 2 * case["rows"] * op["k"] * op["n"] * weight
            operators.append({
                "operator": op["name"], "distributions": len(plan["cases"]),
                "repetition_weighted_device_ms": totals,
                "sum_case_median_weighted_ms": median_total,
                "device_matrix_flops_including_padding": arithmetic,
                "component_tflops_from_case_medians": arithmetic / (median_total * 1e9),
            })
        ranks.append({
            "rank": rank, "max_sample_abs_error": max_abs,
            "group_update_checks": sum(len(b["checks"]) for b in raw["buckets"]),
            "timing_records": len(plan["cases"]) * 2 * 3,
            "operators": operators, "result_sha256": digest(raw_path),
            "timings_sha256": digest(timings_path),
        })
    return {
        "status": "qualified_all_observed_device_gmm_distributions",
        "plan_sha256": digest(plan_path), "receipt_sha256": digest(root / "moe-reference-control-r2/receipt.json"),
        "unique_distributions": len(plan["cases"]), "row_buckets": len(buckets),
        "ranks": ranks, "all_devices_released": True,
        "model_effective_flops": None, "attainment_percent": None,
        "limitations": plan["limitations"] + [
            "ND layout follows the pinned runtime source and default BF16 configuration, not independent model weight-format readback.",
            "Component rates include device graph replay timing and do not establish a full-model matched aggregate capacity.",
        ],
    }


if __name__ == "__main__":
    result = audit(ROOT)
    with (ROOT / "moe-reference-summary-r2.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result, indent=2))
