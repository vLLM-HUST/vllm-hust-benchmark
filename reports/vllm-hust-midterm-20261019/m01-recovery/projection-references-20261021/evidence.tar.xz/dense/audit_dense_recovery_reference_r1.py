"""Reweight newly measured dense timings by r7 calls; retain all repetitions."""
import hashlib
import json
import math
from pathlib import Path
import statistics
from audit_moe_reference import check_samples

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/m01-dense-reference-recovery-r1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def weighted(cases, actual):
    assert len({tuple(row['shape'][k] for k in ('m', 'n', 'k')) for row in cases}) == len(cases)
    totals = [0.0] * 5
    median_sum, seen, operations = 0.0, set(), 0
    for row in cases:
        shape = tuple(row['shape'][k] for k in ('m', 'n', 'k'))
        if shape not in actual:
            continue
        seen.add(shape)
        calls = actual[shape]
        assert type(calls) is int and calls > 0
        assert len(row['timings']) == 5
        values = []
        for index, timing in enumerate(row['timings']):
            assert timing['repetition'] == index and timing['replays'] == 100
            value = timing['device_ms'] / timing['replays']
            assert math.isfinite(value) and value > 0
            values.append(value)
            totals[index] += value * calls
        median_sum += statistics.median(values) * calls
        operations += 2 * math.prod(shape) * calls
    assert seen == set(actual), 'Missing measured shape'
    return {'weighted_repetition_ms': totals, 'sum_case_medians_weighted_ms': median_sum,
            'repetition_min_ms': min(totals), 'repetition_max_ms': max(totals),
            'repetition_mean_ms': statistics.mean(totals),
            'repetition_sample_stdev_ms': statistics.stdev(totals),
            'physical_dense_matrix_operations_including_padding': operations,
            'physical_component_tflops': operations / (median_sum * 1e9)}


def main():
    receipt = json.loads((OUT / 'receipt.json').read_text())
    assert receipt['status'] == 'completed_pending_independent_audit'
    assert receipt['probe_exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_four_idle_after'] and receipt['prior_cache_imported'] is False
    for name, digest in receipt['source_sha256'].items():
        assert sha(Path(name)) == digest
    plan_path = ROOT / 'dense-reference-plan-r2.json'
    plan = json.loads(plan_path.read_text())
    coverage_path = ROOT / 'recovery-dense-coverage-r1.json'
    coverage = json.loads(coverage_path.read_text())
    ranks = []
    for rank in (0, 1):
        path = OUT / 'results' / f'rank-{rank}.json'
        data = json.loads(path.read_text())
        assert data['rank'] == rank and data['status'] == 'qualified_component_timings'
        assert data['plan_sha256'] == sha(plan_path)
        assert data['probe_sha256'] == sha(ROOT / 'dense_reference_repeat.py')
        assert len(data['cases']) == len(plan['cases']) == 121
        max_abs = 0.0
        for row, expected in zip(data['cases'], plan['cases'], strict=True):
            assert row['shape'] == expected and row['case'] == expected['case']
            assert row['weight_format'] == 2 and row['weight_stride'] == [expected['k'], 1]
            max_abs = max(max_abs, check_samples([row['check']], plan))
            for timing in row['timings']:
                assert receipt['started'] <= timing['start_wall'] < timing['end_wall'] <= receipt['ended']
                assert math.isfinite(timing['host_seconds']) and timing['host_seconds'] > 0
        actual = {tuple(c[k] for k in ('m', 'n', 'k')): c['observed_calls']
                  for c in coverage['ranks'][rank]['cases']}
        ranks.append({'rank': rank, 'cases': len(data['cases']), 'calls': sum(actual.values()),
                      'sampled_cpu_max_abs_error': max_abs, 'runtime_paths': data['runtime_paths'],
                      'torch_version': data['torch_version'], 'torch_npu_version': data['torch_npu_version'],
                      'raw_sha256': sha(path), **weighted(data['cases'], actual)})
    result = {'status': 'recovered_runtime_dense_reference_measured', 'ranks': ranks,
              'request_phase': coverage['request_phase'], 'all_four_idle_after': True,
              'source_sha256': {str(p): sha(p) for p in (Path(__file__), OUT / 'receipt.json',
                  plan_path, coverage_path, ROOT / 'audit_moe_reference.py')},
              'limitations': ['Synthetic bounded inputs and resident per-shape weights do not reproduce the full model working set.',
                  'Sampled CPU FP32 checks do not validate every matrix output.',
                  'Weighted isolated component times are not the measured application critical path.',
                  'Device event durations may include host submission gaps; all five repetitions are retained.',
                  'Counts include graph padding; physical component TFLOPS are not useful whole-model FLOPS or M01 attainment.',
                  'Grouped experts, vocabulary projection and non-dense families are not included.'],
              'model_effective_flops': None, 'm01_attainment': None}
    with (ROOT / 'dense-recovery-reference-summary-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'ranks': ranks}))


if __name__ == '__main__':
    main()
