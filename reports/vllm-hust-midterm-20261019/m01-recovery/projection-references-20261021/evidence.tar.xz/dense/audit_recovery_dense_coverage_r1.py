"""Compare recovered-run dense shapes with prior calibration, without admitting rates."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent


def counts(events, micro, phase, partition):
    inventory = next(e for e in events if e['event'] == 'loaded_model_inventory')
    modules = {role: [m for m in inventory[role]['modules']
                     if m['type'].startswith('vllm_ascend.ops.linear.')
                     and len(m['parameters'].get('weight', {}).get('shape', [])) == 2]
               for role in ('target', 'draft')}
    captured = {(e['layer'], e['tokens'], e['split']) for e in micro
                if e['event'] == 'prefix' and e['capturing'] and e['time'] < phase['start_wall']}
    result, roles = Counter(), Counter()
    for e in events:
        if e['event'] != 'forward_enter' or not phase['start_wall'] <= e['wall'] < phase['end_wall']:
            continue
        assert e['graph_mode'] == 'FULL' and e['valid_extent']
        role, rows = e['role'], e['padded_tokens']
        assert rows > 0
        repetitions = len(e['draft_steps']) if role == 'draft' else 1
        assert repetitions > 0
        roles[role] += 1
        for module in modules[role]:
            assert module['parameters']['weight']['dtype'] == 'torch.bfloat16'
            assert 'bias' not in module['parameters']
            n, k = module['parameters']['weight']['shape']
            pieces = 1
            if role == 'target' and module['name'].endswith('.self_attn.qkv_proj'):
                boundaries = partition(rows)
                pieces = len(boundaries) - 1 if boundaries else 1
                layer = module['name'].removesuffix('.self_attn.qkv_proj')
                assert (layer, rows, pieces > 1) in captured
            assert rows % pieces == 0
            result[rows // pieces, n, k] += repetitions * pieces
    return result, roles, modules


def coverage(actual, reference):
    return [{'m': m, 'n': n, 'k': k, 'observed_calls': calls,
             'prior_shape_present': (m, n, k) in reference}
            for (m, n, k), calls in sorted(actual.items())]


def main():
    archive_path = Path('/workspace/m01-completed-model-r7.tar.gz')
    manifest = json.loads((ROOT / 'completed-model-r7-archive.json').read_text())
    with archive_path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == manifest['sha256']
    phase = json.loads((ROOT / 'recovery_model_r7-matrix-accounting.json').read_text())['request_phase']
    source = ROOT / 'microflow-recovery-payload-r2/hust_prefill_microflow/runtime/microflow.py'
    node = next(n for n in ast.parse(source.read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name == 'partition')
    namespace = {}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), 'exec'), namespace)
    wanted = {f'm01-recovery-model-r7/{kind}-{pid}.jsonl'
              for pid in (372631, 372632) for kind in ('token-accounting', 'microflow')}
    documents, hashes = {}, {}
    with tarfile.open(archive_path, 'r|gz') as archive:
        for member in archive:
            if member.name not in wanted:
                continue
            raw = archive.extractfile(member).read()
            digest = hashlib.sha256(raw).hexdigest()
            assert digest == manifest['members'][member.name]['sha256']
            hashes[member.name] = digest
            documents[member.name] = [json.loads(line) for line in raw.splitlines()]
    assert set(documents) == wanted
    plan_path = ROOT / 'dense-reference-plan-r2.json'
    plan = json.loads(plan_path.read_text())
    reference = {(c['m'], c['n'], c['k']) for c in plan['cases']}
    ranks = []
    for pid in (372631, 372632):
        prefix = 'm01-recovery-model-r7/'
        actual, roles, modules = counts(documents[f'{prefix}token-accounting-{pid}.jsonl'],
            documents[f'{prefix}microflow-{pid}.jsonl'], phase, namespace['partition'])
        assert {role: len(items) for role, items in modules.items()} == {'target': 270, 'draft': 7}
        cases = coverage(actual, reference)
        ranks.append({'pid': pid, 'contexts': dict(roles), 'cases': cases,
                      'missing_shapes': [c for c in cases if not c['prior_shape_present']],
                      'calls': sum(actual.values())})
    assert ranks[0]['cases'] == ranks[1]['cases']
    result = {'status': 'shape_coverage_only_not_capacity_admission', 'request_phase': phase,
              'ranks': ranks, 'archive_sha256': manifest['sha256'], 'member_sha256': hashes,
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in (Path(__file__), source, plan_path)},
              'limitations': ['Shapes and call counts follow loaded modules and recorded FULL graph contexts, not per-linear tracing.',
                  'Prior calibration runtime and weight layout require compatibility review before any rate reuse.',
                  'Physical padded dense shapes do not establish useful-operation coverage or a whole-model reference.'],
              'model_effective_flops': None, 'm01_attainment': None}
    with (ROOT / 'recovery-dense-coverage-r1.json').open('x') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps([{'pid': r['pid'], 'contexts': r['contexts'], 'shapes': len(r['cases']),
                      'missing_shapes': len(r['missing_shapes']), 'calls': r['calls']} for r in ranks]))


if __name__ == '__main__':
    main()
