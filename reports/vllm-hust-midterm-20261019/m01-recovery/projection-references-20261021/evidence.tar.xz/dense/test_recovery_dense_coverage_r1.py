from audit_recovery_dense_coverage_r1 import counts, coverage
import pytest


def test_missing_shape_not_admitted():
    result = coverage({(3, 4, 5): 7, (6, 4, 5): 2}, {(3, 4, 5)})
    assert result[0]['prior_shape_present']
    assert not result[1]['prior_shape_present']
    assert sum(c['observed_calls'] for c in result) == 9


def test_window_and_actual_draft_repetitions():
    module = {'name': 'projection', 'type': 'vllm_ascend.ops.linear.Linear',
              'parameters': {'weight': {'shape': [4, 5], 'dtype': 'torch.bfloat16'}}}
    inventory = {'event': 'loaded_model_inventory', 'target': {'modules': [module]},
                 'draft': {'modules': [module]}}
    def event(wall, role, steps=0):
        return {'event': 'forward_enter', 'wall': wall, 'role': role, 'padded_tokens': 3,
                'graph_mode': 'FULL', 'valid_extent': True, 'draft_steps': [{}] * steps}
    actual, roles, _ = counts([inventory, event(0, 'target'), event(1, 'target'),
        event(2, 'draft', 3), event(3, 'target')], [], {'start_wall': 1, 'end_wall': 3}, lambda _: ())
    assert actual == {(3, 4, 5): 4}
    assert roles == {'target': 1, 'draft': 1}


def test_split_requires_capture_and_preserves_call_multiplicity():
    module = {'name': 'layer.self_attn.qkv_proj', 'type': 'vllm_ascend.ops.linear.Linear',
              'parameters': {'weight': {'shape': [4, 5], 'dtype': 'torch.bfloat16'}}}
    events = [{'event': 'loaded_model_inventory', 'target': {'modules': [module]},
               'draft': {'modules': []}},
              {'event': 'forward_enter', 'wall': 2, 'role': 'target', 'padded_tokens': 8,
               'graph_mode': 'FULL', 'valid_extent': True}]
    phase = {'start_wall': 1, 'end_wall': 3}
    with pytest.raises(AssertionError):
        counts(events, [], phase, lambda _: (0, 4, 8))
    capture = [{'event': 'prefix', 'layer': 'layer', 'tokens': 8, 'split': True,
                'capturing': True, 'time': 0}]
    result, _, _ = counts(events, capture, phase, lambda _: (0, 4, 8))
    assert result == {(4, 4, 5): 2}
