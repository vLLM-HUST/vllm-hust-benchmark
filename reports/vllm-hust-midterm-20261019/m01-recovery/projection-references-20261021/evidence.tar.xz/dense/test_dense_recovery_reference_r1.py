import pytest
from audit_dense_recovery_reference_r1 import weighted


def case(values=(100, 200, 300, 400, 500)):
    return {'shape': {'m': 3, 'n': 4, 'k': 5}, 'timings': [
        {'repetition': i, 'replays': 100, 'device_ms': v} for i, v in enumerate(values)]}


def test_weighting_retains_all_repetitions_not_best():
    result = weighted([case()], {(3, 4, 5): 7})
    assert result['weighted_repetition_ms'] == [7, 14, 21, 28, 35]
    assert result['sum_case_medians_weighted_ms'] == 21
    assert result['physical_dense_matrix_operations_including_padding'] == 840


def test_missing_shape_rejected():
    with pytest.raises(AssertionError, match='Missing measured shape'):
        weighted([case()], {(6, 4, 5): 1})


@pytest.mark.parametrize('values', [(100, 200), (100, 200, 0, 400, 500),
                                    (100, 200, float('nan'), 400, 500)])
def test_bad_samples_rejected(values):
    with pytest.raises(AssertionError):
        weighted([case(values)], {(3, 4, 5): 1})
