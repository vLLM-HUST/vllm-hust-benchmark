"""Read-only HCCS statistics through the installed DCMI interface."""
import ctypes as C
import hashlib
from pathlib import Path
import time

LIB = Path("/usr/local/Ascend/driver/lib64/driver/libdcmi.so")
HEADER = Path("/usr/local/Ascend/driver/include/dcmi_interface_api.h")


class Counters:
    def __init__(self):
        self.lib = C.CDLL(str(LIB))
        self.lib.dcmi_init.restype = C.c_int
        self.lib.dcmi_get_device_info.argtypes = [
            C.c_int, C.c_int, C.c_int, C.c_uint, C.c_void_p, C.POINTER(C.c_uint)
        ]
        self.lib.dcmi_get_device_info.restype = C.c_int
        self.lib.dcmi_get_device_logic_id.argtypes = [C.POINTER(C.c_int), C.c_int, C.c_int]
        self.lib.dcmi_get_device_phyid_from_logicid.argtypes = [C.c_uint, C.POINTER(C.c_uint)]
        assert self.lib.dcmi_init() == 0
        self.mapping = []
        for card in (4, 5):
            logic, phy = C.c_int(-1), C.c_uint(999)
            assert self.lib.dcmi_get_device_logic_id(C.byref(logic), card, 0) == 0
            assert self.lib.dcmi_get_device_phyid_from_logicid(logic.value, C.byref(phy)) == 0
            assert logic.value == card - 4 and phy.value == card
            self.mapping.append(dict(card=card, device=0, logical=logic.value, physical=phy.value))

    def read(self, card, bits=64):
        word = C.c_uint64 if bits == 64 else C.c_uint32
        data = (word * 128)()
        size = C.c_uint(C.sizeof(data))
        before = dict(wall_ns=time.time_ns(), monotonic_ns=time.monotonic_ns())
        code = self.lib.dcmi_get_device_info(
            card, 0, 16, 5 if bits == 64 else 3, C.byref(data), C.byref(size)
        )
        after = dict(wall_ns=time.time_ns(), monotonic_ns=time.monotonic_ns())
        if code != 0 or not 32 * C.sizeof(word) <= size.value <= C.sizeof(data):
            raise RuntimeError(f"DCMI HCCS read failed: card={card}, code={code}, size={size.value}")
        return dict(card=card, bits=bits, before=before, after=after,
                    returned_size=size.value, tx_counts=list(data[:16]), rx_counts=list(data[16:32]))

    def provenance(self):
        idle_check = []
        for card in (4, 5):
            narrow, wide = self.read(card, 32), self.read(card)
            match = all(
                [v % 2**32 for v in wide[direction]] == narrow[direction]
                for direction in ("tx_counts", "rx_counts")
            )
            idle_check.append(dict(card=card, prefix_matches_u32_at_idle=match))
        return dict(mapping=self.mapping, idle_prefix_checks=idle_check,
                    hashes={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (LIB, HEADER)},
                    api="dcmi_get_device_info: HCCS main_cmd=16, U64 sub_cmd=5; read first two 16-port arrays only",
                    scope="Raw flit counters; conversion to bytes requires known-payload qualification.")
