"""Audit frozen logits collective timings and independently sampled link counters."""
import hashlib
import json
from pathlib import Path
import statistics
from audit_collective_grid_v2 import boundary, midpoint

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'recovery-logits-collective-r1'
CONTROL = ROOT / 'recovery-logits-collective-control-r1'


def summarize(phases):
    assert {p['repetition'] for p in phases} == {0, 1, 2} and len(phases) == 3
    rates = [p['aggregate_tx_flits_per_second'] for p in phases]
    qualified = all(rate is not None for rate in rates)
    durations = [p['duration_seconds'] for p in phases]
    return {'counter_qualified_repetitions': sum(rate is not None for rate in rates),
            'seconds_per_512_calls': durations,
            'median_seconds_per_call': statistics.median(durations) / 512,
            'duration_sample_stdev_seconds': statistics.stdev(durations),
            'median_aggregate_tx_flits_per_second': statistics.median(rates) if qualified else None,
            'min_aggregate_tx_flits_per_second': min(rates) if qualified else None,
            'max_aggregate_tx_flits_per_second': max(rates) if qualified else None}


def main():
    receipt_path = CONTROL / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['probe_exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_devices_released'] and not receipt['sampler_errors']
    for name, digest in receipt['input_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    plan_path = ROOT / 'recovery-logits-collective-plan-r1.json'
    plan = json.loads(plan_path.read_text())
    grid = plan['calibration_grid']
    for name, digest in plan['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    paths = [RUN / f'rank-{rank}.json' for rank in (0, 1)]
    ranks = [json.loads(path.read_text()) for path in paths]
    assert all(r['grid_sha256'] == hashlib.sha256(plan_path.read_bytes()).hexdigest() for r in ranks)
    assert all(len(r['phases']) == len(grid) * 3 for r in ranks)
    counter_path = CONTROL / 'counters.jsonl'
    raw = [json.loads(line) for line in counter_path.read_text().splitlines()]
    samples = {card: [row for row in raw if row['card'] == card] for card in (4, 5)}
    resets = {card: sum(any(b[key][i] < a[key][i] for key in ('tx_counts', 'rx_counts') for i in range(16))
                        for a, b in zip(rows, rows[1:])) for card, rows in samples.items()}
    phases = []
    for index, pair in enumerate(zip(*(rank['phases'] for rank in ranks), strict=True)):
        shape_index, repetition = index % len(grid), index // len(grid)
        for rank, phase in enumerate(pair):
            assert phase['rank'] == rank and phase['shape_index'] == shape_index and phase['repetition'] == repetition
            assert all(phase[key] == value for key, value in grid[shape_index].items())
            assert phase['calls'] == 512 and phase['numerics_passed']
            assert receipt['started'] <= phase['start_wall'] < phase['end_wall'] <= receipt['ended']
        start, end = min(p['start_wall'] for p in pair), max(p['end_wall'] for p in pair)
        duration = max(p['end_monotonic'] - p['start_monotonic'] for p in pair)
        assert duration > 0
        devices = []
        for card in (4, 5):
            before, left = boundary(samples[card], start - .25)
            after, right = boundary(samples[card], end + .75)
            assert midpoint(before) + .1 < start
            assert midpoint(before) - .1 > max(p['start_wall'] for p in pair) - 1.0
            assert midpoint(after) - .1 > end
            deltas = {direction: [b - a for a, b in zip(before[direction + '_counts'], after[direction + '_counts'], strict=True)]
                      for direction in ('tx', 'rx')}
            valid = left and right and not resets[card] and all(x >= 0 for values in deltas.values() for x in values)
            devices.append({'card': card, 'boundaries_stable': valid,
                            'start_counter_wall': midpoint(before), 'end_counter_wall': midpoint(after),
                            'tx_flits': deltas['tx'], 'rx_flits': deltas['rx']})
        a, b = devices
        peer = a['tx_flits'][4] == b['rx_flits'][1] and a['rx_flits'][4] == b['tx_flits'][1]
        qualified = peer and all(d['boundaries_stable'] and sum(d['tx_flits']) > 0 for d in devices)
        phases.append({'shape_index': shape_index, 'repetition': repetition, 'duration_seconds': duration,
            'counter_qualified': qualified, 'peer_exact': peer, 'devices': devices,
            'aggregate_tx_flits_per_second': sum(sum(d['tx_flits']) for d in devices) / duration if qualified else None})
    shapes = [{**shape, **summarize([p for p in phases if p['shape_index'] == index])}
              for index, shape in enumerate(grid)]
    sources = [Path(__file__), ROOT / 'audit_collective_grid_v2.py', receipt_path, plan_path, counter_path, *paths]
    result = {'status': 'source_shaped_logits_collective_reference_audited', 'shapes': shapes,
        'phases': phases, 'counter_resets': resets, 'all_devices_released': True,
        'boundary_rule': plan['boundary_rule'], 'limitations': plan['limitations'],
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        'model_effective_flops': None, 'm01_attainment': None}
    with (CONTROL / 'summary.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'shapes': len(shapes), 'fully_counter_qualified': sum(s['counter_qualified_repetitions'] == 3 for s in shapes),
                      'counter_resets': resets, 'all_devices_released': True}))


if __name__ == '__main__':
    main()
