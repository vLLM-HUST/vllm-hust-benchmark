"""Read-only official GB/s interface, retaining actual call boundaries."""
import ctypes as C
import time

from dcmi_hccs64 import Counters


class BandwidthInfo(C.Structure):
    _fields_ = [
        ("profiling_time", C.c_int),
        ("total_txbw", C.c_double),
        ("total_rxbw", C.c_double),
        ("tx_bandwidth", C.c_double * 16),
        ("rx_bandwidth", C.c_double * 16),
    ]


class Bandwidth(Counters):
    def __init__(self):
        super().__init__()
        self.get_bandwidth = self.lib.dcmi_get_hccs_link_bandwidth_info
        self.get_bandwidth.argtypes = [C.c_int, C.c_int, C.POINTER(BandwidthInfo)]
        self.get_bandwidth.restype = C.c_int

    def read_bandwidth(self, card):
        data = BandwidthInfo()
        data.profiling_time = 100
        before = {"wall_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}
        code = self.get_bandwidth(card, 0, C.byref(data))
        after = {"wall_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}
        if code != 0:
            raise RuntimeError(f"DCMI bandwidth failed: card={card}, code={code}")
        return {
            "card": card, "before": before, "after": after,
            "profiling_time_ms": data.profiling_time,
            "total_tx_gbs": data.total_txbw, "total_rx_gbs": data.total_rxbw,
            "tx_gbs": list(data.tx_bandwidth), "rx_gbs": list(data.rx_bandwidth),
        }
