"""Preserve the completed logits reference run without disposable runtime caches."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = Path('/workspace/m01-logits-collective-recovery-r1-evidence.tar.gz')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    control = ROOT / 'recovery-logits-collective-control-r1'
    receipt = json.loads((control / 'receipt.json').read_text())
    summary = json.loads((control / 'summary.json').read_text())
    assert receipt['probe_exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_devices_released'] and not receipt['sampler_errors']
    assert len(summary['shapes']) == 76
    assert all(s['counter_qualified_repetitions'] == 3 for s in summary['shapes'])
    names = set(receipt['input_hashes']) | {
        Path(__file__).name, 'runtime-gdn-recovery-r2.sh',
        'audit_recovery_logits_collective_reference_r1.py',
        'test_recovery_logits_collective_reference_r1.py',
        'test_recovery_logits_collective_coverage_r1.py',
        'recovery-logits-collective-coverage-r1.json',
        'recovery-logits-collective-tests-r1.xml',
        'recovery-logits-collective-coverage-tests-r1.xml',
        'audit_collective_grid_v2.py',
    }
    paths = {ROOT / name for name in names}
    for directory in (control, ROOT / 'recovery-logits-collective-r1'):
        paths.update(p for p in directory.iterdir() if p.is_file())
    for name, digest in receipt['input_hashes'].items():
        assert sha(ROOT / name) == digest
    external = {}
    for path in list(paths):
        if path.suffix != '.json':
            continue
        for name, digest in json.loads(path.read_text()).get('source_sha256', {}).items():
            source = Path(name)
            assert sha(source) == digest, name
            external[name] = digest
    members = []
    assert not OUT.exists()
    with tarfile.open(OUT, 'w:gz') as archive:
        for path in sorted(paths):
            assert path.is_file() and not path.is_symlink()
            name = str(path.relative_to(ROOT))
            members.append({'name': name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
            archive.add(path, arcname=name, recursive=False)
    with tarfile.open(OUT, 'r:gz') as archive:
        assert set(archive.getnames()) == {m['name'] for m in members}
        for member in members:
            assert hashlib.sha256(archive.extractfile(member['name']).read()).hexdigest() == member['sha256']
    record = {'archive': OUT.name, 'sha256': sha(OUT), 'bytes': OUT.stat().st_size,
              'members': members, 'referenced_sources': external,
              'scope': '76 source-shaped logits collectives, TP2, three repetitions; not whole-model communication coverage or M01 attainment.',
              'runtime_wrapper_identity': 'Hash captured at archival time; not an additional launch-time receipt.',
              'excluded': ['Disposable runtime-cache directory; no cache is required to inspect raw measurements.']}
    manifest = ROOT / 'recovery-logits-collective-archive-r1.json'
    with manifest.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: record[k] for k in ('archive', 'sha256', 'bytes')}))


if __name__ == '__main__':
    main()
