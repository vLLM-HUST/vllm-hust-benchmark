"""Reserve all four cards and collect flits plus the official GB/s getter."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import threading
import time
from dcmi_hccs64 import Counters
from dcmi_hccs_bandwidth import Bandwidth
from measure_microflow import descendant, stop
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'recovery-logits-collective-control-r1'
RUN = ROOT / 'recovery-logits-collective-r1'

def main():
    assert not RUN.exists()
    OUT.mkdir(exist_ok=False)
    record = {'started': time.time(), 'reserved_devices': [4, 5, 6, 7], 'computing_devices': [4, 5], 'scope': 'All source-shaped r7 logits payloads, TP2 BF16/INT64, 512 calls per point and three repetitions; not full-model execution counts or M01 attainment.', 'input_hashes': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ('run_recovery_logits_collective_r1.py', 'recovery_logits_collective_probe_r1.py', 'recovery_logits_collective_probe_r1.sh', 'dcmi_hccs64.py', 'dcmi_hccs_bandwidth.py', 'measure_microflow.py', 'recovery-logits-collective-plan-r1.json', 'audit_recovery_logits_collective_coverage_r1.py', 'prepare_recovery_logits_collective_run_r1.py')}}
    locks, child, threads, errors = ([], None, [], [])
    finished = threading.Event()
    ready = [threading.Event(), threading.Event()]

    def sample(index):
        try:
            reader = Counters() if index == 0 else Bandwidth()
            if index == 0:
                record['dcmi'] = reader.provenance()
                assert all((p['prefix_matches_u32_at_idle'] for p in record['dcmi']['idle_prefix_checks']))
            name = 'counters.jsonl' if index == 0 else 'bandwidth.jsonl'
            with (OUT / name).open('x') as stream:
                ready[index].set()
                while not finished.is_set():
                    start = time.monotonic()
                    for card in (4, 5):
                        row = reader.read(card) if index == 0 else reader.read_bandwidth(card)
                        stream.write(json.dumps(row) + '\n')
                    stream.flush()
                    finished.wait(max(0, 0.02 - (time.monotonic() - start)))
        except BaseException as error:
            errors.append(f'sampler-{index}: {type(error).__name__}: {error}')
            ready[index].set()
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            lock = open(name, 'a+b')
            locks.append(lock)
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for index in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            (OUT / f'npu-before-{index}.txt').write_text(smi)
            assert all((f'No running processes found in NPU {n}' in smi for n in range(4, 8)))
            time.sleep(2)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 18493))
        for index in range(2):
            thread = threading.Thread(target=sample, args=(index,))
            threads.append(thread)
            thread.start()
        assert all((event.wait(30) for event in ready)) and (not errors), str(errors)
        with (OUT / 'probe.log').open('x') as log, (OUT / 'npu-samples.jsonl').open('x') as samples:
            child = subprocess.Popen(['bash', str(ROOT / 'recovery_logits_collective_probe_r1.sh')], stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=dict(os.environ, TRITON_CACHE_DIR=str(OUT / 'runtime-cache/triton'), TORCHINDUCTOR_CACHE_DIR=str(OUT / 'runtime-cache/inductor'), VLLM_CACHE_ROOT=str(OUT / 'runtime-cache/vllm')))
            deadline = time.monotonic() + 1200
            while child.poll() is None:
                assert not errors, str(errors)
                assert time.monotonic() < deadline, 'Probe timeout'
                if not (RUN / 'go').exists() and all(((RUN / f'ready-{r}.json').exists() for r in (0, 1))):
                    (RUN / 'go').write_text(str(time.time()) + '\n')
                smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps({'wall': time.time(), 'raw': smi}) + '\n')
                samples.flush()
                for line in smi.splitlines():
                    match = re.match('\\|\\s*[4-7]\\s+0\\s*\\|\\s*(\\d+)\\s*\\|', line)
                    if match:
                        pid = int(match[1])
                        try:
                            owned = os.getpgid(pid) == child.pid or descendant(pid, {child.pid})
                        except ProcessLookupError:
                            continue
                        assert owned, 'Foreign NPU process; no admission'
                time.sleep(1)
            record['probe_exit_code'] = child.returncode
            assert child.returncode == 0
            time.sleep(2)
            assert not errors, str(errors)
            record['status'] = 'collected_pending_unit_and_capacity_audit'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['cleanup_exit_code'] = stop(child)
        finished.set()
        for thread in threads:
            thread.join(timeout=30)
            assert not thread.is_alive()
        record['sampler_errors'] = errors
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (OUT / 'npu-after.txt').write_text(smi)
        record.update(ended=time.time(), all_devices_released=all((f'No running processes found in NPU {n}' in smi for n in range(4, 8))))
        (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
        for lock in locks:
            lock.close()
    print(json.dumps(record, indent=2))
    return 0 if record['status'] == 'collected_pending_unit_and_capacity_audit' and record['all_devices_released'] and (not errors) else 1
if __name__ == '__main__':
    raise SystemExit(main())
