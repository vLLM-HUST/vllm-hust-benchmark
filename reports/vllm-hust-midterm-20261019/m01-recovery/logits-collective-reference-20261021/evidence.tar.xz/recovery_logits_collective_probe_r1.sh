#!/usr/bin/env bash
set -eo pipefail
export ASCEND_RT_VISIBLE_DEVICES=0,1 TASK_QUEUE_ENABLE=0
ROOT=/root/gennova-evidence/20261019-midterm-aligned
exec bash "$ROOT/runtime-gdn-recovery-r2.sh" "$ROOT/recovery_logits_collective_probe_r1.py"
