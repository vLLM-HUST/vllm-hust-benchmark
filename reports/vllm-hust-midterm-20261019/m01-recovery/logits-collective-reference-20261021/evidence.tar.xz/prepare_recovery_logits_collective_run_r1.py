"""Specialize the existing counter-qualified collective runner to r7 logits shapes."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def rewrite(source, destination, replacements, grid_size=None):
    tree = ast.parse(source.read_text())

    class Replace(ast.NodeTransformer):
        def visit_Constant(self, node):
            if isinstance(node.value, str) and node.value in replacements:
                return ast.copy_location(ast.Constant(replacements[node.value]), node)
            if type(node.value) is int and node.value == 900:
                return ast.copy_location(ast.Constant(1200), node)
            if grid_size is not None and type(node.value) is int and node.value == 56:
                return ast.copy_location(ast.Constant(grid_size), node)
            return node

    tree = Replace().visit(tree)
    if grid_size is not None:
        index = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Import)
                     and any(alias.name == 'torch' for alias in node.names))
        tree.body[index:index] = ast.parse("os.environ['HUST_TOKEN_OBSERVER'] = '0'").body
    ast.fix_missing_locations(tree)
    with destination.open('x') as stream:
        stream.write(ast.unparse(tree) + '\n')


def main():
    coverage_path = ROOT / 'recovery-logits-collective-coverage-r1.json'
    coverage = json.loads(coverage_path.read_text())
    for name, digest in coverage['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    keys = ('kind', 'dtype', 'elements', 'rank_size', 'input_bytes_per_call')
    plan = {'status': 'frozen_before_measurement',
        'scope': 'Source-shaped r7 logits collectives; not whole-model HCCL execution counts.',
        'calibration_grid': [{key: row[key] for key in keys} for row in coverage['shapes']],
        'source_calls': coverage['shapes'], 'calls_per_point': 512, 'repetitions': 3,
        'boundary_rule': {'start_offset_seconds': -0.25, 'end_offset_seconds': 0.75,
                          'stable_half_width_seconds': 0.1},
        'limitations': coverage['limitations'] + [
            'Synchronous all_gather probe includes host dispatch and synchronization; not overlapped model-stream timing.',
            'Physical TX flits are counted once across both cards; API input bytes remain a separate quantity.',
            'All three counter-qualified repetitions are required; retain failed points and do not select fastest samples.'],
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
            (Path(__file__), coverage_path, ROOT / 'collective_grid_probe_v1.py', ROOT / 'run_collective_grid_v1.py')},
        'model_effective_flops': None, 'm01_attainment': None}
    with (ROOT / 'recovery-logits-collective-plan-r1.json').open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    replacements = {
        'collective-grid-r1': 'recovery-logits-collective-r1',
        'collective-grid-control-r1': 'recovery-logits-collective-control-r1',
        'collective_grid_probe_v1.py': 'recovery_logits_collective_probe_r1.py',
        'collective_grid_probe_v1.sh': 'recovery_logits_collective_probe_r1.sh',
        'run_collective_grid_v1.py': 'run_recovery_logits_collective_r1.py',
        'diagnostic-collective-payload-grid-v1.json': 'recovery-logits-collective-plan-r1.json',
        'recover_collective_payload_grid.py': 'audit_recovery_logits_collective_coverage_r1.py',
        'prepare_collective_grid_controller.py': Path(__file__).name,
        'All 56 recovered diagnostic shapes, TP2 BF16/INT64, 512 calls per point, three repetitions with synchronous dispatch/fill costs; not r19 or full model attainment.':
            'All source-shaped r7 logits payloads, TP2 BF16/INT64, 512 calls per point and three repetitions; not full-model execution counts or M01 attainment.',
        'Recovered diagnostic shape reference; not r19 execution counts or model attainment. Synchronous dispatch and all-reduce fill costs included.':
            'Recovered r7 logits shape reference; synchronous dispatch included, not model overlap or full-model attainment.',
    }
    rewrite(ROOT / 'collective_grid_probe_v1.py', ROOT / 'recovery_logits_collective_probe_r1.py',
            replacements, len(plan['calibration_grid']))
    rewrite(ROOT / 'run_collective_grid_v1.py', ROOT / 'run_recovery_logits_collective_r1.py', replacements)
    print(json.dumps({'shapes': len(plan['calibration_grid']), 'repetitions': 3, 'calls_per_point': 512}))


if __name__ == '__main__':
    main()
