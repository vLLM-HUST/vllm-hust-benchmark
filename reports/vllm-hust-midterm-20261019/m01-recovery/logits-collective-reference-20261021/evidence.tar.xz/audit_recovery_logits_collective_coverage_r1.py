"""Compare source-shaped r7 logits collectives with the old diagnostic grid."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def shapes(vocab):
    result = defaultdict(lambda: {'calls': 0, 'roles': {}})
    for case in vocab['cases']:
        for category, calls in case['cohorts'].items():
            role, cohort = category.split(':')
            assert role in ('target', 'draft') and type(calls) is int and calls > 0
            # Target gathers its local vocabulary; draft greedy gathers maxima and indices.
            payloads = [('BFP16', case['m'] * case['n'])] if role == 'target' else [
                ('BFP16', case['m']), ('INT64', case['m'])]
            for dtype, elements in payloads:
                key = 'all_gather', dtype, elements, 2
                result[key]['calls'] += calls
                result[key]['roles'][category] = result[key]['roles'].get(category, 0) + calls
    return result


def compare(vocab, old_grid, old_summary):
    old = {(r['kind'], r['dtype'], r['elements'], r['rank_size']) for r in old_grid}
    qualified = {(r['kind'], r['dtype'], r['elements'], r['rank_size']) for r in old_summary
                 if r['counter_qualified_repetitions'] == 3}
    rows = []
    for (kind, dtype, elements, ranks), value in sorted(shapes(vocab).items()):
        key = kind, dtype, elements, ranks
        width = {'BFP16': 2, 'INT64': 8}[dtype]
        rows.append({'kind': kind, 'dtype': dtype, 'elements': elements, 'rank_size': ranks,
            'input_bytes_per_call': elements * width, 'source_calls_per_rank': value['calls'],
            'source_calls_by_role_and_window': value['roles'],
            'prior_shape_present': key in old, 'prior_three_counter_repetitions_qualified': key in qualified})
    return rows


def main():
    names = ['recovery-vocab-reference-plan-r1.json', 'diagnostic-collective-payload-grid-v1.json',
             'collective-grid-control-r1/summary-v2.json', 'm01-recovery-model-r7/receipt.json',
             'recovery_model_r7-loaded-configuration.json', 'serve-token-accounting-v20.sh',
             'recovery-model-payload-r1/betterscale/models/qwen35/small_fish_runtime.py',
             'runtime/vllm_ascend/ops/vocab_parallel_embedding.py',
             'runtime/vllm_ascend/spec_decode/llm_base_proposer.py']
    data = {name: (ROOT / name).read_bytes() for name in names}
    receipt = json.loads(data[names[3]])
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    for name in names[5:7]:
        assert hashlib.sha256(data[name]).hexdigest() == receipt['input_hashes'][name]
    loaded = json.loads(data[names[4]])
    for name in names[7:]:
        path = str(ROOT / name)
        # The proposer source pin is retained in the vocabulary source audit.
        pins = loaded['loaded_source_sha256']
        if path not in pins:
            extra = ROOT / 'vocab-projection-summary-recovery_model_r7.json'
            pins = json.loads(extra.read_text())['source_sha256']
            data[extra.name] = extra.read_bytes()
        assert hashlib.sha256(data[name]).hexdigest() == pins[path]
    assert 'BETTERSCALE_MTP_GREEDY=1' in data[names[5]].decode()
    vocab = json.loads(data[names[0]])
    grid = json.loads(data[names[1]])
    reference = json.loads(data[names[2]])
    rows = compare(vocab, grid['calibration_grid'], reference['shapes'])
    result = {'status': 'source_shaped_logits_collective_gap_inventory',
        'request_phase': vocab['request_phase'], 'shapes': rows,
        'required_shapes': len(rows), 'missing_shapes': sum(not r['prior_shape_present'] for r in rows),
        'source_calls_per_rank': sum(r['source_calls_per_rank'] for r in rows),
        'calls_with_missing_shapes_per_rank': sum(r['source_calls_per_rank'] for r in rows if not r['prior_shape_present']),
        'calls_with_three_counter_qualified_reference_per_rank': sum(r['source_calls_per_rank'] for r in rows if r['prior_three_counter_repetitions_qualified']),
        'source_sha256': {str(ROOT / name): hashlib.sha256(raw).hexdigest() for name, raw in data.items()},
        'limitations': ['Source-shaped logits-only inventory; not observed per-collective r7 HCCL device execution counts.',
            'Target all-gather follows the ordinary TP2 logits path; draft greedy follows pinned max-value/index gathers.',
            'Does not cover hidden-state, expert, embedding or control collectives.',
            'Prior shape presence is not runtime/topology/rate admission; no capacity is reused here.',
            'API input payload bytes are not physical HCCS link bytes; do not divide physical counters by an API-payload rate.'],
        'model_effective_flops': None, 'm01_attainment': None}
    result['source_sha256'][str(Path(__file__))] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    with (ROOT / 'recovery-logits-collective-coverage-r1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('shapes', 'source_sha256', 'limitations')}))


if __name__ == '__main__':
    main()
