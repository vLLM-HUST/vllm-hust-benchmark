import pytest
from audit_recovery_logits_collective_reference_r1 import summarize


def samples():
    return [{'repetition': i, 'duration_seconds': 1 + i,
             'aggregate_tx_flits_per_second': 10 + i} for i in range(3)]


def test_all_samples_required_not_fastest():
    result = summarize(samples())
    assert result['median_aggregate_tx_flits_per_second'] == 11
    assert result['median_seconds_per_call'] == 2 / 512
    assert result['seconds_per_512_calls'] == [1, 2, 3]


def test_counter_failure_preserved_without_rate():
    rows = samples()
    rows[1]['aggregate_tx_flits_per_second'] = None
    result = summarize(rows)
    assert result['counter_qualified_repetitions'] == 2
    assert result['median_aggregate_tx_flits_per_second'] is None


def test_missing_repeat_rejected():
    with pytest.raises(AssertionError):
        summarize(samples()[:2])
