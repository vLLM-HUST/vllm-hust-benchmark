from audit_recovery_logits_collective_coverage_r1 import compare


def test_draft_does_not_gather_full_vocab():
    vocab = {'cases': [{'m': 24, 'n': 124160, 'cohorts': {'target:inside': 1, 'draft:inside': 2}}]}
    rows = compare(vocab, [], [])
    assert {(r['dtype'], r['elements'], r['source_calls_per_rank']) for r in rows} == {
        ('BFP16', 24 * 124160, 1), ('BFP16', 24, 2), ('INT64', 24, 2)}


def test_equal_bytes_wrong_dtype_not_matching_reference():
    vocab = {'cases': [{'m': 24, 'n': 124160, 'cohorts': {'draft:inside': 2}}]}
    old = [{'kind': 'all_gather', 'dtype': 'BFP16', 'elements': 96, 'rank_size': 2}]
    rows = compare(vocab, old, [])
    assert all(not row['prior_shape_present'] for row in rows)


def test_one_good_counter_repeat_not_enough_to_admit_three():
    vocab = {'cases': [{'m': 1, 'n': 124160, 'cohorts': {'target:inside': 3}}]}
    old = [{'kind': 'all_gather', 'dtype': 'BFP16', 'elements': 124160, 'rank_size': 2}]
    rows = compare(vocab, old, [{**old[0], 'counter_qualified_repetitions': 1}])
    assert rows[0]['prior_shape_present']
    assert not rows[0]['prior_three_counter_repetitions_qualified']
