"""TP2 calibration for every shape in the recovered diagnostic payload grid."""
import hashlib
import json
import os
from pathlib import Path
import time
os.environ['HUST_TOKEN_OBSERVER'] = '0'
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
import torch_npu
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'recovery-logits-collective-r1'
GRID = ROOT / 'recovery-logits-collective-plan-r1.json'
CALLS = 512
REPETITIONS = 3

def worker(rank):
    grid = json.loads(GRID.read_text())['calibration_grid']
    assert len(grid) == 76
    torch.npu.set_device(rank)
    dist.init_process_group('hccl', rank=rank, world_size=2)
    dist.barrier()
    (OUT / f'ready-{rank}.json').write_text(json.dumps({'rank': rank, 'wall': time.time()}))
    deadline = time.monotonic() + 180
    while not (OUT / 'go').exists():
        if time.monotonic() > deadline:
            raise TimeoutError('Counter sampler did not admit probe')
        time.sleep(0.1)
    phases = []
    for repetition in range(REPETITIONS):
        for index, shape in enumerate(grid):
            dtype = {'BFP16': torch.bfloat16, 'INT64': torch.int64}[shape['dtype']]
            tensor = torch.full((shape['elements'],), rank + 1, dtype=dtype, device=f'npu:{rank}')
            gathered = [torch.empty_like(tensor) for _ in range(2)]
            assert tensor.numel() * tensor.element_size() == shape['input_bytes_per_call']

            def operation():
                if shape['kind'] == 'all_reduce':
                    tensor.fill_(rank + 1)
                    dist.all_reduce(tensor)
                else:
                    assert shape['kind'] == 'all_gather'
                    dist.all_gather(gathered, tensor)
                torch.npu.synchronize()
            for _ in range(5):
                operation()
            dist.barrier()
            torch.npu.synchronize()
            time.sleep(1.0)
            start_wall, start_mono = (time.time(), time.monotonic())
            for _ in range(CALLS):
                operation()
            end_wall, end_mono = (time.time(), time.monotonic())
            correct = bool(torch.all(tensor == 3).item()) if shape['kind'] == 'all_reduce' else all((bool(torch.all(value == other + 1).item()) for other, value in enumerate(gathered)))
            assert correct
            phase = {**shape, 'shape_index': index, 'repetition': repetition, 'rank': rank, 'calls': CALLS, 'start_wall': start_wall, 'end_wall': end_wall, 'start_monotonic': start_mono, 'end_monotonic': end_mono, 'numerics_passed': correct}
            phases.append(phase)
            with (OUT / f'phases-{rank}.jsonl').open('a') as stream:
                stream.write(json.dumps(phase) + '\n')
            time.sleep(1.0)
    dist.barrier()
    with (OUT / f'rank-{rank}.json').open('x') as stream:
        json.dump({'rank': rank, 'phases': phases, 'grid_sha256': hashlib.sha256(GRID.read_bytes()).hexdigest(), 'scope': 'Recovered r7 logits shape reference; synchronous dispatch included, not model overlap or full-model attainment.'}, stream, indent=2)
        stream.write('\n')
    dist.destroy_process_group()
if __name__ == '__main__':
    os.environ['MASTER_ADDR'] = '127.0.0.1'
    os.environ['MASTER_PORT'] = '18493'
    OUT.mkdir(exist_ok=False)
    mp.spawn(worker, nprocs=2, join=True)
