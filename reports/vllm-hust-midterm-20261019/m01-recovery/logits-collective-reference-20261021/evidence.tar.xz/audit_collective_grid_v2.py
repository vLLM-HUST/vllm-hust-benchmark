"""Keep every calibration point and qualify its physical-counter boundaries."""
import hashlib
import json
from pathlib import Path
import statistics
ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'collective-grid-r1'
CONTROL = ROOT / 'collective-grid-control-r1'

def midpoint(row):
    return (row['before']['wall_ns'] + row['after']['wall_ns']) / 2000000000.0

def boundary(samples, target):

    def nanos(row):
        return (row['before']['wall_ns'] + row['after']['wall_ns']) // 2
    target_ns = round(target * 1000000000.0)
    chosen = min(samples, key=lambda row: abs(nanos(row) - target_ns))
    nearby = [row for row in samples if abs(nanos(row) - nanos(chosen)) <= 100000000]
    stable = len(nearby) >= 3 and max(map(nanos, nearby)) - min(map(nanos, nearby)) >= 100000000
    stable = stable and abs(nanos(chosen) - target_ns) <= 100000000
    stable = stable and all((row[key] == chosen[key] for row in nearby for key in ('tx_counts', 'rx_counts')))
    return (chosen, stable)

def main():
    receipt_path = CONTROL / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['probe_exit_code'] == 0 and receipt['all_devices_released']
    assert not receipt['sampler_errors']
    for name, digest in receipt['input_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    grid_path = ROOT / 'diagnostic-collective-payload-grid-v1.json'
    grid = json.loads(grid_path.read_text())['calibration_grid']
    paths = [RUN / f'rank-{rank}.json' for rank in (0, 1)]
    records = [json.loads(path.read_text()) for path in paths]
    for record in records:
        assert record['grid_sha256'] == hashlib.sha256(grid_path.read_bytes()).hexdigest()
        assert len(record['phases']) == len(grid) * 3
    counter_path = CONTROL / 'counters.jsonl'
    raw = [json.loads(line) for line in counter_path.read_text().splitlines()]
    samples = {card: [row for row in raw if row['card'] == card] for card in (4, 5)}
    resets = {card: sum((any((b[key][i] < a[key][i] for key in ('tx_counts', 'rx_counts') for i in range(16))) for a, b in zip(rows, rows[1:]))) for card, rows in samples.items()}
    phases = []
    for index, pair in enumerate(zip(*(record['phases'] for record in records), strict=True)):
        shape_index, repetition = (index % len(grid), index // len(grid))
        for rank, phase in enumerate(pair):
            assert phase['rank'] == rank and phase['shape_index'] == shape_index and (phase['repetition'] == repetition)
            assert all((phase[key] == value for key, value in grid[shape_index].items()))
            assert phase['calls'] == 512 and phase['numerics_passed']
        start = min((item['start_wall'] for item in pair))
        end = max((item['end_wall'] for item in pair))
        duration = max((item['end_monotonic'] - item['start_monotonic'] for item in pair))
        assert duration > 0
        devices = []
        for card in (4, 5):
            before, left = boundary(samples[card], start - 0.25)
            assert midpoint(before) + 0.1 < start
            assert midpoint(before) - 0.1 > max((item['start_wall'] for item in pair)) - 1.0
            after, right = boundary(samples[card], end + 0.75)
            assert midpoint(after) - 0.1 > end
            deltas = {direction: [b - a for a, b in zip(before[direction + '_counts'], after[direction + '_counts'], strict=True)] for direction in ('tx', 'rx')}
            valid = left and right and all((value >= 0 for values in deltas.values() for value in values)) and (not resets[card])
            devices.append({'card': card, 'boundaries_stable': valid, 'start_counter_wall': midpoint(before), 'end_counter_wall': midpoint(after), 'tx_flits': deltas['tx'], 'rx_flits': deltas['rx']})
        a, b = devices
        peer = a['tx_flits'][4] == b['rx_flits'][1] and a['rx_flits'][4] == b['tx_flits'][1]
        qualified = peer and all((device['boundaries_stable'] for device in devices)) and all((sum(device['tx_flits']) > 0 for device in devices))
        phases.append({'shape_index': shape_index, 'repetition': repetition, 'duration_seconds': duration, 'counter_qualified': qualified, 'peer_exact': peer, 'devices': devices, 'aggregate_tx_flits_per_second': sum((sum(d['tx_flits']) for d in devices)) / duration if qualified else None})
    summaries = []
    for index, shape in enumerate(grid):
        values = [phase for phase in phases if phase['shape_index'] == index]
        rates = [phase['aggregate_tx_flits_per_second'] for phase in values]
        valid = all((rate is not None for rate in rates))
        summaries.append({**shape, 'counter_qualified_repetitions': sum((rate is not None for rate in rates)), 'median_aggregate_tx_flits_per_second': statistics.median(rates) if valid else None, 'min_aggregate_tx_flits_per_second': min(rates) if valid else None, 'max_aggregate_tx_flits_per_second': max(rates) if valid else None, 'seconds_per_512_calls': [phase['duration_seconds'] for phase in values]})
    paths += [Path(__file__), receipt_path, grid_path, counter_path, ROOT / 'audit_collective_grid_v1.py', CONTROL / 'summary.json', ROOT / 'collective_grid_probe_v1.py', ROOT / 'prepare_collective_grid_audit_v2.py']
    result = {'status': 'calibration_reaudited_with_corrected_start_anchor', 'boundary_rule': {'start_offset_seconds': -0.25, 'end_offset_seconds': 0.75, 'stable_half_width_seconds': 0.1, 'selection': 'Same fixed offsets for every phase; no per-point plateau search or speed selection'}, 'supersedes_analysis_only': str(CONTROL / 'summary.json'), 'shapes': summaries, 'phases': phases, 'counter_resets': resets, 'm01_attainment': None, 'source_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}, 'limitations': ['Reanalysis uses a later pre-measurement counter anchor after the fixed one-second post-warmup wait. The original -0.75 s anchor was too near delayed warmup/barrier counter updates. Original analysis and samples remain unchanged.', 'Synchronous diagnostic-shape reference includes host dispatch, fill and synchronization, not model overlap or r19 counts.', 'All three counter-qualified repetitions required for each physical-rate summary; no fastest-point selection.', 'Raw flit rate is not API payload byte throughput; bandwidth getter samples remain a separate raw cross-check.']}
    with (CONTROL / 'summary-v2.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'shapes': len(summaries), 'fully_counter_qualified': sum((item['counter_qualified_repetitions'] == 3 for item in summaries)), 'resets': resets}))
if __name__ == '__main__':
    main()
