"""Exclusive two-card qualification with fresh caches and owned-process cleanup."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from measure_microflow import descendant, stop

ROOT = Path(__file__).resolve().parent
OUT = Path("/workspace/m01-preprocess-publication-recovery-r2")


def main():
    OUT.mkdir(exist_ok=False)
    locks, child = [], None
    receipt = {"status": "admitting", "prior_cache_imported": False, "full_model": False}
    try:
        for name in ["/tmp/inference-project-container-model.lock"] + [f"/tmp/gennova-device-leases/device-{i}.lock" for i in range(4, 8)]:
            stream = open(name, "a+b")
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for index in range(3):
            smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
            (OUT / f"npu-before-{index}.txt").write_text(smi)
            assert all(f"No running processes found in NPU {i}" in smi for i in range(4, 8))
            time.sleep(2)
        cache = OUT / "cache"
        cache.mkdir()
        env = dict(os.environ, ASCEND_RT_VISIBLE_DEVICES="0,1", HUST_TOKEN_OBSERVER="0", TASK_QUEUE_ENABLE="0",
                   TRITON_CACHE_DIR=str(cache / "triton"), VLLM_CACHE_ROOT=str(cache / "vllm"),
                   TORCHINDUCTOR_CACHE_DIR=str(cache / "inductor"), XDG_CACHE_HOME=str(cache / "xdg"))
        with (OUT / "child.log").open("x") as log, (OUT / "samples.jsonl").open("x") as samples:
            child = subprocess.Popen([sys.executable, __file__, "--child"], env=env,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            receipt["child_pid"] = child.pid
            deadline = time.monotonic() + 1800
            while child.poll() is None:
                assert time.monotonic() < deadline, "Qualification timeout"
                smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
                samples.write(json.dumps({"wall": time.time(), "raw": smi}) + "\n")
                samples.flush()
                for match in re.finditer(r"\|\s*[4-7]\s+0\s*\|\s*(\d+)\s*\|", smi):
                    pid = int(match[1])
                    try:
                        owned = os.getpgid(pid) == child.pid or descendant(pid, {child.pid})
                    except ProcessLookupError:
                        continue
                    assert owned, "Foreign NPU process; qualification invalid"
                time.sleep(2)
        receipt["exit_code"] = child.returncode
        assert child.returncode == 0
        receipt["status"] = "completed_pending_independent_audit"
    except BaseException as error:
        receipt.update(status="failed", error=f"{type(error).__name__}: {error}")
    finally:
        receipt["cleanup_exit_code"] = stop(child)
        smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
        (OUT / "npu-after.txt").write_text(smi)
        receipt["all_four_idle_after"] = all(f"No running processes found in NPU {i}" in smi for i in range(4, 8))
        names = [Path(__file__), ROOT / "preprocess_publication_recovery_r1.py", ROOT / "preprocess_numeric_probe_v1.py",
                 ROOT / "runtime-gdn-recovery-r2.sh", ROOT / "measure_microflow.py"]
        receipt["source_sha256"] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in names}
        (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        for stream in locks:
            stream.close()
    print(json.dumps(receipt), flush=True)
    return 0 if receipt["status"] == "completed_pending_independent_audit" and receipt["all_four_idle_after"] else 1


if __name__ == "__main__":
    if sys.argv[1:] == ["--child"]:
        from preprocess_publication_recovery_r1 import run
        run(OUT)
    else:
        raise SystemExit(main())
