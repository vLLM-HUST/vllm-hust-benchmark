"""Compare the pinned preprocessing kernel with independent CPU arithmetic."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def reference(torch, x, a, b, log, bias, mapping):
    indices = torch.arange(x.shape[0]) if mapping is None else mapping
    values = x[indices].float()
    q, k = (values[:, start:start + 1024].reshape(-1, 8, 128)
            for start in (0, 1024))
    q = (q / torch.sqrt((q * q).sum(-1, keepdim=True) + 1e-6)).bfloat16()
    k = (k / torch.sqrt((k * k).sum(-1, keepdim=True) + 1e-6)).bfloat16()
    gate = a[indices].float() + bias
    softplus = torch.where(gate <= 20, torch.log1p(torch.exp(gate)), gate)
    g = -torch.exp(log) * softplus
    beta = torch.sigmoid(b[indices].float()).bfloat16()
    v = x[indices, 2048:].reshape(-1, 16, 128)
    return tuple(item.unsqueeze(0) for item in (q, k, v, g, beta))


def run(out):
    import torch
    import torch_npu  # noqa: F401

    source = ROOT / 'payload/betterscale/models/qwen35/preprocess.py'
    payload_path = ROOT / 'payload-receipt.json'
    receipt_path = Path('/workspace/gennova-measurements/microflow-token-accounting-r19/receipt.json')
    receipt = json.loads(receipt_path.read_text())
    assert hashlib.sha256(payload_path.read_bytes()).hexdigest() == receipt['input_hashes']['payload-receipt.json']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == json.loads(payload_path.read_text())['payload_hashes']['models/qwen35/preprocess.py']
    spec = importlib.util.spec_from_file_location('qualified_preprocess', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    torch.npu.set_device(0)
    generator = torch.Generator().manual_seed(20261020)
    cases, tensors = [], {}
    # Include both launch row sizes, non-multiple tails and repeated mapped rows.
    for count, mapped in ((1, False), (16, False), (17, False), (72, True), (257, True)):
        source_rows = 33 if mapped else count
        x = torch.randn((source_rows, 4096), generator=generator).bfloat16()
        x[0, :2048] = 0
        a = torch.linspace(-30, 30, source_rows * 16).reshape(source_rows, 16).bfloat16()
        b = torch.linspace(-10, 10, source_rows * 16).reshape(source_rows, 16).bfloat16()
        log = torch.linspace(-4, 1, 16)
        bias = torch.linspace(-0.5, 0.5, 16)
        mapping = (torch.arange(count) * 7 % source_rows).long() if mapped else None
        expected = reference(torch, x, a, b, log, bias, mapping)
        for head_major in (False, True):
            key = f'rows{count}-mapped{int(mapped)}-headmajor{int(head_major)}'
            device_inputs = [value.npu() for value in (x, a, b, log, bias)]
            outputs = module.preprocess(*device_inputs,
                token_map=None if mapping is None else mapping.npu(), q_head_major=head_major)
            torch.npu.synchronize()
            actual = tuple(value.cpu() for value in outputs)
            checks = []
            for name, observed, wanted in zip(('q', 'k', 'v', 'g', 'beta'), actual, expected, strict=True):
                assert observed.shape == wanted.shape and observed.dtype == wanted.dtype
                assert torch.isfinite(observed).all()
                rtol, atol = ((0, 0) if name == 'v' else
                              (2e-5, 2e-5) if name == 'g' else (0.016, 0.001))
                torch.testing.assert_close(observed, wanted, rtol=rtol, atol=atol)
                checks.append({'output': name, 'shape': list(observed.shape),
                               'dtype': str(observed.dtype), 'rtol': rtol, 'atol': atol,
                               'max_absolute_error': (observed.float() - wanted.float()).abs().max().item()})
            cases.append({'id': key, 'source_rows': source_rows, 'output_rows': count,
                          'mapped': mapped, 'head_major': head_major, 'checks': checks})
            tensors[key] = {'inputs': (x, a, b, log, bias, mapping), 'actual': actual, 'reference': expected}
    archive = out / 'numeric-tensors.pt'
    assert not archive.exists()
    torch.save(tensors, archive)
    paths = [Path(__file__), ROOT / 'qualify_preprocess_numeric_v1.py', source, payload_path, receipt_path]
    result = {'status': 'passed', 'model_run': False, 'performance_publication': False,
              'seed': 20261020, 'cases': cases,
              'tensor_archive': {'name': archive.name, 'bytes': archive.stat().st_size,
                                 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              'limitations': ['Synthetic bounded numerical coverage, not full model accuracy or historical device map capture.',
                             'No graph replay or full-model stream dependency closure.',
                             'BF16 comparisons use predeclared tolerances; V copy is exact.',
                             'Fresh compilation cache and new process; no prior inference tensors imported.']}
    with (out / 'device-result.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')

