"""Audit saved performance texts without promoting them to quality evidence."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def align_cases(materialized, selected, labels):
    if not len(materialized) == len(selected) == len(labels) == 200:
        raise ValueError("Expected exactly 200 cases")
    if len({case["case_id"] for case in selected}) != 200:
        raise ValueError("Duplicate case identity")
    aligned = []
    for index, (raw, case, label) in enumerate(zip(materialized, selected, labels, strict=True)):
        digest = hashlib.sha256(raw["prompt"].encode()).hexdigest()
        if raw["prompt"] != case["prompt"] or digest != label["prompt_sha256"]:
            raise ValueError(f"Prompt mismatch at {index}")
        if case["case_id"] != label["case_id"]:
            raise ValueError(f"Identity mismatch at {index}")
        aligned.append({"index": index, "case_id": case["case_id"], "prompt_sha256": digest})
    return aligned


def main():
    paths = [ROOT / name for name in (
        "materialized.200.jsonl", "recovered-mmlu-cases.json",
        "verified-mmlu-quality-inputs.json", "bench-model-recovery-r1.sh")]
    materialized = [json.loads(line) for line in paths[0].read_text().splitlines()]
    labels = json.loads(paths[2].read_text())
    aligned = align_cases(materialized, json.loads(paths[1].read_text()), labels["cases"])
    scorer_path = Path("/root/vllm-hust-benchmark/src/vllm_hust_benchmark/mmlu_pro_pyramidkv.py")
    if sha(scorer_path) != labels["scorer_source_sha256"]:
        raise ValueError("Scorer changed")
    spec = importlib.util.spec_from_file_location("quality_scorer", scorer_path)
    scorer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scorer)
    runs = []
    for run in ("r5", "r7"):
        directory = ROOT / f"m01-recovery-model-{run}"
        receipt_path, result_path = directory / "receipt.json", directory / "mmlu-pro.json"
        receipt, result = [json.loads(p.read_text()) for p in (receipt_path, result_path)]
        if receipt["input_hashes"][paths[0].name] != sha(paths[0]):
            raise ValueError("Run input differs from audited input")
        if result["completed"] != 200 or result["failed"] != 0:
            raise ValueError("Incomplete run")
        texts = result["generated_texts"]
        if len(texts) != 200 or result["output_lens"] != [256] * 200:
            raise ValueError("Unexpected output shape")
        extracted = [scorer.extract_answer(text) for text in texts]
        runs.append({
            "run": run, "result_sha256": sha(result_path),
            "receipt_sha256": sha(receipt_path),
            "outputs_at_configured_cap": 200,
            "finish_reason_retained": "finish_reasons" in result,
            "token_ids_retained": "output_token_ids" in result,
            "logits_retained": "logits" in result,
            "scorer_nonnull_extractions_diagnostic_only": sum(x is not None for x in extracted),
            "task_accuracy": None,
            "aggregate_mtp_accepted": result["spec_decode_accepted_tokens"],
            "aggregate_mtp_drafted": result["spec_decode_draft_tokens"],
        })
        for record, text, answer in zip(aligned, texts, extracted, strict=True):
            record[run] = {"text_sha256": hashlib.sha256(text.encode()).hexdigest(),
                           "diagnostic_extraction": answer}
        paths.extend((receipt_path, result_path))
    output = {
        "schema": "recovery-request-identity/v1", "runs": runs, "records": aligned,
        "input_order_alignment": "200 prompt hashes and case IDs verified against pinned label receipt",
        "response_identity_scope": "Index-based; saved output lacks per-request server IDs",
        "quality_admission": False, "first_divergent_generated_token": None,
        "limitations": [
            "256-token performance outputs do not establish completed answers.",
            "Scorer fallback may extract a choice mentioned during reasoning; counts are not accuracy.",
            "Re-tokenizing saved text cannot recover original generation token IDs or logits.",
            "Aggregate MTP counts cannot locate per-request divergence.",
        ],
        "source_sha256": {str(p): sha(p) for p in [*paths, scorer_path, Path(__file__)]},
    }
    with (ROOT / "recovery-request-identity-r1.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"runs": runs, "quality_admission": False}))


if __name__ == "__main__":
    main()
