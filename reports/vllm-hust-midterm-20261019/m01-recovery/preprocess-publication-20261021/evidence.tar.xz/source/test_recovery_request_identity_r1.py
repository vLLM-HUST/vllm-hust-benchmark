import copy

import pytest

from audit_recovery_request_identity_r1 import align_cases
import hashlib


def fixture():
    raw = [{"prompt": str(i)} for i in range(200)]
    selected = [dict(row, case_id=str(i)) for i, row in enumerate(raw)]
    labels = [{"case_id": str(i), "prompt_sha256": hashlib.sha256(str(i).encode()).hexdigest()}
              for i in range(200)]
    return raw, selected, labels


def test_identity():
    assert len(align_cases(*fixture())) == 200


@pytest.mark.parametrize("mutation", ["reorder", "duplicate", "label", "missing"])
def test_reject(mutation):
    raw, selected, labels = copy.deepcopy(fixture())
    if mutation == "reorder":
        raw[0], raw[1] = raw[1], raw[0]
    elif mutation == "duplicate":
        selected[1]["case_id"] = selected[0]["case_id"]
    elif mutation == "label":
        labels[0]["case_id"] = "other"
    else:
        raw.pop()
    with pytest.raises(ValueError):
        align_cases(raw, selected, labels)
