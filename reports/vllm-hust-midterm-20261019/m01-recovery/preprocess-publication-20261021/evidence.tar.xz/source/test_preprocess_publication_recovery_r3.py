import pytest

from preprocess_publication_recovery_r3 import expected_maps, scenario


@pytest.mark.parametrize("capacity", [80, 1024, 2048, 4096])
@pytest.mark.parametrize("variant", [0, 1])
def test_scenario_bounds(capacity, variant):
    lengths, roles, accepted = scenario(capacity, variant)
    assert 0 < len(lengths) <= 24
    assert sum(lengths) <= capacity
    assert all(1 <= a <= min(n, 3) for a, n in zip(accepted, lengths))
    assert all(n <= 3 for n, role in zip(lengths, roles) if role)
    assert all(roles) if capacity == 80 else not all(roles)


def test_independent_map_oracle():
    result = expected_maps(8, [3, 2, 1], [True, False, True])
    assert result["prefill_map"] == [3, 4, 0, 0, 0, 0, 0, 0]
    assert result["verify_map"] == [0, 1, 2, 5] + [0] * 68
    assert result["restore"] == [8, 9, 10, 0, 1, 11, 0, 0]


def test_reuse_shorter_wave_zeroes_suffix():
    first = expected_maps(1024, *scenario(1024, 0)[:2])
    second = expected_maps(1024, *scenario(1024, 1)[:2])
    assert first["prefill_map"] != second["prefill_map"]
    assert second["prefill_map"] == [0, 1] + [0] * 1022
    assert second["verify_map"] == [2] + [0] * 71
    assert second["restore"] == [0, 1, 1024] + [0] * 1021
