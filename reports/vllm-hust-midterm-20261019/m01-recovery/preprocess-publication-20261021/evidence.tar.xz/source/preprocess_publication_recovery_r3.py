"""Exercise actual MTPFrame publication and preprocess graph consumption."""
import hashlib
import itertools
import json
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent


def scenario(capacity, variant):
    decode = capacity == 80
    if decode:
        lengths = [3, 2, 1] * 8 if variant == 0 else [1, 3]
        roles = [True] * len(lengths)
    else:
        lengths = [3, capacity - 69] + [3] * 22 if variant == 0 else [2, 1]
        roles = [True, False] + [True] * 22 if variant == 0 else [False, True]
    accepted = [1 + (i + variant) % min(n, 3) for i, n in enumerate(lengths)]
    return lengths, roles, accepted


def expected_maps(capacity, lengths, roles):
    ends = [0, *itertools.accumulate(lengths)]
    pre, verify = [], []
    for index, role in enumerate(roles):
        (verify if role else pre).extend(range(ends[index], ends[index + 1]))
    restore = [0] * capacity
    for base, rows in ((0, pre), (capacity, verify)):
        for packed, source in enumerate(rows):
            restore[source] = base + packed
    return {"prefill_map": pre + [0] * (capacity - len(pre)),
            "verify_map": verify + [0] * (72 - len(verify)), "restore": restore}


def run(out):
    import torch
    import torch_npu  # noqa: F401
    import numpy as np
    from betterscale.models.qwen35.service_metadata import MTPFrame
    from betterscale.models.qwen35.preprocess import preprocess
    from preprocess_numeric_probe_v1 import reference

    payload = json.loads((ROOT / "payload-receipt.json").read_text())
    names = ["models/qwen35/count_policy.py", "models/qwen35/host_metadata.py", "models/qwen35/service_metadata.py",
             "models/qwen35/mixed_core.py", "models/qwen35/preprocess.py",
             "patches/qwen_gdn/publication.py"]
    source_hashes = {}
    for name in names:
        source = ROOT / "recovery-model-payload-r1/betterscale" / name
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        assert digest == payload["payload_hashes"][name], name
        source_hashes[str(source)] = digest
    records = []
    for device in (0, 1):
        torch.npu.set_device(device)
        for capacity in (80, 1024, 2048, 4096):
            for bank in (0, 1):
                transfer = torch.npu.Stream(device=device)
                consumer = torch.npu.Stream(device=device)
                capture = torch.npu.Stream(device=device)
                frame = MTPFrame(capacity, ["gdn"], f"npu:{device}", transfer, requests=24)
                meta = frame.metas["gdn"]
                assert meta.decode == (capacity == 80) and meta.width == 3
                generator = torch.Generator().manual_seed(20261021 + capacity + bank)
                x = torch.randn(capacity, 4096, generator=generator).bfloat16()
                x[0, :2048] = 0
                a = torch.linspace(-30, 30, capacity * 16).reshape(capacity, 16).bfloat16()
                b = torch.linspace(-10, 10, capacity * 16).reshape(capacity, 16).bfloat16()
                log, bias = torch.linspace(-4, 1, 16), torch.linspace(-0.5, 0.5, 16)
                cpu = (x, a, b, log, bias)
                inputs = tuple(t.to(f"npu:{device}") for t in cpu)
                accepted_device = torch.ones(24, dtype=torch.int32, device=f"npu:{device}")
                consumer.wait_stream(torch.npu.current_stream())
                builder = SimpleNamespace(vllm_config=SimpleNamespace(
                    cache_config=SimpleNamespace(mamba_cache_mode="align")),
                    kv_cache_spec=SimpleNamespace(block_size=128))
                table = np.arange(24 * 64).reshape(24, 64)

                def publish(variant):
                    lengths, roles, accepted = scenario(capacity, variant)
                    seq = torch.tensor([n + 128 * (1 + (i + variant) % 3)
                                        for i, n in enumerate(lengths)], dtype=torch.int64)
                    frame.acquire()
                    with torch.npu.stream(consumer):
                        accepted_device.fill_(1)
                        accepted_device[:len(accepted)].copy_(torch.tensor(accepted, dtype=torch.int32))
                        frame.fill_mtp("gdn", SimpleNamespace(seq_lens_cpu=seq), lengths, table,
                                       builder, accepted_device,
                                       torch.tensor([0 if role else -1 for role in roles]))
                        frame.publish()
                    return lengths, roles, accepted, seq

                def consume():
                    fields = {name: getattr(meta, name).clone() for name in
                              ("prefill_map", "verify_map", "restore", "accepted", "cu", "verify_ids")}
                    fields["verify_accepted"] = meta.verify.accepted.clone()
                    fields["verify_slots"] = meta.verify.slots.clone()
                    mappings = (None,) if meta.decode else (meta.prefill_map, meta.verify_map)
                    outputs = [preprocess(*inputs, token_map=mapping,
                                          q_head_major=(bank == 1 and index == 0))
                               for index, mapping in enumerate(mappings)]
                    return fields, outputs

                publish(0)
                with torch.npu.stream(consumer):
                    consume()
                    frame.release()
                torch.npu.synchronize()
                graph = torch.npu.NPUGraph()
                with torch.npu.graph(graph, stream=capture):
                    captured = consume()
                for replay, variant in enumerate((0, 1, 0, 1)):
                    lengths, roles, accepted, seq = publish(variant)
                    with torch.npu.stream(consumer):
                        graph.replay()
                        frame.release()
                    consumer.synchronize()
                    fields = {key: value.cpu() for key, value in captured[0].items()}
                    maps = expected_maps(capacity, lengths, roles)
                    if not meta.decode:
                        for name, expected in maps.items():
                            assert fields[name].tolist() == expected, name
                    expected_cu = [0, *itertools.accumulate(lengths)]
                    expected_cu += [sum(lengths)] * (26 - len(expected_cu))
                    assert fields["cu"].tolist() == expected_cu
                    assert fields["accepted"].tolist() == accepted + [1] * (25 - len(accepted))
                    ids = [i for i, role in enumerate(roles) if role]
                    assert fields["verify_ids"].tolist() == ids + [0] * (25 - len(ids))
                    assert fields["verify_accepted"].tolist() == [accepted[i] for i in ids] + [1] * (25 - len(ids))
                    slots = [[-1] * 3 for _ in range(25)]
                    for packed, i in enumerate(ids):
                        column = (int(seq[i]) - 1) // 128
                        slots[packed] = table[i, column:column + 3].tolist()
                    assert fields["verify_slots"].tolist() == slots
                    mappings = (None,) if meta.decode else tuple(torch.tensor(maps[name]) for name in ("prefill_map", "verify_map"))
                    tensors, checks = [], []
                    for branch, (observed, mapping) in enumerate(zip(captured[1], mappings, strict=True)):
                        expected = reference(torch, *cpu, mapping)
                        actual = tuple(value.cpu() for value in observed)
                        for name, value, target in zip(("q", "k", "v", "g", "beta"), actual, expected, strict=True):
                            rtol, atol = ((0, 0) if name == "v" else (2e-5, 2e-5) if name == "g" else (0.016, 0.001))
                            torch.testing.assert_close(value, target, rtol=rtol, atol=atol)
                            checks.append({"branch": branch, "output": name, "rtol": rtol, "atol": atol,
                                           "max_abs": (value.float() - target.float()).abs().max().item()})
                        tensors.append({"actual": actual, "expected": expected})
                    label = f"device{device}-cap{capacity}-bank{bank}-replay{replay}"
                    archive = out / f"{label}.pt"
                    torch.save({"fields": fields, "maps": maps, "outputs": tensors,
                                "lengths": lengths, "roles": roles, "accepted": accepted}, archive)
                    record = {"id": label, "device": device, "capacity": capacity, "bank": bank,
                              "replay": replay, "variant": variant, "requests": len(lengths),
                              "checks": checks, "tensor_sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
                    records.append(record)
                    print(json.dumps({"passed": label}), flush=True)
                del graph, captured, frame, meta
    result = {"status": "passed", "cases": records, "source_sha256": source_hashes,
              "model_effective_flops": None, "m01_attainment": None,
              "limitations": ["Synthetic publications, not recovered historical device maps.",
                              "Actual MTPFrame publication and preprocess only, not whole-model stream closure.",
                              "Each replay is synchronized for oracle inspection; overlapping model batches are not covered.",
                              "Two banks and both Q layouts tested; no throughput or quality admission."]}
    with (out / "result.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
