"""Seal completed attempts and qualification sources; exclude disposable caches."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
DEST = Path("/workspace/m01-preprocess-publication-20261021-r3.tar.gz")


def main():
    files = {}
    for attempt in ("r1", "r2", "r3"):
        directory = Path(f"/workspace/m01-preprocess-publication-recovery-{attempt}")
        receipt = json.loads((directory / "receipt.json").read_text())
        assert receipt["all_four_idle_after"]
        for path in directory.iterdir():
            if path.is_file() and not path.is_symlink():
                files[f"{directory.name}/{path.name}"] = path
    passed = Path("/workspace/m01-preprocess-publication-recovery-r3")
    assert json.loads((passed / "independent-audit.json").read_text())["status"] == "cpu_reaudit_passed"
    sources = set()
    for directory in (Path("/workspace/m01-preprocess-publication-recovery-r1"), Path("/workspace/m01-preprocess-publication-recovery-r2"), passed):
        sources.update(json.loads((directory / "receipt.json").read_text())["source_sha256"])
    sources.update(json.loads((passed / "result.json").read_text())["source_sha256"])
    sources.update(str(ROOT / name) for name in (
        "audit_preprocess_publication_recovery_r3.py", "test_preprocess_publication_recovery_r3.py",
        "audit_recovery_request_identity_r1.py", "test_recovery_request_identity_r1.py",
        "recovery-request-identity-r1.json", "preprocess-publication-r3-unit-tests.xml"))
    sources.add(str(Path(__file__)))
    for source in sources:
        path = Path(source)
        files["source/" + str(path.relative_to(ROOT))] = path
    members = {}
    assert not DEST.exists()
    with tarfile.open(DEST, "w:gz") as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            item = tarfile.TarInfo(name)
            item.size, item.mode = len(data), 0o644
            archive.addfile(item, io.BytesIO(data))
            members[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    with tarfile.open(DEST) as archive:
        assert {item.name for item in archive} == set(members)
        for item in archive.getmembers():
            data = archive.extractfile(item).read()
            assert hashlib.sha256(data).hexdigest() == members[item.name]["sha256"]
    digest = hashlib.file_digest(DEST.open("rb"), "sha256").hexdigest()
    result = {"archive": DEST.name, "bytes": DEST.stat().st_size, "sha256": digest,
              "members": members, "member_verification": "all_members_passed",
              "model_effective_flops": None, "m01_attainment": None}
    with (ROOT / "preprocess-publication-archive-r3.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("archive", "bytes", "sha256")}))


if __name__ == "__main__":
    main()
