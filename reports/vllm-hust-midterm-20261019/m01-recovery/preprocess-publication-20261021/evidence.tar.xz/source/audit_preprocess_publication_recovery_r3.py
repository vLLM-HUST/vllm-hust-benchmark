"""Recompute saved numerical checks on CPU; no NPU work or evidence rewriting."""
import hashlib
import json
from pathlib import Path
import sys


def main(out):
    import torch
    from preprocess_numeric_probe_v1 import reference
    from preprocess_publication_recovery_r3 import expected_maps, scenario

    receipt = json.loads((out / "receipt.json").read_text())
    result = json.loads((out / "result.json").read_text())
    assert receipt["exit_code"] == 0 and receipt["all_four_idle_after"]
    assert result["status"] == "passed"
    expected_ids = {(device, cap, bank, replay) for device in (0, 1)
                    for cap in (80, 1024, 2048, 4096) for bank in (0, 1) for replay in range(4)}
    assert len(result["cases"]) == len(expected_ids) == 64
    actual_ids = {(row["device"], row["capacity"], row["bank"], row["replay"]) for row in result["cases"]}
    assert actual_ids == expected_ids
    for source, digest in {**receipt["source_sha256"], **result["source_sha256"]}.items():
        assert hashlib.sha256(Path(source).read_bytes()).hexdigest() == digest
    inputs = {}
    checks = 0
    maxima = {}
    for row in result["cases"]:
        cap, bank, variant = row["capacity"], row["bank"], row["variant"]
        assert variant == row["replay"] % 2
        path = out / (row["id"] + ".pt")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row["tensor_sha256"]
        tensors = torch.load(path, map_location="cpu", weights_only=True)
        lengths, roles, accepted = scenario(cap, variant)
        assert tensors["lengths"] == lengths and tensors["roles"] == roles and tensors["accepted"] == accepted
        mapping = expected_maps(cap, lengths, roles)
        assert tensors["maps"] == mapping
        if cap != 80:
            for name in mapping:
                assert tensors["fields"][name].tolist() == mapping[name]
        key = cap, bank
        if key not in inputs:
            generator = torch.Generator().manual_seed(20261021 + cap + bank)
            x = torch.randn(cap, 4096, generator=generator).bfloat16()
            x[0, :2048] = 0
            inputs[key] = (x, torch.linspace(-30, 30, cap * 16).reshape(cap, 16).bfloat16(),
                           torch.linspace(-10, 10, cap * 16).reshape(cap, 16).bfloat16(),
                           torch.linspace(-4, 1, 16), torch.linspace(-0.5, 0.5, 16))
        maps = (None,) if cap == 80 else (torch.tensor(mapping["prefill_map"]), torch.tensor(mapping["verify_map"]))
        for branch, token_map in enumerate(maps):
            expected = reference(torch, *inputs[key], token_map)
            saved = tensors["outputs"][branch]
            for name, target, saved_reference, actual in zip(("q", "k", "v", "g", "beta"),
                    expected, saved["expected"], saved["actual"], strict=True):
                torch.testing.assert_close(saved_reference, target, rtol=0, atol=0)
                rtol, atol = ((0, 0) if name == "v" else (2e-5, 2e-5) if name == "g" else (0.016, 0.001))
                torch.testing.assert_close(actual, target, rtol=rtol, atol=atol)
                error = (actual.float() - target.float()).abs().max().item()
                reported = [c for c in row["checks"] if c["branch"] == branch and c["output"] == name]
                assert len(reported) == 1 and reported[0]["max_abs"] == error
                maxima[name] = max(maxima.get(name, 0), error)
                checks += 1
    audit = {"status": "cpu_reaudit_passed", "cases": 64, "numerical_tensor_checks": checks,
             "max_abs_by_output": maxima, "model_effective_flops": None, "m01_attainment": None,
             "result_sha256": hashlib.sha256((out / "result.json").read_bytes()).hexdigest(),
             "auditor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with (out / "independent-audit.json").open("x") as stream:
        json.dump(audit, stream, indent=2)
        stream.write("\n")
    print(json.dumps(audit))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
