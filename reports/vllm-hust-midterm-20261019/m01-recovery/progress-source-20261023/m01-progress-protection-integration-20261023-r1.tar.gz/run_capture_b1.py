"""Own one diagnostic capture, including both exports and process release."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import time

from audit_wave_capture import audit
from capture_boundary import verify_exports
from run_boundary_b1 import validate_plan as validate_original_plan
from run_collective_graph import DEVICES, LIFECYCLE
from synchronized_boundary import validate_fences
from wave_capture_bridge import check_run_label

HERE = Path(__file__).resolve().parent


def validate_plan(plan):
    if type(plan.get('protect_progress_source', False)) is not bool:
        raise ValueError('Progress protection requires a boolean plan flag')
    if plan.get('protect_progress_source', False) and (
        not plan.get('capture_draft_inputs', False)
        or plan.get('implementation_variant') != 'diagnostic-progress-source-protected/v1'
    ):
        raise ValueError('Protected qualification requires draft inputs and explicit variant')
    if type(plan.get('capture_draft_inputs', False)) is not bool:
        raise ValueError('Draft input capture requires a boolean plan flag')
    if plan.get('capture_draft_inputs', False) and not plan.get('capture_draft_lengths', False):
        raise ValueError('Draft inputs require paired device lengths')
    if type(plan.get('capture_draft_lengths', False)) is not bool:
        raise ValueError('Draft length capture requires a boolean plan flag')
    if plan.get('protocol') != 'm01-diagnostic-capture/v1':
        raise ValueError('Unexpected capture protocol')
    check_run_label(plan['run_id'])
    validate_original_plan(dict(plan, protocol='m01-boundary-supplement/v1'))
    if plan.get('measurement_role') != 'diagnostic_qualification':
        raise ValueError('Capture cannot be a performance arm')
    return plan


def check_client(output, run_id):
    data = json.loads((output / 'mmlu-pro.json').read_text())
    expected = dict(completed=200, failed=0, total_input_tokens=282265, total_output_tokens=51200)
    if any(data.get(key) != value for key, value in expected.items()):
        raise ValueError('Incomplete or changed workload')
    rows = [json.loads(line) for line in (output / 'boundary.jsonl').read_text().splitlines()]
    if len(rows) != 1 or rows[0].get('protocol') != 'm01-diagnostic-capture-boundary/v1':
        raise ValueError('Expected unique successful diagnostic boundary')
    boundary = rows[0]
    if boundary.get('run_id') != run_id or boundary.get('performance_acceptance') is not False:
        raise ValueError('Wrong diagnostic boundary identity')
    calls = boundary['calls']
    paths = ['/pause?mode=wait&clear_cache=false', '/collective_rpc', '/resume',
             '/pause?mode=wait&clear_cache=false', '/collective_rpc', '/collective_rpc']
    if [call['path'] for call in calls] != paths:
        raise ValueError('Incomplete diagnostic boundary sequence')
    if calls[-1]['request']['method'] != 'hust_m01_export_wave_capture':
        raise ValueError('Missing export operation')
    identity = validate_fences(calls[1]['response'], 'begin')
    validate_fences(calls[4]['response'], 'end', identity)
    verify_exports(calls[-1]['response'], output, identity, run_id)
    return dict(**expected, scope='diagnostic workload; timing includes instrumentation',
                effective_flops=None, m01_attainment=None)


def check_final(output, *, require_draft_lengths=False, require_draft_inputs=False,
                require_progress_protection=False):
    schedulers = list(output.glob('scheduler-*.json'))
    workers = list(output.glob('worker-*.json'))
    if len(schedulers) != 1 or len(workers) != 2:
        raise ValueError('Missing unique scheduler and TP2 worker exports after exit')
    sources = schedulers + workers
    raw = [path.read_bytes() for path in sources]
    worker_records = [json.loads(value) for value in raw[1:]]
    if require_progress_protection:
        for worker in worker_records:
            protection = worker.get('progress_source_protection', {})
            if (protection.get('enabled') is not True
                or protection.get('failed') is not False
                or type(protection.get('prepare_calls')) is not int
                or protection['prepare_calls'] <= 0):
                raise ValueError('Requested progress source protection not exercised')
    if require_draft_lengths and any('draft_device_lengths' not in worker for worker in worker_records):
        raise ValueError('Requested draft device lengths missing')
    if require_draft_inputs:
        from audit_draft_inputs import validate
        for worker in worker_records:
            validate(worker)
    result = audit(json.loads(raw[0]), worker_records)
    result['sources'] = [dict(file=p.name, sha256=hashlib.sha256(b).hexdigest()) for p, b in zip(sources, raw)]
    with (output / 'capture-join.json').open('x') as stream:
        json.dump(result, stream, indent=2)
    if result['status'] != 'joined':
        raise ValueError('Cross-process capture audit failed: ' + '; '.join(result['errors']))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    plan = validate_plan(json.loads(args.plan.read_text()))
    if args.check:
        print('PASS: capture source plan validated; no device admission')
        return 0
    if plan.get('status') != 'frozen_for_execution' or not plan.get('model_weight_identity'):
        raise ValueError('Plan not frozen with checkpoint identity')
    sys.path.insert(0, str(LIFECYCLE))
    import run_fs018_solver as lifecycle
    from process_group_drain import wait_session_drained
    output, cache = Path(plan['output']), Path(plan['cache'])
    if any(p.exists() or p.is_symlink() for p in (output, cache)):
        raise FileExistsError('Output and cache must both be new')
    children, locks, created = [], [], False
    record = dict(status='admitting', started=time.time(), participating=[0, 1],
                  reserved=list(DEVICES), run_id=plan['run_id'],
                  measurement_role='diagnostic_qualification', effective_flops=None, m01_attainment=None)

    def observe(event):
        with (output / 'monitor.jsonl').open('a') as stream:
            stream.write(json.dumps(event) + '\n')

    def save():
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in DEVICES]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        output.mkdir()
        created = True
        for _ in range(3):
            raw = lifecycle.runtime.npu_info(observe)
            if not all(f'No running processes found in NPU {i}' in raw for i in DEVICES):
                raise RuntimeError('Devices not idle')
            time.sleep(2)
        (output / 'npu-before.txt').write_text(raw)
        if shutil.disk_usage(output).free < 20 * 1024**3:
            raise RuntimeError('Insufficient capture/cache space')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 18390))
        shutil.copyfile(args.plan, output / 'execution-plan.json')
        environment = dict(HOME='/root', PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                           LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', KVMAT_RUN_DIR=str(output))
        if plan.get('capture_draft_lengths', False):
            environment['HUST_M01_DRAFT_LENGTHS'] = '1'
        if plan.get('capture_draft_inputs', False):
            environment['HUST_M01_DRAFT_INPUTS'] = '1'
        if plan.get('protect_progress_source', False):
            environment['HUST_M01_PROGRESS_SNAPSHOT'] = '1'
        runtime = ['bash', str(HERE / 'runtime_boundary_b1.sh')]
        with (output / 'service.log').open('x') as service_log, (output / 'bench.log').open('x') as bench_log:
            server = subprocess.Popen([*runtime, str(HERE / 'launch_capture_b1.py'),
                '--output', str(output), '--cache', str(cache), '--run-id', plan['run_id']],
                env=environment, stdout=service_log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append(server)
            record.update(status='starting', service_pid=server.pid)
            save()
            client, deadline = None, time.monotonic() + 3600
            while True:
                if server.poll() is not None:
                    raise RuntimeError(f'Service exited {server.returncode}')
                if time.monotonic() >= deadline:
                    raise TimeoutError('Capture stage timed out')
                raw = lifecycle.runtime.npu_info(observe)
                observe(dict(time=time.time(), status=record['status'], npu=raw))
                for line in raw.splitlines():
                    match = re.match(r'\|\s*(?:0|1|6|7)\s+0\s*\|\s*(\d+)\s*\|', line)
                    if match and Path(f'/proc/{match[1]}').exists():
                        if not lifecycle.runtime.owned(int(match[1]), {p.pid for p in children}):
                            raise RuntimeError('Foreign NPU load')
                if client is None:
                    try:
                        with lifecycle.OPENER.open('http://127.0.0.1:18390/health', timeout=2) as response:
                            ready = response.status == 200
                    except OSError:
                        ready = False
                    if ready:
                        command = [*runtime, str(HERE / 'run_capture_benchmark.py'), '--port', '18390',
                            '--source-sha256', plan['benchmark_sha256'], '--receipt', str(output / 'boundary.jsonl'),
                            '--capture-dir', str(output), '--run-id', plan['run_id'], '--', *plan['benchmark_args'],
                            '--result-dir', str(output), '--result-filename', 'mmlu-pro.json']
                        client = subprocess.Popen(command, env=environment, stdout=bench_log,
                            stderr=subprocess.STDOUT, start_new_session=True)
                        children.append(client)
                        record.update(status='capturing', client_pid=client.pid)
                        save()
                        deadline = time.monotonic() + 1800
                elif client.poll() is not None:
                    record['client_exit_code'] = client.returncode
                    if client.returncode != 0:
                        raise RuntimeError('Diagnostic client failed')
                    record.update(status='awaiting_scheduler_export', workload=check_client(output, plan['run_id']))
                    break
                time.sleep(5)
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['sessions_drained'] = True
        for child in reversed(children):
            try:
                code = lifecycle.runtime.stop(child)
                record.setdefault('exit_codes', []).append(dict(pid=child.pid, code=code))
                wait_session_drained(child.pid, timeout=180, observe=observe)
            except BaseException as error:
                record['sessions_drained'] = False
                record.setdefault('cleanup_errors', []).append(str(error))
        if created:
            try:
                deadline = time.monotonic() + 120
                while True:
                    raw = lifecycle.runtime.npu_info(observe)
                    record['all_devices_released'] = all(f'No running processes found in NPU {i}' in raw for i in DEVICES)
                    if record['all_devices_released'] or time.monotonic() >= deadline:
                        break
                    time.sleep(2)
                (output / 'npu-after.txt').write_text(raw)
                if record['status'] == 'awaiting_scheduler_export':
                    if not record['sessions_drained'] or not record['all_devices_released']:
                        raise RuntimeError('Release incomplete; exports not final')
                    if plan.get('capture_draft_inputs', False):
                        record['capture_audit'] = check_final(output, require_draft_lengths=True,
                                                            require_draft_inputs=True,
                                                            require_progress_protection=plan.get('protect_progress_source', False))
                    elif plan.get('capture_draft_lengths', False):
                        record['capture_audit'] = check_final(output, require_draft_lengths=True)
                    else:
                        record['capture_audit'] = check_final(output)
                    record['status'] = 'diagnostic_capture_joined'
            except BaseException as error:
                record.update(status='failed', final_audit_error=f'{type(error).__name__}: {error}')
            record['ended'] = time.time()
            save()
            lifecycle.seal_if_released(output, record)
        for stream in locks:
            stream.close()
    print(json.dumps(record))
    return 0 if record['status'] == 'diagnostic_capture_joined' else 1


if __name__ == '__main__':
    raise SystemExit(main())
