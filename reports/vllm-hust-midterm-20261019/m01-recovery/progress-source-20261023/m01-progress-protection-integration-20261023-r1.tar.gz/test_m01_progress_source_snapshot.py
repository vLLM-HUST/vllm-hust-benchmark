from types import SimpleNamespace as NS
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent / 'm01-critical-path-review-20261023'))
from m01_progress_source_snapshot import ProgressSourceSnapshots, ProgressSnapshotRunnerMixin


class Tensor:
    def __init__(self, values, pinned=True):
        self.values = np.array(values, dtype=np.int32)
        self.device, self.dtype, self.ndim = NS(type='cpu'), 'int32', 1
        self.pinned = pinned

    def is_pinned(self):
        return self.pinned

    def data_ptr(self):
        return self.values.__array_interface__['data'][0]

    def copy_(self, source):
        self.values[:] = source.values


def fixture():
    pending, observed, events = [], [], []

    class Event:
        def __init__(self):
            self.reads, self.syncs = [], 0
            events.append(self)

        def record(self):
            self.reads.extend(pending)
            pending.clear()

        def synchronize(self):
            observed.extend(read() for read in self.reads)
            self.reads.clear()
            self.syncs += 1

    torch = NS(int32='int32', int64='int64', npu=NS(Event=Event),
               empty_like=lambda source, pin_memory: Tensor([0] * len(source.values), pin_memory))
    original = Tensor([100])
    batch = NS(num_computed_tokens_cpu_tensor=original, num_computed_tokens_cpu=original.values)
    return torch, batch, pending, observed, events


def test_late_reads_remain_immutable_and_reuse_waits():
    torch, batch, pending, observed, events = fixture()
    guard = ProgressSourceSnapshots(torch, batch)
    original = batch.num_computed_tokens_cpu_tensor
    for expected in (100, 99, 98):
        def prepare():
            source = batch.num_computed_tokens_cpu_tensor
            pending.append(lambda: int(source.values[0]))
            assert batch.num_computed_tokens_cpu is original.values
            return expected
        assert guard.run(prepare) == expected
        assert batch.num_computed_tokens_cpu_tensor is original
        original.values[:] -= 1
    assert observed == [100] and events[0].syncs == 1
    events[1].synchronize()
    events[0].synchronize()
    assert observed == [100, 99, 98]
    assert len(guard.buffers) == len(guard.events) == 2


def test_native_exception_restores_source_and_fences_pending_read():
    torch, batch, pending, observed, events = fixture()
    guard = ProgressSourceSnapshots(torch, batch)
    original = batch.num_computed_tokens_cpu_tensor
    def prepare():
        source = batch.num_computed_tokens_cpu_tensor
        pending.append(lambda: int(source.values[0]))
        raise ValueError('native failure')
    with pytest.raises(ValueError, match='native failure'):
        guard.run(prepare)
    assert batch.num_computed_tokens_cpu_tensor is original and not guard.active
    original.values[:] = 0
    events[0].synchronize()
    assert observed == [100]


def test_fence_failure_restores_source_and_prevents_reuse():
    torch, batch, _, _, events = fixture()
    guard = ProgressSourceSnapshots(torch, batch)
    original = batch.num_computed_tokens_cpu_tensor
    def fail():
        raise RuntimeError('fence failure')
    events[0].record = fail
    with pytest.raises(RuntimeError, match='fence failure'):
        guard.run(lambda: None)
    assert batch.num_computed_tokens_cpu_tensor is original
    with pytest.raises(RuntimeError, match='failed'):
        guard.run(lambda: None)


def test_reentry_is_rejected():
    torch, batch, *_ = fixture()
    guard = ProgressSourceSnapshots(torch, batch)
    with pytest.raises(RuntimeError, match='reentered'):
        guard.run(lambda: guard.run(lambda: None))


def test_alias_requirement_is_checked():
    torch, batch, *_ = fixture()
    batch.num_computed_tokens_cpu = batch.num_computed_tokens_cpu.copy()
    with pytest.raises(ValueError, match='alias'):
        ProgressSourceSnapshots(torch, batch)


def test_runner_mixin_is_opt_in_and_reports_exercised_calls():
    torch, batch, pending, observed, events = fixture()
    class Native:
        def _prepare_inputs(self, value):
            source = batch.num_computed_tokens_cpu_tensor
            pending.append(lambda: int(source.values[0]))
            return value
    class Runner(ProgressSnapshotRunnerMixin, Native):
        pass
    runner = Runner()
    assert runner._prepare_inputs(42) == 42
    assert not hasattr(runner, '_m01_progress_snapshot_calls')
    pending.clear()
    runner._m01_progress_source_snapshots = ProgressSourceSnapshots(torch, batch)
    runner._m01_progress_snapshot_calls = 0
    assert runner._prepare_inputs(43) == 43
    batch.num_computed_tokens_cpu[:] = 0
    events[0].synchronize()
    assert observed == [100] and runner._m01_progress_snapshot_calls == 1
