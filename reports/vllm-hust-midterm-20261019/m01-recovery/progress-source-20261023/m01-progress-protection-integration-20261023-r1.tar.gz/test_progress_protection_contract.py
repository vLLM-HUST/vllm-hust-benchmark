import json

import pytest

import run_capture_b1 as controller


def test_plan_requires_boolean_and_explicit_variant(monkeypatch):
    monkeypatch.setattr(controller, 'validate_original_plan', lambda value: value)
    plan = dict(protocol='m01-diagnostic-capture/v1', run_id='protected-test-r1',
                measurement_role='diagnostic_qualification', capture_draft_lengths=True,
                capture_draft_inputs=True, protect_progress_source=True,
                implementation_variant='diagnostic-progress-source-protected/v1')
    assert controller.validate_plan(plan) is plan
    for changes in (dict(protect_progress_source='1'),
                    dict(implementation_variant='unchanged-b1'),
                    dict(capture_draft_inputs=False)):
        with pytest.raises(ValueError):
            controller.validate_plan(dict(plan, **changes))


@pytest.mark.parametrize('protection', [None, dict(enabled=False),
    dict(enabled=True, failed=False, prepare_calls=0),
    dict(enabled=True, failed=True, prepare_calls=1),
    dict(enabled=True, failed=False, prepare_calls=True)])
def test_final_rejects_unexercised_protection(tmp_path, protection):
    (tmp_path / 'scheduler-1.json').write_text('{}')
    for rank in (0, 1):
        (tmp_path / f'worker-{rank}.json').write_text(json.dumps(
            dict(progress_source_protection=protection) if protection is not None else {}))
    with pytest.raises(ValueError, match='protection not exercised'):
        controller.check_final(tmp_path, require_progress_protection=True)
