"""Owned, small NPU check of upload-wait-copy-replay ordering; no model loaded."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
DEVICES=(0,1,6,7)


def progress_child(output):
    import torch
    import torch_npu
    from types import SimpleNamespace
    from m01_progress_source_snapshot import ProgressSourceSnapshots
    torch.npu.set_device(0)
    matrix = torch.ones((8192, 8192), dtype=torch.bfloat16, device='npu:0')
    product = torch.empty_like(matrix)
    torch.mm(matrix, matrix, out=product)
    torch.npu.synchronize()
    cases = []
    for repetition in range(3):
        for protected in (False, True):
            host = torch.full((32,), 100, dtype=torch.int64, pin_memory=True)
            if protected:
                source = torch.empty_like(host, pin_memory=True)
                source.copy_(host)
            else:
                source = host
            for _ in range(12):
                torch.mm(matrix, matrix, out=product)
            copied = source.to(device=matrix.device, non_blocking=True)
            host.sub_(1)
            torch.npu.synchronize()
            values = copied.cpu().tolist()
            assert set(values) <= {99, 100}
            if protected:
                assert values == [100] * 32
            cases.append(dict(repetition=repetition, protected=protected,
                              original_value_count=values.count(100),
                              mutated_value_count=values.count(99)))
    host = torch.full((32,), 100, dtype=torch.int64, pin_memory=True)
    batch = SimpleNamespace(num_computed_tokens_cpu_tensor=host,
                            num_computed_tokens_cpu=host.numpy())
    guard = ProgressSourceSnapshots(torch, batch)
    guarded_reads = []
    for iteration in range(6):
        for _ in range(12):
            torch.mm(matrix, matrix, out=product)
        copied = guard.run(lambda: batch.num_computed_tokens_cpu_tensor.to(
            device=matrix.device, non_blocking=True))
        assert batch.num_computed_tokens_cpu_tensor is host
        assert batch.num_computed_tokens_cpu.__array_interface__['data'][0] == host.data_ptr()
        guarded_reads.append((100 - iteration, copied))
        host.sub_(1)
    torch.npu.synchronize()
    guard_cases = []
    for expected, copied in guarded_reads:
        values = copied.cpu().tolist()
        assert values == [expected] * 32
        guard_cases.append(dict(expected=expected, values=values))
    result = dict(status='immutable_host_snapshot_device_check_passed', cases=cases,
                  guard_cases=guard_cases, guard_buffer_count=len(guard.buffers),
                  guard_source_sha256=hashlib.sha256(
                      (HERE / 'm01_progress_source_snapshot.py').read_bytes()).hexdigest(),
                  mutation_observed=any(c['mutated_value_count'] for c in cases if not c['protected']),
                  model_loaded=False, actual_model_dma_timing_proven=False,
                  torch_version=torch.__version__)
    with (output / 'device-probe.json').open('x') as stream:
        json.dump(result, stream, indent=2)


def input_child(output):
    import torch
    import torch_npu
    from draft_input_journal import DraftInputJournal
    torch.npu.set_device(0)
    source = torch.arange(12, dtype=torch.int32, device='npu:0').reshape(3, 4)
    captured = torch.empty_like(source)
    producer = torch.npu.Stream()
    graph = torch.npu.NPUGraph()
    torch.npu.synchronize()
    with torch.npu.graph(graph):
        captured.copy_(source)
    journal = DraftInputJournal(torch, source.device)
    expected = []
    for i in range(8):
        producer.wait_stream(torch.npu.current_stream())
        with torch.npu.stream(producer):
            source.copy_(torch.arange(12, dtype=torch.int32, device=source.device).reshape(3, 4) + i * 100)
            ready = torch.npu.Event()
            ready.record(producer)
        torch.npu.current_stream().wait_event(ready)
        journal.record(dict(iteration=i), dict(strided_table=source[:, ::2], transposed_positions=source.T))
        graph.replay()
        expected.append(captured.clone())
        source.fill_(-1)
    result = journal.finish(torch.npu.synchronize)
    assert result['complete'] and not result['errors']
    for record, tensor in zip(result['records'], expected, strict=True):
        assert record['values']['strided_table'] == tensor[:, ::2].cpu().tolist()
        assert record['values']['transposed_positions'] == tensor.T.cpu().tolist()
    result.update(status='integer_input_snapshot_replay_probe_passed', model_loaded=False,
                  full_runtime_stream_qualification=False, torch_version=torch.__version__)
    with (output / 'device-probe.json').open('x') as stream:
        json.dump(result, stream, indent=2)


def child(output):
    import torch
    import torch_npu
    from m01_draft_length_bridge import load_journal
    torch.npu.set_device(0)
    q=torch.zeros(25,dtype=torch.int64,device='npu:0')
    kv=torch.zeros_like(q)
    outq=torch.empty_like(q); outkv=torch.empty_like(q)
    producer=torch.npu.Stream()
    graph=torch.npu.NPUGraph()
    torch.npu.synchronize()
    with torch.npu.graph(graph):
        outq.copy_(q); outkv.copy_(kv)
    journal=load_journal()(torch,q.device,capacity=8,max_rows=25)
    observed=[]
    for i in range(8):
        producer.wait_stream(torch.npu.current_stream())
        with torch.npu.stream(producer):
            q.fill_(i+1); kv.fill_(100+i)
            ready=torch.npu.Event()
            ready.record(producer)
        torch.npu.current_stream().wait_event(ready)
        journal.record(q,kv,dict(iteration=i))
        graph.replay()
        observed.append((outq.clone(),outkv.clone()))
        q.fill_(-1); kv.fill_(-1)
    result=journal.finish(torch.npu.synchronize)
    assert not result['errors']
    for i,(record,(a,b)) in enumerate(zip(result['records'],observed,strict=True)):
        assert record['device_query_lengths']==a.cpu().tolist()==[i+1]*25
        assert record['device_kv_lengths']==b.cpu().tolist()==[100+i]*25
    result.update(status='upload_wait_snapshot_replay_probe_passed',model_loaded=False,
        full_runtime_stream_qualification=False,torch_version=torch.__version__)
    with (output/'device-probe.json').open('x') as stream:
        json.dump(result,stream,indent=2)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--child',action='store_true')
    parser.add_argument('--input-journal',action='store_true')
    parser.add_argument('--progress-source',action='store_true')
    args=parser.parse_args()
    if args.input_journal and args.progress_source:
        raise ValueError('Choose one probe mode')
    if args.child:
        (progress_child if args.progress_source else input_child if args.input_journal else child)(args.output)
        return
    locks=[]
    for name in ['/tmp/inference-project-container-model.lock']+[f'/tmp/gennova-device-leases/device-{i}.lock' for i in DEVICES]:
        lock=open(name,'a+b'); locks.append(lock)
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    args.output.mkdir()
    env=dict(os.environ,LD_LIBRARY_PATH='/usr/local/Ascend/driver/lib64/driver:/usr/local/Ascend/driver/lib64/common')
    def npu():
        return subprocess.check_output(['npu-smi','info'],env=env,text=True,timeout=30)
    def idle(raw):
        return all(f'No running processes found in NPU {i}' in raw for i in DEVICES)
    for _ in range(3):
        raw=npu()
        if not idle(raw):
            raise RuntimeError('Foreign device load; no probe started')
        time.sleep(2)
    (args.output/'npu-before.txt').write_text(raw)
    with (args.output/'child.log').open('x') as log:
        proc=subprocess.run(['bash',str(HERE/'runtime_boundary_b1.sh'),str(Path(__file__)),
            '--child','--output',str(args.output), *(['--input-journal'] if args.input_journal else []),
            *(['--progress-source'] if args.progress_source else [])],stdout=log,stderr=subprocess.STDOUT,
            env=dict(HOME='/root',PATH=os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1'),timeout=240)
    end=time.monotonic()+120
    while True:
        raw=npu()
        if idle(raw) or time.monotonic()>end:
            break
        time.sleep(2)
    (args.output/'npu-after.txt').write_text(raw)
    receipt=dict(child_exit=proc.returncode,all_devices_released=idle(raw),model_loaded=False,
                 status='passed' if proc.returncode==0 and idle(raw) else 'failed')
    (args.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if idle(raw):
        lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in sorted(args.output.iterdir()) if p.is_file()]
        (args.output/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
    print(json.dumps(receipt))
    if receipt['status']!='passed':
        raise SystemExit(1)


if __name__=='__main__':
    main()
