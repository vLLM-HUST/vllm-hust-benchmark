"""Source-bound permitted interleaving; not a claim of actual DMA timing."""
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

import numpy as np

BASE = Path('/root/modcost-runtime-028-20261017/vllm-workspace/vllm/vllm/v1/worker/gpu_model_runner.py')
ASCEND = Path('/root/gennova-evidence/20261019-midterm-aligned/runtime/vllm_ascend/worker/model_runner_v1.py')
PLAN = Path('/workspace/m01-capture-b1-r6/execution-plan.json')


def reproduce(rejected):
    if rejected not in (0, 1, 2):
        raise ValueError('MTP2 rejection count required')
    plan = json.loads(PLAN.read_text())
    hashes = {}
    for path in (BASE, ASCEND):
        raw = path.read_bytes()
        hashes[str(path)] = hashlib.sha256(raw).hexdigest()
        assert hashes[str(path)] == plan['source_sha256'][str(path)]
    source = ASCEND.read_text()
    assert 'computed_token_tensor_cpu = self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs].to(' in source
    assert 'device=self.device, non_blocking=True' in source
    tree = ast.parse(BASE.read_text())
    correction = next(n for n in ast.walk(tree)
                      if isinstance(n, ast.FunctionDef) and n.name == 'correct_spec_decode_token_counts')
    host = np.array([100], dtype=np.int64)
    batch = NS(prev_req_id_to_index={'a': 0}, req_id_to_index={'a': 0}, num_computed_tokens_cpu=host)
    state = NS(num_computed_tokens=100)
    runner = NS(input_batch=batch, _get_valid_sampled_token_count=lambda: [3 - rejected])
    namespace = dict(self=runner, deferred_spec_decode_corrections=[('a', 2, state)], is_ngram_gpu=False)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[correction], type_ignores=[])),
                 '<pinned-deferred-correction>', 'exec'), namespace)
    mutable_source = host[:1]
    immutable_source = mutable_source.copy()
    namespace['correct_spec_decode_token_counts']()
    actual_progress = 100 - rejected
    assert host[0] == state.num_computed_tokens == actual_progress
    # Model the allowed ordering where DMA reads its source after CPU correction.
    mutable_rope = 100 + actual_progress - int(mutable_source[0])
    immutable_rope = 100 + actual_progress - int(immutable_source[0])
    assert mutable_rope - actual_progress == rejected
    assert immutable_rope == actual_progress
    return dict(rejected=rejected, corrected_progress=actual_progress,
                mutable_source_late_read=int(mutable_source[0]),
                immutable_source_late_read=int(immutable_source[0]),
                mutable_position_delta=mutable_rope - actual_progress,
                immutable_position_delta=immutable_rope - actual_progress,
                source_sha256=hashes)


if __name__ == '__main__':
    result = dict(status='source_bound_late_read_interleaving_reproduced',
                  cases=[reproduce(n) for n in (0, 1, 2)],
                  actual_dma_timing_proven=False, runtime_modified=False,
                  limitation='Shows a permitted source-lifetime failure mechanism, not which DMA ordering occurred in r6.')
    with Path('/workspace/m01-progress-source-lifetime.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([dict(rejected=c['rejected'], mutable_delta=c['mutable_position_delta'],
                           immutable_delta=c['immutable_position_delta']) for c in result['cases']]))
