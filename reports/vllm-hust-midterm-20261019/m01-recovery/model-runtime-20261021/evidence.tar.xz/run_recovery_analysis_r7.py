"""Run only the sealed same-run derivations; stop at the first inconsistent input."""
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
FILES = [
    'integrate_r21_hardware.py', 'audit_r21_inventory.py',
    'derive_r21_attention_window.py', 'derive_r21_matrix.py',
    'audit_r21_gdn_publications.py', 'derive_r21_device_gdn.py',
    'derive_r21_gdn_prefill.py', 'derive_r21_norm.py',
    'derive_r21_softmax.py', 'derive_r21_scalar.py',
    'derive_r21_gdn_preprocess.py', 'audit_vocab_projection_r21.py',
    'audit_r21_logits.py', 'derive_r21_vocab_window.py',
    'audit_r21_device_maps.py', 'assemble_r21_accounted_families.py',
]

out = ROOT / 'recovery-analysis-execution-r7'
out.mkdir(exist_ok=False)
records = []
for original in FILES:
    name = original.replace('r21', 'recovery_model_r7')
    if original == 'integrate_r21_hardware.py':
        name = 'integrate_recovery_model_r7_hardware.py'
    if original == 'audit_vocab_projection_r21.py':
        name = 'audit_vocab_projection_recovery_model_r7.py'
    begin = time.time()
    with (out / (name + '.log')).open('x') as log:
        command = [sys.executable, str(ROOT / name)]
        if original == 'integrate_r21_hardware.py':
            command.extend(['--output', str(ROOT / 'recovery_model_r7-hardware.json')])
        result = subprocess.run(command, cwd=ROOT,
                                stdout=log, stderr=subprocess.STDOUT)
    records.append(dict(module=name, exit_code=result.returncode, started=begin, ended=time.time()))
    (out / 'receipt.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
