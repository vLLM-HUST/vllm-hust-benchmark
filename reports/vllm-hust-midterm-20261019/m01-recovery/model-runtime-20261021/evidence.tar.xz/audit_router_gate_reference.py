"""Audit actual fused-router calls; keep special functions separate from FLOPs."""
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def router_counts(tokens, experts=256, top_k=8):
    if any(type(v) is not int for v in (tokens, experts, top_k)):
        raise ValueError("Integer extents required")
    if tokens < 0 or not 1 <= top_k <= experts:
        raise ValueError("Invalid routing extents")
    return {
        "basic": {
            "subtract_max": tokens * experts,
            "full_sum_add": tokens * (experts - 1),
            "full_normalize_multiply": tokens * experts,
            "selected_sum_add": tokens * (top_k - 1),
            "selected_denominator_epsilon_add": tokens,
        },
        "separate": {
            "exp": tokens * experts,
            "reciprocal": tokens,
            "selected_normalize_divide": tokens * top_k,
            "reduce_max_semantic_comparisons": tokens * (experts - 1),
        },
    }


def main():
    plan_path = ROOT / "router-gate-reference-plan-r1.json"
    control_path = ROOT / "router-gate-reference-control-r1/receipt.json"
    plan, control = json.loads(plan_path.read_text()), json.loads(control_path.read_text())
    assert control["status"] == "collected_pending_component_audit"
    assert control["probe_exit_code"] == control["cleanup_exit_code"] == 0
    assert control["all_devices_released"] and control["sampler_errors"] == []
    for name, sha in {**plan["source_sha256"], **control["input_hashes"]}.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha
    ranks = []
    for rank in (0, 1):
        path = ROOT / f"router-gate-reference-r1/rank-{rank}.json"
        raw = json.loads(path.read_text())
        assert raw["rank"] == rank and raw["status"] == "qualified_component_timings"
        assert raw["router_type"] == "AscendFusedTopKRouter"
        assert raw["plan_sha256"] == hashlib.sha256(plan_path.read_bytes()).hexdigest()
        totals = {"router": 0.0, "fa_gate": 0.0}
        cases = []
        for case, row in zip(plan["cases"], raw["cases"], strict=True):
            assert row["shape"] == case and row["case"] == case["case"]
            check = row["checks"]
            assert check["finite"] and check["close"]
            if case["kind"] == "router":
                assert check["ids_exact"] and check["max_weight_sum_error"] <= 1e-5
                assert check["channels"] == 8 and len(row["router_calls"]) == 4
                for call in row["router_calls"]:
                    assert call == {
                        "shape": [case["rows"], 256], "dtype": "torch.float32",
                        "k": 8, "k_group": 1, "group_count": 1, "group_select_mode": 1,
                        "renorm": 1, "norm_type": 0, "out_flag": False,
                        "routed_scaling_factor": 1.0, "eps": 1e-20, "bias_is_none": True,
                    }
            else:
                assert check["channels"] == 2048 and row["router_calls"] == []
            tol = plan[case["kind"]]
            for a, b in zip(check["actual_first16"], check["cpu_first16"], strict=True):
                assert abs(a - b) <= tol["atol"] + tol["rtol"] * abs(b)
            values = []
            assert len(row["timings"]) == 3
            for i, t in enumerate(row["timings"]):
                assert t["repetition"] == i and t["replays"] == 100
                assert control["started"] <= t["start_wall"] < t["end_wall"] <= control["ended"]
                value = t["device_ms"] / 100
                assert math.isfinite(value) and value > 0
                values.append(value)
            median = statistics.median(values)
            totals[case["kind"]] += median * case["calls"]
            cases.append({**case, "times_ms": values, "median_ms": median,
                          "repetition_ratio": max(values) / min(values)})
        ranks.append({"rank": rank, "raw_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "weighted_ms_by_kind": totals, "cases": cases,
                      "max_repetition_ratio": max(c["repetition_ratio"] for c in cases),
                      "max_abs_by_kind": {kind: max(r["checks"]["max_abs"] for r in raw["cases"]
                                                    if r["shape"]["kind"] == kind)
                                          for kind in totals}})
    moe = json.loads((ROOT / "moe-scalar-source-audit-r1.json").read_text())
    rope = json.loads((ROOT / "rope-reference-summary-r2.json").read_text())
    assert moe["request_phase"] == plan["request_phase"]
    router = router_counts(moe["useful_token_layers"])
    fa_tokens = rope["whole_model_valid_token_layers"]
    gate_multiply = fa_tokens * 4096
    basic_subtotal = sum(router["basic"].values()) + gate_multiply
    output = {
        "status": "qualified_router_and_fa_gate_components",
        "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
        "control_sha256": hashlib.sha256(control_path.read_bytes()).hexdigest(),
        "request_phase": plan["request_phase"], "ranks": ranks,
        "router_useful_token_layers": moe["useful_token_layers"],
        "fa_useful_token_layers": fa_tokens,
        "router_scalar_accounting": router,
        "fa_gate_multiply": gate_multiply, "fa_gate_sigmoid_separate": gate_multiply,
        "new_basic_subtotal": basic_subtotal,
        "model_effective_flops": None, "attainment_percent": None,
        "limitations": plan["limitations"] + [
            "Full softmax subtract/sum/scale and selected sum/epsilon are counted from the frozen no-group kernel source.",
            "Reciprocal, division, exp, sigmoid and comparisons are separate; no arbitrary FLOP conversion.",
            "Multiplication by the identity routed_scaling_factor and integer indexing are not useful floating-point work.",
            "The sampled CPU reference uses FP64 stable softmax; device routing is FP32.",
        ],
    }
    output_path = ROOT / "router-gate-reference-summary-r1.json"
    with output_path.open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    prior_path = ROOT / "same-run-partial-accounting-r9-v8.json"
    catalog = json.loads(prior_path.read_text())
    assert catalog["request_phase"] == plan["request_phase"]
    catalog["components"]["router_softmax_basic_ops"] = sum(router["basic"].values())
    catalog["components"]["fa_output_gate_multiply"] = gate_multiply
    catalog["covered_basic_semantic_subtotal"] += basic_subtotal
    assert sum(catalog["components"].values()) == catalog["covered_basic_semantic_subtotal"]
    catalog["previous_catalog_sha256"] = hashlib.sha256(prior_path.read_bytes()).hexdigest()
    catalog["extension_input_sha256"][output_path.name] = hashlib.sha256(output_path.read_bytes()).hexdigest()
    catalog["status"] = "same_run_partial_catalog_with_router_and_fa_output_gate"
    catalog["excluded"] = [
        "Attention softmax and remaining GDN activation/gate arithmetic",
        "Special functions, divisions and comparisons have separate counts, not arbitrary FLOP equivalents",
        "Graph padding, masked implementation arithmetic and TP-replicated work",
        "Parameter transforms, precomputed trigonometric cache construction and structural indexing",
    ]
    with (ROOT / "same-run-partial-accounting-r9-v9.json").open("x") as stream:
        json.dump(catalog, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"ranks": [{k: v for k, v in r.items() if k != "cases"} for r in ranks],
                      "new_basic_subtotal": basic_subtotal,
                      "catalog_subtotal": catalog["covered_basic_semantic_subtotal"]}, indent=2))


if __name__ == "__main__":
    main()
