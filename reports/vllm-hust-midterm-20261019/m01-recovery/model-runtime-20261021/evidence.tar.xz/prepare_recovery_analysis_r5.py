"""Derive the unchanged same-run analysis pipeline for the new recovery run."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'prepare_recovery_analysis_r4.py').read_text()
source = source.replace('recovery-model-r4', 'recovery-model-r5')
source = source.replace('recovery_model_r4', 'recovery_model_r5')
source = source.replace('recovery-analysis-build-r4', 'recovery-analysis-build-r5')
exec(compile(source, str(ROOT / 'prepare_recovery_analysis_r4.py'), 'exec'),
     {'__file__': str(__file__), '__name__': '__main__'})
