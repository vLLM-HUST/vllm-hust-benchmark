"""Useful arithmetic for the deployed 16 -> 32 -> 64 triangular inverse."""


def inverse_arithmetic(n):
    if not isinstance(n, int) or not 1 <= n <= 64:
        raise ValueError("valid chunk length must be in [1, 64]")
    blocks = [min(16, n - start) for start in range(0, n, 16)]
    recurrence = sum(m * (m - 1) * (m - 2) // 3 for m in blocks)
    negations = sum(m * (m - 1) // 2 for m in blocks)
    merge = 0
    for start, size in ((0, 16), (32, 16), (0, 32)):
        left = max(0, min(size, n - start))
        right = max(0, min(size, n - start - size))
        merge += left * right * (right + 1) + right * left * (left + 1)
        negations += left * right
    return {
        "inverse16_recurrence": recurrence,
        "inverse_merge_triangular_dot": merge,
        "inverse_negations": negations,
    }
