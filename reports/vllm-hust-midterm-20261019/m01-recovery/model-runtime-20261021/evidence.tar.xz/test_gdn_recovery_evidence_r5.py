"""Independently reconstruct all snapshots, including untouched pool slots."""
import hashlib
import json
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'gdn-recovery-probe-r5'


def test_lifecycle_and_sources():
    receipt = json.loads((RUN / 'receipt.json').read_text())
    assert receipt['status'] == 'gdn_qualification_completed_pending_audit'
    assert receipt['exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_four_idle_after']
    assert not receipt['protocol']['prior_cache_imported']
    assert not receipt['performance_publication']
    for name, digest in receipt['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest


def test_independent_cpu_reconstruction():
    for device in [0, 1]:
        outputs = []
        for label in ['eager', 'graph-0', 'graph-1']:
            raw = torch.load(RUN / f'device-{device}' / f'{label}.pt', weights_only=True)
            data = raw['inputs']
            state = data['initial_state'].double().clone()
            output = torch.zeros_like(data['v'], dtype=torch.float64)
            for row, (begin, end) in enumerate(zip(data['cu_seqlens'][:-1], data['cu_seqlens'][1:])):
                slots = data['ssm_state_indices'][row]
                if slots[0] < 0:
                    continue
                h = state[slots[int(data['num_accepted_tokens'][row]) - 1]].clone()
                for pos in range(int(begin), int(end)):
                    q = data['q'][0, pos].double()[torch.arange(16) // 2] * 128 ** -0.5
                    k = data['k'][0, pos].double()[torch.arange(16) // 2]
                    h *= data['g'][0, pos].double().exp()[:, None, None]
                    delta = data['v'][0, pos].double() - torch.einsum('hkv,hk->hv', h, k)
                    delta *= data['beta'][0, pos].double()[:, None]
                    h += torch.einsum('hk,hv->hkv', k, delta)
                    state[slots[pos - int(begin)]] = h
                    output[0, pos] = torch.einsum('hkv,hk->hv', h, q)
            torch.testing.assert_close(raw['actual_output'].double(), output, rtol=0.008, atol=0.0002)
            torch.testing.assert_close(raw['actual_state'].double(), state, rtol=0.002, atol=0.0001)
            outputs.append(raw['actual_output'])
        assert torch.equal(outputs[0], outputs[1])
        assert not torch.equal(outputs[1], outputs[2])


def test_state_commit_reconstruction():
    import test_state_commit_device_evidence_v1 as state
    state.RUN = ROOT / 'state-commit-recovery-r5'
    state.test_lifecycle_and_frozen_sources()
    state.test_cpu_reconstruction_and_changed_inputs()
