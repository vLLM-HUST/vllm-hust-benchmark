"""Reconstruct prefill chunk semantics using recovery_model_r5 device-final initial states."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_gdn_ho_accounting import operations as ho
from audit_gdn_wy_accounting import arithmetic as wy
from gdn_inverse_accounting import inverse_arithmetic as inverse
from audit_recovery_model_r5_gdn_publications import join
from integrate_recovery_model_r5_hardware import classify

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5')


def chunks(group, record):
    fields = record['device_fields']
    cu = [row[0] for row in fields['cu']]
    histogram = Counter()
    for j, i in enumerate(record['metadata']['prefill_ids']):
        initial = fields['initial'][i][0]
        assert type(initial) is bool
        assert fields['prefill_state'][j][1] == int(initial)
        length = cu[i + 1] - cu[i]
        assert length > 0
        for offset in range(0, length, 64):
            histogram[min(64, length - offset), initial or offset > 0] += len(group['layers'])
    return histogram


def main():
    summary_path = ROOT / 'recovery_model_r5-gdn-publication-summary.json'
    ledger_path = ROOT / 'recovery_model_r5-device-gdn-ledger.json'
    summary, ledger = [json.loads(p.read_text()) for p in (summary_path, ledger_path)]
    assert summary['request_phase'] == ledger['request_phase']
    paths = {summary_path, ledger_path, Path(__file__), ROOT / 'audit_gdn_ho_accounting.py',
             ROOT / 'audit_gdn_wy_accounting.py', ROOT / 'gdn_inverse_accounting.py',
             ROOT / 'audit_recovery_model_r5_gdn_publications.py', ROOT / 'integrate_recovery_model_r5_hardware.py'}
    for prior in (summary, ledger):
        for path, expected in prior['source_sha256'].items():
            path = Path(path)
            assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
            paths.add(path)
    ranks = []
    for expected in summary['ranks']:
        pid = expected['pid']
        capture_path = RUN / f'moe-deferred-{pid}.json'
        publication_path = RUN / f'gdn-publication-{pid}.json'
        capture, publication = [json.loads(p.read_text()) for p in (capture_path, publication_path)]
        histograms = {name: Counter() for name in expected['cohorts']}
        for frame, pairs in join(capture['frames'], publication['records']):
            a, b = capture['anchor_host_bracket']
            start = [a + frame['start_ms'] / 1000 - .002, b + frame['start_ms'] / 1000 + .002]
            end = [a + frame['end_ms'] / 1000 - .002, b + frame['end_ms'] / 1000 + .002]
            name = 'inside_request_under_clock_tolerance' if classify(start, end, summary['request_phase']) == 'inside' else 'boundary_or_tail'
            for group, record in pairs:
                histograms[name].update(chunks(group, record))
        cohorts = {}
        for name, histogram in histograms.items():
            assert sum(n * count for (n, state), count in histogram.items()) == expected['cohorts'][name].get('prefill_tokens_layers', 0)
            totals = Counter()
            for (n, state), count in histogram.items():
                for prefix, values in [('ho', ho(n, state)), ('wy', wy(n)), ('inverse', inverse(n))]:
                    totals.update({f'{prefix}_{key}': value * count * 16 for key, value in values.items()})
            cohorts[name] = {
                'chunk_catalog': [{'length': n, 'has_state': state, 'chunk_layers': count}
                                  for (n, state), count in sorted(histogram.items())],
                'operations_per_rank': totals,
                'basic_arithmetic_subtotal': sum(value for key, value in totals.items()
                                                 if not key.endswith(('exp_evaluations', 'clamp_comparisons'))),
            }
        ranks.append({'pid': pid, 'cohorts': cohorts})
        paths.update((capture_path, publication_path))
    assert ranks[0]['cohorts'] == ranks[1]['cohorts']
    output = {'status': 'recovery_model_r5_device_initial_state_prefill_semantic_ledger', 'ranks': ranks,
              'request_phase': summary['request_phase'],
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},
              'model_effective_flops': None, 'm01_attainment': None,
              'limitations': ['Device state flags and lengths, but source-semantic arithmetic rather than instruction counters.',
                              'Native binary equivalence and workload-matched component capacity remain separate checks.',
                              'Special functions are separate categories; other normalization and elementwise families are excluded.']}
    with (ROOT / 'recovery_model_r5-device-gdn-prefill.json').open('x') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{k: v for k, v in rank.items() if k == 'pid'} | {
        'basic_arithmetic': {name: c['basic_arithmetic_subtotal'] for name, c in rank['cohorts'].items()}}
        for rank in ranks]))


if __name__ == '__main__':
    main()
