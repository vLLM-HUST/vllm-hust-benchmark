"""Extend prospective hardware coverage without changing model or workload."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


build = json.loads((ROOT / 'model-recovery-controller-r5.json').read_text())
for name, digest in build['files'].items():
    assert sha(ROOT / name) == digest, name
previous = json.loads((ROOT / 'm01-recovery-model-r5/receipt.json').read_text())
assert previous['status'] == 'measured' and previous['all_devices_released']
assert previous['bench_exit_code'] == previous['hardware_collector_exit_code'] == 0
hardware = json.loads((ROOT / 'recovery_model_r5-hardware.json').read_text())
assert hardware['status'] == 'partial_interval_coverage_not_full_m01'
sampler = (ROOT / 'sample_system_hardware_r23.sh').read_text()
assert sampler.count('--sys-period=240') == 1
sampler = sampler.replace('--sys-period=240', '--sys-period=360')
collector = (ROOT / 'collect_model_recovery_r1.py').read_text().replace(
    'sample_system_hardware_r23.sh', 'sample_system_hardware_recovery_r6.sh').replace(
    'profiler.wait(timeout=600)', 'profiler.wait(timeout=900)')
controller = (ROOT / 'measure_model_recovery_r5.py').read_text().replace(
    'collect_model_recovery_r1.py', 'collect_model_recovery_r2.py').replace(
    'model-recovery-controller-r5.json', 'model-recovery-controller-r6.json').replace(
    'collector.wait(timeout=600)', 'collector.wait(timeout=900)')
outputs = {'sample_system_hardware_recovery_r6.sh': sampler,
           'collect_model_recovery_r2.py': collector,
           'measure_model_recovery_r6.py': controller}
for name, source in outputs.items():
    with (ROOT / name).open('x') as stream:
        stream.write(source)
names = list(outputs) + ['prepare_model_recovery_r6.py', 'model-recovery-controller-r5.json',
                        'm01-recovery-model-r5/receipt.json', 'recovery_model_r5-hardware.json',
                        'integrate_recovery_model_r5_hardware_v2.py', 'prepare_recovery_hardware_analysis_r5_v2.py']
build['files'].update({name: sha(ROOT / name) for name in names})
build['hardware_sampling_change'] = {'previous_seconds': 240, 'next_seconds': 360,
    'reason': 'Cover all deferred export synchronizations, including observer drain.',
    'workload_changed': False, 'model_configuration_changed': False,
    'compiler_caches': 'fresh empty per-run directories; no seed imported'}
with (ROOT / 'model-recovery-controller-r6.json').open('x') as stream:
    json.dump(build, stream, indent=2)
    stream.write('\n')
print('Recovery r6 sealed: same workload, 360-second hardware sampling, fresh caches.')
