"""Audit fused RMS/RoPE timing and add only disjoint useful rotation arithmetic."""

import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def rope_operations(tokens, heads=18, rotary_dim=64):
    if any(type(v) is not int or v < 0 for v in (tokens, heads, rotary_dim)):
        raise ValueError("non-negative integer dimensions required")
    if heads < 1 or rotary_dim < 2 or rotary_dim % 2:
        raise ValueError("positive heads and even rotation dimension required")
    return {"multiply": 2 * tokens * heads * rotary_dim,
            "add_or_subtract": tokens * heads * rotary_dim}


def main():
    plan_path = ROOT / "rope-reference-plan-r1.json"
    control_path = ROOT / "rope-reference-control-r1/receipt.json"
    plan, control = json.loads(plan_path.read_text()), json.loads(control_path.read_text())
    assert control["probe_exit_code"] == control["cleanup_exit_code"] == 0
    assert control["all_devices_released"] and not control["sampler_errors"]
    for name, digest in {**control["input_hashes"], **plan["source_sha256"]}.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    results = []
    for rank in (0, 1):
        path = ROOT / f"rope-reference-r1/rank-{rank}.json"
        raw = json.loads(path.read_text())
        assert raw["rank"] == rank and raw["status"] == "qualified_component_timings"
        assert raw["plan_sha256"] == hashlib.sha256(plan_path.read_bytes()).hexdigest()
        assert Path(raw["contiguous_import"]) == ROOT / "runtime/vllm_ascend/ops/triton/linearnorm/split_qkv_rmsnorm_mrope.py"
        assert Path(raw["partitioned_import"]) == ROOT / "microflow-payload-r4/hust_prefill_microflow/runtime/microflow_rope.py"
        cases = []
        for row, case in zip(raw["cases"], plan["cases"], strict=True):
            assert row["case"] == case["case"] and row["shape"] == case
            assert row["cos_stride"] == [case["cos_tokens"] * 64, 64, 1]
            assert [c["name"] for c in row["checks"]] == ["q", "k", "v", "gate"]
            for check in row["checks"]:
                assert check["finite"] and check["close"]
                assert math.isfinite(check["max_abs"]) and check["max_abs"] >= 0
                assert check["atol"] == 0.002 and check["rtol"] == 0.02
                for actual, expected in zip(check["actual_first16"], check["cpu_first16"], strict=True):
                    assert math.isfinite(actual) and math.isfinite(expected)
                    assert abs(actual - expected) <= check["atol"] + check["rtol"] * abs(expected)
                if check["name"] in ("v", "gate"):
                    assert check["max_abs"] == 0
            assert len(row["timings"]) == plan["repetitions"] == 3
            values = []
            for i, timing in enumerate(row["timings"]):
                assert timing["repetition"] == i and timing["replays"] == 100
                assert control["started"] <= timing["start_wall"] < timing["end_wall"] <= control["ended"]
                value = timing["device_ms"] / 100
                assert math.isfinite(value) and value > 0
                values.append(value)
            cases.append({**case, "timings_ms": values, "median_ms": statistics.median(values),
                          "dispersion": max(values) / min(values)})
        results.append({
            "rank": rank, "raw_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "cases": cases,
            "source_call_weighted_ms": sum(c["calls"] * c["median_ms"] for c in cases),
            "max_dispersion": max(c["dispersion"] for c in cases),
            "max_abs_by_output": {name: max(c["max_abs"] for row in raw["cases"] for c in row["checks"] if c["name"] == name)
                                  for name in ("q", "k", "v", "gate")},
        })
    counts_path = ROOT / "host-attention-pairs-r9.json"
    counts = json.loads(counts_path.read_text())
    assert counts["request_phase"] == plan["request_phase"]
    assert counts["ranks"][0]["roles"] == counts["ranks"][1]["roles"]
    roles = counts["ranks"][0]["roles"]
    tokens = 10 * roles["target"]["valid_query_tokens"] + sum(
        roles[f"draft_step{i}"]["valid_query_tokens"] for i in range(2))
    ops = rope_operations(tokens)
    result = {
        "status": "qualified_fused_rms_rope_component_reference",
        "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
        "control_sha256": hashlib.sha256(control_path.read_bytes()).hexdigest(),
        "counts_sha256": hashlib.sha256(counts_path.read_bytes()).hexdigest(),
        "cases_per_rank": len(plan["cases"]), "ranks": results,
        "whole_model_valid_token_layers": tokens, "useful_rope_arithmetic": ops,
        "rope_basic_arithmetic_subtotal": sum(ops.values()),
        "model_effective_flops": None, "attainment_percent": None,
        "limitations": plan["limitations"] + [
            "Rotation uses four multiplies and two add/subtracts per coordinate pair; sign changes are not double-counted.",
            "Cached cos/sin preparation and structural indexing are excluded from token rotation arithmetic.",
            "CPU oracle checks up to five rows, all channels; V/gate copied outputs must be exact.",
            "Real model value distributions and BF16 bitwise equivalence are not claimed.",
        ],
    }
    destination = ROOT / "rope-reference-summary-r1.json"
    with destination.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    prior_path = ROOT / "same-run-partial-accounting-r9-v6.json"
    combined = json.loads(prior_path.read_text())
    assert combined["request_phase"] == plan["request_phase"]
    combined["components"]["partial_rope_basic_ops"] = sum(ops.values())
    combined["covered_basic_semantic_subtotal"] += sum(ops.values())
    assert sum(combined["components"].values()) == combined["covered_basic_semantic_subtotal"]
    combined["previous_catalog_sha256"] = hashlib.sha256(prior_path.read_bytes()).hexdigest()
    combined["extension_input_sha256"][destination.name] = hashlib.sha256(destination.read_bytes()).hexdigest()
    combined["status"] = "same_run_partial_catalog_with_partial_rope"
    combined["excluded"] = [
        "Softmax, remaining activations and elementwise gates",
        "Special functions have separate counts where known, not arbitrary FLOP equivalents",
        "Graph padding, masked implementation arithmetic and TP-replicated work",
        "Parameter transforms, precomputed trigonometric cache construction and structural indexing",
    ]
    with (ROOT / "same-run-partial-accounting-r9-v7.json").open("x") as stream:
        json.dump(combined, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"ranks": [{k: v for k, v in r.items() if k != "cases"} for r in results],
                      "rope_arithmetic": ops, "new_subtotal": combined["covered_basic_semantic_subtotal"]}, indent=2))


if __name__ == "__main__":
    main()
