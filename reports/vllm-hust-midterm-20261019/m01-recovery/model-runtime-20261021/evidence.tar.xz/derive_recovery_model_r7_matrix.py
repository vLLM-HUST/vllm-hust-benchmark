"""Same-run matrix ledger from validated device token extents and loaded weights."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = Path("/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r7")


def weight_product(shape):
    if len(shape) != 2 or any(type(n) is not int or n <= 0 for n in shape):
        raise ValueError("Expected positive two-dimensional loaded weight")
    return shape[0] * shape[1]


def count_role(modules, tokens, role):
    if type(tokens) is not int or tokens < 0 or role not in ("target", "draft"):
        raise ValueError("Invalid token extent or model role")
    layers = 40 if role == "target" else 1
    # Router and shared gate are replicated; other listed matrices are TP shards.
    selectors = [
        (".self_attn.qkv_proj", 10 if role == "target" else 1, [4608, 2048], 2),
        (".self_attn.o_proj", 10 if role == "target" else 1, [2048, 2048], 2),
        (".shared_expert.gate_up_proj", layers, [512, 2048], 2),
        (".shared_expert.down_proj", layers, [2048, 256], 2),
        (".mlp.gate", layers, [256, 2048], 1),
        (".mlp.shared_expert_gate", layers, [1, 2048], 1),
    ]
    if role == "target":
        selectors.extend([
            (".linear_attn.in_proj_qkvz", 30, [6144, 2048], 2),
            (".linear_attn.in_proj_ba", 30, [32, 2048], 2),
            (".linear_attn.out_proj", 30, [2048, 2048], 2),
        ])
    else:
        selectors.append(("model.fc", 1, [1024, 4096], 2))
    entries = {}
    for suffix, count, shape, partitions in selectors:
        matched = [m for m in modules if m["name"].endswith(suffix)]
        assert len(matched) == count, suffix
        assert all(m["parameters"]["weight"]["shape"] == shape for m in matched)
        entries[suffix] = 2 * tokens * count * weight_product(shape) * partitions
    routed = [m for m in modules if m["type"].endswith(".AscendRoutedExperts")]
    assert len(routed) == layers
    for module in routed:
        cfg = module["objects"]["moe_config"]["scalars"]
        assert cfg["tp_size"] == 2 and cfg["ep_size"] == 1
        assert cfg["num_experts"] == 256 and cfg["is_sequence_parallel"] is False
        assert module["scalars"]["top_k"] == 8
        assert module["parameters"]["w13_weight"]["shape"] == [256, 2048, 512]
        assert module["parameters"]["w2_weight"]["shape"] == [256, 256, 2048]
    entries["routed_expert_projection"] = (
        2 * tokens * layers * 8 * 2 * (2048 * 512 + 256 * 2048))
    return entries


def build():
    attention_path = ROOT / "recovery_model_r7-request-attention.json"
    attention = json.loads(attention_path.read_text())
    assert attention["status"] == "device_lengths_joined_to_enclosing_forwards_and_partitioned_by_request_interval"
    for filename, digest in attention["source_sha256"].items():
        assert hashlib.sha256(Path(filename).read_bytes()).hexdigest() == digest
    dispatcher = ROOT / "runtime/vllm_ascend/ops/fused_moe/token_dispatcher.py"
    receipt = json.loads((RUN / 'receipt.json').read_text())
    assert receipt['status'] == 'measured'
    assert hashlib.sha256(dispatcher.read_bytes()).hexdigest() == receipt['input_hashes'][str(dispatcher.relative_to(ROOT))]
    tree = ast.parse(dispatcher.read_text())
    active = [
        kw.value for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        and node.func.attr == "npu_moe_init_routing"
        for kw in node.keywords if kw.arg == "active_num"
    ]
    assert len(active) == 1
    assert ast.dump(active[0]) == ast.dump(ast.parse("num_tokens * self.top_k", mode="eval").body)
    traces = sorted(RUN.glob("token-accounting-*.jsonl"))
    assert len(traces) == 2
    inventories = []
    ranks = []
    for path in traces:
        inventory = installed = None
        with path.open() as stream:
            for line in stream:
                event = json.loads(line)
                if event["event"] == "loaded_model_inventory":
                    assert inventory is None
                    inventory = event
                if event["event"] == "observer_installed":
                    assert installed is None
                    installed = event
                if event["event"] == "forward_enter":
                    assert event["moe_context"]["type"] == "MoECommType.ALLGATHER"
        assert inventory is not None and installed is not None
        inventories.append(inventory)
        ranks.append(installed["rank"])
    assert set(ranks) == {0, 1}
    cohorts = {}
    for name, counts in attention["cohorts"].items():
        tokens = {"target": counts.get("target", {}).get("valid_query_tokens", 0),
                  "draft": sum(counts.get(f"draft_step{i}", {}).get("valid_query_tokens", 0) for i in (0, 1))}
        entries = []
        for inventory in inventories:
            entries.append({role: count_role(inventory[role]["modules"], tokens[role], role)
                            for role in ("target", "draft")})
        assert entries[0] == entries[1]
        projection = sum(sum(values.values()) for values in entries[0].values())
        qk_av = sum(values["semantic_qk_av_arithmetic"] for values in counts.values())
        cohorts[name] = {
            "valid_tokens": tokens, "projection_entries_global": entries[0],
            "projection_semantic_subtotal": projection, "causal_qk_av_semantic_subtotal": qk_av,
            "matrix_semantic_subtotal": projection + qk_av,
        }
    paths = [attention_path, dispatcher, RUN / "receipt.json", Path(__file__), *traces]
    return {
        "status": "same_run_loaded_shape_matrix_ledger_with_device_length_cohorts",
        "request_phase": attention["request_phase"], "cohorts": cohorts,
        "source_sha256": {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        "model_effective_flops": None, "m01_attainment": None,
        "limitations": [
            "Semantic 2MNK convention, not physical padded-kernel instruction counting.",
            "Routed useful rows rely on the pinned full-range top-8 no-drop contract; valid per-expert distributions are not measured.",
            "TP shards are summed once; replicated router and shared gate are not multiplied by TP.",
            "Request classification inherits the qualified 2 ms clock-mapping assumption.",
            "Vocabulary, GDN core/convolution, normalization, RoPE, softmax and activations are excluded.",
            "This is not full effective F or an M01 attainment claim.",
        ],
    }


if __name__ == "__main__":
    output = ROOT / "recovery_model_r7-matrix-accounting.json"
    assert not output.exists()
    result = build()
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: {n: v[n] for n in (
        "valid_tokens", "projection_semantic_subtotal", "causal_qk_av_semantic_subtotal",
        "matrix_semantic_subtotal")} for k, v in result["cohorts"].items()}, indent=2))
