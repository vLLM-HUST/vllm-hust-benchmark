"""Reconstruct useful causal-convolution arithmetic, not executed instructions."""

from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_gdn_host_schedule import validate
from audit_token_accounting import request_phase

ROOT = Path(__file__).resolve().parent
KERNEL = "runtime/vllm_ascend/_cann_ops_custom/vendors/custom_transformer/op_impl/ai_core/tbe/custom_transformer_impl/ascendc/causal_conv1d/"


def operations(length, initial, width=4, channels=4096):
    if length < 1 or width < 1 or channels < 1 or not isinstance(initial, bool):
        raise ValueError("invalid causal-convolution dimensions or state flag")
    partial = min(length, width - 1)
    taps = length * width if initial else partial * (partial + 1) // 2 + (length - partial) * width
    return {
        "convolution_multiply": taps * channels,
        "convolution_add": (taps - length) * channels,
        "silu_evaluations": length * channels,
        "zero_history_multiply_excluded": (length * width - taps) * channels,
    }


def main():
    run = ROOT / "microflow-token-accounting-r9"
    receipt = json.loads((run / "receipt.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, json.loads((run / "mmlu-pro.json").read_text()))
    ranks = []
    for path in sorted(run.glob("token-accounting-*.jsonl")):
        events = list(map(json.loads, path.read_text().splitlines()))
        rank = next(e["rank"] for e in events if e["event"] == "observer_installed")
        inventory = next(e for e in events if e["event"] == "loaded_model_inventory")
        convs = [m for m in inventory["target"]["modules"] if m["name"].endswith(".linear_attn.conv1d")]
        assert len(convs) == 30
        assert all(m["parameters"]["weight"]["shape"] == [4096, 1, 4] for m in convs)
        assert all(m["parameters"]["weight"]["dtype"] == "torch.bfloat16" for m in convs)
        histogram, totals, counts = Counter(), Counter(), Counter()
        for e in events:
            if e["event"] != "forward_enter" or e["role"] != "target":
                continue
            if not phase["start_wall"] <= e["wall"] <= phase["end_wall"]:
                continue
            layers = []
            counts["target_contexts"] += 1
            for group in e["owned_gdn"]:
                validate(group, e["actual_tokens"])
                factor = len(group["layers"])
                layers.extend(group["layers"])
                verify = set(group["verify_ids"])
                assert all(row[0] >= 0 for row in group["verify_slots"])
                lengths = [b - a for a, b in zip(group["cu"], group["cu"][1:])]
                for i, length in enumerate(lengths):
                    role = "verify" if i in verify else "prefill"
                    initial = True if role == "verify" else group["initial"][i]
                    histogram[role, length, initial] += factor
                    counts[role + "_token_layers"] += length * factor
                    if not initial:
                        counts["zero_initial_sequence_layers"] += factor
                    for key, value in operations(length, initial).items():
                        totals[key] += value * factor
            assert len(layers) == len(set(layers)) == 30
        ranks.append({
            "rank": rank, "trace": path.name, "trace_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "counts": dict(counts), "operations": dict(totals),
            "basic_arithmetic_subtotal": totals["convolution_multiply"] + totals["convolution_add"],
            "sequence_catalog": [{"role": role, "length": n, "initial": initial, "sequence_layers": c}
                                 for (role, n, initial), c in sorted(histogram.items())],
        })
    assert {r["rank"] for r in ranks} == {0, 1}
    assert ranks[0]["sequence_catalog"] == ranks[1]["sequence_catalog"]
    sources = ["payload/betterscale/models/qwen35/mixed_core.py",
               "payload/betterscale/models/qwen35/service_metadata.py",
               KERNEL + "causal_conv1d.h", KERNEL + "causal_conv1d_fn_tasks.h",
               KERNEL + "causal_conv1d_update.h"]
    output = {
        "status": "source_and_host_derived_useful_convolution_catalog",
        "request_phase": phase, "ranks": ranks,
        "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
        "basic_arithmetic_subtotal": sum(r["basic_arithmetic_subtotal"] for r in ranks),
        "model_effective_flops": None, "attainment_percent": None,
        "limitations": [
            "Scalar multiply and add each count one; structural zero initial history is excluded.",
            "SiLU is recorded separately, with no arbitrary FLOP-equivalent cost.",
            "State reuse is derived from host flags; numerical zero values in live state are not treated as structural zeros.",
            "Installed CANN source and wrapper behavior are inspected, not a reproducible source-to-binary build proof.",
            "Rolling-path startup, duplicate partial sums, token padding and state copies are not effective convolution arithmetic.",
            "r9 omits accepted-token offsets used for verification state reads; exact state-access replay is not established.",
            "No device reference timing or full-model F/attainment is claimed by this catalog.",
        ],
    }
    with (ROOT / "conv-accounting-r9.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"ranks": [{k: v for k, v in r.items() if k != "sequence_catalog"} for r in ranks],
                      "basic_arithmetic_subtotal": output["basic_arithmetic_subtotal"]}, indent=2))


if __name__ == "__main__":
    main()
