"""Recover the missing preprocessing family, retaining both row-scope ledgers."""
import hashlib
import json
from pathlib import Path

from audit_gdn_preprocess_semantics import basic, operations, verify_source

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5')


def main():
    summary_path = ROOT / 'recovery_model_r5-gdn-publication-summary.json'
    summary = json.loads(summary_path.read_text())
    for name, digest in summary['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    receipt_path = RUN / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    payload_path = ROOT / 'payload-receipt.json'
    assert hashlib.sha256(payload_path.read_bytes()).hexdigest() == receipt['input_hashes']['payload-receipt.json']
    payload = json.loads(payload_path.read_text())
    paths = [Path(__file__), ROOT / 'audit_gdn_preprocess_semantics.py',
             summary_path, receipt_path, payload_path, ROOT / 'recovery_model_r5-norm-semantics.json']
    for name in ('models/qwen35/preprocess.py', 'models/qwen35/mixed_core.py',
                 'models/qwen35/service_metadata.py'):
        path = ROOT / 'payload/betterscale' / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == payload['payload_hashes'][name]
        paths.append(path)
    verify_source(paths[-3].read_text())
    ranks = []
    for rank in summary['ranks']:
        cohorts = {}
        for name, counts in rank['cohorts'].items():
            prefill = counts.get('prefill_tokens_layers', 0)
            active = counts.get('device_active_verify_tokens_layers', 0)
            skipped = counts.get('device_skipped_verify_tokens_layers', 0)
            scopes = {}
            for scope, rows in [('logical_valid_rows', prefill + active + skipped),
                                ('state_update_eligible_rows', prefill + active)]:
                counts = operations(rows)
                scopes[scope] = {'token_layers': rows, 'operations': counts,
                                 'basic_arithmetic_subtotal': basic(counts)}
            cohorts[name] = {'skipped_verify_token_layers': skipped, 'scopes': scopes}
        ranks.append({'pid': rank['pid'], 'cohorts': cohorts})
    assert ranks[0]['cohorts'] == ranks[1]['cohorts']
    result = {
        'status': 'source_semantic_preprocessing_scopes_not_complete_effective_flops',
        'ranks': ranks, 'model_effective_flops': None, 'm01_attainment': None,
        'source_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        'limitations': [
            'Scopes are alternatives, never additive; counts are per TP rank and layer.',
            'Valid-row semantics exclude padding, duplicate mapped capacity and address/copy operations.',
            'State-update eligibility is not proof that every computed row contributes to the final response.',
            'Softplus counts describe the tl.where source expression, not data-dependent mathematical branches or physical instructions.',
            'Parameter exp may be reused or hoisted; special functions, comparisons and unary negation are separate, without invented FLOP weights.',
            'Final device token maps and per-kernel preprocessing invocation counts were not captured; actual padded execution is not inferred.',
            'Existing RMS ledger explicitly excludes Q/K L2; convolution and recurrence remain separate.',
        ],
    }
    with (ROOT / 'recovery_model_r5-gdn-preprocess-semantics.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{ 'pid': r['pid'], 'cohorts': {
        name: {scope: values['basic_arithmetic_subtotal'] for scope, values in item['scopes'].items()}
        for name, item in r['cohorts'].items()}} for r in ranks]))


if __name__ == '__main__':
    main()
