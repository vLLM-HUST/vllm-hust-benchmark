"""Source-semantic Q/K L2 and gate counts, not padded device instructions."""
import ast


def operations(token_layers):
    if type(token_layers) is not int or token_layers < 0:
        raise ValueError('Nonnegative integer token-layer count required')
    # Two vectors, eight local heads, 128 coordinates each.
    heads = token_layers * 2 * 8
    gates = token_layers * 16
    return {
        'qk_square_multiply': heads * 128,
        'qk_reduce_add': heads * 127,
        'qk_epsilon_add': heads,
        'qk_normalize_multiply': heads * 128,
        'gate_bias_add': gates,
        'softplus_expression_add': gates,
        'gate_scale_multiply': gates,
        'inverse_sqrt_evaluations': heads,
        'softplus_expression_exp_evaluations': gates,
        'softplus_expression_log_evaluations': gates,
        'parameter_exp_expression_evaluations': gates,
        'sigmoid_evaluations': gates,
        'threshold_comparisons': gates,
        'unary_negations': gates,
    }


def basic(counts):
    return sum(value for key, value in counts.items()
               if key.endswith(('_multiply', '_add')))


def verify_source(source):
    tree = ast.parse(source)
    kernel = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                  and node.name == 'preprocess_kernel')
    expressions = {
        'qy': 'qx * tl.rsqrt(tl.sum(qx * qx, 2) + 1.0e-6)[:, :, None]',
        'ky': 'kx * tl.rsqrt(tl.sum(kx * kx, 2) + 1.0e-6)[:, :, None]',
        'gate_input': 'a + bias',
        'softplus': 'tl.where(gate_input <= 20.0, tl.log(1.0 + tl.exp(gate_input)), gate_input)',
    }
    assignments = {target.id: node.value for node in ast.walk(kernel)
                   if isinstance(node, ast.Assign) for target in node.targets
                   if isinstance(target, ast.Name)}
    for name, expression in expressions.items():
        assert ast.dump(assignments[name]) == ast.dump(ast.parse(expression, mode='eval').body)
    assert ast.dump(assignments['head']) == ast.dump(ast.parse(
        'tl.arange(0, 8)[None, :, None]', mode='eval').body)
    assert ast.dump(assignments['d']) == ast.dump(ast.parse(
        'tl.arange(0, 128)[None, None, :]', mode='eval').body)
    stored = [node.args[1] for node in ast.walk(kernel)
              if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
              and node.func.attr == 'store']
    for expression in ('-tl.exp(log) * softplus', 'tl.sigmoid(b)'):
        assert ast.dump(ast.parse(expression, mode='eval').body) in [ast.dump(node) for node in stored]

