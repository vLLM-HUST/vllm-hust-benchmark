"""Recover source-derived MoE activation metadata without changing r9 evidence."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SITE = Path("/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/"
            "venv-school-r1/lib/python3.12/site-packages")


def function(tree, name):
    nodes = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name]
    if len(nodes) != 1:
        raise ValueError(f"Expected one {name}, got {len(nodes)}")
    return nodes[0]


def default_value(node, name):
    defaults = dict(zip([a.arg for a in node.args.args[-len(node.args.defaults):]],
                        node.args.defaults))
    return ast.literal_eval(defaults[name])


def has_expression(tree, expression):
    expected = ast.dump(ast.parse(expression, mode="eval").body)
    return any(ast.dump(node) == expected for node in ast.walk(tree))


def scalar_counts(token_layers, top_k=8, hidden=2048, intermediate=512):
    values = token_layers, top_k, hidden, intermediate
    if any(type(x) is not int for x in values) or token_layers < 0 or min(values[1:]) < 1:
        raise ValueError("Invalid semantic dimensions")
    return {
        "routed_swiglu_outer_multiply": token_layers * top_k * intermediate,
        "shared_swiglu_outer_multiply": token_layers * intermediate,
        "routed_weight_multiply": token_layers * top_k * hidden,
        "routed_weighted_sum_add": token_layers * (top_k - 1) * hidden,
        "shared_gate_multiply": token_layers * hidden,
        "shared_routed_add": token_layers * hidden,
    }


def main():
    files = {
        "qwen3_5.py": SITE / "vllm/model_executor/models/qwen3_5.py",
        "qwen3_next.py": SITE / "vllm/model_executor/models/qwen3_next.py",
        "moe_factory.py": SITE / "vllm/model_executor/layers/fused_moe/layer.py",
        "moe_runner.py": SITE / "vllm/model_executor/layers/fused_moe/runner/moe_runner.py",
        "upstream_routed_experts.py": SITE / "vllm/model_executor/layers/fused_moe/routed_experts.py",
        "ascend_routed_experts.py": ROOT / "runtime/vllm_ascend/ops/fused_moe/routed_experts.py",
        "moe_mlp.py": ROOT / "runtime/vllm_ascend/ops/fused_moe/moe_mlp.py",
        "shared_experts.py": ROOT / "runtime/vllm_ascend/ops/fused_moe/shared_experts.py",
        "token_dispatcher.py": ROOT / "runtime/vllm_ascend/ops/fused_moe/token_dispatcher.py",
        "device_op.py": ROOT / "runtime/vllm_ascend/device/device_op.py",
    }
    trees = {name: ast.parse(path.read_text()) for name, path in files.items()}
    factory = function(trees["moe_factory.py"], "FusedMoEFactory")
    defaults = {key: default_value(factory, key) for key in (
        "activation", "swiglu_limit", "apply_router_weight_on_input",
        "routed_scaling_factor", "scoring_func")}
    assert defaults == {"activation": "silu", "swiglu_limit": None,
                        "apply_router_weight_on_input": False,
                        "routed_scaling_factor": 1.0, "scoring_func": "softmax"}
    constructors = [n for n in ast.walk(trees["qwen3_next.py"])
                    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                    and n.func.id == "FusedMoEFactory"]
    assert len(constructors) == 1
    assert all(k.arg is not None and k.arg not in defaults for k in constructors[0].keywords)
    assert has_expression(trees["moe_factory.py"], "MoEActivation.from_str(activation)")
    assert any(isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Attribute) and t.attr == "activation"
                       and isinstance(t.value, ast.Name) and t.value.id == "self"
                       for t in n.targets)
               and has_expression(n.value, "self.moe_config.activation")
               for n in ast.walk(trees["upstream_routed_experts.py"]))
    unquantized = next(n for n in trees["ascend_routed_experts.py"].body
                       if isinstance(n, ast.ClassDef) and n.name == "AscendUnquantizedFusedMoEMethod")
    supports = function(unquantized, "supports_fused_activation")
    assert len(supports.body) == 1 and isinstance(supports.body[0], ast.Return)
    assert ast.literal_eval(supports.body[0].value) is False
    assert has_expression(trees["moe_mlp.py"], "torch_npu.npu_swiglu(hidden_states)")
    assert has_expression(trees["shared_experts.py"], "F.sigmoid(gate_out) * shared_out")
    assert has_expression(trees["moe_runner.py"], "shared_output + fused_output")
    assert has_expression(trees["token_dispatcher.py"], "num_tokens * self.top_k")
    assert has_expression(trees["token_dispatcher.py"], "combine_metadata.topk_weights.to(hidden_states.dtype)")
    plan_path = ROOT / "swiglu-reference-plan-r1.json"
    plan = json.loads(plan_path.read_text())
    for name, digest in plan["source_sha256"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    tokens = plan["ranks"][0]["useful_token_layers"]
    assert tokens == plan["ranks"][1]["useful_token_layers"] == 13949541
    ops = scalar_counts(tokens)
    output = {
        "status": "source_derived_scalar_accounting_pending_combine_reference",
        "metadata_basis": "Deployed source defaults and recorded module/weight inventory; not direct r9 activation-field telemetry.",
        "factory_defaults": defaults,
        "request_phase": plan["request_phase"],
        "useful_token_layers": tokens,
        "basic_ops": ops, "basic_subtotal": sum(ops.values()),
        "special_functions_separate": {
            "silu": ops["routed_swiglu_outer_multiply"] + ops["shared_swiglu_outer_multiply"],
            "shared_gate_sigmoid": tokens,
        },
        "sources": {name: {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                    for name, path in files.items()},
        "swiglu_plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
        "admitted_to_whole_model_catalog": False,
        "limitations": [
            "Useful mathematical operations counted once globally; padding and TP replication excluded.",
            "Top-k reduction uses k products and k-1 additions per output coordinate.",
            "SiLU/sigmoid are separate counts, not assigned arbitrary FLOP equivalents.",
            "Router softmax, top-k selection, collectives and projection arithmetic excluded here.",
            "A matched weighted-combine/reference check is still required before whole-model admission.",
            "Historical raw evidence is unchanged; this is source-derived supplemental metadata.",
        ],
    }
    with (ROOT / "moe-scalar-source-audit-r1.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: v for k, v in output.items() if k != "sources"}, indent=2))


if __name__ == "__main__":
    main()
