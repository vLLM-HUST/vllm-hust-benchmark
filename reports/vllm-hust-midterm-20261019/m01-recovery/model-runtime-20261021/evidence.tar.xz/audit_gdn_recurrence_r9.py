"""Account eligible recurrent rows, separate scalar semantics from tiled repeats."""
import argparse
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
from audit_token_accounting import request_phase
from audit_gdn_host_schedule import validate
ROOT = Path(__file__).resolve().parent
KERNEL = ROOT / 'payload/betterscale/models/qwen35/decode_kv.py'

def operations(k, v, tile_v):
    assert k > 0 and v > 0 and (tile_v > 0)
    components = {'query_scale': k, 'state_decay': k * v, 'prediction_multiply': k * v, 'prediction_reduce': (k - 1) * v, 'residual_subtract': v, 'beta_scale': v, 'state_fma': 2 * k * v, 'output_multiply': k * v, 'output_reduce': (k - 1) * v}
    semantic = sum(components.values())
    tiles = (v + tile_v - 1) // tile_v
    return {'components': components, 'semantic_basic_flops': semantic, 'source_tiled_basic_flops': semantic + (tiles - 1) * k, 'semantic_exp_evaluations': 1, 'source_tiled_exp_evaluations': tiles}

def eligible(group, actual):
    validate(group, actual)
    q = [b - a for a, b in zip(group['cu'], group['cu'][1:])]
    ids, slots = (group['verify_ids'], group['verify_slots'])
    assert slots is not None and len(slots) == len(ids)
    active = skipped = 0
    for i, row in zip(ids, slots):
        assert len(row) == group['width'] == 3
        assert all((isinstance(value, int) for value in row))
        if row[0] < 0:
            skipped += q[i]
        else:
            active += q[i]
    return (active, skipped)

def audit(root, run):
    receipt = json.loads((run / 'receipt.json').read_text())
    result = json.loads((run / 'mmlu-pro.json').read_text())
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    assert result['completed'] == 200 and result['failed'] == 0
    phase = request_phase(receipt, result)
    ranks = []
    for path in sorted(run.glob('token-accounting-*.jsonl')):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        installed = next((e for e in events if e['event'] == 'observer_installed'))
        assert installed['observer_sha256'] == receipt['input_hashes']['token-observer-v8/hust_token_observer/__init__.py']
        counts = Counter()
        for event in events:
            if event['event'] != 'forward_enter' or not phase['start_wall'] <= event['wall'] <= receipt['bench_ended_wall']:
                continue
            if event['role'] == 'draft':
                assert not event['owned_gdn']
                continue
            counts['target_contexts'] += 1
            layers = []
            for group in event['owned_gdn']:
                layers.extend(group['layers'])
                active, skipped = eligible(group, event['actual_tokens'])
                factor = len(group['layers'])
                counts['eligible_token_layers'] += active * factor
                counts['skipped_token_layers'] += skipped * factor
                kind = 'decode' if group['decode_only'] else 'mixed'
                counts[kind + '_eligible_token_layers'] += active * factor
            assert len(layers) == len(set(layers)) == 30
        assert counts['target_contexts'] > 0
        ranks.append({'rank': installed['rank'], 'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'counts': dict(counts)})
    assert {r['rank'] for r in ranks} == {0, 1}
    assert ranks[0]['counts'] == ranks[1]['counts']
    per_head = operations(128, 128, 32)
    for rank in ranks:
        head_tokens = rank['counts']['eligible_token_layers'] * 16
        rank['eligible_head_token_layers'] = head_tokens
        rank['semantic_basic_flops'] = head_tokens * per_head['semantic_basic_flops']
        rank['source_tiled_basic_flops'] = head_tokens * per_head['source_tiled_basic_flops']
        rank['semantic_exp_evaluations'] = head_tokens
        rank['source_tiled_exp_evaluations'] = 4 * head_tokens
    return {'status': 'host_slot_eligible_recurrence_semantics', 'request_phase': phase, 'ranks': ranks, 'per_head_token': per_head, 'source_sha256': hashlib.sha256(KERNEL.read_bytes()).hexdigest(), 'model_effective_flops': None, 'attainment_percent': None, 'limitations': ['Slot eligibility is observed on the host, not independently read back from device.', 'Only recurrent verification core is covered; prefill, convolution, preprocessing and outer projections are excluded.', 'Basic scalar FLOPs count FMA as two, K-term reduction as K-1 additions; exp is separate, not assigned a FLOP cost.', 'Source-tiled count includes repeated query scaling across four value tiles; it is not a hardware instruction counter.', 'No replacement of uninstrumented performance or whole-model M01 pass is claimed.']}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = KERNEL.read_text()
    ast.parse(source)
    for expression in ('b_q = b_q * scale', 'b_h *= exp(b_g)', 'b_v -= tl.sum(b_h * b_k[:, None], 0)', 'b_v *= b_beta', 'b_h = tl.fma(b_k[:, None], b_v[None, :], b_h)', 'b_o = tl.sum(b_h * b_q[:, None], 0)', '32 if speculative else 64'):
        assert expression in source
    result = audit(ROOT, args.run)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))
if __name__ == '__main__':
    main()
