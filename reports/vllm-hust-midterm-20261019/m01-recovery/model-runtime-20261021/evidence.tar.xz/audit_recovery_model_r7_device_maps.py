"""Join actual device map snapshots to same-run forwards; keep padding separate."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_recovery_model_r7_gdn_publications import join
from await_gdn_maps import validate
from integrate_r16_hardware import classify
from recover_model_hardware import request_phase

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r7')


def extents(row):
    meta, maps = row['metadata'], row['device_maps']
    valid = meta['host_cu'][-1]
    mapped = not meta['decode_only']
    launched = len(maps['prefill_map']) + len(maps['verify_map']) if mapped else meta['tokens']
    assert 0 < valid <= launched
    return {'mapped': mapped, 'valid_rows': valid,
            'source_predicted_launch_rows': launched, 'padding_rows': launched - valid}


def main():
    receipt_path, result_path = RUN / 'receipt.json', RUN / 'mmlu-pro.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    phase = request_phase(receipt, json.loads(result_path.read_text()))
    paths = {receipt_path, result_path, Path(__file__).resolve()}
    paths.update(ROOT / name for name in ('audit_recovery_model_r7_gdn_publications.py', 'await_gdn_maps.py',
                 'await_gdn_publication.py', 'integrate_r16_hardware.py', 'recover_model_hardware.py'))
    ranks = []
    for export in receipt['gdn_publication_exports']:
        pid = export['pid']
        ready = RUN / f'gdn-publication-{pid}.ready'
        assert validate(RUN, ready) == export
        publication_path = ready.with_suffix('.json')
        capture_path = RUN / f'moe-deferred-{pid}.json'
        paths.update((ready, publication_path, capture_path))
        publication = json.loads(publication_path.read_text())
        capture = json.loads(capture_path.read_text())
        cohorts = {name: Counter() for name in ('inside_request_under_clock_tolerance', 'boundary_or_tail')}
        rows = []
        a, b = capture['anchor_host_bracket']
        for frame, pairs in join(capture['frames'], publication['records']):
            start = [a + frame['start_ms'] / 1000 - .002, b + frame['start_ms'] / 1000 + .002]
            end = [a + frame['end_ms'] / 1000 - .002, b + frame['end_ms'] / 1000 + .002]
            cohort = 'inside_request_under_clock_tolerance' if classify(start, end, phase) == 'inside' else 'boundary_or_tail'
            for group, record in pairs:
                row = extents(record)
                layers = len(group['layers'])
                rows.append({'slot': record['slot'], 'cohort': cohort, 'layers': layers, **row})
                cohorts[cohort]['publications'] += 1
                cohorts[cohort]['mapped_publications' if row['mapped'] else 'identity_publications'] += 1
                cohorts[cohort]['source_predicted_calls'] += layers * (2 if row['mapped'] else 1)
                for key in ('valid_rows', 'source_predicted_launch_rows', 'padding_rows'):
                    cohorts[cohort][key + '_layers'] += row[key] * layers
        ranks.append({'pid': pid, 'cohorts': cohorts, 'records': rows})
    assert len(ranks) == 2 and len({r['pid'] for r in ranks}) == 2
    result = {'status': 'actual_device_maps_validated_and_joined_to_same_run',
              'request_phase': phase, 'ranks': ranks,
              'model_effective_flops': None, 'm01_attainment': None,
              'limitations': ['Device map snapshots are observed; per-kernel launch counts remain source-predicted.',
                             'Decode-only maps are unused; only their shape is validated.',
                             'Window membership retains the 2 ms clock tolerance.',
                             'Padding is not useful F; full stream closure and model arithmetic coverage remain separate requirements.'],
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}}
    with (ROOT / 'recovery_model_r7-device-map-window.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{'pid': r['pid'], 'cohorts': r['cohorts']} for r in ranks], indent=2))


if __name__ == '__main__':
    main()
