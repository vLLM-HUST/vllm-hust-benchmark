"""Join host logits to adjacent device-timed forwards, without inventing stream identity."""
import hashlib
import json
from pathlib import Path

from integrate_r18_hardware import classify

ROOT = Path(__file__).resolve().parent
RUN = Path('/workspace/gennova-measurements/microflow-token-accounting-r18')


def verify_ready(path):
    ready = path.with_suffix('.ready')
    digest = ready.read_text().strip()
    assert len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
    assert digest == hashlib.sha256(path.read_bytes()).hexdigest()
    return ready


def join(frames, logits, replay):
    assert len(frames) == 2 * len(logits) == 2 * len(replay) and frames
    result = []
    for index, (target, draft) in enumerate(zip(frames[::2], frames[1::2], strict=True)):
        assert target['role'] == 'target' and draft['role'] == 'draft'
        observed, merged = logits[index], replay[index]
        assert target['host_end'] <= observed['wall'] <= draft['host_begin']
        assert draft['host_begin'] <= merged['wall'] <= draft['host_end']
        if index + 1 < len(logits):
            assert draft['host_end'] <= frames[2 * index + 2]['host_begin']
        assert type(observed['rows']) is int and observed['rows'] >= 0
        assert merged['batch_size'] == merged['first_step_sample_indices_rows']
        assert merged['batch_size'] == draft['fields']['draft_steps'][1]['actual_tokens']
        result.append({
            'index': index, 'target_logits_rows': observed['rows'],
            'draft_rows_per_step': merged['batch_size'],
            'target_forward_host_end': target['host_end'],
            'target_logits_host_call': observed['wall'],
            'draft_forward_host_begin': draft['host_begin'],
            'draft_replay_host_call': merged['wall'],
        })
    return result


def build():
    summary_path = ROOT / 'vocab-projection-summary-r18.json'
    summary = json.loads(summary_path.read_text())
    for name, digest in summary['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    phase = summary['request_phase']
    paths = [summary_path, Path(__file__), ROOT / 'integrate_r18_hardware.py']
    ranks = []
    for path in sorted(RUN.glob('moe-deferred-*.json')):
        pid = int(path.stem.removeprefix('moe-deferred-'))
        capture = json.loads(path.read_text())
        ready = verify_ready(path)
        trace = RUN / f'token-accounting-{pid}.jsonl'
        events = [json.loads(line) for line in trace.open()]
        rank = next(e['rank'] for e in events if e['event'] == 'observer_installed')
        selected = [e for e in events if phase['start_wall'] <= e['wall'] <= summary['host_selection_end']]
        records = join(capture['frames'],
                       [e for e in selected if e['event'] == 'target_logits_input'],
                       [e for e in selected if e['event'] == 'draft_replay_input'])
        a, b = capture['anchor_host_bracket']
        for record, target, draft in zip(records, capture['frames'][::2], capture['frames'][1::2], strict=True):
            start = [a + target['start_ms'] / 1000 - .002, b + target['start_ms'] / 1000 + .002]
            end = [a + draft['end_ms'] / 1000 - .002, b + draft['end_ms'] / 1000 + .002]
            record['adjacent_forward_device_envelope'] = {'start_wall_bounds': start, 'end_wall_bounds': end,
                                                          'classification': classify(start, end, phase)}
        expected = next(row for row in summary['ranks'] if row['rank'] == rank)
        assert sum(row['target_logits_rows'] for row in records) == expected['rows']['target']
        assert sum(row['draft_rows_per_step'] for row in records) == expected['rows']['draft_step0'] == expected['rows']['draft_step1']
        ranks.append({'rank': rank, 'pid': pid, 'records': records,
                      'inside_adjacent_forward_envelopes': sum(row['adjacent_forward_device_envelope']['classification'] == 'inside' for row in records)})
        paths.extend((path, ready, trace))
    assert {row['rank'] for row in ranks} == {0, 1}
    return {
        'status': 'host_logits_joined_to_adjacent_device_forward_envelopes',
        'ranks': ranks,
        'source_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        'target_logits_device_completion_verified': False,
        'model_effective_flops': None, 'm01_attainment': None,
        'limitations': [
            'Host enqueue order is verified. Current-stream identity across logits and adjacent forwards was not recorded.',
            'Adjacent device events do not independently time logits or prove every custom operator stream dependency.',
            'Inside classification inherits the existing 2 ms clock mapping tolerance; it is not a standalone logits device interval.',
            'No cross-run counts, new model run, cache reuse or historical evidence mutation.',
        ],
    }


if __name__ == '__main__':
    result = build()
    with (ROOT / 'r18-vocab-envelopes.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{'rank': r['rank'], 'cycles': len(r['records']),
                       'inside_adjacent_forward_envelopes': r['inside_adjacent_forward_envelopes']}
                      for r in result['ranks']]))
