"""Audit actual schema-v2 worker metadata, without assuming absent attributes."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5')


def summarize(inventory):
    assert inventory['schema_version'] == 3
    groups = {name: [] for name in ('rotary', 'routed', 'gated_norm', 'hidden_norm')}
    sources = inventory['source_sha256']
    for module in inventory['modules']:
        name, kind = module['name'], module['type']
        if name.endswith('.rotary_emb'):
            group = 'rotary'
        elif kind.endswith('.AscendRoutedExperts'):
            group = 'routed'
        elif kind.endswith('.AscendRMSNormGated'):
            group = 'gated_norm'
        elif kind.endswith('.AscendGemmaRMSNorm'):
            group = 'hidden_norm'
        else:
            continue
        entry = {key: module[key] for key in
                 ('name', 'type', 'scalars', 'class_source', 'methods', 'parameters', 'buffers')}
        entry['objects'] = module['objects']
        for obj in (module, *module['objects'].values()):
            identities = [obj['class_source'], *obj['methods'].values()]
            for item in identities:
                if item is not None:
                    assert item['file'] in sources
        groups[group].append(entry)
    return groups


def requirements(groups, role):
    expected = {'routed': 40 if role == 'target' else 1,
                'gated_norm': 30 if role == 'target' else 0,
                'hidden_norm': 101 if role == 'target' else 7}
    issues = []
    # named_modules deduplicates shared cached rotary modules.
    if len(groups['rotary']) not in ({1, 10} if role == 'target' else {1}):
        issues.append(f"{role}.rotary: unexpected distinct instance count {len(groups['rotary'])}")
    for name, count in expected.items():
        if len(groups[name]) != count:
            issues.append(f'{role}.{name}: expected {count}, observed {len(groups[name])}')
    for row in groups['rotary']:
        if row['scalars'].get('rotary_dim') != 64:
            issues.append(f"{row['name']}: rotary_dim=64 not established")
    for row in groups['routed']:
        scalar = row['scalars']
        if scalar.get('top_k') != 8:
            issues.append(f"{row['name']}: top_k=8 not established")
        activation = scalar.get('activation')
        if not (activation == 'silu' or isinstance(activation, dict)
                and activation.get('name') == 'SILU'):
            issues.append(f"{row['name']}: SiLU activation not established")
        router = row['objects'].get('router')
        if not router or not router['class_source'] or '_select_experts' not in router['methods']:
            issues.append(f"{row['name']}: actual router implementation identity missing")
    for row in groups['gated_norm']:
        if row['scalars'].get('norm_before_gate') is not True:
            issues.append(f"{row['name']}: norm-before-gate not established")
    return issues


def build():
    receipt_path = RUN / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    assert receipt['bench_exit_code'] == 0
    traces = sorted(RUN.glob('token-accounting-*.jsonl'))
    assert len(traces) == 2
    ranks, pins = [], {}
    for path in traces:
        inventory, rank = None, None
        for line in path.open():
            event = json.loads(line)
            if event['event'] == 'loaded_model_inventory':
                assert inventory is None
                inventory = event
            elif event['event'] == 'observer_installed':
                assert rank is None
                rank = event['rank']
        assert inventory is not None
        groups, issues = {}, []
        for role in ('target', 'draft'):
            for name, digest in inventory[role]['source_sha256'].items():
                assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
                assert pins.get(name, digest) == digest
                pins[name] = digest
            groups[role] = summarize(inventory[role])
            issues.extend(requirements(groups[role], role))
        ranks.append({'rank': rank, 'trace': str(path), 'groups': groups, 'missing_or_different': issues})
    assert {r['rank'] for r in ranks} == {0, 1}
    source_paths = [receipt_path, Path(__file__), *traces]
    return {
        'status': 'loaded_configuration_recovered' if all(not r['missing_or_different'] for r in ranks)
                  else 'loaded_configuration_partially_recovered',
        'ranks': ranks, 'loaded_source_sha256': pins,
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},
        'model_effective_flops': None, 'm01_attainment': None,
        'limitations': [
            'Configuration and implementation identity captured after model load, not device operation counts.',
            'named_modules deduplicates shared modules; rotary entries count distinct objects, not per-layer invocations or alias assignments.',
            'No attributes are retroactively inserted into r17 or other historical inventories.',
            'Tensor values were not read; source hashes do not establish fused-kernel numerical equivalence.',
            'Actual request counts and hardware coverage require separate recovery_model_r5 audits.',
        ],
    }


if __name__ == '__main__':
    result = build()
    with (ROOT / 'recovery_model_r5-loaded-configuration.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'ranks': [
        {'rank': r['rank'], 'groups': {role: {k: len(v) for k, v in groups.items()}
                                     for role, groups in r['groups'].items()},
         'missing_or_different': r['missing_or_different']} for r in result['ranks']]}, indent=2))
