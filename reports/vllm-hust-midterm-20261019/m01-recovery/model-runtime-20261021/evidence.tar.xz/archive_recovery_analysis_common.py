"""Collect local Python import dependencies for both recovery analysis runs."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = Path('/workspace/m01-analysis-common-20261021.tar.gz')
paths = set()
for pattern in ['*recovery_model_r5*.py', '*recovery_model_r7*.py',
                'prepare_recovery*analysis*.py', 'run_recovery_analysis*.py']:
    paths.update(ROOT.glob(pattern))
paths.add(Path(__file__))
pending = list(paths)
while pending:
    path = pending.pop()
    tree = ast.parse(path.read_text())
    modules = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            modules.append(node.module)
    for module in modules:
        candidate = ROOT / (module.replace('.', '/') + '.py')
        if candidate.is_file() and candidate not in paths:
            paths.add(candidate)
            pending.append(candidate)
members = {}
with tarfile.open(ARCHIVE, 'x:gz') as archive:
    for path in sorted(paths):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        name = str(path.relative_to(ROOT))
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), 0o644
        archive.addfile(info, io.BytesIO(data))
        members[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for member in archive.getmembers():
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == members[member.name]['sha256']
result = dict(archive=ARCHIVE.name, bytes=ARCHIVE.stat().st_size,
              sha256=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
              members=members, member_verification='all_members_passed',
              scope='Local Python import closure; original raw measurements remain in their separate immutable archives.')
(ROOT / 'recovery-analysis-common-archive.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'members'}))
