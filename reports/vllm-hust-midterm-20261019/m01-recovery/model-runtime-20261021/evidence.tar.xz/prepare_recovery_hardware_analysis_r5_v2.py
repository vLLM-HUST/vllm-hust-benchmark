"""Retain valid intervals while explicitly rejecting incomplete counter windows."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'integrate_recovery_model_r5_hardware.py').read_text()
source = source.replace('            assert has_complete_hbm_coverage(values), window["name"]',
                        '            values["complete_coverage"] = has_complete_hbm_coverage(values)')
source = source.replace('        window["hccs"] = link_bounds(rows, start, end)',
    '        window["hbm_coverage_complete"] = all(d["complete_coverage"] for d in window["hbm_devices"])\n'
    '        if not window["hbm_coverage_complete"]:\n'
    '            window["observed_hbm_bytes_in_incomplete_window"] = window["hbm_bytes"]\n'
    '            window["hbm_bytes"] = None\n'
    '        window["hccs"] = link_bounds(rows, start, end)')
source = source.replace('"status": "same_run_named_interval_counter_coverage_verified",',
    '"status": ("same_run_named_interval_counter_coverage_verified" if all(w["hbm_coverage_complete"] for w in windows)\n'
    '                   else "partial_interval_coverage_not_full_m01"),')
source = source.replace('"integrate_recovery_model_r5_hardware.py", "integrate_r12_hardware.py",',
    '"integrate_recovery_model_r5_hardware_v2.py", "prepare_recovery_hardware_analysis_r5_v2.py",\n'
    '        "integrate_recovery_model_r5_hardware.py", "integrate_r12_hardware.py",')
ast.parse(source)
with (ROOT / 'integrate_recovery_model_r5_hardware_v2.py').open('x') as stream:
    stream.write(source)
