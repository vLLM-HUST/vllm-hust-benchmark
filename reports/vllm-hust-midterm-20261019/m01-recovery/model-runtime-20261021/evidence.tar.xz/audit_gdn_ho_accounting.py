"""Useful H/O and prefix-scan arithmetic from manifest-linked source and r9."""

from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_gdn_host_schedule import validate
from audit_token_accounting import request_phase

ROOT = Path(__file__).resolve().parent


def operations(n, has_state, k=128, v=128):
    if not 1 <= n <= 64 or k < 1 or v < 1 or not isinstance(has_state, bool):
        raise ValueError("invalid chunk or state")
    pairs = n * (n + 1) // 2
    return {
        "prefix_scan_add": n - 1,
        "h_wh_dot": 2 * n * k * v if has_state else 0,
        "h_value_residual_subtract": n * v if has_state else 0,
        "h_decay_difference": n,
        "h_value_decay_multiply": n * v,
        "h_kv_dot": 2 * k * v * n,
        "h_state_decay_and_add": 2 * k * v if has_state else 0,
        "o_qk_causal_dot": 2 * k * pairs,
        "o_gate_difference_and_multiply": 2 * pairs,
        "o_qh_dot": 2 * n * k * v if has_state else 0,
        "o_av_causal_dot": 2 * v * pairs,
        "o_state_decay_and_add": 2 * n * v if has_state else 0,
        "o_output_scale": n * v,
        "exp_evaluations": n + pairs + (n + 1 if has_state else 0),
        "clamp_comparisons": pairs,
    }


def main():
    run = ROOT / "microflow-token-accounting-r9"
    receipt = json.loads((run / "receipt.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, json.loads((run / "mmlu-pro.json").read_text()))
    ranks = []
    for path in sorted(run.glob("token-accounting-*.jsonl")):
        events = list(map(json.loads, path.read_text().splitlines()))
        rank = next(e["rank"] for e in events if e["event"] == "observer_installed")
        hist, totals = Counter(), Counter()
        for e in events:
            if e["event"] != "forward_enter" or e["role"] != "target":
                continue
            if not phase["start_wall"] <= e["wall"] <= phase["end_wall"]:
                continue
            for group in e["owned_gdn"]:
                validate(group, e["actual_tokens"])
                if group["decode_only"]:
                    continue
                factor = len(group["layers"])
                for i, (a, b) in enumerate(zip(group["cu"], group["cu"][1:])):
                    if i in group["verify_ids"]:
                        continue
                    for offset in range(0, b - a, 64):
                        n = min(64, b - a - offset)
                        state = bool(group["initial"][i]) or offset > 0
                        hist[n, state] += factor
                        totals.update({name: value * factor * 16 for name, value in operations(n, state).items()})
        ranks.append({
            "rank": rank, "trace": path.name, "trace_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "chunk_catalog": [{"length": n, "has_state": s, "chunk_layers": c} for (n, s), c in sorted(hist.items())],
            "operations": dict(totals),
            "basic_arithmetic_subtotal": sum(v for k, v in totals.items() if k not in ("exp_evaluations", "clamp_comparisons")),
        })
    assert {r["rank"] for r in ranks} == {0, 1}
    assert ranks[0]["chunk_catalog"] == ranks[1]["chunk_catalog"]
    source_root = ROOT / "gdn-native-source-r8"
    source_receipt = json.loads((source_root / "source-receipt.json").read_text())
    for name, digest in source_receipt["source_sha256"].items():
        assert hashlib.sha256((source_root / name).read_bytes()).hexdigest() == digest
    output = {
        "status": "manifest_linked_source_host_derived_ho_scan_arithmetic",
        "request_phase": phase, "ranks": ranks,
        "source_receipt_sha256": hashlib.sha256((source_root / "source-receipt.json").read_bytes()).hexdigest(),
        "scan_source_sha256": hashlib.sha256((ROOT / "payload/betterscale/models/qwen35/mixed_layout.py").read_bytes()).hexdigest(),
        "basic_arithmetic_subtotal": sum(r["basic_arithmetic_subtotal"] for r in ranks),
        "model_effective_flops": None, "attainment_percent": None,
        "limitations": [
            "Matrix products retain 2 operations per multiply-accumulate, including causal diagonal; vector arithmetic counts 1 per scalar operation.",
            "First chunk with no initial state omits state-dependent zero products; later chunks and cached initial states are retained.",
            "Prefix scan uses n-1 semantic additions, not physical parallel-scan instruction counts.",
            "Mask construction, padding, duplicate sub-block work and structural-zero state operations are excluded.",
            "Unit decay factors and zero gate differences on live diagonal entries remain under the stated source-operation convention.",
            "Exp and clamp comparisons are separate; no arbitrary FLOP equivalents are assigned.",
            "CPU tests validate real-arithmetic chunk equations, not BF16 device rounding equivalence.",
            "Native source is manifest-linked, not a reproducible binary build proof; no device FLOP counter or full-model attainment is claimed.",
        ],
    }
    with (ROOT / "gdn-ho-accounting-r9.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"basic_arithmetic_subtotal": output["basic_arithmetic_subtotal"],
                      "ranks": [{k: v for k, v in r.items() if k != "chunk_catalog"} for r in ranks]}, indent=2))


if __name__ == "__main__":
    main()
