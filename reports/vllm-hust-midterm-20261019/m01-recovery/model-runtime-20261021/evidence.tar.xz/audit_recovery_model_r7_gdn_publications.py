"""Join device-final publications to the actual enclosing recovery_model_r7 model workload."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from await_gdn_maps import validate
from recover_model_hardware import request_phase
from integrate_r16_hardware import classify

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r7')


def join(frames, records):
    used = set()
    output = []
    for frame in frames:
        if frame['role'] == 'draft':
            assert not frame['fields']['owned_gdn']
            continue
        matched = []
        for group in frame['fields']['owned_gdn']:
            candidates = [r for r in records if r['slot'] not in used
                          and r['metadata']['core_object_id'] == group['core_object_id']
                          and r['host_enqueue_end_wall'] <= frame['host_begin']]
            assert len(candidates) == 1, 'Missing or ambiguous final device publication'
            record = candidates[0]
            meta = record['metadata']
            assert meta['tokens'] == frame['fields']['padded_tokens']
            assert meta['host_cu'] == group['cu']
            assert meta['verify_ids'] == group['verify_ids']
            used.add(record['slot'])
            matched.append((group, record))
        assert sum(len(group['layers']) for group, record in matched) == 30
        output.append((frame, matched))
    assert len(used) == len(records), 'Unmatched final device publication'
    return output


def count(group, record):
    fields, meta = record['device_fields'], record['metadata']
    cu = [row[0] for row in fields['cu']]
    lengths = [b - a for a, b in zip(cu, cu[1:])]
    assert all(length > 0 for length in lengths)
    result = Counter(publications=1, valid_tokens=sum(lengths))
    for i in meta['prefill_ids']:
        result['prefill_tokens'] += lengths[i]
    for j, i in enumerate(meta['verify_ids']):
        slots = fields['verify_slots'][j]
        conv = fields['verify_conv'][i][0]
        if slots[0] < 0:
            assert slots == [-1, -1, -1] and conv == -1
            result['device_skipped_verify_tokens'] += lengths[i]
        else:
            assert slots == [3 * conv + k for k in range(3)] and conv >= 0
            result['device_active_verify_tokens'] += lengths[i]
        result['distinct_feedback_rows'] += int(fields['accepted'][i][0] != fields['verify_accepted'][j][0])
        if group['verify_slots'][j] != slots:
            result['host_device_slot_difference_rows'] += 1
    assert result['valid_tokens'] == result['prefill_tokens'] + result['device_active_verify_tokens'] + result['device_skipped_verify_tokens']
    factor = len(group['layers'])
    for name in ('prefill_tokens', 'device_active_verify_tokens', 'device_skipped_verify_tokens'):
        result[name + '_layers'] = result[name] * factor
    return result


def main():
    receipt_path = RUN / 'receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    result_path = RUN / 'mmlu-pro.json'
    phase = request_phase(receipt, json.loads(result_path.read_text()))
    paths = [receipt_path, result_path, Path(__file__), ROOT / 'await_gdn_publication.py', ROOT / 'await_gdn_maps.py',
             ROOT / 'recover_model_hardware.py', ROOT / 'integrate_r16_hardware.py']
    ranks = []
    for export in receipt['gdn_publication_exports']:
        pid = export['pid']
        ready_path = RUN / f'gdn-publication-{pid}.ready'
        assert validate(RUN, ready_path) == export
        publication_path = ready_path.with_suffix('.json')
        publication = json.loads(publication_path.read_text())
        capture_path = RUN / f'moe-deferred-{pid}.json'
        capture = json.loads(capture_path.read_text())
        cohorts = {name: Counter() for name in ('inside_request_under_clock_tolerance', 'boundary_or_tail')}
        for frame, pairs in join(capture['frames'], publication['records']):
            a, b = capture['anchor_host_bracket']
            start = [a + frame['start_ms'] / 1000 - .002, b + frame['start_ms'] / 1000 + .002]
            end = [a + frame['end_ms'] / 1000 - .002, b + frame['end_ms'] / 1000 + .002]
            name = 'inside_request_under_clock_tolerance' if classify(start, end, phase) == 'inside' else 'boundary_or_tail'
            for group, record in pairs:
                cohorts[name].update(count(group, record))
        ranks.append({'pid': pid, 'cohorts': cohorts})
        paths.extend((ready_path, publication_path, capture_path))
    assert len(ranks) == 2
    output = {'status': 'device_final_gdn_publications_joined_to_recovery_model_r7_forwards', 'request_phase': phase,
              'ranks': ranks, 'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              'model_effective_flops': None, 'm01_attainment': None,
              'limitations': ['Per-rank event membership remains conditional on 2 ms mapping tolerance.',
                              'Device metadata is observed, not full state tensor contents or model quality.',
                              'Diagnostic copies are included in this run; not replacement B1 performance.']}
    with (ROOT / 'recovery_model_r7-gdn-publication-summary.json').open('x') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps(ranks, indent=2))


if __name__ == '__main__':
    main()
