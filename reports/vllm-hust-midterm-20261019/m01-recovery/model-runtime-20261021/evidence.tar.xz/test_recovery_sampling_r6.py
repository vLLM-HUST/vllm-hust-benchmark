import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_only_sampling_duration_changed():
    old = (ROOT / 'sample_system_hardware_r23.sh').read_text()
    assert (ROOT / 'sample_system_hardware_recovery_r6.sh').read_text() == old.replace('--sys-period=240', '--sys-period=360')


def test_model_and_client_unchanged():
    old = (ROOT / 'measure_model_recovery_r5.py').read_text()
    expected = old.replace('collect_model_recovery_r1.py', 'collect_model_recovery_r2.py').replace(
        'model-recovery-controller-r5.json', 'model-recovery-controller-r6.json').replace(
        'collector.wait(timeout=600)', 'collector.wait(timeout=900)')
    assert (ROOT / 'measure_model_recovery_r6.py').read_text() == expected
    build = json.loads((ROOT / 'model-recovery-controller-r6.json').read_text())
    for name in ['launch_model_recovery_r1.py', 'bench-model-recovery-r1.sh', 'runtime-gdn-recovery-r2.sh']:
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == build['files'][name]


def test_partial_interval_never_exposes_full_hbm_total():
    raw = json.loads((ROOT / 'recovery_model_r5-hardware.json').read_text())
    assert raw['status'] == 'partial_interval_coverage_not_full_m01'
    assert raw['model_effective_flops'] is None and raw['m01_attainment'] is None
    assert [window['hbm_coverage_complete'] for window in raw['windows']] == [True, True, False]
    assert raw['windows'][-1]['hbm_bytes'] is None
