"""Source-derived KKT/WY useful arithmetic, excluding inverse and padding."""

from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_gdn_host_schedule import validate
from audit_token_accounting import request_phase

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "microflow-token-accounting-r9"
SOURCE_FILES = (
    "payload/betterscale/models/qwen35/chunk_layout.py",
    "payload/betterscale/models/qwen35/wy_head_major.py",
    "runtime/vllm_ascend/device/device_op.py",
    "runtime/vllm_ascend/ops/triton/fla/chunk_scaled_dot_kkt.py",
)


def arithmetic(n, width=128):
    if not isinstance(n, int) or not 1 <= n <= 64:
        raise ValueError("valid chunk length must be in [1, 64]")
    strict = n * (n - 1) // 2
    inclusive = n * (n + 1) // 2
    # Same 2-MNK convention as the existing matrix catalog; SFUs stay separate.
    return {
        "kkt_dot": 2 * width * strict,
        "kkt_gate_difference_and_scaling": 3 * strict,
        "wy_value_beta": n * width,
        "wy_key_beta_gate": 2 * n * width,
        "wy_lower_triangular_dot": 4 * width * inclusive,
        "exp_evaluations": strict + n,
    }


def collect(events, start, end):
    histogram = Counter()
    contexts = 0
    for event in events:
        if event["event"] != "forward_enter" or event["role"] != "target":
            continue
        if not start <= event["wall"] <= end:
            continue
        groups = event["owned_gdn"]
        assert sum(len(g["layers"]) for g in groups) == 30
        mixed = False
        for group in groups:
            validate(group, event["actual_tokens"])
            if group["decode_only"]:
                continue
            mixed = True
            for a, b in zip(group["prefill_cu"], group["prefill_cu"][1:]):
                for offset in range(0, b - a, 64):
                    histogram[min(64, b - a - offset)] += len(group["layers"])
        contexts += int(mixed)
    return histogram, contexts


def main():
    receipt = json.loads((RUN / "receipt.json").read_text())
    result = json.loads((RUN / "mmlu-pro.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, result)
    ranks = []
    for path in sorted(RUN.glob("token-accounting-*.jsonl")):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        rank = next(e["rank"] for e in events if e["event"] == "observer_installed")
        hist, contexts = collect(events, phase["start_wall"], receipt["bench_ended_wall"])
        totals = {
            key: sum(arithmetic(n)[key] * count * 16 for n, count in hist.items())
            for key in arithmetic(1)
        }
        ranks.append({
            "rank": rank, "trace_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "mixed_contexts": contexts, "chunk_token_layers_histogram": dict(sorted(hist.items())),
            "prefill_token_layers": sum(n * count for n, count in hist.items()),
            "operations": totals,
            "basic_arithmetic_subtotal": sum(v for k, v in totals.items() if k != "exp_evaluations"),
        })
    assert {r["rank"] for r in ranks} == {0, 1}
    assert ranks[0]["operations"] == ranks[1]["operations"]
    output = {
        "status": "source_derived_useful_kkt_wy_partial_catalog",
        "request_phase": phase, "ranks": ranks,
        "source_sha256": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in SOURCE_FILES},
        "basic_arithmetic_subtotal": sum(r["basic_arithmetic_subtotal"] for r in ranks),
        "model_effective_flops": None, "attainment_percent": None,
        "convention": "2 operations per matrix multiply-accumulate, including unit diagonal; scalar add/multiply/subtract count 1; exp separate.",
        "limitations": [
            "Host schedule and pinned source derivation, not device arithmetic counters.",
            "Only target mixed-prefill KKT and WY; no inverse, cumulative gates, H/O, convolution or normalization.",
            "Masked upper triangles and padded token rows excluded; this is not physical executed FLOPs.",
            "WY unit diagonal is counted under the existing 2-MNK convention, not algebraically eliminated.",
            "SFU exp costs are not assigned an arbitrary FLOP equivalent.",
            "No full-model F or acceptance decision follows from this partial catalog.",
        ],
    }
    with (ROOT / "gdn-wy-accounting-r9.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
