"""Derive independent same-run analyses without editing any historical ledger."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = [
    'integrate_r21_hardware.py', 'derive_r21_attention_window.py',
    'derive_r21_matrix.py', 'audit_r21_gdn_publications.py',
    'derive_r21_device_gdn.py', 'derive_r21_gdn_prefill.py',
    'derive_r21_norm.py', 'derive_r21_softmax.py', 'derive_r21_scalar.py',
    'derive_r21_gdn_preprocess.py', 'audit_r21_logits.py',
    'derive_r21_vocab_window.py', 'audit_vocab_projection_r21.py',
    'audit_r21_device_maps.py', 'audit_r21_inventory.py',
    'assemble_r21_accounted_families.py',
]


def main():
    pins = {}
    for name in FILES:
        original = (ROOT / name).read_text()
        text = original.replace('/workspace/gennova-measurements/microflow-token-accounting-r21',
                                str(ROOT / 'm01-recovery-model-r4'))
        text = text.replace('r21', 'recovery_model_r4')
        if name == 'integrate_r21_hardware.py':
            text = text.replace('control = ROOT / "recovery_model_r4-system-control"', 'control = RUN / "system"')
            text = text.replace('system["sampler_errors"]', 'system["errors"]')
            text = text.replace('    assert system["workload_receipt_sha256"] == sha(receipt_path)\n',
                                '    assert system["run"] == str(RUN)\n')
            text = text.replace('Path(system["profile_root"])', '(control / "profiler")')
        ast.parse(text)
        target = name.replace('r21', 'recovery_model_r4')
        with (ROOT / target).open('x') as stream:
            stream.write(text)
        pins[name] = hashlib.sha256(original.encode()).hexdigest()
        pins[target] = hashlib.sha256(text.encode()).hexdigest()
    with (ROOT / 'recovery-analysis-build-r4.json').open('x') as stream:
        json.dump(dict(run=str(ROOT / 'm01-recovery-model-r4'), source_sha256=pins,
                       old_measurement_imported=False, model_effective_flops=None,
                       m01_attainment=None), stream, indent=2)
        stream.write('\n')
    print(f'Prepared {len(FILES)} same-run analysis modules; not executed.')


if __name__ == '__main__':
    main()
