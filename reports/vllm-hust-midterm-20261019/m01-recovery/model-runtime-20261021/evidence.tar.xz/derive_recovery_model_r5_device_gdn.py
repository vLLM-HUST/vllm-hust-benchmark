"""Count recurrence and convolution using device-final eligibility and state flags."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_conv_accounting import operations as convolution
from audit_gdn_recurrence_r9 import operations as recurrence
from audit_recovery_model_r5_gdn_publications import join
from integrate_recovery_model_r5_hardware import classify

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5')


def operations(group, record):
    meta, fields = record['metadata'], record['device_fields']
    cu = [row[0] for row in fields['cu']]
    lengths = [b - a for a, b in zip(cu, cu[1:])]
    factor = len(group['layers'])
    counts = Counter()
    for j, i in enumerate(meta['prefill_ids']):
        initial = fields['initial'][i][0]
        assert type(initial) is bool
        assert fields['prefill_state'][j][1] == int(initial)
        assert fields['prefill_conv'][i][0] >= 0
        counts.update({key: value * factor for key, value in convolution(lengths[i], initial).items()})
        counts['prefill_token_layers'] += lengths[i] * factor
    for j, i in enumerate(meta['verify_ids']):
        assert 1 <= fields['accepted'][i][0] <= 3
        assert 1 <= fields['verify_accepted'][j][0] <= 3
        if fields['verify_slots'][j][0] < 0:
            assert fields['verify_slots'][j] == [-1, -1, -1]
            assert fields['verify_conv'][i][0] == -1
            counts['skipped_verify_token_layers'] += lengths[i] * factor
            continue
        counts['active_verify_token_layers'] += lengths[i] * factor
        counts.update({key: value * factor for key, value in convolution(lengths[i], True).items()})
        head_tokens = lengths[i] * factor * 16
        counts['recurrent_basic_arithmetic'] += head_tokens * recurrence(128, 128, 32)['semantic_basic_flops']
        counts['recurrent_exp_evaluations'] += head_tokens
    return counts


def main():
    summary_path = ROOT / 'recovery_model_r5-gdn-publication-summary.json'
    summary = json.loads(summary_path.read_text())
    for path, expected in summary['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
    paths = [summary_path, Path(__file__), ROOT / 'audit_conv_accounting.py',
             ROOT / 'audit_gdn_recurrence_r9.py', ROOT / 'audit_recovery_model_r5_gdn_publications.py',
             ROOT / 'integrate_recovery_model_r5_hardware.py']
    ranks = []
    for expected in summary['ranks']:
        pid = expected['pid']
        trace = RUN / f'token-accounting-{pid}.jsonl'
        with trace.open() as stream:
            inventory = next(json.loads(line) for line in stream if '"event": "loaded_model_inventory"' in line)
        modules = inventory['target']['modules']
        heads = [m for m in modules if m['name'].endswith('.linear_attn')]
        convs = [m for m in modules if m['name'].endswith('.linear_attn.conv1d')]
        assert len(heads) == len(convs) == 30
        for module in heads:
            assert all(module['scalars'][key] == value for key, value in
                       {'tp_size': 2, 'head_k_dim': 128, 'head_v_dim': 128, 'num_v_heads': 32}.items())
        assert all(m['parameters']['weight']['shape'] == [4096, 1, 4]
                   and m['parameters']['weight']['dtype'] == 'torch.bfloat16' for m in convs)
        capture_path = RUN / f'moe-deferred-{pid}.json'
        publication_path = RUN / f'gdn-publication-{pid}.json'
        capture, publication = [json.loads(p.read_text()) for p in (capture_path, publication_path)]
        cohorts = {name: Counter() for name in expected['cohorts']}
        for frame, pairs in join(capture['frames'], publication['records']):
            a, b = capture['anchor_host_bracket']
            start = [a + frame['start_ms'] / 1000 - .002, b + frame['start_ms'] / 1000 + .002]
            end = [a + frame['end_ms'] / 1000 - .002, b + frame['end_ms'] / 1000 + .002]
            name = 'inside_request_under_clock_tolerance' if classify(start, end, summary['request_phase']) == 'inside' else 'boundary_or_tail'
            for group, record in pairs:
                cohorts[name].update(operations(group, record))
        for name, counts in cohorts.items():
            reference = expected['cohorts'][name]
            assert counts['active_verify_token_layers'] == reference.get('device_active_verify_tokens_layers', 0)
            assert counts['skipped_verify_token_layers'] == reference.get('device_skipped_verify_tokens_layers', 0)
            counts['convolution_basic_arithmetic'] = counts['convolution_multiply'] + counts['convolution_add']
        ranks.append({'pid': pid, 'cohorts': cohorts})
        paths.extend((trace, capture_path, publication_path))
    assert ranks[0]['cohorts'] == ranks[1]['cohorts']
    output = {'status': 'device_eligible_recovery_model_r5_recurrence_and_convolution_semantic_ledger',
              'request_phase': summary['request_phase'], 'ranks': ranks,
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
              'model_effective_flops': None, 'm01_attainment': None,
              'limitations': ['Per-rank counts; sum TP shards once, do not multiply global head count twice.',
                              'Semantic operations, not physical padded instructions or full effective F.',
                              'SiLU and exp remain separate categories; full GDN prefill and other families are excluded.',
                              'Matched state-access component reference remains to be measured.']}
    with (ROOT / 'recovery_model_r5-device-gdn-ledger.json').open('x') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps(ranks, indent=2))


if __name__ == '__main__':
    main()
