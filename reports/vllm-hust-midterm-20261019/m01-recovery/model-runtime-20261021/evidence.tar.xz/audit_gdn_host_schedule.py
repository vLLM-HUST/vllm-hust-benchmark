"""Reconstruct and verify GDN grouping/chunk descriptors from live host views."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_token_accounting import request_phase

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "microflow-token-accounting-r7"


def lengths(cumulative):
    assert cumulative and cumulative[0] == 0
    values = [b-a for a, b in zip(cumulative, cumulative[1:])]
    assert all(value > 0 for value in values)
    return values


def validate(group, actual_tokens):
    q = lengths(group["cu"])
    assert len(q) == group["live"]
    assert sum(q) == actual_tokens
    assert actual_tokens <= group["capacity"] == group["tokens"]
    ids = group["verify_ids"]
    assert len(ids) == group["verify_count"] and len(set(ids)) == len(ids)
    assert all(0 <= index < len(q) for index in ids)
    assert all(q[index] <= group["width"] for index in ids)
    verify_tokens = sum(q[index] for index in ids)
    if group["decode_only"]:
        assert ids == list(range(len(q)))
        return {"decode_only": True, "prefill_tokens": 0,
                "verify_tokens": verify_tokens, "chunks": {}}
    pre = [value for index, value in enumerate(q) if index not in set(ids)]
    assert pre and lengths(group["prefill_cu"]) == pre
    assert lengths(group["verify_cu"]) == [q[index] for index in ids]
    assert len(group["initial"]) == len(q)
    chunks = {}
    for raw_size, indices in group["chunk_indices"].items():
        size = int(raw_size)
        assert size > 0
        expected = [[index, chunk] for index, count in enumerate(pre)
                    for chunk in range((count+size-1)//size)]
        assert indices == expected
        chunks[raw_size] = len(indices)
    return {"decode_only": False, "prefill_tokens": sum(pre),
            "verify_tokens": verify_tokens, "chunks": chunks}


def main():
    receipt = json.loads((RUN / "receipt.json").read_text())
    result = json.loads((RUN / "mmlu-pro.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    assert result["completed"] == 200 and result["failed"] == 0
    phase = request_phase(receipt, result)
    ranks = []
    for path in sorted(RUN.glob("token-accounting-*.jsonl")):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        installed = next(e for e in events if e["event"] == "observer_installed")
        assert installed["observer_sha256"] == receipt["input_hashes"][
            "token-observer-v6/hust_token_observer/__init__.py"]
        counters, chunks = Counter(), Counter()
        for event in events:
            if event["event"] != "forward_enter" or not (
                phase["start_wall"] <= event["wall"] <= receipt["bench_ended_wall"]
            ):
                continue
            if event["role"] == "draft":
                assert event["owned_gdn"] == []
                continue
            groups = event["owned_gdn"]
            assert len(groups) == 1 and len(groups[0]["layers"]) == 30
            data = validate(groups[0], event["actual_tokens"])
            counters["contexts"] += 1
            counters["decode_only_contexts" if data["decode_only"] else "mixed_contexts"] += 1
            counters["actual_tokens"] += event["actual_tokens"]
            counters["prefill_tokens"] += data["prefill_tokens"]
            counters["verify_tokens"] += data["verify_tokens"]
            for size, count in data["chunks"].items():
                chunks[size] += count
        assert counters["contexts"] > 0
        assert counters["actual_tokens"] == counters["prefill_tokens"] + counters["verify_tokens"]
        ranks.append({"rank": installed["rank"], "counts": dict(counters),
                      "prefill_chunks_by_size": dict(chunks),
                      "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    assert {r["rank"] for r in ranks} == {0, 1}
    assert ranks[0]["counts"] == ranks[1]["counts"]
    assert ranks[0]["prefill_chunks_by_size"] == ranks[1]["prefill_chunks_by_size"]
    output = {
        "status": "owned_gdn_host_schedule_reconstructed",
        "ranks": ranks, "request_phase": phase, "completed": 200, "failed": 0,
        "model_effective_flops": None,
        "limitations": [
            "Counts describe one common scheduling pattern across 30 GDN layers; they are not multiplied by layer aliases.",
            "Host chunk descriptors are not hardware instruction counters.",
            "Custom recurrence/chunk arithmetic and workload-matched reference still require accounting.",
            "No uninstrumented performance replacement or M01 attainment is claimed.",
        ],
    }
    with (ROOT / "gdn-host-summary-r7.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
