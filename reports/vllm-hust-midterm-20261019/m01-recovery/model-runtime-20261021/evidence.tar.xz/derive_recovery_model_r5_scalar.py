"""Disjoint RoPE, MoE and attention-gate semantics from recovery_model_r5 loaded configuration."""
import hashlib
import json
from pathlib import Path

from audit_moe_scalar_sources import scalar_counts
from audit_rope_reference import rope_operations
from audit_router_gate_reference import router_counts

ROOT = Path(__file__).resolve().parent


def validate_groups(groups):
    for role in ('target', 'draft'):
        group = groups[role]
        assert len(group['routed']) == (40 if role == 'target' else 1)
        assert group['rotary']
        assert all(row['scalars']['rotary_dim'] == 64 for row in group['rotary'])
        for row in group['routed']:
            scalar = row['scalars']
            assert scalar['top_k'] == 8 and scalar['hidden_size'] == 2048
            assert scalar['intermediate_size_per_partition'] == 256
            assert scalar['activation']['name'] == 'SILU'
            assert scalar['apply_router_weight_on_input'] is False
            assert scalar['renormalize'] is True
            assert scalar['routed_scaling_factor'] == 1.0
            assert scalar['scoring_func'] == 'softmax'
            router = row['objects']['router']
            assert router['type'].endswith('.AscendFusedTopKRouter')
            assert router['scalars']['top_k'] == 8
            assert router['scalars']['renormalize'] is True
            assert router['scalars']['scoring_func'] == 'softmax'


def operations(target, draft):
    if any(type(value) is not int or value < 0 for value in (target, draft)):
        raise ValueError('Nonnegative integer token extents required')
    moe_layers = 40 * target + draft
    attention_layers = 10 * target + draft
    moe = scalar_counts(moe_layers)
    router = router_counts(moe_layers)
    rope = rope_operations(attention_layers, heads=18, rotary_dim=64)
    gate = attention_layers * 4096
    return {
        'target_valid_rows': target, 'draft_valid_rows': draft,
        'moe_token_layers': moe_layers, 'attention_token_layers': attention_layers,
        'moe_basic': moe, 'router_basic': router['basic'], 'rope_basic': rope,
        'attention_gate_multiply': gate,
        'basic_subtotal': sum(moe.values()) + sum(router['basic'].values()) + sum(rope.values()) + gate,
        'separate': {
            'moe_silu': moe['routed_swiglu_outer_multiply'] + moe['shared_swiglu_outer_multiply'],
            'shared_gate_sigmoid': moe_layers, 'attention_gate_sigmoid': gate,
            **{f'router_{name}': count for name, count in router['separate'].items()},
        },
    }


def build():
    config_path = ROOT / 'recovery_model_r5-loaded-configuration.json'
    matrix_path = ROOT / 'recovery_model_r5-matrix-accounting.json'
    config, matrix = [json.loads(path.read_text()) for path in (config_path, matrix_path)]
    assert config['status'] == 'loaded_configuration_recovered'
    for record in (config, matrix):
        for field in ('source_sha256', 'loaded_source_sha256'):
            for name, digest in record.get(field, {}).items():
                assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    for rank in config['ranks']:
        validate_groups(rank['groups'])
        inventory = next(event for line in Path(rank['trace']).open()
                         if (event := json.loads(line))['event'] == 'loaded_model_inventory')
        for role in ('target', 'draft'):
            attention = [m for m in inventory[role]['modules'] if m['name'].endswith('.self_attn')]
            assert len(attention) == (10 if role == 'target' else 1)
            for layer in attention:
                scalars = layer['scalars']
                assert scalars['attn_output_gate'] is True
                assert (scalars['num_heads'], scalars['num_kv_heads'], scalars['head_dim']) == (8, 1, 256)
    cohorts = {name: operations(row['valid_tokens']['target'], row['valid_tokens']['draft'])
               for name, row in matrix['cohorts'].items()}
    paths = [config_path, matrix_path, Path(__file__), ROOT / 'audit_moe_scalar_sources.py',
             ROOT / 'audit_rope_reference.py', ROOT / 'audit_router_gate_reference.py']
    return {
        'status': 'recovery_model_r5_loaded_configuration_valid_row_scalar_semantics',
        'cohorts': cohorts,
        'source_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        'model_effective_flops': None, 'm01_attainment': None,
        'limitations': [
            'Source-semantic work on valid rows, not physical instruction counting or output-contribution certification.',
            'Global TP2 model counted once. Q/K RMS, GDN normalization, projections and attention softmax are separate ledgers and excluded here.',
            'Rotary shared-object count is not an invocation count; layer multiplicities come from loaded attention modules.',
            'Special functions, divisions and max comparisons are separated; top-k selection algorithm comparisons remain uncounted.',
            'Cached trigonometry construction, graph padding, parameter transforms and any unrecorded activation clipping are excluded.',
            'Numerical qualification and shape-matched capacity are separate requirements; this ledger does not close M01.',
        ],
    }


if __name__ == '__main__':
    result = build()
    with (ROOT / 'recovery_model_r5-scalar-semantics.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({name: row['basic_subtotal'] for name, row in result['cohorts'].items()}))
