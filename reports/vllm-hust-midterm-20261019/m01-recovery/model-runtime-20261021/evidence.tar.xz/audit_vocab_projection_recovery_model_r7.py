"""Audit recovery_model_r7 vocabulary work without asserting unobserved device completion."""
import hashlib
import json
from pathlib import Path

from recover_model_hardware import request_phase

ROOT = Path(__file__).resolve().parent
RUN = Path("/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r7")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def projection(rows, partitions):
    assert type(rows) is int and rows >= 0
    assert partitions == [[124160, 2048], [124160, 2048]]
    return 2 * rows * 248320 * 2048


def count_rows(events, start, end):
    selected = [e for e in events if start <= e["wall"] <= end]
    target = [e for e in selected if e["event"] == "target_logits_input"]
    replay = [e for e in selected if e["event"] == "draft_replay_input"]
    contexts = [
        e for e in selected
        if e["event"] == "forward_enter" and e["role"] == "draft"
    ]
    assert len(target) == len(replay) == len(contexts) > 0
    for i, (context, item) in enumerate(zip(contexts, replay, strict=True)):
        assert context["wall"] <= item["wall"]
        if i + 1 < len(contexts):
            assert item["wall"] < contexts[i + 1]["wall"]
        assert len(context["draft_steps"]) == 2
        assert item["batch_size"] == item["first_step_sample_indices_rows"]
        assert item["batch_size"] == context["draft_steps"][1]["actual_tokens"]
    assert all(type(e["rows"]) is int and e["rows"] >= 0 for e in target)
    return {
        "contexts": len(contexts),
        "rows": {
            "target": sum(e["rows"] for e in target),
            "draft_step0": sum(e["first_step_sample_indices_rows"] for e in replay),
            "draft_step1": sum(e["draft_steps"][1]["actual_tokens"] for e in contexts),
        },
        "first_host_event": min(e["wall"] for e in target + replay + contexts),
        "last_host_event": max(e["wall"] for e in target + replay + contexts),
    }


def main():
    receipt = json.loads((RUN / "receipt.json").read_text())
    result = json.loads((RUN / "mmlu-pro.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, result)
    pins = {}
    for path in (RUN / "receipt.json", RUN / "mmlu-pro.json",
                 RUN / "launch-command.json", Path(__file__),
                 ROOT / "recover_model_hardware.py"):
        pins[str(path)] = digest(path)
    payload = ROOT / "payload-receipt.json"
    assert digest(payload) == receipt["input_hashes"]["payload-receipt.json"]
    pins[str(payload)] = digest(payload)
    payload_pins = json.loads(payload.read_text())["payload_hashes"]
    runtime_receipt = ROOT / "actual-runtime.json"
    pins[str(runtime_receipt)] = digest(runtime_receipt)
    runtime_pins = {
        item["path"]: item["sha256"]
        for item in json.loads(runtime_receipt.read_text())["admitted_source_files"]
    }
    for relative in ("models/qwen35/__init__.py",
                     "models/qwen35/small_fish_runtime.py",
                     "models/qwen35/integration.py"):
        path = ROOT / "payload/betterscale" / relative
        assert digest(path) == payload_pins[relative]
        pins[str(path)] = digest(path)
    for relative in ("vllm_ascend/spec_decode/llm_base_proposer.py",
                     "vllm_ascend/ops/vocab_parallel_embedding.py"):
        path = ROOT / "runtime" / relative
        assert digest(path) == runtime_pins[relative]
        pins[str(path)] = digest(path)
    command = json.loads((RUN / "launch-command.json").read_text())
    assert json.loads(command[command.index("--speculative-config") + 1]) == {
        "method": "mtp", "num_speculative_tokens": 2
    }
    ranks = []
    for path in sorted(RUN.glob("token-accounting-*.jsonl")):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        pins[str(path)] = digest(path)
        installed = next(e for e in events if e["event"] == "observer_installed")
        logits = next(e for e in events if e["event"] == "logits_observer_installed")
        observer = "token-observer-recovery-r1/hust_token_observer/logits.py"
        assert logits["source_sha256"] == receipt["input_hashes"][observer]
        assert digest(ROOT / observer) == logits["source_sha256"]
        pins[str(ROOT / observer)] = logits["source_sha256"]
        inventory = next(e for e in events if e["event"] == "loaded_model_inventory")
        shapes = {}
        for role in ("target", "draft"):
            heads = [m for m in inventory[role]["modules"] if m["name"].endswith("lm_head")]
            assert len(heads) == 1
            assert heads[0]["type"] == "vllm_ascend.ops.vocab_parallel_embedding.AscendParallelLMHead"
            assert heads[0]["parameters"]["weight"]["shape"] == [124160, 2048]
            assert heads[0]["parameters"]["weight"]["dtype"] == "torch.bfloat16"
            shapes[role] = heads[0]["parameters"]["weight"]["shape"]
        counted = count_rows(events, phase["start_wall"], receipt["bench_ended_wall"])
        ranks.append({"rank": installed["rank"], "loaded_head_shapes": shapes, **counted})
    assert len(ranks) == 2 and {r["rank"] for r in ranks} == {0, 1}
    assert ranks[0]["rows"] == ranks[1]["rows"]
    expected_contexts = {item["frames"] // 2 for item in receipt["deferred_exports"]}
    assert len(expected_contexts) == 1
    assert all(item["frames"] % 2 == 0 for item in receipt["deferred_exports"])
    assert ranks[0]["contexts"] == ranks[1]["contexts"] == next(iter(expected_contexts))
    arithmetic = {
        role: projection(rows, [
            r["loaded_head_shapes"]["target" if role == "target" else "draft"]
            for r in ranks
        ]) for role, rows in ranks[0]["rows"].items()
    }
    output = {
        "status": "same_run_host_observed_vocabulary_rows_not_device_window_attainment",
        "request_phase": phase,
        "host_selection_end": receipt["bench_ended_wall"],
        "ranks": ranks,
        "source_sha256": pins,
        "semantic_projection_flops": arithmetic,
        "semantic_projection_subtotal": sum(arithmetic.values()),
        "model_effective_flops": None,
        "m01_attainment": None,
        "limitations": [
            "Selection includes drain until benchmark client completion.",
            "Target logits are outside the observed model forward; device completion is not timed here.",
            "Draft rows use pinned replay inputs and source mapping, not per-kernel observations.",
            "Do not add this subtotal to request-window F without matching device boundaries.",
            "TP vocabulary partitions are counted once; 2MNK is semantic arithmetic.",
            "Gathering, sampling, argmax and non-matrix operations are excluded.",
        ],
    }
    with (ROOT / "vocab-projection-summary-recovery_model_r7.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"rows": ranks[0]["rows"], "contexts": ranks[0]["contexts"],
                      "subtotal": output["semantic_projection_subtotal"]}, indent=2))


if __name__ == "__main__":
    main()
