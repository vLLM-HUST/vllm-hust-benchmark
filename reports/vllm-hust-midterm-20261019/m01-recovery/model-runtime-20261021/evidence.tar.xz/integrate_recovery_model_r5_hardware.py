"""Audit recovery_model_r5 boundaries and integrate only the same run's hardware counters."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3

from audit_deferred_model_capture import audit as audit_capture
from integrate_hbm_samples import check_export, has_complete_hbm_coverage, integrate
from integrate_r12_hardware import link_bounds
from recover_model_hardware import request_phase

ROOT = Path(__file__).resolve().parent
RUN = Path("/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def classify(start, end, phase):
    if end[1] < phase["start_wall"]:
        return "before"
    if start[0] > phase["end_wall"]:
        return "after"
    if start[0] >= phase["start_wall"] and end[1] <= phase["end_wall"]:
        return "inside"
    return "crosses_boundary"


def boundaries(run, phase):
    ranks, endpoints, syncs, paths = [], [], [], []
    for path in sorted(run.glob("moe-deferred-*.json")):
        checked = audit_capture(path)
        raw = json.loads(path.read_text())
        pid = int(path.stem.removeprefix("moe-deferred-"))
        owned_path = run / f"owned-fia-{pid}.json"
        owned = json.loads(owned_path.read_text())
        ready_path = owned_path.with_suffix(".ready")
        ready = json.loads(ready_path.read_text())
        assert ready["pid"] == pid and ready["sha256"] == sha(owned_path)
        assert ready["records"] == len(owned["records"]) and not owned["errors"]
        counts = {name: {"target": 0, "draft": 0} for name in
                  ("before", "inside", "crosses_boundary", "after")}
        a, b = raw["anchor_host_bracket"]
        end_bounds = []
        for frame in raw["frames"]:
            start = [a + frame["start_ms"] / 1000 - .002,
                     b + frame["start_ms"] / 1000 + .002]
            end = [a + frame["end_ms"] / 1000 - .002,
                   b + frame["end_ms"] / 1000 + .002]
            counts[classify(start, end, phase)][frame["role"]] += 1
            end_bounds.append(end)
        final = owned["final_synchronization_host_bracket"]
        assert final[0] <= final[1]
        assert all(entry["host_enqueue_end_wall"] <= final[0] for entry in owned["records"])
        endpoints.append(max(pair[1] for pair in end_bounds))
        syncs.extend((raw["final_anchor_host_bracket"][1], final[1]))
        component_syncs = {}
        for kind in ("block", "plan"):
            reference = owned[f"{kind}_export"]
            component_path = run / reference["file"]
            assert sha(component_path) == reference["sha256"]
            component = json.loads(component_path.read_text())
            bracket = component["final_synchronization_host_bracket"]
            assert bracket[0] <= bracket[1]
            assert not component["errors"]
            assert len(component["records"]) == len(owned["records"])
            assert all(entry["host_enqueue_end_wall"] <= bracket[0]
                       for entry in component["records"])
            syncs.append(bracket[1])
            component_syncs[kind] = bracket
            paths.append(component_path)
        gdn_path = run / f"gdn-publication-{pid}.json"
        gdn_ready_path = gdn_path.with_suffix(".ready")
        gdn_ready = json.loads(gdn_ready_path.read_text())
        assert gdn_ready["pid"] == pid and gdn_ready["sha256"] == sha(gdn_path)
        gdn = json.loads(gdn_path.read_text())
        assert not gdn["errors"] and len(gdn["records"]) == gdn_ready["records"]
        bracket = gdn["final_synchronization_host_bracket"]
        assert bracket[0] <= bracket[1]
        assert all(r["host_enqueue_end_wall"] <= bracket[0] for r in gdn["records"])
        syncs.append(bracket[1])
        component_syncs["gdn_publication"] = bracket
        paths.extend((gdn_path, gdn_ready_path))
        ranks.append({"pid": pid, "frame_buckets": counts,
                      "capture_audit": checked,
                      "last_forward_end_wall_outer": endpoints[-1],
                      "moe_final_sync": raw["final_anchor_host_bracket"],
                      "owned_lengths_final_sync": final,
                      "paired_component_final_sync": component_syncs})
        paths.extend((path, path.with_suffix(".ready"), owned_path, ready_path))
    assert len(ranks) == 2
    windows = [
        {"name": "first_request_to_last_response", "end_wall": phase["end_wall"]},
        {"name": "first_request_to_last_forward_event_outer", "end_wall": max(endpoints)},
        {"name": "first_request_to_all_export_synchronizations", "end_wall": max(syncs)},
    ]
    for window in windows:
        window["start_wall"] = phase["start_wall"]
        assert window["end_wall"] > window["start_wall"]
    return ranks, windows, paths


def build():
    receipt_path = RUN / "receipt.json"
    receipt = json.loads(receipt_path.read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    assert receipt["bench_exit_code"] == 0
    result_path = RUN / "mmlu-pro.json"
    result = json.loads(result_path.read_text())
    assert result["completed"] == 200 and result["failed"] == 0
    phase = request_phase(receipt, result)
    prep_path = RUN / "checkpoint-cache-pre-request.json"
    prep = json.loads(prep_path.read_text())
    assert prep["after"]["wall"] < receipt["bench_started_wall"]
    ranks, windows, paths = boundaries(RUN, phase)
    control = RUN / "system"
    system_path = control / "receipt.json"
    system = json.loads(system_path.read_text())
    assert system["profiler_exit_code"] == system["profiler_cleanup_exit_code"] == 0
    assert system["errors"] == []
    assert system["run"] == str(RUN)
    qualification_path = ROOT / "hccs-capacity-control-r1/summary.json"
    qualification = json.loads(qualification_path.read_text())
    assert qualification["status"] == "qualified_reference_flit_rates"
    assert qualification["decoder"]["library_sha256"] == system["dcmi"]["hashes"][
        "/usr/local/Ascend/driver/lib64/driver/libdcmi.so"]
    hccs_path = control / "hccs64.jsonl"
    rows = [json.loads(line) for line in hccs_path.read_text().splitlines()]
    databases = sorted((control / "profiler").glob("*/device_*/sqlite/hbm.db"))
    assert len(databases) == 2
    hbm = []
    for path in databases:
        with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as connection:
            samples = connection.execute(
                "SELECT device_id,timestamp,counts,hbmid,event_type FROM HBMOriginalData WHERE replayid=0"
            ).fetchall()
            exported = connection.execute("SELECT * FROM HBMbwData").fetchall()
        hbm.append((path, samples, check_export(samples, exported)))
    assert [{row[0] for row in samples} for _, samples, _ in hbm] == [{0}, {1}]
    for window in windows:
        start, end = (window[key] * 1e9 for key in ("start_wall", "end_wall"))
        window["duration_seconds"] = window["end_wall"] - window["start_wall"]
        window["hbm_devices"] = []
        for path, samples, check in hbm:
            values = integrate(samples, start, end)
            assert has_complete_hbm_coverage(values), window["name"]
            window["hbm_devices"].append({
                "db": str(path), "sha256": sha(path), "decoder_crosscheck": check, **values})
        window["hbm_bytes"] = {
            key: sum(device[key] for device in window["hbm_devices"])
            for key in ("fully_contained_bytes", "prorated_bytes", "intersecting_interval_bytes")
        }
        window["hccs"] = link_bounds(rows, start, end)
    paths.extend((receipt_path, result_path, prep_path, system_path, hccs_path, qualification_path))
    paths.extend(ROOT / name for name in (
        "integrate_recovery_model_r5_hardware.py", "integrate_r12_hardware.py",
        "integrate_hbm_samples.py", "recover_model_hardware.py", "audit_deferred_model_capture.py"))
    return {
        "status": "same_run_named_interval_counter_coverage_verified",
        "request_phase": phase, "ranks": ranks, "windows": windows,
        "source_sha256": {str(path): sha(path) for path in paths},
        "hccs_decoder": qualification["decoder"],
        "model_effective_flops": None, "m01_attainment": None,
        "limitations": [
            "Forward bounds use qualified 2 ms clock mapping tolerance, not a hardware error guarantee.",
            "Current-stream forward events do not prove all production streams have completed.",
            "Final export synchronization includes observer control and controller waiting.",
            "Physical HBM and HCCS include observer traffic; they are not model-only logical traffic.",
            "HBM prorating is an estimate; containment/intersection totals give sample-interval bounds.",
            "HCCS sums TX once across two cards, without adding RX.",
            "No full effective F, matching capacity or attained M01 is asserted.",
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    result = build()
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps([{
        "name": w["name"], "seconds": w["duration_seconds"], "hbm": w["hbm_bytes"],
        "hccs_tx": w["hccs"]["aggregate_tx_bytes"],
    } for w in result["windows"]], indent=2))
