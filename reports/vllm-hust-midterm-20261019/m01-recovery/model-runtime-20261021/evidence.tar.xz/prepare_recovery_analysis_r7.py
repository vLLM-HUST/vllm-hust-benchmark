"""Use a new run identity after the r6 disk-admission rejection."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'prepare_recovery_analysis_r6.py').read_text().replace('r6', 'r7')
exec(compile(source, str(ROOT / 'prepare_recovery_analysis_r6.py'), 'exec'),
     {'__file__': str(__file__), '__name__': '__main__'})
