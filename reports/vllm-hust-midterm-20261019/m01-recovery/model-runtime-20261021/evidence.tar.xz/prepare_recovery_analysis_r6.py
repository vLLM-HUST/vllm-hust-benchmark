"""Prepare same-run analyses with the actual recovery observer and strict coverage."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'prepare_recovery_analysis_r4.py').read_text()
source = source.replace('recovery-model-r4', 'recovery-model-r6')
source = source.replace('recovery_model_r4', 'recovery_model_r6')
source = source.replace('recovery-analysis-build-r4', 'recovery-analysis-build-r6')
source = source.replace('        ast.parse(text)',
    '        if name == "audit_vocab_projection_r21.py":\n'
    '            text = text.replace("token-observer-v19/hust_token_observer/logits.py",\n'
    '                                "token-observer-recovery-r1/hust_token_observer/logits.py")\n'
    '        ast.parse(text)')
exec(compile(source, str(ROOT / 'prepare_recovery_analysis_r4.py'), 'exec'),
     {'__file__': str(__file__), '__name__': '__main__'})
runner = (ROOT / 'run_recovery_analysis_r5.py').read_text()
runner = runner.replace("assert sys.argv[1:] == ['--remaining']\nFILES = FILES[11:]\n", '')
runner = runner.replace('recovery-analysis-execution-r5d', 'recovery-analysis-execution-r6')
runner = runner.replace('recovery_model_r5', 'recovery_model_r6')
runner = runner.replace('integrate_recovery_model_r6_hardware_v2.py', 'integrate_recovery_model_r6_hardware.py')
runner = runner.replace('audit_vocab_projection_recovery_model_r6_v2.py', 'audit_vocab_projection_recovery_model_r6.py')
with (ROOT / 'run_recovery_analysis_r6.py').open('x') as stream:
    stream.write(runner)
