"""Require complete device maps as well as the existing final GDN fields."""
import json
import time

from await_gdn_publication import validate as validate_fields


def validate_maps(raw):
    for row in raw['records']:
        meta, maps = row['metadata'], row['device_maps']
        tokens, requests = meta['tokens'], meta['requests']
        assert set(maps) == {'prefill_map', 'verify_map', 'restore'}
        assert len(maps['prefill_map']) == len(maps['restore']) == tokens
        assert len(maps['verify_map']) == requests * 3
        assert all(type(value) is int for values in maps.values() for value in values)
        if meta['decode_only']:
            continue  # The decode branch uses identity preprocessing, not these maps.
        cu = meta['host_cu']
        restore = [0] * tokens
        for name, ids, base in [('prefill_map', meta['prefill_ids'], 0),
                                ('verify_map', meta['verify_ids'], tokens)]:
            expected = [token for i in ids for token in range(cu[i], cu[i + 1])]
            assert maps[name] == expected + [0] * (len(maps[name]) - len(expected))
            for packed, token in enumerate(expected):
                restore[token] = base + packed
        assert maps['restore'] == restore


def validate(out, ready_path):
    ready = validate_fields(out, ready_path)
    raw = json.loads((out / f"gdn-publication-{ready['pid']}.json").read_text())
    validate_maps(raw)
    return ready


def await_export(out, server, timeout=180):
    with (out / 'gdn-publication-stop').open('x') as stream:
        stream.write(str(time.time()) + '\n')
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        errors = list(out.glob('gdn-publication-*.error'))
        assert not errors, [p.read_text() for p in errors]
        ready = sorted(out.glob('gdn-publication-*.ready'))
        if len(ready) == 2:
            result = [validate(out, path) for path in ready]
            assert len({r['pid'] for r in result}) == 2
            return result
        assert len(ready) < 2 and server.poll() is None
        time.sleep(.1)
    raise TimeoutError('GDN map export incomplete')
