"""Audit host forward-context token extents without claiming whole-model FLOPs."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, "/root/vllm-hust-benchmark/reports/vllm-hust-midterm-20261019")
from recover_model_hardware import request_phase


def main():
    run = ROOT / "microflow-token-accounting-r1"
    receipt = json.loads((run / "receipt.json").read_text())
    result = json.loads((run / "mmlu-pro.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, result)
    ranks = []
    for path in sorted(run.glob("token-accounting-*.jsonl")):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        installed = [e for e in events if e["event"] == "observer_installed"]
        assert len(installed) == 1
        rank = installed[0]["rank"]
        assert installed[0]["observer_sha256"] == receipt["input_hashes"][
            "token-observer/hust_token_observer/__init__.py"
        ]
        enters = [
            e for e in events if e["event"] == "forward_enter"
            and phase["start_wall"] <= e["wall"] <= phase["end_wall"]
        ]
        exits = [
            e for e in events if e["event"] == "forward_exit"
            and phase["start_wall"] <= e["wall"] <= phase["end_wall"]
        ]
        roles = {}
        for role in ("target", "draft"):
            rows = [e for e in enters if e["role"] == role]
            finished = [e for e in exits if e["role"] == role]
            assert rows and len(rows) == len(finished)
            assert all(e["valid_extent"] for e in rows)
            histogram = Counter((e["actual_tokens"], e["padded_tokens"], e["graph_mode"]) for e in rows)
            roles[role] = {
                "contexts": len(rows), "matched_exits": len(finished),
                "sum_context_actual_tokens": sum(e["actual_tokens"] for e in rows),
                "sum_context_padded_tokens": sum(e["padded_tokens"] for e in rows),
                "histogram": [
                    {"actual_tokens": a, "padded_tokens": p, "graph_mode": mode, "contexts": n}
                    for (a, p, mode), n in sorted(histogram.items())
                ],
                "metadata_types": sorted({m["type"] for e in rows for m in e["metadata"]}),
            }
        ranks.append({
            "rank": rank, "roles": roles, "import_receipt": installed[0],
            "file": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })
    assert {r["rank"] for r in ranks} == {0, 1}
    matched = ranks[0]["roles"] == ranks[1]["roles"]
    summary = {
        "status": "forward_context_extent_qualified" if matched else "rank_extent_mismatch",
        "request_phase": phase, "ranks": ranks, "rank_histograms_match": matched,
        "completed": result["completed"], "failed": result["failed"],
        "limitations": [
            "Host forward-context extents, not counts of every model or kernel invocation.",
            "One draft context surrounds multiple MTP steps; do not multiply its token sum blindly by draft count.",
            "Custom-kernel arithmetic, per-query attention lengths and valid-versus-routed MoE rows are not fully accounted.",
            "No whole-model effective FLOPs or acceptance attainment is derived.",
            "This diagnostic does not replace uninstrumented B1 performance.",
        ],
        "model_effective_flops": None, "attainment_percent": None,
        "source_sha256": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (run / "receipt.json", run / "mmlu-pro.json", ROOT / "audit_token_accounting.py")
        },
    }
    with (ROOT / "token-accounting-summary-r1.json").open("x") as stream:
        json.dump(summary, stream, indent=2)
        stream.write("\n")
    print(json.dumps(summary, indent=2))
    return 0 if matched else 1


if __name__ == "__main__":
    raise SystemExit(main())
