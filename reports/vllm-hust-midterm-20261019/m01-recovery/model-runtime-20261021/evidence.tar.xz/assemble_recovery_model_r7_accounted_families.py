"""Disjoint accounted-family index; deliberately not a whole-model F certificate."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INSIDE = 'inside_request_under_clock_tolerance'


def subtotal(entries):
    names = [item['family'] for item in entries]
    assert len(names) == len(set(names)), 'Duplicate arithmetic family'
    for item in entries:
        assert type(item['global_basic_operations']) is int
        assert item['global_basic_operations'] >= 0
        assert item['counting_scope'] in ('already_global', 'sum_two_tp_shards')
    return sum(item['global_basic_operations'] for item in entries)


def main():
    names = {
        'matrix': 'recovery_model_r7-matrix-accounting.json', 'vocab': 'recovery_model_r7-vocab-window.json',
        'norm': 'recovery_model_r7-norm-semantics.json', 'softmax': 'recovery_model_r7-softmax-semantics.json',
        'scalar': 'recovery_model_r7-scalar-semantics.json', 'gdn': 'recovery_model_r7-device-gdn-ledger.json',
        'prefill': 'recovery_model_r7-device-gdn-prefill.json',
        'preprocess': 'recovery_model_r7-gdn-preprocess-semantics.json',
    }
    data = {}
    for key, name in names.items():
        item = json.loads((ROOT / name).read_text())
        for path, digest in item['source_sha256'].items():
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
        assert item['model_effective_flops'] is None and item['m01_attainment'] is None
        data[key] = item
    phase = data['matrix']['request_phase']
    for item in data.values():
        if 'request_phase' in item:
            assert item['request_phase'] == phase
    entries = []

    def add(family, source, amount, scope='already_global'):
        entries.append({'family': family, 'source': names[source],
                        'counting_scope': scope, 'global_basic_operations': amount})

    matrix = data['matrix']['cohorts'][INSIDE]
    add('linear_and_expert_projections', 'matrix', matrix['projection_semantic_subtotal'])
    add('causal_attention_qk_av', 'matrix', matrix['causal_qk_av_semantic_subtotal'])
    add('vocabulary_projection', 'vocab', data['vocab']['inside_projection_subtotal'])
    add('rms_residual_and_gdn_output_norm', 'norm', data['norm']['cohorts'][INSIDE]['basic_arithmetic_subtotal'])
    softmax = data['softmax']['cohorts'][INSIDE]['totals']
    add('attention_softmax_basic', 'softmax', sum(softmax[key] for key in
        ('score_scale_multiply', 'stability_subtract', 'denominator_add')))
    add('rope_moe_router_and_full_attention_gate', 'scalar', data['scalar']['cohorts'][INSIDE]['basic_subtotal'])
    for family, keys in (
        ('gdn_convolution', ('convolution_basic_arithmetic',)),
        ('gdn_active_recurrence', ('recurrent_basic_arithmetic',)),
    ):
        ranks = data['gdn']['ranks']
        assert len(ranks) == 2 and len({r['pid'] for r in ranks}) == 2
        add(family, 'gdn', sum(rank['cohorts'][INSIDE][key] for rank in ranks for key in keys),
            'sum_two_tp_shards')
    add('gdn_prefill_kkt_wy_inverse_ho_and_prefix_scan', 'prefill',
        sum(rank['cohorts'][INSIDE]['basic_arithmetic_subtotal'] for rank in data['prefill']['ranks']),
        'sum_two_tp_shards')
    add('gdn_qk_l2_and_preprocess_gate_valid_rows', 'preprocess',
        sum(rank['cohorts'][INSIDE]['scopes']['logical_valid_rows']['basic_arithmetic_subtotal']
            for rank in data['preprocess']['ranks']), 'sum_two_tp_shards')
    result = {
        'status': 'accounted_source_semantic_families_not_full_effective_flops',
        'request_phase': phase, 'families': entries,
        'accounted_basic_operation_subtotal': subtotal(entries),
        'model_effective_flops': None, 'm01_attainment': None,
        'remaining_checks': [
            {'id': 'gdn_preprocess_mapping', 'requirement': 'Establish device-final mapped preprocessing extents or qualify the exact host-to-device mapping path.',
             'evidence': 'recovery_model_r7-gdn-preprocess-semantics.json'},
            {'id': 'stream_dependencies', 'requirement': 'Establish dependency closure for timed model/collective/custom-op streams, beyond unchanged current stream identity.',
             'evidence': 'recovery_model_r7-direct-logits.json'},
            {'id': 'numerical_coverage', 'requirement': 'Reconcile source-semantic families with loaded binary behavior and retain special-function, selection, padding and parameter-transform exclusions.',
             'evidence': 'Per-family limitations remain applicable; this index does not override them.'},
            {'id': 'matched_capacity', 'requirement': 'Calibrate actual operation shapes, precision, state access, collective payloads and topology with repetitions and dispersion.',
             'evidence': 'Existing 16 MiB HCCS probe is not an application-matched reference for all shapes.'},
        ],
        'non_additive_categories': [
            'State-update-eligible preprocessing is an alternative scope, not an additional family.',
            'Prefix scan is already in the GDN prefill H/O ledger.',
            'Q/K L2 preprocessing is excluded from the RMS ledger.',
            'Special functions, division, comparison and unary negation retain separate counts without arbitrary FLOP weights.',
            'Tail operations and replicated TP hidden normalization are not added to this request-window semantic subtotal.',
        ],
        'source_sha256': {str(ROOT / name): hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                          for name in [*names.values(), Path(__file__).name]},
    }
    with (ROOT / 'recovery_model_r7-accounted-families.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'families': len(entries), 'accounted_basic_operation_subtotal': result['accounted_basic_operation_subtotal'],
                      'model_effective_flops': None, 'm01_attainment': None}))


if __name__ == '__main__':
    main()
