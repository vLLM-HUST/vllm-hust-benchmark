"""Reconcile same-run direct target-logits events without asserting full-model F."""
import hashlib
import json
from pathlib import Path

from audit_r18_vocab_envelopes import verify_ready
from integrate_r18_hardware import classify

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5')


def reconcile(records, host_events):
    assert records and len(records) == len(host_events)
    previous_end = 0
    for record, host in zip(records, host_events, strict=True):
        assert record['returned'] is True
        assert type(record['stream_before']) is int
        assert record['stream_before'] == record['stream_after']
        assert type(record['rows']) is int and record['rows'] >= 0
        assert record['rows'] == host['rows']
        assert record['host_begin'] <= host['wall'] <= record['host_end']
        assert 0 <= previous_end <= record['start_ms'] <= record['end_ms']
        previous_end = record['end_ms']


def main():
    summary_path = ROOT / 'vocab-projection-summary-recovery_model_r5.json'
    summary = json.loads(summary_path.read_text())
    for name, digest in summary['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    phase = summary['request_phase']
    sources = [Path(__file__), summary_path, ROOT / 'audit_r18_vocab_envelopes.py',
               ROOT / 'integrate_r18_hardware.py']
    ranks = []
    for path in sorted(RUN.glob('moe-deferred-*.json')):
        ready = verify_ready(path)
        pid = int(path.stem.removeprefix('moe-deferred-'))
        raw = json.loads(path.read_text())
        trace = RUN / f'token-accounting-{pid}.jsonl'
        events = [json.loads(line) for line in trace.open()]
        rank = next(e['rank'] for e in events if e['event'] == 'observer_installed')
        selected = [e for e in events if e['event'] == 'target_logits_input'
                    and phase['start_wall'] <= e['wall'] <= summary['host_selection_end']]
        records = raw['target_logits']['records']
        reconcile(records, selected)
        assert len(raw['frames']) == 2 * len(records)
        a, b = raw['anchor_host_bracket']
        buckets = {}
        details = []
        for item in records:
            start = [a + item['start_ms'] / 1000 - .002,
                     b + item['start_ms'] / 1000 + .002]
            end = [a + item['end_ms'] / 1000 - .002,
                   b + item['end_ms'] / 1000 + .002]
            category = classify(start, end, phase)
            buckets[category] = buckets.get(category, 0) + item['rows']
            details.append({'start_wall_bounds': start, 'end_wall_bounds': end,
                            'classification': category, 'rows': item['rows']})
        expected = next(row for row in summary['ranks'] if row['rank'] == rank)
        assert sum(buckets.values()) == expected['rows']['target']
        ranks.append({'rank': rank, 'pid': pid, 'calls': len(records),
                      'target_rows_by_device_window': buckets, 'intervals': details})
        sources.extend((path, ready, trace))
    assert {row['rank'] for row in ranks} == {0, 1}
    result = {
        'status': 'direct_target_logits_events_reconciled_pending_complete_model_accounting',
        'ranks': ranks,
        'model_effective_flops': None, 'm01_attainment': None,
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        'limitations': [
            'Current-stream event bounds use the existing 2 ms host/device mapping tolerance.',
            'Operator and communication dependency coverage remains a separate source/runtime audit.',
            'This is a diagnostic run, not a new B1 throughput result.',
            'No r18 event counts or inference state are used.',
        ],
    }
    with (ROOT / 'recovery_model_r5-direct-logits.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{key: value for key, value in row.items() if key != 'intervals'}
                      for row in ranks]))


if __name__ == '__main__':
    main()
