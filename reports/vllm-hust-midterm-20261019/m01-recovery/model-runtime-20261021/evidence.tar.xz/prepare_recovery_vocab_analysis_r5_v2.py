"""Use the actual recovery observer identity, retaining strict source SHA checks."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'audit_vocab_projection_recovery_model_r5.py').read_text()
old = 'token-observer-v19/hust_token_observer/logits.py'
new = 'token-observer-recovery-r1/hust_token_observer/logits.py'
assert source.count(old) == 1
source = source.replace(old, new)
with (ROOT / 'audit_vocab_projection_recovery_model_r5_v2.py').open('x') as stream:
    stream.write(source)
