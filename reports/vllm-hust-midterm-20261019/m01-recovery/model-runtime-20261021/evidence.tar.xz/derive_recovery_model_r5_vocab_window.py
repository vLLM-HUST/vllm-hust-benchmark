"""Separate request-window vocabulary projections from post-response work."""
import hashlib
import json
from pathlib import Path

from audit_r18_vocab_envelopes import verify_ready
from audit_vocab_projection_recovery_model_r5 import projection
from integrate_r18_hardware import classify

ROOT = Path(__file__).resolve().parent
RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-r5')


def main():
    paths = [ROOT / 'recovery_model_r5-direct-logits.json', ROOT / 'vocab-projection-summary-recovery_model_r5.json',
             Path(__file__), ROOT / 'audit_vocab_projection_recovery_model_r5.py',
             ROOT / 'integrate_r18_hardware.py', ROOT / 'audit_r18_vocab_envelopes.py']
    direct, summary = [json.loads(p.read_text()) for p in paths[:2]]
    for item in (direct, summary):
        for name, digest in item['source_sha256'].items():
            assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    phase = summary['request_phase']
    ranks = []
    for rank in direct['ranks']:
        path = RUN / f"moe-deferred-{rank['pid']}.json"
        ready = verify_ready(path)
        raw = json.loads(path.read_text())
        a, b = raw['anchor_host_bracket']
        rows = {'target': rank['target_rows_by_device_window'], 'draft_step0': {}, 'draft_step1': {}}
        for frame in raw['frames'][1::2]:
            assert frame['role'] == 'draft'
            count = frame['fields']['draft_steps'][1]['actual_tokens']
            assert type(count) is int and count >= 0
            start = [a + frame['start_ms'] / 1000 - .002, b + frame['start_ms'] / 1000 + .002]
            end = [a + frame['end_ms'] / 1000 - .002, b + frame['end_ms'] / 1000 + .002]
            category = classify(start, end, phase)
            for role in ('draft_step0', 'draft_step1'):
                rows[role][category] = rows[role].get(category, 0) + count
        expected = next(r for r in summary['ranks'] if r['rank'] == rank['rank'])
        for role, buckets in rows.items():
            assert sum(buckets.values()) == expected['rows'][role]
        ranks.append({'rank': rank['rank'], 'rows_by_device_window': rows})
        paths.extend((path, ready))
    assert len(ranks) == 2 and ranks[0]['rows_by_device_window'] == ranks[1]['rows_by_device_window']
    flops = {}
    for role, buckets in ranks[0]['rows_by_device_window'].items():
        shape_role = 'target' if role == 'target' else 'draft'
        shapes = [r['loaded_head_shapes'][shape_role] for r in summary['ranks']]
        flops[role] = {category: projection(count, shapes) for category, count in buckets.items()}
    result = {
        'status': 'vocabulary_rows_partitioned_by_device_event_window',
        'ranks': ranks, 'semantic_projection_flops_by_window': flops,
        'inside_projection_subtotal': sum(value.get('inside', 0) for value in flops.values()),
        'model_effective_flops': None, 'm01_attainment': None,
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'limitations': [
            'Target uses direct current-stream events; draft uses enclosing merged-forward events and pinned replay row mapping.',
            'Clock classification uses the existing 2 ms tolerance.',
            '2MNK counts only projection arithmetic, not gather, sampling or argmax.',
            'Current-stream operator dependency coverage is required; this is not a full-model effective FLOP certificate.',
        ],
    }
    with (ROOT / 'recovery_model_r5-vocab-window.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'ranks': ranks, 'projection_flops': flops,
                      'inside_projection_subtotal': result['inside_projection_subtotal']}))


if __name__ == '__main__':
    main()
