"""Require both ranks' device-final GDN publication exports before cleanup."""
import hashlib
import json
import time


def validate(out, ready_path):
    ready = json.loads(ready_path.read_text())
    path = out / f"gdn-publication-{ready['pid']}.json"
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == ready['sha256']
    raw = json.loads(data)
    assert raw['pid'] == ready['pid'] and raw['status'] == 'pending_stream_qualification'
    assert not raw['errors'] and len(raw['records']) == ready['records'] > 0
    for i, record in enumerate(raw['records']):
        assert record['slot'] == i
        meta, fields = record['metadata'], record['device_fields']
        live, verify = meta['live'], meta['verify_count']
        assert len(fields['cu']) == live + 1
        assert len(fields['accepted']) == live
        assert len(fields['verify_accepted']) == len(fields['verify_slots']) == verify
        assert len(fields['prefill_state']) == live - verify
        assert [row[0] for row in fields['cu']] == meta['host_cu']
        assert all(len(row) == 3 for row in fields['verify_slots'])
    return ready


def await_export(out, server, timeout=180):
    (out / 'gdn-publication-stop').write_text(str(time.time()) + '\n')
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        errors = list(out.glob('gdn-publication-*.error'))
        assert not errors, [p.read_text() for p in errors]
        ready = sorted(out.glob('gdn-publication-*.ready'))
        if len(ready) == 2:
            result = [validate(out, path) for path in ready]
            assert len({row['pid'] for row in result}) == 2
            return result
        assert len(ready) < 2 and server.poll() is None
        time.sleep(.1)
    raise TimeoutError('GDN publication export incomplete')
