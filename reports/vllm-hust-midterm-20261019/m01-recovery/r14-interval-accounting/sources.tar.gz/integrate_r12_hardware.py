"""Integrate r12 hardware over named intervals without asserting full-model F."""
import hashlib
import json
from pathlib import Path
import sqlite3

from integrate_hbm_samples import check_export, has_complete_hbm_coverage, integrate
from recover_model_hardware import request_phase

ROOT = Path(__file__).resolve().parent
RUN = Path("/workspace/gennova-measurements/microflow-token-accounting-r12")


def link_bounds(rows, start, end):
    devices = []
    for card in (4, 5):
        samples = [row for row in rows if row["card"] == card]
        assert samples and all(row["bits"] == 64 for row in samples)
        assert all(a["after"]["wall_ns"] < b["before"]["wall_ns"]
                   for a, b in zip(samples, samples[1:]))
        for direction in ("tx", "rx"):
            assert all(len(row[direction + "_counts"]) == 16 for row in samples)
            assert all(all(y >= x for x, y in zip(a[direction + "_counts"], b[direction + "_counts"]))
                       for a, b in zip(samples, samples[1:]))
        outer_start = max((r for r in samples if r["after"]["wall_ns"] <= start),
                          key=lambda r: r["after"]["wall_ns"])
        outer_end = min((r for r in samples if r["before"]["wall_ns"] >= end),
                        key=lambda r: r["before"]["wall_ns"])
        inner_start = min((r for r in samples if r["before"]["wall_ns"] >= start),
                          key=lambda r: r["before"]["wall_ns"])
        inner_end = max((r for r in samples if r["after"]["wall_ns"] <= end),
                        key=lambda r: r["after"]["wall_ns"])
        assert inner_start["after"]["wall_ns"] < inner_end["before"]["wall_ns"]
        intervals = {}
        for name, a, b in (("lower", inner_start, inner_end), ("upper", outer_start, outer_end)):
            intervals[name] = {
                "start_read_bracket": [a["before"]["wall_ns"], a["after"]["wall_ns"]],
                "end_read_bracket": [b["before"]["wall_ns"], b["after"]["wall_ns"]],
                **{direction + "_flits": [
                    y - x for x, y in zip(a[direction + "_counts"], b[direction + "_counts"])
                ] for direction in ("tx", "rx")},
            }
        devices.append({"card": card, "intervals": intervals})
    total = {bound: sum(sum(d["intervals"][bound]["tx_flits"]) for d in devices) * 20
             for bound in ("lower", "upper")}
    assert 0 <= total["lower"] <= total["upper"]
    return {"devices": devices, "aggregate_tx_bytes": total}


def main():
    receipt = json.loads((RUN / "receipt.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, json.loads((RUN / "mmlu-pro.json").read_text()))
    control = ROOT / "r12-system-control"
    system = json.loads((control / "receipt.json").read_text())
    assert system["profiler_exit_code"] == system["profiler_cleanup_exit_code"] == 0
    assert not system["sampler_errors"]
    assert system["workload_receipt_sha256"] == hashlib.sha256((RUN / "receipt.json").read_bytes()).hexdigest()
    qualification = json.loads((ROOT / "hccs-capacity-control-r1/summary.json").read_text())
    assert qualification["status"] == "qualified_reference_flit_rates"
    assert qualification["decoder"]["library_sha256"] == system["dcmi"]["hashes"][
        "/usr/local/Ascend/driver/lib64/driver/libdcmi.so"]
    captures = [json.loads(p.read_text()) for p in sorted(RUN.glob("moe-deferred-*.json"))]
    assert len(captures) == 2
    boundary = json.loads((ROOT / "deferred-request-window-r12.json").read_text())
    windows = [
        {"name": "first_request_to_last_response",
         "start_wall": phase["start_wall"], "end_wall": phase["end_wall"]},
        {"name": "first_request_to_last_recorded_forward_event_outer_bound",
         "start_wall": phase["start_wall"],
         "end_wall": max(r["last_capture_event_end_wall_bounds"][1] for r in boundary["ranks"])},
        {"name": "first_request_to_final_export_synchronization",
         "start_wall": phase["start_wall"],
         "end_wall": max(c["final_anchor_host_bracket"][1] for c in captures)},
    ]
    raw_path = control / "hccs64.jsonl"
    rows = [json.loads(line) for line in raw_path.read_text().splitlines()]
    databases = sorted(Path(system["profile_root"]).glob("*/device_*/sqlite/hbm.db"))
    assert len(databases) == 2
    hbm = []
    for path in databases:
        with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as connection:
            samples = connection.execute(
                "SELECT device_id,timestamp,counts,hbmid,event_type FROM HBMOriginalData WHERE replayid=0"
            ).fetchall()
            exported = connection.execute("SELECT * FROM HBMbwData").fetchall()
        check = check_export(samples, exported)
        hbm.append((path, samples, check))
    assert [{row[0] for row in samples} for _, samples, _ in hbm] == [{0}, {1}]
    for window in windows:
        start, end = (window[key] * 1e9 for key in ("start_wall", "end_wall"))
        window["duration_seconds"] = window["end_wall"] - window["start_wall"]
        window["hbm_devices"] = []
        for path, samples, check in hbm:
            values = integrate(samples, start, end)
            assert has_complete_hbm_coverage(values), window["name"]
            window["hbm_devices"].append({
                "db": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "decoder_crosscheck": check, **values,
            })
        window["hbm_bytes"] = {
            key: sum(d[key] for d in window["hbm_devices"])
            for key in ("fully_contained_bytes", "prorated_bytes", "intersecting_interval_bytes")
        }
        window["hccs"] = link_bounds(rows, start, end)
    output = {
        "status": "named_interval_hardware_coverage_verified_not_model_attainment",
        "windows": windows, "hccs_decoder": qualification["decoder"],
        "source_sha256": {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (
            RUN / "receipt.json", RUN / "mmlu-pro.json", control / "receipt.json", raw_path,
            ROOT / "deferred-request-window-r12.json",
            ROOT / "hccs-capacity-control-r1/summary.json",
            ROOT / "integrate_hbm_samples.py", ROOT / "integrate_r12_hardware.py",
        )},
        "model_effective_flops": None, "m01_attainment": None,
        "limitations": [
            "The last-response interval excludes observed drain work.",
            "The event endpoint is a current-stream bound, not proof of all-stream completion.",
            "The export synchronization interval includes controller wait and observer control overhead.",
            "HBM bounds are interval-count bounds; prorating is an estimate.",
            "HCCS TX is counted once; RX is retained but not added; physical traffic is not logical payload.",
            "Complete useful-work F and matching reference capacity are not established by these counters.",
        ],
    }
    destination = ROOT / "r12-hardware-intervals.json"
    with destination.open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps([{"name": w["name"], "seconds": w["duration_seconds"],
                       "hbm_bytes": w["hbm_bytes"], "hccs_tx_bytes": w["hccs"]["aggregate_tx_bytes"]}
                      for w in windows], indent=2))


if __name__ == "__main__":
    main()
