"""Semantic causal pairs from exported owned-frame device length values."""


def count_device_pairs(query_ends, kv_lengths, logical_rows, token_capacity):
    if type(logical_rows) is not int or not 0 < logical_rows <= len(query_ends):
        raise ValueError("Invalid logical row extent")
    if len(query_ends) != len(kv_lengths):
        raise ValueError("Mismatched device length arrays")
    if type(token_capacity) is not int or token_capacity <= 0:
        raise ValueError("Invalid token capacity")
    if any(type(value) is not int or value < 0 for value in query_ends + kv_lengths):
        raise ValueError("Invalid device length")
    if any(query_ends[logical_rows:]):
        raise ValueError("Unexpected query data outside published row extent")
    previous = 0
    pairs = valid = padding = active_rows = 0
    for end, kv in zip(query_ends[:logical_rows], kv_lengths[:logical_rows], strict=True):
        if not previous <= end <= token_capacity:
            raise ValueError("Nonmonotone or over-capacity query offsets")
        query = end - previous
        previous = end
        if kv == 0:
            padding += query
            continue
        if query > kv:
            raise ValueError("Query extent exceeds actual KV length")
        valid += query
        active_rows += int(query > 0)
        pairs += query * kv - query * (query - 1) // 2
    return {
        "valid_query_tokens": valid, "zero_kv_padding_tokens": padding,
        "causal_pairs": pairs, "nonempty_query_sequences": active_rows,
        "published_query_extent": previous,
    }
