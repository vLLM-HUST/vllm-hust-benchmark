"""Match deferred device histories to ordered host contexts; do not infer full F."""
import argparse
import hashlib
import json
from pathlib import Path


def audit(path):
    raw = json.loads(path.read_text())
    assert hashlib.sha256(path.read_bytes()).hexdigest() == path.with_suffix(".ready").read_text().strip()
    assert raw["status"] == "exported_pending_context_and_stream_coverage_audit"
    counts = {"target": 0, "draft": 0}
    frames = {"target": [], "draft": []}
    previous = 0
    for frame in raw["frames"]:
        role = frame["role"]
        fields = frame["fields"]
        assert role in counts and fields["role"] == role
        assert fields["valid_extent"]
        assert previous <= frame["start_ms"] + 0.001 <= frame["end_ms"] + 0.002
        previous = frame["end_ms"]
        if role == "target":
            actual = [fields["actual_tokens"]]
        else:
            assert fields["draft_steps"] and len(fields["draft_steps"]) == 2
            actual = [step["actual_tokens"] for step in fields["draft_steps"]]
        for value in actual:
            assert isinstance(value, int) and 0 <= value <= fields["padded_tokens"]
            frames[role].append({"actual": value, "padded": fields["padded_tokens"]})
        counts[role] += len(actual)
    assert counts["target"] > 0 and counts["draft"] > 0
    assert len(raw["layers"]) == 41
    names = set()
    total_rows = {"target": 0, "draft": 0}
    for layer in raw["layers"]:
        role = layer["role"]
        key = (role, layer["name"])
        assert key not in names
        names.add(key)
        assert layer["calls"] == counts[role] == len(layer["group_counts"])
        for groups, frame in zip(layer["group_counts"], frames[role]):
            assert len(groups) == 256 and all(isinstance(n, int) and n >= 0 for n in groups)
            assert sum(groups) == frame["padded"] * 8
            total_rows[role] += sum(groups)
    assert sum(role == "target" for role, _ in names) == 40
    assert sum(role == "draft" for role, _ in names) == 1
    a, b = raw["anchor_host_bracket"]
    c, d = raw["final_anchor_host_bracket"]
    assert c - b - .002 <= raw["anchor_device_seconds"] <= d - a + .002
    assert previous / 1000 <= raw["anchor_device_seconds"] + .002
    return {
        "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "contexts": {role: sum(f["role"] == role for f in raw["frames"]) for role in counts},
        "calls_per_layer": counts, "device_rows_including_padding": total_rows,
        "host_valid_tokens": {role: sum(f["actual"] for f in rows) for role, rows in frames.items()},
        "status": "ordered_context_counts_and_current_stream_events_consistent",
        "all_production_streams_proven": False, "whole_model_effective_compute_verified": False,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    paths = sorted(args.run.glob("moe-deferred-*.json"))
    assert len(paths) == 2
    print(json.dumps([audit(path) for path in paths], indent=2))
