"""Join device lengths to enclosing forward contexts before interval accounting."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_deferred_model_capture import audit
from integrate_r14_hardware import classify
from owned_fia_pairs import count_device_pairs
from recover_model_hardware import request_phase

ROOT = Path(__file__).resolve().parent
RUN = Path("/workspace/gennova-measurements/microflow-token-accounting-r14")


def associate(frames, records):
    cursor = 0
    result = []
    for frame in frames:
        expected = [("target", None)] if frame["role"] == "target" else [
            ("draft", 0), ("draft", 1)]
        group = records[cursor:cursor + len(expected)]
        assert len(group) == len(expected)
        for entry, (role, step) in zip(group, expected, strict=True):
            meta = entry["metadata"]
            assert meta["role"] == role and meta["draft_step"] == step
            assert frame["host_begin"] <= entry["host_enqueue_begin_wall"]
            assert entry["host_enqueue_begin_wall"] <= entry["host_enqueue_end_wall"] <= frame["host_end"]
            assert meta["tokens"] == meta["frame"]["tokens"] == frame["fields"]["padded_tokens"]
        result.append(group)
        cursor += len(expected)
    assert cursor == len(records), "Unassociated device publications"
    return result


def build():
    receipt = json.loads((RUN / "receipt.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, json.loads((RUN / "mmlu-pro.json").read_text()))
    captures, associated, pins = [], [], {}
    for path in sorted(RUN.glob("moe-deferred-*.json")):
        audit(path)
        raw = json.loads(path.read_text())
        owned_path = RUN / path.name.replace("moe-deferred-", "owned-fia-")
        owned_data = owned_path.read_bytes()
        owned = json.loads(owned_data)
        ready = json.loads(owned_path.with_suffix(".ready").read_text())
        assert ready["sha256"] == hashlib.sha256(owned_data).hexdigest()
        assert not owned["errors"] and ready["records"] == len(owned["records"])
        captures.append(raw)
        associated.append(associate(raw["frames"], owned["records"]))
        for p in (path, path.with_suffix(".ready"), owned_path, owned_path.with_suffix(".ready")):
            pins[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    assert len(captures) == 2 and len(captures[0]["frames"]) == len(captures[1]["frames"])
    cohorts = {key: {} for key in ("inside_request_under_clock_tolerance", "boundary_or_tail")}
    for index, frames in enumerate(zip(*(raw["frames"] for raw in captures), strict=True)):
        buckets = []
        for raw, frame in zip(captures, frames, strict=True):
            a, b = raw["anchor_host_bracket"]
            start = [a + frame["start_ms"] / 1000 - .002, b + frame["start_ms"] / 1000 + .002]
            end = [a + frame["end_ms"] / 1000 - .002, b + frame["end_ms"] / 1000 + .002]
            buckets.append(classify(start, end, phase))
        cohort = cohorts["inside_request_under_clock_tolerance"
                          if buckets == ["inside", "inside"] else "boundary_or_tail"]
        for left, right in zip(associated[0][index], associated[1][index], strict=True):
            meta = left["metadata"]
            for key in ("role", "draft_step", "tokens", "bank", "causal"):
                assert meta[key] == right["metadata"][key]
            assert meta["causal"] is True
            for key in ("device_query_lengths", "device_kv_lengths"):
                assert left[key] == right[key]
            rows = len(meta["host_planning_query_lengths"]["host_values"])
            assert rows == len(right["metadata"]["host_planning_query_lengths"]["host_values"])
            counts = count_device_pairs(left["device_query_lengths"], left["device_kv_lengths"],
                                        rows, meta["tokens"])
            step = meta["draft_step"]
            for frame in frames:
                actual = (frame["fields"]["actual_tokens"] if step is None else
                          frame["fields"]["draft_steps"][step]["actual_tokens"])
                assert counts["valid_query_tokens"] == actual
            role = "target" if step is None else f"draft_step{step}"
            cohort.setdefault(role, Counter()).update({"publications": 1, **counts})
    config_path = Path("/models/Qwen3.5-35B-A3B/config.json")
    config = json.loads(config_path.read_text())["text_config"]
    assert config["num_attention_heads"] == 16 and config["head_dim"] == 256
    assert config["layer_types"].count("full_attention") == 10
    assert config["mtp_num_hidden_layers"] == 1
    for cohort in cohorts.values():
        for role, counts in cohort.items():
            layers = 10 if role == "target" else 1
            counts["semantic_qk_av_arithmetic"] = 4 * counts["causal_pairs"] * 16 * 256 * layers
    for path in (config_path, RUN / "receipt.json", RUN / "mmlu-pro.json",
                 Path(__file__), ROOT / "owned_fia_pairs.py", ROOT / "integrate_r14_hardware.py",
                 ROOT / "audit_deferred_model_capture.py", ROOT / "recover_model_hardware.py"):
        pins[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {
        "status": "device_lengths_joined_to_enclosing_forwards_and_partitioned_by_request_interval",
        "request_phase": phase, "cohorts": cohorts, "source_sha256": pins,
        "model_effective_flops": None, "m01_attainment": None,
        "limitations": [
            "Inside classification is conditional on the 2 ms event-to-host mapping tolerance.",
            "Current-stream bounds do not establish every model stream boundary.",
            "Counts are logical causal attention pairs and 2MNK-style QK/AV arithmetic, not kernel instructions.",
            "TP2 partitions are counted once with global head count; padding is excluded.",
            "Softmax, projection, other operators and matched reference capacity are not supplied by this subtotal.",
        ],
    }


if __name__ == "__main__":
    output = ROOT / "r14-request-attention.json"
    assert not output.exists()
    result = build()
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result["cohorts"], indent=2))
