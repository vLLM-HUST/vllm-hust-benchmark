import copy
import unittest

from derive_r14_attention_window import associate
from integrate_r14_hardware import classify


class IntervalTests(unittest.TestCase):
    def test_boundary_classification(self):
        phase = {"start_wall": 10, "end_wall": 20}
        for start, end, expected in (
            ([1, 2], [3, 4], "before"),
            ([21, 22], [23, 24], "after"),
            ([10, 11], [19, 20], "inside"),
            ([9, 11], [12, 13], "crosses_boundary"),
            ([11, 12], [19, 21], "crosses_boundary"),
            ([8, 9], [9, 10], "crosses_boundary"),
        ):
            self.assertEqual(classify(start, end, phase), expected)

    def test_join_requires_containment_and_identity(self):
        frame = {"role": "target", "host_begin": 10, "host_end": 20,
                 "fields": {"padded_tokens": 32}}
        record = {"metadata": {"role": "target", "draft_step": None,
                               "tokens": 32, "frame": {"tokens": 32}},
                  "host_enqueue_begin_wall": 12, "host_enqueue_end_wall": 13}
        self.assertEqual(associate([frame], [record]), [[record]])
        for key, value in (("host_enqueue_begin_wall", 9), ("host_enqueue_end_wall", 21)):
            bad = copy.deepcopy(record)
            bad[key] = value
            with self.assertRaises(AssertionError):
                associate([frame], [bad])
        bad = copy.deepcopy(record)
        bad["metadata"]["draft_step"] = 0
        with self.assertRaises(AssertionError):
            associate([frame], [bad])
        with self.assertRaises(AssertionError):
            associate([frame], [record, record])
        with self.assertRaises(AssertionError):
            associate([frame], [])


if __name__ == "__main__":
    unittest.main()
