"""Audit full-model completion and actual capture, not full arithmetic coverage."""
import hashlib
import json
from pathlib import Path
import sqlite3
from m01_fenced_window import EXPORT_STOP_FLAGS, validate_fences

RUN = Path('/root/gennova-evidence/20261019-midterm-aligned/m01-recovery-model-fenced-r1')
EXPORT = Path('/workspace/m01-fenced-r1-offline-export')


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def main():
    receipt = json.loads((RUN / 'receipt.json').read_text())
    result = json.loads((RUN / 'mmlu-pro.json').read_text())
    envelope = json.loads((RUN / 'device-envelope.json').read_text())
    exported = json.loads((EXPORT / 'receipt.json').read_text())
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    assert receipt['bench_exit_code'] == receipt['hardware_collector_exit_code'] == 0
    assert result['completed'] == 200 and result['failed'] == 0
    assert result['total_output_tokens'] == 51200
    assert exported['status'] == 'exported_pending_database_audit'
    assert envelope['duration_seconds'] == (envelope['end_ns'] - envelope['start_ns']) / 1e9
    begin = validate_fences({'results': envelope['begin_fences']}, 'begin')
    end = validate_fences({'results': envelope['end_fences']}, 'end')
    assert {(r['rank'], r['pid'], r['device']) for r in begin} == {
        (r['rank'], r['pid'], r['device']) for r in end}
    assert all(r['sync_end_ns'] <= envelope['start_ns'] for r in begin)
    assert all(envelope['start_ns'] <= r['sync_start_ns'] <= r['sync_end_ns'] <= envelope['end_ns'] for r in end)
    assert all((RUN / name).stat().st_mtime_ns >= (RUN / 'device-envelope.json').stat().st_mtime_ns
               for name in EXPORT_STOP_FLAGS)
    sources = [RUN / name for name in ('receipt.json', 'mmlu-pro.json', 'device-envelope.json')]
    ranks = []
    capture_gaps = []
    for entry in exported['ranks']:
        assert entry['exit_code'] == 0 and entry['original_unchanged'] is True
        directory = Path(entry['destination'])
        databases = list(directory.glob('msprof_*.db'))
        assert len(databases) == 1, databases
        path = databases[0]
        samples = list(directory.glob('device_*/sample.json'))
        assert len(samples) == 1
        profile = json.loads(samples[0].read_text())
        assert profile['profMode'] != 'system'
        assert profile['runtimeApi'] == profile['acl'] == 'on'
        assert profile['taskTime'] in ('l1', 'on')
        sources += [path, samples[0]]
        with sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True) as db:
            assert db.execute('PRAGMA quick_check').fetchone()[0] == 'ok'
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if 'TASK' in tables:
                pids = [r[0] for r in db.execute('SELECT DISTINCT globalPid FROM TASK')]
                assert pids == [entry['pid']], pids
                devices = [r[0] for r in db.execute('SELECT DISTINCT deviceId FROM TASK')]
                assert devices == [entry['rank']], devices
            counts = {name: (db.execute(f'SELECT count(*) FROM "{name}"').fetchone()[0]
                            if name in tables else None)
                      for name in ('TASK', 'CANN_API', 'COMMUNICATION_OP', 'HBM', 'HCCS')}
            for name, count in counts.items():
                if count is None or count == 0:
                    capture_gaps.append(dict(rank=entry['rank'], table=name,
                                             reason='missing table' if count is None else 'empty table'))
            ranks.append(dict(rank=entry['rank'], pid=entry['pid'], rows=counts,
                task_streams=(list(db.execute('SELECT streamId,count(*) FROM TASK GROUP BY streamId'))
                              if 'TASK' in tables else None),
                profile={k: profile.get(k) for k in ('profMode', 'runtimeApi', 'acl', 'taskTime')},
                count_scope='Entire captured process lifetime; not yet filtered to the measurement envelope'))
    assert {r['rank'] for r in ranks} == {0, 1}
    audit = dict(status=('full_model_completed_device_fences_verified_capture_incomplete'
                         if capture_gaps else 'full_model_completed_device_fences_and_application_capture_verified'),
        completed=200, failed=0, output_tokens=51200, request_seconds=result['duration'],
        device_envelope_seconds=envelope['duration_seconds'],
        includes_client_startup_and_control_overhead=True,
        service_manager_exit_code=receipt['child_exit_codes'][1],
        automatic_export_completed=False, offline_export_completed=True,
        all_devices_released=True, ranks=ranks, capture_gaps=capture_gaps,
        full_arithmetic_coverage_proven=False,
        matching_reference_complete=False, model_effective_flops=None, m01_attainment=None,
        source_sha256={str(p): sha(p) for p in sources})
    with Path('/workspace/m01-fenced-r1-audit.json').open('x') as stream:
        json.dump(audit, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in audit.items() if k != 'source_sha256'}, indent=2))


if __name__ == '__main__':
    main()
