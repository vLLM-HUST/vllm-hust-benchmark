"""Offline export from copies; preserve the terminated run's raw capture."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

RAW = Path('/workspace/m01-fenced-r1-profiler')
OUT = Path('/workspace/m01-fenced-r1-offline-export')
OUT.mkdir(exist_ok=False)
record = dict(started=time.time(), status='exporting', ranks=[])


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


try:
    for rank, pid in enumerate((1222575, 1222576)):
        sources = list(RAW.glob(f'PROF_*_0{pid}*'))
        assert len(sources) == 1, sources
        source = sources[0]
        target = OUT / source.name
        hashes = {str(p.relative_to(source)): digest(p) for p in source.rglob('*') if p.is_file()}
        shutil.copytree(source, target)
        assert all(digest(target / name) == value for name, value in hashes.items())
        entry = dict(rank=rank, pid=pid, source=str(source), destination=str(target),
                     source_files_sha256=hashes)
        record['ranks'].append(entry)
        command = ['/usr/local/Ascend/ascend-toolkit/latest/bin/msprof', '--export=on',
                   '--type=db', f'--output={target}']
        entry['command'] = command
        with (OUT / f'rank-{rank}.log').open('x') as stream:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
        entry['exit_code'] = result.returncode
        assert result.returncode == 0, f'Rank {rank} export failed'
        assert all(digest(source / name) == value for name, value in hashes.items())
        entry['original_unchanged'] = True
        (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    record['status'] = 'exported_pending_database_audit'
except BaseException as error:
    record.update(status='failed', error=f'{type(error).__name__}: {error}')
    raise
finally:
    record['ended'] = time.time()
    (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
