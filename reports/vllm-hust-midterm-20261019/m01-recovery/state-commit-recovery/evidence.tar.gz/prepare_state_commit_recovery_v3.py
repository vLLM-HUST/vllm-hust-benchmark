"""Use a no-system-site venv to exclude global conflicting Triton metadata."""
import hashlib
import json
from pathlib import Path

from prepare_state_commit_recovery_v1 import replace_once

ROOT = Path(__file__).resolve().parent
VENV = Path('/workspace/state-commit-recovery-venv-r3')


def main():
    config = (VENV / 'pyvenv.cfg').read_text()
    assert 'include-system-site-packages = false' in config
    text = (ROOT / 'run_state_commit_recovery_v2.py').read_text()
    text = text.replace('state-commit-recovery-r2', 'state-commit-recovery-r3')
    text = text.replace('state-commit-recovery-cache-r2', 'state-commit-recovery-cache-r3')
    text = replace_once(text, "names = ['run_state_commit_recovery_v2.py',",
                        "names = ['run_state_commit_recovery_v3.py', 'prepare_state_commit_recovery_v3.py',\n                 'state_commit_recovery_v3.sh', 'state-commit-recovery-build-r3.json',\n                 'run_state_commit_recovery_v2.py',")
    target = ROOT / 'run_state_commit_recovery_v3.py'
    compile(text, str(target), 'exec')
    with target.open('x') as stream:
        stream.write(text)
    shell = (ROOT / 'state_commit_recovery_v2.sh').read_text()
    shell = replace_once(shell, 'exec python "$ROOT/run_state_commit_recovery_v2.py"',
                        'exec /workspace/state-commit-recovery-venv-r3/bin/python "$ROOT/run_state_commit_recovery_v3.py"')
    with (ROOT / 'state_commit_recovery_v3.sh').open('x') as stream:
        stream.write(shell)
    with (ROOT / 'state-commit-recovery-build-r3.json').open('x') as stream:
        json.dump(dict(venv_config=config,
                       venv_config_sha256=hashlib.sha256(config.encode()).hexdigest(),
                       controller_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                       global_site_packages_enabled=False, prior_cache_imported=False,
                       reason='Global interpreter also contains obsolete triton-3.5.0 metadata.'),
                  stream, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
