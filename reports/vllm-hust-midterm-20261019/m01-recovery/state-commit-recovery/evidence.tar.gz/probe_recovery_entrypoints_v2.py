"""Isolated import-order diagnostics, not runtime admission or a model run."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'runtime-entrypoint-recovery-r2'


def main():
    OUT.mkdir(exist_ok=False)
    results = []
    for name in ('vllm.entrypoints.cli.main', 'vllm_ascend.worker.model_runner_v1'):
        command = [sys.executable, '-c',
                   'import importlib; m=importlib.import_module(' + repr(name) + '); print(m.__file__)']
        log = OUT / (name + '.log')
        with log.open('x') as stream:
            try:
                result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT,
                                        timeout=180, check=False)
                code = result.returncode
            except subprocess.TimeoutExpired:
                code = 124
        results.append(dict(module=name, exit_code=code, log=log.name))
    receipt = dict(status='diagnostic_only', fresh_interpreter_per_entrypoint=True,
                   model_service_launched=False, results=results)
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    return int(any(row['exit_code'] for row in results))


if __name__ == '__main__':
    raise SystemExit(main())
