"""Reuse the exclusive-device controller, replacing only probe-specific setup."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = ROOT / 'run_gmm_graph_numeric_v1.py'
text = source.read_text()
start = text.index('        layout = json.loads(')
end = text.index('        for name in [\'/tmp/inference-project', start)
replacement = '''        names = ['run_state_commit_device_v1.py', 'qualify_state_commit_device_v1.py',
                 'state_commit_device_capture_v1.py', 'logits_device_capture_v1.py',
                 'payload-receipt.json', 'payload/betterscale/models/qwen35/state_commit.py',
                 'prepare_state_commit_qualification_v1.py', 'measure_microflow.py']
        receipt['source_sha256'] = {str(ROOT / name): hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}
        receipt['protocol'] = {'prior_cache_imported': False, 'rows': [0, 1, 24, 32],
                               'widths': [1, 2, 3], 'variants': [0, 1], 'cards': 2,
                               'model_qualification': False, 'cross_device_clock_qualification': False}
'''
text = text[:start] + replacement + text[end:]
text = text.replace('gmm-graph-numeric-r1', 'state-commit-device-r1')
text = text.replace('GMM', 'state commit').replace('Graph GMM numeric qualification with changed-input stale-output checks; no performance publication.', 'Pinned state commit numeric and cross-stream event qualification; no performance publication.')
text = text.replace('18496', '18501').replace('graph_numeric_completed_pending_audit', 'state_commit_qualification_completed_pending_audit')
text = text.replace("PYTHONPATH=''", "PYTHONPATH=str(ROOT / 'compat') + ':' + str(ROOT)")
text = text.replace('from gmm_graph_numeric_v1 import run', 'from qualify_state_commit_device_v1 import run')
ast.parse(text)
destination = ROOT / 'run_state_commit_device_v1.py'
with destination.open('x') as stream:
    stream.write(text)
names = [source, destination, Path(__file__).resolve(), ROOT / 'state_commit_device_capture_v1.py', ROOT / 'qualify_state_commit_device_v1.py']
with (ROOT / 'state-commit-qualification-build-v1.json').open('x') as stream:
    json.dump({'status': 'prepared_not_executed', 'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in names}}, stream, indent=2)
    stream.write('\n')
