"""Read-only import diagnostics; no model, tensor allocation or device probe."""
import importlib
import importlib.metadata
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'runtime-import-recovery-r1.json'


def main():
    assert not OUT.exists()
    records = []
    for name in ('torch', 'torch_npu', 'triton', 'transformers', 'vllm', 'vllm_ascend',
                 'vllm_ascend.worker.model_runner_v1'):
        before = time.time()
        try:
            module = importlib.import_module(name)
            row = dict(module=name, status='imported', path=getattr(module, '__file__', None),
                       module_version=getattr(module, '__version__', None))
        except Exception as error:
            row = dict(module=name, status='failed', error_type=type(error).__name__, error=str(error))
        row['elapsed_seconds'] = time.time() - before
        records.append(row)
    packages = {}
    for name in ('torch', 'torch-npu', 'triton-ascend', 'triton', 'vllm', 'vllm-ascend', 'transformers'):
        try:
            dist = importlib.metadata.distribution(name)
            packages[name] = dict(version=dist.version, root=str(dist.locate_file('')))
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    result = dict(status='candidate_import_diagnostic_not_runtime_admission', modules=records,
                  distributions=packages,
                  limitations=['No device tensor, model service, numerical or performance qualification.',
                               'Paths and versions identify this candidate only, not the lost original environment.'])
    with OUT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))
    return 0 if all(r['status'] == 'imported' for r in records) else 1


if __name__ == '__main__':
    raise SystemExit(main())
