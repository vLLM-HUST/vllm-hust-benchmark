"""Exclude conflicting Triton distributions without modifying either source tree."""
import hashlib
import json
from pathlib import Path

from prepare_state_commit_recovery_v1 import replace_once

ROOT = Path(__file__).resolve().parent
SITE = Path('/root/modcost-runtime-028-20261017/usr/local/python3.12.13/lib/python3.12/site-packages')
FILTERED = Path('/workspace/state-commit-recovery-site-r2')


def main():
    FILTERED.mkdir(exist_ok=False)
    excluded = []
    for path in sorted(SITE.iterdir()):
        if path.name == 'triton' or path.name.startswith(('triton-', 'triton_ascend-')):
            excluded.append(path.name)
        else:
            (FILTERED / path.name).symlink_to(path, target_is_directory=path.is_dir())
    assert 'triton' in excluded
    text = (ROOT / 'run_state_commit_recovery_v1.py').read_text()
    text = text.replace('state-commit-recovery-r1', 'state-commit-recovery-r2')
    text = text.replace('state-commit-recovery-cache-r1', 'state-commit-recovery-cache-r2')
    text = replace_once(text, "names = ['run_state_commit_recovery_v1.py',",
                        "names = ['run_state_commit_recovery_v2.py', 'prepare_state_commit_recovery_v2.py',\n                 'state_commit_recovery_v2.sh', 'state-commit-recovery-build-r2.json',\n                 'run_state_commit_recovery_v1.py',")
    target = ROOT / 'run_state_commit_recovery_v2.py'
    compile(text, str(target), 'exec')
    with target.open('x') as stream:
        stream.write(text)
    shell = (ROOT / 'state_commit_recovery_v1.sh').read_text()
    shell = replace_once(shell, 'SITE=' + str(SITE), 'SITE=' + str(FILTERED))
    shell = replace_once(shell, 'run_state_commit_recovery_v1.py', 'run_state_commit_recovery_v2.py')
    with (ROOT / 'state_commit_recovery_v2.sh').open('x') as stream:
        stream.write(shell)
    with (ROOT / 'state-commit-recovery-build-r2.json').open('x') as stream:
        json.dump(dict(filtered_site=str(FILTERED), source_site=str(SITE),
                       excluded_entries=excluded,
                       source_packages_modified=False, prior_cache_imported=False,
                       controller_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                       reason='Prevent obsolete triton distribution metadata selecting legacy Gluon stubs.'),
                  stream, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
