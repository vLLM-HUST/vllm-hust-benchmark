"""Import the real worker entrypoint without constructing a worker or model."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'runtime-worker-recovery-r3'


def main():
    OUT.mkdir(exist_ok=False)
    code = ('import vllm.entrypoints.cli.main; '
            'import vllm_ascend.worker.worker as w; print(w.__file__); '
            'print(w.NPUWorker.__name__)')
    with (OUT / 'worker-import.log').open('x') as log:
        try:
            result = subprocess.run([sys.executable, '-c', code], stdout=log,
                                    stderr=subprocess.STDOUT, timeout=180, check=False)
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            exit_code = 124
    receipt = dict(status='diagnostic_only', exit_code=exit_code,
                   imported_entrypoints=['vllm.entrypoints.cli.main', 'vllm_ascend.worker.worker'],
                   worker_constructed=False, model_service_launched=False)
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
