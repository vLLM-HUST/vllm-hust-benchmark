import base64
import hashlib

import pytest

from probe_triton_candidates_v1 import verify_record


def fixture_record(root, name='module.py'):
    package = root / 'triton_ascend-3.6.0.dist-info'
    package.mkdir()
    digest = base64.urlsafe_b64encode(hashlib.sha256(b'pass\n').digest()).decode().rstrip('=')
    (package / 'RECORD').write_text(f'{name},sha256={digest},5\n')


def test_valid_record(tmp_path):
    (tmp_path / 'module.py').write_bytes(b'pass\n')
    fixture_record(tmp_path)
    assert verify_record(tmp_path)['verified_files'] == 1


def test_changed_bytes_rejected(tmp_path):
    (tmp_path / 'module.py').write_bytes(b'fail\n')
    fixture_record(tmp_path)
    with pytest.raises(AssertionError):
        verify_record(tmp_path)


def test_escape_rejected(tmp_path):
    fixture_record(tmp_path, '../outside.py')
    with pytest.raises(AssertionError):
        verify_record(tmp_path)
