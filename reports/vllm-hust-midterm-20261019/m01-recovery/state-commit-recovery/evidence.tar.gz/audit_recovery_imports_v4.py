"""Seal import diagnostics without promoting them to runtime qualification."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'runtime-import-recovery-audit-v4.json'


def main():
    first = json.loads((ROOT / 'runtime-import-recovery-r1.json').read_text())
    third = json.loads((ROOT / 'runtime-worker-recovery-r3/receipt.json').read_text())
    fourth = json.loads((ROOT / 'runtime-worker-recovery-r4/receipt.json').read_text())
    log3 = (ROOT / 'runtime-worker-recovery-r3/worker-import.log').read_text()
    log4 = (ROOT / 'runtime-worker-recovery-r4/worker-import.log').read_text()
    assert third['exit_code'] == 1 and "No module named 'acl'" in log3
    assert fourth['exit_code'] == 0 and '\nNPUWorker\n' in log4
    assert 'Traceback (most recent call last)' not in log4
    sources = ['probe_recovery_imports_v1.py', 'probe_recovery_imports_v1.sh',
               'runtime-import-recovery-r1.json', 'probe_recovery_entrypoints_v2.py',
               'probe_recovery_entrypoints_v2.sh', 'probe_recovery_worker_v3.py',
               'probe_recovery_worker_v3.sh', 'probe_recovery_worker_v4.sh',
               Path(__file__).name]
    for directory in ('runtime-entrypoint-recovery-r2', 'runtime-worker-recovery-r3',
                      'runtime-worker-recovery-r4'):
        sources.extend(str(path.relative_to(ROOT)) for path in sorted((ROOT / directory).iterdir()))
    report = dict(
        status='worker_entrypoint_import_passed_not_runtime_admitted',
        worker_entrypoint_exit_code=0,
        correction='Preserve CANN PYTHONPATH after sourcing vendor environment.',
        direct_runner_import='Circular import reproduced; not evidence that normal worker entrypoint fails.',
        candidate_distributions=first['distributions'],
        runtime_admitted=False, model_service_launched=False,
        unresolved=['Candidate Triton package/module versions differ from original runtime.',
                    'Full source and dependency admission plus model numerical qualification remain.',
                    'M01 complete operation accounting and matched capacity remain unverified.',
                    'Persistent storage is insufficient for full trace collection.'],
        files={name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources})
    with OUT.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(report['status'])


if __name__ == '__main__':
    main()
