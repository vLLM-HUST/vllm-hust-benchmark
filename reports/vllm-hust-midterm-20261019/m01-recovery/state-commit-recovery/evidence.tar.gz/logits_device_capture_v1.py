"""Opt-in target-logits events; export only after workload completion."""
from functools import wraps
import threading
import time


class Capture:
    def __init__(self, npu, enabled, capacity=8192, clock=time.time):
        if type(capacity) is not int or capacity <= 0:
            raise ValueError('Invalid logits event capacity')
        self.npu = npu
        self.enabled = enabled
        self.capacity = capacity
        self.clock = clock
        self.records = []
        self.closed = False
        self.lock = threading.RLock()

    @staticmethod
    def stream_id(stream):
        value = stream.npu_stream
        if type(value) is not int:
            raise TypeError('NPU stream identity must be an integer')
        return value

    def wrap(self, original):
        @wraps(original)
        def observed(hidden_states, *args, **kwargs):
            with self.lock:
                if self.closed or not self.enabled():
                    return original(hidden_states, *args, **kwargs)
                if len(self.records) >= self.capacity:
                    raise RuntimeError('Logits event capacity exceeded')
                rows = hidden_states.shape[0]
                if type(rows) is not int or rows < 0:
                    raise ValueError('Invalid logits row count')
                stream = self.npu.current_stream()
                start = self.npu.Event(enable_timing=True)
                end = self.npu.Event(enable_timing=True)
                item = dict(rows=rows, stream_before=self.stream_id(stream),
                            host_begin=self.clock(), start=start, end=end,
                            returned=False)
                start.record(stream)
                self.records.append(item)
                try:
                    result = original(hidden_states, *args, **kwargs)
                    item['returned'] = True
                    return result
                finally:
                    item['stream_after'] = self.stream_id(self.npu.current_stream())
                    end.record(stream)
                    item['host_end'] = self.clock()
        return observed

    def export(self, anchor):
        # The caller ends the workload and synchronizes once before export.
        with self.lock:
            self.closed = True
            if not self.records:
                raise RuntimeError('No measured logits calls')
            if not anchor.query():
                raise RuntimeError('Anchor event is incomplete')
            result = []
            for item in self.records:
                if not item['returned']:
                    raise RuntimeError('Logits call did not return normally')
                if item['stream_before'] != item['stream_after']:
                    raise RuntimeError('Logits changed current stream')
                if not item['start'].query() or not item['end'].query():
                    raise RuntimeError('Logits event is incomplete')
                start_ms = anchor.elapsed_time(item['start'])
                end_ms = anchor.elapsed_time(item['end'])
                if not 0 <= start_ms <= end_ms:
                    raise RuntimeError('Invalid logits event order')
                result.append({key: value for key, value in item.items()
                               if key not in ('start', 'end')} |
                              {'start_ms': start_ms, 'end_ms': end_ms})
            return {
                'status': 'current_stream_logits_events_pending_runtime_qualification',
                'records': result,
                'limitations': [
                    'Caller must supply the same-run device anchor and clock bracket.',
                    'Current-stream events require source or profiler verification of custom-stream dependencies.',
                    'This observer is diagnostic, not a throughput candidate.',
                ],
            }
