"""Reconstruct saved device results independently and preserve failed attempts."""
import hashlib
import json
from pathlib import Path

import test_state_commit_device_evidence_v1 as checks

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'state-commit-recovery-r3'


def main():
    checks.RUN = RUN
    checks.test_lifecycle_and_frozen_sources()
    checks.test_cpu_reconstruction_and_changed_inputs()
    failed = []
    paths = [Path(__file__), ROOT / 'test_state_commit_device_evidence_v1.py']
    for attempt in (1, 2, 3):
        directory = ROOT / f'state-commit-recovery-r{attempt}'
        paths.extend(sorted(directory.iterdir()))
        receipt = json.loads((directory / 'receipt.json').read_text())
        for name, digest in receipt['source_sha256'].items():
            source = Path(name)
            assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
            paths.append(source)
        assert receipt['all_four_idle_after']
        if attempt < 3:
            assert receipt['status'] == 'failed' and receipt['exit_code'] == 1
            assert "No module named 'triton.experimental.gluon.nvidia'" in (directory / 'child.log').read_text()
            failed.append(dict(attempt=attempt, exit_code=1, all_four_idle_after=True))
    result = dict(
        status='two_device_eager_state_commit_recovery_qualification_passed',
        candidate_triton='3.6.0+git702d89ca', original_runtime_identity_proven=False,
        calls_per_rank=24, empty_noop_calls_per_rank=6, nonempty_kernel_calls_per_rank=18,
        cpu_reconstruction='Exact equality for recurrent, conv, remaining and accepted arrays.',
        changed_input_check='Nonempty paired cases have different accepted-token outputs.',
        isolation='Fresh interpreter/workers, exclusive output and cache directories, no prior cache copied.',
        failed_attempts_preserved=failed,
        scope='Pinned state_commit.publish; synthetic strided tokens and separate producer/consumer streams per device.',
        not_proven=['Complete runtime equivalence', 'Full model numerical qualification',
                    'Model graph behavior', 'Cross-device clock alignment', 'Whole-model stream closure',
                    'Complete F or matched-capacity M01 attainment'],
        model_qualification=False, performance_publication=False,
        source_sha256={str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in sorted(set(paths)) if path.is_file()})
    with (ROOT / 'state-commit-recovery-audit-r3.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(result['status'])


if __name__ == '__main__':
    main()
