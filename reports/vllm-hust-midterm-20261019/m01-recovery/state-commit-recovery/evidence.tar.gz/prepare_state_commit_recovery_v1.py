"""Derive a fresh recovery probe without changing frozen qualification sources."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main():
    source = ROOT / 'run_state_commit_device_v1.py'
    text = source.read_text()
    text = replace_once(text, "OUT = Path('/workspace/gennova-measurements/state-commit-device-r1')",
                        "OUT = ROOT / 'state-commit-recovery-r1'")
    text = replace_once(text,
                        "PYTHON = '/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python'",
                        'PYTHON = sys.executable')
    text = replace_once(text, 'Graph state commit numeric qualification', 'Eager state commit recovery numeric qualification')
    text = replace_once(text, "names = ['run_state_commit_device_v1.py',",
                        "names = ['run_state_commit_recovery_v1.py', 'run_state_commit_device_v1.py',\n                 'prepare_state_commit_recovery_v1.py', 'state_commit_recovery_v1.sh',\n                 'triton-candidate-import-r1/receipt.json',")
    text = replace_once(text, "cache = OUT / 'runtime-cache'",
                        "cache = Path('/workspace/state-commit-recovery-cache-r1')")
    text = replace_once(text, "PYTHONPATH=str(ROOT / 'compat') + ':' + str(ROOT)",
                        "PYTHONPATH=str(ROOT) + ':' + os.environ['PYTHONPATH']")
    target = ROOT / 'run_state_commit_recovery_v1.py'
    compile(text, str(target), 'exec')
    with target.open('x') as stream:
        stream.write(text)
    with (ROOT / 'state-commit-recovery-build-r1.json').open('x') as stream:
        json.dump(dict(original_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                       generated_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                       candidate='triton-ascend 3.6.0+git702d89ca',
                       candidate_selection='First listed import-passing candidate; not selected by performance.',
                       qualification='Unchanged eager numeric cases; not graph or complete model qualification.',
                       output=str(ROOT / 'state-commit-recovery-r1'),
                       cache='/workspace/state-commit-recovery-cache-r1',
                       prior_cache_imported=False), stream, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
