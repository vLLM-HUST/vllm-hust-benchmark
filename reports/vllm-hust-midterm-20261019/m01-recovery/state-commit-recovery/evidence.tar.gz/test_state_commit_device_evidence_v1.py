import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = Path('/workspace/gennova-measurements/state-commit-device-r1')


def test_lifecycle_and_frozen_sources():
    receipt = json.loads((RUN / 'receipt.json').read_text())
    assert receipt['status'] == 'state_commit_qualification_completed_pending_audit'
    assert receipt['exit_code'] == receipt['cleanup_exit_code'] == 0
    assert receipt['all_four_idle_after'] and not receipt['protocol']['prior_cache_imported']
    assert receipt['performance_publication'] is False
    for name, digest in receipt['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest


def test_cpu_reconstruction_and_changed_inputs():
    for rank in range(2):
        raw = json.loads((RUN / f'rank-{rank}.json').read_text())
        assert raw['rank'] == rank
        assert len(raw['cases']) == len(raw['records']) == 24
        assert not raw['model_qualification'] and not raw['performance_publication']
        assert raw['producer_stream'] != raw['consumer_stream']
        grouped = {}
        for case, event in zip(raw['cases'], raw['records']):
            n, width = case['rows'], case['width']
            assert event['rows'] == n and event['token_width'] == width
            assert event['stream_before'] == event['stream_after'] == raw['consumer_stream']
            assert 0 <= event['start_ms'] <= event['end_ms']
            expected = {'recurrent': [-7] * 32, 'conv': [-8] * 32,
                        'remaining': case['initial_remaining'].copy(), 'accepted': [-9] * 32}
            for i, seat in enumerate(case['seats']):
                count = len([value for value in case['tokens'][i] if value != -1])
                remaining = case['initial_remaining'][seat]
                committed = min(remaining, count)
                if remaining > 0:
                    if case['verify'][i]:
                        expected['recurrent'][seat] = committed + 2
                    expected['conv'][seat] = committed + 2 if case['verify'][i] else 1
                if case['sampling'][i]:
                    expected['remaining'][seat] -= committed
                expected['accepted'][i] = count
            assert case['actual'] == case['expected'] == expected
            grouped.setdefault((n, width), []).append(case)
        assert len(grouped) == 12
        for (n, width), pair in grouped.items():
            assert len(pair) == 2 and {r['variant'] for r in pair} == {0, 1}
            if n:
                assert pair[0]['actual']['accepted'] != pair[1]['actual']['accepted']
            else:
                assert pair[0]['actual'] == pair[1]['actual']
