"""Observe state commit on its caller stream without introducing a stream join."""
from functools import wraps

try:
    from .logits_device import Capture as EventCapture
except ImportError:
    from logits_device_capture_v1 import Capture as EventCapture


class Capture(EventCapture):
    def wrap(self, original):
        observed = super().wrap(original)

        @wraps(original)
        def commit(output_token_ids, *args, **kwargs):
            with self.lock:
                if self.closed or not self.enabled():
                    return original(output_token_ids, *args, **kwargs)
                shape = output_token_ids.shape
                if len(shape) != 2 or any(type(n) is not int for n in shape):
                    raise ValueError('State commit requires a concrete rank-two shape')
                rows, width = shape
                if not 0 <= rows <= 32 or not 0 < width <= 3:
                    raise ValueError('State commit exceeds qualified MTP2 capacity')
                index = len(self.records)
                try:
                    return observed(output_token_ids, *args, **kwargs)
                finally:
                    if len(self.records) > index:
                        self.records[index]['token_width'] = width
        return commit

    def export(self, anchor):
        result = super().export(anchor)
        result['status'] = 'state_commit_events_pending_device_and_stream_qualification'
        result['limitations'] = [
            'Timing is recorded on the caller stream; no synchronization or stream join is added.',
            'The same-run device anchor must be qualified for cross-stream elapsed-time use.',
            'Shape metadata is observed, not sampled-token values or state tensor contents.',
            'This does not prove closure of model, collective, input-copy or output-copy streams.',
            'No prior-run observations are imported; this is a diagnostic, not a B1 candidate.',
        ]
        return result
