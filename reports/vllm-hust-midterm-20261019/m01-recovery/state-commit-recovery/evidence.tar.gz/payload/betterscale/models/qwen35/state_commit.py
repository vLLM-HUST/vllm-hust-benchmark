"""Commit verified resident progress in one launch, without host readback."""
from vllm.triton_utils import triton, tl


@triton.jit(do_not_specialize=["N"])
def commit(TOKENS, SEATS, DRAFTS, SAMPLING, SCHEDULED, VERIFY,
           RECURRENT, CONV, REMAINING, ACCEPTED, N,
           TOKEN_STRIDE: tl.constexpr, COL_STRIDE: tl.constexpr,
           WIDTH: tl.constexpr, COLS: tl.constexpr, ROWS: tl.constexpr):
    row = tl.arange(0, ROWS)
    col = tl.arange(0, COLS)
    live = row < N
    token = tl.load(TOKENS + row[:, None] * TOKEN_STRIDE + col[None, :] * COL_STRIDE,
                    live[:, None] & (col[None, :] < WIDTH), other=-1)
    accepted = tl.sum((token != -1).to(tl.int32), axis=1)
    seat = tl.load(SEATS + row, live, other=0)
    remaining = tl.load(REMAINING + seat, live, other=0)
    committed = tl.minimum(accepted, remaining)
    scheduled = tl.load(SCHEDULED + row, live, other=0)
    drafts = tl.load(DRAFTS + row, live, other=0)
    selected = (scheduled - drafts + committed - 1).to(tl.int32)
    verify = tl.load(VERIFY + row, live, other=0).to(tl.int1)
    sampling = tl.load(SAMPLING + row, live, other=0).to(tl.int1)
    writable = remaining > 0
    # Inactive/terminal resident selections remain untouched, including rows
    # outside this wave. SEATS are unique by the resident scheduler contract.
    tl.store(RECURRENT + seat, selected, live & verify & writable)
    tl.store(CONV + seat, tl.where(verify, selected, 1), live & writable)
    tl.store(REMAINING + seat, remaining - tl.where(sampling, committed, 0), live)
    tl.store(ACCEPTED + row, accepted, live)


def publish(runner, output_token_ids):
    root, ingress = runner._live_state_root, runner._live_ingress
    n, width = output_token_ids.shape
    capacity = runner.scheduler_config.max_num_seqs
    if not 0 <= n <= capacity or not 0 < width <= root.capacity.speculative_tokens + 1:
        raise ValueError("Resident commit requires live MTP rows within configured capacity")
    if n == 0:
        return
    commit[(1,)](
        output_token_ids, ingress.seats, ingress.drafts, ingress.sampling,
        runner.num_scheduled_tokens.gpu, runner._live_verify_roles,
        root.continuation.selection.tensor, root.conv_selection.tensor,
        root.remaining_outputs.tensor, runner.num_accepted_tokens.gpu, n,
        TOKEN_STRIDE=output_token_ids.stride(0), COL_STRIDE=output_token_ids.stride(1),
        WIDTH=width, COLS=triton.next_power_of_2(width),
        ROWS=triton.next_power_of_2(capacity), num_warps=4,
    )
