"""Admit only exclusive, fresh-process two-card state commit reference measurements."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time

from measure_microflow import descendant, stop

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'state-commit-recovery-r1'
PYTHON = sys.executable


def main():
    OUT.mkdir(exist_ok=False)
    child = None
    locks = []
    receipt = {'status': 'admitting', 'started': time.time(), 'performance_publication': False,
               'purpose': 'Eager state commit recovery numeric qualification with changed-input stale-output checks; no performance publication.'}
    try:
        names = ['run_state_commit_recovery_v1.py', 'run_state_commit_device_v1.py',
                 'prepare_state_commit_recovery_v1.py', 'state_commit_recovery_v1.sh',
                 'triton-candidate-import-r1/receipt.json', 'qualify_state_commit_device_v1.py',
                 'state_commit_device_capture_v1.py', 'logits_device_capture_v1.py',
                 'payload-receipt.json', 'payload/betterscale/models/qwen35/state_commit.py',
                 'prepare_state_commit_qualification_v1.py', 'measure_microflow.py']
        receipt['source_sha256'] = {str(ROOT / name): hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}
        receipt['protocol'] = {'prior_cache_imported': False, 'rows': [0, 1, 24, 32],
                               'widths': [1, 2, 3], 'variants': [0, 1], 'cards': 2,
                               'model_qualification': False, 'cross_device_clock_qualification': False}
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for index in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            (OUT / f'npu-before-{index}.txt').write_text(smi)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
            time.sleep(2)
        with socket.socket() as port:
            port.bind(('127.0.0.1', 18501))
        cache = Path('/workspace/state-commit-recovery-cache-r1')
        cache.mkdir(exist_ok=False)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT) + ':' + os.environ['PYTHONPATH'],
                   ASCEND_RT_VISIBLE_DEVICES='0,1', OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4',
                   XDG_CACHE_HOME=str(cache / 'xdg'), TRITON_CACHE_DIR=str(cache / 'triton'),
                   TORCHINDUCTOR_CACHE_DIR=str(cache / 'inductor'), VLLM_CACHE_ROOT=str(cache / 'vllm'))
        with (OUT / 'child.log').open('x') as log, (OUT / 'device-samples.jsonl').open('x') as samples:
            child = subprocess.Popen([PYTHON, str(Path(__file__)), '--child'], env=env,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            receipt['child_pid'] = child.pid
            deadline = time.monotonic() + 2700
            while child.poll() is None:
                assert time.monotonic() < deadline, 'state commit reference deadline exceeded'
                smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps({'wall': time.time(), 'raw': smi}) + '\n')
                samples.flush()
                for match in re.finditer(r'\|\s*[4-7]\s+0\s*\|\s*(\d+)\s*\|', smi):
                    pid = int(match[1])
                    try:
                        owned = os.getpgid(pid) == child.pid or descendant(pid, {child.pid})
                    except ProcessLookupError:
                        continue
                    assert owned, f'Foreign NPU context {pid}; reference not admitted'
                time.sleep(2)
        receipt['exit_code'] = child.returncode
        assert child.returncode == 0
        receipt['status'] = 'state_commit_qualification_completed_pending_audit'
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        receipt['cleanup_exit_code'] = stop(child)
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (OUT / 'npu-after.txt').write_text(smi)
        receipt['all_four_idle_after'] = all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
        receipt['ended'] = time.time()
        with (OUT / 'receipt.json').open('x') as stream:
            json.dump(receipt, stream, indent=2)
            stream.write('\n')
        for stream in locks:
            stream.close()
    print(json.dumps(receipt))
    return 0 if receipt['status'] == 'state_commit_qualification_completed_pending_audit' and receipt['all_four_idle_after'] else 1


if __name__ == '__main__':
    if sys.argv[1:] == ['--child']:
        from qualify_state_commit_device_v1 import run
        run(OUT)
    else:
        raise SystemExit(main())
