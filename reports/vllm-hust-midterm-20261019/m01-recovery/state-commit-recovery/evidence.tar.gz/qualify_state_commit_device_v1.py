"""Two-device numeric and cross-stream-event qualification of pinned commit."""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace as NS
import time

ROOT = Path(__file__).resolve().parent


def worker(rank, output):
    import torch
    import torch_npu  # noqa: F401
    from state_commit_device_capture_v1 import Capture

    torch.set_num_threads(4)
    torch.npu.set_device(rank)
    device = f'npu:{rank}'
    path = ROOT / 'payload/betterscale/models/qwen35/state_commit.py'
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == json.loads((ROOT / 'payload-receipt.json').read_text())['payload_hashes']['models/qwen35/state_commit.py']
    spec = importlib.util.spec_from_file_location('qualified_state_commit', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    producer = torch.npu.current_stream()
    consumer = torch.npu.Stream()
    assert producer.npu_stream != consumer.npu_stream
    consumer.wait_stream(producer)
    torch.npu.synchronize()
    anchor = torch.npu.Event(enable_timing=True)
    before = time.time()
    anchor.record(producer)
    anchor.synchronize()
    after = time.time()
    capture = Capture(torch.npu, lambda: True, capacity=24)
    cases = []
    for n in (0, 1, 24, 32):
        for width in (1, 2, 3):
            for variant in (0, 1):
                seats = list(reversed(range(n)))
                remaining = [i % 4 for i in range(32)]
                verify = [i % 2 == 0 for i in range(n)]
                sampling = [i % 3 != 0 for i in range(n)]
                values = [[100 + j if j < (i + variant) % (width + 1) else -1
                           for j in range(width)] for i in range(n)]
                def tensor(values, dtype=torch.int32):
                    return torch.tensor(values, dtype=dtype, device=device)
                recurrent = tensor([-7] * 32)
                conv = tensor([-8] * 32)
                remaining_device = tensor(remaining)
                accepted = tensor([-9] * 32)
                runner = NS(
                    scheduler_config=NS(max_num_seqs=32),
                    _live_state_root=NS(capacity=NS(speculative_tokens=2),
                        continuation=NS(selection=NS(tensor=recurrent)),
                        conv_selection=NS(tensor=conv),
                        remaining_outputs=NS(tensor=remaining_device)),
                    _live_ingress=NS(seats=tensor(seats, torch.int64), drafts=tensor([2] * n),
                                     sampling=tensor(sampling, torch.bool)),
                    num_scheduled_tokens=NS(gpu=tensor([5] * n)),
                    _live_verify_roles=tensor(verify, torch.bool),
                    num_accepted_tokens=NS(gpu=accepted))
                # Strided token columns exercise production stride parameters.
                storage = torch.full((n, width * 2), -1, dtype=torch.int64, device=device)
                tokens = storage[:, ::2]
                if n:
                    tokens.copy_(tensor(values, torch.int64))
                ready = torch.npu.Event()
                ready.record(producer)
                expected = {'recurrent': [-7] * 32, 'conv': [-8] * 32,
                            'remaining': remaining.copy(), 'accepted': [-9] * 32}
                for i, seat in enumerate(seats):
                    count = sum(token != -1 for token in values[i])
                    committed = min(count, remaining[seat])
                    selected = 5 - 2 + committed - 1
                    if remaining[seat] > 0:
                        if verify[i]:
                            expected['recurrent'][seat] = selected
                        expected['conv'][seat] = selected if verify[i] else 1
                    expected['remaining'][seat] -= committed if sampling[i] else 0
                    expected['accepted'][i] = count
                with torch.npu.stream(consumer):
                    consumer.wait_event(ready)
                    capture.wrap(lambda value: module.publish(runner, value))(tokens)
                consumer.synchronize()
                actual = {name: value.cpu().tolist() for name, value in
                          [('recurrent', recurrent), ('conv', conv),
                           ('remaining', remaining_device), ('accepted', accepted)]}
                assert actual == expected, (rank, n, width, variant)
                cases.append({'rows': n, 'width': width, 'variant': variant,
                              'tokens': values, 'seats': seats, 'verify': verify,
                              'sampling': sampling, 'initial_remaining': remaining,
                              'expected': expected, 'actual': actual})
    torch.npu.synchronize()
    evidence = capture.export(anchor)
    assert len(evidence['records']) == len(cases) == 24
    assert all(r['stream_before'] == r['stream_after'] == consumer.npu_stream for r in evidence['records'])
    evidence.update(status='pinned_state_commit_numeric_and_cross_stream_events_passed',
                    rank=rank, producer_stream=producer.npu_stream, consumer_stream=consumer.npu_stream,
                    anchor_host_bracket=[before, after], cases=cases,
                    source_sha256={str(path): digest},
                    model_qualification=False, performance_publication=False,
                    qualification_scope='Independent streams on each device; no claim of cross-device clock alignment, model graph replay or complete model closure.')
    with (Path(output) / f'rank-{rank}.json').open('x') as stream:
        json.dump(evidence, stream, indent=2)
        stream.write('\n')


def run(output):
    import torch.multiprocessing as mp
    mp.spawn(worker, args=(str(output),), nprocs=2, join=True)
