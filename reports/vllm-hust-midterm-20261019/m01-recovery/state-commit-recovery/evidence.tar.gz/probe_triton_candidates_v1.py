"""Verify cached candidate artifacts and import in independent interpreters."""
import base64
import csv
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'triton-candidate-import-r1'
CANDIDATES = (
    Path('/root/.cache/uv/archive-v0/X6ZYEyhyj7UP92GM'),
    Path('/root/.cache/uv/archive-v0/BD6jpype2qcK6WP9'),
)


def verify_record(root):
    record, = root.glob('triton_ascend-*.dist-info/RECORD')
    verified = 0
    unchecked = []
    for name, digest, size in csv.reader(record.open()):
        path = (root / name).resolve()
        assert path.is_relative_to(root.resolve()), name
        if not digest:
            unchecked.append(name)
            continue
        algorithm, expected = digest.split('=', 1)
        assert algorithm == 'sha256'
        hasher = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                hasher.update(block)
        assert base64.urlsafe_b64encode(hasher.digest()).decode().rstrip('=') == expected, name
        assert path.stat().st_size == int(size), name
        verified += 1
    return dict(record_sha256=hashlib.sha256(record.read_bytes()).hexdigest(),
                verified_files=verified, unchecked_files=unchecked)


def main():
    OUT.mkdir(exist_ok=False)
    results = []
    for root in CANDIDATES:
        row = dict(candidate=str(root), integrity=verify_record(root))
        result_path = OUT / (root.name + '.json')
        code = '''import importlib.metadata as m
import json
import triton
import vllm.entrypoints.cli.main
import vllm_ascend.worker.worker as w
from pathlib import Path
result = dict(triton_module=triton.__file__, triton_module_version=triton.__version__,
              triton_distribution=m.version('triton-ascend'), worker=w.__file__,
              worker_class=w.NPUWorker.__name__)
with Path(OUTPUT).open('x') as stream:
    json.dump(result, stream, indent=2)
'''.replace('OUTPUT', repr(str(result_path)))
        env = dict(os.environ, PYTHONPATH=str(root) + ':' + os.environ['PYTHONPATH'])
        with (OUT / (root.name + '.log')).open('x') as log:
            try:
                process = subprocess.run([sys.executable, '-c', code], env=env,
                                         stdout=log, stderr=subprocess.STDOUT, timeout=180)
                row['exit_code'] = process.returncode
            except subprocess.TimeoutExpired:
                row['exit_code'] = 124
        if result_path.exists():
            row['actual_imports'] = json.loads(result_path.read_text())
        results.append(row)
    report = dict(status='candidate_import_diagnostic_not_admission', results=results,
                  original_runtime_identity_proven=False, model_service_launched=False,
                  limitations=['RECORD validates local artifact consistency, not publisher authenticity.',
                               'No model, numerical, graph or performance qualification.'])
    with (OUT / 'receipt.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report, indent=2))
    return int(any(row['exit_code'] != 0 for row in results))


if __name__ == '__main__':
    raise SystemExit(main())
