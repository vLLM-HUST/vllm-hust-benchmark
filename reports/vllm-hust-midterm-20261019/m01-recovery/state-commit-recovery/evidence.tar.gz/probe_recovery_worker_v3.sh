#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH LD_PRELOAD
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
ROOT=/root/gennova-evidence/20261019-midterm-aligned
SITE=/root/modcost-runtime-028-20261017/usr/local/python3.12.13/lib/python3.12/site-packages
export PYTHONPATH=$ROOT/compat:$ROOT/runtime:/root/modcost-runtime-028-20261017/vllm-workspace/vllm:$SITE
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
exec python "$ROOT/probe_recovery_worker_v3.py"
