"""Known logical-copy volumes; this is not a model-performance measurement."""
import hashlib
import json
from pathlib import Path
import time

import torch
import torch_npu

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "memory-counter-v2"
OUT.mkdir(exist_ok=False)
torch.npu.set_device(0)
sizes = [32768, 33554432, 134217728]
inputs = [torch.full((size // 2,), 7, dtype=torch.bfloat16, device="npu") for size in sizes]
for value in inputs:
    warm = value.clone()
torch.npu.synchronize()
config = torch_npu.profiler._ExperimentalConfig(
    export_type=[torch_npu.profiler.ExportType.Db, torch_npu.profiler.ExportType.Text],
    profiler_level=torch_npu.profiler.ProfilerLevel.Level1,
    aic_metrics=torch_npu.profiler.AiCMetrics.MemoryAccess,
    op_attr=True, l2_cache=True, data_simplification=True,
)
rows = []
outputs = []
with torch_npu.profiler.profile(
    activities=[torch_npu.profiler.ProfilerActivity.CPU, torch_npu.profiler.ProfilerActivity.NPU],
    record_shapes=True, with_stack=False, experimental_config=config,
    on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(OUT / "traces")),
):
    for size, source in zip(sizes, inputs):
        for repeat in range(3):
            with torch.profiler.record_function(f"known_clone_bytes_{size}_repeat_{repeat}"):
                start = time.time()
                value = source.clone()
                torch.npu.synchronize()
                rows.append(dict(bytes=size, repeat=repeat, start=start, end=time.time(),
                                 logical_read_bytes=size, logical_write_bytes=size))
                outputs.append(value)
numerics = [bool(torch.all(value == 7).item()) for value in outputs]
assert all(numerics)
result = dict(
    scope="Single-rank BF16 copy-counter qualification; not physical-HBM certification or model attainment",
    torch_version=torch.__version__, torch_npu_version=torch_npu.__version__,
    rows=rows, numerics=numerics,
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
)
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(dict(copies=len(rows), numerics_passed=all(numerics))))
