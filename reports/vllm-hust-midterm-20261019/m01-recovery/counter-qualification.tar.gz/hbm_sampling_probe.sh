#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
export ASCEND_RT_VISIBLE_DEVICES=0
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
ROOT=/root/gennova-evidence/20261019-midterm-aligned
test ! -e "$ROOT/hbm-sampling-profiler"
exec /usr/local/Ascend/cann-9.1.0/bin/msprof \
  --output="$ROOT/hbm-sampling-profiler" --ai-core=off --task-time=on \
  --sys-hardware-mem=on --sys-hardware-mem-freq=50 \
  --sys-interconnection-profiling=on --sys-interconnection-freq=50 \
  --application="/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python $ROOT/hbm_sampling_probe.py"
