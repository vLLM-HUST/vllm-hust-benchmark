import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import time

from measure_pair import stop

root = Path(__file__).resolve().parent
out = root / "hbm-sampling-control"
out.mkdir(exist_ok=False)
record = dict(started=time.time(), status="admitting", reserved_devices=[4, 5, 6, 7],
              computing_devices=[4], scope="Hardware-memory sampler qualification")
record["input_hashes"] = {
    name: hashlib.sha256((root / name).read_bytes()).hexdigest()
    for name in ("hbm_sampling_probe.py", "hbm_sampling_probe.sh", "run_hbm_sampling_probe.py", "measure_pair.py")
}
locks, child = [], None
try:
    for name in ["/tmp/inference-project-container-model.lock"] + [
        f"/tmp/gennova-device-leases/device-{i}.lock" for i in range(4, 8)
    ]:
        lock = open(name, "a+b")
        locks.append(lock)
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for i in range(3):
        smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
        (out / f"npu-before-{i}.txt").write_text(smi)
        assert all(f"No running processes found in NPU {n}" in smi for n in range(4, 8))
        time.sleep(2)
    with (out / "probe.log").open("x") as log:
        child = subprocess.Popen(["bash", str(root / "hbm_sampling_probe.sh")],
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record["exit_code"] = child.wait(timeout=300)
        assert record["exit_code"] == 0
    record["status"] = "collection_process_completed"
except BaseException as error:
    record.update(status="failed", error=f"{type(error).__name__}: {error}")
finally:
    record["cleanup_exit_code"] = stop(child)
    smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
    (out / "npu-after.txt").write_text(smi)
    record.update(ended=time.time(), all_devices_released=all(
        f"No running processes found in NPU {n}" in smi for n in range(4, 8)))
    (out / "receipt.json").write_text(json.dumps(record, indent=2) + "\n")
    for lock in locks:
        lock.close()
print(json.dumps(record, indent=2))
raise SystemExit(0 if record["status"] == "collection_process_completed" and record["all_devices_released"] else 1)
