import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import time

from measure_pair import stop

root = Path(__file__).resolve().parent
out = root / "memory-counter-v2-control"
out.mkdir(exist_ok=False)
locks = []
child = None
record = dict(started=time.time(), status="admitting", reserved_devices=[4, 5, 6, 7],
              computing_devices=[4], scope="Known-copy counter qualification")
record["input_hashes"] = {
    name: hashlib.sha256((root / name).read_bytes()).hexdigest()
    for name in ("memory_counter_probe_v2.py", "memory_counter_probe_v2.sh", "run_memory_counter_v2.py", "measure_pair.py")
}
try:
    for name in ["/tmp/inference-project-container-model.lock"] + [
        f"/tmp/gennova-device-leases/device-{i}.lock" for i in range(4, 8)
    ]:
        lock = open(name, "a+b")
        locks.append(lock)
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for i in range(3):
        smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
        (out / f"npu-before-{i}.txt").write_text(smi)
        assert all(f"No running processes found in NPU {n}" in smi for n in range(4, 8))
        time.sleep(2)
    with (out / "probe.log").open("x") as log:
        child = subprocess.Popen(["bash", str(root / "memory_counter_probe_v2.sh")],
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record["exit_code"] = child.wait(timeout=300)
        assert record["exit_code"] == 0
    record["status"] = "numerics_and_export_completed"
except BaseException as error:
    record.update(status="failed", error=f"{type(error).__name__}: {error}")
finally:
    record["cleanup_exit_code"] = stop(child)
    smi = subprocess.check_output(["npu-smi", "info"], text=True, timeout=15)
    (out / "npu-after.txt").write_text(smi)
    record.update(ended=time.time(), all_devices_released=all(
        f"No running processes found in NPU {n}" in smi for n in range(4, 8)))
    (out / "receipt.json").write_text(json.dumps(record, indent=2) + "\n")
    for lock in locks:
        lock.close()
print(json.dumps(record, indent=2))
raise SystemExit(0 if record["status"] == "numerics_and_export_completed" and record["all_devices_released"] else 1)
