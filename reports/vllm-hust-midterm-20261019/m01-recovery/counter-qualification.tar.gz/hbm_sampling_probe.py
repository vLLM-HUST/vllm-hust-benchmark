"""Qualify hardware-memory sampling on known, long-enough copy phases."""
import json
from pathlib import Path
import time

import torch
import torch_npu

root = Path(__file__).resolve().parent
out = root / "hbm-sampling-probe"
out.mkdir(exist_ok=False)
torch.npu.set_device(0)
rows = []
for size in (33554432, 134217728):
    source = torch.full((size // 2,), 7, dtype=torch.bfloat16, device="npu")
    dest = torch.empty_like(source)
    for _ in range(5):
        dest.copy_(source)
    torch.npu.synchronize()
    started = time.time()
    count = 0
    while time.time() - started < 3:
        for _ in range(32):
            dest.copy_(source)
        torch.npu.synchronize()
        count += 32
    ended = time.time()
    exact = bool(torch.all(dest == 7).item())
    assert exact
    rows.append(dict(size_bytes=size, copies=count, start_wall=started, end_wall=ended,
                     logical_read_bytes=size * count, logical_write_bytes=size * count,
                     numerics_passed=exact))
    time.sleep(1)
(out / "result.json").write_text(json.dumps(dict(
    scope="Hardware-memory sampler qualification; not model performance",
    phases=rows, torch=torch.__version__, torch_npu=torch_npu.__version__,
), indent=2) + "\n")
print(json.dumps(rows))
