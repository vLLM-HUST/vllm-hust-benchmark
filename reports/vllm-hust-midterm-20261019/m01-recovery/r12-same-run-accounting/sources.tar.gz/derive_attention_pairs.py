"""Derive causal pair counts per metadata group, not whole-model FLOPs."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "microflow-token-accounting-r5"


def causal_pairs(cumulative_q, kv_lengths, actual_tokens):
    assert len(cumulative_q) == len(kv_lengths)
    previous = total_q = pairs = discarded = 0
    for end, kv in zip(cumulative_q, kv_lengths, strict=True):
        assert isinstance(end, int) and end >= previous
        assert isinstance(kv, int) and kv >= 0
        q = max(0, min(end, actual_tokens) - min(previous, actual_tokens))
        discarded += end - previous - q
        if q:
            assert kv >= q, "A valid query segment exceeds its KV extent"
            pairs += q * (kv - q) + q * (q + 1) // 2
            total_q += q
        previous = end
    assert total_q == actual_tokens, "Metadata does not cover the valid extent"
    return {"causal_pairs": pairs, "valid_query_tokens": total_q,
            "excluded_padded_query_tokens": discarded}


def main():
    summary = json.loads((ROOT / "attention-length-summary-r5.json").read_text())
    receipt = json.loads((RUN / "receipt.json").read_text())
    ranks = []
    for rank in summary["ranks"]:
        path = RUN / rank["file"]
        events = [json.loads(line) for line in path.read_text().splitlines()]
        pending, totals = {}, {}
        for event in events:
            if not summary["request_phase"]["start_wall"] <= event["wall"] <= receipt["bench_ended_wall"]:
                continue
            if event["event"] == "attention_length_snapshot":
                assert event["role"] not in pending
                pending[event["role"]] = event
            elif event["event"] == "forward_enter":
                observed = pending.pop(event["role"])
                if event["role"] == "target":
                    selected = [("target", observed["metadata"], event["actual_tokens"])]
                else:
                    selected = [(f"draft_step{index}", groups,
                                 event["draft_steps"][index]["actual_tokens"])
                                for index, groups in enumerate(observed["draft_steps"])]
                for role, groups, actual in selected:
                    assert len(groups) == 1, "Multiple distinct metadata groups need explicit accounting"
                    group = groups[0]
                    assert group["cpu_seq_lens"] == group["device_seq_lens"]
                    assert group["cpu_cumulative_query_lengths"] == group["device_query_start_loc"][1:]
                    counts = causal_pairs(group["cpu_cumulative_query_lengths"],
                                          group["cpu_seq_lens"], actual)
                    total = totals.setdefault(role, {"contexts": 0, **{key: 0 for key in counts}})
                    total["contexts"] += 1
                    for key, value in counts.items():
                        total[key] += value
        assert not pending
        ranks.append({"rank": rank["rank"], "roles": totals,
                      "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    assert ranks[0]["roles"] == ranks[1]["roles"]
    output = {
        "status": "causal_pairs_derived_from_valid_extents",
        "ranks": ranks, "model_effective_flops": None,
        "formula": "sum(q*(kv-q)+q*(q+1)/2), with q clipped to the observed actual-token extent",
        "limitations": [
            "These are causal semantic pair counts per metadata group, not executed kernel arithmetic.",
            "Metadata layer aliases are not multiplied; actual layer/head mapping requires separate source verification.",
            "Masked/padded implementation work and custom softmax arithmetic are not included.",
            "This synchronized diagnostic is not an uninstrumented performance measurement.",
        ],
    }
    with (ROOT / "attention-pairs-summary-r5.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
