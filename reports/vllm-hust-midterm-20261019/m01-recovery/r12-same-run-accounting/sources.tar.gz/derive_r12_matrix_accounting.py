"""Recompute same-run matrix subtotals, separating definite request work and tail."""
import ast
import hashlib
import json
from pathlib import Path

from audit_deferred_model_capture import audit as audit_capture
from derive_attention_pairs import causal_pairs
from derive_moe_projection_accounting_r9 import projection_counts
from derive_partial_operator_accounting_r9 import attention_qk_av, projection
from recover_model_hardware import request_phase

ROOT = Path(__file__).resolve().parent
RUN = Path("/workspace/gennova-measurements/microflow-token-accounting-r12")
MODEL = Path("/models/Qwen3.5-35B-A3B/config.json")


def main():
    receipt = json.loads((RUN / "receipt.json").read_text())
    assert receipt["status"] == "measured" and receipt["all_devices_released"]
    phase = request_phase(receipt, json.loads((RUN / "mmlu-pro.json").read_text()))
    paths = sorted(RUN.glob("moe-deferred-*.json"))
    assert len(paths) == 2
    raw = []
    pins = {}
    for path in paths:
        audit_capture(path)
        pins[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        raw.append(json.loads(path.read_text()))
    assert len(raw[0]["frames"]) == len(raw[1]["frames"])
    # ALLGATHER/TP2 replicates routing; it is not an additional model-work axis.
    assert raw[0]["layers"] == raw[1]["layers"]
    config = json.loads(MODEL.read_text())["text_config"]
    hidden = config["hidden_size"]
    assert hidden == 2048 and config["num_hidden_layers"] == 40
    fa = config["layer_types"].count("full_attention")
    gdn = config["layer_types"].count("linear_attention")
    assert (fa, gdn, config["mtp_num_hidden_layers"]) == (10, 30, 1)
    assert config["attn_output_gate"] is True
    dispatcher = ROOT / "runtime/vllm_ascend/ops/fused_moe/token_dispatcher.py"
    tree = ast.parse(dispatcher.read_text())
    active = [
        kw.value for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        and node.func.attr == "npu_moe_init_routing"
        for kw in node.keywords if kw.arg == "active_num"
    ]
    assert len(active) == 1
    assert ast.dump(active[0]) == ast.dump(ast.parse("num_tokens * self.top_k", mode="eval").body)
    for path in paths:
        pid = path.stem.removeprefix("moe-deferred-")
        trace = RUN / f"token-accounting-{pid}.jsonl"
        events = [json.loads(line) for line in trace.read_text().splitlines()]
        inventory = next(row for row in events if row["event"] == "loaded_model_inventory")
        pins[str(trace)] = hashlib.sha256(trace.read_bytes()).hexdigest()
        for role, layers in (("target", 40), ("draft", 1)):
            modules = inventory[role]["modules"]
            routed = [m for m in modules if m["type"].endswith(".AscendRoutedExperts")]
            assert len(routed) == layers
            for module in routed:
                cfg = module["objects"]["moe_config"]["scalars"]
                assert cfg["ep_size"] == 1 and cfg["tp_size"] == 2
                assert cfg["num_experts"] == 256 and cfg["is_sequence_parallel"] is False
                assert module["scalars"]["top_k"] == 8
                assert module["parameters"]["w13_weight"]["shape"] == [256, 2048, 512]
                assert module["parameters"]["w2_weight"]["shape"] == [256, 256, 2048]
            for suffix, expected in (
                (".shared_expert.gate_up_proj", [512, 2048]),
                (".shared_expert.down_proj", [2048, 256]),
                (".mlp.gate", [256, 2048]),
                (".mlp.shared_expert_gate", [1, 2048]),
            ):
                matches = [m for m in modules if m["name"].endswith(suffix)]
                assert len(matches) == layers
                assert all(m["parameters"]["weight"]["shape"] == expected for m in matches)
    cohorts = {key: {"roles": {}, "device_routed_rows_including_padding": 0}
               for key in ("definitely_inside_request_interval", "tail_or_boundary")}
    cursors = {"target": 0, "draft": 0}
    for frames in zip(raw[0]["frames"], raw[1]["frames"], strict=True):
        assert frames[0]["role"] == frames[1]["role"]
        role = frames[0]["role"]
        fields = frames[0]["fields"]
        for key in ("actual_tokens", "padded_tokens", "draft_steps",
                    "host_attention_lengths", "host_draft_lengths"):
            assert fields[key] == frames[1]["fields"][key], key
        assert fields["moe_context"]["type"] == "MoECommType.ALLGATHER"
        inside = all(
            record["anchor_host_bracket"][0] + frame["start_ms"] / 1000 - .002 >= phase["start_wall"]
            and record["anchor_host_bracket"][1] + frame["end_ms"] / 1000 + .002 <= phase["end_wall"]
            for record, frame in zip(raw, frames)
        )
        cohort = cohorts["definitely_inside_request_interval" if inside else "tail_or_boundary"]
        steps = [("target", fields["host_attention_lengths"], fields["actual_tokens"])] if role == "target" else [
            (f"draft_step{i}", groups, fields["draft_steps"][i]["actual_tokens"])
            for i, groups in enumerate(fields["host_draft_lengths"])
        ]
        for key, groups, actual in steps:
            assert len(groups) == 1
            group = groups[0]
            assert group["device_seq_lens"] is group["device_query_start_loc"] is None
            counts = causal_pairs(group["cpu_cumulative_query_lengths"], group["cpu_seq_lens"], actual)
            total = cohort["roles"].setdefault(key, {"contexts": 0, **dict.fromkeys(counts, 0)})
            total["contexts"] += 1
            for name, value in counts.items():
                total[name] += value
        start = cursors[role]
        cursors[role] += len(steps)
        for layer in raw[0]["layers"]:
            if layer["role"] == role:
                cohort["device_routed_rows_including_padding"] += sum(
                    sum(groups) for groups in layer["group_counts"][start:cursors[role]]
                )
    for cohort in cohorts.values():
        roles = cohort["roles"]
        target = roles["target"]["valid_query_tokens"]
        draft = sum(roles[f"draft_step{i}"]["valid_query_tokens"] for i in range(2))
        q = config["num_attention_heads"] * config["head_dim"]
        kv = config["num_key_value_heads"] * config["head_dim"]
        gk = config["linear_num_key_heads"] * config["linear_key_head_dim"]
        gv = config["linear_num_value_heads"] * config["linear_value_head_dim"]
        entries = {}
        for role, tokens, layers in (("target", target, fa), ("draft", draft, 1)):
            entries[role + ".attention_qkv_gate"] = projection(tokens, hidden, 2 * q + 2 * kv, layers)
            entries[role + ".attention_output"] = projection(tokens, q, hidden, layers)
        entries["target.gdn_qkvz"] = projection(target, hidden, 2 * gk + 2 * gv, gdn)
        entries["target.gdn_ba"] = projection(target, hidden, 2 * config["linear_num_value_heads"], gdn)
        entries["target.gdn_output"] = projection(target, gv, hidden, gdn)
        entries["draft.input_fusion"] = projection(draft, 2 * hidden, hidden)
        entries["target.causal_qk_av"] = attention_qk_av(roles["target"]["causal_pairs"],
                                                      config["num_attention_heads"], config["head_dim"], fa)
        entries["draft.causal_qk_av"] = attention_qk_av(sum(roles[f"draft_step{i}"]["causal_pairs"] for i in range(2)),
                                                     config["num_attention_heads"], config["head_dim"], 1)
        moe = {}
        for role, tokens, layers in (("target", target, 40), ("draft", draft, 1)):
            moe[role] = projection_counts(tokens, layers, 8, 2, [256, 2048, 512],
                                          [256, 256, 2048], [512, 2048], [2048, 256],
                                          [256, 2048], [1, 2048])
        cohort.update(non_moe_entries=entries, moe=moe)
        cohort["matrix_semantic_subtotal"] = sum(entries.values()) + sum(
            value for row in moe.values() for key, value in row.items() if key.endswith("_flops")
        )
    for path in (MODEL, dispatcher, Path(__file__), ROOT / "derive_attention_pairs.py",
                 ROOT / "derive_moe_projection_accounting_r9.py",
                 ROOT / "derive_partial_operator_accounting_r9.py"):
        pins[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    output = {
        "status": "same_run_source_shaped_matrix_subtotals_with_explicit_tail",
        "cohorts": cohorts, "request_phase": phase, "source_sha256": pins,
        "model_effective_flops": None, "m01_attainment": None,
        "limitations": [
            "Semantic 2MNK matrix arithmetic, not hardware instruction counts or complete F.",
            "Valid routed rows use the source-checked top-8 no-drop contract; per-expert valid/padded separation is not measured.",
            "TP partitions are combined once; duplicated rank routing and router/gate execution are not added twice.",
            "Host causal metadata is not a same-run device-length comparison.",
            "Tail work is retained separately, not asserted useful request work.",
            "Vocabulary, GDN core/convolution, normalization, RoPE, softmax and activations are excluded here.",
        ],
    }
    with (ROOT / "r12-matrix-accounting.json").open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: {"roles": value["roles"], "matrix_semantic_subtotal": value["matrix_semantic_subtotal"]}
                      for key, value in cohorts.items()}, indent=2))


if __name__ == "__main__":
    main()
