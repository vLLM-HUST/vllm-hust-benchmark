import copy
import unittest

from integrate_r12_hardware import link_bounds
from integrate_hbm_samples import integrate, has_complete_hbm_coverage


class HardwareBoundsTest(unittest.TestCase):
    def samples(self):
        return [
            {"card": card, "bits": 64, "before": {"wall_ns": i * 10},
             "after": {"wall_ns": i * 10 + 1},
             "tx_counts": [i] * 16, "rx_counts": [i * 2] * 16}
            for card in (4, 5) for i in range(7)
        ]

    def test_link_read_brackets(self):
        result = link_bounds(self.samples(), 15, 45)
        self.assertEqual(result["aggregate_tx_bytes"], {"lower": 1280, "upper": 2560})

    def test_counter_reset_rejected(self):
        rows = self.samples()
        rows[3]["tx_counts"][0] = 0
        with self.assertRaises(AssertionError):
            link_bounds(rows, 15, 45)

    def test_missing_endpoint_rejected(self):
        with self.assertRaises(ValueError):
            link_bounds(self.samples(), -1, 45)

    def test_hbm_prorating_and_missing_channel(self):
        samples = [(0, time, 10, channel, direction)
                   for channel in range(4) for direction in ("read", "write")
                   for time in (0, 10, 20, 30)]
        result = integrate(samples, 5, 25)
        self.assertTrue(has_complete_hbm_coverage(result))
        self.assertEqual(result["fully_contained_bytes"], 320 * 8)
        self.assertEqual(result["prorated_bytes"], 640 * 8)
        self.assertEqual(result["intersecting_interval_bytes"], 960 * 8)
        bad = copy.deepcopy(result)
        bad["channels"].pop()
        self.assertFalse(has_complete_hbm_coverage(bad))


if __name__ == "__main__":
    unittest.main()
