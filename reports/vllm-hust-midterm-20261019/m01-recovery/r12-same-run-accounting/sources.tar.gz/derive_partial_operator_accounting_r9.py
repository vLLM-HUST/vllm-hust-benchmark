"""Source-shaped arithmetic subtotal, explicitly not a complete M01 F value."""
import ast
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
SITE = Path('/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/lib/python3.12/site-packages')
MODEL = Path('/models/Qwen3.5-35B-A3B/config.json')

def attention_qk_av(pairs, heads, head_dim, layers):
    assert min(pairs, heads, head_dim, layers) >= 0
    return 4 * pairs * heads * head_dim * layers

def projection(rows, input_dim, output_dim, layers=1):
    assert min(rows, input_dim, output_dim, layers) >= 0
    return 2 * rows * input_dim * output_dim * layers

def main():
    config = json.loads(MODEL.read_text())['text_config']
    assert config['num_hidden_layers'] == len(config['layer_types']) == 40
    fa = config['layer_types'].count('full_attention')
    gdn = config['layer_types'].count('linear_attention')
    assert fa == 10 and gdn == 30 and (config['mtp_num_hidden_layers'] == 1)
    assert config['attn_output_gate'] is True
    source_files = [SITE / 'vllm/model_executor/models/qwen3_5.py', SITE / 'vllm/model_executor/models/qwen3_next.py', SITE / 'vllm/model_executor/models/qwen3_5_mtp.py', SITE / 'vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py', ROOT / 'runtime/vllm_ascend/patch/worker/patch_qwen3_5.py']
    pins = {entry['path']: entry['sha256'] for entry in json.loads((ROOT / 'actual-runtime.json').read_text())['admitted_source_files']}
    sources = {}
    for path in source_files:
        relative = path.relative_to(SITE if path.is_relative_to(SITE) else ROOT / 'runtime').as_posix()
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if relative in pins:
            assert digest == pins[relative], relative
        tree = ast.parse(data.decode())
        sources[relative] = {'sha256': digest, 'matched_existing_admitted_pin': relative in pins, 'classes': [node.name for node in tree.body if isinstance(node, ast.ClassDef)]}
    mtp = ast.parse(source_files[2].read_text())
    decoder_calls = [node for node in ast.walk(mtp) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and (node.func.id == 'Qwen3_5DecoderLayer')]
    assert len(decoder_calls) == 1
    assert any((k.arg == 'layer_type' and isinstance(k.value, ast.Constant) and (k.value.value == 'full_attention') for k in decoder_calls[0].keywords))
    pair_path = ROOT / 'host-attention-pairs-r9.json'
    counts = json.loads(pair_path.read_text())
    assert counts['ranks'][0]['roles'] == counts['ranks'][1]['roles']
    roles = counts['ranks'][0]['roles']
    target_tokens = roles['target']['valid_query_tokens']
    draft_tokens = sum((roles[f'draft_step{i}']['valid_query_tokens'] for i in range(2)))
    hidden = config['hidden_size']
    q_dim = config['num_attention_heads'] * config['head_dim']
    kv_dim = config['num_key_value_heads'] * config['head_dim']
    gdn_key = config['linear_num_key_heads'] * config['linear_key_head_dim']
    gdn_value = config['linear_num_value_heads'] * config['linear_value_head_dim']
    entries = []

    def add(name, rows, k, n, layers):
        entries.append({'name': name, 'rows_per_layer': rows, 'input_dim': k, 'output_dim': n, 'layers': layers, 'semantic_flops': projection(rows, k, n, layers)})
    for role, tokens, layers in (('target', target_tokens, fa), ('draft', draft_tokens, 1)):
        add(f'{role}.full_attention.qkv_with_output_gate', tokens, hidden, 2 * q_dim + 2 * kv_dim, layers)
        add(f'{role}.full_attention.output', tokens, q_dim, hidden, layers)
    add('target.gdn.qkvz', target_tokens, hidden, 2 * gdn_key + 2 * gdn_value, gdn)
    add('target.gdn.ba', target_tokens, hidden, 2 * config['linear_num_value_heads'], gdn)
    add('target.gdn.output', target_tokens, gdn_value, hidden, gdn)
    add('draft.input_fusion', draft_tokens, 2 * hidden, hidden, 1)
    attention = {'target': attention_qk_av(roles['target']['causal_pairs'], config['num_attention_heads'], config['head_dim'], fa), 'draft': attention_qk_av(sum((roles[f'draft_step{i}']['causal_pairs'] for i in range(2))), config['num_attention_heads'], config['head_dim'], 1)}
    output = {'status': 'partial_source_shaped_semantic_accounting', 'scope': 'Whole TP2 model semantic arithmetic, counted once; not sum of duplicated rank metadata.', 'model_config_sha256': hashlib.sha256(MODEL.read_bytes()).hexdigest(), 'counts_source_sha256': hashlib.sha256(pair_path.read_bytes()).hexdigest(), 'sources': sources, 'full_attention_layers': fa, 'gdn_layers': gdn, 'matrix_convention': '2*M*N*K, fused multiply-add counts as two operations', 'projections': entries, 'causal_qk_av_semantic_flops': attention, 'covered_semantic_subtotal': sum((e['semantic_flops'] for e in entries)) + sum(attention.values()), 'model_effective_flops': None, 'attainment_percent': None, 'excluded': ['MoE routed/shared projections, router and shared gates', 'Vocabulary projections until same-run row-to-kernel mapping is confirmed', 'GDN recurrent/chunk arithmetic and convolution', 'RMS normalization, RoPE, softmax, activations and elementwise gates', 'Padding, masked kernel work, communication and TP replicated execution'], 'limitations': ['This is a source-shaped semantic subtotal, not a profiler-complete F or a hardware instruction counter.', 'Historical pin coverage is explicit; newly inspected source files are hashed, not retroactively claimed pinned.', 'No cross-run time denominator or attainment is derived.']}
    with (ROOT / 'partial-operator-accounting-r9.json').open('x') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': output['status'], 'covered_semantic_subtotal': output['covered_semantic_subtotal'], 'attention': attention, 'model_effective_flops': None}, indent=2))
if __name__ == '__main__':
    main()
