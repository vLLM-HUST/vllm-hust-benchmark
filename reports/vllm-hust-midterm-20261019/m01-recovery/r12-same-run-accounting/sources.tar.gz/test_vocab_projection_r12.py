import copy
import unittest

from audit_vocab_projection_r12 import count_rows, projection


class R12VocabTests(unittest.TestCase):
    def events(self):
        return [
            {"event": "target_logits_input", "wall": 1.1, "rows": 3},
            {"event": "forward_enter", "role": "draft", "wall": 1.2,
             "draft_steps": [{"actual_tokens": 3}, {"actual_tokens": 1}]},
            {"event": "draft_replay_input", "wall": 1.3,
             "batch_size": 1, "first_step_sample_indices_rows": 1},
        ]

    def test_tp_partitions_once(self):
        self.assertEqual(projection(7, [[124160, 2048]] * 2), 2 * 7 * 248320 * 2048)

    def test_bad_rows_or_partitions_rejected(self):
        for rows in (-1, True, 1.5):
            with self.assertRaises(AssertionError):
                projection(rows, [[124160, 2048]] * 2)
        with self.assertRaises(AssertionError):
            projection(1, [[248320, 2048]] * 2)

    def test_excludes_initialization(self):
        events = [{"event": "target_logits_input", "wall": 0, "rows": 9000}] + self.events()
        self.assertEqual(count_rows(events, 1, 2)["rows"],
                         {"target": 3, "draft_step0": 1, "draft_step1": 1})

    def test_incomplete_or_misaligned_replay_rejected(self):
        events = self.events()
        with self.assertRaises(AssertionError):
            count_rows(events[:-1], 1, 2)
        corrupt = copy.deepcopy(events)
        corrupt[-1]["batch_size"] = 2
        with self.assertRaises(AssertionError):
            count_rows(corrupt, 1, 2)
        corrupt = copy.deepcopy(events)
        corrupt[-1]["wall"] = 1.15
        with self.assertRaises(AssertionError):
            count_rows(corrupt, 1, 2)


if __name__ == "__main__":
    unittest.main()
