"""Derive nominal MoE projection arithmetic from loaded shapes and routing contract."""
import ast
import hashlib
import json
from pathlib import Path
from audit_token_accounting import request_phase
ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'microflow-token-accounting-r9'

def projection_counts(tokens, layers, top_k, tp, w13, w2, shared_up, shared_down, router, gate):
    assert min(tokens, layers, top_k, tp) >= 0
    assert w13[0] == w2[0] and top_k <= w13[0]
    per_route_per_rank = 2 * (w13[1] * w13[2] + w2[1] * w2[2])
    shared_per_rank = 2 * (shared_up[0] * shared_up[1] + shared_down[0] * shared_down[1])
    return {'nominal_routed_rows_all_layers': tokens * layers * top_k, 'routed_projection_semantic_flops': tokens * layers * top_k * per_route_per_rank * tp, 'shared_projection_semantic_flops': tokens * layers * shared_per_rank * tp, 'router_projection_semantic_flops': tokens * layers * 2 * router[0] * router[1], 'shared_gate_projection_semantic_flops': tokens * layers * 2 * gate[0] * gate[1]}

def main():
    receipt = json.loads((RUN / 'receipt.json').read_text())
    result = json.loads((RUN / 'mmlu-pro.json').read_text())
    assert receipt['status'] == 'measured' and receipt['all_devices_released']
    assert result['completed'] == 200 and result['failed'] == 0
    phase = request_phase(receipt, result)
    dispatcher = ROOT / 'runtime/vllm_ascend/ops/fused_moe/token_dispatcher.py'
    tree = ast.parse(dispatcher.read_text())
    arguments = [kw.value for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and (node.func.attr == 'npu_moe_init_routing') for kw in node.keywords if kw.arg == 'active_num']
    assert len(arguments) == 1
    assert ast.dump(arguments[0]) == ast.dump(ast.parse('num_tokens * self.top_k', mode='eval').body)
    ranks = []
    for path in sorted(RUN.glob('token-accounting-*.jsonl')):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        installed = next((e for e in events if e['event'] == 'observer_installed'))
        inventory = next((e for e in events if e['event'] == 'loaded_model_inventory'))
        enters = [e for e in events if e['event'] == 'forward_enter' and phase['start_wall'] <= e['wall'] <= receipt['bench_ended_wall']]
        assert all((e['moe_context']['type'] == 'MoECommType.ALLGATHER' for e in enters))
        tokens = {'target': sum((e['actual_tokens'] for e in enters if e['role'] == 'target')), 'draft': sum((step['actual_tokens'] for e in enters if e['role'] == 'draft' for step in e['draft_steps']))}
        roles = {}
        for role, layers in (('target', 40), ('draft', 1)):
            modules = inventory[role]['modules']
            routed = [m for m in modules if m['type'].endswith('.AscendRoutedExperts')]
            assert len(routed) == layers
            for module in routed:
                cfg = module['objects']['moe_config']['scalars']
                assert cfg['ep_size'] == 1 and cfg['tp_size'] == 2
                assert cfg['num_experts'] == 256 and cfg['is_sequence_parallel'] is False
                assert module['scalars']['top_k'] == 8
                assert module['parameters']['w13_weight']['shape'] == [256, 2048, 512]
                assert module['parameters']['w2_weight']['shape'] == [256, 256, 2048]
            dimensions = {}
            for suffix, key, expected in [('.shared_expert.gate_up_proj', 'shared_up', [512, 2048]), ('.shared_expert.down_proj', 'shared_down', [2048, 256]), ('.mlp.gate', 'router', [256, 2048]), ('.mlp.shared_expert_gate', 'gate', [1, 2048])]:
                matches = [m for m in modules if m['name'].endswith(suffix)]
                assert len(matches) == layers
                assert all((m['parameters']['weight']['shape'] == expected for m in matches))
                dimensions[key] = expected
            roles[role] = {'valid_context_tokens': tokens[role], 'layers': layers, 'moe_ep_size': 1, 'tp_size': 2, **projection_counts(tokens[role], layers, 8, 2, [256, 2048, 512], [256, 256, 2048], **dimensions)}
        ranks.append({'rank': installed['rank'], 'roles': roles, 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    assert {r['rank'] for r in ranks} == {0, 1}
    assert ranks[0]['roles'] == ranks[1]['roles']
    source_files = [dispatcher, ROOT / 'runtime/vllm_ascend/eplb/core/eplb_utils.py', ROOT / 'runtime/vllm_ascend/ops/fused_moe/routed_experts.py', ROOT / 'runtime/vllm_ascend/device/device_op.py']
    output = {'status': 'nominal_moe_projection_arithmetic_derived', 'ranks': ranks, 'request_phase': phase, 'source_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files + [Path(__file__)]}, 'scope': 'Model-level semantic projection arithmetic; TP partitions combined once, replicated router/gate counted once.', 'assumptions': ['The full-range, non-EP routing operator implements its documented no-capacity-drop contract.', 'Each valid context token has eight expert assignments; expert-count axis is not another multiplier.'], 'actual_routed_rows_measured': None, 'model_effective_flops': None, 'limitations': ['Nominal routed rows are derived from the active routing contract, not sampled device counters.', 'Unselected experts, padding and repeated metadata across ranks are not counted as useful projection work.', 'GDN core, activations, normalization and matched reference remain incomplete.', 'No cross-run subtotal addition, performance substitution or M01 attainment is made.']}
    with (ROOT / 'moe-projection-summary-r9.json').open('x') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': output['status'], 'roles': ranks[0]['roles']}, indent=2))
if __name__ == '__main__':
    main()
