"""Independent raw-frame reconciliation for the unpublished r12 subtotals."""
import hashlib
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = Path("/workspace/gennova-measurements/microflow-token-accounting-r12")


class MatrixEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.summary = json.loads((ROOT / "r12-matrix-accounting.json").read_text())
        cls.raw = [
            json.loads(path.read_text())
            for path in sorted(RUN.glob("moe-deferred-*.json"))
        ]

    def test_source_pins_still_match(self):
        for filename, digest in self.summary["source_sha256"].items():
            with self.subTest(filename=filename):
                self.assertEqual(hashlib.sha256(Path(filename).read_bytes()).hexdigest(), digest)

    def test_device_boundaries_and_all_token_rows_reconciled(self):
        self.assertEqual(len(self.raw), 2)
        self.assertEqual(len(self.raw[0]["frames"]), len(self.raw[1]["frames"]))
        phase = self.summary["request_phase"]
        counts = {name: {} for name in self.summary["cohorts"]}
        for a, b in zip(self.raw[0]["frames"], self.raw[1]["frames"], strict=True):
            self.assertEqual(a["role"], b["role"])
            bounds = [
                (raw["anchor_host_bracket"][0] + frame["start_ms"] / 1000 - .002,
                 raw["anchor_host_bracket"][1] + frame["end_ms"] / 1000 + .002)
                for raw, frame in zip(self.raw, (a, b))
            ]
            inside = min(lo for lo, _ in bounds) >= phase["start_wall"] and (
                max(hi for _, hi in bounds) <= phase["end_wall"]
            )
            bucket = counts["definitely_inside_request_interval" if inside else "tail_or_boundary"]
            fields = a["fields"]
            if a["role"] == "target":
                steps = [("target", fields["actual_tokens"])]
            else:
                steps = [(f"draft_step{i}", step["actual_tokens"])
                         for i, step in enumerate(fields["draft_steps"])]
            for role, tokens in steps:
                item = bucket.setdefault(role, [0, 0])
                item[0] += 1
                item[1] += tokens
        for cohort, roles in counts.items():
            for role, (contexts, tokens) in roles.items():
                reported = self.summary["cohorts"][cohort]["roles"][role]
                self.assertEqual(contexts, reported["contexts"])
                self.assertEqual(tokens, reported["valid_query_tokens"])

    def test_routing_not_double_counted_or_tail_discarded(self):
        self.assertEqual(self.raw[0]["layers"], self.raw[1]["layers"])
        all_rows = sum(
            sum(group)
            for layer in self.raw[0]["layers"]
            for group in layer["group_counts"]
        )
        self.assertEqual(all_rows, sum(
            c["device_routed_rows_including_padding"]
            for c in self.summary["cohorts"].values()
        ))
        self.assertGreater(self.summary["cohorts"]["tail_or_boundary"]["matrix_semantic_subtotal"], 0)

    def test_routed_projection_from_global_expert_shape(self):
        for cohort in self.summary["cohorts"].values():
            for role, layers in (("target", 40), ("draft", 1)):
                tokens = (cohort["roles"]["target"]["valid_query_tokens"] if role == "target"
                          else sum(cohort["roles"][f"draft_step{i}"]["valid_query_tokens"]
                                   for i in range(2)))
                # Global intermediate size is 512: gate/up and down, top-8.
                expected = 2 * tokens * layers * 8 * (2048 * 1024 + 512 * 2048)
                self.assertEqual(cohort["moe"][role]["routed_projection_semantic_flops"], expected)
            components = list(cohort["non_moe_entries"].values()) + [
                value for item in cohort["moe"].values()
                for name, value in item.items() if name.endswith("_flops")
            ]
            self.assertEqual(sum(components), cohort["matrix_semantic_subtotal"])
        self.assertIsNone(self.summary["model_effective_flops"])
        self.assertIsNone(self.summary["m01_attainment"])


if __name__ == "__main__":
    unittest.main()
