"""Launch the original text configuration using the isolated rebuilt host adapter."""
import json
import os
from pathlib import Path
from betterscale.models.qwen35.launch import prepare

ROOT = Path(__file__).resolve().parent
command, env = prepare(
    model=Path('/models/Qwen3.5-35B-A3B'), devices='0,1', port=18390,
    cache_dir=Path('/workspace/midterm-b1-e32-r36-20261019'), runtime_dir=ROOT / 'runtime', context_tokens=65536,
    state_budget_bytes=21474836480, served_model_name='qwen3.5-35b',
    distributed_port=29670, execution_seats=32, resident_seats=36,
    mtp_tokens=2, max_images=0,
)
(ROOT / 'launch-candidate-command.json').write_text(json.dumps(command, indent=2) + '\n')
os.execvpe(command[0], command, env)
