#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
export ASCEND_RT_VISIBLE_DEVICES=0,1
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector
export VLLM_WORKER_MULTIPROC_METHOD=spawn
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
export VLLM_CACHE_ROOT=/root/midterm-run-20261019/cache
export TRITON_CACHE_DIR=/root/midterm-run-20261019/triton-cache
export TORCHINDUCTOR_CACHE_DIR=/root/midterm-run-20261019/inductor-cache
exec /workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python /root/midterm-run-20261019/measure.py "$@"
