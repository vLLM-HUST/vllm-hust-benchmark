"""Dedicated internal long-input baseline. Never connects to an existing service."""
import argparse
import asyncio
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
MODEL = '/models/Qwen3.5-35B-A3B'
ENGINE = dict(model=MODEL, tensor_parallel_size=2, dtype='bfloat16',
    max_model_len=32768, max_num_seqs=16, max_num_batched_tokens=4095,
    gpu_memory_utilization=0.9, seed=17, enable_prefix_caching=True,
    mamba_cache_mode='align', enable_chunked_prefill=True, async_scheduling=True,
    limit_mm_per_prompt={'image':0,'video':0}, additional_config={'enable_cpu_binding':False},
    compilation_config={'cudagraph_mode':'FULL_DECODE_ONLY',
        'cudagraph_capture_sizes':[1,2,4,8,16], 'max_cudagraph_capture_size':16,
        'pass_config':{'enable_sp':False}}, kv_cache_memory_bytes=17179869184,
    speculative_config=None, enforce_eager=False)

def save(path, data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def prepare():
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
    prompts=[]
    for lane in range(8):
        head=tokenizer.encode(f'Internal synthetic long-context record {lane}.\n',add_special_tokens=False)
        filler=tokenizer.encode(' This is a synthetic engineering log. No production data is included.\n',add_special_tokens=False)
        tail=tokenizer.encode('\nSummarize the engineering log in a detailed paragraph.\nSummary:',add_special_tokens=False)
        ids=(head+filler*4096)[:16384-len(tail)]+tail
        assert len(ids)==16384
        prompts.append(ids)
    versions={k:importlib.metadata.version(k) for k in ['vllm','vllm-ascend','torch','torch-npu','transformers']}
    import vllm, vllm_ascend
    plan=dict(schema='vllm-hust-internal-long-input-v1',arm='B0-native-runtime',
        project='vLLM-HUST',scope='Synthetic serving supplement, not dataset quality or full acceptance',
        engine=ENGINE,packages=versions,imports={'vllm':vllm.__file__,'vllm_ascend':vllm_ascend.__file__},
        prompt_tokens=16384,concurrency=8,qualification_seconds=60,measurement_seconds=300,
        request_timeout_seconds=180,max_tokens=256,temperature=0,seed=17,
        thinking='raw completion; no chat-template thinking toggle',
        cache_policy='One fixed salt per lane; reuse within qualification and measurement; arm starts fresh',
        timing='Async engine output arrival, not HTTP end-to-end; chunks may contain several tokens',
        input_sha256=hashlib.sha256(json.dumps(prompts).encode()).hexdigest(),
        model_config_sha256=hashlib.sha256((Path(MODEL)/'config.json').read_bytes()).hexdigest(),
        candidate=None,currency_cost=None)
    save(ROOT/'inputs.json',prompts)
    save(ROOT/'plan.json',plan)
    print('PREPARED: 8 synthetic inputs, exactly 16384 tokens each; pinned runtime metadata',flush=True)

def quantile(values,p):
    return sorted(values)[math.ceil(len(values)*p)-1] if values else None

def summarize(records,start,seconds):
    windows=[]
    for i in range(math.ceil(seconds/60)):
        a=start+i*60;b=min(start+seconds,a+60)
        requests=[r for r in records if a<=r['start']<b]
        counts=sum(e['tokens'] for r in records for e in r['events'] if a<=e['time']<b)
        ttft=[r['events'][0]['time']-r['start'] for r in requests if r['success'] and r['events']]
        tpot=[(r['events'][-1]['time']-r['events'][0]['time'])/(r['output_tokens']-1)
              for r in requests if r['success'] and r['output_tokens']>1]
        windows.append(dict(index=i,start=a,end=b,output_tokens=counts,output_tps=counts/(b-a),
            requests=len(requests),failed=sum(not r['success'] for r in requests),
            ttft_n=len(ttft),tpot_n=len(tpot),
            ttft_mean_s=sum(ttft)/len(ttft) if ttft else None,
            tpot_mean_s=sum(tpot)/len(tpot) if tpot else None,
            ttft_p95_s=quantile(ttft,.95),ttft_p99_s=quantile(ttft,.99),
            tpot_p95_s=quantile(tpot,.95),tpot_p99_s=quantile(tpot,.99)))
    return windows

async def measure(out):
    from vllm import SamplingParams
    from vllm.engine.arg_utils import AsyncEngineArgs
    from vllm.v1.engine.async_llm import AsyncLLM
    plan=json.loads((ROOT/'plan.json').read_text());inputs=json.loads((ROOT/'inputs.json').read_text())
    assert plan['engine']==ENGINE
    assert hashlib.sha256(json.dumps(inputs).encode()).hexdigest()==plan['input_sha256']
    out.mkdir(mode=0o700,exist_ok=False)
    save(out/'plan.json',plan)
    llm=None
    records=[]
    try:
        llm=AsyncLLM.from_engine_args(AsyncEngineArgs(**ENGINE))
        print('ENGINE_READY',flush=True)
        save(out/'effective-config.json', {'engine':str(llm.vllm_config) if hasattr(llm,'vllm_config') else 'see engine startup log'})
        params=SamplingParams(temperature=0,max_tokens=256,seed=17)
        async def phase(name,seconds):
            begin=time.monotonic();deadline=begin+seconds
            save(out/(name+'-start.json'),{'monotonic':begin,'wall_time':time.time(),'deadline':deadline})
            async def lane(n):
                index=0
                while time.monotonic()<deadline:
                    request_id=f'{name}-{n}-{index}'
                    r=dict(id=request_id,phase=name,start=time.monotonic(),events=[],output_tokens=0,success=False)
                    try:
                        async with asyncio.timeout(180):
                            last=None
                            async for value in llm.generate({'prompt_token_ids':inputs[n],'cache_salt':f'midterm-lane-{n}'},params,request_id):
                                now=time.monotonic();last=value
                                count=len(value.outputs[0].token_ids)
                                delta=count-r['output_tokens'];assert delta>=0
                                if delta:r['events'].append({'time':now,'tokens':delta})
                                r['output_tokens']=count
                            assert last is not None and last.finished
                            assert len(last.prompt_token_ids)==16384
                            r.update(success=True,actual_input_tokens=len(last.prompt_token_ids),
                                finish_reason=last.outputs[0].finish_reason,
                                output_token_ids=list(last.outputs[0].token_ids),text=last.outputs[0].text)
                    except Exception as error:
                        r['error']=type(error).__name__+': '+str(error)
                        await llm.abort(request_id)
                    r['end']=time.monotonic();records.append(r)
                    with (out/'requests.jsonl').open('a') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n')
                    index+=1
                    if not r['success']:raise RuntimeError('Request failed; retain evidence, stop this arm')
            await asyncio.gather(*(lane(n) for n in range(8)))
            save(out/(name+'-summary.json'),{'start':begin,'measurement_end':deadline,'drain_end':time.monotonic(),
                'windows':summarize([r for r in records if r['phase']==name],begin,seconds)})
            print(name.upper()+'_COMPLETE',flush=True)
        await phase('qualification',60)
        await phase('formal',300)
        save(out/'finished.json',{'completed':True,'requests':len(records),'wall_time':time.time()})
    finally:
        if llm is not None:llm.shutdown()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.prepare:prepare()
    else:
        if args.output is None:parser.error('--output required')
        asyncio.run(measure(args.output))
