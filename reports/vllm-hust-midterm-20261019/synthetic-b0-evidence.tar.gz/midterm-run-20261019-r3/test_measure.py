import unittest
from measure import quantile, summarize

class MeasurementTests(unittest.TestCase):
    def test_quantile(self):
        self.assertIsNone(quantile([],.99))
        self.assertEqual(quantile(list(range(1,101)),.95),95)
        self.assertEqual(quantile(list(range(1,101)),.99),99)

    def test_windows_do_not_count_drain(self):
        rows=[dict(start=0,success=True,output_tokens=4,
                   events=[dict(time=1,tokens=1),dict(time=59,tokens=1),dict(time=60,tokens=1),dict(time=121,tokens=1)]),
              dict(start=61,success=False,output_tokens=1,events=[dict(time=62,tokens=1)])]
        windows=summarize(rows,0,120)
        self.assertEqual([w['output_tokens'] for w in windows],[2,2])
        self.assertEqual([w['requests'] for w in windows],[1,1])
        self.assertEqual([w['failed'] for w in windows],[0,1])
        self.assertEqual(windows[0]['tpot_mean_s'],40)
        self.assertIsNone(windows[1]['tpot_p99_s'])

    def test_empty_window(self):
        result=summarize([],0,60)[0]
        self.assertEqual(result['output_tps'],0)
        self.assertEqual(result['requests'],0)
        self.assertIsNone(result['ttft_p95_s'])

if __name__=='__main__':unittest.main()
