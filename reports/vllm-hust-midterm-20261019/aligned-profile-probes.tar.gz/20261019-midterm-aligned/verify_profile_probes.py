"""Verify known-operation attributes without relabeling hardware work as useful FLOPs."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
result = {}
for name, directory in [('arithmetic','profile-probe-traces'),('memory','profile-memory-probe-traces')]:
    path = next((ROOT / directory).rglob('kernel_details.csv'))
    rows = list(csv.DictReader(path.open()))
    matmuls = [row for row in rows if row['Type'] == 'MatMulV2']
    assert len(matmuls) == 10
    for row in matmuls:
        assert row['Input Shapes'].strip('"') == '64,256;256,256'
        assert row['Output Shapes'].strip('"') == '64,256'
        assert row['Input Data Types'] == 'DT_BF16;DT_BF16'
    item = dict(matmuls=len(matmuls), effective_matmul_flops=10*2*64*256*256,
                shapes_and_dtypes_verified=True, kernel_rows=len(rows), source=str(path))
    if name == 'arithmetic':
        item['reported_hardware_cube_fops'] = sum(float(row['aic_cube_fops']) for row in matmuls)
        item['hardware_fops_equal_effective_flops'] = item['reported_hardware_cube_fops'] == item['effective_matmul_flops']
    else:
        item['reported_gm_read_kb'] = sum(float(row['aic_read_main_memory_datas(KB)']) for row in matmuls)
        item['reported_gm_write_kb'] = sum(float(row['aic_write_main_memory_datas(KB)']) for row in matmuls)
        assert item['reported_gm_read_kb'] > 0 and item['reported_gm_write_kb'] > 0
    result[name] = item
result['scope'] = 'Known BF16 matmul shape/accounting and GM-counter qualification only; no whole-model attainment claim'
result['cautions'] = ['Hardware cube fops include implementation/padding work and are not substituted for effective matrix operations',
                      'GM counters and logical bytes are distinct; neither is silently relabeled physical HBM traffic']
(ROOT / 'profile-probe-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
