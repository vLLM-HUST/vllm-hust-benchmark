#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
export ASCEND_RT_VISIBLE_DEVICES=0,1
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
exec /workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python /root/gennova-evidence/20261019-midterm-aligned/profile_probe.py "$@"
