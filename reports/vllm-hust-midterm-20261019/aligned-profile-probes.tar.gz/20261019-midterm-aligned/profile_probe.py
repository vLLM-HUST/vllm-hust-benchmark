"""Qualify Db operator attributes against known BF16 operations, not model performance."""
import hashlib
import json
from pathlib import Path
import sys
import torch
import torch_npu

ROOT = Path(__file__).resolve().parent
memory = '--memory' in sys.argv[1:]
OUT = ROOT / ('profile-memory-probe-traces' if memory else 'profile-probe-traces')
assert not OUT.exists(), 'Refusing to overwrite profiling evidence'
torch.npu.set_device(0)
a = torch.ones((64, 256), dtype=torch.bfloat16, device='npu')
b = torch.ones((256, 256), dtype=torch.bfloat16, device='npu')
for _ in range(3):
    c = a @ b
torch.npu.synchronize()
config = torch_npu.profiler._ExperimentalConfig(
    export_type=[torch_npu.profiler.ExportType.Db, torch_npu.profiler.ExportType.Text],
    profiler_level=torch_npu.profiler.ProfilerLevel.Level1,
    aic_metrics=(torch_npu.profiler.AiCMetrics.MemoryAccess if memory else torch_npu.profiler.AiCMetrics.ArithmeticUtilization),
    op_attr=True, l2_cache=True, data_simplification=True,
)
assert config._op_attr and torch_npu.profiler.ExportType.Db in config.export_type
with torch_npu.profiler.profile(
    activities=[torch_npu.profiler.ProfilerActivity.CPU, torch_npu.profiler.ProfilerActivity.NPU],
    record_shapes=True, with_flops=True, with_stack=False,
    experimental_config=config,
    on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(OUT), worker_name='known-bf16-probe'),
):
    for _ in range(10):
        c = a @ b
        d = c.clone()
    torch.npu.synchronize()
assert torch.equal(d.cpu(), torch.full((64, 256), 256, dtype=torch.bfloat16))
files = {str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest()
         for p in OUT.rglob('*') if p.is_file()}
(ROOT / ('profile-memory-probe-result.json' if memory else 'profile-probe-result.json')).write_text(json.dumps(dict(
    scope='Known-operation profiler export qualification; not model effective-compute attainment',
    metric='MemoryAccess' if memory else 'ArithmeticUtilization',
    matmuls=10, copies=10, dtype='bfloat16', shape=dict(M=64, N=256, K=256),
    expected_matmul_flops=10*2*64*256*256,
    expected_logical_copy_bytes=10*2*64*256*2,
    numerics_passed=True, op_attr_enabled=config._op_attr, trace_hashes=files,
    exported_counters_verified=False,
), indent=2) + '\n')
print('Known-operation numerics passed; inspect Db attributes before admitting profiler counters.')
