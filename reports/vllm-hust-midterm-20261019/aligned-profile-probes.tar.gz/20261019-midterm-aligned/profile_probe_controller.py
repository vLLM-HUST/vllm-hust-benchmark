"""Reserve all devices for a bounded known-operation profiling probe."""
import fcntl
import json
from pathlib import Path
import subprocess
import sys
import time
from measure_pair import stop

ROOT = Path(__file__).resolve().parent


def main():
    memory = '--memory' in sys.argv[1:]
    out = ROOT / ('profile-memory-probe-control' if memory else 'profile-probe-control')
    out.mkdir(exist_ok=False)
    locks = []
    child = None
    record = dict(scope='profiler qualification, not model performance', started=time.time(), status='admitting')
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4,8)]:
            f = open(name, 'a+b'); locks.append(f)
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for _ in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4,8))
            time.sleep(2)
        (out / 'npu-before.txt').write_text(smi)
        with (out / 'probe.log').open('x') as log:
            command = ['bash', str(ROOT / 'profile-probe.sh')] + (['--memory'] if memory else [])
            child = subprocess.Popen(command, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            record['exit_code'] = child.wait(timeout=300)
            assert record['exit_code'] == 0
        record['status'] = 'numerics_and_export_completed'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['cleanup_exit_code'] = stop(child)
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (out / 'npu-after.txt').write_text(smi)
        record.update(ended=time.time(), all_devices_released=all(f'No running processes found in NPU {i}' in smi for i in range(4,8)))
        (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
        for f in locks:
            f.close()
    print(json.dumps(record, indent=2))
    return 0 if record['status'] == 'numerics_and_export_completed' and record['all_devices_released'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
