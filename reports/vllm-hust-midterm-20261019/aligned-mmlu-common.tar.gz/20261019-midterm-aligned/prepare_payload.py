"""Freeze a qualification-only payload without altering installed packages."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/root/mod-cost-campaign-20261017-0135/sources/BetterScale-v1/src/betterscale')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    target = ROOT / 'payload/betterscale'
    shutil.copytree(SOURCE, target, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    manifest = target / 'patches/qwen_gdn/host_school.json'
    original = json.loads(manifest.read_text())
    host = ROOT / 'build/libbs_gdn_host_cann91.so'
    assert sha(SOURCE / 'patches/qwen_gdn/host.cpp') == original['source_sha256']
    updated = dict(original, sha256=sha(host),
                   qualification='Pending device qualification of unchanged source rebuilt locally; not the October 16 binary')
    manifest.write_text(json.dumps(updated, indent=2) + '\n')
    differences = [str(p.relative_to(target)) for p in target.rglob('*')
                   if p.is_file() and sha(p) != sha(SOURCE / p.relative_to(target))]
    assert differences == ['patches/qwen_gdn/host_school.json'], differences
    (ROOT / 'payload-receipt.json').write_text(json.dumps(dict(
        source=str(SOURCE), original_host_manifest=original, rebuilt_host_manifest=updated,
        modified_files=differences, qualification='pending',
        payload_hashes={str(p.relative_to(target)):sha(p) for p in target.rglob('*') if p.is_file()},
    ), indent=2) + '\n')
    print('Isolated qualification payload prepared; one host-manifest change, device kernels unchanged.')


if __name__ == '__main__':
    main()
