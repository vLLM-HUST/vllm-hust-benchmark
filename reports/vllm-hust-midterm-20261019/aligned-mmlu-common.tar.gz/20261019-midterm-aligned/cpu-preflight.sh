#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
SOURCE=/root/mod-cost-campaign-20261017-0135/sources/BetterScale-v1
PYTHON=/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python
set +u
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
export PYTHONPATH="$SOURCE/src${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
"$PYTHON" -c 'import sys, runpy; sys.path.append("/usr/local/python3.12.13/lib/python3.12/site-packages"); runpy.run_module("pytest", run_name="__main__")' -q -p no:cacheprovider \
  "$SOURCE/tests/test_qwen35_draft_interface.py" \
  "$SOURCE/tests/test_fair_schedule.py" \
  "$SOURCE/tests/test_prefill_round_robin.py" \
  --junitxml="$ROOT/cpu-preflight.xml"
