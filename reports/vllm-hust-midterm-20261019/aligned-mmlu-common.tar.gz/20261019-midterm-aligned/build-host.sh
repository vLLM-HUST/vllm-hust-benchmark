#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
SOURCE=/root/mod-cost-campaign-20261017-0135/sources/BetterScale-v1/src/betterscale/patches/qwen_gdn
PYTHON=/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python
set +u
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
test ! -e "$ROOT/build/libbs_gdn_host_cann91.so"
"$PYTHON" "$SOURCE/build_host.py" "$SOURCE/host.cpp" "$ROOT/build/libbs_gdn_host_cann91.so"
sha256sum "$SOURCE/host.cpp" "$ROOT/build/libbs_gdn_host_cann91.so"
