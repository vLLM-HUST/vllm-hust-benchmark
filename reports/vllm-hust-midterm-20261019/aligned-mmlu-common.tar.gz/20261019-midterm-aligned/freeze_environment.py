"""Record allowlisted runtime identities without reading credentials."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess

ROOT = Path(__file__).resolve().parent
SITE = Path('/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/lib/python3.12/site-packages')
names = {'vllm', 'vllm-ascend', 'torch', 'torch-npu', 'transformers', 'triton-ascend'}
packages = {d.metadata['Name'].lower().replace('_', '-'):d.version
            for d in importlib.metadata.distributions(path=[str(SITE)])
            if d.metadata['Name'].lower().replace('_', '-') in names}
pins = json.loads((ROOT / 'payload/betterscale/qwen35_school_pins.json').read_text())
records = []
for item in pins['source_files']:
    base = ROOT / 'runtime' if item['path'].startswith('vllm_ascend/') else SITE
    actual = hashlib.sha256((base / item['path']).read_bytes()).hexdigest()
    assert actual == item['sha256'], item['path']
    records.append(dict(path=item['path'], sha256=actual))
result = dict(project='vLLM-HUST', packages=packages,
              architecture=platform.machine(), kernel=platform.release(),
              source_commit=subprocess.check_output(['git','-C','/root/mod-cost-campaign-20261017-0135/sources/BetterScale-v1','rev-parse','HEAD'], text=True).strip(),
              admitted_source_files=records, source_pin_count=len(records),
              common_runtime_override='compat/triton_compat.py: distribution-name detection only',
              candidate_host_rebuild=json.loads((ROOT / 'payload-receipt.json').read_text())['rebuilt_host_manifest'],
              weight_identity_scope='Small model/tokenizer files checked against original contract; full weight hashes not collected')
(ROOT / 'actual-runtime.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(packages=packages, admitted_sources=len(records)), indent=2))
