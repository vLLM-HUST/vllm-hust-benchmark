import importlib.util
import json
from pathlib import Path
import unittest
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PreflightTests(unittest.TestCase):
    def test_ascend_distribution(self):
        mod = load('compat', ROOT / 'compat/triton_compat.py')
        def version(name):
            if name == 'triton':
                raise mod.importlib.metadata.PackageNotFoundError(name)
            return '3.6.0'
        with patch.object(mod.importlib.metadata, 'version', side_effect=version):
            self.assertEqual(str(mod._triton_version()), '3.6.0')

    def test_old_distribution(self):
        mod = load('compat', ROOT / 'compat/triton_compat.py')
        with patch.object(mod.importlib.metadata, 'version', return_value='3.2.0'):
            self.assertLess(mod._triton_version(), mod._REAL_GLUON_MIN_VERSION)

    def test_native_kernels_unchanged(self):
        audit = json.loads((ROOT / 'alignment-audit.json').read_text())
        self.assertTrue(audit['libraries']['libbs_gdn.so']['matched'])
        self.assertTrue(audit['libraries']['libbs_fia_owned.so']['matched'])

    def test_recovered_exact_inputs(self):
        import hashlib
        self.assertEqual(hashlib.sha256((ROOT / 'materialized.200.jsonl').read_bytes()).hexdigest(),
                         'fb79b6fa98f232282a948e4a17f404f80c03dc2bae05af57b95b9cc0651b3506')

    def test_percentiles(self):
        mod = load('verify', ROOT / 'verify_pair.py')
        self.assertEqual(mod.percentile([1, 2, 3, 4], .5), 2.5)
        self.assertEqual(mod.percentile([2], .99), 2)

    def test_failed_run_cannot_be_published(self):
        mod = load('verify', ROOT / 'verify_pair.py')
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'run').mkdir()
            (root / 'run/receipt.json').write_text(json.dumps(dict(status='failed', all_devices_released=True)))
            with self.assertRaises(AssertionError):
                mod.verify(root, 'run')

    def test_unreleased_run_cannot_be_published(self):
        mod = load('verify', ROOT / 'verify_pair.py')
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'run').mkdir()
            (root / 'run/receipt.json').write_text(json.dumps(dict(status='measured', all_devices_released=False)))
            with self.assertRaises(AssertionError):
                mod.verify(root, 'run')


if __name__ == '__main__':
    unittest.main()
