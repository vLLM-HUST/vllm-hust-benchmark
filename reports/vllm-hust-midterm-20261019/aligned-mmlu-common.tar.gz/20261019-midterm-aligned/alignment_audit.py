"""Bind replay configuration to the completed dataset run without loading a model."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORTS = Path('/root/vllm-hust-benchmark/reports')
SOURCE = Path('/root/mod-cost-campaign-20261017-0135/sources/BetterScale-v1/src')
SITE = Path('/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/lib/python3.12/site-packages')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    reference_path = REPORTS / 'betterscale-school-runtime-20261016/report.json'
    reference = json.loads(reference_path.read_text())
    contract_path = REPORTS / 'mmlu-pro-qwen35-b0-precheck-20261012/plan/contract.json'
    contract = json.loads(contract_path.read_text())
    libraries = {}
    for name, expected in reference['evidence']['native_sha256'].items():
        relative = ('patches/qwen_fia/context_parallel/' if 'fia' in name
                    else 'patches/qwen_gdn/') + name
        path = SITE / 'betterscale' / relative
        actual = sha(path) if path.is_file() else None
        libraries[name] = dict(path=str(path), expected=expected, actual=actual,
                               matched=actual == expected)
    dataset = Path('/root/vllm-hust-eval-data/pujiang-five/MMLU-Pro/data')
    inputs = {}
    for name, expected in contract['data_sha256'].items():
        path = dataset / (name + '-00000-of-00001.parquet')
        actual = sha(path)
        inputs[name] = dict(path=str(path), expected=expected, actual=actual,
                            matched=actual == expected)
        assert actual == expected, name
    model = {}
    for name, expected in contract['model_files_sha256'].items():
        path = Path('/models/Qwen3.5-35B-A3B') / name
        actual = sha(path)
        model[name] = dict(expected=expected, actual=actual, matched=actual == expected)
        assert actual == expected, name
    sources = []
    for relative, expected in reference['evidence']['tested_code_sha256'].items():
        path = SOURCE / relative
        actual = sha(path) if path.is_file() else None
        if actual != expected:
            sources.append(dict(path=relative, expected=expected, actual=actual))
    result = dict(
        project='vLLM-HUST', scope='Restore chapter-five dataset configuration',
        reference=str(reference_path), reference_sha256=sha(reference_path),
        runtime=reference['runtime'], libraries=libraries, model=model,
        mmlu_inputs=inputs, source_differences=sources,
        performance_input=str(REPORTS / 'mmlu-pro-qwen35-b0-precheck-20261012/bench/materialized.200.cases.json'),
        source_contract_sha256=sha(contract_path),
        measurement_started=False,
        admission='pending host artifact and runtime source checks',
    )
    (ROOT / 'alignment-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'native_matches': {k:v['matched'] for k,v in libraries.items()},
                      'source_differences':[x['path'] for x in sources],
                      'dataset_and_model_checks':'passed'},indent=2))


if __name__ == '__main__':
    main()
