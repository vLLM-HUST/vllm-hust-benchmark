"""Recover the original selected MMLU prompts from pinned parquet inputs."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import urllib.request

sys.path.append('/root/agentx-bench/.venv/lib/python3.12/site-packages')
import pyarrow.parquet as pq
from transformers import AutoTokenizer

ROOT = Path(__file__).resolve().parent
REPORT = Path('/root/vllm-hust-benchmark/reports/mmlu-pro-qwen35-b0-precheck-20261012')
ADAPTER = Path('/root/vllm-hust-benchmark/src/vllm_hust_benchmark/mmlu_pro_pyramidkv.py')
spec = importlib.util.spec_from_file_location('adapter', ADAPTER)
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)
data = Path('/root/vllm-hust-eval-data/pujiang-five/MMLU-Pro/data')
tables = {}
for name, expected in adapter.DATA_HASHES.items():
    path = data / f'{name}-00000-of-00001.parquet'
    adapter.checked(path, expected)
    tables[name] = pq.read_table(path).to_pylist()
url = 'https://raw.githubusercontent.com/TIGER-AI-Lab/MMLU-Pro/' + adapter.REFERENCE_REVISION + '/cot_prompt_lib/initial_prompt.txt'
instruction = urllib.request.urlopen(url, timeout=30).read()
assert hashlib.sha256(instruction).hexdigest() == adapter.INITIAL_PROMPT_HASH
ids = json.loads((REPORT / 'bench/materialized.200.cases.json').read_text())
rows = {f'mmlu-pro-{r["question_id"]:05d}':r for r in tables['test']}
tokenizer = AutoTokenizer.from_pretrained('/models/Qwen3.5-35B-A3B', local_files_only=True)
cases = []
for identity in ids:
    row = rows[identity]
    examples = [r for r in tables['validation'] if r['category'] == row['category']]
    assert len(examples) == 5
    prompt = (instruction.decode().replace('{$}', row['category']) + '\n' +
              ''.join(adapter.format_example(r, answered=True) for r in examples) +
              adapter.format_example(row, answered=False))
    cases.append(dict(case_id=identity, prompt=prompt, output_tokens=256,
                      frozen_prompt_tokens=len(adapter.encode_prompt(tokenizer, prompt))))
totals = {}
for thinking in (True, False):
    totals[str(thinking)] = sum(len(tokenizer.encode(tokenizer.apply_chat_template(
        [dict(role='user', content=c['prompt'])], tokenize=False, add_generation_prompt=True,
        enable_thinking=thinking), add_special_tokens=False)) for c in cases)
(ROOT / 'recovered-mmlu-cases.json').write_text(json.dumps(cases, ensure_ascii=False) + '\n')
materialized = ''.join(json.dumps(dict(prompt=c['prompt']), ensure_ascii=False) + '\n' for c in cases).encode()
expected_materialized = 'fb79b6fa98f232282a948e4a17f404f80c03dc2bae05af57b95b9cc0651b3506'
assert hashlib.sha256(materialized).hexdigest() == expected_materialized
(ROOT / 'materialized.200.jsonl').write_bytes(materialized)
(ROOT / 'input-recovery.json').write_text(json.dumps(dict(
    count=len(cases), source_ids_sha256=hashlib.sha256((REPORT / 'bench/materialized.200.cases.json').read_bytes()).hexdigest(),
    chat_template_token_totals=totals,
    original_bench_reported_input_tokens=282265,
    original_materialized_sha256='fb79b6fa98f232282a948e4a17f404f80c03dc2bae05af57b95b9cc0651b3506',
    materialized_sha256=hashlib.sha256(materialized).hexdigest(),
    status='Exact original materialized JSONL recovered; preserve original bench client wrapping'), indent=2) + '\n')
print(json.dumps(dict(count=len(cases), chat_template_token_totals=totals)))
