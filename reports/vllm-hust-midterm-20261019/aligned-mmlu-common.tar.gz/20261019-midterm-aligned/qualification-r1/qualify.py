"""Bounded device qualification, retaining lifecycle and device evidence."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'qualification-r1'
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def save(value):
    (OUT / 'receipt.json').write_text(json.dumps(value, indent=2) + '\n')


def main():
    OUT.mkdir(exist_ok=False)
    receipt = dict(status='admitting', performance_measurement=False, started=time.time())
    locks = []
    child = None
    try:
        for name in ['/tmp/inference-project-container-model.lock'] + [
                f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b')
            locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for _ in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
            time.sleep(2)
        (OUT / 'npu-before.txt').write_text(smi)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 18390))
        with (OUT / 'service.log').open('x') as log, (OUT / 'device-samples.jsonl').open('x') as samples:
            child = subprocess.Popen(['bash', str(ROOT / 'runtime.sh')], stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            receipt.update(status='starting', pid=child.pid)
            save(receipt)
            deadline = time.monotonic() + 900
            while True:
                if child.poll() is not None:
                    raise RuntimeError(f'Service exited {child.returncode}')
                if time.monotonic() > deadline:
                    raise TimeoutError('Service startup exceeded 900 seconds')
                samples.write(json.dumps(dict(time=time.time(), raw=subprocess.check_output(
                    ['npu-smi', 'info'], text=True, timeout=15))) + '\n')
                samples.flush()
                try:
                    with OPENER.open('http://127.0.0.1:18390/health', timeout=2) as response:
                        if response.status == 200:
                            break
                except OSError:
                    pass
                time.sleep(3)
            body = dict(model='qwen3.5-35b', messages=[dict(role='user', content='What is 2 + 2? Answer with the number only.')],
                        max_tokens=32, temperature=0, seed=17,
                        chat_template_kwargs=dict(enable_thinking=False))
            request = urllib.request.Request('http://127.0.0.1:18390/v1/chat/completions',
                json.dumps(body).encode(), {'Content-Type':'application/json'})
            start = time.monotonic()
            with OPENER.open(request, timeout=120) as response:
                result = json.load(response)
            (OUT / 'smoke.json').write_text(json.dumps(dict(request=body, response=result,
                elapsed=time.monotonic()-start), indent=2) + '\n')
            assert result['usage']['completion_tokens'] > 0
            assert result['choices'][0]['message']['content'].strip() == '4', result['choices']
            receipt.update(status='text_smoke_passed', usage=result['usage'])
    except BaseException as error:
        receipt.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        if child is not None:
            for sig, timeout in [(signal.SIGINT, 90), (signal.SIGTERM, 30), (signal.SIGKILL, 10)]:
                try:
                    os.killpg(child.pid, sig)
                except ProcessLookupError:
                    break
                time.sleep(2)
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    try:
                        os.killpg(child.pid, 0)
                    except ProcessLookupError:
                        break
                    child.poll()
                    time.sleep(1)
                else:
                    continue
                break
            receipt['service_exit_code'] = child.wait(timeout=10)
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            (OUT / 'npu-after.txt').write_text(smi)
            receipt['all_devices_released'] = all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
        receipt['ended'] = time.time()
        save(receipt)
        for stream in locks:
            stream.close()
        files = [p for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS']
        (OUT / 'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in files))
    print(json.dumps(receipt, indent=2))
    return 0 if receipt['status'] == 'text_smoke_passed' and receipt.get('all_devices_released') else 1


if __name__ == '__main__':
    raise SystemExit(main())
