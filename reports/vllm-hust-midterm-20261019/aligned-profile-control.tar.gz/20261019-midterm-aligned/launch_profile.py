"""Launch the original text configuration using the isolated rebuilt host adapter."""
import json
import os
from pathlib import Path
from betterscale.models.qwen35.launch import prepare

ROOT = Path(__file__).resolve().parent
command, env = prepare(
    model=Path('/models/Qwen3.5-35B-A3B'), devices='0,1', port=18390,
    cache_dir=Path('/workspace/midterm-profile-cache-20261019-r2'), runtime_dir=ROOT / 'runtime', context_tokens=65536,
    state_budget_bytes=21474836480, served_model_name='qwen3.5-35b',
    distributed_port=29670, execution_seats=16, resident_seats=36,
    mtp_tokens=2, max_images=0,
)
command += ['--profiler-config', json.dumps(dict(
    profiler='torch', torch_profiler_dir='/workspace/midterm-aligned-profile-20261019-r1',
    torch_profiler_with_flops=True, torch_profiler_record_shapes=True,
    torch_profiler_with_stack=False, ignore_frontend=True,
))]
(ROOT / 'launch-profile-command.json').write_text(json.dumps(command, indent=2) + '\n')
os.execvpe(command[0], command, env)
