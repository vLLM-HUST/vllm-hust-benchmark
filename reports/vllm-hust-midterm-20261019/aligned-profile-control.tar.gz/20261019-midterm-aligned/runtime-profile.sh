#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
ROOT=/root/gennova-evidence/20261019-midterm-aligned
BASE=/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1
SITE=$BASE/lib/python3.12/site-packages
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
export PYTHONPATH=$ROOT/profile-compat:$ROOT/payload${PYTHONPATH:+:$PYTHONPATH}
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export BETTERSCALE_FIA_METADATA=owned BETTERSCALE_STATE_CACHE_HOST_BYTES=8589934592
export BETTERSCALE_GDN_LIBRARY=$SITE/betterscale/patches/qwen_gdn/libbs_gdn.so
export BETTERSCALE_GDN_HOST_LIBRARY=$ROOT/build/libbs_gdn_host_cann91.so
export BETTERSCALE_CP_LIBRARY=$SITE/betterscale/patches/qwen_fia/context_parallel/libbs_fia_owned.so
export TRITON_CACHE_DIR=$ROOT/cache/triton TORCHINDUCTOR_CACHE_DIR=$ROOT/cache/inductor
exec "$BASE/bin/python" "$ROOT/launch_profile.py"
