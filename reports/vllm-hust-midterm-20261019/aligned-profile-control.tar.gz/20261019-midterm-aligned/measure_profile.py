"""Collect instrumented B1 counters; never use this run as a serving comparison."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def stop(child):
    if child is None:
        return None
    for sig, seconds in [(signal.SIGINT, 90), (signal.SIGTERM, 20), (signal.SIGKILL, 10)]:
        try:
            os.killpg(child.pid, sig)
        except ProcessLookupError:
            break
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            child.poll()
            try:
                os.killpg(child.pid, 0)
            except ProcessLookupError:
                break
            time.sleep(1)
        else:
            continue
        break
    return child.wait(timeout=10)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('arm', choices=['b1'])
    parser.add_argument('--run-id', required=True)
    args = parser.parse_args()
    out = ROOT / args.run_id
    out.mkdir(exist_ok=False)
    record = dict(arm=args.arm, status='admitting', started=time.time(),
                  performance_measurement=False, purpose='Instrumented F/B/V coverage audit',
                  allocated_cards=2, reserved_cards=4, simultaneous_other_services=0,
                  protocol='original MMLU 200-request burst, output 256, infinite arrival rate',
                  input_hashes={name:hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                      for name in ['measure_profile.py', 'runtime-profile.sh',
                                   'launch_profile.py', 'bench-profile.sh', 'materialized.200.jsonl', 'payload-receipt.json',
                                   'profile-compat/sitecustomize.py', 'profile-compat/torch_npu_profiler.py', 'compat/triton_compat.py']})
    children = []
    locks = []

    def save():
        (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    try:
        assert not Path('/workspace/midterm-aligned-profile-20261019-r1').exists(), 'Trace destination already exists'
        assert shutil.disk_usage('/workspace').free > 20 * 1024**3
        assert hashlib.sha256((ROOT / 'materialized.200.jsonl').read_bytes()).hexdigest() == 'fb79b6fa98f232282a948e4a17f404f80c03dc2bae05af57b95b9cc0651b3506'
        if args.arm == 'b1':
            qualification = json.loads((ROOT / 'qualification-r2/receipt.json').read_text())
            assert qualification['status'] == 'text_smoke_passed' and qualification['all_devices_released']
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b'); locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for _ in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
            time.sleep(2)
        (out / 'npu-before.txt').write_text(smi)
        assert shutil.disk_usage(ROOT).free > 5 * 1024**3
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', 18390))
        with (out / 'service.log').open('x') as log, (out / 'bench.log').open('x') as bench_log, (out / 'device-samples.jsonl').open('x') as samples:
            server = subprocess.Popen(['bash', str(ROOT / 'runtime-profile.sh')], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append(server)
            record.update(status='starting', service_pid=server.pid); save()
            deadline = time.monotonic() + 1200
            bench = None
            while True:
                assert server.poll() is None, f'Service exited {server.returncode}'
                assert time.monotonic() < deadline, 'Stage timeout'
                assert shutil.disk_usage(ROOT).free > 2 * 1024**3, 'Disk reserve exhausted'
                assert shutil.disk_usage('/workspace').free > 10 * 1024**3, 'Trace reserve exhausted'
                t0 = time.monotonic()
                raw = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps(dict(wall_time=time.time(), start_monotonic=t0, end_monotonic=time.monotonic(), phase=record['status'], raw=raw)) + '\n'); samples.flush()
                assert all(f'No running processes found in NPU {i}' in raw for i in (6, 7)), 'Unrelated device workload appeared'
                owned_groups = {p.pid for p in children}
                for line in raw.splitlines():
                    match = re.match(r'\|\s*[4-7]\s+0\s*\|\s*(\d+)\s*\|', line)
                    if match:
                        try:
                            group = os.getpgid(int(match[1]))
                        except ProcessLookupError:
                            continue
                        assert group in owned_groups, 'Unrelated NPU process appeared; no result admitted'
                if bench is None:
                    try:
                        with OPENER.open('http://127.0.0.1:18390/health', timeout=1) as response:
                            ready = response.status == 200
                    except OSError:
                        ready = False
                    if ready:
                        record.update(status='benchmark_client', bench_started_wall=time.time(), bench_started_monotonic=time.monotonic()); save()
                        bench = subprocess.Popen(['bash', str(ROOT / 'bench-profile.sh'), str(out)], stdout=bench_log, stderr=subprocess.STDOUT, start_new_session=True)
                        children.append(bench)
                        deadline = time.monotonic() + 900
                elif bench.poll() is not None:
                    record.update(bench_exit_code=bench.returncode, bench_ended_wall=time.time(), bench_ended_monotonic=time.monotonic())
                    assert bench.returncode == 0, f'Bench exited {bench.returncode}'
                    result = json.loads((out / 'mmlu-pro.json').read_text())
                    assert result['completed'] == 200 and result['failed'] == 0
                    record.update(status='profiled', instrumented_output_throughput=result['output_throughput'])
                    break
                time.sleep(max(0, 1 - (time.monotonic() - t0)))
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['child_exit_codes'] = [stop(child) for child in reversed(children)]
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (out / 'npu-after.txt').write_text(smi)
        record.update(ended=time.time(), all_devices_released=all(f'No running processes found in NPU {i}' in smi for i in range(4, 8)))
        save()
        for stream in locks:
            stream.close()
        files = [p for p in out.iterdir() if p.is_file() and p.name != 'SHA256SUMS']
        (out / 'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in files))
    print(json.dumps(record, indent=2))
    return 0 if record['status'] == 'profiled' and record['all_devices_released'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
