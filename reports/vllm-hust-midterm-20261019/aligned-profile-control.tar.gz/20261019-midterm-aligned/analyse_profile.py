"""Parse retained traces offline without creating a model service."""
import json
from pathlib import Path
import time
from torch_npu.profiler.profiler import analyse

ROOT = Path(__file__).resolve().parent


if __name__ == '__main__':
    started = time.time()
    analyse('/workspace/midterm-aligned-profile-20261019-r1',
                               max_process_number=1, export_type=['db', 'text'])
    (ROOT/'offline-profile-analysis.json').write_text(json.dumps(dict(
        started=started, ended=time.time(), max_process_number=1,
        export_type=['db', 'text'], scope='Offline trace analysis only'), indent=2)+'\n')
