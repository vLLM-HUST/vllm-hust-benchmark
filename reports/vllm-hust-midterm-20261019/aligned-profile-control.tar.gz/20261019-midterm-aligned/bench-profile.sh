#!/usr/bin/env bash
set -eo pipefail
test "$#" -eq 1 || { printf '%s\n' 'Usage: bench.sh OUTPUT_DIRECTORY' >&2; exit 2; }
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
ROOT=/root/gennova-evidence/20261019-midterm-aligned
PYTHON=/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
unset OPENAI_API_KEY
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
if [[ "$1" == --check ]]; then
  exec "$PYTHON" -m vllm.entrypoints.cli.main bench serve --help
fi
exec "$PYTHON" -m vllm.entrypoints.cli.main bench serve \
  --backend openai-chat --base-url http://127.0.0.1:18390 \
  --endpoint /v1/chat/completions --model qwen3.5-35b \
  --tokenizer /models/Qwen3.5-35B-A3B --dataset-name custom \
  --dataset-path "$ROOT/materialized.200.jsonl" --disable-shuffle \
  --custom-output-len 256 --num-prompts 200 --request-rate inf \
  --temperature 0 --seed 0 --save-result --save-detailed --profile \
  --percentile-metrics ttft,tpot,itl,e2el --metric-percentiles 50,95,99 \
  --result-dir "$1" --result-filename mmlu-pro.json
