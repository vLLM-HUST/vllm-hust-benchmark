"""Apply profiling-only export configuration and the common Triton correction."""
import importlib.abc
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent


class ProfileFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        paths = {
            'vllm_ascend._triton_compat': ROOT / 'compat/triton_compat.py',
            'vllm_ascend.profiler.torch_npu_profiler': ROOT / 'profile-compat/torch_npu_profiler.py',
        }
        if fullname in paths:
            return importlib.util.spec_from_file_location(fullname, paths[fullname])
        return None


sys.meta_path.insert(0, ProfileFinder())
