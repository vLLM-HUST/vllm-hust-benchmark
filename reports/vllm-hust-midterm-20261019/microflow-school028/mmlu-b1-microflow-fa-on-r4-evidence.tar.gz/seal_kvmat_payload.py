"""Verify every installed plugin Python source against its immutable commit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/root/vllm-hust-kv-materialization-arrival-control')
COMMIT = 'b1680f2365f3468a062a0530bd50dba3d8f80046'
payload = ROOT / 'kvmat-payload-r3'
files = {}
for path in sorted((payload / 'vllm_kv_materialization').rglob('*.py')):
    relative = path.relative_to(payload)
    original = subprocess.check_output(['git', '-C', str(REPO), 'show', f'{COMMIT}:src/{relative}'])
    assert path.read_bytes() == original, str(relative)
    files[str(path.relative_to(ROOT))] = hashlib.sha256(original).hexdigest()
assert files
(ROOT / 'kvmat-source-receipt.json').write_text(json.dumps({
    'source_commit': COMMIT, 'installed_python_files': files,
    'installation': '--no-deps --no-build-isolation into isolated target',
    'manager_check': 'incompatible: native manifest requires >=0.31,<0.32',
    'activation': 'explicit opt-in source-pinned recompute-only experiment; not native host API',
}, indent=2) + '\n')
print(json.dumps({'source_commit': COMMIT, 'verified_python_files': len(files)}))
