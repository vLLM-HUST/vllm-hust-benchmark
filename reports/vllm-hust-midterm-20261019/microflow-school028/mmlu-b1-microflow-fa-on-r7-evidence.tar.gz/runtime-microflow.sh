#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
ROOT=/root/gennova-evidence/20261019-midterm-aligned
BASE=/workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1
SITE=$BASE/lib/python3.12/site-packages
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
export PYTHONPATH=$ROOT/microflow-payload-r3:/root/extension-manager/src:$ROOT/kvmat-managed-payload-r1:$ROOT/compat:$ROOT/payload
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export BETTERSCALE_FIA_METADATA=owned BETTERSCALE_STATE_CACHE_HOST_BYTES=8589934592
export BETTERSCALE_GDN_LIBRARY=$SITE/betterscale/patches/qwen_gdn/libbs_gdn.so
export BETTERSCALE_GDN_HOST_LIBRARY=$ROOT/build/libbs_gdn_host_cann91.so
export BETTERSCALE_CP_LIBRARY=$SITE/betterscale/patches/qwen_fia/context_parallel/libbs_fia_owned.so
export HUST_MICROFLOW_CACHE_ROOT="${HUST_MICROFLOW_CACHE_ROOT:-/workspace/microflow-school028-preflight}"
export HUST_MICROFLOW_ARM="${HUST_MICROFLOW_ARM:-on}"
export VLLM_CACHE_ROOT=$HUST_MICROFLOW_CACHE_ROOT/$HUST_MICROFLOW_ARM/vllm
export TRITON_CACHE_DIR=$HUST_MICROFLOW_CACHE_ROOT/$HUST_MICROFLOW_ARM/triton
export TORCHINDUCTOR_CACHE_DIR=$HUST_MICROFLOW_CACHE_ROOT/$HUST_MICROFLOW_ARM/inductor
export VLLM_HUST_EXT_CONFIG=$ROOT/microflow-manager.json
export VLLM_KV_ENABLE_SCHOOL_028=1 VLLM_KV_POLICY_MODE=controller
if [ "$#" -gt 0 ]; then
    exec "$BASE/bin/python" "$@"
fi
exec "$BASE/bin/python" "$ROOT/launch_microflow.py"
