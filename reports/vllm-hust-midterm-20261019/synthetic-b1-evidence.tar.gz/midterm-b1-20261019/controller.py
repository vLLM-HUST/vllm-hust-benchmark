"""Serialize with existing experiments, monitor own child, retain exit evidence."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'native-controller-r2'
LOCKS=['/tmp/inference-project-container-model.lock',
       '/tmp/gennova-device-leases/device-4.lock','/tmp/gennova-device-leases/device-5.lock']

def save(value):
    (OUT/'receipt.json').write_text(json.dumps(value,indent=2)+'\n')

def members(pgid):
    values=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            if os.getpgid(int(p.name))==pgid and p.joinpath('stat').read_text().rsplit(')',1)[1].split()[0]!='Z':
                values.append(int(p.name))
        except (OSError,ProcessLookupError):pass
    return values

def main():
    OUT.mkdir(exist_ok=False,mode=0o700)
    receipt={'status':'waiting_for_existing_reservations','started':time.time(),
             'devices':[4,5],'measurement_started':False,'project':'vLLM-HUST',
             'scope':'B1 vLLM-HUST: resident State/FULL/MTP2 with prefill-microflow',
             'input_hashes':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                for name in ['controller.py','measure.py','runtime.sh','plan.json','inputs.json',
                             'manager.json']}}
    save(receipt)
    streams=[];child=None
    try:
        deadline=time.monotonic()+900
        while True:
            try:
                for path in LOCKS:
                    f=open(path,'a+b');streams.append(f)
                    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
                break
            except BlockingIOError:
                for f in streams:f.close()
                streams=[]
                if time.monotonic()>deadline:raise TimeoutError('Existing reservation remains; no model launched')
                time.sleep(10)
        for _ in range(3):
            smi=subprocess.check_output(['npu-smi','info'],text=True,timeout=15)
            assert all('No running processes found in NPU '+str(i) in smi for i in [4,5,6,7]),'Shared hardware busy'
            time.sleep(3)
        (OUT/'npu-before.txt').write_text(smi)
        assert shutil.disk_usage(ROOT).free>5*1024**3,'Less than 5GiB available'
        mem=dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
        assert int(mem['anon'])<30*1024**3,'Other anonymous memory remains in use'
        receipt.update(status='starting_owned_baseline',admitted=time.time());save(receipt)
        with (OUT/'service.log').open('x') as log:
            child=subprocess.Popen(['bash',str(ROOT/'runtime.sh'),'--output',str(ROOT/'native')],
                                   stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            receipt.update(child_pid=child.pid);save(receipt)
            deadline=time.monotonic()+1800
            with (OUT/'device-samples.jsonl').open('x') as samples:
                while child.poll() is None:
                    started=time.monotonic()
                    if started>deadline:raise TimeoutError('Owned baseline exceeded 1800s')
                    if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('Disk reserve exhausted')
                    if int(Path('/sys/fs/cgroup/memory.stat').read_text().split('anon ')[1].split()[0])>110*1024**3:
                        raise RuntimeError('Owned run exceeded anonymous memory budget')
                    result=subprocess.run(['npu-smi','info'],capture_output=True,text=True,timeout=15)
                    samples.write(json.dumps({'start_monotonic':started,'end_monotonic':time.monotonic(),
                        'wall_time':time.time(),'returncode':result.returncode,'raw':result.stdout})+'\n');samples.flush()
                    if (ROOT/'native/formal-start.json').exists() and not receipt['measurement_started']:
                        receipt.update(status='formal_measurement',measurement_started=True);save(receipt)
                    time.sleep(max(0,1-(time.monotonic()-started)))
            receipt.update(exit_code=child.returncode,status='passed' if child.returncode==0 else 'failed')
    except BaseException as error:
        receipt.update(status='blocked_or_failed',error=type(error).__name__+': '+str(error))
    finally:
        if child is not None:
            for sig,seconds in [(signal.SIGINT,60),(signal.SIGTERM,20),(signal.SIGKILL,10)]:
                if not members(child.pid):break
                try:os.killpg(child.pid,sig)
                except ProcessLookupError:break
                deadline=time.monotonic()+seconds
                while members(child.pid) and time.monotonic()<deadline:time.sleep(1)
            child.wait(timeout=10)
            receipt['owned_processes_gone']=not members(child.pid)
            (OUT/'npu-after.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True,timeout=15))
        receipt['ended']=time.time();save(receipt)
        for f in streams:f.close()
        files=[p for p in ROOT.rglob('*') if p.is_file() and
               not any('cache' in x for x in p.relative_to(ROOT).parts) and p.name!='SHA256SUMS']
        (ROOT/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in files))
    print(json.dumps(receipt,indent=2),flush=True)
    return 0 if receipt['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
