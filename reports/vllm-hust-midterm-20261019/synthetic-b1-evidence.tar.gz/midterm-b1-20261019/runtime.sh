#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
export PYTHONPATH=/workspace/test6-p0-20261018/ascend-runtime-joint-r1:/workspace/test6-p0-20261018/joint-guard-packages-r2:/workspace/test6-p0-20261018/joint-packages-r3${PYTHONPATH:+:$PYTHONPATH}
export ASCEND_RT_VISIBLE_DEVICES=0,1
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector
export VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ENABLE_V1_MULTIPROCESSING=1
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 TASK_QUEUE_ENABLE=0 HCCL_OP_EXPANSION_MODE=AIV
export MTP_TOKENS=2 BETTERSCALE_MTP_GREEDY=1 BETTERSCALE_GDN_SMALL_COPIES=1 MTP_PROFILE=0
export BETTERSCALE_STATE_CACHE_HOST_BYTES=0 BETTERSCALE_FIA_METADATA=owned
export BETTERSCALE_GDN_LIBRARY=/workspace/test6-p0-20261018/joint-packages-r3/betterscale/patches/qwen_gdn/libbs_gdn.so
export BETTERSCALE_GDN_HOST_LIBRARY=/workspace/test6-p0-20261018/joint-packages-r3/betterscale/patches/qwen_gdn/libbs_gdn_host_cann91.so
export BETTERSCALE_CP_LIBRARY=/workspace/test6-p0-20261018/joint-packages-r3/betterscale/patches/qwen_fia/context_parallel/libbs_fia_owned.so
export BETTERSCALE_MICROFLOW_NATIVE_DIR=/workspace/test6-p0-20261018/microflow-native-build/lib
export HUST_PREFILL_MICROFLOW_NATIVE_MANIFEST=/workspace/test6-p0-20261018/microflow-native.json
export HUST_PREFILL_MICROFLOW_CACHE_ROOT=/root/midterm-b1-20261019/cache
export HUST_PREFILL_MICROFLOW_ARM=on
export VLLM_CACHE_ROOT=/root/midterm-b1-20261019/cache/on/vllm
export TRITON_CACHE_DIR=/root/midterm-b1-20261019/cache/on/triton
export TORCHINDUCTOR_CACHE_DIR=/root/midterm-b1-20261019/cache/on/inductor
export VLLM_HUST_EXT_CONFIG=/root/midterm-b1-20261019/manager.json
export HUST_JOINT_GUARD_REPORT_DIR=/root/midterm-b1-20261019/guard
if [[ "${1:-}" == manager ]]; then
    shift
    exec /workspace/test6-p0-20261018/venv/bin/vllm-hust-ext "$@"
fi
exec /workspace/test6-p0-20261018/venv/bin/vllm-hust-ext run -- /workspace/test6-p0-20261018/venv/bin/python /root/midterm-b1-20261019/measure.py "$@"
