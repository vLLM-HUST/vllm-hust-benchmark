#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
export ASCEND_RT_VISIBLE_DEVICES=0,1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
exec /workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python -m torch.distributed.run --standalone --nnodes=1 --nproc_per_node=2 /root/midterm-calibration-20261019/calibrate.py
