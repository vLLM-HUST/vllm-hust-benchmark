"""Independent calibration; no model performance or physical peak inference."""
from datetime import timedelta
import importlib.metadata
import json
import os
from pathlib import Path
import statistics
import time
import torch
import torch_npu
import torch.distributed as dist

ROOT = Path(__file__).resolve().parent
plan = json.loads((ROOT/'plan.json').read_text())
rank = int(os.environ['LOCAL_RANK'])
torch.npu.set_device(rank)
dist.init_process_group('hccl', timeout=timedelta(seconds=120))
torch.manual_seed(plan['seed'])
records = []


def measure(name, fn, numerator, unit, parameters):
    for _ in range(plan['warmup_iterations']):
        fn()
    torch.npu.synchronize()
    durations = []
    for _ in range(plan['timed_repetitions']):
        dist.barrier()
        torch.npu.synchronize()
        start = time.perf_counter()
        for _ in range(plan['iterations_per_repetition']):
            fn()
        torch.npu.synchronize()
        durations.append((time.perf_counter()-start)/plan['iterations_per_repetition'])
    records.append(dict(name=name, parameters=parameters, seconds_per_iteration=durations,
                        median_seconds=statistics.median(durations), numerator=numerator,
                        numerator_unit=unit, median_rate=numerator/statistics.median(durations)))
    print(f'RANK={rank} COMPLETE {name}', flush=True)


try:
    for m,n,k in plan['gemm_mnk']:
        a = torch.randn(m,k,dtype=torch.bfloat16,device='npu')*.02
        b = torch.randn(k,n,dtype=torch.bfloat16,device='npu')*.02
        out = torch.empty(m,n,dtype=torch.bfloat16,device='npu')
        torch.mm(a,b,out=out)
        reference = a[:4].float().cpu() @ b[:,:4].float().cpu()
        actual = out[:4,:4].float().cpu()
        torch.testing.assert_close(actual, reference, rtol=.02, atol=.002)
        measure(f'gemm-{m}-{n}-{k}',lambda:torch.mm(a,b,out=out),2*m*n*k,
                'FLOP',dict(m=m,n=n,k=k,dtype='bfloat16',correctness='4x4 FP32 CPU sample'))
        del a,b,out
    for count in plan['copy_bytes']:
        src=torch.arange(count//2,dtype=torch.int32,device='npu').to(torch.bfloat16)
        dst=torch.empty_like(src)
        measure(f'copy-{count}',lambda:dst.copy_(src),2*count,'logical read+write bytes',
                dict(payload_bytes=count,dtype='bfloat16'))
        assert torch.equal(dst,src)
        del src,dst
    for count in plan['allreduce_payload_bytes_per_rank']:
        values=torch.zeros(count//2,dtype=torch.bfloat16,device='npu')
        measure(f'allreduce-{count}',lambda:dist.all_reduce(values),count,
                'payload bytes per rank',dict(payload_bytes_per_rank=count,ranks=2,dtype='bfloat16'))
        values.fill_(rank+1)
        dist.all_reduce(values)
        assert bool(torch.all(values == 3).item())
        del values
    result=dict(project='vLLM-HUST',rank=rank,physical_device=plan['devices'][rank],
                packages={p:importlib.metadata.version(p) for p in ['torch','torch-npu']},
                timing='host wall time including launch overhead, NPU synchronized; barriers excluded',
                records=records,success=True,model_effective_compute_attainment=None)
    (ROOT/f'rank-{rank}.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
    dist.destroy_process_group()
