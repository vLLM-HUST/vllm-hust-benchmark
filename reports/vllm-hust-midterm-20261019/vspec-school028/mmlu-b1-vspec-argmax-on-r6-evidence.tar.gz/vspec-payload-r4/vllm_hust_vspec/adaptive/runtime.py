"""Runtime hooks for vSpec Adaptive scheduling and dynamic Draft lengths."""

from __future__ import annotations

import logging
import os
import time
from bisect import bisect_left
from collections import deque
from contextlib import contextmanager
from dataclasses import fields, replace
from typing import Any

from ..config import PluginSettings
from ..host_compat import call_with_supported_kwargs
from .controller import GoodputController
from .entropy import EntropyDraftStopper, topk_entropy
from .online import OnlineGammaController
from .profile import AdaptiveProfile

logger = logging.getLogger(__name__)

# Gamma 1 has no suffix to trim. At gamma 2, the first-position confidence
# already determines whether verifying the second proposal is worthwhile.
_MIN_CONFIDENCE_STOP_GAMMA = 2

SCHEDULER_PATCH_MARKER = "_vllm_hust_vspec_adaptive_scheduler_patched"
PROPOSER_PATCH_MARKER = "_vllm_hust_vspec_adaptive_proposer_patched"
RUNNER_PATCH_MARKER = "_vllm_hust_vspec_adaptive_runner_patched"
CAPTURE_SIZE_PATCH_MARKER = "_vllm_hust_vspec_adaptive_capture_sizes_patched"
DISPATCHER_PATCH_MARKER = "_vllm_hust_vspec_adaptive_dispatcher_patched"
ASYNC_OUTPUT_PATCH_MARKER = "_vllm_hust_vspec_adaptive_output_patched"
_EAGLE_UNIFORM_STATE_ENV = "VLLM_ASCEND_EAGLE_UNIFORM_STATE_KERNEL"
_EAGLE_DYNAMIC_UNIFORM_STATE_ENV = "HUST_VSPEC_EAGLE_DYNAMIC_UNIFORM_STATE_KERNEL"
_EAGLE_CONFIDENCE_ACCEPT_ATTR = "_vspec_eagle_confidence_accept_enabled"


class _TargetOnlyLatch:
    """Keep Draft-disabled requests sticky until their cohort drains."""

    def __init__(self) -> None:
        self.request_ids: set[str] = set()

    @property
    def active(self) -> bool:
        return bool(self.request_ids)

    def refresh(self, active_request_ids: set[str]) -> bool:
        if not self.request_ids:
            return False
        self.request_ids.intersection_update(active_request_ids)
        if not self.request_ids:
            return False
        self.request_ids.update(active_request_ids)
        return True

    def enter(self, active_request_ids: set[str]) -> None:
        self.request_ids.update(active_request_ids)


def _disable_fixed_width_eagle_state_kernel(
    method: str,
    min_gamma: int,
    max_gamma: int,
    environ: Any,
) -> bool:
    """Disable an upstream fixed-width state shortcut for dynamic EAGLE."""
    if method == "eagle" and min_gamma < max_gamma and environ.get(_EAGLE_UNIFORM_STATE_ENV) == "1":
        environ[_EAGLE_DYNAMIC_UNIFORM_STATE_ENV] = "1"
        environ[_EAGLE_UNIFORM_STATE_ENV] = "0"
        return True
    return False


def _context_tokens_after_schedule(scheduler: Any, scheduler_output: Any) -> int:
    total = 0
    for request_id, scheduled_tokens in scheduler_output.num_scheduled_tokens.items():
        request = scheduler.requests.get(request_id)
        computed_tokens = int(getattr(request, "num_computed_tokens", 0))
        total += max(1, computed_tokens + int(scheduled_tokens))
    return total


def _adaptive_scheduled_batch_size(
    scheduler: Any,
    num_scheduled_requests: int,
) -> int:
    """Resolve the controller batch size across scheduler API versions."""
    get_batch_size = getattr(scheduler, "_get_dynamic_sd_batch_size", None)
    if get_batch_size is not None:
        return int(get_batch_size(num_scheduled_requests))
    return int(num_scheduled_requests)


def _should_hold_initial_cohort(
    num_running: int,
    num_waiting: int,
    target_size: int,
    started_at: float,
    now: float,
    max_wait_seconds: float,
) -> bool:
    """Briefly coalesce an empty engine's first speculative decode cohort."""
    return (
        target_size > 1
        and num_running == 0
        and 0 < num_waiting < target_size
        and now - started_at < max_wait_seconds
    )


def _should_hold_growing_initial_cohort(
    scheduler: Any,
    num_running: int,
    num_waiting: int,
    now: float,
    quiet_seconds: float,
    max_wait_seconds: float,
) -> bool:
    """Gate an empty engine until a request burst stops growing.

    This is a bounded gated-batching policy, not a fixed batch threshold. The
    observed arrival burst determines the cohort size; the quiet period avoids
    committing a stateful speculative width from only the first HTTP request.
    """
    state_attr = "_vspec_adaptive_arrival_gate"
    if num_running != 0 or num_waiting <= 0 or quiet_seconds <= 0 or max_wait_seconds <= 0:
        if hasattr(scheduler, state_attr):
            delattr(scheduler, state_attr)
        return False

    state = getattr(scheduler, state_attr, None)
    if state is None:
        state = {
            "started_at": now,
            "last_growth_at": now,
            "waiting_count": num_waiting,
        }
        setattr(scheduler, state_attr, state)
    elif num_waiting > int(state["waiting_count"]):
        state["last_growth_at"] = now
        state["waiting_count"] = num_waiting

    within_latency_budget = now - float(state["started_at"]) < max_wait_seconds
    burst_is_growing = now - float(state["last_growth_at"]) < quiet_seconds
    if within_latency_budget and burst_is_growing:
        return True

    delattr(scheduler, state_attr)
    return False


def _adaptive_graph_batch_limit(
    method: str | None,
    gamma: int,
    max_gamma: int,
    max_num_seqs: int,
) -> int:
    """Bound low-width EAGLE3 graph materialization by serving geometry.

    The graph-backed anchor and its immediate lower neighbor retain every
    concurrency. Each farther low-gamma arm gets half as many request rows.
    This preserves all online arms where they are useful without allowing cold
    low-width graphs to evict the high-concurrency hot graph pool.
    """
    if method != "eagle3" or gamma <= 0:
        return max_num_seqs
    anchor_gamma = min(max_gamma, 5)
    full_width_floor = max(1, anchor_gamma - 1)
    if gamma >= full_width_floor:
        return max_num_seqs
    return max(1, max_num_seqs // (1 << (full_width_floor - gamma)))


def _adaptive_candidate_batch_limits(
    method: str,
    min_gamma: int,
    max_gamma: int,
    max_num_seqs: int,
) -> dict[int, int]:
    if method != "eagle3":
        return {}
    return {
        gamma: _adaptive_graph_batch_limit(
            method,
            gamma,
            max_gamma,
            max_num_seqs,
        )
        for gamma in range(min_gamma, max_gamma + 1)
    }


def _online_probe_shared_cost_units(method: str) -> float:
    """Return a conservative shared-cost prior for an unmeasured gamma arm."""
    # EAGLE3's head is cheap relative to the Target, but a width transition
    # also changes graph and recurrent-state bindings. Treat that runtime cost
    # as part of the serial Draft unit until direct serving feedback exists.
    return 8.0 if method == "eagle3" else 2.0


def _should_hold_eagle3_async_cohort(
    method: str,
    adaptive_async: bool,
    num_running: int,
    *,
    runtime_width_switching: bool = False,
) -> bool:
    """Keep one stateful speculative width until an async cohort drains.

    Async scheduling can have multiple Target frames in flight. A mid-cohort
    width change makes older EAGLE3 or hybrid-MTP frames consume state with a
    different layout and attributes delayed feedback to the wrong arm.
    """
    return (
        method in {"eagle3", "mtp"}
        and adaptive_async
        and not runtime_width_switching
        and num_running > 0
    )


def _can_use_eagle3_native_scheduler_hold(
    method: str,
    adaptive_async: bool,
    runtime_width_switching: bool,
    num_running: int,
    schedule_gamma: int,
    configured_gamma: int,
    *,
    target_only_latched: bool = False,
) -> bool:
    """Return whether an active EAGLE3 cohort can use native scheduling."""
    return (
        not target_only_latched
        and schedule_gamma == configured_gamma
        and _should_hold_eagle3_async_cohort(
            method,
            adaptive_async,
            num_running,
            runtime_width_switching=runtime_width_switching,
        )
    )


def _eagle3_cohort_refill_enabled(
    method: str,
    schedule: Any,
    environ: Any = os.environ,
) -> bool:
    """Detect a native refill hook before or after patch installation."""
    if method == "eagle3":
        return bool(
            getattr(
                schedule,
                "_vllm_hust_vspec_eagle3_cohort_refill_patched",
                False,
            )
            or environ.get("HUST_VSPEC_EAGLE3_COHORT_REFILL", "0") == "1"
        )
    if method == "mtp":
        return bool(
            getattr(schedule, "_vspec_mtp_cohort_refill", False)
            or environ.get("HUST_VSPEC_MTP_COHORT_REFILL", "0") == "1"
        )
    return False


@contextmanager
def _scheduler_runtime_gamma(scheduler: Any, gamma: int) -> Any:
    """Use the selected arm for scheduling without shrinking engine capacity."""
    native_gamma = int(scheduler.num_spec_tokens)
    configured_gamma = int(
        getattr(
            scheduler,
            "_vspec_adaptive_configured_gamma",
            native_gamma,
        )
    )
    runtime_gamma = int(gamma)
    if runtime_gamma < 0 or runtime_gamma > configured_gamma:
        raise RuntimeError(
            "adaptive scheduler gamma is outside configured capacity: "
            f"runtime={runtime_gamma}, configured={configured_gamma}"
        )
    if runtime_gamma == native_gamma:
        yield
        return

    # Scheduler.schedule() uses num_spec_tokens both to pad newly admitted
    # decode requests and to size their placeholder list. Keeping the configured
    # maximum here mixes q(max+1) refill rows with the active arm's q(gamma+1)
    # rows, which makes an otherwise uniform Target batch eager. Allocation
    # buffers remain sized for configured_gamma; only scheduling is scoped.
    scheduler.num_spec_tokens = runtime_gamma
    try:
        yield
    finally:
        scheduler.num_spec_tokens = native_gamma


def _normalize_spec_decoding_stats_width(stats: Any, width: int) -> Any:
    """Keep adaptive metrics at the configured maximum Draft width."""
    if stats is None:
        return None
    configured_width = int(width)
    if configured_width <= 0:
        raise ValueError("spec decoding stats width must be positive")
    for attribute in (
        "num_accepted_tokens_per_pos",
        "num_draft_tokens_per_pos",
    ):
        values = getattr(stats, attribute)
        if len(values) > configured_width:
            raise RuntimeError(
                "spec decoding stats exceed configured adaptive capacity: "
                f"attribute={attribute}, actual={len(values)}, "
                f"configured={configured_width}"
            )
        values.extend([0] * (configured_width - len(values)))
    stats.num_spec_tokens = configured_width
    return stats


def _adaptive_target_query_lens(existing: Any, max_gamma: int) -> tuple[int, ...]:
    widths = {int(width) for width in existing}
    widths.update(range(1, max_gamma + 2))
    return tuple(sorted(widths))


def _adaptive_capture_query_lens(
    existing: Any,
    max_gamma: int,
    method: str,
    min_gamma: int | None = None,
) -> tuple[int, ...]:
    if method == "draft_model" and min_gamma is not None and min_gamma <= 2 <= max_gamma:
        # Gamma 2 is the graph-backed serial-Draft arm. Its Target width is 3
        # and its merged Draft continuation width is 4. Other arms stay fully
        # selectable, but run eagerly until they have a validated graph path.
        return (3, 4)
    if method == "eagle3" and min_gamma is not None:
        # Every online arm needs an independent Target graph. Registering only
        # the old gamma-5 anchor silently sends all other widths through the
        # non-uniform slow path and biases the controller toward that anchor.
        return tuple(range(min_gamma + 1, max_gamma + 2))
    if method == "mtp" and min_gamma is not None:
        return tuple(gamma + 1 for gamma in range(min_gamma, max_gamma + 1, 2))
    widths = {int(width) for width in existing}
    first_width = 1 if min_gamma is None else min_gamma + 1
    widths.update(range(first_width, max_gamma + 2))
    if method == "draft_model":
        widths.add(max_gamma + 2)
    return tuple(sorted(widths))


def _uses_width_isolated_target_graph_params(cudagraph_mode: Any) -> bool:
    """Return whether Target graph state is independent for each query width."""
    return getattr(cudagraph_mode, "name", "") in {
        "FULL_DECODE_ONLY",
        "FULL_AND_PIECEWISE",
    }


def _runtime_target_query_width(scheduler_output: Any) -> int | None:
    scheduled = scheduler_output.num_scheduled_tokens
    draft_tokens = scheduler_output.scheduled_spec_decode_tokens
    widths = {len(draft_tokens.get(request_id, ())) + 1 for request_id in scheduled}
    return widths.pop() if len(widths) == 1 else None


def _runtime_target_metadata_query_width(scheduler_output: Any) -> int | None:
    """Return the widest request layout represented by the current frame."""
    scheduled = scheduler_output.num_scheduled_tokens
    draft_tokens = scheduler_output.scheduled_spec_decode_tokens
    widths = [len(draft_tokens.get(request_id, ())) + 1 for request_id in scheduled]
    return max(widths, default=None)


def _runtime_proposal_query_width(scheduler_output: Any) -> int:
    """Return the runner width needed while sampling the next proposal."""
    gamma = int(getattr(scheduler_output, "num_spec_tokens_to_schedule", 0))
    return gamma + 1


def _current_target_is_target_only(
    current_query_width: int | None,
    proposal_gamma: int,
) -> bool:
    """Identify the Target frame independently of the next proposal width."""
    if current_query_width is not None:
        return current_query_width == 1
    return proposal_gamma == 0


def _current_eagle_confidence_accept_enabled(
    current_query_width: int | None,
    proposal_gamma: int,
) -> bool:
    """Use relaxed EAGLE verification only for the validated gamma range."""
    current_gamma = current_query_width - 1 if current_query_width is not None else proposal_gamma
    return current_gamma <= 2


@contextmanager
def _runtime_dynamic_eagle_state_kernel(
    runner: Any,
    *,
    stable_decode: bool,
    gamma: int,
    environ: Any = os.environ,
) -> Any:
    """Enable the native state kernel only at its stable anchor width."""
    if environ.get(_EAGLE_DYNAMIC_UNIFORM_STATE_ENV) != "1":
        yield
        return

    previous_enabled = environ.get(_EAGLE_UNIFORM_STATE_ENV)
    enabled = stable_decode and runner.num_spec_tokens == gamma
    environ[_EAGLE_UNIFORM_STATE_ENV] = "1" if enabled else "0"
    try:
        yield
    finally:
        if previous_enabled is None:
            environ.pop(_EAGLE_UNIFORM_STATE_ENV, None)
        else:
            environ[_EAGLE_UNIFORM_STATE_ENV] = previous_enabled


def _batch_descriptor_query_width(batch_descriptor: Any) -> int | None:
    """Return the uniform query width represented by a graph descriptor."""
    if batch_descriptor is None or not getattr(
        batch_descriptor,
        "uniform",
        False,
    ):
        return None
    num_tokens = int(getattr(batch_descriptor, "num_tokens", 0))
    num_reqs = int(getattr(batch_descriptor, "num_reqs", 0) or 0)
    if num_tokens <= 0 or num_reqs <= 0 or num_tokens % num_reqs:
        return None
    return num_tokens // num_reqs


def _proposal_input_query_width(
    common_attn_metadata: Any,
    batch_descriptor: Any,
) -> int | None:
    """Resolve the Target output width consumed by the Draft first pass."""
    # Uniform descriptors already encode the exact logical width. Reading them
    # first avoids materializing a per-request tensor as a Python list on every
    # stable decode step.
    descriptor_width = _batch_descriptor_query_width(batch_descriptor)
    if descriptor_width is not None:
        return descriptor_width
    if common_attn_metadata is not None:
        query_start_loc = getattr(
            common_attn_metadata,
            "query_start_loc_cpu",
            None,
        )
        if query_start_loc is not None:
            starts = [int(value) for value in query_start_loc.tolist()]
            adjacent_starts = zip(starts, starts[1:], strict=False)
            widths = {end - start for start, end in adjacent_starts}
            if len(widths) == 1:
                width = widths.pop()
                if width > 0:
                    return width
    return None


def _nonuniform_batch_descriptor(batch_descriptor: Any) -> Any:
    if batch_descriptor is None or not getattr(
        batch_descriptor,
        "uniform",
        False,
    ):
        return batch_descriptor
    return replace(batch_descriptor, uniform=False)


def _uniform_decode_fits_capture_bucket(
    dispatcher: Any,
    num_tokens: int,
    query_width: int,
) -> bool:
    padded_sizes = getattr(dispatcher, "_bs_to_padded_graph_size", ())
    if query_width <= 0 or num_tokens < 0 or num_tokens >= len(padded_sizes):
        return True
    return int(padded_sizes[num_tokens]) % query_width == 0


def _active_dispatch_query_width(
    dispatcher: Any,
    explicit_query_width: int | None = None,
) -> int:
    """Resolve Target or Draft width before validating a uniform graph bucket."""
    if explicit_query_width is not None:
        return int(explicit_query_width)
    for attribute in (
        "_vspec_capture_uniform_query_len",
        "_vspec_active_uniform_query_len",
        "_vspec_runtime_draft_query_len",
    ):
        query_width = getattr(dispatcher, attribute, None)
        if query_width is not None:
            return int(query_width)
    return int(dispatcher.uniform_decode_query_len)


def _add_adaptive_decode_graph_keys(
    dispatcher: Any,
    query_widths: tuple[int, ...],
) -> None:
    """Add FULL_DECODE_ONLY descriptors for every reachable runtime width."""
    from vllm.config import CUDAGraphMode

    if not dispatcher.cudagraph_mode.separate_routine():
        return
    capture_sizes = dispatcher.compilation_config.cudagraph_capture_sizes or ()
    max_num_seqs = dispatcher.vllm_config.scheduler_config.max_num_seqs
    speculative_config = getattr(dispatcher.vllm_config, "speculative_config", None)
    method = getattr(speculative_config, "method", None)
    max_gamma = max((width - 1 for width in query_widths), default=0)
    lora_cases = dispatcher._get_lora_cases()
    previous_width = dispatcher.uniform_decode_query_len
    try:
        for query_width in query_widths:
            dispatcher.uniform_decode_query_len = query_width
            gamma = query_width - 1
            batch_limit = _adaptive_graph_batch_limit(
                method,
                gamma,
                max_gamma,
                max_num_seqs,
            )
            for size in capture_sizes:
                if size < query_width or size > query_width * max_num_seqs or size % query_width:
                    continue
                if size // query_width > batch_limit:
                    continue
                for num_active_loras in lora_cases:
                    descriptor = dispatcher._create_padded_batch_descriptor(
                        size,
                        True,
                        num_active_loras > 0,
                        num_active_loras,
                    )
                    dispatcher.add_cudagraph_key(CUDAGraphMode.FULL, descriptor)
    finally:
        dispatcher.uniform_decode_query_len = previous_width


def _initialize_adaptive_decode_only_graph_keys(
    dispatcher: Any,
    cudagraph_mode: Any,
    query_widths: tuple[int, ...],
) -> None:
    """Initialize FULL_DECODE_ONLY keys without mixing verification widths."""
    dispatcher.cudagraph_mode = cudagraph_mode
    dispatcher._compute_bs_to_padded_graph_size()
    lora_cases = dispatcher._get_lora_cases()
    dispatcher.captured_lora_counts = [count for count in lora_cases if count]
    _add_adaptive_decode_graph_keys(dispatcher, query_widths)
    dispatcher.keys_initialized = True


def _initialize_adaptive_graph_keys(
    dispatcher: Any,
    cudagraph_mode: Any,
    query_widths: tuple[int, ...],
    mixed_capture_sizes: tuple[int, ...] = (),
) -> None:
    """Initialize mixed graphs once and FULL decode graphs per runtime width."""
    from vllm.config import CUDAGraphMode

    dispatcher.cudagraph_mode = cudagraph_mode
    dispatcher._compute_bs_to_padded_graph_size()
    lora_cases = dispatcher._get_lora_cases()
    dispatcher.captured_lora_counts = [count for count in lora_cases if count]

    mixed_mode = cudagraph_mode.mixed_mode()
    if mixed_mode != CUDAGraphMode.NONE:
        sizes = mixed_capture_sizes or tuple(
            dispatcher.compilation_config.cudagraph_capture_sizes or ()
        )
        for size in sizes:
            for num_active_loras in lora_cases:
                descriptor = dispatcher._create_padded_batch_descriptor(
                    size,
                    False,
                    num_active_loras > 0,
                    num_active_loras,
                )
                if mixed_mode == CUDAGraphMode.PIECEWISE:
                    descriptor = replace(
                        descriptor,
                        num_reqs=None,
                        uniform=False,
                    )
                dispatcher.add_cudagraph_key(mixed_mode, descriptor)

    _add_adaptive_decode_graph_keys(dispatcher, query_widths)
    dispatcher.keys_initialized = True


@contextmanager
def _runner_query_width(
    runner: Any,
    query_width: int | None,
) -> Any:
    """Temporarily align runner and dispatcher with one Target frame width."""
    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    if runner is None or dispatcher is None or query_width is None:
        yield
        return

    previous_runner_width = runner.uniform_decode_query_len
    previous_dispatcher_width = dispatcher.uniform_decode_query_len
    previous_decode_width = getattr(
        runner,
        "decode_token_per_req",
        previous_runner_width,
    )
    previous_num_spec_tokens = getattr(
        runner,
        "num_spec_tokens",
        max(previous_runner_width - 1, 0),
    )
    previous_decode_threshold = getattr(
        runner,
        "decode_threshold",
        previous_runner_width,
    )
    previous_reorder_threshold = getattr(
        runner,
        "reorder_batch_threshold",
        None,
    )
    metadata_builder_states = [
        (
            builder,
            getattr(builder, "decode_threshold", None),
            getattr(builder, "reorder_batch_threshold", None),
            getattr(builder, "num_spec", None),
            getattr(builder, "spec_state_indices_tensor", None),
        )
        for builder in _adaptive_metadata_builders(runner)
    ]
    runtime_gamma = max(query_width - 1, 0)
    if (
        previous_runner_width == query_width
        and previous_dispatcher_width == query_width
        and previous_decode_width == query_width
        and previous_num_spec_tokens == runtime_gamma
        and previous_decode_threshold == query_width
        and (previous_reorder_threshold is None or previous_reorder_threshold == query_width)
        and all(
            decode_threshold in (None, query_width)
            and reorder_threshold in (None, query_width)
            and builder_num_spec in (None, runtime_gamma)
            and (state_indices is None or state_indices.shape[1] == query_width)
            for (
                _,
                decode_threshold,
                reorder_threshold,
                builder_num_spec,
                state_indices,
            ) in metadata_builder_states
        )
    ):
        yield
        return
    runner.uniform_decode_query_len = query_width
    dispatcher.uniform_decode_query_len = query_width
    # Ascend copies the configured maximum into this attention-metadata field
    # during runner construction.  Leaving it at max_gamma + 1 makes a gamma-2
    # frame retain a q5 decode layout in a 1..4 deployment even though graph
    # dispatch is correctly bound to q3.
    runner.decode_token_per_req = query_width
    runner.num_spec_tokens = runtime_gamma
    runner.decode_threshold = query_width
    if previous_reorder_threshold is not None:
        runner.reorder_batch_threshold = query_width
    for (
        builder,
        decode_threshold,
        reorder_threshold,
        builder_num_spec,
        state_indices,
    ) in metadata_builder_states:
        if decode_threshold is not None:
            builder.decode_threshold = query_width
        if reorder_threshold is not None:
            builder.reorder_batch_threshold = query_width
        if builder_num_spec is not None:
            # GDN builders allocate their buffers at configured capacity, but
            # ``num_spec`` controls how many recurrent-state slots are consumed
            # by this frame. Using max_gamma here with a narrower runtime arm
            # advances an extra state slot and corrupts subsequent verification.
            builder.num_spec = runtime_gamma
        if state_indices is not None and state_indices.shape[1] != query_width:
            buffers = getattr(
                builder,
                "_vspec_adaptive_spec_state_indices_by_width",
                None,
            )
            if buffers is None:
                buffers = {int(state_indices.shape[1]): state_indices}
                builder._vspec_adaptive_spec_state_indices_by_width = buffers
            else:
                buffers.setdefault(int(state_indices.shape[1]), state_indices)
            if query_width not in buffers:
                buffers[query_width] = state_indices.new_empty(
                    (state_indices.shape[0], query_width)
                )
            builder.spec_state_indices_tensor = buffers[query_width]
    try:
        yield
    finally:
        runner.uniform_decode_query_len = previous_runner_width
        dispatcher.uniform_decode_query_len = previous_dispatcher_width
        runner.decode_token_per_req = previous_decode_width
        runner.num_spec_tokens = previous_num_spec_tokens
        runner.decode_threshold = previous_decode_threshold
        if previous_reorder_threshold is not None:
            runner.reorder_batch_threshold = previous_reorder_threshold
        for (
            builder,
            decode_threshold,
            reorder_threshold,
            builder_num_spec,
            state_indices,
        ) in metadata_builder_states:
            if decode_threshold is not None:
                builder.decode_threshold = decode_threshold
            if reorder_threshold is not None:
                builder.reorder_batch_threshold = reorder_threshold
            if builder_num_spec is not None:
                builder.num_spec = builder_num_spec
            if state_indices is not None:
                builder.spec_state_indices_tensor = state_indices


def _adaptive_metadata_builders(runner: Any) -> tuple[Any, ...]:
    """Resolve stable attention builders once after KV-cache initialization."""
    cached = getattr(runner, "_vspec_adaptive_metadata_builders", None)
    if cached is not None:
        return cached

    attn_group_iterator = getattr(runner, "_attn_group_iterator", None)
    if not callable(attn_group_iterator):
        return ()
    try:
        builders = tuple(group.get_metadata_builder() for group in attn_group_iterator())
    except (AttributeError, TypeError):
        # Attention groups are populated after runner construction.
        return ()
    if builders:
        runner._vspec_adaptive_metadata_builders = builders
    return builders


def _state_indices_for_query_width(builder: Any, query_width: int) -> Any:
    state_indices = getattr(builder, "spec_state_indices_tensor", None)
    if state_indices is None:
        return None
    buffers = getattr(
        builder,
        "_vspec_adaptive_spec_state_indices_by_width",
        None,
    )
    if buffers is None:
        buffers = {int(state_indices.shape[1]): state_indices}
        builder._vspec_adaptive_spec_state_indices_by_width = buffers
    else:
        buffers.setdefault(int(state_indices.shape[1]), state_indices)
    if query_width not in buffers:
        buffers[query_width] = state_indices.new_empty((state_indices.shape[0], query_width))
    return buffers[query_width]


def _runner_query_width_pin_plan(
    runner: Any,
    query_width: int,
) -> tuple[tuple[Any, ...], tuple[Any, ...], tuple[Any, ...], tuple[tuple[Any, Any], ...]]:
    """Cache the host assignments needed to restore one native query width."""
    plans = getattr(runner, "_vspec_adaptive_query_width_pin_plans", None)
    if plans is None:
        plans = {}
        runner._vspec_adaptive_query_width_pin_plans = plans
    cached = plans.get(query_width)
    if cached is not None:
        return cached

    builders = _adaptive_metadata_builders(runner)
    plan = (
        tuple(builder for builder in builders if hasattr(builder, "decode_threshold")),
        tuple(builder for builder in builders if hasattr(builder, "reorder_batch_threshold")),
        tuple(builder for builder in builders if hasattr(builder, "num_spec")),
        tuple(
            (builder, state_indices)
            for builder in builders
            if (
                state_indices := _state_indices_for_query_width(
                    builder,
                    query_width,
                )
            )
            is not None
        ),
    )
    if builders:
        plans[query_width] = plan
    return plan


def _pin_runner_query_width(runner: Any, query_width: int) -> None:
    """Make the dominant adaptive width the runner's native host state."""
    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    if runner is None or dispatcher is None:
        return

    runtime_gamma = max(query_width - 1, 0)
    runner.uniform_decode_query_len = query_width
    dispatcher.uniform_decode_query_len = query_width
    runner.decode_token_per_req = query_width
    runner.num_spec_tokens = runtime_gamma
    runner.decode_threshold = query_width
    if hasattr(runner, "reorder_batch_threshold"):
        runner.reorder_batch_threshold = query_width

    (
        decode_builders,
        reorder_builders,
        num_spec_builders,
        state_index_bindings,
    ) = _runner_query_width_pin_plan(runner, query_width)
    for builder in decode_builders:
        builder.decode_threshold = query_width
    for builder in reorder_builders:
        builder.reorder_batch_threshold = query_width
    for builder in num_spec_builders:
        builder.num_spec = runtime_gamma
    for builder, state_indices in state_index_bindings:
        builder.spec_state_indices_tensor = state_indices

    runner._vspec_adaptive_pinned_query_width = query_width


def _is_eagle3_anchor_runtime(
    runner: Any,
    method: str,
    gamma: int,
    query_width: int | None,
    *,
    require_pinned: bool = True,
) -> bool:
    """Return whether a stateful frame can use its native anchor fast path."""
    if method not in {"eagle3", "mtp"} or runner is None or query_width is None:
        return False
    anchor_gamma = getattr(runner, "_vspec_adaptive_anchor_gamma", None)
    if gamma != anchor_gamma or query_width != gamma + 1:
        return False
    if (
        require_pinned
        and getattr(
            runner,
            "_vspec_adaptive_pinned_query_width",
            None,
        )
        != query_width
    ):
        return False
    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    return (
        int(getattr(runner, "num_spec_tokens", -1)) == gamma
        and int(getattr(runner, "uniform_decode_query_len", -1)) == query_width
        and (
            dispatcher is None
            or int(getattr(dispatcher, "uniform_decode_query_len", -1)) == query_width
        )
    )


def _eagle3_native_anchor_query_width(
    runner: Any,
    method: str,
    scheduler_output: Any,
    *,
    cohort_locked: bool,
) -> int | None:
    """Resolve a cohort-locked native frame without scanning requests."""
    if not cohort_locked or bool(scheduler_output.scheduled_new_reqs):
        return None
    gamma = int(getattr(scheduler_output, "num_spec_tokens_to_schedule", -1))
    query_width = gamma + 1
    if not _is_eagle3_anchor_runtime(
        runner,
        method,
        gamma,
        query_width,
        require_pinned=False,
    ):
        return None
    return query_width


def _synchronize_eagle3_width_transition(
    runner: Any,
    method: str,
    gamma: int,
    *,
    enabled: bool,
    synchronize: Any | None = None,
) -> bool:
    """Fence queued graph work before changing stateful EAGLE3 width.

    Async scheduling can prepare the next cohort while the final graph of the
    previous cohort is still executing. EAGLE3's GDN metadata owns tensors
    whose second dimension is the speculative width, so rebinding those
    tensors before the old graph completes can expose a width-5 allocation to
    a width-6 replay. The controller changes width only at a drained-cohort
    boundary; this one-time fence makes that boundary real on the device.
    """
    if not enabled or method != "eagle3" or runner is None:
        return False

    previous_gamma = int(
        getattr(
            runner,
            "_vspec_eagle3_synchronized_gamma",
            getattr(runner, "_vspec_adaptive_anchor_gamma", gamma),
        )
    )
    if previous_gamma == gamma:
        runner._vspec_eagle3_synchronized_gamma = gamma
        return False

    if synchronize is None:
        import torch

        synchronize = torch.npu.synchronize
    synchronize()
    runner._vspec_eagle3_synchronized_gamma = gamma

    drafter = getattr(runner, "drafter", None)
    if drafter is not None:
        # No request survives this boundary. Start the new cohort directly at
        # its selected width instead of executing one compatibility step at
        # the old width.
        drafter._vspec_adaptive_previous_proposal_gamma = gamma

    # The leader rebuilds shared GDN metadata on the first frame of the new
    # cohort. Invalidate its old-width gather plan so followers cannot consume
    # it if their build order changes during the transition.
    for builder in _adaptive_metadata_builders(runner):
        state = getattr(builder, "_vspec_gdn_shared_state", None)
        if state is not None:
            state.metadata = None
            state.gather_indices = None
    return True


@contextmanager
def _draft_capture_query_width(
    runner: Any,
    query_width: int | None,
) -> Any:
    """Expose continuation-only widths to the Draft graph dispatcher."""
    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    merged_query_lens = getattr(
        dispatcher,
        "_vspec_draft_merged_query_lens",
        (),
    )
    if dispatcher is None or query_width not in merged_query_lens:
        yield
        return

    attribute = "_vspec_capture_uniform_query_len"
    had_attribute = hasattr(dispatcher, attribute)
    previous_value = getattr(dispatcher, attribute, None)
    setattr(dispatcher, attribute, query_width)
    try:
        yield
    finally:
        if had_attribute:
            setattr(dispatcher, attribute, previous_value)
        else:
            delattr(dispatcher, attribute)


@contextmanager
def _runtime_runner_query_width(
    proposer: Any,
    query_width: int | None,
) -> Any:
    """Temporarily align shared runner state with the current Target frame."""
    with _runner_query_width(getattr(proposer, "runner", None), query_width):
        yield


@contextmanager
def _runtime_draft_continuation_query_width(
    proposer: Any,
    gamma: int,
) -> Any:
    """Bind the validated gamma-2 continuation width for padded tail batches."""
    # The compact gamma-2 path merges two serial continuation forwards into a
    # four-token descriptor. Wider gammas still have runtime-dependent layouts;
    # forcing ``gamma + 2`` can bind a captured FIA query to shorter metadata.
    if gamma != 2:
        yield
        return
    dispatcher = getattr(
        getattr(proposer, "runner", None),
        "cudagraph_dispatcher",
        None,
    )
    query_width = gamma + 2
    if query_width not in getattr(
        dispatcher,
        "_vspec_draft_merged_query_lens",
        (),
    ):
        yield
        return

    attribute = "_vspec_active_uniform_query_len"
    runtime_attribute = "_vspec_runtime_draft_query_len"
    had_attribute = hasattr(dispatcher, attribute)
    previous_value = getattr(dispatcher, attribute, None)
    had_runtime_attribute = hasattr(dispatcher, runtime_attribute)
    previous_runtime_value = getattr(dispatcher, runtime_attribute, None)
    setattr(dispatcher, attribute, query_width)
    setattr(dispatcher, runtime_attribute, query_width)
    try:
        yield
    finally:
        if had_attribute:
            setattr(dispatcher, attribute, previous_value)
        else:
            delattr(dispatcher, attribute)
        if had_runtime_attribute:
            setattr(
                dispatcher,
                runtime_attribute,
                previous_runtime_value,
            )
        else:
            delattr(dispatcher, runtime_attribute)


@contextmanager
def _runtime_eager_dispatch(proposer: Any, enabled: bool) -> Any:
    """Prevent graph dispatch when the selected Draft body is eager."""
    runner = getattr(proposer, "runner", None)
    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    if dispatcher is None or not enabled:
        yield
        return

    from vllm.config import CUDAGraphMode
    from vllm.forward_context import BatchDescriptor

    previous_dispatch = dispatcher.dispatch

    def dispatch_eager(*args: Any, **kwargs: Any) -> Any:
        num_tokens = kwargs.get(
            "num_tokens",
            args[0] if args else None,
        )
        if num_tokens is None:
            raise RuntimeError("eager Draft dispatch requires num_tokens")
        return CUDAGraphMode.NONE, BatchDescriptor(int(num_tokens))

    dispatcher.dispatch = dispatch_eager
    try:
        yield
    finally:
        dispatcher.dispatch = previous_dispatch


@contextmanager
def _runtime_eager_proposer(proposer: Any, enabled: bool) -> Any:
    """Bypass proposer graph setup for a shape-incompatible transition."""
    if not enabled:
        yield
        return
    previous_use_cuda_graph = proposer.use_cuda_graph
    proposer.use_cuda_graph = False
    try:
        yield
    finally:
        proposer.use_cuda_graph = previous_use_cuda_graph


def _update_async_next_frame_gamma(
    scheduler: Any,
    scheduler_output: Any,
    gamma: int,
) -> None:
    """Repair AsyncScheduler state after a post-schedule gamma decision."""
    scheduler_config = getattr(scheduler, "scheduler_config", None)
    if not getattr(scheduler_config, "async_scheduling", False):
        return
    if gamma == int(getattr(scheduler, "num_spec_tokens", -1)):
        # The native async scheduler already installed the configured-width
        # placeholders. Replacing them here can race queued async frames even
        # though the selected arm did not change.
        return

    current_placeholders = getattr(scheduler, "_spec_token_placeholders", None)
    if current_placeholders is not None and len(current_placeholders) == gamma:
        # A non-native arm can remain active for hundreds of async frames.
        # Rebinding an equivalent list on every frame races requests whose
        # previous Target output is still in flight. New requests already use
        # this scheduler-level list, so only a real width change needs repair.
        return

    placeholders = [-1] * gamma
    scheduler._spec_token_placeholders = placeholders
    for request_id in scheduler_output.num_scheduled_tokens:
        request = scheduler.requests.get(request_id)
        if request is None or getattr(request, "is_prefill_chunk", False):
            continue
        # AsyncScheduler already ran _update_after_schedule with the old gamma.
        # Replace only the next-frame Draft placeholders; current-frame
        # accounting remains tied to scheduled_spec_decode_tokens.
        request.spec_token_ids = placeholders


def _run_with_runtime_gamma(
    proposer: Any,
    requested_gamma: int,
    callback: Any,
    *args: Any,
    **kwargs: Any,
) -> Any:
    previous_gamma = proposer.num_speculative_tokens
    previous_steps = getattr(proposer, "num_draft_steps", previous_gamma)
    previous_threshold = getattr(proposer, "decode_threshold", previous_gamma + 1)
    previous_extra_slots = getattr(proposer, "extra_slots_per_request", None)
    previous_net_slots = getattr(
        proposer,
        "net_num_new_slots_per_request",
        None,
    )
    previous_needs_extra_slots = getattr(
        proposer,
        "needs_extra_input_slots",
        None,
    )
    proposer.num_speculative_tokens = requested_gamma
    proposer.num_draft_steps = requested_gamma
    proposer.decode_threshold = requested_gamma + 1
    if getattr(proposer, "parallel_drafting", False):
        proposer.extra_slots_per_request = requested_gamma
        proposer.net_num_new_slots_per_request = requested_gamma - (
            1
            if (
                getattr(proposer, "pass_hidden_states_to_model", False)
                and getattr(proposer, "method", None) != "dflash"
            )
            else 0
        )
        proposer.needs_extra_input_slots = proposer.net_num_new_slots_per_request > 0
    try:
        return callback(proposer, *args, **kwargs)
    finally:
        proposer.num_speculative_tokens = previous_gamma
        proposer.num_draft_steps = previous_steps
        proposer.decode_threshold = previous_threshold
        if previous_extra_slots is not None:
            proposer.extra_slots_per_request = previous_extra_slots
        if previous_net_slots is not None:
            proposer.net_num_new_slots_per_request = previous_net_slots
        if previous_needs_extra_slots is not None:
            proposer.needs_extra_input_slots = previous_needs_extra_slots


def _proposal_execution_gamma(
    method: str | None,
    requested_gamma: int,
    previous_gamma: int,
) -> int:
    """Keep serial EAGLE-family state aligned while reducing proposal width."""
    if method in {"eagle", "eagle3"} and 0 < requested_gamma < previous_gamma:
        return previous_gamma
    return requested_gamma


def _online_initial_gamma(
    method: str,
    min_gamma: int,
    max_gamma: int,
) -> int | None:
    """Choose a graph-backed cold-start arm without restricting exploration."""
    if method == "draft_model" and min_gamma <= 2 <= max_gamma:
        return 2
    if method == "eagle3":
        # Gamma 5 is only the graph-backed cold-start prior.  All configured
        # arms remain available to the online model and UCB selector.
        return min(max_gamma, max(min_gamma, 5))
    if method == "mtp":
        # MTP2 rolls the two-layer head repeatedly. Gamma 4 is the measured
        # B16 knee while 2 and 6 remain explicit online candidates.
        anchor = min(max_gamma, max(min_gamma, 4))
        return anchor - (anchor % 2)
    return None


def _can_use_stable_configured_draft_path(
    method: str | None,
    requested_gamma: int,
    previous_gamma: int,
    configured_gamma: int,
    *,
    adaptive_full_graph: bool,
    entropy_stop: bool,
    native_gamma: int | None = None,
) -> bool:
    """Return whether the proposal can keep its native FULL-graph state."""
    if not adaptive_full_graph or entropy_stop or requested_gamma != previous_gamma:
        return False
    if method == "draft_model":
        # Serial Draft anchors its native graph at gamma 2 when that arm is
        # available, even if the configured capacity is wider.
        return configured_gamma >= 2 and requested_gamma == 2
    return requested_gamma == (configured_gamma if native_gamma is None else native_gamma)


def _force_non_native_serial_draft_target_eager(
    method: str,
    adaptive_full_graph: bool,
    query_width: int | None,
) -> bool:
    """Keep dynamic serial-Draft probes off incompatible Target graph widths."""
    return (
        method == "draft_model"
        and adaptive_full_graph
        and query_width is not None
        and query_width != 3
    )


def _force_eagle3_non_decode_target_eager(
    method: str,
    adaptive_full_graph: bool,
    query_width: int | None,
) -> bool:
    """Keep EAGLE3 admission and heterogeneous frames off decode graphs."""
    return method == "eagle3" and adaptive_full_graph and (query_width is None or query_width <= 1)


def _copy_dynamic_draft_tokens(
    destination: Any,
    source: Any,
    *,
    zeros_only: bool = False,
) -> None:
    num_reqs, num_spec_tokens = source.shape[:2]
    if num_spec_tokens > destination.shape[1]:
        raise RuntimeError(
            "dynamic Draft output exceeds the configured D2H buffer width: "
            f"runtime={num_spec_tokens}, configured={destination.shape[1]}"
        )
    active = destination[:num_reqs, :num_spec_tokens]
    if zeros_only:
        active.zero_()
    else:
        active.copy_(source, non_blocking=True)
    if num_spec_tokens < destination.shape[1]:
        destination[:num_reqs, num_spec_tokens:].fill_(-1)


def _trim_placeholder_suffixes(draft_token_ids: Any) -> Any:
    """Convert fixed-width device output rows into scheduler-visible lengths."""
    for row in draft_token_ids.draft_token_ids:
        try:
            first_placeholder = row.index(-1)
        except ValueError:
            continue
        del row[first_placeholder:]
    return draft_token_ids


def _unwrap_model_runner_output(result: Any) -> Any:
    output = getattr(result, "model_runner_output", None)
    if output is None:
        output = getattr(result, "_model_runner_output", result)
    return output


def _native_full_graph_gamma(
    proposer: Any,
    configured_gamma: int,
    min_gamma: int,
) -> int:
    """Choose which adaptive arm owns the host's native FULL graph wrapper."""
    explicit_gamma = getattr(
        proposer,
        "_vspec_adaptive_graph_native_gamma",
        None,
    )
    if explicit_gamma is not None:
        native_gamma = int(explicit_gamma)
        if not min_gamma <= native_gamma <= configured_gamma:
            raise RuntimeError(
                "adaptive native graph gamma is outside the configured range: "
                f"native={native_gamma}, range=[{min_gamma}, {configured_gamma}]"
            )
        return native_gamma
    if getattr(proposer, "method", None) == "draft_model" and min_gamma <= 2 <= configured_gamma:
        return 2
    if getattr(proposer, "method", None) == "eagle3":
        return min(configured_gamma, max(min_gamma, 5))
    if getattr(proposer, "method", None) == "mtp":
        anchor = min(configured_gamma, max(min_gamma, 4))
        return anchor - (anchor % 2)
    return configured_gamma


def _configure_serial_draft_runtime_anchor(
    runner: Any,
    method: str,
    min_gamma: int,
    max_gamma: int,
) -> int | None:
    """Keep gamma-2 hot while preserving all buffers at max-gamma capacity."""
    if method != "draft_model" or not min_gamma <= 2 <= max_gamma:
        return None

    anchor_gamma = 2
    query_width = anchor_gamma + 1
    configured_target_gamma = int(runner.num_spec_tokens)
    if configured_target_gamma < max_gamma:
        raise RuntimeError(
            "Target runner capacity is smaller than the adaptive range: "
            f"capacity={configured_target_gamma}, max_gamma={max_gamma}"
        )
    runner._vspec_adaptive_configured_target_gamma = configured_target_gamma
    runner.num_spec_tokens = anchor_gamma
    runner.prev_num_spec_tokens = anchor_gamma
    runner.uniform_decode_query_len = query_width
    runner.decode_token_per_req = query_width
    runner.decode_threshold = query_width
    if hasattr(runner, "reorder_batch_threshold"):
        runner.reorder_batch_threshold = query_width

    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    if dispatcher is not None:
        dispatcher.uniform_decode_query_len = query_width

    drafter = getattr(runner, "drafter", None)
    if drafter is not None:
        configured_draft_gamma = int(drafter.num_speculative_tokens)
        if configured_draft_gamma < max_gamma:
            raise RuntimeError(
                "Draft proposer capacity is smaller than the adaptive range: "
                f"capacity={configured_draft_gamma}, max_gamma={max_gamma}"
            )
        drafter._vspec_adaptive_configured_gamma = configured_draft_gamma
        drafter.num_speculative_tokens = anchor_gamma
        if hasattr(drafter, "num_draft_steps"):
            drafter.num_draft_steps = anchor_gamma
        if hasattr(drafter, "decode_threshold"):
            drafter.decode_threshold = query_width
    return anchor_gamma


def _configure_eagle3_runtime_anchor(
    runner: Any,
    method: str,
    min_gamma: int,
    max_gamma: int,
) -> int | None:
    """Configure a native EAGLE3 arm while retaining graphs for all arms."""
    if method != "eagle3" or max_gamma < 1:
        return None

    anchor_gamma = _online_initial_gamma(method, min_gamma, max_gamma)
    if anchor_gamma is None:
        return None
    query_width = anchor_gamma + 1
    configured_target_gamma = int(
        getattr(
            runner,
            "_vspec_adaptive_configured_target_gamma",
            runner.num_spec_tokens,
        )
    )
    if configured_target_gamma < max_gamma:
        raise RuntimeError(
            "Target runner capacity is smaller than the adaptive range: "
            f"capacity={configured_target_gamma}, max_gamma={max_gamma}"
        )
    runner._vspec_adaptive_configured_target_gamma = configured_target_gamma
    runner._vspec_adaptive_anchor_gamma = anchor_gamma
    runner._vspec_adaptive_anchor_uses_configured_width = anchor_gamma == configured_target_gamma
    if runner._vspec_adaptive_anchor_uses_configured_width:
        runner._vspec_adaptive_pinned_query_width = query_width
    runner.num_spec_tokens = anchor_gamma
    runner.prev_num_spec_tokens = anchor_gamma
    runner.uniform_decode_query_len = query_width
    runner.decode_token_per_req = query_width
    runner.decode_threshold = query_width
    if hasattr(runner, "reorder_batch_threshold"):
        runner.reorder_batch_threshold = query_width

    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    if dispatcher is not None:
        dispatcher.uniform_decode_query_len = query_width

    drafter = getattr(runner, "drafter", None)
    if drafter is not None:
        configured_draft_gamma = int(
            getattr(
                drafter,
                "_vspec_adaptive_configured_gamma",
                drafter.num_speculative_tokens,
            )
        )
        if configured_draft_gamma < max_gamma:
            raise RuntimeError(
                "EAGLE3 proposer capacity is smaller than the adaptive range: "
                f"capacity={configured_draft_gamma}, max_gamma={max_gamma}"
            )
        drafter._vspec_adaptive_configured_gamma = configured_draft_gamma
        drafter._vspec_adaptive_graph_min_gamma = min_gamma
        drafter._vspec_adaptive_graph_max_gamma = max_gamma
        drafter._vspec_adaptive_candidate_gammas = tuple(range(min_gamma, max_gamma + 1))
        drafter._vspec_adaptive_graph_native_gamma = anchor_gamma
        drafter.num_speculative_tokens = anchor_gamma
        if hasattr(drafter, "num_draft_steps"):
            drafter.num_draft_steps = anchor_gamma
        if hasattr(drafter, "decode_threshold"):
            drafter.decode_threshold = query_width
        if getattr(drafter, "parallel_drafting", False):
            drafter.extra_slots_per_request = anchor_gamma
            drafter.net_num_new_slots_per_request = anchor_gamma - (
                1
                if (
                    getattr(drafter, "pass_hidden_states_to_model", False)
                    and getattr(drafter, "method", None) != "dflash"
                )
                else 0
            )
            drafter.needs_extra_input_slots = drafter.net_num_new_slots_per_request > 0
    return anchor_gamma


def _configure_mtp_runtime_anchor(
    runner: Any,
    method: str,
    min_gamma: int,
    max_gamma: int,
) -> int | None:
    """Keep native MTP state at gamma 4 with capacity through gamma 6."""
    if method != "mtp":
        return None

    anchor_gamma = _online_initial_gamma(method, min_gamma, max_gamma)
    if anchor_gamma is None:
        return None
    configured_target_gamma = int(runner.num_spec_tokens)
    if configured_target_gamma < max_gamma:
        raise RuntimeError(
            "MTP Target runner capacity is smaller than the adaptive range: "
            f"capacity={configured_target_gamma}, max_gamma={max_gamma}"
        )

    query_width = anchor_gamma + 1
    runner._vspec_adaptive_configured_target_gamma = configured_target_gamma
    runner._vspec_adaptive_anchor_gamma = anchor_gamma
    runner._vspec_adaptive_anchor_uses_configured_width = anchor_gamma == configured_target_gamma
    runner.num_spec_tokens = anchor_gamma
    runner.prev_num_spec_tokens = anchor_gamma
    runner.uniform_decode_query_len = query_width
    runner.decode_token_per_req = query_width
    runner.decode_threshold = query_width
    if hasattr(runner, "reorder_batch_threshold"):
        runner.reorder_batch_threshold = query_width

    dispatcher = getattr(runner, "cudagraph_dispatcher", None)
    if dispatcher is not None:
        dispatcher.uniform_decode_query_len = query_width

    drafter = getattr(runner, "drafter", None)
    if drafter is not None:
        configured_draft_gamma = int(drafter.num_speculative_tokens)
        if configured_draft_gamma < max_gamma:
            raise RuntimeError(
                "MTP proposer capacity is smaller than the adaptive range: "
                f"capacity={configured_draft_gamma}, max_gamma={max_gamma}"
            )
        candidates = tuple(range(min_gamma, max_gamma + 1, 2))
        drafter._vspec_adaptive_candidate_gammas = candidates
        drafter._vspec_adaptive_configured_gamma = configured_draft_gamma
        drafter._vspec_adaptive_graph_native_gamma = anchor_gamma
        drafter.num_speculative_tokens = anchor_gamma
        if hasattr(drafter, "num_draft_steps"):
            drafter.num_draft_steps = anchor_gamma
        if hasattr(drafter, "decode_threshold"):
            drafter.decode_threshold = query_width
    return anchor_gamma


def _initialize_full_graph_runnables(
    proposer: Any,
    configured_gamma: int,
    min_gamma: int,
) -> dict[int, Any] | None:
    from vllm.config import CUDAGraphMode
    from vllm_ascend.compilation.acl_graph import ACLGraphWrapper

    existing = getattr(
        proposer,
        "_vspec_adaptive_full_graph_runnables",
        None,
    )
    if existing is not None:
        return existing

    runnable = proposer._runnable
    if (
        not proposer.use_cuda_graph
        or not isinstance(runnable, ACLGraphWrapper)
        or runnable.runtime_mode != CUDAGraphMode.FULL
    ):
        return None

    graph_min_gamma = max(
        1,
        int(getattr(proposer, "_vspec_adaptive_graph_min_gamma", min_gamma)),
    )
    native_gamma = _native_full_graph_gamma(
        proposer,
        configured_gamma,
        graph_min_gamma,
    )
    body = runnable.unwrap()
    graph_max_gamma = min(
        configured_gamma,
        int(getattr(proposer, "_vspec_adaptive_graph_max_gamma", configured_gamma)),
    )
    candidate_gammas = tuple(
        gamma
        for gamma in getattr(
            proposer,
            "_vspec_adaptive_candidate_gammas",
            range(graph_min_gamma, graph_max_gamma + 1),
        )
        if graph_min_gamma <= gamma <= graph_max_gamma
    )
    runnables = {native_gamma: runnable}
    for gamma in reversed(candidate_gammas):
        if gamma == native_gamma:
            continue
        runnables[gamma] = call_with_supported_kwargs(
            ACLGraphWrapper,
            body,
            proposer.vllm_config,
            runtime_mode=CUDAGraphMode.FULL,
            cudagraph_options=runnable.aclgraph_options,
            use_eagle=runnable.use_eagle,
            enable_enpu=runnable.enable_enpu,
            is_draft_model=True,
        )
    proposer._vspec_adaptive_full_graph_runnables = runnables
    proposer._vspec_adaptive_full_graph_body = body
    return runnables


def _empty_graph_params_like(graph_params: Any) -> Any:
    """Create an isolated graph-parameter table with identical shape keys."""
    graph_params_type = type(graph_params)
    sizes = tuple(graph_params.events)
    values = {}
    for field in fields(graph_params):
        source = getattr(graph_params, field.name)
        if not isinstance(source, dict):
            raise TypeError(f"unsupported graph parameter field: {field.name}")
        if field.name == "workspaces":
            values[field.name] = {size: None for size in sizes}
        else:
            values[field.name] = {size: [] for size in sizes}
    return graph_params_type(**values)


def _install_draft_entropy_probe(proposer: Any) -> None:
    """Capture per-request entropy inside each Draft logits operation."""
    if getattr(proposer, "_vspec_entropy_probe_installed", False):
        return
    model = proposer.model
    original_compute_logits = model.compute_logits

    def compute_logits(*args: Any, **kwargs: Any) -> Any:
        result = original_compute_logits(*args, **kwargs)
        if not getattr(proposer, "_vspec_entropy_measure_enabled", True):
            return result
        raw_logits = getattr(result, "logits", result)
        try:
            import torch

            if torch.is_tensor(raw_logits):
                entropy = topk_entropy(
                    raw_logits,
                    int(proposer._vspec_entropy_topk),
                )
                proposer._vspec_entropy_recent_values.append(entropy)
        except AttributeError:
            pass
        return result

    proposer._vspec_entropy_recent_values = []
    proposer._vspec_entropy_graph_values = {}
    proposer._vspec_entropy_original_compute_logits = original_compute_logits
    model.compute_logits = compute_logits
    proposer._vspec_entropy_probe_installed = True


def _draft_entropy_matrix(
    proposer: Any,
    gamma: int,
    batch_size: int,
    topk: int,
) -> Any | None:
    """Read graph-stable current-round entropy as [position, request]."""
    proposer._vspec_entropy_topk = topk
    recent = list(getattr(proposer, "_vspec_entropy_recent_values", ()))
    if len(recent) >= gamma:
        entropy_by_position = recent[-gamma:]
    else:
        captured_by_batch = getattr(
            proposer,
            "_vspec_entropy_graph_values",
            {},
        ).get(gamma, {})
        captured_batch = next(
            (size for size in sorted(captured_by_batch) if size >= batch_size),
            None,
        )
        entropy_by_position = (
            list(captured_by_batch[captured_batch]) if captured_batch is not None else []
        )
    if len(entropy_by_position) < gamma:
        return None
    import torch

    return torch.stack(
        [value[:batch_size] for value in entropy_by_position[:gamma]],
        dim=0,
    )


def _prepare_gamma_graph_params(
    proposer: Any,
    configured_gamma: int,
    min_gamma: int,
    base_graph_params: Any,
) -> dict[int, Any] | None:
    if base_graph_params is None:
        return None
    source_id = id(base_graph_params)
    if getattr(proposer, "_vspec_adaptive_graph_params_source_id", None) != source_id:
        graph_min_gamma = max(
            1,
            int(getattr(proposer, "_vspec_adaptive_graph_min_gamma", min_gamma)),
        )
        native_gamma = _native_full_graph_gamma(
            proposer,
            configured_gamma,
            graph_min_gamma,
        )
        graph_max_gamma = min(
            configured_gamma,
            int(getattr(proposer, "_vspec_adaptive_graph_max_gamma", configured_gamma)),
        )
        candidate_gammas = tuple(
            gamma
            for gamma in getattr(
                proposer,
                "_vspec_adaptive_candidate_gammas",
                range(graph_min_gamma, graph_max_gamma + 1),
            )
            if graph_min_gamma <= gamma <= graph_max_gamma
        )
        proposer._vspec_adaptive_graph_params_by_gamma = {
            gamma: (
                base_graph_params
                if gamma == native_gamma
                else _empty_graph_params_like(base_graph_params)
            )
            for gamma in candidate_gammas
        }
        proposer._vspec_adaptive_graph_params_source_id = source_id
    return proposer._vspec_adaptive_graph_params_by_gamma


def _prepare_target_graph_params(
    runner: Any,
    base_graph_params: Any,
    query_widths: tuple[int, ...],
) -> dict[int, Any] | None:
    if base_graph_params is None:
        return None
    native_width = int(
        getattr(
            runner,
            "uniform_decode_query_len",
            max(query_widths),
        )
    )
    if native_width not in query_widths:
        native_width = max(query_widths)
    source_key = (id(base_graph_params), query_widths, native_width)
    if getattr(runner, "_vspec_adaptive_target_graph_source_key", None) != source_key:
        runner._vspec_adaptive_target_graph_params_by_width = {
            width: (
                base_graph_params
                if width == native_width
                else _empty_graph_params_like(base_graph_params)
            )
            for width in query_widths
        }
        runner._vspec_adaptive_target_graph_source_key = source_key
    return runner._vspec_adaptive_target_graph_params_by_width


def _get_full_graph_runnable_for_gamma(
    proposer: Any,
    gamma: int,
    configured_gamma: int,
    min_gamma: int,
) -> Any:
    runnables = _initialize_full_graph_runnables(
        proposer,
        configured_gamma,
        min_gamma,
    )
    if runnables is None:
        return proposer._runnable
    return runnables[gamma]


def _draft_capture_request_count(proposer: Any, kwargs: dict[str, Any]) -> int | None:
    """Return the logical batch encoded by a Draft continuation descriptor."""
    if getattr(proposer, "method", None) != "draft_model":
        return None
    descriptor = kwargs.get("batch_descriptor")
    num_reqs = kwargs.get("num_reqs")
    descriptor_reqs = getattr(descriptor, "num_reqs", None)
    if not descriptor_reqs or num_reqs is None:
        return None
    query_width = _batch_descriptor_query_width(descriptor)
    dispatcher = getattr(getattr(proposer, "runner", None), "cudagraph_dispatcher", None)
    continuation_widths = getattr(
        dispatcher,
        "_vspec_draft_merged_query_lens",
        (),
    )
    if query_width not in continuation_widths:
        return None
    if int(num_reqs) != int(descriptor_reqs):
        raise RuntimeError(
            "Draft continuation capture request count does not match its descriptor: "
            f"runtime={num_reqs}, descriptor={descriptor_reqs}"
        )
    return int(num_reqs)


def _draft_capture_gamma(
    proposer: Any,
    kwargs: dict[str, Any],
) -> int | None:
    """Map a continuation capture descriptor to its runtime gamma."""
    if _draft_capture_request_count(proposer, kwargs) is None:
        return None
    query_width = _batch_descriptor_query_width(kwargs.get("batch_descriptor"))
    if query_width is None or query_width < 3:
        return None
    return query_width - 2


def _adaptive_draft_capture_gammas(
    configured_gamma: int,
    min_gamma: int,
    capture_gamma: int | None,
    native_gamma: int | None = None,
) -> tuple[int, ...]:
    """Select the runtime gamma(s) compatible with a capture descriptor."""
    graph_min_gamma = max(1, min_gamma)
    if capture_gamma is None:
        if native_gamma is not None:
            if not graph_min_gamma <= native_gamma <= configured_gamma:
                raise RuntimeError(
                    "native Draft graph gamma is outside the configured range: "
                    f"native={native_gamma}, range=[{graph_min_gamma}, "
                    f"{configured_gamma}]"
                )
            return (native_gamma,)
        return tuple(range(configured_gamma, graph_min_gamma - 1, -1))
    if not graph_min_gamma <= capture_gamma <= configured_gamma:
        raise RuntimeError(
            "Draft continuation capture gamma is outside the configured range: "
            f"capture={capture_gamma}, range=[{graph_min_gamma}, "
            f"{configured_gamma}]"
        )
    return (capture_gamma,)


def _draft_capture_runnable(
    proposer: Any,
    graph_runnable: Any,
    num_reqs: int,
) -> Any:
    """Force the graph output batch to use descriptor request rows."""

    def run_with_descriptor_batch(*args: Any, **kwargs: Any) -> Any:
        kwargs["batch_size"] = num_reqs
        token_indices = kwargs.get("token_indices_to_sample")
        if token_indices is not None:
            token_count = num_reqs * proposer.extra_slots_per_request
            kwargs["token_indices_to_sample"] = token_indices[:token_count]
        return graph_runnable(*args, **kwargs)

    return run_with_descriptor_batch


def _capture_all_adaptive_draft_graphs(
    proposer: Any,
    callback: Any,
    configured_gamma: int,
    min_gamma: int,
    *args: Any,
    **kwargs: Any,
) -> Any:
    """Warm and capture one FULL Draft graph per stable runtime gamma."""
    runnables = _initialize_full_graph_runnables(
        proposer,
        configured_gamma,
        min_gamma,
    )
    if runnables is None:
        return callback(proposer, *args, **kwargs)

    from vllm_ascend.compilation import acl_graph as acl_graph_module

    base_graph_params = acl_graph_module._draft_graph_params
    graph_params_by_gamma = _prepare_gamma_graph_params(
        proposer,
        configured_gamma,
        min_gamma,
        base_graph_params,
    )

    previous_runnable = proposer._runnable
    capture_num_reqs = _draft_capture_request_count(proposer, kwargs)
    capture_gamma = _draft_capture_gamma(proposer, kwargs)
    discarded_graph_params: dict[int, Any] = {}
    previous_entropy_enabled = getattr(
        proposer,
        "_vspec_entropy_measure_enabled",
        True,
    )
    configured_result = None
    try:
        # Capture the largest graph first so smaller graphs reuse its pool.
        requested_capture_gammas = _adaptive_draft_capture_gammas(
            configured_gamma,
            min_gamma,
            capture_gamma,
            native_gamma=(
                _native_full_graph_gamma(
                    proposer,
                    configured_gamma,
                    max(1, min_gamma),
                )
                if getattr(proposer, "method", None) == "draft_model"
                else None
            ),
        )
        capture_gammas = tuple(
            gamma
            for gamma in requested_capture_gammas
            if gamma in runnables
            and (graph_params_by_gamma is None or gamma in graph_params_by_gamma)
        )
        if not capture_gammas:
            return callback(proposer, *args, **kwargs)
        result_gamma = max(capture_gammas)
        for gamma in capture_gammas:
            proposer._vspec_entropy_measure_enabled = gamma >= _MIN_CONFIDENCE_STOP_GAMMA
            if getattr(proposer, "_vspec_entropy_probe_installed", False):
                proposer._vspec_entropy_recent_values = []
            graph_runnable = runnables[gamma]
            proposer._runnable = (
                _draft_capture_runnable(
                    proposer,
                    graph_runnable,
                    capture_num_reqs,
                )
                if capture_num_reqs is not None
                else graph_runnable
            )
            if graph_params_by_gamma is not None:
                if capture_gamma is None or gamma == capture_gamma:
                    selected_graph_params = graph_params_by_gamma[gamma]
                else:
                    selected_graph_params = discarded_graph_params.setdefault(
                        gamma,
                        _empty_graph_params_like(base_graph_params),
                    )
                acl_graph_module._draft_graph_params = selected_graph_params
            result = _run_with_runtime_gamma(
                proposer,
                gamma,
                callback,
                *args,
                **kwargs,
            )
            if getattr(proposer, "_vspec_entropy_probe_installed", False):
                recent = proposer._vspec_entropy_recent_values
                if len(recent) >= gamma:
                    captured = tuple(recent[-gamma:])
                    captured_batch = int(captured[0].shape[0])
                    proposer._vspec_entropy_graph_values.setdefault(
                        gamma,
                        {},
                    )[captured_batch] = captured
            if gamma == result_gamma or capture_gamma is not None:
                configured_result = result
    finally:
        proposer._vspec_entropy_measure_enabled = previous_entropy_enabled
        proposer._runnable = previous_runnable
        acl_graph_module._draft_graph_params = base_graph_params
    return configured_result


def _full_graph_batch_matches_capture(
    common_attn_metadata: Any,
    target_model_batch_desc: Any,
    gamma: int,
    capture_sizes: list[int] | None = None,
) -> bool:
    if common_attn_metadata is None or target_model_batch_desc is None:
        return False
    num_tokens = int(getattr(target_model_batch_desc, "num_tokens", 0))
    if num_tokens <= 0:
        return False
    actual_batch = int(common_attn_metadata.batch_size())
    actual_tokens = int(
        getattr(
            common_attn_metadata,
            "num_actual_tokens",
            actual_batch * (gamma + 1),
        )
    )
    if actual_tokens < actual_batch * (gamma + 1):
        return False
    if capture_sizes:
        index = bisect_left(capture_sizes, actual_tokens)
        return index < len(capture_sizes) and num_tokens == capture_sizes[index]
    return num_tokens == actual_tokens


def _draft_full_graph_batch_matches_capture(
    proposer: Any,
    common_attn_metadata: Any,
    _target_model_batch_desc: Any,
    gamma: int,
) -> bool:
    """Return whether a padded Draft continuation graph covers this batch."""
    if common_attn_metadata is None:
        return False

    actual_batch = int(common_attn_metadata.batch_size())
    if actual_batch <= 0:
        return False

    dispatcher = getattr(
        getattr(proposer, "runner", None),
        "cudagraph_dispatcher",
        None,
    )
    continuation_width = gamma + 2
    if continuation_width not in getattr(
        dispatcher,
        "_vspec_draft_merged_query_lens",
        (),
    ):
        return False

    graph_keys = getattr(dispatcher, "cudagraph_keys", {})
    descriptor_groups = graph_keys.values() if hasattr(graph_keys, "values") else ()
    return any(
        bool(getattr(descriptor, "uniform", False))
        and getattr(descriptor, "num_reqs", None) is not None
        and int(descriptor.num_reqs) >= actual_batch
        and int(getattr(descriptor, "num_tokens", 0))
        == int(descriptor.num_reqs) * continuation_width
        for descriptors in descriptor_groups
        for descriptor in descriptors
    )


def apply_adaptive_patches(settings: PluginSettings) -> bool:
    """Install scheduler feedback and Ascend dynamic-gamma runtime hooks."""
    if not settings.adaptive_speculation:
        return False
    if settings.adaptive_min_gamma == settings.adaptive_max_gamma:
        logger.warning(
            "vSpec Adaptive gamma range is fixed at %d; using the native fixed-gamma runtime",
            settings.adaptive_max_gamma,
        )
        return False

    if _disable_fixed_width_eagle_state_kernel(
        settings.method,
        settings.adaptive_min_gamma,
        settings.adaptive_max_gamma,
        os.environ,
    ):
        logger.warning(
            "%s was isolated from dynamic EAGLE transitions; it is only "
            "enabled for stable frames at the runtime state width",
            _EAGLE_UNIFORM_STATE_ENV,
        )

    from vllm.config import CUDAGraphMode
    from vllm.v1.core.sched.scheduler import Scheduler
    from vllm.v1.cudagraph_dispatcher import CudagraphDispatcher
    from vllm.v1.spec_decode.metrics import SpecDecodingStats
    from vllm.v1.worker.gpu_model_runner import AsyncGPUModelRunnerOutput
    from vllm_ascend.spec_decode.llm_base_proposer import (
        AscendSpecDecodeBaseProposer,
    )
    from vllm_ascend.worker import model_runner_v1 as model_runner_module
    from vllm_ascend.worker.model_runner_v1 import NPUModelRunner

    AscendDflashProposer = None
    if settings.method == "dflash":
        from vllm_ascend.spec_decode.dflash_proposer import (
            AscendDflashProposer,
        )

    profile = None
    if settings.adaptive_policy == "profile":
        profile = AdaptiveProfile.load(settings.adaptive_profile_path)
        if settings.adaptive_max_gamma > profile.max_speculative_tokens:
            raise RuntimeError(
                "vSpec Adaptive max gamma exceeds profile capacity: "
                f"configured={settings.adaptive_max_gamma}, "
                f"profile={profile.max_speculative_tokens}"
            )
        expected_parallel_profile = settings.method == "dflash"
        if profile.draft_parallel != expected_parallel_profile:
            raise RuntimeError(
                "vSpec Adaptive profile draft_parallel does not match method: "
                f"method={settings.method}, profile={profile.draft_parallel}"
            )

    # Online control measures realized output cadence at the scheduler. Model
    # execution intervals overlap under async scheduling and cannot be summed
    # into serving goodput.
    measure_step_latency = (
        settings.adaptive_latency_calibration and settings.adaptive_policy != "online"
    )
    runtime_switch_env = (
        "HUST_VSPEC_MTP_ASYNC_RUNTIME_SWITCH"
        if settings.method == "mtp"
        else "HUST_VSPEC_EAGLE3_ASYNC_RUNTIME_SWITCH"
    )
    stateful_cohort_locked = (
        settings.method in {"eagle3", "mtp"}
        and settings.adaptive_async
        and os.environ.get(runtime_switch_env, "0") != "1"
    )
    draft_stopper = (
        EntropyDraftStopper(
            max_gamma=settings.adaptive_max_gamma,
            min_gamma=settings.adaptive_min_gamma,
            threshold=settings.adaptive_entropy_threshold,
            scale=settings.adaptive_entropy_scale,
        )
        if settings.adaptive_entropy_stop
        else None
    )

    applied = False
    if measure_step_latency and not getattr(
        AsyncGPUModelRunnerOutput,
        ASYNC_OUTPUT_PATCH_MARKER,
        False,
    ):
        original_async_get_output = AsyncGPUModelRunnerOutput.get_output

        def adaptive_async_get_output(self: Any) -> Any:
            output = original_async_get_output(self)
            measurement = getattr(
                output,
                "vspec_adaptive_step_measurement",
                None,
            )
            if measurement and "started_at" in measurement:
                started_at = float(measurement.pop("started_at"))
                measurement["latency_ms"] = (time.perf_counter() - started_at) * 1000.0
                if settings.adaptive_trace:
                    logger.warning(
                        "vSpec Adaptive async latency completed: gamma=%d batch=%d latency_ms=%.4f",
                        measurement["gamma"],
                        measurement["batch_size"],
                        measurement["latency_ms"],
                    )
            return output

        AsyncGPUModelRunnerOutput.get_output = adaptive_async_get_output
        setattr(
            AsyncGPUModelRunnerOutput,
            ASYNC_OUTPUT_PATCH_MARKER,
            True,
        )
        applied = True
    if not getattr(CudagraphDispatcher, DISPATCHER_PATCH_MARKER, False):
        original_dispatch = CudagraphDispatcher.dispatch

        def adaptive_dispatch(
            self: Any,
            num_tokens: int,
            uniform_decode: bool = False,
            has_lora: bool = False,
            num_active_loras: int = 0,
            valid_modes: Any = None,
            invalid_modes: Any = None,
            uniform_decode_query_len: int | None = None,
        ) -> Any:
            query_width = _active_dispatch_query_width(
                self,
                uniform_decode_query_len,
            )
            if uniform_decode and not _uniform_decode_fits_capture_bucket(
                self,
                num_tokens,
                query_width,
            ):
                uniform_decode = False
            return call_with_supported_kwargs(
                original_dispatch,
                self,
                num_tokens=num_tokens,
                uniform_decode=uniform_decode,
                has_lora=has_lora,
                num_active_loras=num_active_loras,
                valid_modes=valid_modes,
                invalid_modes=invalid_modes,
                uniform_decode_query_len=uniform_decode_query_len,
            )

        CudagraphDispatcher.dispatch = adaptive_dispatch
        setattr(CudagraphDispatcher, DISPATCHER_PATCH_MARKER, True)
        applied = True

    original_restore_capture_sizes = getattr(
        model_runner_module,
        "_restore_nanoparl_dynamic_graph_capture_sizes",
        None,
    )
    if not getattr(
        model_runner_module,
        CAPTURE_SIZE_PATCH_MARKER,
        False,
    ):

        def restore_adaptive_capture_sizes(
            compilation_config: Any,
            *,
            method: str | None,
            requested_capture_sizes: list[int],
        ) -> bool:
            if settings.adaptive_full_graph and requested_capture_sizes:
                exact_sizes = sorted(set(int(size) for size in requested_capture_sizes))
                if any(size <= 0 for size in exact_sizes):
                    raise ValueError("vSpec Adaptive graph capture sizes must be positive")
                compilation_config.cudagraph_capture_sizes = exact_sizes
                compilation_config.max_cudagraph_capture_size = exact_sizes[-1]
                return True
            if original_restore_capture_sizes is None:
                return False
            return original_restore_capture_sizes(
                compilation_config,
                method=method,
                requested_capture_sizes=requested_capture_sizes,
            )

        model_runner_module._restore_nanoparl_dynamic_graph_capture_sizes = (
            restore_adaptive_capture_sizes
        )
        setattr(
            model_runner_module,
            CAPTURE_SIZE_PATCH_MARKER,
            True,
        )
        applied = True

    if not getattr(Scheduler, SCHEDULER_PATCH_MARKER, False):
        original_scheduler_init = Scheduler.__init__
        original_schedule = Scheduler.schedule
        original_make_stats = Scheduler.make_spec_decoding_stats
        original_update_from_output = Scheduler.update_from_output
        original_update_draft_token_ids = Scheduler.update_draft_token_ids

        def scheduler_init(self: Any, *args: Any, **kwargs: Any) -> None:
            original_scheduler_init(self, *args, **kwargs)
            if self.scheduler_config.async_scheduling and not settings.adaptive_async:
                raise RuntimeError("vSpec Adaptive does not yet support async scheduling")
            graph_mode = self.vllm_config.compilation_config.cudagraph_mode
            allowed_graph_modes = {CUDAGraphMode.NONE, CUDAGraphMode.PIECEWISE}
            if settings.adaptive_full_graph:
                allowed_graph_modes.update(
                    {
                        CUDAGraphMode.FULL,
                        CUDAGraphMode.FULL_DECODE_ONLY,
                        CUDAGraphMode.FULL_AND_PIECEWISE,
                    }
                )
            if graph_mode not in allowed_graph_modes:
                raise RuntimeError(
                    f"vSpec Adaptive requires Eager or PIECEWISE graph mode, got {graph_mode}"
                )
            common_options = {
                "max_gamma": settings.adaptive_max_gamma,
                "min_gamma": settings.adaptive_min_gamma,
                "ewma_weight": settings.adaptive_ewma_weight,
                "control_interval": settings.adaptive_control_interval,
                "hysteresis": settings.adaptive_hysteresis,
                "max_gamma_step": settings.adaptive_max_gamma_step,
                "max_batched_tokens": int(self.scheduler_config.max_num_batched_tokens),
            }
            if settings.adaptive_policy == "online":
                self._vspec_adaptive_controller = OnlineGammaController(
                    **common_options,
                    candidate_stride=(2 if settings.method == "mtp" else 1),
                    window_size=settings.adaptive_online_window,
                    exploration=settings.adaptive_online_exploration,
                    warmup_samples=(settings.adaptive_online_warmup_samples),
                    warmup_return=(settings.adaptive_online_warmup_return),
                    inflight_warmup_padding=(1 if settings.adaptive_async else 0),
                    initial_gamma=_online_initial_gamma(
                        settings.method,
                        settings.adaptive_min_gamma,
                        settings.adaptive_max_gamma,
                    ),
                    probe_shared_cost_units=_online_probe_shared_cost_units(
                        settings.method,
                    ),
                    candidate_batch_limits=_adaptive_candidate_batch_limits(
                        settings.method,
                        settings.adaptive_min_gamma,
                        settings.adaptive_max_gamma,
                        int(self.scheduler_config.max_num_seqs),
                    ),
                )
            else:
                assert profile is not None
                self._vspec_adaptive_controller = GoodputController(
                    profile,
                    **common_options,
                    min_observations=settings.adaptive_min_observations,
                    latency_ewma_weight=(settings.adaptive_latency_ewma_weight),
                )
            self._vspec_adaptive_target_only = _TargetOnlyLatch()
            self._vspec_adaptive_summary_logged = False
            self._vspec_adaptive_configured_gamma = int(self.num_spec_tokens)
            native_gamma = _online_initial_gamma(
                settings.method,
                settings.adaptive_min_gamma,
                settings.adaptive_max_gamma,
            )
            if native_gamma is not None:
                self.num_spec_tokens = native_gamma
            self._vspec_eagle3_async_runtime_switching = (
                os.environ.get(runtime_switch_env, "0") == "1"
            )
            self._vspec_eagle3_stateful_cohort_lock = (
                settings.method == "eagle3"
                and settings.adaptive_async
                and os.environ.get(
                    "HUST_VSPEC_EAGLE3_STATEFUL_COHORT_LOCK",
                    "1",
                )
                == "1"
            )
            self._vspec_adaptive_native_eagle3_refill = _eagle3_cohort_refill_enabled(
                settings.method,
                original_schedule,
            )
            self._vspec_adaptive_initial_cohort_size = max(
                int(os.environ.get("HUST_VSPEC_ADAPTIVE_INITIAL_COHORT_SIZE", "0")),
                0,
            )
            self._vspec_adaptive_initial_cohort_wait_seconds = max(
                float(os.environ.get("HUST_VSPEC_ADAPTIVE_INITIAL_COHORT_WAIT_MS", "0")) / 1000.0,
                0.0,
            )
            default_quiet_ms = "1.0" if settings.method == "eagle3" else "0"
            default_max_wait_ms = "6.0" if settings.method == "eagle3" else "0"
            self._vspec_adaptive_arrival_quiet_seconds = max(
                float(
                    os.environ.get(
                        "HUST_VSPEC_ADAPTIVE_ARRIVAL_QUIET_MS",
                        default_quiet_ms,
                    )
                )
                / 1000.0,
                0.0,
            )
            self._vspec_adaptive_arrival_max_wait_seconds = max(
                float(
                    os.environ.get(
                        "HUST_VSPEC_ADAPTIVE_ARRIVAL_MAX_WAIT_MS",
                        default_max_wait_ms,
                    )
                )
                / 1000.0,
                0.0,
            )
            self._vspec_adaptive_isolate_refill = (
                os.environ.get("HUST_VSPEC_ADAPTIVE_ISOLATE_REFILL", "0") == "1"
            )

        def adaptive_schedule(self: Any, *args: Any, **kwargs: Any) -> Any:
            needs_target_only_latch = settings.adaptive_gamma0_mode == "sticky" and (
                settings.adaptive_min_gamma == 0
            )
            active_request_ids = set(self.requests) if needs_target_only_latch else set()
            if self.requests and self._vspec_adaptive_summary_logged:
                self._vspec_adaptive_summary_logged = False
            target_only_latched = (
                needs_target_only_latch
                and self._vspec_adaptive_target_only.refresh(active_request_ids)
            )
            schedule_gamma = (
                0 if target_only_latched else int(self._vspec_adaptive_controller.current_gamma)
            )
            num_running = len(self.running) + self.num_waiting_for_streaming_input
            previous_max_num_running_reqs = self.max_num_running_reqs
            refill_batch = settings.adaptive_refill_batch
            if refill_batch == 0:
                refill_batch = 8 if settings.method == "draft_model" else 4
            if self._vspec_adaptive_native_eagle3_refill:
                # The backend scheduler wrapper already owns refill coalescing.
                # Applying a second, slightly different limiter here creates
                # avoidable tail stalls and diverges from the fixed-gamma path.
                refill_batch = 1
            num_waiting = len(self.waiting) + len(self.skipped_waiting)
            free_slots = previous_max_num_running_reqs - num_running
            refill_target = min(refill_batch, num_waiting)
            initial_cohort_target = min(
                self._vspec_adaptive_initial_cohort_size,
                previous_max_num_running_reqs,
            )
            initial_cohort_wait_seconds = self._vspec_adaptive_initial_cohort_wait_seconds
            now = time.monotonic()
            initial_cohort_started_at = getattr(
                self,
                "_vspec_adaptive_initial_cohort_started_at",
                now,
            )
            if num_running == 0 and num_waiting > 0:
                if not hasattr(self, "_vspec_adaptive_initial_cohort_started_at"):
                    self._vspec_adaptive_initial_cohort_started_at = now
                    initial_cohort_started_at = now
            else:
                self._vspec_adaptive_initial_cohort_started_at = now
                initial_cohort_started_at = now
            hold_initial_cohort = _should_hold_initial_cohort(
                num_running,
                num_waiting,
                initial_cohort_target,
                initial_cohort_started_at,
                now,
                initial_cohort_wait_seconds,
            )
            hold_initial_cohort = hold_initial_cohort or _should_hold_growing_initial_cohort(
                self,
                num_running,
                num_waiting,
                now,
                self._vspec_adaptive_arrival_quiet_seconds,
                self._vspec_adaptive_arrival_max_wait_seconds,
            )
            preselected_decision = None
            if (
                not hold_initial_cohort
                and not target_only_latched
                and settings.adaptive_policy == "online"
                and num_running == 0
                and num_waiting > 0
            ):
                anticipated_batch_size = _adaptive_scheduled_batch_size(
                    self,
                    min(num_waiting, previous_max_num_running_reqs),
                )
                preselected_decision = self._vspec_adaptive_controller.choose(
                    anticipated_batch_size,
                    0,
                )
                schedule_gamma = preselected_decision.gamma

            if (
                not hold_initial_cohort
                and self._vspec_adaptive_native_eagle3_refill
                and _can_use_eagle3_native_scheduler_hold(
                    settings.method,
                    settings.adaptive_async,
                    self._vspec_eagle3_async_runtime_switching,
                    num_running,
                    schedule_gamma,
                    int(self.num_spec_tokens),
                    target_only_latched=target_only_latched,
                )
            ):
                scheduler_output = original_schedule(self, *args, **kwargs)
                if not scheduler_output.num_scheduled_tokens:
                    return scheduler_output
                batch_size = _adaptive_scheduled_batch_size(
                    self,
                    len(scheduler_output.num_scheduled_tokens),
                )
                scheduler_output.num_spec_tokens_to_schedule = schedule_gamma
                scheduler_output.vspec_adaptive_batch_size = batch_size
                scheduler_output.vspec_adaptive_context_tokens = 0
                if preselected_decision is not None:
                    self._vspec_adaptive_last_decision = preselected_decision
                return scheduler_output
            hold_waiting = (
                refill_batch > 1
                and num_running > 0
                and num_waiting > 0
                and free_slots < refill_target
            )
            isolate_refill = (
                self._vspec_adaptive_isolate_refill
                and refill_batch > 1
                and num_running > 0
                and num_waiting > 0
                and free_slots >= refill_target
            )
            if hold_waiting:
                self.max_num_running_reqs = num_running
            elif hold_initial_cohort:
                self.max_num_running_reqs = 0
            previous_running = None
            if isolate_refill:
                previous_running = self.running
                self.running = []
                self.max_num_running_reqs = free_slots
            try:
                with _scheduler_runtime_gamma(self, schedule_gamma):
                    scheduler_output = original_schedule(self, *args, **kwargs)
            finally:
                if previous_running is not None:
                    self.running = previous_running + self.running
                self.max_num_running_reqs = previous_max_num_running_reqs
            if not scheduler_output.num_scheduled_tokens:
                return scheduler_output

            batch_size = _adaptive_scheduled_batch_size(
                self,
                len(scheduler_output.num_scheduled_tokens),
            )
            context_tokens = (
                0
                if settings.adaptive_policy == "online"
                else _context_tokens_after_schedule(self, scheduler_output)
            )
            if target_only_latched:
                decision = self._vspec_adaptive_controller.force(
                    0,
                    batch_size,
                    context_tokens,
                    reason="target_only_latched",
                )
            elif preselected_decision is not None:
                decision = preselected_decision
            elif _should_hold_eagle3_async_cohort(
                settings.method,
                settings.adaptive_async,
                num_running,
                # Width switching remains enabled at an empty-cohort boundary
                # so the regular async graph path stays hot. Recurrent EAGLE3
                # state is protected independently by holding the selected
                # width while any request from that cohort is still active.
                runtime_width_switching=(
                    self._vspec_eagle3_async_runtime_switching
                    and not self._vspec_eagle3_stateful_cohort_lock
                ),
            ):
                decision = self._vspec_adaptive_controller.force(
                    schedule_gamma,
                    batch_size,
                    context_tokens,
                    reason="eagle3_async_cohort_hold",
                )
            else:
                decision = self._vspec_adaptive_controller.choose(
                    batch_size,
                    context_tokens,
                )
                if decision.gamma == 0 and settings.adaptive_gamma0_mode == "sticky":
                    self._vspec_adaptive_target_only.enter(set(self.requests))
            scheduler_output.num_spec_tokens_to_schedule = decision.gamma
            scheduler_output.vspec_adaptive_batch_size = batch_size
            scheduler_output.vspec_adaptive_context_tokens = context_tokens
            _update_async_next_frame_gamma(
                self,
                scheduler_output,
                decision.gamma,
            )
            self._vspec_adaptive_last_decision = decision
            if settings.adaptive_trace:
                position_acceptance = tuple(
                    round(rate, 4)
                    for rate in self._vspec_adaptive_controller.position_acceptance_rates
                )
                logger.warning(
                    "vSpec Adaptive decision: batch=%d context_tokens=%d "
                    "gamma=%d previous_gamma=%d acceptance=%.4f "
                    "position_acceptance=%s goodput=%.6f "
                    "previous_goodput=%.6f latency_factor=%.4f "
                    "latency_samples=%d gamma0_mode=%s reason=%s",
                    batch_size,
                    context_tokens,
                    decision.gamma,
                    decision.previous_gamma,
                    decision.acceptance_rate,
                    position_acceptance,
                    decision.predicted_goodput,
                    decision.previous_goodput,
                    self._vspec_adaptive_controller.latency_correction_factor(decision.gamma),
                    self._vspec_adaptive_controller.latency_observations[decision.gamma],
                    settings.adaptive_gamma0_mode,
                    decision.reason,
                )
            return scheduler_output

        def adaptive_update_from_output(
            self: Any,
            scheduler_output: Any,
            model_runner_output: Any,
        ) -> Any:
            controller = self._vspec_adaptive_controller
            if settings.adaptive_policy == "online":
                controller.begin_step_feedback()
            try:
                result = original_update_from_output(
                    self,
                    scheduler_output,
                    model_runner_output,
                )
            except Exception:
                if settings.adaptive_policy == "online":
                    controller.discard_step_feedback(
                        completed_at_ms=time.perf_counter() * 1000.0,
                    )
                raise
            if settings.adaptive_policy == "online":
                gamma = int(scheduler_output.num_spec_tokens_to_schedule)
                stable_decode = (
                    not bool(scheduler_output.scheduled_new_reqs)
                    and _runtime_target_query_width(scheduler_output) == gamma + 1
                )
                completed_at_ms = time.perf_counter() * 1000.0
                if stable_decode:
                    controller.complete_step(
                        gamma=gamma,
                        batch_size=int(scheduler_output.vspec_adaptive_batch_size),
                        context_tokens=int(scheduler_output.vspec_adaptive_context_tokens),
                        completed_at_ms=completed_at_ms,
                    )
                else:
                    controller.discard_step_feedback(
                        completed_at_ms=completed_at_ms,
                    )
            elif measure_step_latency and (
                measurement := getattr(
                    model_runner_output,
                    "vspec_adaptive_step_measurement",
                    None,
                )
            ):
                controller.observe_step_latency(
                    gamma=int(measurement["gamma"]),
                    batch_size=int(measurement["batch_size"]),
                    context_tokens=int(measurement["context_tokens"]),
                    latency_ms=float(measurement["latency_ms"]),
                )
            if (
                settings.adaptive_policy == "online"
                and not self.requests
                and not self._vspec_adaptive_summary_logged
            ):
                logger.warning(
                    "vSpec Online Adaptive summary: %s",
                    controller.summary(),
                )
                self._vspec_adaptive_summary_logged = True
            return result

        def adaptive_make_stats(
            self: Any,
            spec_decoding_stats: Any,
            num_draft_tokens: int,
            num_accepted_tokens: int,
            num_invalid_spec_tokens: dict[str, int] | None,
            request_id: str,
        ) -> Any:
            valid_draft_tokens = num_draft_tokens
            if num_invalid_spec_tokens:
                valid_draft_tokens -= num_invalid_spec_tokens.get(request_id, 0)
            valid_draft_tokens = max(0, valid_draft_tokens)
            valid_accepted_tokens = min(num_accepted_tokens, valid_draft_tokens)
            self._vspec_adaptive_controller.observe(
                valid_draft_tokens,
                valid_accepted_tokens,
                request_id=request_id,
            )
            configured_gamma = int(self._vspec_adaptive_configured_gamma)
            if spec_decoding_stats is None and self.log_stats and num_draft_tokens:
                spec_decoding_stats = SpecDecodingStats.new(configured_gamma)
            else:
                _normalize_spec_decoding_stats_width(
                    spec_decoding_stats,
                    configured_gamma,
                )
            result = original_make_stats(
                self,
                spec_decoding_stats,
                num_draft_tokens,
                num_accepted_tokens,
                num_invalid_spec_tokens,
                request_id,
            )
            return _normalize_spec_decoding_stats_width(result, configured_gamma)

        def adaptive_update_draft_token_ids(
            self: Any,
            draft_token_ids: Any,
        ) -> Any:
            if settings.adaptive_entropy_stop:
                _trim_placeholder_suffixes(draft_token_ids)
            return original_update_draft_token_ids(self, draft_token_ids)

        Scheduler.__init__ = scheduler_init
        Scheduler.schedule = adaptive_schedule
        Scheduler.make_spec_decoding_stats = adaptive_make_stats
        Scheduler.update_from_output = adaptive_update_from_output
        Scheduler.update_draft_token_ids = adaptive_update_draft_token_ids
        setattr(Scheduler, SCHEDULER_PATCH_MARKER, True)
        applied = True

    if not getattr(AscendSpecDecodeBaseProposer, PROPOSER_PATCH_MARKER, False):
        original_propose = AscendSpecDecodeBaseProposer._propose
        original_dummy_run = AscendSpecDecodeBaseProposer.dummy_run

        def adaptive_dummy_run(self: Any, *args: Any, **kwargs: Any) -> Any:
            if settings.adaptive_entropy_stop:
                self._vspec_entropy_topk = settings.adaptive_entropy_topk
                _install_draft_entropy_probe(self)
            if not settings.adaptive_full_graph:
                return original_dummy_run(self, *args, **kwargs)
            configured_gamma = int(
                getattr(
                    self,
                    "_vspec_adaptive_configured_gamma",
                    self.num_speculative_tokens,
                )
            )
            self._vspec_adaptive_configured_gamma = configured_gamma
            return _capture_all_adaptive_draft_graphs(
                self,
                original_dummy_run,
                configured_gamma,
                settings.adaptive_min_gamma,
                *args,
                **kwargs,
            )

        def adaptive_propose(self: Any, *args: Any, **kwargs: Any) -> Any:
            scheduler_output = kwargs.get("scheduler_output")
            requested_gamma = getattr(
                scheduler_output,
                "num_spec_tokens_to_schedule",
                settings.adaptive_max_gamma,
            )
            requested_gamma = int(requested_gamma)
            if settings.adaptive_entropy_stop:
                self._vspec_entropy_topk = settings.adaptive_entropy_topk
                _install_draft_entropy_probe(self)
                self._vspec_entropy_recent_values = []
            configured_gamma = int(
                getattr(
                    self,
                    "_vspec_adaptive_configured_gamma",
                    self.num_speculative_tokens,
                )
            )
            self._vspec_adaptive_configured_gamma = configured_gamma
            if not settings.adaptive_min_gamma <= requested_gamma <= configured_gamma:
                raise RuntimeError(
                    "vSpec Adaptive runtime gamma is outside the configured range: "
                    f"requested={requested_gamma}, range="
                    f"[{settings.adaptive_min_gamma}, {configured_gamma}]"
                )
            if requested_gamma == 0:
                runner = getattr(self, "runner", None)
                input_batch = getattr(runner, "input_batch", None)
                num_reqs = int(getattr(input_batch, "num_reqs", 0))
                next_token_ids = kwargs.get("next_token_ids")
                if next_token_ids is None:
                    raise RuntimeError(
                        "vSpec Adaptive target-only proposal requires next_token_ids"
                    )
                if settings.adaptive_gamma0_mode == "sync":
                    previous_runnable = self._runnable
                    if settings.adaptive_full_graph:
                        self._runnable = getattr(
                            self,
                            "_vspec_adaptive_full_graph_body",
                            previous_runnable,
                        )
                    target_query_width = _proposal_input_query_width(
                        kwargs.get("common_attn_metadata"),
                        kwargs.get("target_model_batch_desc"),
                    )
                    try:
                        with _runtime_runner_query_width(
                            self,
                            target_query_width,
                        ):
                            with _runtime_eager_proposer(self, True):
                                with _runtime_eager_dispatch(self, True):
                                    synced = _run_with_runtime_gamma(
                                        self,
                                        1,
                                        original_propose,
                                        *args,
                                        **kwargs,
                                    )
                    finally:
                        self._runnable = previous_runnable
                    self._vspec_adaptive_previous_proposal_gamma = 0
                    return synced.new_empty((num_reqs, 0))
                self._vspec_adaptive_previous_proposal_gamma = 0
                return next_token_ids.new_empty((num_reqs, 0))

            previous_proposal_gamma = int(
                getattr(
                    self,
                    "_vspec_adaptive_previous_proposal_gamma",
                    requested_gamma,
                )
            )
            if _can_use_stable_configured_draft_path(
                getattr(self, "method", None),
                requested_gamma,
                previous_proposal_gamma,
                configured_gamma,
                adaptive_full_graph=settings.adaptive_full_graph,
                entropy_stop=settings.adaptive_entropy_stop,
                native_gamma=_native_full_graph_gamma(
                    self,
                    configured_gamma,
                    max(1, settings.adaptive_min_gamma),
                ),
            ):
                # Gamma 2 owns the native runnable and graph-parameter table.
                # Keep only the two width bindings that serial Draft needs for
                # padded tail batches; bypassing those bindings makes FIA see a
                # stale actualSequenceLengthQ shape.
                target_query_width = _proposal_input_query_width(
                    kwargs.get("common_attn_metadata"),
                    kwargs.get("target_model_batch_desc"),
                )
                if _is_eagle3_anchor_runtime(
                    getattr(self, "runner", None),
                    settings.method,
                    requested_gamma,
                    target_query_width,
                ):
                    result = original_propose(self, *args, **kwargs)
                    self._vspec_adaptive_previous_proposal_gamma = requested_gamma
                    return result
                with _runtime_runner_query_width(
                    self,
                    target_query_width,
                ):
                    with _runtime_draft_continuation_query_width(
                        self,
                        requested_gamma,
                    ):
                        result = _run_with_runtime_gamma(
                            self,
                            requested_gamma,
                            original_propose,
                            *args,
                            **kwargs,
                        )
                self._vspec_adaptive_previous_proposal_gamma = requested_gamma
                return result
            previous_runnable = self._runnable
            previous_entropy_enabled = getattr(
                self,
                "_vspec_entropy_measure_enabled",
                True,
            )
            self._vspec_entropy_measure_enabled = requested_gamma >= _MIN_CONFIDENCE_STOP_GAMMA
            from vllm_ascend.compilation import acl_graph as acl_graph_module

            previous_graph_params = acl_graph_module._draft_graph_params
            execution_gamma = _proposal_execution_gamma(
                getattr(self, "method", None),
                requested_gamma,
                previous_proposal_gamma,
            )
            graph_params_by_gamma = getattr(
                self,
                "_vspec_adaptive_graph_params_by_gamma",
                None,
            )
            graph_params_for_gamma = (
                graph_params_by_gamma.get(execution_gamma)
                if graph_params_by_gamma is not None
                else None
            )
            if graph_params_for_gamma is not None:
                acl_graph_module._draft_graph_params = graph_params_for_gamma
            proposal_force_eager = False
            if settings.adaptive_full_graph:
                # Only gamma 2 currently has a runtime-stable continuation
                # descriptor and metadata layout. Keep the other online arms
                # executable through eager Draft so the controller can measure
                # them without triggering a forbidden lazy graph capture.
                if settings.method == "draft_model" and execution_gamma != 2:
                    proposal_force_eager = True
                    self._runnable = getattr(
                        self,
                        "_vspec_adaptive_full_graph_body",
                        previous_runnable,
                    )
                elif graph_params_by_gamma is not None and graph_params_for_gamma is None:
                    proposal_force_eager = True
                    self._runnable = getattr(
                        self,
                        "_vspec_adaptive_full_graph_body",
                        previous_runnable,
                    )
                elif previous_proposal_gamma == execution_gamma:
                    if settings.method == "draft_model":
                        graph_batch_matches = _draft_full_graph_batch_matches_capture(
                            self,
                            kwargs.get("common_attn_metadata"),
                            kwargs.get("target_model_batch_desc"),
                            execution_gamma,
                        )
                    else:
                        graph_batch_matches = _full_graph_batch_matches_capture(
                            kwargs.get("common_attn_metadata"),
                            kwargs.get("target_model_batch_desc"),
                            execution_gamma,
                            list(self.vllm_config.compilation_config.cudagraph_capture_sizes),
                        )
                    if graph_batch_matches:
                        self._runnable = _get_full_graph_runnable_for_gamma(
                            self,
                            execution_gamma,
                            configured_gamma,
                            settings.adaptive_min_gamma,
                        )
                    else:
                        proposal_force_eager = True
                        self._runnable = getattr(
                            self,
                            "_vspec_adaptive_full_graph_body",
                            previous_runnable,
                        )
                        if settings.adaptive_trace:
                            common_attn_metadata = kwargs.get("common_attn_metadata")
                            target_model_batch_desc = kwargs.get("target_model_batch_desc")
                            logger.warning(
                                "vSpec Adaptive Draft graph batch mismatch; "
                                "using eager for gamma=%d target_tokens=%s "
                                "target_reqs=%s metadata_batch=%s "
                                "metadata_actual_tokens=%s",
                                execution_gamma,
                                getattr(
                                    target_model_batch_desc,
                                    "num_tokens",
                                    None,
                                ),
                                getattr(
                                    target_model_batch_desc,
                                    "num_reqs",
                                    None,
                                ),
                                (
                                    common_attn_metadata.batch_size()
                                    if common_attn_metadata is not None
                                    else None
                                ),
                                getattr(
                                    common_attn_metadata,
                                    "num_actual_tokens",
                                    None,
                                ),
                            )
                else:
                    # The first pass consumes Target outputs produced with the
                    # previous gamma. Its static FULL-graph batch constants do
                    # not match the new gamma until the next scheduler step.
                    proposal_force_eager = True
                    self._runnable = getattr(
                        self,
                        "_vspec_adaptive_full_graph_body",
                        previous_runnable,
                    )
                    if settings.adaptive_trace:
                        logger.warning(
                            "vSpec Adaptive Draft transition uses eager: "
                            "previous_gamma=%d gamma=%d",
                            previous_proposal_gamma,
                            execution_gamma,
                        )
            try:
                proposal_kwargs = kwargs
                if proposal_force_eager:
                    proposal_kwargs = dict(kwargs)
                    proposal_kwargs["target_model_batch_desc"] = _nonuniform_batch_descriptor(
                        kwargs.get("target_model_batch_desc")
                    )
                target_query_width = _proposal_input_query_width(
                    kwargs.get("common_attn_metadata"),
                    kwargs.get("target_model_batch_desc"),
                )
                with _runtime_runner_query_width(
                    self,
                    target_query_width,
                ):
                    with _runtime_draft_continuation_query_width(
                        self,
                        execution_gamma,
                    ):
                        with _runtime_eager_proposer(
                            self,
                            proposal_force_eager,
                        ):
                            with _runtime_eager_dispatch(
                                self,
                                proposal_force_eager,
                            ):
                                if settings.adaptive_trace:
                                    logger.warning(
                                        "vSpec Adaptive Draft propose start: "
                                        "requested_gamma=%d execution_gamma=%d "
                                        "force_eager=%s target_query_width=%s",
                                        requested_gamma,
                                        execution_gamma,
                                        proposal_force_eager,
                                        target_query_width,
                                    )
                                result = _run_with_runtime_gamma(
                                    self,
                                    execution_gamma,
                                    original_propose,
                                    *args,
                                    **proposal_kwargs,
                                )
                                if settings.adaptive_trace:
                                    logger.warning(
                                        "vSpec Adaptive Draft propose complete: "
                                        "requested_gamma=%d execution_gamma=%d",
                                        requested_gamma,
                                        execution_gamma,
                                    )
                if execution_gamma != requested_gamma:
                    result = result[:, :requested_gamma]
                self._vspec_adaptive_previous_proposal_gamma = requested_gamma
                if draft_stopper is not None:
                    common_attn_metadata = kwargs.get("common_attn_metadata")
                    batch_size = (
                        int(common_attn_metadata.batch_size())
                        if common_attn_metadata is not None
                        else int(result.shape[0])
                    )
                    batch_size = min(batch_size, int(result.shape[0]))
                    entropies = _draft_entropy_matrix(
                        self,
                        requested_gamma,
                        batch_size,
                        settings.adaptive_entropy_topk,
                    )
                    if entropies is not None:
                        masked, lengths = draft_stopper.mask_draft_tokens(
                            result[:batch_size, :requested_gamma],
                            entropies,
                        )
                        if batch_size == int(result.shape[0]):
                            result = masked
                        else:
                            result = result.clone()
                            result[:batch_size, :requested_gamma] = masked
                        self._vspec_adaptive_last_draft_lengths = lengths
                        if settings.adaptive_trace:
                            import torch

                            counts = (
                                torch.bincount(
                                    lengths.to(torch.int64),
                                    minlength=requested_gamma + 1,
                                )
                                .cpu()
                                .tolist()
                            )
                            logger.warning(
                                "vSpec Adaptive current-round Draft lengths: budget=%d counts=%s",
                                requested_gamma,
                                {
                                    length: int(count)
                                    for length, count in enumerate(counts)
                                    if count
                                },
                            )
                    elif settings.adaptive_trace:
                        logger.warning(
                            "vSpec Adaptive current-round confidence data is "
                            "unavailable for gamma=%d; keeping the full proposal",
                            requested_gamma,
                        )
                return result
            finally:
                self._vspec_entropy_measure_enabled = previous_entropy_enabled
                self._runnable = previous_runnable
                acl_graph_module._draft_graph_params = previous_graph_params

        AscendSpecDecodeBaseProposer.dummy_run = adaptive_dummy_run
        AscendSpecDecodeBaseProposer._propose = adaptive_propose
        setattr(AscendSpecDecodeBaseProposer, PROPOSER_PATCH_MARKER, True)
        applied = True

        if AscendDflashProposer is not None and "dummy_run" in AscendDflashProposer.__dict__:
            original_dflash_dummy_run = AscendDflashProposer.dummy_run

            def adaptive_dflash_dummy_run(
                self: Any,
                *args: Any,
                **kwargs: Any,
            ) -> Any:
                if not settings.adaptive_full_graph:
                    return original_dflash_dummy_run(
                        self,
                        *args,
                        **kwargs,
                    )
                configured_gamma = int(
                    getattr(
                        self,
                        "_vspec_adaptive_configured_gamma",
                        self.num_speculative_tokens,
                    )
                )
                self._vspec_adaptive_configured_gamma = configured_gamma
                return _capture_all_adaptive_draft_graphs(
                    self,
                    original_dflash_dummy_run,
                    configured_gamma,
                    settings.adaptive_min_gamma,
                    *args,
                    **kwargs,
                )

            AscendDflashProposer.dummy_run = adaptive_dflash_dummy_run

    if not getattr(NPUModelRunner, RUNNER_PATCH_MARKER, False):
        import torch

        original_runner_init = NPUModelRunner.__init__
        original_prepare_inputs = NPUModelRunner._prepare_inputs
        original_execute_model = NPUModelRunner.execute_model
        original_sample_tokens = NPUModelRunner.sample_tokens
        original_warmup_and_capture = NPUModelRunner._warmup_and_capture
        original_determine_batch_execution = NPUModelRunner._determine_batch_execution_and_padding
        original_copy_draft_tokens = NPUModelRunner._copy_draft_token_ids_to_cpu
        original_propose_draft_tokens = NPUModelRunner.propose_draft_token_ids
        original_profile_cudagraph_memory = NPUModelRunner.profile_cudagraph_memory
        original_capture_model = NPUModelRunner.capture_model
        original_check_cudagraph_mode = NPUModelRunner._check_and_update_cudagraph_mode

        def runner_init(self: Any, *args: Any, **kwargs: Any) -> None:
            original_runner_init(self, *args, **kwargs)
            existing_widths = getattr(
                self,
                "_nanoparl_uniform_decode_query_lens",
                (self.uniform_decode_query_len,),
            )
            adaptive_query_widths = _adaptive_capture_query_lens(
                existing_widths,
                settings.adaptive_max_gamma,
                settings.method,
                settings.adaptive_min_gamma,
            )
            # Serial Draft's gamma + 2 descriptor passes through the shared
            # Target capture wrapper, so the helper includes that width too.
            self._nanoparl_uniform_decode_query_lens = adaptive_query_widths
            _configure_serial_draft_runtime_anchor(
                self,
                settings.method,
                settings.adaptive_min_gamma,
                settings.adaptive_max_gamma,
            )
            _configure_eagle3_runtime_anchor(
                self,
                settings.method,
                settings.adaptive_min_gamma,
                settings.adaptive_max_gamma,
            )
            _configure_mtp_runtime_anchor(
                self,
                settings.method,
                settings.adaptive_min_gamma,
                settings.adaptive_max_gamma,
            )
            if measure_step_latency:
                self._vspec_adaptive_pending_measurements = deque()

        def prepare_inputs(
            self: Any,
            scheduler_output: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            runtime_gamma = int(
                getattr(
                    scheduler_output,
                    "num_spec_tokens_to_schedule",
                    settings.adaptive_max_gamma,
                )
            )
            _synchronize_eagle3_width_transition(
                self,
                settings.method,
                runtime_gamma,
                enabled=stateful_cohort_locked,
            )
            native_query_width = _eagle3_native_anchor_query_width(
                self,
                settings.method,
                scheduler_output,
                cohort_locked=stateful_cohort_locked,
            )
            if native_query_width is None:
                current_query_width = _runtime_target_query_width(scheduler_output)
                metadata_query_width = _runtime_target_metadata_query_width(scheduler_output)
                stable_decode = (
                    not bool(scheduler_output.scheduled_new_reqs)
                    and current_query_width == runtime_gamma + 1
                )
            else:
                current_query_width = native_query_width
                metadata_query_width = native_query_width
                stable_decode = True
            if stable_decode and _is_eagle3_anchor_runtime(
                self,
                settings.method,
                runtime_gamma,
                metadata_query_width,
                require_pinned=False,
            ):
                if (
                    getattr(
                        self,
                        "_vspec_adaptive_pinned_query_width",
                        None,
                    )
                    != metadata_query_width
                ):
                    assert metadata_query_width is not None
                    _pin_runner_query_width(self, metadata_query_width)
                return original_prepare_inputs(
                    self,
                    scheduler_output,
                    *args,
                    **kwargs,
                )
            with _runtime_dynamic_eagle_state_kernel(
                self,
                stable_decode=stable_decode,
                gamma=runtime_gamma,
            ):
                with _runner_query_width(self, metadata_query_width):
                    return original_prepare_inputs(
                        self,
                        scheduler_output,
                        *args,
                        **kwargs,
                    )

        def execute_model(
            self: Any,
            scheduler_output: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            if (
                settings.method == "eagle"
                and os.environ.get(_EAGLE_DYNAMIC_UNIFORM_STATE_ENV) == "1"
                and not hasattr(
                    self,
                    "_vspec_adaptive_configured_target_gamma",
                )
            ):
                configured_target_gamma = self.num_spec_tokens
                self._vspec_adaptive_configured_target_gamma = configured_target_gamma
                self.num_spec_tokens = (
                    settings.adaptive_min_gamma + settings.adaptive_max_gamma + 1
                ) // 2
                logger.warning(
                    "vSpec Adaptive EAGLE Target state width isolated: "
                    "configured=%d state_anchor=%d",
                    configured_target_gamma,
                    self.num_spec_tokens,
                )
            started_at = time.perf_counter() if measure_step_latency else None
            runtime_gamma = int(
                getattr(
                    scheduler_output,
                    "num_spec_tokens_to_schedule",
                    settings.adaptive_max_gamma,
                )
            )
            native_query_width = _eagle3_native_anchor_query_width(
                self,
                settings.method,
                scheduler_output,
                cohort_locked=stateful_cohort_locked,
            )
            if native_query_width is None:
                current_query_width = _runtime_target_query_width(scheduler_output)
                metadata_query_width = _runtime_target_metadata_query_width(scheduler_output)
                stable_decode = (
                    not bool(scheduler_output.scheduled_new_reqs)
                    and current_query_width == runtime_gamma + 1
                )
            else:
                current_query_width = native_query_width
                metadata_query_width = native_query_width
                stable_decode = True
            if (
                not measure_step_latency
                and not settings.adaptive_trace
                and stable_decode
                and _is_eagle3_anchor_runtime(
                    self,
                    settings.method,
                    runtime_gamma,
                    metadata_query_width,
                )
            ):
                # The dominant EAGLE3 arm already owns the native Target graph
                # and host layout. Avoid rebuilding generic dynamic bindings on
                # every decode step, but restore GDN metadata after the async
                # launch because the runner may replace its width-specific view.
                try:
                    return original_execute_model(
                        self,
                        scheduler_output,
                        *args,
                        **kwargs,
                    )
                finally:
                    if not getattr(
                        self,
                        "_vspec_adaptive_anchor_uses_configured_width",
                        False,
                    ):
                        assert metadata_query_width is not None
                        _pin_runner_query_width(self, metadata_query_width)
            previous_target_only = getattr(
                self,
                "_vspec_adaptive_target_only_step",
                False,
            )
            had_force_target_eager = hasattr(
                self,
                "_vspec_adaptive_force_target_eager_step",
            )
            previous_force_target_eager = getattr(
                self,
                "_vspec_adaptive_force_target_eager_step",
                False,
            )
            self._vspec_adaptive_force_target_eager_step = (
                _force_non_native_serial_draft_target_eager(
                    settings.method,
                    settings.adaptive_full_graph,
                    current_query_width,
                )
                or _force_eagle3_non_decode_target_eager(
                    settings.method,
                    settings.adaptive_full_graph,
                    current_query_width,
                )
            )
            # With async scheduling, ``runtime_gamma`` controls the proposal
            # produced after this Target pass. The current pass still verifies
            # the previous proposal, whose width is represented by the actual
            # query layout. In particular, the 0 -> 1 recovery frame is a q1
            # Target pass and must not replay a wider combined FULL graph.
            self._vspec_adaptive_target_only_step = _current_target_is_target_only(
                current_query_width,
                runtime_gamma,
            )
            from vllm_ascend.compilation import acl_graph as acl_graph_module

            base_graph_params = acl_graph_module._graph_params
            # GraphParams are indexed only by total token count. Different
            # adaptive widths can therefore collide (for example q6/B14 and
            # q7/B12 both use 84 tokens) unless each width owns a table.
            isolate_target_graph_params = _uses_width_isolated_target_graph_params(
                self.compilation_config.cudagraph_mode
            )
            graph_params_by_width = (
                _prepare_target_graph_params(
                    self,
                    base_graph_params,
                    self._nanoparl_uniform_decode_query_lens,
                )
                if isolate_target_graph_params
                else None
            )
            # Mixed async frames can contain q1 admissions beside the previous
            # proposal width. They are not eligible for a uniform FULL replay,
            # but still need the event/workspace table of their widest layout
            # so the preceding width-specific graph is retired consistently.
            runtime_query_width = metadata_query_width
            if graph_params_by_width is not None and runtime_query_width in graph_params_by_width:
                acl_graph_module._graph_params = graph_params_by_width[runtime_query_width]
            rejection_sampler = getattr(self, "rejection_sampler", None)
            previous_confidence_accept = None
            had_confidence_accept_attr = False
            if settings.method == "eagle" and rejection_sampler is not None:
                had_confidence_accept_attr = hasattr(
                    rejection_sampler,
                    _EAGLE_CONFIDENCE_ACCEPT_ATTR,
                )
                previous_confidence_accept = getattr(
                    rejection_sampler,
                    _EAGLE_CONFIDENCE_ACCEPT_ATTR,
                    None,
                )
                setattr(
                    rejection_sampler,
                    _EAGLE_CONFIDENCE_ACCEPT_ATTR,
                    _current_eagle_confidence_accept_enabled(
                        current_query_width,
                        runtime_gamma,
                    ),
                )
            try:
                if settings.adaptive_trace:
                    logger.warning(
                        "vSpec Adaptive Target execute start: gamma=%d "
                        "query_width=%s stable_decode=%s force_eager=%s",
                        runtime_gamma,
                        current_query_width,
                        stable_decode,
                        self._vspec_adaptive_force_target_eager_step,
                    )
                if stable_decode and _is_eagle3_anchor_runtime(
                    self,
                    settings.method,
                    runtime_gamma,
                    metadata_query_width,
                ):
                    # execute_model may replace GDN builder state while the
                    # asynchronous Target frame is launched. The anchor starts
                    # from its pinned native state, then restores that state
                    # after launch without first snapshotting every builder.
                    try:
                        result = original_execute_model(
                            self,
                            scheduler_output,
                            *args,
                            **kwargs,
                        )
                    finally:
                        if not getattr(
                            self,
                            "_vspec_adaptive_anchor_uses_configured_width",
                            False,
                        ):
                            assert metadata_query_width is not None
                            _pin_runner_query_width(self, metadata_query_width)
                else:
                    # The host runner is initialized with max_gamma + 1, but a
                    # dynamic step must classify uniform decode against the
                    # width of the proposal currently being verified.
                    with _runner_query_width(self, metadata_query_width):
                        result = original_execute_model(
                            self,
                            scheduler_output,
                            *args,
                            **kwargs,
                        )
                if settings.adaptive_trace:
                    logger.warning(
                        "vSpec Adaptive Target execute complete: gamma=%d result_type=%s",
                        runtime_gamma,
                        type(result).__name__,
                    )
                if not measure_step_latency:
                    return result

                assert started_at is not None
                elapsed_ms = (time.perf_counter() - started_at) * 1000.0
                output = _unwrap_model_runner_output(result)
                measurement = None
                if stable_decode:
                    measurement = {
                        "gamma": runtime_gamma,
                        "batch_size": int(
                            getattr(
                                scheduler_output,
                                "vspec_adaptive_batch_size",
                                len(scheduler_output.num_scheduled_tokens),
                            )
                        ),
                        "context_tokens": int(
                            getattr(
                                scheduler_output,
                                "vspec_adaptive_context_tokens",
                                0,
                            )
                        ),
                        "started_at": started_at,
                    }
                if hasattr(output, "req_ids"):
                    if measurement is not None:
                        output.vspec_adaptive_step_measurement = measurement
                        if output is result:
                            measurement["latency_ms"] = float(
                                getattr(
                                    output,
                                    "execution_time_ms",
                                    elapsed_ms,
                                )
                            )
                            measurement.pop("started_at", None)
                elif result is None:
                    self._vspec_adaptive_pending_measurements.append(measurement)
                if (
                    settings.adaptive_trace
                    and measurement is not None
                    and hasattr(output, "req_ids")
                    and "latency_ms" in measurement
                ):
                    measured_ms = measurement["latency_ms"]
                    logger.warning(
                        "vSpec Adaptive latency staged: gamma=%d "
                        "query_width=%d batch=%d latency_ms=%.4f",
                        runtime_gamma,
                        current_query_width,
                        measurement["batch_size"],
                        measured_ms,
                    )
                return result
            finally:
                if settings.method == "eagle" and rejection_sampler is not None:
                    if had_confidence_accept_attr:
                        setattr(
                            rejection_sampler,
                            _EAGLE_CONFIDENCE_ACCEPT_ATTR,
                            previous_confidence_accept,
                        )
                    else:
                        delattr(
                            rejection_sampler,
                            _EAGLE_CONFIDENCE_ACCEPT_ATTR,
                        )
                acl_graph_module._graph_params = base_graph_params
                self._vspec_adaptive_target_only_step = previous_target_only
                if had_force_target_eager:
                    self._vspec_adaptive_force_target_eager_step = previous_force_target_eager
                else:
                    delattr(
                        self,
                        "_vspec_adaptive_force_target_eager_step",
                    )

        def sample_tokens(
            self: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            if settings.adaptive_trace:
                logger.warning("vSpec Adaptive Target sample start")
            execute_model_state = getattr(self, "execute_model_state", None)
            scheduler_output = execute_model_state[0] if execute_model_state is not None else None
            proposal_query_width = (
                _runtime_proposal_query_width(scheduler_output)
                if scheduler_output is not None
                else None
            )
            proposal_gamma = (
                int(getattr(scheduler_output, "num_spec_tokens_to_schedule", -1))
                if scheduler_output is not None
                else -1
            )
            if not measure_step_latency and _is_eagle3_anchor_runtime(
                self,
                settings.method,
                proposal_gamma,
                proposal_query_width,
            ):
                return original_sample_tokens(self, *args, **kwargs)
            # Ascend async execute_model() only launches the Target forward.
            # Sampling and EAGLE proposal happen here, after the execute-time
            # width context has been restored to configured capacity.
            with _runner_query_width(self, proposal_query_width):
                result = original_sample_tokens(self, *args, **kwargs)
            if settings.adaptive_trace:
                logger.warning(
                    "vSpec Adaptive Target sample complete: result_type=%s",
                    type(result).__name__,
                )
            if not measure_step_latency:
                return result
            pending = self._vspec_adaptive_pending_measurements
            measurement = pending.popleft() if pending else None
            if measurement is None:
                return result
            output = _unwrap_model_runner_output(result)
            if not hasattr(output, "req_ids"):
                raise RuntimeError(
                    "vSpec Adaptive cannot attach latency to sampler output "
                    f"type {type(output).__name__}"
                )
            started_at = float(measurement.pop("started_at"))
            if output is result:
                measurement["latency_ms"] = (time.perf_counter() - started_at) * 1000.0
            else:
                measurement["started_at"] = started_at
            output.vspec_adaptive_step_measurement = measurement
            if settings.adaptive_trace and "latency_ms" in measurement:
                logger.warning(
                    "vSpec Adaptive latency staged after sampling: "
                    "gamma=%d batch=%d latency_ms=%.4f",
                    measurement["gamma"],
                    measurement["batch_size"],
                    measurement["latency_ms"],
                )
            return result

        def warmup_and_capture(
            self: Any,
            desc: Any,
            cudagraph_runtime_mode: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            if (
                not settings.adaptive_full_graph
                or cudagraph_runtime_mode != CUDAGraphMode.FULL
                or not desc.uniform
                or not self.compilation_config.cudagraph_mode.separate_routine()
            ):
                return original_warmup_and_capture(
                    self,
                    desc,
                    cudagraph_runtime_mode,
                    *args,
                    **kwargs,
                )

            if desc.num_reqs is None or desc.num_reqs <= 0:
                raise RuntimeError("adaptive Target graph requires a positive request count")
            if desc.num_tokens % desc.num_reqs:
                raise RuntimeError("adaptive Target graph query width is not integral")
            query_width = desc.num_tokens // desc.num_reqs
            isolate_graph_params = _uses_width_isolated_target_graph_params(
                self.compilation_config.cudagraph_mode
            )
            acl_graph_module = None
            base_graph_params = None
            if isolate_graph_params:
                from vllm_ascend.compilation import acl_graph as acl_graph_module

                base_graph_params = acl_graph_module._graph_params
                graph_params_by_width = _prepare_target_graph_params(
                    self,
                    base_graph_params,
                    self._nanoparl_uniform_decode_query_lens,
                )
                if graph_params_by_width is None or query_width not in graph_params_by_width:
                    raise RuntimeError(
                        "missing adaptive Target graph-parameter table for "
                        f"query width {query_width}"
                    )
                acl_graph_module._graph_params = graph_params_by_width[query_width]
            try:
                # Every separate-routine FULL capture needs the descriptor's
                # actual query width and a width-private parameter table.
                with _runner_query_width(self, query_width):
                    with _draft_capture_query_width(self, query_width):
                        return original_warmup_and_capture(
                            self,
                            desc,
                            cudagraph_runtime_mode,
                            *args,
                            **kwargs,
                        )
            finally:
                if isolate_graph_params:
                    assert acl_graph_module is not None
                    acl_graph_module._graph_params = base_graph_params

        def determine_batch_execution_and_padding(
            self: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            # Combined FULL graphs have one mixed descriptor family. A q1
            # target-only step can collide with a graph captured at q(max+1),
            # whose static FIA metadata is incompatible. FULL_DECODE_ONLY has
            # width-specific uniform descriptors and remains graph-backed.
            force_target_eager = getattr(
                self,
                "_vspec_adaptive_force_target_eager_step",
                False,
            ) or (
                getattr(self, "_vspec_adaptive_target_only_step", False)
                and self.compilation_config.cudagraph_mode == CUDAGraphMode.FULL
            )
            if force_target_eager:
                if len(args) >= 7:
                    mutable_args = list(args)
                    mutable_args[6] = True
                    args = tuple(mutable_args)
                else:
                    kwargs["force_eager"] = True
            return original_determine_batch_execution(
                self,
                *args,
                **kwargs,
            )

        def prepare_adaptive_full_graphs(self: Any) -> None:
            drafter = getattr(self, "drafter", None)
            if drafter is None or not settings.adaptive_full_graph:
                return
            configured_gamma = int(
                getattr(
                    drafter,
                    "_vspec_adaptive_configured_gamma",
                    drafter.num_speculative_tokens,
                )
            )
            drafter._vspec_adaptive_configured_gamma = configured_gamma
            _initialize_full_graph_runnables(
                drafter,
                configured_gamma,
                settings.adaptive_min_gamma,
            )

        def propose_draft_token_ids(
            self: Any,
            valid_sampled_token_ids: Any,
            sampling_metadata: Any,
            scheduler_output: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            requested_gamma = int(
                getattr(
                    scheduler_output,
                    "num_spec_tokens_to_schedule",
                    settings.adaptive_max_gamma,
                )
            )
            if (
                requested_gamma != 0
                or self.use_async_scheduling
                or settings.adaptive_gamma0_mode == "sync"
            ):
                # Async scheduling still needs the generic next-token state
                # preparation. adaptive_propose() returns before Draft forward
                # once that state has been staged.
                return original_propose_draft_tokens(
                    self,
                    valid_sampled_token_ids,
                    sampling_metadata,
                    scheduler_output,
                    *args,
                    **kwargs,
                )

            drafter = getattr(self, "drafter", None)
            if drafter is not None:
                drafter._vspec_adaptive_previous_proposal_gamma = 0
            num_reqs = int(self.input_batch.num_reqs)
            if torch.is_tensor(valid_sampled_token_ids):
                return valid_sampled_token_ids.new_empty((num_reqs, 0))
            return torch.empty(
                (num_reqs, 0),
                dtype=torch.int64,
                device=self.device,
            )

        def profile_cudagraph_memory(self: Any, *args: Any, **kwargs: Any) -> Any:
            prepare_adaptive_full_graphs(self)
            return original_profile_cudagraph_memory(self, *args, **kwargs)

        def capture_model(self: Any, *args: Any, **kwargs: Any) -> Any:
            prepare_adaptive_full_graphs(self)
            return original_capture_model(self, *args, **kwargs)

        def copy_draft_tokens_to_cpu(
            self: Any,
            scheduler_output: Any,
            zeros_only: bool = False,
        ) -> None:
            draft_token_ids = self._draft_token_ids
            destination = self.draft_token_ids_cpu
            if (
                not torch.is_tensor(draft_token_ids)
                or draft_token_ids.ndim < 2
                or destination is None
                or draft_token_ids.shape[1] == destination.shape[1]
            ):
                return original_copy_draft_tokens(
                    self,
                    scheduler_output,
                    zeros_only,
                )

            self.prev_num_spec_tokens = draft_token_ids.shape[1]
            custom_class_enabled = getattr(
                self,
                "_nanoparl_async_custom_class_enabled",
                None,
            )
            if callable(custom_class_enabled) and custom_class_enabled():
                self._draft_token_req_ids = self.input_batch.req_ids.copy()
                return
            if self.use_async_scheduling and not (
                scheduler_output.has_structured_output_requests
                or self.input_batch.sampling_metadata.output_token_ids
            ):
                return
            self._draft_token_req_ids = self.input_batch.req_ids.copy()
            assert self.draft_token_ids_event is not None
            assert self.draft_token_ids_copy_stream is not None
            default_stream = torch.npu.current_stream()
            with torch.npu.stream(self.draft_token_ids_copy_stream):
                if not zeros_only:
                    self.draft_token_ids_copy_stream.wait_stream(default_stream)
                _copy_dynamic_draft_tokens(
                    destination,
                    draft_token_ids,
                    zeros_only=zeros_only,
                )
                self.draft_token_ids_event.record()

        def check_and_update_cudagraph_mode(
            self: Any,
            *args: Any,
            **kwargs: Any,
        ) -> Any:
            if not settings.adaptive_full_graph or original_restore_capture_sizes is not None:
                return original_check_cudagraph_mode(self, *args, **kwargs)

            requested_capture_sizes = list(self.compilation_config.cudagraph_capture_sizes or ())
            dispatcher = self.cudagraph_dispatcher
            original_initialize = dispatcher.initialize_cudagraph_keys

            def initialize_cudagraph_keys(
                cudagraph_mode: Any,
                uniform_decode_query_len: int = 1,
            ) -> Any:
                resolved_capture_sizes = tuple(
                    self.compilation_config.cudagraph_capture_sizes or ()
                )
                restore_adaptive_capture_sizes(
                    self.compilation_config,
                    method=(
                        self.speculative_config.method
                        if self.speculative_config is not None
                        else None
                    ),
                    requested_capture_sizes=requested_capture_sizes,
                )
                if cudagraph_mode.separate_routine():
                    _initialize_adaptive_graph_keys(
                        dispatcher,
                        cudagraph_mode,
                        self._nanoparl_uniform_decode_query_lens,
                        resolved_capture_sizes,
                    )
                    if settings.method == "draft_model":
                        from ..backends.draft import (
                            _add_draft_continuation_graph_keys,
                        )

                        graph_min_gamma = max(1, settings.adaptive_min_gamma)
                        native_gamma = _native_full_graph_gamma(
                            self.drafter,
                            settings.adaptive_max_gamma,
                            graph_min_gamma,
                        )
                        continuation_query_lens = (
                            (native_gamma + 2,)
                            if native_gamma == 2
                            else tuple(
                                range(
                                    graph_min_gamma + 2,
                                    settings.adaptive_max_gamma + 3,
                                )
                            )
                        )
                        _add_draft_continuation_graph_keys(
                            dispatcher,
                            cudagraph_mode,
                            settings.adaptive_max_gamma + 1,
                            query_lens=continuation_query_lens,
                        )
                    return None
                result = original_initialize(cudagraph_mode, uniform_decode_query_len)
                _add_adaptive_decode_graph_keys(
                    dispatcher,
                    self._nanoparl_uniform_decode_query_lens,
                )
                return result

            dispatcher.initialize_cudagraph_keys = initialize_cudagraph_keys
            try:
                return original_check_cudagraph_mode(self, *args, **kwargs)
            finally:
                dispatcher.initialize_cudagraph_keys = original_initialize

        NPUModelRunner.__init__ = runner_init
        NPUModelRunner._prepare_inputs = prepare_inputs
        NPUModelRunner.execute_model = execute_model
        NPUModelRunner.sample_tokens = sample_tokens
        NPUModelRunner._warmup_and_capture = warmup_and_capture
        NPUModelRunner._determine_batch_execution_and_padding = (
            determine_batch_execution_and_padding
        )
        NPUModelRunner.profile_cudagraph_memory = profile_cudagraph_memory
        NPUModelRunner.capture_model = capture_model
        NPUModelRunner.propose_draft_token_ids = propose_draft_token_ids
        NPUModelRunner._copy_draft_token_ids_to_cpu = copy_draft_tokens_to_cpu
        NPUModelRunner._check_and_update_cudagraph_mode = check_and_update_cudagraph_mode
        setattr(NPUModelRunner, RUNNER_PATCH_MARKER, True)
        applied = True

    return applied
