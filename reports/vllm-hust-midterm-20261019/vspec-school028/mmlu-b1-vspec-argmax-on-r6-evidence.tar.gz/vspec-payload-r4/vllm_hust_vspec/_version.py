"""vSpec package version."""

__version__ = "0.14.3"
