import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/root/vllm-hust-kv-materialization-arrival-control')
commit = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
payload = root / 'kvmat-managed-payload-r1'
files = {}
for path in sorted((payload / 'vllm_kv_materialization').rglob('*')):
    if path.suffix not in ('.py', '.json'):
        continue
    source = subprocess.check_output(['git', '-C', str(repo), 'show', f'{commit}:src/{path.relative_to(payload)}'])
    assert path.read_bytes() == source
    files[str(path.relative_to(root))] = hashlib.sha256(source).hexdigest()
(root / 'kvmat-managed-source-receipt.json').write_text(json.dumps({
    'source_commit': commit, 'installed_python_files': files,
    'activation': 'Manager school028 recompute bundle; native manifest unchanged',
}, indent=2) + '\n')
print(commit, len(files))
