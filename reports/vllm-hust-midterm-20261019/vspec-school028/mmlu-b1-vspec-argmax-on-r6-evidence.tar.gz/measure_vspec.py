"""Run isolated original-profile B0/B1 bursts with complete lifecycle sampling."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def descendant(pid, ancestors):
    seen = set()
    while pid > 1 and pid not in seen:
        if pid in ancestors:
            return True
        seen.add(pid)
        try:
            # The process comm may contain spaces or parentheses.
            fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
            pid = int(fields[1])
        except FileNotFoundError:
            return False
    return False


def stop(child):
    if child is None:
        return None
    for sig, seconds in [(signal.SIGINT, 90), (signal.SIGTERM, 20), (signal.SIGKILL, 10)]:
        try:
            os.killpg(child.pid, sig)
        except ProcessLookupError:
            break
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            child.poll()
            try:
                os.killpg(child.pid, 0)
            except ProcessLookupError:
                break
            time.sleep(1)
        else:
            continue
        break
    return child.wait(timeout=10)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('arm', choices=['b0', 'b1'])
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--mode', choices=['off', 'on'], default='on')
    args = parser.parse_args()
    out = ROOT / args.run_id
    out.mkdir(exist_ok=False)
    record = dict(arm=args.arm, status='admitting', started=time.time(),
                  allocated_cards=2, reserved_cards=4, simultaneous_other_services=0,
                  protocol='original MMLU 200-request burst, output 256, infinite arrival rate',
                  measurement_role='E24/R36 plus KV recompute plus FA Microflow ON plus vSpec local argmax ' + args.mode,
                  input_hashes={name:hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                      for name in ['measure_vspec.py', 'baseline.py', 'baseline.sh', 'runtime-vspec.sh',
                                   'launch_vspec.py', 'serve-vspec.sh', 'microflow-source-receipt.json',
                                   'vspec-source-receipt-r4.json', 'vspec-manager.json', 'vspec-manager-receipt.json',
                                   'vspec-repetition-plan.json', 'vspec-prior-best.json',
                                   'microflow-manager-receipt.json', 'microflow-manager.json', 'seal_microflow.py',
                                   'microflow-cache-seed.json', 'seal_microflow_cache_seed.py',
                                   'kvmat-managed-source-receipt.json', 'seal_kvmat_managed.py',
                                   'bench.sh', 'materialized.200.jsonl', 'payload-receipt.json',
                                   'compat/sitecustomize.py', 'compat/triton_compat.py']})
    children = []
    locks = []
    sealed = json.loads((ROOT / 'kvmat-managed-source-receipt.json').read_text())
    record['input_hashes'].update(sealed['installed_python_files'])
    micro = json.loads((ROOT / 'microflow-source-receipt.json').read_text())
    record['input_hashes'].update(micro['files'])
    record['microflow_source_commit'] = micro['commit']
    vspec = json.loads((ROOT / 'vspec-source-receipt-r4.json').read_text())
    record['input_hashes'].update(vspec['files'])
    record['vspec_source_commit'] = vspec['commit']

    def save():
        (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    try:
        for name, digest in vspec['files'].items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
        for name, digest in micro['files'].items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
        for name, digest in sealed['installed_python_files'].items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
        assert hashlib.sha256((ROOT / 'materialized.200.jsonl').read_bytes()).hexdigest() == 'fb79b6fa98f232282a948e4a17f404f80c03dc2bae05af57b95b9cc0651b3506'
        if args.arm == 'b1':
            qualification = json.loads((ROOT / 'qualification-r2/receipt.json').read_text())
            assert qualification['status'] == 'text_smoke_passed' and qualification['all_devices_released']
        for name in ['/tmp/inference-project-container-model.lock'] + [f'/tmp/gennova-device-leases/device-{i}.lock' for i in range(4, 8)]:
            stream = open(name, 'a+b'); locks.append(stream)
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for _ in range(3):
            smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
            assert all(f'No running processes found in NPU {i}' in smi for i in range(4, 8))
            time.sleep(2)
        (out / 'npu-before.txt').write_text(smi)
        assert shutil.disk_usage(ROOT).free > 5 * 1024**3
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', 18390))
        with (out / 'service.log').open('x') as log, (out / 'bench.log').open('x') as bench_log, (out / 'device-samples.jsonl').open('x') as samples:
            server = subprocess.Popen(['bash', str(ROOT / ('baseline.sh' if args.arm == 'b0' else 'runtime-vspec.sh'))], env={**os.environ, 'KVMAT_RUN_DIR': str(out), 'HUST_MICROFLOW_ARM': 'on', 'HUST_VSPEC_SCHOOL_MODE': args.mode}, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append(server)
            record.update(status='starting', service_pid=server.pid); save()
            deadline = time.monotonic() + 1200
            bench = None
            quiet_samples = 0
            while True:
                assert server.poll() is None, f'Service exited {server.returncode}'
                assert time.monotonic() < deadline, 'Stage timeout'
                assert shutil.disk_usage(ROOT).free > 2 * 1024**3, 'Disk reserve exhausted'
                t0 = time.monotonic()
                raw = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
                samples.write(json.dumps(dict(wall_time=time.time(), start_monotonic=t0, end_monotonic=time.monotonic(), phase=record['status'], raw=raw)) + '\n'); samples.flush()
                owned_groups = {p.pid for p in children}
                foreign = []
                for line in raw.splitlines():
                    match = re.match(r'\|\s*[4-7]\s+0\s*\|\s*(\d+)\s*\|', line)
                    if match:
                        try:
                            group = os.getpgid(int(match[1]))
                        except ProcessLookupError:
                            continue
                        if group not in owned_groups and not descendant(int(match[1]), owned_groups):
                            foreign.append(int(match[1]))
                if foreign:
                    record.setdefault('startup_foreign_context_observations', []).append({'time': time.time(), 'pids': foreign, 'phase': record['status']})
                    save()
                    assert bench is None, 'Unrelated NPU process appeared during measurement; no result admitted'
                    quiet_samples = 0
                else:
                    quiet_samples += 1
                if bench is None:
                    try:
                        with OPENER.open('http://127.0.0.1:18390/health', timeout=1) as response:
                            ready = response.status == 200
                    except OSError:
                        ready = False
                    if ready and quiet_samples >= 3:
                        assert 'KV_MATERIALIZATION_PLUGIN_REGISTERED host_api=school028-recompute-only' in (out / 'service.log').read_text(), 'KV recompute was not activated'
                        events = [json.loads(line) for path in out.glob('microflow-*.jsonl')
                                  for line in path.read_text().splitlines()]
                        loaded = [e for e in events if e['event'] == 'model_loaded']
                        assert {e['rank'] for e in loaded} == {0, 1}, 'Missing actual Microflow worker receipts'
                        assert all(e['active'] for e in loaded)
                        if True:
                            checks = [e for e in events if e['event'] == 'partition_equivalence']
                            assert {(e['rank'], e['tokens']) for e in checks} == {(r, t) for r in (0, 1) for t in (1024, 2048, 4096)}
                            assert all(all(e['exact']) for e in checks)
                            assert any(e['event'] == 'prefix' and e['split'] and e['capturing'] for e in events)
                        vspec_events = [json.loads(line) for path in out.glob('vspec-*.jsonl') for line in path.read_text().splitlines()]
                        checks = [e for e in vspec_events if e['event'] == 'head_equivalence']
                        assert {(e['rank'], e['rows'], e['kind']) for e in checks} == {(r, n, k) for r in (0, 1) for n in (1, 24, 36, 48) for k in ('zeros', 'sin')}
                        assert all(e['exact'] for e in checks)
                        assert {e['rank'] for e in vspec_events if e['event'] == 'model_loaded' and e['active'] == (args.mode == 'on')} == {0, 1}
                        record.update(status='benchmark_client', bench_started_wall=time.time(), bench_started_monotonic=time.monotonic()); save()
                        bench = subprocess.Popen(['bash', str(ROOT / 'bench.sh'), str(out)], stdout=bench_log, stderr=subprocess.STDOUT, start_new_session=True)
                        children.append(bench)
                        deadline = time.monotonic() + 900
                elif bench.poll() is not None:
                    record.update(bench_exit_code=bench.returncode, bench_ended_wall=time.time(), bench_ended_monotonic=time.monotonic())
                    assert bench.returncode == 0, f'Bench exited {bench.returncode}'
                    result = json.loads((out / 'mmlu-pro.json').read_text())
                    assert result['completed'] == 200 and result['failed'] == 0
                    policy = [json.loads(line) for line in (out / 'kvmat-policy.jsonl').read_text().splitlines()]
                    engine = [json.loads(line) for line in (out / 'kvmat-engine.jsonl').read_text().splitlines()]
                    assert len(policy) == 200
                    assert sum(e.get('event') == 'school028_request_salt_admitted' for e in engine) == 200
                    record.update(status='measured', output_throughput=result['output_throughput'])
                    break
                time.sleep(max(0, 1 - (time.monotonic() - t0)))
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        record['child_exit_codes'] = [stop(child) for child in reversed(children)]
        smi = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=15)
        (out / 'npu-after.txt').write_text(smi)
        record.update(ended=time.time(), all_devices_released=all(f'No running processes found in NPU {i}' in smi for i in range(4, 8)))
        save()
        for stream in locks:
            stream.close()
        files = [p for p in out.iterdir() if p.is_file() and p.name != 'SHA256SUMS']
        (out / 'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in files))
    print(json.dumps(record, indent=2))
    return 0 if record['status'] == 'measured' and record['all_devices_released'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
