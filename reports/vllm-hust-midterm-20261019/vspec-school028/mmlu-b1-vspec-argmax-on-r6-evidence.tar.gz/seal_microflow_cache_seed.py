import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
seed = Path('/workspace/microflow-b1-compiler-seed')
files = {str(p.relative_to(seed)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(seed.rglob('*')) if p.is_file()}
(root / 'microflow-cache-seed.json').write_text(json.dumps({
    'source': 'Existing B1 cache/triton and cache/inductor; copied before this pair',
    'seed_directory': str(seed), 'files': files,
    'scope': 'Independent per-arm copies; VLLM AOT cache remains fresh',
}, indent=2) + '\n')
print(len(files), 'cache files sealed')
