import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
repo = Path('/root/vllm-hust-prefill-microflow')
commit = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
files = {}
for p in sorted((ROOT / 'microflow-payload-r4/hust_prefill_microflow').rglob('*')):
    if p.suffix not in ('.py', '.json'):
        continue
    source = 'src/' + str(p.relative_to(ROOT / 'microflow-payload-r4'))
    expected = subprocess.check_output(['git', '-C', str(repo), 'show', f'{commit}:{source}'])
    assert p.read_bytes() == expected, source
    files[str(p.relative_to(ROOT))] = hashlib.sha256(expected).hexdigest()
(ROOT / 'microflow-source-receipt.json').write_text(json.dumps({'commit':commit,'files':files},indent=2)+'\n')
