#!/usr/bin/env bash
set -eo pipefail
unset PYTHONPATH
source /usr/local/Ascend/cann-9.1.0/set_env.sh >/dev/null
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1 >/dev/null
set -u
ROOT=/root/gennova-evidence/20261019-midterm-aligned
export PYTHONPATH=$ROOT/compat${PYTHONPATH:+:$PYTHONPATH}
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY http_proxy https_proxy all_proxy
export ASCEND_RT_VISIBLE_DEVICES=0,1
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector
export VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_ENABLE_V1_MULTIPROCESSING=1
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 TASK_QUEUE_ENABLE=0 HCCL_OP_EXPANSION_MODE=AIV
export VLLM_CACHE_ROOT=$ROOT/baseline-cache/vllm
export TRITON_CACHE_DIR=$ROOT/baseline-cache/triton TORCHINDUCTOR_CACHE_DIR=$ROOT/baseline-cache/inductor
exec /workspace/gennova-6-20261019/shared028-device-r1/deployed/runtime/venv-school-r1/bin/python "$ROOT/baseline.py"
