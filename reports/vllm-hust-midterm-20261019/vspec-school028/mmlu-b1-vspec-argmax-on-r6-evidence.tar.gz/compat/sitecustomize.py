"""Load only the audited Triton distribution-name compatibility correction."""
import importlib.abc
import importlib.util
from pathlib import Path
import sys


class CompatibilityFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'vllm_ascend._triton_compat':
            return importlib.util.spec_from_file_location(
                fullname, Path(__file__).with_name('triton_compat.py'))
        return None


sys.meta_path.insert(0, CompatibilityFinder())
