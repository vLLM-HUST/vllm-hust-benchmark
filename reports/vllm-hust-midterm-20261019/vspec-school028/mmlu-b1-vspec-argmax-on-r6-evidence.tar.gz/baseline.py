"""Reproduce the original MMLU B0 profile on the same school runtime."""
import json
import os
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
profile = json.loads(Path('/root/vllm-hust-benchmark/reports/mmlu-pro-qwen35-b0-precheck-20261012/reproduction/b0_35b.profile.json').read_text())
args = list(profile['serve_args'])
args[args.index('--port') + 1] = '18390'
command = [sys.executable, '-m', 'vllm.entrypoints.cli.main', 'serve', profile['model']['path'], *args]
(root / 'baseline-command.json').write_text(json.dumps(command, indent=2) + '\n')
os.execv(sys.executable, command)
