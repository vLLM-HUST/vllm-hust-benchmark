"""E24/R36 plus isolated, source-pinned recompute controller."""
import hashlib
import inspect
import json
import os
import shutil
from pathlib import Path
from betterscale.models.qwen35.launch import prepare
import vllm_kv_materialization.school_vllm_028 as adapter

ROOT = Path(__file__).resolve().parent
out = Path(os.environ['KVMAT_RUN_DIR']).resolve()
assert out.parent == ROOT
cache = Path('/workspace') / out.name
arm = os.environ['HUST_MICROFLOW_ARM']
seed = json.loads((ROOT / 'microflow-cache-seed.json').read_text())
seed_path = Path(seed['seed_directory'])
for name, digest in seed['files'].items():
    assert hashlib.sha256((seed_path / name).read_bytes()).hexdigest() == digest
for name in ('triton', 'inductor'):
    destination = cache / arm / name
    assert not destination.exists()
    shutil.copytree(seed_path / name, destination)
(out / 'compiler-cache-initialization.json').write_text(json.dumps({
    'seed_manifest_sha256': hashlib.sha256((ROOT / 'microflow-cache-seed.json').read_bytes()).hexdigest(),
    'files': len(seed['files']), 'vllm_aot_cache': 'fresh',
    'destination': str(cache / arm),
}, indent=2) + '\n')
os.environ.update(HUST_MICROFLOW_CACHE_ROOT=str(cache),
                  HUST_MICROFLOW_EVENT_DIR=str(out),
                  HUST_VSPEC_SCHOOL_EVENT_DIR=str(out),
                  VLLM_CACHE_ROOT=str(cache / arm / 'vllm'),
                  TRITON_CACHE_DIR=str(cache / arm / 'triton'),
                  TORCHINDUCTOR_CACHE_DIR=str(cache / arm / 'inductor'))
source = Path(inspect.getfile(adapter)).resolve()
assert source.is_relative_to(ROOT / 'kvmat-managed-payload-r1')
command, env = prepare(
    model=Path('/models/Qwen3.5-35B-A3B'), devices='0,1', port=18390,
    cache_dir=cache / arm / 'vllm',
    runtime_dir=ROOT / 'runtime', context_tokens=65536,
    state_budget_bytes=21474836480, served_model_name='qwen3.5-35b',
    distributed_port=29670, execution_seats=24, resident_seats=36,
    mtp_tokens=2, max_images=0,
)
assert Path(command[1]).name == 'serve.sh'
command[1] = str(ROOT / 'serve-vspec.sh')
env['VLLM_KV_MATERIALIZATION_LOG_PATH'] = str(out / 'kvmat-policy.jsonl')
env['VLLM_KV_MATERIALIZATION_RUNTIME_EVENT_LOG_PATH'] = str(out / 'kvmat-engine.jsonl')
(out / 'kvmat-import.json').write_text(json.dumps({
    'source_commit': json.loads((ROOT / 'kvmat-managed-source-receipt.json').read_text())['source_commit'], 'adapter_import': str(source),
    'adapter_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'scope': 'recompute only; no eligible reuse anchors in original workload',
}, indent=2) + '\n')
(out / 'launch-command.json').write_text(json.dumps(command, indent=2) + '\n')
os.environ.update(env)
from vllm_hust_ext.cli import main
raise SystemExit(main(['run', '--', *command]))
