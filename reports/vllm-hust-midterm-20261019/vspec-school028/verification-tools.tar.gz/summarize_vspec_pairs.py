import hashlib
import importlib.util
import json
import math
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
verifier = Path('/root/vllm-hust-vspec-school028/scripts/verify_school028_run.py')
spec = importlib.util.spec_from_file_location('verify_vspec', verifier)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
plan = json.loads((root / 'vspec-repetition-plan.json').read_text())
prior = json.loads((root / 'vspec-prior-best.json').read_text())
keys = ['output_throughput', 'mean_ttft_ms', 'mean_tpot_ms', 'p99_tpot_ms', 'p99_tpot_nearest_ms']
best = {
    'output_throughput': max(m['output_tps'] for m in prior['measurements'].values()),
    'mean_ttft_ms': 1000 * min(m['ttft_s']['mean'] for m in prior['measurements'].values()),
    'mean_tpot_ms': 1000 * min(m['tpot_s']['mean'] for m in prior['measurements'].values()),
}
rows = []
hashes = []
for index, pair in enumerate(plan['pairs'], 1):
    for mode in ('off', 'on'):
        run = pair[mode]
        verified = module.verify(root, run)
        raw = json.loads((root / run / 'mmlu-pro.json').read_text())
        receipt = json.loads((root / run / 'receipt.json').read_text())
        hashes.append(receipt['input_hashes'])
        values = [(latency - ttft) / (length - 1) for latency, ttft, length
                  in zip(raw['latencies'], raw['ttfts'], raw['output_lens'])]
        assert math.isclose(statistics.mean(values) * 1000, raw['mean_tpot_ms'], rel_tol=1e-8)
        assert math.isclose(statistics.mean(raw['ttfts']) * 1000, raw['mean_ttft_ms'], rel_tol=1e-8)
        raw['p99_tpot_nearest_ms'] = 1000 * sorted(values)[math.ceil(0.99 * len(values)) - 1]
        archive = root / (run + '-evidence.tar.gz')
        rows.append(dict(pair_index=index, mode=mode, verification=verified,
                         metrics={k: raw[k] for k in keys}, duration_seconds=raw['duration'],
                         ended=receipt['ended'], archive=archive.name,
                         archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                         raw_sha256=hashlib.sha256((root / run / 'mmlu-pro.json').read_bytes()).hexdigest()))
assert all(h == hashes[0] for h in hashes)
aggregate = {mode: {key: {
    'median': statistics.median(r['metrics'][key] for r in rows if r['mode'] == mode),
    'min': min(r['metrics'][key] for r in rows if r['mode'] == mode),
    'max': max(r['metrics'][key] for r in rows if r['mode'] == mode),
} for key in keys} for mode in ('off', 'on')}
ratios = [rows[i+1]['metrics']['output_throughput'] / rows[i]['metrics']['output_throughput'] for i in (0, 2, 4)]
gain = 100 * (statistics.geometric_mean(ratios) - 1)
on = {key: value['median'] for key, value in aggregate['on'].items()}
improves = {key: (on[key] > value and gain > 0 if key == 'output_throughput'
                  else on[key] < value and on[key] < aggregate['off'][key]['median'])
            for key, value in best.items()}
summary = dict(schema='vspec-school028-pair-screen/v1', project='vLLM-HUST',
               scope='Microflow B1 plus isolated MTP local argmax service performance screen',
               workload='MMLU-Pro, original 200-request burst, infinite arrival, out256',
               input_sha256=hashlib.sha256((root / 'materialized.200.jsonl').read_bytes()).hexdigest(),
               configuration='Qwen3.5-35B-A3B BF16 TP2 EP-off E24/R36 ctx64k APC MTP2 FULL async, 20GiB state and 8GiB host per rank',
               independent_pairs=3, quality_rescored=False, aggregation=plan['selection'],
               aggregates=aggregate, paired_throughput_ratios=ratios, runs=rows,
               verifier_sha256=hashlib.sha256(verifier.read_bytes()).hexdigest(),
               current_best_per_metric=best, improves_current_best_per_metric=improves,
               on_vs_off_throughput_pct=gain,
               on_vs_current_throughput_b1_pct=100*(on['output_throughput']/best['output_throughput']-1),
               promote_throughput_candidate=improves['output_throughput'])
(root / 'vspec-pair-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
