import argparse
import hashlib
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('run')
args = parser.parse_args()
receipt = json.loads((root / args.run / 'receipt.json').read_text())
files = set((root / args.run).glob('*'))
files.add(root / 'mmlu-b1-kvmat-e24-r36-screen-r1/mmlu-pro.json')
for name, digest in receipt['input_hashes'].items():
    path = root / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
    files.add(path)
archive = root / (args.run + '-evidence.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(files):
        if path.is_file():
            tar.add(path, arcname=str(path.relative_to(root)))
print(archive.name, hashlib.sha256(archive.read_bytes()).hexdigest())
