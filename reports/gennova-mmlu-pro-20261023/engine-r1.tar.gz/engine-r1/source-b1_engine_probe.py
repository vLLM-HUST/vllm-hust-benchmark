"""Current best B1 at the same tokenized request-engine client boundary."""
import asyncio
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent


def bootstrap():
    from launch_boundary_b1 import prepare_command, reserve_cache
    from vllm_hust_ext.cli import main as manager_main
    out = Path(os.environ['CAPSULE'])
    cache = out/'cache'
    reserve_cache(cache)
    command, env, original = prepare_command(out, cache)
    assert command[-2:] == ['--worker-extension-cls', 'synchronized_boundary.WorkerBoundary']
    serving_args = command[4:-2]
    assert serving_args == json.loads(original.read_text())[2:]
    env['CAPSULE'] = str(out)
    os.environ.update(env)
    (out/'serving-arguments.json').write_text(json.dumps(serving_args,indent=2))
    raise SystemExit(manager_main(['run', '--', sys.executable, __file__, '--engine', *serving_args]))


async def run():
    from vllm.entrypoints.launchers.cli_args import make_arg_parser
    from vllm.entrypoints.launchers.api_server.entry import build_async_engine_client
    from vllm.utils.argparse_utils import FlexibleArgumentParser
    from vllm import SamplingParams
    args = make_arg_parser(FlexibleArgumentParser()).parse_args(sys.argv[2:])
    args.model = args.model_tag
    out = Path(os.environ['CAPSULE'])
    rows = json.loads((ROOT/'workload.json').read_text())['requests']
    events = []
    async with build_async_engine_client(args) as engine:
        print('B1 tokenized request engine ready', flush=True)
        async def request(row):
            params = SamplingParams(temperature=0,max_tokens=256,ignore_eos=True,detokenize=False)
            last, final = 0, None
            async for result in engine.generate({'prompt_token_ids':row['input_ids']},params,request_id=row['request_id']):
                tokens = result.outputs[0].token_ids
                if len(tokens)>last:
                    events.append(dict(request_id=row['request_id'],seconds=time.perf_counter()-begin,count=len(tokens)-last))
                    last = len(tokens)
                final = result
            assert final is not None and final.finished
            assert len(final.outputs[0].token_ids)==256
            return dict(request_id=row['request_id'],tokens=list(final.outputs[0].token_ids),cached_tokens=final.num_cached_tokens)
        begin = time.perf_counter()
        results = await asyncio.gather(*(request(row) for row in rows))
        seconds = time.perf_counter()-begin
        payload = dict(engine='current B1',status='completed',seconds=seconds,
                       timing_boundary='tokenized enqueue through CPU-visible complete outputs',
                       total_input_tokens=sum(len(r['input_ids']) for r in rows),
                       total_output_tokens=sum(len(r['tokens']) for r in results),
                       outputs=results,token_delivery_events=events)
        (out/'results.json').write_text(json.dumps(payload,indent=2)+'\n')
        print('B1 completed',seconds,flush=True)


if __name__=='__main__':
    if len(sys.argv)==1:
        bootstrap()
    else:
        asyncio.run(run())
