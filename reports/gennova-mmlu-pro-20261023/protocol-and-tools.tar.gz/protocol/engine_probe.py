"""Independent real-weight request-engine candidate; not an HTTP benchmark."""
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import torch
import torch.distributed as dist
import torch_npu
from livemodule.arch.ascend.llm.better_qwen35.collective import TensorParallel
from livemodule.arch.ascend.llm.better_qwen35.native import SchoolOps
from livemodule.arch.ascend.llm.better_qwen35.recipe import KernelArtifacts
from livemodule.arch.ascend.llm.better_qwen35.session import SessionCapacity, open_session
from livemodule.serve.better_qwen35.scheduler import Request


@torch.no_grad()
def main():
    root = Path(__file__).resolve().parent
    out = Path(os.environ['CAPSULE'])
    rank = int(os.environ['LOCAL_RANK'])
    workload = json.loads((root/'workload.json').read_text())
    pilot = os.environ.get('GENNOVA_PILOT') == '1'
    rows = workload['requests'][:4] if pilot else workload['requests']
    budget = 16 if pilot else 256
    build = root/'build'
    native = SchoolOps(host_library=build/'aclnn-r2/liblive_aclnn_host.so',
                       vendor_path=build/'aclnn-r2/opp/vendors/custom_transformer')
    artifacts = KernelArtifacts(build/'gdn/lib/libbs_gdn.so',
                                build/'gdn/liblive_gdn_host.so',
                                build/'fia/liblive_fia.so',
                                build/'fia/liblive_fia_host.so')
    torch.npu.set_device(rank)
    dist.init_process_group('hccl', timeout=timedelta(seconds=600))
    capacity = SessionCapacity(24, 36, 2048, 4096, 65536)
    record = dict(rank=rank, engine='GenNova', pilot=pilot, capacity=vars(capacity),
                  torch=torch.__version__, torch_npu=torch_npu.__version__,
                  workload_sha256=hashlib.sha256((root/'workload.json').read_bytes()).hexdigest(),
                  timing_boundary='tokenized enqueue through CPU-visible complete outputs',
                  http_comparable=False, status='starting')

    def save():
        (out/f'rank-{rank}.json').write_text(json.dumps(record, indent=2)+'\n')

    save()
    try:
        start = time.perf_counter()
        with open_session('/models/Qwen3.5-35B-A3B', capacity, device=f'npu:{rank}',
                          native=native, artifacts=artifacts,
                          collective=TensorParallel(dist.group.WORLD)) as session:
            record.update(startup_s=time.perf_counter()-start, weights=session.weight_receipt)
            assert not session.root.remaining.tensor.any().item()
            assert not session.root.continuation.resident_epoch.tensor.any().item()
            assert not any(name == 'vllm' or name.startswith(('vllm.', 'vllm_ascend.', 'betterscale.')) for name in sys.modules)
            events, delivered = [], {r['request_id']: 0 for r in rows}
            complete = session.scheduler.complete

            def observe(batch, tokens, valid):
                result = complete(batch, tokens, valid)
                at = time.perf_counter()-begin
                for name, count in zip(batch.request_ids, valid):
                    count = min(count, budget-delivered[name])
                    if count:
                        delivered[name] += count
                        events.append(dict(request_id=name, seconds=at, count=count))
                return result

            session.scheduler.complete = observe
            record['status'] = 'ready'
            save()
            dist.barrier()
            torch.npu.synchronize()
            print('GenNova ready', rank, flush=True)
            begin = time.perf_counter()
            for row in rows:
                session.scheduler.enqueue(Request(row['request_id'], tuple(row['input_ids']), budget))
            results, ticks = [], 0
            while not session.scheduler.idle:
                results.extend(session.loop.tick())
                ticks += 1
                if ticks > 10000 or time.perf_counter()-begin > 1800:
                    raise RuntimeError('Bounded request-engine progress limit exceeded')
            elapsed = time.perf_counter()-begin
            result_map = {r.request_id: list(r.tokens) for r in results}
            assert len(result_map) == len(rows)
            assert all(len(v) == budget for v in result_map.values())
            peers = [None, None]
            dist.all_gather_object(peers, result_map)
            assert peers[0] == peers[1], 'TP output disagreement'
            record.update(status='completed', seconds=elapsed, ticks=ticks,
                          outputs=result_map, token_delivery_events=events,
                          total_input_tokens=sum(len(r['input_ids']) for r in rows),
                          total_output_tokens=sum(map(len, result_map.values())),
                          peak_memory_allocated=torch.npu.max_memory_allocated(),
                          native_libraries=sorted(torch.ops.loaded_libraries))
            save()
            print('GenNova completed', rank, elapsed, flush=True)
    except BaseException as exc:
        record.update(status='failed', error_type=type(exc).__name__, error=str(exc))
        save()
        raise
    finally:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
