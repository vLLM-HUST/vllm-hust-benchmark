"""Exclusive, bounded admission for an owned GenNova qualification process."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent
repo = Path('/workspace/GenNova')
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['native', 'checkpoint', 'pilot', 'engine', 'b1', 'snapshot'])
parser.add_argument('--label', required=True)
args = parser.parse_args()
out = root/args.label
if out.parent != root or out.exists():
    raise ValueError('Fresh immediate child output directory required')
devices = (0, 1, 6, 7)
locks = []
for path in ['/tmp/inference-project-container-model.lock', *[f'/tmp/gennova-device-leases/device-{i}.lock' for i in devices]]:
    stream = open(path, 'a+b')
    fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
    locks.append(stream)
out.mkdir()
identity = json.loads(Path('/workspace/m01-boundary-b1-r1/execution-plan.json').read_text())['model_weight_identity']
checkpoint = Path(identity['directory'])
for row in identity['files']:
    stat = (checkpoint/row['name']).stat()
    assert (stat.st_size, stat.st_ino, stat.st_mtime_ns) == (row['size'], row['inode'], row['mtime_ns'])
index = checkpoint/'model.safetensors.index.json'
assert hashlib.sha256(index.read_bytes()).hexdigest() == identity['index_sha256']
(out/'model-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for source in (Path(__file__), root/'engine_probe.py', root/'b1_engine_probe.py', root/'comparison-plan.json'):
    shutil.copyfile(source, out/('source-'+source.name))
def npu():
    return subprocess.check_output(['npu-smi', 'info'], text=True, timeout=30)
def idle(raw):
    return all(f'No running processes found in NPU {i}' in raw for i in devices)
for _ in range(3):
    raw = npu()
    if not idle(raw):
        raise RuntimeError('Devices occupied; no process was modified')
    time.sleep(2)
(out/'npu-before.txt').write_text(raw)
env = {k: os.environ[k] for k in ['PATH', 'LD_LIBRARY_PATH', 'ASCEND_OPP_PATH', 'ASCEND_HOME_PATH'] if k in os.environ}
env.update(HOME='/root', LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=str(repo/'src')+':/root/gennova-runtime/m01-triton-recovery-dev20261007-r2:/root/frontierscience-recovery-20261022/filtered-site',
           TASK_QUEUE_ENABLE='0', ASCEND_RT_VISIBLE_DEVICES='0,1',
           HCCL_OP_EXPANSION_MODE='AIV',
           OMP_NUM_THREADS='1', CAPSULE=str(out), GENNOVA_PILOT=str(int(args.mode=='pilot')),
           CHECKPOINT='/models/Qwen3.5-35B-A3B',
           TRITON_CACHE_DIR=str(out/'cache/triton'), XDG_CACHE_HOME=str(out/'cache/xdg'),
           TORCHINDUCTOR_CACHE_DIR=str(out/'cache/inductor'))
python = '/root/frontierscience-recovery-20261022/venv/bin/python'
for name, target in [('aclnn02', 'aclnn-r2'), ('fia-zero-query', 'fia')]:
    alias = root/'build'/name
    if not alias.exists():
        alias.symlink_to(target)
if args.mode == 'snapshot':
    repo = repo/'.worktrees/snapshot-coalescing'
    env['PYTHONPATH'] = str(repo/'src')+':/root/frontierscience-recovery-20261022/filtered-site'
    command = [python, str(repo/'research/betterscale-refactor/state_snapshot_probe.py'),
               '--reference-source', '/workspace/GenNova/src/livemodule/core/state_tensor.py',
               '--output', str(out/'results.json')]
    for source in [repo/'src/livemodule/core/state_tensor.py', repo/'research/betterscale-refactor/state_snapshot_probe.py']:
        shutil.copyfile(source, out/('source-'+source.name))
elif args.mode == 'b1':
    env['KVMAT_RUN_DIR'] = str(out)
    command = ['bash', '/workspace/m01-critical-path-review-20261023/runtime_boundary_b1.sh', str(root/'b1_engine_probe.py')]
elif args.mode == 'native':
    command = [python, str(repo/'research/betterscale-refactor/native_school_probe.py')]
else:
    probe = repo/'research/betterscale-refactor/session_checkpoint_probe.py' if args.mode == 'checkpoint' else root/'engine_probe.py'
    command = [python, '-m', 'torch.distributed.run', '--nproc-per-node=2', '--master-port=29731', str(probe)]
receipt = dict(mode=args.mode, command=command, status='starting',
               source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
               fresh_cache=True, participating=[0,1], reserved=list(devices),
               artifacts={str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'build').rglob('*.so') if '/source/' not in str(p)},
               started=time.time())
if args.mode == 'b1':
    receipt['comparison_candidate_commit'] = receipt.pop('source_commit')
    receipt['engine'] = 'current B1 combination; runtime identity in runtime.json'
def save():
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save()
proc = None
try:
    with (out/'service.log').open('x') as log:
        proc = subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        receipt.update(pid=proc.pid,status='running')
        save()
        deadline = time.monotonic()+2400
        while proc.poll() is None:
            if time.monotonic()>deadline:
                raise TimeoutError('Bounded qualification exceeded 2400 seconds')
            try:
                sample = dict(time=time.time(), npu=npu())
            except subprocess.TimeoutExpired:
                sample = dict(time=time.time(), error='npu-smi observation timeout')
            with (out/'device-samples.jsonl').open('a') as monitor:
                monitor.write(json.dumps(sample)+'\n')
            time.sleep(10)
        receipt.update(exit_code=proc.returncode,status='completed' if proc.returncode==0 else 'failed')
finally:
    if proc is not None:
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=60)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            proc.wait(timeout=30)
    for _ in range(30):
        raw=npu()
        if idle(raw):
            break
        time.sleep(2)
    receipt.update(all_devices_released=idle(raw),ended=time.time())
    (out/'npu-after.txt').write_text(raw)
    save()
    if not receipt['all_devices_released']:
        raise RuntimeError('Device release unconfirmed')
    paths=sorted(p for p in out.iterdir() if p.is_file())
    (out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in paths))
print(json.dumps({k:receipt[k] for k in ('mode','status','exit_code','all_devices_released')}))
raise SystemExit(receipt['exit_code'])
