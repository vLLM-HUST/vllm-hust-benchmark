import pytest
from compare_engines import delivery_metrics, validate_b1_actions


def test_delivery_uses_all_tokens_including_batched_first_chunk():
    events=[dict(request_id='a',seconds=2.,count=3),dict(request_id='a',seconds=5.,count=253)]
    result=delivery_metrics(events,{'a'})
    assert result['mean_ttft_s']==2.
    assert result['mean_tpot_s']==3/255


def test_reject_incomplete_output():
    with pytest.raises(AssertionError):
        delivery_metrics([dict(request_id='a',seconds=2.,count=255)],{'a'})


def test_reject_enabled_but_unexercised_b1():
    with pytest.raises(AssertionError, match='must be exercised'):
        validate_b1_actions({}, [], [])


def test_require_both_actual_actions():
    b1 = {'kvmat_admitted_requests':200}
    admitted = [dict(event='school028_request_salt_admitted', request_id=str(i)) for i in range(200)]
    validate_b1_actions(b1, admitted, [dict(event='graph_replay', active=True)])
    with pytest.raises(AssertionError):
        validate_b1_actions(b1, admitted, [dict(event='graph_replay', active=False)])
