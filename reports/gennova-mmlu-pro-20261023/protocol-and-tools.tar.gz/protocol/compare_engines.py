"""Pair only completed, released, full-workload request-engine receipts."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics


def validate_b1_actions(b1, admitted, microflow):
    assert b1.get('kvmat_admitted_requests') == 200, 'B1 KV materialization must be exercised'
    assert len(admitted) == 200
    assert all(row['event']=='school028_request_salt_admitted' for row in admitted)
    assert len({row['request_id'] for row in admitted}) == 200
    assert any(row['event']=='graph_replay' and row.get('active') for row in microflow)


def delivery_metrics(events, ids, budget=256):
    groups = {name: [] for name in ids}
    for event in events:
        assert event['request_id'] in groups
        assert type(event['count']) is int and event['count'] > 0
        groups[event['request_id']].append(event)
    ttfts, tpots = [], []
    for rows in groups.values():
        assert sum(row['count'] for row in rows) == budget
        times = [row['seconds'] for row in rows]
        assert times == sorted(times) and times[0] >= 0
        ttfts.append(times[0])
        tpots.append((times[-1]-times[0])/(budget-1))
    return dict(mean_ttft_s=statistics.mean(ttfts), mean_tpot_s=statistics.mean(tpots))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--b1', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    for directory in (args.candidate, args.b1):
        receipt = json.loads((directory/'receipt.json').read_text())
        assert receipt['status']=='completed' and receipt['exit_code']==0 and receipt['all_devices_released']
        for line in (directory/'SHA256SUMS').read_text().splitlines():
            sha, name = line.split('  ',1)
            assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==sha
    ranks = [json.loads((args.candidate/f'rank-{rank}.json').read_text()) for rank in (0,1)]
    b1 = json.loads((args.b1/'results.json').read_text())
    admitted = [json.loads(line) for line in (args.b1/'kvmat-engine.jsonl').read_text().splitlines()]
    microflow = [json.loads(line) for path in args.b1.glob('microflow-*.jsonl') for line in path.read_text().splitlines()]
    validate_b1_actions(b1, admitted, microflow)
    for item in [*ranks,b1]:
        assert item['status']=='completed'
        assert item['total_input_tokens']==282265 and item['total_output_tokens']==51200
        assert item['seconds']>0
    assert not any(rank['pilot'] for rank in ranks)
    assert ranks[0]['outputs']==ranks[1]['outputs']
    old = {r['request_id']:r['tokens'] for r in b1['outputs']}
    new = ranks[0]['outputs']
    assert set(old)==set(new) and len(new)==200
    assert all(len(tokens)==256 for tokens in [*old.values(),*new.values()])
    elapsed = max(rank['seconds'] for rank in ranks)
    exact = sum(old[name]==new[name] for name in old)
    generation = json.loads(Path('/models/Qwen3.5-35B-A3B/generation_config.json').read_text())
    eos = set(generation['eos_token_id'])
    eos_counts = {label: sum(any(t in eos for t in tokens) for tokens in outputs.values())
                  for label, outputs in [('candidate',new),('b1',old)]}
    result = dict(scope='single paired 200-request tokenized request-engine comparison; not HTTP or full MMLU-Pro quality',
                  candidate_seconds=elapsed,b1_seconds=b1['seconds'],
                  candidate_output_tps=51200/elapsed,b1_output_tps=51200/b1['seconds'],
                  throughput_gain_percent=(b1['seconds']/elapsed-1)*100,
                  exact_token_sequence_matches=exact,requests=200,
                  requests_with_eos=eos_counts,
                  stop_policy='Both paired engine arms use ignore_eos=True; prior HTTP results used the benchmark default EOS policy',
                  candidate_delivery=delivery_metrics(ranks[0]['token_delivery_events'],new),
                  b1_delivery=delivery_metrics(b1['token_delivery_events'],old),
                  b1_replacement_approved=False,
                  full_dataset_quality_score=None)
    with args.output.open('x') as stream:
        json.dump(result,stream,indent=2)
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
