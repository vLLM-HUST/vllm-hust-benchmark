"""Preserve run bytes in compressed capsules; omit caches and native binaries."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
DEST = Path('/workspace/gennova-benchmark/reports/gennova-mmlu-pro-20261023')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    DEST.mkdir(exist_ok=True)
    rows = []
    for label in ['native-r1', 'checkpoint-r1', 'checkpoint-r2', 'engine-r1', 'b1-r1', 'b1-r2', 'b1-r3', 'snapshot-r1']:
        directory = ROOT/label
        if not directory.exists():
            continue
        receipt = json.loads((directory/'receipt.json').read_text())
        if not receipt.get('all_devices_released') or receipt['status']=='running':
            raise ValueError('Refuse unsealed run '+label)
        files = sorted(p for p in directory.iterdir() if p.is_file())
        archive = DEST/(label+'.tar.gz')
        if archive.exists():
            raise FileExistsError(archive)
        with tarfile.open(archive,'w:gz') as stream:
            for path in files:
                stream.add(path,arcname=label+'/'+path.name)
        rows.append(dict(run=label,status=receipt['status'],archive=archive.name,
                         sha256=sha(archive),members={label+'/'+p.name:sha(p) for p in files}))
    inputs = [p for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.py','.json')]
    archive = DEST/'protocol-and-tools.tar.gz'
    with tarfile.open(archive,'x:gz') as stream:
        for path in sorted(inputs):
            stream.add(path,arcname='protocol/'+path.name)
    rows.append(dict(run='protocol',archive=archive.name,sha256=sha(archive),
                     members={'protocol/'+p.name:sha(p) for p in inputs}))
    manifest = dict(schema='gennova-independent-engine-evidence/v1',
                    scope='Independent Qwen3.5 BF16 TP2 qualification and MMLU-Pro request-engine comparison',
                    native_fix_pr='https://github.com/vLLM-HUST/GenNova/pull/171',
                    source_commit='ea13161d09446b8e8db0fc903b2356e75d1b4002',
                    native_fix_merge='946095c8d01b03b80a7b24928e739083bc74367c',
                    archives=rows,full_dataset_quality_score=None,b1_replacement_approved=False)
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Packaged',len(rows),'capsules')


if __name__=='__main__':
    main()
