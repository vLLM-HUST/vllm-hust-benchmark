"""Reproduce the actual frozen B1 custom-dataset/chat request transformation."""
import hashlib
import json
from pathlib import Path
from transformers import AutoTokenizer

root = Path(__file__).resolve().parent
source = Path('/root/gennova-evidence/20261019-midterm-aligned/materialized.200.jsonl')
baseline = Path('/workspace/m01-boundary-b1-r1/mmlu-pro.json')
tokenizer = AutoTokenizer.from_pretrained('/models/Qwen3.5-35B-A3B', local_files_only=True)
rows = [json.loads(line) for line in source.read_text().splitlines()]
requests = []
for i, row in enumerate(rows):
    # CustomDataset renders once; openai-chat wraps that string as user content.
    inner = tokenizer.apply_chat_template([dict(role='user', content=row['prompt'])],
                                         add_generation_prompt=True, tokenize=False)
    ids = tokenizer.apply_chat_template([dict(role='user', content=inner)],
                                       add_generation_prompt=True, return_dict=False)
    assert isinstance(ids, list) and all(type(t) is int for t in ids)
    requests.append(dict(request_id=f'mmlu-{i:03}', input_ids=ids, max_new_tokens=256))
expected = json.loads(baseline.read_text())
assert len(requests) == 200
assert [len(r['input_ids']) for r in requests] == expected['input_lens']
assert sum(len(r['input_ids']) for r in requests) == 282265
payload = dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               baseline_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),
               prompt_policy='Frozen B1 CustomDataset rendering followed by openai-chat rendering; preserved, not redesigned',
               thinking='checkpoint chat-template default', temperature=0,
               ignore_eos=True, requests=requests)
with (root/'workload.json').open('x') as stream:
    json.dump(payload, stream)
print('PASS: 200 per-request input lengths match B1; 282265 input tokens')
