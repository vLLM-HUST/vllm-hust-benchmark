"""Derived receipt for the observed successful clean-build retry."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
artifact = root/'build/aclnn-r2/liblive_aclnn_host.so'
vendor = root/'build/aclnn-r2/opp/vendors/custom_transformer'
assert artifact.is_file() and vendor.is_dir()
receipt = dict(kind='derived execution receipt; original failed build log retained',
               initial_failure_log='aclnn.log',
               source_commit='ea13161d09446b8e8db0fc903b2356e75d1b4002',
               command=['/root/frontierscience-recovery-20261022/venv/bin/python',
                        'native/ascend/better_qwen35/aclnn/build.py',
                        str(root/'build/aclnn-r2'),'--cann','/usr/local/Ascend/cann-9.1.0'],
               observed_exit_code=0,
               compiler_stdout_preserved_as_local_file=False,
               execution_evidence='native-r1/SHA256SUMS',
               artifacts={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [artifact,*sorted(p for p in vendor.rglob('*') if p.is_file())]})
with (root/'build-retry-receipt.json').open('x') as stream:
    json.dump(receipt,stream,indent=2)
    stream.write('\n')
