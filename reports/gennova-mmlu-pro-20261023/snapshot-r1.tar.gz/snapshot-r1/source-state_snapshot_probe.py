"""Bounded native differential for construction-only State host images."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import time

import torch
import torch_npu  # noqa: F401

from livemodule import LiveModule, LiveRuntime, StateDomain, ExactStateCapacity
from livemodule import StateTensor, TorchStateBackend, live_runtime
from livemodule.arch.ascend.binding import ASCEND
from livemodule.core import state_tensor


class Root(LiveModule):
    def __init__(self, domain):
        super().__init__()
        self.register_state('state', StateTensor(
            role='probe', requirement='probe', domain=domain,
            block_shape=(128, 32), storage_dtype=torch.float32,
            leading_physical_blocks=1))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--reference-source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--device', default='npu:0')
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    tree = ast.parse(args.reference_source.read_text())
    definition = next(node for node in tree.body if isinstance(node, ast.ClassDef)
                      and node.name == 'StateGenerationSnapshot')
    namespace = dict(vars(state_tensor))
    exec(compile(ast.Module(body=[definition], type_ignores=[]),
                 str(args.reference_source), 'exec'), namespace)
    reference = namespace['StateGenerationSnapshot']
    torch.npu.set_device(args.device)
    runtime = LiveRuntime(architecture=ASCEND, device=args.device,
                          state_backend=TorchStateBackend(args.device))
    domain = StateDomain(ExactStateCapacity(2048))
    with live_runtime(runtime):
        root = Root(domain)
    root.activate()
    results = []
    try:
        destination = root.state.tensor
        initial = (torch.arange(destination.numel(), dtype=torch.float32) % 127).reshape(destination.shape)
        for label, blocks in [('dense', tuple(range(2048))),
                              ('sparse', (0, 1, 1024, 1025)),
                              ('unsorted', (1024, 0, 1, 1024)), ('prefix', ())]:
            for implementation, cls in [('reference', reference),
                                        ('coalesced', state_tensor.StateGenerationSnapshot)]:
                destination.copy_(initial)
                torch.npu.synchronize()
                before = torch.npu.memory_allocated()
                torch.npu.reset_peak_memory_stats()
                started = time.perf_counter()
                snapshot = cls((root.state,), domain_blocks={domain: blocks})
                snapshot_s = time.perf_counter()-started
                assert all(image.device.type == 'cpu'
                           for _, _, spans in snapshot._entries for _, _, image in spans)
                destination.fill_(-7)
                torch.npu.synchronize()
                started = time.perf_counter()
                snapshot.restore()
                torch.npu.synchronize()
                restore_s = time.perf_counter()-started
                growth = torch.npu.max_memory_allocated()-before
                assert growth <= 0, ('unexpected device image/workspace', growth)
                expected = torch.full_like(initial, -7)
                expected[0] = initial[0]
                for block in blocks:
                    expected[block+1] = initial[block+1]
                torch.testing.assert_close(destination.cpu(), expected, rtol=0, atol=0)
                assert root.state.tensor is destination
                results.append(dict(case=label, implementation=implementation,
                                    spans=sum(len(spans) for _, _, spans in snapshot._entries),
                                    snapshot_s=snapshot_s, restore_s=restore_s,
                                    peak_device_growth_bytes=growth, status='PASS'))
                snapshot.release()
                print(results[-1], flush=True)
    finally:
        root.close()
    payload = dict(scope='Bounded startup transfer probe, not whole-model performance',
                   reference_sha256=hashlib.sha256(args.reference_source.read_bytes()).hexdigest(),
                   candidate_sha256=hashlib.sha256(Path(state_tensor.__file__).read_bytes()).hexdigest(),
                   records=results)
    args.output.write_text(json.dumps(payload, indent=2)+'\n')


if __name__ == '__main__':
    main()
