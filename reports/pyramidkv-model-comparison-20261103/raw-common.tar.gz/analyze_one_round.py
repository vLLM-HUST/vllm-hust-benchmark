"""Apply the user's recorded one-round amendment to the frozen raw verifier."""
import json
import analyze_verified as analyze
ROOT=analyze.ROOT

def main():
 contract=json.loads((ROOT/'contract.json').read_text())
 amendment=json.loads((ROOT/'single-round-amendment.json').read_text())
 assert analyze.digest(ROOT/'single-round-amendment.json')==(ROOT/'single-round-amendment.sha256').read_text().strip()
 assert amendment['selected_lifecycles']==contract['lifecycles'][:4]
 for relative,sha in contract['files_sha256'].items():assert analyze.digest(ROOT/relative)==sha,relative
 requests=json.loads((ROOT/'requests.json').read_text())
 runs=[analyze.verify_run(row,requests) for row in amendment['selected_lifecycles']]
 selected={row['name'] for row in amendment['selected_lifecycles']}
 extras=[]
 for path in (ROOT/'runs').iterdir():
  if path.name in selected:continue
  assert path.name=='qwen35-off-2' and not (path/'ready.json').exists() and not (path/'evaluation').exists()
  assert (path/'npu-after.txt').read_text().count('No running processes found')==2
  extras.append({'name':path.name,'disposition':'User-canceled startup outside amended scope; no readiness or measured requests','failure':json.loads((path/'failure.json').read_text())})
 models={}
 for model in ('qwen25','qwen35'):
  arms={}
  for arm in ('off','on'):
   rows=[r['groups']['long'] for r in runs if r['model']==model and r['enabled']==(arm=='on')];assert len(rows)==1
   arms[arm]=rows[0]
  changes={key:100*(arms['on'][key]/arms['off'][key]-1) if arms['off'][key] else None for key in arms['off'] if isinstance(arms['off'][key],(int,float))}
  models[model]={'long_aggregates':arms,'long_percent_change':changes,'observations_per_arm':1}
 result={'contract_sha256':analyze.digest(ROOT/'contract.json'),'amendment_sha256':analyze.digest(ROOT/'single-round-amendment.json'),'runs':runs,'models':models,'verified_measured_requests':320,'verified_readiness_requests':8,'excluded_unmeasured_startups':extras,'verification':'Original frozen raw verifier applied to the user-amended four lifecycles. Every measured/readiness payload, usage and SSE stream recomputed; exactly two rank acknowledgements per long commit; native pool configuration; zero active requests and both devices free. No repeatability estimate from a single round.'}
 (ROOT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(models,indent=2))
if __name__=='__main__':main()
