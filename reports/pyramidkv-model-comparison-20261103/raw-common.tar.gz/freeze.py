"""Freeze only after preflight/review; refuses to overwrite a formal contract."""
import hashlib,json,pathlib,shutil,subprocess,time,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/tmp/pyramidkv-qwen25-retest/source')
PREVIOUS=pathlib.Path('/root/.cache/pyramidkv-qwen25-20261103')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert not (ROOT/'contract.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
for name in ('serve.sh','pyramidkv.json','audit.py'):shutil.copyfile(SOURCE/'scripts/model-comparison'/name,ROOT/name)
shutil.copyfile(SOURCE/'scripts/qwen25/measure.py',ROOT/'measure.py')
(ROOT/'candidate-source.patch').write_bytes(subprocess.check_output(['git','diff','12c235b76ab771449048ace86961eb2b6786bf1b',head],cwd=SOURCE))
wheel=next((ROOT/'wheels').glob('*.whl'));overlay=ROOT/'candidate-overlay';overlay.mkdir()
with zipfile.ZipFile(wheel) as z:z.extractall(overlay)
for file in (SOURCE/'src/vllm_ascend_pyramidkv').rglob('*'):
 if file.is_file() and file.suffix not in ('.pyc',) and '__pycache__' not in file.parts:
  assert file.read_bytes()==(overlay/file.relative_to(SOURCE/'src')).read_bytes(),str(file)
(ROOT/'launch.sh').write_text('''set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export ASCEND_RT_VISIBLE_DEVICES=0,1
export PYTHONPATH=/root/.cache/pyramidkv-model-compare-20261103/candidate-overlay:$PYTHONPATH
export SERVE_PORT=8016
export PYRAMIDKV_CONFIG=/root/.cache/pyramidkv-model-compare-20261103/pyramidkv.json
unset VLLMHUST_EXT_ENABLED_BUNDLES VLLM_EXTENSION_MANIFESTS VLLM_EXTENSION_BUNDLES VLLM_ASCEND_KVCOMPRESS_ENABLED VLLM_ASCEND_KVCOMPRESS_CONFIG VLLM_ASCEND_PYRAMIDKV_EXPERIMENTAL_MTP2 VLLM_ASCEND_PYRAMIDKV_BATCHED_METADATA
python -c 'import vllm_ascend_pyramidkv as p; assert p.__file__.startswith("/root/.cache/pyramidkv-model-compare-20261103/candidate-overlay/"); assert p.__version__=="0.4.0rc2.dev0"; print("Candidate:",p.__file__,p.__version__,flush=True)'
exec bash /root/.cache/pyramidkv-model-compare-20261103/serve.sh
''')
host={}
for name in ('vllm','vllm-ascend'):
 path=pathlib.Path('/root/workspace/pyramidkv-runtime/src')/name
 host[name]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True)}
 assert not host[name]['status']
write(ROOT/'host-source-identity.json',host)
shutil.copyfile(PREVIOUS/'runtime-versions.json',ROOT/'runtime-versions.json')
models={'qwen25':{'path':'/data/shared_models/Qwen2.5-14B-Instruct','name':'Qwen/Qwen2.5-14B-Instruct'},'qwen35':{'path':'/root/workspace/Qwen3.5-35B-A3B','name':'Qwen/Qwen3.5-35B-A3B'}}
model_stats={}
for key,model in models.items():
 receipt=json.loads((ROOT/(key+'-model-identity.json')).read_text());files=receipt.get('files',receipt)
 for name,record in files.items():
  file=pathlib.Path(model['path'])/name;stat=file.stat();expected=[record['bytes'],record['mtime_ns']]
  assert [stat.st_size,stat.st_mtime_ns]==expected,str(file)
  model_stats[str(file)]=expected
files=['preflight-summary-final.json','launch.sh','serve.sh','pyramidkv.json','measure.py','audit.py','run_series.py','analyze.py','prepare_common.py','requests.json','common-words.json','qwen25-model-identity.json','qwen35-model-identity.json','candidate-source.patch','host-source-identity.json','runtime-versions.json','batch-budget-amendment.json','freeze.py']
files += [str(p.relative_to(ROOT)) for p in overlay.rglob('*') if p.is_file()]
files.append(str(wheel.relative_to(ROOT)))
lifecycles=[]
for round in (1,2,3):
 for model in (('qwen35','qwen25') if round==2 else ('qwen25','qwen35')):
  for enabled in (False,True):lifecycles.append({'name':f'{model}-'+('on' if enabled else 'off')+f'-{round}','model':model,'enabled':enabled})
contract={'schema_version':1,'created_at':time.time(),'candidate_source_commit':head,'candidate_label':'0.4.0rc2.dev0 source/wheel candidate, not published0.4.0rc1','core_commit':host['vllm']['head'],'ascend_commit':host['vllm-ascend']['head'],'runtime_choice':'Same current CANN9.1/Torch2.10 in all arms, explicitly user-approved','models':models,'physical_devices':[1,6],'visible_ordinals':[0,1],'files_sha256':{f:sha(ROOT/f) for f in files},'host_files_sha256':{'/root/workspace/pyramidkv-runtime/env.sh':sha(pathlib.Path('/root/workspace/pyramidkv-runtime/env.sh'))},'model_stats':model_stats,'lifecycles':lifecycles,'measured_requests_per_lifecycle':80,'readiness_requests_per_lifecycle':2,'startup_timeout_seconds':1200,'request_timeout_seconds':600,'client_timeout_seconds':3600,'controller_grace_seconds':30,'startup_memory_guard':'If cgroup memory exceeds48GiB, POSIX_FADV_DONTNEED only current model shard files during startup; no eviction during inference; all events retained','shared_settings':{'tp':2,'dtype':'bfloat16','enforce_eager':True,'speculative_config':None,'max_model_len':8192,'max_num_seqs':32,'max_num_batched_tokens':4096,'gpu_memory_utilization':0.8,'requested_block_size':128,'seed':0,'prefix_caching':True,'chunked_prefill':True,'async_scheduling':True,'generation_config':'vllm','long_input_tokens':7168,'long_output_tokens':512,'long_concurrency':32},'stop_rule':'Stop at first startup/request failure, retain all evidence, no selective retries or tuning after results','aggregation':'Arithmetic means of three lifecycle metrics per model/arm; ratios of arm means; expose every run','limitations':['Common literal synthetic prompts differ from historical TP1 random-token prompts; batch budget4096 also differs from TP1 2048, so this is not a TP-only comparison','Model change includes size, MoE, hybrid cache layout and weight footprint, not isolated architecture causality','Automatic pool capacities retained; no artificial shrinking to induce pressure','SSE/events and completed-request file writes, metrics sampling~0.2s and HBM~2s add common instrumentation overhead','Synthetic performance does not establish task-quality parity','Full model SHA256 receipts reused only after unchanged sizes/nanosecond mtimes verified; source receipt preserved']}
write(ROOT/'contract.json',contract);print('FROZEN',head,sha(ROOT/'contract.json'),len(lifecycles))
