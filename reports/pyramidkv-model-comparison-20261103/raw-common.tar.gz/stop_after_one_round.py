"""Honor the user's one-round amendment without interrupting the current pair."""
import json,os,pathlib,signal,time
ROOT=pathlib.Path(__file__).resolve().parent
controller=348089
start_ticks=pathlib.Path(f'/proc/{controller}/stat').read_text().split()[21]
contract=json.loads((ROOT/'contract.json').read_text())
amendment={'at':time.time(),'reason':'User explicitly requested only one OFF/ON round per model; no repetitions.','original_contract':'contract.json','selected_lifecycles':contract['lifecycles'][:4],'measured_requests':320,'readiness_requests':8,'aggregation':'One observed lifecycle per model/arm; no repeatability estimate','controller_pid':controller,'controller_start_ticks':start_ticks,'control':'Allow first four lifecycles to complete; stop original controller at the first out-of-scope startup before it can become ready or issue any requests. Preserve any canceled startup receipt.'}
(ROOT/'single-round-amendment.json').write_text(json.dumps(amendment,indent=2)+'\n')
completed=ROOT/'runs/qwen35-on-1/completion.json'
while not completed.exists():
 if not pathlib.Path(f'/proc/{controller}').exists():raise RuntimeError('Controller stopped before selected round completed')
 time.sleep(1)
next_run=ROOT/'runs/qwen35-off-2'
while not (next_run/'process.json').exists():
 if not pathlib.Path(f'/proc/{controller}').exists():raise RuntimeError('Controller exited at boundary; inspect cleanup')
 time.sleep(0.02)
assert not (next_run/'ready.json').exists() and not (next_run/'evaluation').exists()
assert pathlib.Path(f'/proc/{controller}/stat').read_text().split()[21]==start_ticks
os.kill(controller,signal.SIGTERM)
(ROOT/'single-round-stop.json').write_text(json.dumps({'at':time.time(),'controller_pid':controller,'canceled_unmeasured_startup':'qwen35-off-2','ready':False,'evaluation_exists':False},indent=2)+'\n')
print('Stopped after four requested lifecycles, before any repeated measurement',flush=True)
