import unittest
from log_boundary import check_errors
KNOWN='INFO [shutdown] MPClient: complete\nserver ERROR 11-03 06:00:00 [async_llm.py:704] AsyncLLM output_handler failed.\nserver ERROR 11-03 06:00:00 [async_llm.py:704] EngineDeadError: engine stopped\n'
class TestBoundary(unittest.TestCase):
 def test_expected_post_shutdown_handler(self):self.assertEqual(check_errors(KNOWN),2)
 def test_serving_failure_cannot_be_hidden(self):
  with self.assertRaises(ValueError):check_errors('worker ERROR 11-03 05:00:00 inference failed\n'+KNOWN)
 def test_other_shutdown_failure_is_rejected(self):
  with self.assertRaises(ValueError):check_errors(KNOWN+'worker ERROR 11-03 06:00:00 [worker.py:1] failed\n')
if __name__=='__main__':unittest.main()
