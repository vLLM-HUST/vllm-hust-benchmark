import urllib.request,json,pathlib,time,sys
root=pathlib.Path(__file__).resolve().parent;out=root/sys.argv[1];client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
for row in json.loads((root/'boundary-requests.json').read_text()):
 n=row['input_tokens'];payload=row['payload'];(out/f'request-{n}.json').write_text(json.dumps(payload,ensure_ascii=False));t=time.monotonic()
 req=urllib.request.Request('http://127.0.0.1:8016/v1/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Request-Id':row['id']})
 try:raw=client.open(req,timeout=600).read()
 except urllib.error.HTTPError as e:(out/f'failure-{n}.txt').write_bytes(e.read());raise
 (out/f'response-{n}.json').write_bytes(raw);usage=json.loads(raw)['usage'];assert usage['prompt_tokens']==n and usage['completion_tokens']==32;print(n,time.monotonic()-t,usage,flush=True)
