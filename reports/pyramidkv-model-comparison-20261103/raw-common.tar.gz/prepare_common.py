import hashlib,json,pathlib,random
from transformers import AutoTokenizer
import numpy as np
root=pathlib.Path(__file__).resolve().parent
paths=['/data/shared_models/Qwen2.5-14B-Instruct','/root/workspace/Qwen3.5-35B-A3B']
toks=[AutoTokenizer.from_pretrained(p,local_files_only=True) for p in paths]
common=set(toks[0].get_vocab())&set(toks[1].get_vocab())
words=sorted(s for s in common if s.startswith('Ġ') and 3<=len(s[1:])<=12 and s[1:].isascii() and s[1:].islower() and s[1:].isalpha())
words=[' '+w[1:] for w in words if all(len(t.encode(' '+w[1:],add_special_tokens=False))==1 for t in toks)]
assert len(words)>1000,len(words)
print('common single-token words',len(words),flush=True)
result={}
for kind,count,isl,osl in [('short',48,1024,256),('long',32,7168,512)]:
 rng=np.random.default_rng(0);arrivals=np.cumsum(np.random.RandomState(0).gamma(1,1,count)) if kind=='short' else np.zeros(count)
 if kind=='short':arrivals*=count/arrivals[-1]
 rows=[]
 for i in range(count):
  text=''.join(words[k] for k in rng.integers(0,len(words),isl));ids=[t.encode(text,add_special_tokens=False) for t in toks];assert all(len(x)==isl for x in ids),(i,[len(x) for x in ids])
  payload={'model':'pyramidkv-model-comparison','prompt':text,'repetition_penalty':1.0,'max_tokens':osl,'logprobs':None,'stream':True,'stream_options':{'include_usage':True},'ignore_eos':True}
  rows.append({'id':f'{kind}-{i:02d}','input_tokens':isl,'token_ids_sha256_by_model':{name:hashlib.sha256(json.dumps(x).encode()).hexdigest() for name,x in zip(('qwen25','qwen35'),ids)},'delay_seconds':float(arrivals[i]),'payload':payload})
 result[kind]=rows
(root/'common-words.json').write_text(json.dumps(words,ensure_ascii=False)+'\n')
(root/'requests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('requests', {k:len(v) for k,v in result.items()},hashlib.sha256((root/'requests.json').read_bytes()).hexdigest())
