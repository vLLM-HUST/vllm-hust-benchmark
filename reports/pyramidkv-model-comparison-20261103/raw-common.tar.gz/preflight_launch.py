import json,os,pathlib,subprocess,sys,time,urllib.request,signal
ROOT=pathlib.Path(__file__).resolve().parent
name,model,enabled=sys.argv[1:];out=ROOT/name;out.mkdir()
model_path='/root/workspace/Qwen3.5-35B-A3B' if model=='qwen35' else '/data/shared_models/Qwen2.5-14B-Instruct'
script=(ROOT/'preflight-qwen35-on-1/serve.sh').read_text().replace('/root/workspace/Qwen3.5-35B-A3B',model_path).replace('PYRAMIDKV_ENABLED=1','PYRAMIDKV_ENABLED='+enabled)
(out/'serve.sh').write_text(script)
source=pathlib.Path('/tmp/pyramidkv-qwen25-retest/source')
(out/'source-head.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD'],cwd=source))
(out/'source-working.patch').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=source))
(out/'common-launcher.sh').write_bytes((source/'scripts/model-comparison/serve.sh').read_bytes())
for _ in range(30):
 if subprocess.check_output(['npu-smi','info'],text=True).count('No running processes found')==2:break
 time.sleep(1)
else:raise RuntimeError('devices remain occupied')
log=(out/'server.log').open('wb');p=subprocess.Popen(['bash',str(out/'serve.sh')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/'process.json').write_text(json.dumps({'pid':p.pid,'start_ticks':pathlib.Path(f'/proc/{p.pid}/stat').read_text().split()[21]}));print('START',name,p.pid,flush=True)
client=urllib.request.build_opener(urllib.request.ProxyHandler({}));events=[];start=time.monotonic()
try:
 while time.monotonic()-start<1200:
  if p.poll() is not None:raise RuntimeError(f'startup exited {p.returncode}')
  try:
   if client.open('http://127.0.0.1:8016/health',timeout=1).status==200:break
  except OSError:pass
  m=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
  if m>48*2**30:
   for file in pathlib.Path(model_path).glob('*.safetensors'):
    fd=os.open(file,os.O_RDONLY)
    try:os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
    finally:os.close(fd)
   events.append({'at':time.time(),'memory_before':m});(out/'startup-cache-events.json').write_text(json.dumps(events,indent=2))
  time.sleep(2)
 else:raise RuntimeError('startup timeout')
 (out/'ready.json').write_text(json.dumps({'at':time.time(),'pid':p.pid}));print('READY',name,flush=True)
except BaseException:
 os.killpg(p.pid,signal.SIGTERM);raise
