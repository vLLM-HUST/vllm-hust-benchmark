import json,os,pathlib,signal,subprocess,time,urllib.request
ROOT=pathlib.Path(__file__).resolve().parent;PY='/root/workspace/pyramidkv-runtime/venv/bin/python';SOURCE=pathlib.Path('/tmp/pyramidkv-qwen25-retest/source');CLIENT=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def finish(name):
 out=ROOT/name;p=json.loads((out/'process.json').read_text());pid=p['pid']
 try:
  start=time.monotonic()
  while not (out/'ready.json').exists():
   if time.monotonic()-start>1200:raise RuntimeError('Readiness deadline')
   if not pathlib.Path(f'/proc/{pid}').exists():raise RuntimeError('Service exited before ready')
   time.sleep(2)
  with (out/'boundary.log').open('wb') as log:subprocess.run([PY,str(ROOT/'preflight_requests.py'),name],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2500)
  with (out/'concurrent.log').open('wb') as log:subprocess.run([PY,str(SOURCE/'scripts/qwen25/measure.py'),'--requests',str(ROOT/'preflight-requests.json'),'--output',str(out/'concurrent'),'--base','http://127.0.0.1:8016','--kinds','long'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1000)
  (out/'final-metrics.prom').write_bytes(CLIENT.open('http://127.0.0.1:8016/metrics',timeout=10).read())
  print('PASS',name,(out/'concurrent.log').read_text(),flush=True)
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e)}));raise
 finally:
  if pathlib.Path(f'/proc/{pid}/stat').exists():
   assert pathlib.Path(f'/proc/{pid}/stat').read_text().split()[21]==p['start_ticks']
   os.killpg(pid,signal.SIGTERM)
  for _ in range(40):
   state=subprocess.check_output(['npu-smi','info'],text=True)
   if state.count('No running processes found')==2:break
   time.sleep(1)
  else:raise RuntimeError('Devices remain occupied')
  (out/'shutdown.txt').write_text(state)

for name,enabled in [('preflight-qwen25-off-4096-2','0'),('preflight-qwen25-on-4096','1')]:
 subprocess.run([PY,str(ROOT/'preflight_launch.py'),name,'qwen25',enabled],check=True)
 finish(name)
