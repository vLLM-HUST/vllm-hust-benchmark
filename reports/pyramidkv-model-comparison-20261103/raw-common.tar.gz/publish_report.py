"""Package completed originals into bounded public archives; never used in timing."""
import gzip,hashlib,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPORT=Path('/tmp/pyramidkv-delivery/benchmark/reports/pyramidkv-model-comparison-20261103')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def number(value):return f'{value:,.2f}'
def main():
 a=json.loads((ROOT/'analysis.json').read_text());c=json.loads((ROOT/'contract.json').read_text())
 assert a['verified_measured_requests']==320 and a['verified_readiness_requests']==8
 assert a['contract_sha256']==sha(ROOT/'contract.json')
 REPORT.mkdir(parents=True,exist_ok=False)
 shutil.copyfile(ROOT/'analysis.json',REPORT/'analysis.json')
 metric_rows=[('Output throughput','output_token_throughput','tokens/s'),('TTFT','mean_ttft_ms','ms'),('TPOT','mean_tpot_ms','ms'),('End-to-end','mean_e2e_ms','ms'),('Peak active KV usage','kv_peak_fraction','%'),('Peak simultaneous two-card HBM','hbm_peak_mib_sum','MiB')]
 tables=[]
 for model,title in [('qwen25','Qwen2.5-14B-Instruct'),('qwen35','Qwen3.5-35B-A3B')]:
  m=a['models'][model];g=m['long_aggregates'];table=[f'## {title}','', '| Metric | OFF | ON | Change |','| --- | ---: | ---: | ---: |']
  for label,key,unit in metric_rows:table.append(f'| {label} ({unit}) | {number(g["off"][key]*(100 if key=='kv_peak_fraction' else 1))} | {number(g["on"][key]*(100 if key=='kv_peak_fraction' else 1))} | {m["long_percent_change"][key]:+.2f}% |')
  table+=['','Individual fresh-process runs:','', '| Run | Output tokens/s | TTFT ms | TPOT ms | Peak active KV |','| --- | ---: | ---: | ---: | ---: |']
  for run in a['runs']:
   if run['model']==model:
    x=run['groups']['long'];table.append(f'| {run["name"]} | {number(x["output_token_throughput"])} | {number(x["mean_ttft_ms"])} | {number(x["mean_tpot_ms"])} | {x["kv_peak_fraction"]:.6f} |')
  table+=['','Native cache configuration by arm:','']
  for enabled in (False,True):
   runs=[r for r in a['runs'] if r['model']==model and r['enabled']==enabled]
   pools={json.dumps(r['kv_pool'],sort_keys=True) for r in runs}
   budgets=sorted({r['kv_pool_available_gib_rank0_log_rounded'] for r in runs})
   pool=runs[0]['kv_pool'];table.append(f'- {"ON" if enabled else "OFF"}: {pool["physical_blocks"]} native blocks, logical block size {pool["logical_block_size"]}; effective context capacity {pool["effective_capacity_tokens"]} tokens; rank0 available KV budget {budgets} GiB (rounded host log).')
  tables.append('\n'.join(table))
 totals={r['name']:r['lifecycle_preemptions_total'] for r in a['runs']}
 readme=f'''# PyramidKV model comparison: shared TP2 eager profile

**Diagnostic Eager measurements, excluded from official performance leaderboards.**
This report compares the effect of enabling the independent PyramidKV candidate
within each model, then compares those changes between models. It does not
isolate architecture from parameter count, MoE, weight footprint or cache layout,
and it does not establish task-quality parity.

Candidate source: [`{c['candidate_source_commit']}`](https://github.com/vLLM-HUST/vllm-ascend-pyramidkv-hust/tree/{c['candidate_source_commit']}).
Measured wheel: `0.4.0rc2.dev0`; this is not the published `0.4.0rc1` wheel.
The preceding [Qwen2.5 TP1 reproduction](../pyramidkv-qwen25-matched-20261103/)
used a different prompt bank and 2048 batch budget; absolute differences against
that run must not be called a TP-only effect.

## Frozen comparison

Both models use the same two physical Ascend910B2 cards1/6 (visible0/1), BF16,
TP2, Eager/NONE, no MTP, APC/async/chunked prefill, seed0, context8192,
32 maximum sequences, 4096 batch-token budget, automatic utilization0.8,
text-only requests and `generation-config=vllm`. Qwen3.5 alone requires Mamba
`align`; dense Qwen2.5 has no Mamba state. Requested kernel pages are128 tokens;
Qwen3.5 retains native2048-token logical cache alignment.

The runtime is the user-approved current CANN9.1, Torch2.10.0+cpu,
torch-npu2.10.0.post4, transformers5.14.1. Installed metadata says vLLM0.23.0+empty
and Ascend0.23.0.post1; `VLLM_VERSION=0.25.1` selects the prepared ABI branch.
Pinned core `{c['core_commit']}` and Ascend `{c['ascend_commit']}`
are preserved in the capsule. Both arms use the same explicit host worker.

Compression remains512/beta20/window8/kernel7/maxpool, KV-head/mean GQA, no merge,
and admission above4096 prompt tokens. At7168, dense materialization allocates
1024 physical tokens (8 private pages), while hybrid alignment allocates2048
(1 logical page). Layer-specific retained lengths remain distinct.

All four arms receive identical literal synthetic English-word prompts. Whole
prompts were verified to encode to exactly1024 or7168 tokens under both local
tokenizers before freezing. Requests SHA256: `{c['files_sha256']['requests.json']}`.
Each fresh lifecycle has48 short1024/256 requests at rate1, followed by32
long7168/512 requests at rate infinity/concurrency32. One separate first-prompt
readiness request precedes each cohort; no additional warmups. `ignore_eos=true`
forces exact output length. All320 measured requests and8 readiness requests
are independently verified from raw SSE and timestamped events.

The original contract planned three pairs per model. While the first round was
running, the user explicitly requested only one pair per model. The original
contract remains intact; `single-round-amendment.json` records the four selected
lifecycles. These are single observations, with change calculated directly from
OFF and ON metrics; no run-to-run variance estimate is available. No model,
request or runtime parameters were changed, and no selective retry occurred.
The native pool was not shrunk to manufacture pressure. Startup-only file-cache
eviction events are retained; no eviction occurs during measured requests.

{chr(10).join(tables)}

## Interpretation and metric boundaries

In this single round, enabling PyramidKV reduced active KV occupancy for both
models but reduced output throughput: Qwen2.5 by17.25%, Qwen3.5 by3.68%.
Both OFF arms had zero lifecycle preemptions and substantial free pool capacity.
Unlike the earlier TP1 run, this workload therefore offered no preemption to
remove. Lower occupancy did not compensate for the enabled path's total cost.
This identifies the observed tradeoff, not a profiling attribution to a specific
kernel. A single round cannot establish the repeatability of these differences.

The models differ in more than name: Qwen2.5 has48 full-attention layers;
Qwen3.5 has10 full-attention layers plus30 linear-attention layers. PyramidKV
materializes the full-attention KV, while native linear state remains present.
Hybrid logical alignment also raises the physical allocation floor. These
properties explain why the same nominal algorithm budget does not mean the same
fraction of whole-model cache can be reclaimed.

KV usage is active block occupancy inside a preallocated pool. Lower occupancy
does not imply a matching reduction in device HBM. HBM is sampled on both cards;
the sum peak is the maximum simultaneous sampled sum, not the sum of independent
per-card maxima. Native `num_gpu_blocks` is recorded directly. Hybrid reported
context-token capacity is an effective capacity and cannot be divided by logical
block size to recover physical block count.

TTFT ends at the first streamed choice event, including an empty choice; E2E
ends at the last choice, excluding usage/DONE bookkeeping. TPOT divides the
interval after the first choice by output tokens minus one. Cohort throughput
uses actual completed output tokens divided by cohort wall time. Per-process
mean/p50/p95 and all request-level data are preserved.

Metrics are sampled about every0.2s, HBM about every2s. Peaks can miss events
between samples. `sampled_preemptions_lower_bound` may omit the unsampled tail
of a cohort; it is not an exact cohort total. Exact final counters for each fresh
lifecycle, including readiness and both cohorts, are `{totals}`. Synchronous
completed-request artifact writes are common instrumentation overhead.

Both TP ranks acknowledge every admitted long-request scheduler commit; ON has
33 such transactions per lifecycle (readiness plus32 measured long requests).
Every lifecycle ends with zero active/waiting requests and both devices free.
The full ledger includes unsuccessful preflights: initial text-only setup,
2048-budget hybrid serialization, and an inapplicable Mamba flag on dense Qwen2.
Those were corrected before the frozen formal series; no failed formal run was
silently discarded. One out-of-scope startup was canceled after the fourth
lifecycle, before readiness or requests; its stop receipt and cleanup logs are
also preserved. The complete preflight summaries and logs are preserved.
All four services emitted the same native `AsyncLLM output_handler`/`EngineDeadError`
trace only after explicit shutdown and engine-manager completion. The original
frozen analyzer rejected these teardown messages. Its unchanged source is retained;
`analyze_verified.py` changes only that error-boundary check, with negative tests
that still reject serving errors and other shutdown errors. Raw requests, timing,
metric formulas, transaction checks and original logs remain unchanged.

## Originals and offline verification

`raw-common.tar.gz` contains frozen inputs, package/source identities, controller,
analysis, preflights and validation receipts. Each `raw-<lifecycle>.tar.gz`
contains that lifecycle's service, streaming, metrics and shutdown originals.
`members.json.gz` hashes every member; `SHA256SUMS` hashes all public files.
Model weights are referenced by hashes/stat pins and are not duplicated here.

Run with Python3.12 or newer, CPU only, no model/runtime installation:

```sh
python verify.py
```

The verifier checks outer and member hashes, safely extracts the complete
capsule, recomputes every measured/readiness request and aggregate, validates
rank commits/pools/cleanup, and byte-compares the resulting analysis. Public
GitHub download/readback is checked after upload. Full model hash receipts were
reused only after matching current file sizes and nanosecond mtimes; that reuse
is explicitly recorded in model identity files.
'''
 (REPORT/'README.md').write_text(readme)
 members={}
 def archive(name,paths):
  with tarfile.open(REPORT/name,'w:gz',compresslevel=6) as tar:
   for p in sorted(paths):
    relative=str(p.relative_to(ROOT));assert relative not in members
    members[relative]={'bytes':p.stat().st_size,'sha256':sha(p),'archive':name}
    info=tar.gettarinfo(str(p),arcname=relative);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
    with p.open('rb') as stream:tar.addfile(info,stream)
  assert (REPORT/name).stat().st_size<50*2**20,name
 common=[]
 for p in ROOT.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(ROOT)
  if len(rel.parts)>1 and not (rel.parts[0].startswith('preflight-') or rel.parts[0] in ('candidate-overlay','wheels')):continue
  if rel.parts[0] in ('lifecycle.lock',):continue
  common.append(p)
 archive('raw-common.tar.gz',common)
 for run in sorted((ROOT/'runs').iterdir()):
  archive('raw-'+run.name+'.tar.gz',[p for p in run.rglob('*') if p.is_file()])
 (REPORT/'members.json.gz').write_bytes(gzip.compress(json.dumps(members,sort_keys=True,indent=2).encode(),mtime=0))
 shutil.copyfile(ROOT/'verify_public.py',REPORT/'verify.py')
 (REPORT/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(REPORT.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
 print(REPORT,len(members),sum(p.stat().st_size for p in REPORT.iterdir()))
if __name__=='__main__':main()
