"""Offline raw-stream recomputation of the frozen two-model, two-rank series."""
import hashlib,json,re,statistics
from pathlib import Path
import measure,audit
ROOT=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def value(row,key):
 vals=[v for k,v in row.get('metrics',{}).items() if k.split('{')[0]=='vllm:'+key]
 if len(vals)!=1:raise ValueError(('Missing/ambiguous metric',key,vals))
 return vals[0]
def verify_request(folder,expected,stored):
 artifact=json.loads((folder/(expected['id']+'.events.json')).read_text());assert artifact['request']==expected
 raw=(folder/(expected['id']+'.sse')).read_bytes();data=[]
 for line in raw.splitlines():
  if line.startswith(b'data: '):
   payload=line[6:].strip();data.append('[DONE]' if payload==b'[DONE]' else json.loads(payload))
 assert data==[e['data'] for e in artifact['events']]
 computed=measure.request_metrics(artifact['events'],artifact['start'],expected['input_tokens'],expected['payload']['max_tokens'])
 assert stored['success'] and stored['id']==expected['id']
 assert json.loads((folder/(expected['id']+'.result.json')).read_text())==stored
 for key,val in computed.items():assert stored[key]==val,(expected['id'],key)
 return computed

def verify_run(row,requests):
 name,model,enabled=row['name'],row['model'],row['enabled'];out=ROOT/'runs'/name
 assert not (out/'failure.json').exists()
 completion=json.loads((out/'completion.json').read_text());assert completion['measured_requests']==80 and completion['readiness_requests']==2
 process=json.loads((out/'process.json').read_text());assert process['contract_sha256']==digest(ROOT/'contract.json')
 assert process['model']==model and process['enabled']==enabled
 telemetry=[json.loads(x) for x in (out/'evaluation/telemetry.jsonl').read_text().splitlines()]
 summaries=json.loads((out/'evaluation/summary.json').read_text())
 identity=json.loads((out/'evaluation/identity.json').read_text())
 assert identity['requests_sha256']==digest(ROOT/'requests.json') and identity['client_sha256']==digest(ROOT/'measure.py')
 log=(out/'server.log').read_text()
 assert ('PyramidKV plugin activated' in log)==enabled
 assert 'tensor_parallel_size=2' in log and 'enforce_eager=True' in log and 'speculative_config=None' in log
 assert not re.search(r'ERROR.*(?:fatal|Traceback|failed)',log)
 tokens=int(re.search(r'GPU KV cache size: ([\d,]+) tokens',log).group(1).replace(',',''))
 pool_gib=float(re.search(r'Available KV cache memory: ([\d.]+) GiB',log).group(1))
 expected_ids=['long-readiness']+[r['id'] for r in requests['long']] if enabled else []
 count=audit.transactions(log,model,expected_ids)
 pool=audit.pool((out/'final-metrics.prom').read_text());assert pool['effective_capacity_tokens']==tokens
 result={'name':name,'model':model,'enabled':enabled,'kv_pool':pool,'kv_pool_available_gib_rank0_log_rounded':pool_gib,'transactions':count,'worker_acknowledgements':count*2,'groups':{}}
 for kind in ('short','long'):
  folder=out/'evaluation'/kind;g=json.loads((folder/'group.json').read_text());rows=[]
  assert len(g['results'])==len(requests[kind])
  readiness=dict(requests[kind][0],id=kind+'-readiness')
  verify_request(folder,readiness,json.loads((folder/(readiness['id']+'.result.json')).read_text()))
  for expected,stored in zip(requests[kind],g['results']):rows.append(verify_request(folder,expected,stored))
  computed=measure.group_metrics(rows,g['end']-g['start']);original=next(x for x in summaries if x['kind']==kind)
  for k,v in computed.items():assert original[k]==v,(name,kind,k)
  samples=[x for x in telemetry if g['start']<=x['t']<=g['end'] and 'metrics' in x];assert samples
  prior=[x for x in telemetry if x['t']<g['start'] and 'metrics' in x];assert prior
  computed['kv_peak_fraction']=max(value(x,'kv_cache_usage_perc') for x in samples)
  computed['sampled_preemptions_lower_bound']=max(value(x,'num_preemptions_total') for x in samples)-value(prior[-1],'num_preemptions_total')
  memory=[audit.hbm(x['npu_smi']) for x in samples if 'npu_smi' in x];assert memory
  for card in ('1','6'):computed['hbm_peak_mib_card'+card]=max(m[card] for m in memory)
  computed['hbm_peak_mib_sum']=max(sum(m.values()) for m in memory)
  computed['peak_running']=max(value(x,'num_requests_running') for x in samples)
  computed['peak_waiting']=max(value(x,'num_requests_waiting') for x in samples)
  computed['telemetry_samples']=len(samples);computed['hbm_samples']=len(memory)
  result['groups'][kind]=computed
 final={'metrics':measure.metric_values((out/'final-metrics.prom').read_text())}
 result['lifecycle_preemptions_total']=value(final,'num_preemptions_total')
 assert value(final,'num_requests_running')==0 and value(final,'num_requests_waiting')==0
 assert (out/'npu-after.txt').read_text().count('No running processes found')==2
 return result

def main():
 contract=json.loads((ROOT/'contract.json').read_text());requests=json.loads((ROOT/'requests.json').read_text())
 for relative,sha in contract['files_sha256'].items():assert digest(ROOT/relative)==sha,relative
 runs=[verify_run(row,requests) for row in contract['lifecycles']]
 models={}
 for model in ('qwen25','qwen35'):
  aggregates={}
  for arm in ('off','on'):
   rows=[x['groups']['long'] for x in runs if x['model']==model and x['enabled']==(arm=='on')];assert len(rows)==3
   aggregates[arm]={key:statistics.mean(x[key] for x in rows) for key in rows[0] if isinstance(rows[0][key],(int,float))}
  changes={key:100*(aggregates['on'][key]/aggregates['off'][key]-1) if aggregates['off'][key] else None for key in aggregates['off']}
  models[model]={'long_aggregates':aggregates,'long_percent_change':changes}
 result={'contract_sha256':digest(ROOT/'contract.json'),'runs':runs,'models':models,'verified_measured_requests':960,'verified_readiness_requests':24,'verification':'Exact frozen payloads and usage; raw SSE equals timestamped events; every request and cohort recomputed; two explicit TP-rank acknowledgements per scheduler commit; zero final active requests and both physical devices free.'}
 (ROOT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(models,indent=2))
if __name__=='__main__':main()
