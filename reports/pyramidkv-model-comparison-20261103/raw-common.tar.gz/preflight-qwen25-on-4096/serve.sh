set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export ASCEND_RT_VISIBLE_DEVICES=0,1
export PYTHONPATH=/tmp/pyramidkv-qwen25-retest/source/src:$PYTHONPATH
export MODEL_PATH=/data/shared_models/Qwen2.5-14B-Instruct SERVE_PORT=8016 PYRAMIDKV_ENABLED=1
unset VLLMHUST_EXT_ENABLED_BUNDLES VLLM_EXTENSION_MANIFESTS VLLM_EXTENSION_BUNDLES VLLM_ASCEND_KVCOMPRESS_ENABLED VLLM_ASCEND_KVCOMPRESS_CONFIG VLLM_ASCEND_PYRAMIDKV_EXPERIMENTAL_MTP2 VLLM_ASCEND_PYRAMIDKV_BATCHED_METADATA
exec bash /tmp/pyramidkv-qwen25-retest/source/scripts/model-comparison/serve.sh
