"""Read-only acceptance of retained raw streams and high-concurrency coverage."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
run = root / 'runs/qwen35-on-558'
bank = json.loads((root / 'qwen35-requests.json').read_text())
count = 0
for kind, rows in bank.items():
    folder = run / 'evaluation' / kind
    for row in [dict(rows[0], id=kind + '-readiness'), *rows]:
        stem = folder / row['id']
        result = json.loads(stem.with_suffix('.result.json').read_text())
        envelope = json.loads(stem.with_suffix('.events.json').read_text())
        events = envelope['events']
        assert envelope['request'] == row, row['id']
        assert envelope['start'] == result['start']
        raw = stem.with_suffix('.sse').read_text()
        data = []
        for line in raw.splitlines():
            if line.startswith('data: '):
                value = line[6:]
                data.append(value if value == '[DONE]' else json.loads(value))
        assert data == [e['data'] for e in events], row['id']
        assert data[-1] == '[DONE]' and data.count('[DONE]') == 1, row['id']
        assert all(b['t'] >= a['t'] for a, b in zip(events, events[1:])), row['id']
        choices = [e for e in events if isinstance(e['data'], dict) and e['data'].get('choices')]
        usages = [e['data']['usage'] for e in events if isinstance(e['data'], dict) and e['data'].get('usage')]
        assert usages[-1] == result['usage'], row['id']
        assert result['success'] is True and result['id'] == row['id']
        assert result['usage']['prompt_tokens'] == row['input_tokens']
        assert result['usage']['completion_tokens'] == row['payload']['max_tokens']
        assert result['text'] == ''.join(e['data']['choices'][0].get('text') or '' for e in choices)
        assert abs(result['ttft_seconds'] - (choices[0]['t'] - result['start'])) < 1e-9
        assert abs(result['e2e_seconds'] - (choices[-1]['t'] - result['start'])) < 1e-9
        count += 1
telemetry = [json.loads(line) for line in (run / 'evaluation/telemetry.jsonl').read_text().splitlines()]
assert not any('error' in row for row in telemetry)
long = [r for r in telemetry if r['stage'] == 'long']
def activity(row):
    return sum(v for k, v in row['metrics'].items() if k.startswith(('vllm:num_requests_running{', 'vllm:num_requests_waiting{')))
peak = max(activity(row) for row in long)
assert peak == 128, peak
results = json.loads((run / 'evaluation/long/group.json').read_text())['results']
assert max(r['start'] for r in results) < min(r['end'] for r in results)
assert any(activity(r) == 128 and r['t'] < min(x['end'] for x in results) for r in long)
report = dict(raw_streams_verified=count, peak_running_plus_waiting=peak,
              all_admitted_before_first_completed=True, telemetry_errors=0,
              requests_sha256=hashlib.sha256((root/'qwen35-requests.json').read_bytes()).hexdigest())
(root / 'raw-verification.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
