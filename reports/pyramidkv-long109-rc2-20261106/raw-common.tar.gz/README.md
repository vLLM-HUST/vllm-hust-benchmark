# Qwen3.5 long-109 / 0.4.0rc2.dev0 功能验收

状态：通过。源代码提交 `77b5c7fd8817b14c9800f6369bd4db622f53f43e`，分支 `fix/qwen35-long109-rc2`。

修复抢占恢复跨过 prompt 末尾而错过首次压缩的问题。固定 host 的原生逻辑在
6144 个已计算 token、7168 个 prompt token、1 个已生成 token 下会调度 1025；
补丁先按原生逻辑对齐，再截为 1024，在 prompt 边界执行原有压缩。
本轮真机中 long-109 实际命中此路径，并获得 scheduler 提交及 TP0/TP1 确认。

- 原冻结请求库、C128、558 块、TP2 eager/no-MTP；物理设备为 4/6。
- 178 个请求全部成功；目标长请求 128/128 提交，含预检共 129 提交、258 ACK。
- 长请求均为 7168 输入、512 输出；long-109 压缩到 2048。
- 原始 SSE、事件、请求内容、usage 和时间戳已逐一核验。
- 服务端峰值运行加等待为 128，全部请求在首条完成前进入服务端。
- 结束后运行和等待均为 0；服务无 ERROR，正常退出，设备已释放。
- 通用测试 303 通过、5 跳过；跳过项另由 4 个 NPU 测试及 1 个生产插件启动方式下的 host 检查全部补验通过。
- lint、format、wheel/sdist 构建、无运行时依赖的独立安装、Manager 生命周期通过。
- 独立审查发现的日志数值后缀误接受问题已修复，并补充失败→通过回归。

原 127/128 实验和冻结文件保持原样；新验收器对其仍以 long-109 缺失判失败。
历史缺乏逐请求调度轨迹，不能将新轨迹当作旧运行的直接记录。
本轮是候选版本的功能验收，未做 OFF/ON 配对性能或质量评价，也未发布版本。

机器可读结果：[acceptance.json](acceptance.json)。
严格提交验收：[release-audit.json](release-audit.json)。
原始流核验：[raw-verification.json](raw-verification.json)。
完整运行：[runs/qwen35-on-558](runs/qwen35-on-558)。
测试：[pytest-reviewed.log](pytest-reviewed.log)、[npu-tests.log](npu-tests.log)、[host-plugin-bootstrap.log](host-plugin-bootstrap.log)。
最终发行候选产物：[dist-final](dist-final)。
源码差异：[final-source.patch](final-source.patch)。
校验清单：[SHA256SUMS](SHA256SUMS)。
