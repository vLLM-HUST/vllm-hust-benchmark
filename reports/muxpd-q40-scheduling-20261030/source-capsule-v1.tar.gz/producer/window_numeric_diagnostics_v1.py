"""Explicit, bounded sampler observations; never replaces a native sample.

This diagnostic adds cloning, D2H and file-writing overhead. Its timings are
unsuitable for performance comparisons. No hook is installed by importing it.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

TARGET_PROFILE_SHA256 = (
    "8e1d9af5546d8b98f8d578eecbfbc543bd10dcbfea146da1a6201c0c9dd42a43"
)
MAX_CLONE_BYTES = 7946240


def load_target_profile():
    """Bind this experiment's extra selector to exact sidecar and original plan."""
    raw = Path(__file__).with_name("target-capture-profile-v1.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != TARGET_PROFILE_SHA256:
        raise ValueError("Target capture sidecar bytes differ")
    profile = json.loads(raw)
    source = profile["source_plan"]
    plan_path = Path(source["path"])
    if (
        str(plan_path)
        != "/root/workspace/muxpd-quality-layout-20261028/new-loss-probe-v1/plan-v1.json"
    ):
        raise ValueError("Target capture original plan path differs")
    plan_raw = plan_path.read_bytes()
    if hashlib.sha256(plan_raw).hexdigest() != source["sha256"]:
        raise ValueError("Target capture original plan bytes differ")
    plan = json.loads(plan_raw)
    canonical = lambda value: json.dumps(value, sort_keys=True, separators=(",", ":"))
    payload = {key: value for key, value in plan.items() if key != "plan_sha256"}
    if (
        hashlib.sha256(canonical(payload).encode()).hexdigest() != plan["plan_sha256"]
        or source["plan_sha256"] != plan["plan_sha256"]
        or source["quality_plan_semantic_sha256"]
        != plan["quality_plan_semantic_sha256"]
    ):
        raise ValueError("Target capture semantic plan identity differs")
    target = [
        case for case in plan["cases"] if case["case_id"] == plan["target_case_id"]
    ]
    if (
        len(target) != 1
        or plan["target_case_id"] != "mmlu-pro-07338"
        or plan["batch"]["batch_id"] != 7
    ):
        raise ValueError("Target capture original case/batch differs")
    prompt = target[0]["prompt_token_ids"]
    expected = {
        "schema": "muxpd-target-early-logits-profile-v1",
        "source_plan": source,
        "batch_id": 7,
        "target_case_id": "mmlu-pro-07338",
        "target_prompt_sha256": "5d42eef6c9648f1d229e6cb6614fc93ef886342cb709be3af5b9f84a7bc483f1",
        "target_prompt_token_count": 1340,
        "regular_capture_token_indices_one_based": [
            1,
            200,
            201,
            202,
            203,
            204,
            205,
            206,
            207,
            208,
        ],
        "extra_capture_token_indices_one_based": list(range(2, 200)),
        "capture_ranks": [0],
        "allowed_extra_lanes": ["native", "decode"],
        "vocab_size": 248320,
        "max_clone_rows": 8,
        "clone_dtype": "torch.float32",
        "clone_element_size": 4,
        "max_clone_bytes": MAX_CLONE_BYTES,
        "extra_directory": "target-extra-logits",
        "extra_vector_count": 198,
        "extra_vector_payload_bytes": 196669440,
    }
    if (
        profile != expected
        or len(prompt) != 1340
        or token_digest(prompt) != expected["target_prompt_sha256"]
    ):
        raise ValueError("Target capture selector/profile differs")
    return profile, prompt


def clone_receipt_digest(receipt):
    return hashlib.sha256(
        json.dumps(receipt, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def validate_capture_window(values):
    """Explicit one-based output positions; bounded count, not a prefix length."""
    if (
        not isinstance(values, (list, tuple))
        or not 1 <= len(values) <= 128
        or any(type(value) is not int or not 1 <= value <= 8192 for value in values)
        or list(values) != sorted(set(values))
    ):
        raise ValueError(
            "Capture window must be sorted unique integer positions1..8192, at most128"
        )
    return tuple(values)


def token_digest(tokens: list[int]) -> str:
    return hashlib.sha256(
        json.dumps(tokens, separators=(",", ":")).encode()
    ).hexdigest()


def schedule_snapshot(output: Any) -> dict[str, Any]:
    cached = output.scheduled_cached_reqs
    return {
        "num_scheduled_tokens": dict(output.num_scheduled_tokens),
        "total_num_scheduled_tokens": output.total_num_scheduled_tokens,
        "new_request_ids": [r.req_id for r in output.scheduled_new_reqs],
        "cached_request_ids": list(cached.req_ids),
        "cached_num_computed_tokens": list(cached.num_computed_tokens),
        "cached_num_output_tokens": list(cached.num_output_tokens),
        "finished_request_ids": sorted(output.finished_req_ids),
        "preempted_request_ids": sorted(getattr(output, "preempted_req_ids", ()) or ()),
        "muxpd_prefill_cohort_id": getattr(output, "muxpd_prefill_cohort_id", None),
    }


def batch_snapshot(runner: Any) -> list[dict[str, Any]]:
    batch = runner.input_batch
    rows = []
    for index, request_id in enumerate(batch.req_ids):
        request = runner.requests[request_id]
        prompt = list(request.prompt_token_ids)
        prefix = list(request.output_token_ids)
        count = int(batch.num_tokens_no_spec[index])
        rows.append(
            {
                "row": index,
                "request_id": request_id,
                "prompt_token_ids": prompt,
                "prompt_sha256": token_digest(prompt),
                "output_prefix_token_ids": prefix,
                "output_prefix_sha256": token_digest(prefix),
                "output_token_index": len(prefix),
                "num_computed_tokens": int(batch.num_computed_tokens_cpu[index]),
                "num_tokens_no_spec": count,
                "input_token_ids": [int(x) for x in batch.token_ids_cpu[index, :count]],
                "kv_block_ids": [
                    [int(x) for x in blocks] for blocks in request.block_ids
                ],
            }
        )
    return rows


class NativeSamplerObserver:
    """Observe one runner through original execute/sample/bookkeeping methods."""

    def __init__(
        self,
        runner: Any,
        directory: Path,
        lane: str,
        rank: int,
        *,
        capture_token_indices_one_based: tuple[int, ...] = (1,),
        capture_ranks: tuple[int, ...] = (0,),
    ):
        if not directory.is_absolute():
            raise ValueError("Absolute output directory required")
        capture_window = validate_capture_window(capture_token_indices_one_based)
        if getattr(runner, "use_async_scheduling", False):
            raise ValueError("Numerical observer requires synchronous scheduling")
        if getattr(runner, "speculative_config", None) is not None:
            raise ValueError("Numerical observer requires non-speculative sampling")
        if getattr(runner, "_muxpd_numerical_observer", None) is not None:
            raise ValueError("Runner already has a numerical observer")
        self.runner, self.directory, self.lane, self.rank = (
            runner,
            directory,
            lane,
            rank,
        )
        self.capture_window, self.capture_ranks = capture_window, capture_ranks
        self.target_profile, self.target_prompt = load_target_profile()
        if list(capture_window) != self.target_profile[
            "regular_capture_token_indices_one_based"
        ] or list(capture_ranks) != [0]:
            raise ValueError("Target experiment requires original control window/rank")
        self.extra_directory = directory.parent / self.target_profile["extra_directory"]
        self.extra_exported = set()
        self.sequence = 0
        self.pending = None
        self.schedule = None
        self.batch_descriptor = None
        directory.mkdir(parents=True, exist_ok=True)
        self.log = (directory / f"rank-{rank}-{lane}.jsonl").open("x")
        self.emit(
            {
                "event": "observer-installed",
                "pid": os.getpid(),
                "capture_token_indices_one_based": list(capture_window),
                "capture_ranks": capture_ranks,
                "target_extra_profile": self.target_profile,
                "target_extra_profile_sha256": TARGET_PROFILE_SHA256,
                "scope": (
                    "Diagnostic only: native greedy call and native bookkeeping "
                    "remain intact; added clone/copy/I/O overhead."
                ),
            }
        )
        self.install()
        runner._muxpd_numerical_observer = self

    def emit(self, row: dict[str, Any]) -> None:
        self.log.write(
            json.dumps(
                {
                    "rank": self.rank,
                    "lane": self.lane,
                    "host_monotonic_ns": time.monotonic_ns(),
                    **row,
                },
                allow_nan=False,
            )
            + "\n"
        )
        self.log.flush()

    def install(self) -> None:
        runner = self.runner
        execute, sample = runner.execute_model, runner._sample
        bookkeeping, greedy = runner._bookkeeping_sync, runner.sampler.greedy_sample

        def observed_execute(output, *args, **kwargs):
            self.sequence += 1
            self.schedule = schedule_snapshot(output)
            self.emit(
                {
                    "event": "execute-enter",
                    "sequence": self.sequence,
                    "schedule": self.schedule,
                }
            )
            result = execute(output, *args, **kwargs)
            state = getattr(runner, "execute_model_state", None)
            self.batch_descriptor = None
            if state is not None:
                if len(state) != 12:
                    raise RuntimeError("Unknown native execute_model_state contract")
                descriptor = state[-1]
                self.batch_descriptor = (
                    asdict(descriptor)
                    if is_dataclass(descriptor)
                    else {
                        name: getattr(descriptor, name, None)
                        for name in (
                            "num_tokens",
                            "num_reqs",
                            "uniform",
                            "has_lora",
                            "num_active_loras",
                        )
                    }
                )
            self.emit(
                {
                    "event": "execute-return",
                    "sequence": self.sequence,
                    "deferred_native_state": state is not None,
                    "batch_descriptor": self.batch_descriptor,
                }
            )
            return result

        def observed_sample(logits, spec_decode_metadata, *args, **kwargs):
            if self.pending is not None:
                raise RuntimeError(
                    "Previous diagnostic sample has no native bookkeeping"
                )
            metadata = runner.input_batch.sampling_metadata
            if spec_decode_metadata is not None or not metadata.all_greedy:
                raise ValueError("Numerical observer only accepts plain greedy samples")
            rows = batch_snapshot(runner)
            self.pending = {
                "rows": rows,
                "shape": list(logits.shape),
                "dtype": str(logits.dtype),
                "logits": None,
                "native_greedy_calls": 0,
                "clone_receipt": None,
            }
            try:
                return sample(logits, spec_decode_metadata, *args, **kwargs)
            except BaseException:
                self.pending = None
                raise

        def observed_greedy(logits):
            # Original implementation is invoked exactly once, first. In
            # particular its collective/reduce-sample behavior is not replaced.
            result = greedy(logits)
            if self.pending is not None:
                self.pending["native_greedy_calls"] += 1
                if self.pending["native_greedy_calls"] != 1:
                    raise RuntimeError("Expected exactly one native greedy decision")
                selected = any(
                    row["output_token_index"] + 1 in self.capture_window
                    or self._select_extra(row)
                    for row in self.pending["rows"]
                )
                if self.rank in self.capture_ranks and selected:
                    self.pending["clone_receipt"] = self._clone_receipt(logits)
                    self.pending["logits"] = logits.detach().clone()
            return result

        def observed_bookkeeping(*args, **kwargs):
            # Native synchronous D2H and bookkeeping happen before diagnostic
            # copies, numpy conversion, argmax inspection or file writes.
            result = bookkeeping(*args, **kwargs)
            pending, self.pending = self.pending, None
            if pending is not None:
                if pending["native_greedy_calls"] != 1:
                    raise RuntimeError("No single native greedy call was observed")
                self.flush(pending, result)
            return result

        runner.execute_model = observed_execute
        runner._sample = observed_sample
        runner.sampler.greedy_sample = observed_greedy
        runner._bookkeeping_sync = observed_bookkeeping

    def flush(self, pending: dict[str, Any], native: Any) -> None:
        import numpy as np

        valid_tokens, req_ids, invalid = native[1], native[3], native[5]
        if list(req_ids) != [row["request_id"] for row in pending["rows"]]:
            raise RuntimeError("Sampler rows differ from native bookkeeping rows")
        raw = pending.pop("logits")
        array = raw.float().cpu().numpy() if raw is not None else None
        for row in pending["rows"]:
            row["sampled_token_ids"] = list(valid_tokens[row["row"]])
            row["discarded_by_native"] = (
                row["row"] in invalid or not row["sampled_token_ids"]
            )
            if (
                array is None
                or row["output_token_index"] + 1 not in self.capture_window
            ):
                continue
            values = array[row["row"]]
            filename = (
                f"rank-{self.rank}-{self.lane}-step-{self.sequence:05d}"
                f"-row-{row['row']}.npy"
            )
            path = self.directory / filename
            with path.open("xb") as stream:
                np.save(stream, values, allow_pickle=False)
            encoded = path.read_bytes()
            finite = bool(np.isfinite(values).all())
            top = np.argsort(values, kind="stable")[-8:][::-1]
            row["logits"] = {
                "file": filename,
                "bytes": len(encoded),
                "sha256": hashlib.sha256(encoded).hexdigest(),
                "shape": list(values.shape),
                "dtype": str(values.dtype),
                "all_finite": finite,
                "top_token_ids": [int(x) for x in top],
                "top_values": [
                    float(values[x]) if np.isfinite(values[x]) else None for x in top
                ],
                "cpu_argmax": int(np.argmax(values)),
            }
        self._export_extra(array, pending)
        self.emit(
            {
                "event": "native-sample-observed",
                "sequence": self.sequence,
                "schedule": self.schedule,
                "batch_descriptor": self.batch_descriptor,
                **pending,
            }
        )

    def _target_position(self, row):
        if row["prompt_sha256"] != self.target_profile["target_prompt_sha256"]:
            return None
        if row["prompt_token_ids"] != self.target_prompt:
            raise ValueError("Target prompt hash does not bind exact original tokens")
        index = row["output_token_index"]
        if (
            type(index) is not int
            or index < 0
            or len(row["output_prefix_token_ids"]) != index
        ):
            raise ValueError("Target output prefix/index differs")
        return index + 1

    def _select_extra(self, row):
        if self.rank != 0:
            return False
        position = self._target_position(row)
        if position not in self.target_profile["extra_capture_token_indices_one_based"]:
            return False
        if self.lane not in self.target_profile["allowed_extra_lanes"]:
            raise ValueError("Target early output must be an actual decode sample")
        return True

    def _clone_receipt(self, logits):
        shape = list(logits.shape)
        dtype, element_size, numel = (
            str(logits.dtype),
            logits.element_size(),
            logits.numel(),
        )
        if (
            len(shape) != 2
            or not 1 <= shape[0] <= 8
            or shape[1] != 248320
            or shape[0] != len(self.pending["rows"])
            or dtype != "torch.float32"
            or element_size != 4
            or numel != shape[0] * shape[1]
            or numel * element_size > MAX_CLONE_BYTES
        ):
            raise ValueError("Actual greedy clone shape/dtype/budget differs")
        return {
            "shape": shape,
            "dtype": dtype,
            "numel": numel,
            "element_size": element_size,
            "bytes": numel * element_size,
            "clone_count": 1,
            "original_greedy_completed": True,
        }

    def _export_extra(self, array, pending):
        import numpy as np

        if self.rank != 0:
            return
        for row in pending["rows"]:
            position = self._target_position(row)
            if position is None or position == 1:
                continue
            if (
                position >= 200
                and self.lane in self.target_profile["allowed_extra_lanes"]
                and self.extra_exported != set(range(2, 200))
            ):
                raise RuntimeError(
                    "Target early exports incomplete before old late window"
                )
            if not self._select_extra(row):
                continue
            if (
                position != len(self.extra_exported) + 2
                or position in self.extra_exported
            ):
                raise RuntimeError(
                    "Target early export duplicate, missing or out of order"
                )
            if (
                array is None
                or array.dtype != np.float32
                or row["discarded_by_native"]
                or len(row["sampled_token_ids"]) != 1
                or row["num_computed_tokens"] != 1340 + position - 2
                or row["num_tokens_no_spec"] != 1340 + position - 1
                or row["input_token_ids"]
                != self.target_prompt + row["output_prefix_token_ids"]
            ):
                raise RuntimeError(
                    "Target extra export does not match actual decode input/sample"
                )
            values = array[row["row"]]
            if list(values.shape) != [248320] or not np.isfinite(values).all():
                raise RuntimeError(
                    "Target extra vector shape/dtype/finite check failed"
                )
            filename = f"rank-{self.rank}-{self.lane}-target-{position:03d}.npy"
            self.extra_directory.mkdir(parents=True, exist_ok=True)
            path = self.extra_directory / filename
            with path.open("xb") as stream:
                np.save(stream, values, allow_pickle=False)
            encoded = path.read_bytes()
            top = np.argsort(values, kind="stable")[-8:][::-1]
            row["extra_logits"] = {
                "file": filename,
                "bytes": len(encoded),
                "sha256": hashlib.sha256(encoded).hexdigest(),
                "shape": list(values.shape),
                "dtype": str(values.dtype),
                "all_finite": True,
                "top_token_ids": [int(x) for x in top],
                "top_values": [float(values[x]) for x in top],
                "cpu_argmax": int(np.argmax(values)),
                "output_token_index_one_based": position,
                "profile_sha256": TARGET_PROFILE_SHA256,
                "clone_receipt_sha256": clone_receipt_digest(pending["clone_receipt"]),
            }
            self.extra_exported.add(position)


def attach_observer(worker: Any, runner: Any, lane: str) -> NativeSamplerObserver:
    directory = Path(os.environ["MUXPD_NUMERIC_OUTPUT"])
    if "MUXPD_NUMERIC_CAPTURE_STEPS" in os.environ:
        raise ValueError("Window observer rejects legacy capture_steps environment")
    window = validate_capture_window(
        json.loads(os.environ["MUXPD_NUMERIC_CAPTURE_WINDOW"])
    )
    ranks = tuple(
        int(rank) for rank in os.environ.get("MUXPD_NUMERIC_RANKS", "0").split(",")
    )
    return NativeSamplerObserver(
        runner,
        directory,
        lane,
        worker.rank,
        capture_token_indices_one_based=window,
        capture_ranks=ranks,
    )


def observe_prefill_group_return(worker: Any, index: int, *, final: bool) -> None:
    """Observe bounded host state before the original callback switches lanes."""
    observer = getattr(worker.model_runner, "_muxpd_numerical_observer", None)
    observed = getattr(worker, "_numeric_group_returns", 0)
    if observer is not None and observer.schedule is not None and observed < 128:
        from vllm.forward_context import get_forward_context

        context = get_forward_context()
        layers = context.all_moe_layers
        task = worker._interleaver.active
        observer.emit(
            {
                "event": "prefill-group-return-observed",
                "sequence": observer.sequence,
                "group_index": index,
                "final": final,
                "moe_layer_index": context.moe_layer_index,
                "all_moe_layers": list(layers[:128]) if layers is not None else None,
                "all_moe_layers_count": len(layers) if layers is not None else None,
                "all_moe_layers_truncated": layers is not None and len(layers) > 128,
                "active_lane": worker._execution_backend.active_lane,
                "task_name": task.name if task is not None else None,
                "task_completed_layers_before_checkpoint": (
                    task.completed_layers if task is not None else None
                ),
                "prefill_cohort_id": worker._prefill_cohort_id,
                "prefill_num_tokens": worker._prefill_num_tokens,
                "schedule": observer.schedule,
            }
        )
        worker._numeric_group_returns = observed + 1


class PrefillGroupObservationMixin:
    """Compatibility helper; serving extensions wrap the stored checkpoint."""

    def _prefill_group_return(self, index: int, *, final: bool) -> None:
        observe_prefill_group_return(self, index, final=final)
        return super()._prefill_group_return(index, final=final)


def bounded_constant(value: Any, *, depth: int = 0) -> Any:
    """JSON metadata for compiler constants; never read tensor contents."""
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return (
            value
            if value not in (float("inf"), float("-inf")) and value == value
            else str(value)
        )
    if depth >= 8:
        return {
            "type": type(value).__module__ + "." + type(value).__qualname__,
            "truncated": True,
        }
    if isinstance(value, (list, tuple)):
        return [bounded_constant(item, depth=depth + 1) for item in value]
    if isinstance(value, dict):
        return {
            str(key): bounded_constant(item, depth=depth + 1)
            for key, item in value.items()
        }
    if hasattr(value, "shape") and hasattr(value, "dtype"):
        return {
            "type": type(value).__module__ + "." + type(value).__qualname__,
            "shape": list(value.shape),
            "dtype": str(value.dtype),
            "device": str(getattr(value, "device", "unknown")),
            "contents_observed": False,
        }
    return {
        "type": type(value).__module__ + "." + type(value).__qualname__,
        "name": getattr(value, "__qualname__", None),
        "repr": str(value) if type(value).__module__ == "torch" else None,
    }


def compiler_constants_snapshot(worker: Any) -> None:
    import torch
    from torch._higher_order_ops.triton_kernel_wrap import kernel_side_table

    path = (
        Path(os.environ["MUXPD_NUMERIC_OUTPUT"])
        / f"rank-{worker.rank}-compiler-constants.json"
    )
    contents = {
        "rank": worker.rank,
        "pid": os.getpid(),
        "scope": (
            "Post-native-warmup Triton constant argument metadata; tensor "
            "contents are never read, and this alone does not establish "
            "compiler equivalence. Environment values are observed, not proof "
            "that every collective/operator is deterministic."
        ),
        "deterministic_algorithms_enabled": (
            torch.are_deterministic_algorithms_enabled()
        ),
        "deterministic_algorithms_warn_only": (
            torch.is_deterministic_algorithms_warn_only_enabled()
        ),
        "environment": {
            name: os.environ.get(name)
            for name in (
                "HCCL_DETERMINISTIC",
                "VLLM_BATCH_INVARIANT",
                "ASCEND_LAUNCH_BLOCKING",
                "ASCEND_RT_VISIBLE_DEVICES",
                "OMP_NUM_THREADS",
                "PYTHONHASHSEED",
            )
        },
        "constant_args": bounded_constant(kernel_side_table.constant_args),
    }
    with path.open("x") as stream:
        json.dump(contents, stream, indent=2, allow_nan=False)
        stream.write("\n")
