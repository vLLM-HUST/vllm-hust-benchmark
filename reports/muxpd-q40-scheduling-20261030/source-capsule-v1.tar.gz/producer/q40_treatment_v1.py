"""One pinned, supported scheduler quota change after original q4 validation."""

import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROFILE_SHA = "5c5795ae97d76241a73533c2bc327c59baad9804942543e297363c0618f4cd0e"
WORKER = "vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker"
OBSERVER = "window_numeric_workers_v1.NumericalObserverExtension"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_treatment():
    path = HERE / "treatment-profile-v1.json"
    if sha(path) != PROFILE_SHA:
        raise ValueError("Treatment sidecar bytes changed")
    value = json.loads(path.read_text())
    for field in ("base_plan", "base_config"):
        receipt = value[field]
        if sha(HERE / receipt["file"]) != receipt["sha256"]:
            raise ValueError("Original plan/config bytes changed")
    return value


def expected_config(profile, base, quota):
    value = load_treatment()
    pinned = json.loads((HERE / value["base_config"]["file"]).read_text())
    if profile not in value["profiles"] or base != pinned:
        raise ValueError("Profile/base differs from original raw q4 input")
    expected = copy.deepcopy(base)
    expected["worker_cls"] = WORKER
    if profile == "prefix-observed":
        expected["worker_extension_cls"] = OBSERVER
    expected["batch_admission_policy_config"]["layers_per_slice"] = quota
    return expected


def apply_treatment(profile, base, configured):
    if configured != expected_config(profile, base, 4):
        raise ValueError("Original configured input differs before q40 treatment")
    result = copy.deepcopy(configured)
    result["batch_admission_policy_config"]["layers_per_slice"] = 40
    validate_launch_config(profile, base, result)
    return result


def validate_launch_config(profile, base, actual):
    if actual != expected_config(profile, base, 40):
        raise ValueError("Launch config differs beyond declared quota4-to40")


def treatment_receipt(profile, base, actual):
    validate_launch_config(profile, base, actual)
    value = load_treatment()
    return {
        "profile_sha256": PROFILE_SHA,
        "base_config_sha256": value["base_config"]["sha256"],
        "plan_file_sha256": value["base_plan"]["sha256"],
        "change": value["change"],
        "profile": profile,
        "launch_config_sha256": hashlib.sha256(
            json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
    }
