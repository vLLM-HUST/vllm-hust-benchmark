"""Bounded raw-P collective-layout counterfactual, never a production fix.

No torch/vLLM import on module import. Install before layer observers and remove
those observers first. Neither dummy requests nor extra collectives are created.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import operator
import os
from pathlib import Path

ATTRIBUTE = "_muxpd_prefill_collective_layout_v1"
MODES = frozenset(("prefix", "copy_only", "suffix"))
_MISSING = object()
MAX_COHORTS = 64
MAX_CALLS = 4096
MAX_PAYLOAD_BYTES = 512 * 1024 * 1024


def _unwrap(argument):
    try:
        return object.__getattribute__(argument, "worker")
    except AttributeError:
        return argument


def _ints(values):
    if str(getattr(values, "device", "cpu")) != "cpu":
        raise RuntimeError("Layout metadata must already be on CPU")
    return [operator.index(value) for value in values]


def _digest(values):
    return hashlib.sha256(
        json.dumps(_ints(values), separators=(",", ":")).encode()
    ).hexdigest()


def _sha():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


class TorchRuntime:
    def __init__(self):
        import torch
        from greenlet import getcurrent
        from vllm.forward_context import get_forward_context

        self.torch = torch
        self.context = get_forward_context
        self.coroutine = getcurrent

    def transform(self, tensor, prefix, suffix, original):
        scratch = tensor.new_zeros((prefix + tensor.shape[0] + suffix, tensor.shape[1]))
        scratch[prefix : prefix + tensor.shape[0]].copy_(tensor)
        result = original(scratch)
        if (
            result.shape != scratch.shape
            or result.dtype != scratch.dtype
            or result.device != scratch.device
        ):
            raise RuntimeError("Existing collective changed payload shape/dtype/device")
        tensor.copy_(result[prefix : prefix + tensor.shape[0]])
        return tensor


def _route(worker, group, *, serving=False):
    communicator = group.device_communicator
    router = worker._collective_router
    function = communicator.all_reduce
    if (
        getattr(function, "_muxpd_collective_router", None) is not router
        or router._backend is not worker._execution_backend
        or router._failed
        or communicator.device_group is not group.device_group
        or not any(
            owner is communicator and name == "all_reduce" and installed is function
            for owner, name, _, installed in router._installed
        )
    ):
        raise RuntimeError("Existing isolated P route is not owned/intact")
    closure = inspect.getclosurevars(function).nonlocals
    target = getattr(closure.get("prefill"), "__self__", None)
    siblings = [s for s in worker._prefill_groups if s.device_communicator is target]
    if (
        len(siblings) != 1
        or getattr(closure.get("original"), "__self__", None) is not communicator
    ):
        raise RuntimeError("Router does not identify one existing P sibling")
    sibling = siblings[0]
    if (
        sibling.device_group is group.device_group
        or sibling.ranks != group.ranks
        or sibling.device_communicator.device_group is not sibling.device_group
    ):
        raise RuntimeError("P group must be independent with identical rank membership")
    if serving and router._backend.active_lane != "prefill":
        raise RuntimeError("Layout collective is outside the actual P lane")
    return {
        "process_id": os.getpid(),
        "coordinator_name": group.unique_name,
        "coordinator_python_id": id(group),
        "device_group_python_id": id(group.device_group),
        "selected_coordinator_name": sibling.unique_name,
        "selected_device_group_python_id": id(sibling.device_group),
        "ranks": list(group.ranks),
        "rank_in_group": int(group.rank_in_group),
        "router_calls": dict(router.calls),
        "active_lane": router._backend.active_lane,
    }


class Layout:
    def __init__(self, worker, mode, group, runtime, hidden_size):
        if mode not in MODES:
            raise ValueError("mode must be prefix, copy_only, or suffix")
        self.worker, self.mode, self.group, self.runtime = worker, mode, group, runtime
        self.hidden_size, self.rank = hidden_size, int(worker.rank)
        self.local_rank = int(getattr(worker, "local_rank", worker.rank))
        self.expected_device = f"npu:{self.local_rank}"
        self.patches = []
        self.cohorts = []
        self.active = None
        self.context = None
        self.in_collective = False
        self.errors = []
        self.restored_count = 0
        self.uninstalled = False

    def _patch(self, owner, name, factory):
        slot = vars(owner).get(name, _MISSING)
        original = getattr(owner, name)
        wrapper = factory(original)
        setattr(owner, name, wrapper)
        self.patches.append((owner, name, slot, original, wrapper))

    def install(self):
        _route(self.worker, self.group)
        self._patch(self.worker, "execute_model", self._execute_wrapper)
        self._patch(self.worker, "_clear_prefill", self._clear_wrapper)
        self._patch(self.group, "_all_reduce_out_place", self._collective_wrapper)

    def _admit(self, output):
        new = set(output.muxpd_prefill_request_ids)
        if not new:
            return
        if self.active is not None or self.worker._prefill_task is not None:
            raise RuntimeError("A layout cohort cannot replace an owned P cohort")
        counts = dict(output.num_scheduled_tokens)
        if (
            not new <= counts.keys()
            or any(type(n) is not int or n <= 0 for n in counts.values())
            or sum(counts.values()) != output.total_num_scheduled_tokens
            or type(output.muxpd_prefill_cohort_id) is not int
            or output.muxpd_prefill_cohort_id <= 0
            or set(output.muxpd_pending_prefill_ids) != new
            or output.muxpd_cancel_prefill_request_ids
            or output.scheduled_spec_decode_tokens
        ):
            raise RuntimeError("Malformed new-P admission layout")
        p_counts = {rid: n for rid, n in counts.items() if rid in new}
        d_counts = {rid: n for rid, n in counts.items() if rid not in new}
        if any(n != 1 for n in d_counts.values()):
            raise RuntimeError("Layout diagnostic requires ordinary one-token decodes")
        if len(self.cohorts) >= MAX_COHORTS or any(
            c["cohort_id"] == output.muxpd_prefill_cohort_id for c in self.cohorts
        ):
            raise RuntimeError("Layout cohort bound or identity violated")
        record = {
            "cohort_id": output.muxpd_prefill_cohort_id,
            "mode": self.mode,
            "admission_p_counts": p_counts,
            "admission_d_counts": d_counts,
            "p_rows": sum(p_counts.values()),
            "d_rows": sum(d_counts.values()),
            "status": "admitted",
            "batch": None,
            "calls": [],
            "zero_d_bypass_calls": 0,
            "clear_count": 0,
            "error": None,
            "native_equivalent_order_claimed": False,
        }
        self.cohorts.append(record)
        self.active = record

    def _execute_wrapper(self, original):
        signature = inspect.signature(original)

        def wrapper(*args, **kwargs):
            admitted = None
            try:
                output = signature.bind(*args, **kwargs).arguments["scheduler_output"]
                if getattr(output, "muxpd_execution", None) != "decoupled":
                    raise RuntimeError(
                        "Layout requires the original decoupled scheduler"
                    )
                previous = self.active
                self._admit(output)
                if self.active is not previous:
                    admitted = self.active
                return original(*args, **kwargs)
            except BaseException as exc:
                error = f"{type(exc).__name__}: {exc}"
                self.errors.append(error)
                if self.active is not None:
                    self.active["error"] = error
                # Only an admission that never obtained a worker cohort can
                # roll back immediately. Suspended/in-flight P retains ownership.
                if (
                    admitted is not None
                    and self.worker._prefill_task is None
                    and self.worker._prefill_cohort_id is None
                ):
                    admitted["status"] = "admission_failed"
                    self.active = None
                    self.context = None
                raise

        return wrapper

    def _clear_wrapper(self, original):
        def wrapper(*args, **kwargs):
            task = self.worker._prefill_task
            if self.in_collective or (
                task is not None and not task.tasks["prefill"].done
            ):
                raise RuntimeError(
                    "Cannot clear layout while P still owns unfinished work"
                )
            result = original(*args, **kwargs)
            if (
                self.worker._prefill_task is not None
                or self.worker._prefill_cohort_id is not None
            ):
                raise RuntimeError("Original P clear did not release cohort ownership")
            if self.active is not None:
                self.active["status"] = "closed"
                self.active["clear_count"] += 1
                self.active = None
                self.context = None
            return result

        return wrapper

    def _verify_owner_and_batch(self):
        worker, record = self.worker, self.active
        if record is None or worker._prefill_cohort_id != record["cohort_id"]:
            raise RuntimeError("Actual P lane has no matching frozen layout cohort")
        interleaver = worker._interleaver
        if (
            interleaver is None
            or interleaver is not worker._prefill_task
            or interleaver.active is None
            or interleaver.active.name != "prefill"
            or interleaver.active.coroutine is not self.runtime.coroutine()
        ):
            raise RuntimeError("Layout is outside the owning P coroutine")
        context = self.runtime.context()
        mode = getattr(getattr(context, "cudagraph_runtime_mode", None), "name", None)
        if (
            context is None
            or getattr(context, "capturing", False)
            or getattr(context, "in_profile_run", False)
            or mode != "NONE"
            or not getattr(context, "skip_compiled", False)
            or worker._prefill_compiled
        ):
            raise RuntimeError("Layout requires raw non-capturing P execution")
        if self.context is not None and context is not self.context:
            raise RuntimeError("P forward context changed inside frozen layout cohort")
        self.context = context
        if record["batch"] is not None:
            return
        runner = worker.model_runner
        batch = runner.input_batch
        n = int(batch.num_reqs)
        ids = list(batch.req_ids[:n])
        qsl = _ints(runner.query_start_loc.cpu[: n + 1])
        computed = _ints(batch.num_computed_tokens_cpu[:n])
        if (
            len(set(ids)) != n
            or set(ids) != set(record["admission_p_counts"])
            or len(qsl) != n + 1
            or qsl[0] != 0
            or qsl[-1] != record["p_rows"]
            or any(computed)
        ):
            raise RuntimeError("Layout requires the complete untouched P token axis")
        rows = []
        for i, rid in enumerate(ids):
            request = runner.requests[rid]
            tokens = _ints(request.prompt_token_ids)
            begin, end = qsl[i : i + 2]
            if (
                request.output_token_ids
                or end - begin != len(tokens)
                or end - begin != record["admission_p_counts"][rid]
                or _ints(runner.input_ids.cpu[begin:end]) != tokens
                or _ints(runner._positions_np_buf[begin:end])
                != list(range(len(tokens)))
            ):
                raise RuntimeError(
                    "Layout rejects partial/recomputed/mismatched P rows"
                )
            rows.append(
                {
                    "request_id": rid,
                    "prompt_sha256": _digest(tokens),
                    "prompt_tokens": len(tokens),
                    "computed_tokens": computed[i],
                    "token_start": begin,
                    "token_end": end,
                    "output_tokens": 0,
                }
            )
        record["batch"] = {
            "req_ids": ids,
            "query_start_loc": qsl,
            "rows": rows,
            "order_matches_admission_p_map": ids == list(record["admission_p_counts"]),
            "packed_tokens_and_positions_verified": True,
        }
        record["status"] = "executing"

    def _collective_wrapper(self, original):
        def wrapper(input_):
            if self.worker._execution_backend.active_lane != "prefill":
                return original(input_)
            self._verify_owner_and_batch()
            record = self.active
            if record["d_rows"] == 0:
                record["zero_d_bypass_calls"] += 1
                return original(input_)
            shape = [int(value) for value in input_.shape]
            if (
                shape != [record["p_rows"], self.hidden_size]
                or str(input_.dtype) != "torch.bfloat16"
                or str(input_.device) != self.expected_device
                or not input_.is_contiguous()
            ):
                raise RuntimeError(
                    "Layout accepts only contiguous BF16 P token-axis TP reductions"
                )
            prefix = record["d_rows"] if self.mode == "prefix" else 0
            suffix = record["d_rows"] if self.mode == "suffix" else 0
            payload = [shape[0] + prefix + suffix, shape[1]]
            if (
                payload[0] * payload[1] * 2 > MAX_PAYLOAD_BYTES
                or len(record["calls"]) >= MAX_CALLS
            ):
                raise RuntimeError("Layout diagnostic payload/call bound exceeded")
            if self.in_collective:
                raise RuntimeError("Reentrant P layout collective")
            before = _route(self.worker, self.group, serving=True)
            call = {
                "ordinal": len(record["calls"]) + 1,
                "mode": self.mode,
                "input_shape": shape,
                "collective_payload_shape": payload,
                "prefix_rows": prefix,
                "suffix_rows": suffix,
                "dummy_rows": prefix + suffix,
                "copyback_offset": prefix,
                "dtype": str(input_.dtype),
                "device": str(input_.device),
                "existing_collective_calls": 0,
                "return_original_input": False,
                "route_before": before,
                "status": "started",
                "error": None,
            }
            record["calls"].append(call)

            def once(scratch):
                if call["existing_collective_calls"] or list(scratch.shape) != payload:
                    raise RuntimeError(
                        "Layout collective count or actual payload differs from plan"
                    )
                call["existing_collective_calls"] += 1
                return original(scratch)

            self.in_collective = True
            try:
                result = self.runtime.transform(input_, prefix, suffix, once)
                if result is not input_ or call["existing_collective_calls"] != 1:
                    raise RuntimeError(
                        "Layout must reduce once and return original input object"
                    )
                after = _route(self.worker, self.group, serving=True)
                delta = {
                    lane: after["router_calls"][lane] - before["router_calls"][lane]
                    for lane in ("caller", "decode", "prefill")
                }
                if delta != {"caller": 0, "decode": 0, "prefill": 1}:
                    raise RuntimeError(
                        "Layout did not call exactly one existing P collective"
                    )
                call.update(
                    return_original_input=True,
                    router_call_delta=delta,
                    route_after=after,
                    status="complete",
                )
                return result
            except BaseException as exc:
                call["status"] = "failed"
                call["error"] = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                self.in_collective = False

        return wrapper

    def snapshot(self):
        return json.loads(
            json.dumps(
                {
                    "schema": "muxpd-prefill-collective-layout-v1",
                    "rank": self.rank,
                    "mode": self.mode,
                    "module_sha256": _sha(),
                    "installed_hook_count": len(self.patches),
                    "all_hooks_intact": all(
                        vars(o).get(n, _MISSING) is w for o, n, _, _, w in self.patches
                    ),
                    "hidden_size": self.hidden_size,
                    "expected_device": self.expected_device,
                    "local_rank": self.local_rank,
                    "active_cohort": None
                    if self.active is None
                    else self.active["cohort_id"],
                    "in_collective": self.in_collective,
                    "errors": self.errors,
                    "cohorts": self.cohorts,
                    "treated_cohorts": sum(bool(c["calls"]) for c in self.cohorts),
                    "uninstalled": self.uninstalled,
                    "limits": {
                        "max_cohorts": MAX_COHORTS,
                        "max_calls_per_cohort": MAX_CALLS,
                        "max_payload_bytes": MAX_PAYLOAD_BYTES,
                    },
                    "scope": "Diagnostic communication layout; no native batch equivalence or quality/performance qualification",
                }
            )
        )

    def _idle(self):
        worker = self.worker
        if (
            self.active is not None
            or self.in_collective
            or worker._prefill_task is not None
            or getattr(worker, "_awaiting_sample", False)
            or getattr(worker, "_pending_lanes", ())
            or getattr(worker, "_interleaver", None) is not None
            or worker._execution_backend.active_lane is not None
        ):
            return False
        for runner in (worker.model_runner, worker.decode_runner):
            batch = runner.input_batch
            if (
                runner.requests
                or batch.num_reqs
                or batch.req_id_to_index
                or any(rid is not None for rid in batch.req_ids)
                or getattr(runner, "execute_model_state", None) is not None
            ):
                return False
        return True

    def _restored(self):
        return all(
            (name not in vars(owner) and getattr(owner, name) == original)
            if slot is _MISSING
            else vars(owner).get(name, _MISSING) is slot
            for owner, name, slot, original, _ in self.patches
        )

    def uninstall(self, allow_incomplete=False):
        receipt = {
            "schema": "muxpd-prefill-layout-uninstall-v1",
            "rank": self.rank,
            "mode": self.mode,
            "module_sha256": _sha(),
            "allow_incomplete": allow_incomplete,
            "ok": False,
            "error": None,
            "collection_errors": list(self.errors),
        }
        try:
            if type(allow_incomplete) is not bool or not self._idle():
                raise RuntimeError(
                    "Layout uninstall requires aborted/drained idle worker"
                )
            if self.errors and not allow_incomplete:
                raise RuntimeError(
                    "Failed layout collection requires explicit incomplete cleanup"
                )
            if not self.uninstalled:
                foreign = [
                    name
                    for owner, name, _, _, wrapper in self.patches
                    if vars(owner).get(name, _MISSING) is not wrapper
                ]
                if foreign:
                    raise RuntimeError(
                        f"Layout slots changed externally; uninstall outer observers first: {foreign}"
                    )
                for owner, name, slot, _, _ in reversed(self.patches):
                    if slot is _MISSING:
                        delattr(owner, name)
                    else:
                        setattr(owner, name, slot)
                    self.restored_count += 1
                self.uninstalled = True
            if not self._restored():
                raise RuntimeError("Layout original method slots were not restored")
            receipt["ok"] = True
        except BaseException as exc:  # noqa: BLE001 -- retain separate failed cleanup evidence
            receipt["error"] = f"{type(exc).__name__}: {exc}"
        receipt.update(
            restored_count=self.restored_count,
            installed_hook_count=len(self.patches),
            all_originals_restored=self._restored(),
            idle=self._idle(),
            collection_success_not_inferred_from_cleanup=True,
        )
        return receipt


def install_on_worker(argument, mode):
    if mode not in MODES:
        raise ValueError("mode must be prefix, copy_only, or suffix")
    worker = _unwrap(argument)
    if getattr(worker, ATTRIBUTE, None) is not None:
        raise RuntimeError("Layout installation already attempted")
    if getattr(worker, "_muxpd_layer_capture_v3", None) is not None:
        raise RuntimeError("Install layout before any layer-v3 observer")
    cfg = worker.vllm_config
    parallel = cfg.parallel_config
    if (
        worker.execution_mode != "decoupled"
        or getattr(worker, "decode_runner", None) is None
        or worker._stream_mode != "overlap"
        or worker._overlap_communication != "isolated"
        or not worker._decode_graph_enabled
        or worker._prefill_groups_enabled
        or cfg.scheduler_config.async_scheduling
        or cfg.speculative_config is not None
        or cfg.quant_config is not None
        or str(cfg.model_config.dtype) != "torch.bfloat16"
        or cfg.model_config.hf_text_config.model_type != "qwen3_5_moe_text"
        or parallel.tensor_parallel_size != 4
        or not parallel.enable_expert_parallel
        or any(
            getattr(parallel, name, 1) != 1
            for name in (
                "data_parallel_size",
                "pipeline_parallel_size",
                "prefill_context_parallel_size",
                "decode_context_parallel_size",
            )
        )
        or getattr(parallel, "enable_dbo", False)
        or getattr(parallel, "use_sequence_parallel_moe", False)
    ):
        raise RuntimeError(
            "Layout diagnostic requires the fixed raw synchronous BF16 Qwen3.5 TP4/EP4 profile"
        )
    graph = worker._decode_graph_controller.snapshot()
    if (
        not graph["captured"]
        or graph["failed"]
        or graph["closed"]
        or graph["compile_full_prefill"]
    ):
        raise RuntimeError(
            "Install layout only after successful raw-P/decode graph startup"
        )
    from vllm.distributed import get_tp_group

    group = get_tp_group()
    if (
        group.world_size != 4
        or group.ranks[group.rank_in_group] != worker.rank
        or not group.use_custom_op_call
    ):
        raise RuntimeError("Layout requires the original opaque TP coordinator")
    layout = Layout(
        worker, mode, group, TorchRuntime(), cfg.model_config.hf_text_config.hidden_size
    )
    if not layout._idle():
        raise RuntimeError("Layout must be installed while both runners are idle")
    setattr(worker, ATTRIBUTE, layout)
    try:
        layout.install()
    except BaseException as exc:
        layout.errors.append(f"{type(exc).__name__}: {exc}")
        raise
    return layout.snapshot()


def snapshot_on_worker(argument):
    layout = getattr(_unwrap(argument), ATTRIBUTE, None)
    return None if layout is None else layout.snapshot()


def uninstall_on_worker(argument, allow_incomplete=False):
    worker = _unwrap(argument)
    layout = getattr(worker, ATTRIBUTE, None)
    if layout is None:
        return {
            "schema": "muxpd-prefill-layout-uninstall-v1",
            "rank": int(worker.rank),
            "mode": None,
            "module_sha256": _sha(),
            "allow_incomplete": allow_incomplete,
            "ok": bool(allow_incomplete),
            "error": None if allow_incomplete else "Layout never installed",
            "installed_hook_count": 0,
            "restored_count": 0,
            "all_originals_restored": True,
            "idle": True,
            "collection_success_not_inferred_from_cleanup": True,
        }
    return layout.uninstall(allow_incomplete)


def validate_receipts(
    rows, module_sha, *, mode, expected_treated_cohorts=None, expected_completed=None
):
    if (
        mode not in MODES
        or len(rows) != 4
        or {r["rank"] for r in rows} != set(range(4))
    ):
        raise RuntimeError(
            "Layout requires a valid mode and four distinct rank receipts"
        )
    for expected in (expected_treated_cohorts, expected_completed):
        if expected is not None and (type(expected) is not int or expected < 0):
            raise ValueError("Expected cohort counts must be non-negative integers")
    rank_signatures = []
    for row in rows:
        if (
            row["schema"] != "muxpd-prefill-collective-layout-v1"
            or row["module_sha256"] != module_sha
            or row["mode"] != mode
            or row["installed_hook_count"] != 3
            or not row["all_hooks_intact"]
            or row["errors"]
            or row["in_collective"]
            or row["uninstalled"]
            or row["expected_device"] != f"npu:{row['local_rank']}"
            or type(row["hidden_size"]) is not int
            or row["hidden_size"] <= 0
        ):
            raise RuntimeError("Layout collection receipt failed")
        if (
            expected_treated_cohorts is not None
            and row["treated_cohorts"] != expected_treated_cohorts
        ):
            raise RuntimeError("Unexpected number of treated layout cohorts")
        if expected_completed is not None and (
            len(row["cohorts"]) != expected_completed
            or row["active_cohort"] is not None
            or any(
                c["status"] != "closed" or c["clear_count"] != 1 or c["error"]
                for c in row["cohorts"]
            )
        ):
            raise RuntimeError("Layout completed cohort count or retirement differs")
        if row["treated_cohorts"] != sum(bool(c["calls"]) for c in row["cohorts"]):
            raise RuntimeError(
                "Declared treated count differs from actual cohort calls"
            )
        signatures = []
        for cohort in row["cohorts"]:
            p_counts, d_counts = (
                cohort["admission_p_counts"],
                cohort["admission_d_counts"],
            )
            if (
                not p_counts
                or set(p_counts) & set(d_counts)
                or any(type(v) is not int or v <= 0 for v in p_counts.values())
                or any(type(v) is not int or v != 1 for v in d_counts.values())
                or sum(p_counts.values()) != cohort["p_rows"]
                or sum(d_counts.values()) != cohort["d_rows"]
            ):
                raise RuntimeError("Layout admission counts are inconsistent")
            batch = cohort["batch"]
            if cohort["calls"] or cohort["zero_d_bypass_calls"]:
                if (
                    batch is None
                    or set(batch["req_ids"]) != set(p_counts)
                    or len(batch["req_ids"]) != len(p_counts)
                ):
                    raise RuntimeError("Layout actual P requests differ from admission")
                qsl = batch["query_start_loc"]
                if (
                    len(qsl) != len(p_counts) + 1
                    or qsl[0] != 0
                    or qsl[-1] != cohort["p_rows"]
                    or not batch["packed_tokens_and_positions_verified"]
                    or len(batch["rows"]) != len(p_counts)
                ):
                    raise RuntimeError(
                        "Layout actual P token boundaries are incomplete"
                    )
                for i, rid in enumerate(batch["req_ids"]):
                    actual = batch["rows"][i]
                    if (
                        qsl[i + 1] - qsl[i] != p_counts[rid]
                        or actual["request_id"] != rid
                        or actual["token_start"] != qsl[i]
                        or actual["token_end"] != qsl[i + 1]
                        or actual["prompt_tokens"] != p_counts[rid]
                        or actual["computed_tokens"] != 0
                        or actual["output_tokens"] != 0
                        or len(actual["prompt_sha256"]) != 64
                    ):
                        raise RuntimeError(
                            "Layout actual P rows are not full fresh prompts"
                        )
            if cohort["mode"] != mode or (cohort["d_rows"] == 0 and cohort["calls"]):
                raise RuntimeError("Layout mode or zero-D bypass changed")
            for ordinal, call in enumerate(cohort["calls"], 1):
                prefix = cohort["d_rows"] if mode == "prefix" else 0
                suffix = cohort["d_rows"] if mode == "suffix" else 0
                if (
                    call["ordinal"] != ordinal
                    or call["input_shape"] != [cohort["p_rows"], row["hidden_size"]]
                    or call["dtype"] != "torch.bfloat16"
                    or call["device"] != row["expected_device"]
                    or call["status"] != "complete"
                    or call["error"] is not None
                    or call["mode"] != mode
                    or call["prefix_rows"] != prefix
                    or call["suffix_rows"] != suffix
                    or call["copyback_offset"] != prefix
                    or call["dummy_rows"] != prefix + suffix
                    or call["collective_payload_shape"]
                    != [cohort["p_rows"] + prefix + suffix, call["input_shape"][1]]
                    or call["existing_collective_calls"] != 1
                    or not call["return_original_input"]
                    or call["router_call_delta"]
                    != {"caller": 0, "decode": 0, "prefill": 1}
                ):
                    raise RuntimeError("Layout collective call receipt failed")
                before, after = call["route_before"], call["route_after"]
                if (
                    any(
                        before[key] != after[key]
                        for key in before
                        if key != "router_calls"
                    )
                    or before["active_lane"] != "prefill"
                    or len(set(before["ranks"])) != 4
                    or before["ranks"][before["rank_in_group"]] != row["rank"]
                    or before["device_group_python_id"]
                    == before["selected_device_group_python_id"]
                    or {
                        lane: after["router_calls"][lane] - before["router_calls"][lane]
                        for lane in ("caller", "decode", "prefill")
                    }
                    != call["router_call_delta"]
                ):
                    raise RuntimeError("Layout real P route receipt is inconsistent")
            signature = {key: value for key, value in cohort.items() if key != "calls"}
            signature["calls"] = [
                {
                    key: value
                    for key, value in call.items()
                    if key not in ("device", "route_before", "route_after")
                }
                for call in cohort["calls"]
            ]
            signatures.append(signature)
        rank_signatures.append(signatures)
    if any(signature != rank_signatures[0] for signature in rank_signatures[1:]):
        raise RuntimeError(
            "Frozen layout cohort/call metadata disagrees across TP ranks"
        )
    return {
        "validated_ranks": [0, 1, 2, 3],
        "mode": mode,
        "quality_and_plain_observed_bridge_still_required": True,
    }


def validate_uninstall_receipts(rows, module_sha, *, mode, allow_incomplete=False):
    if len(rows) != 4 or {r["rank"] for r in rows} != set(range(4)):
        raise RuntimeError("Layout cleanup requires four distinct ranks")
    for row in rows:
        absent = row["installed_hook_count"] == 0 and allow_incomplete
        if (
            row["schema"] != "muxpd-prefill-layout-uninstall-v1"
            or row["module_sha256"] != module_sha
            or (row["mode"] != mode and not absent)
            or row["allow_incomplete"] != allow_incomplete
            or not row["ok"]
            or row["error"]
            or not row["idle"]
            or not row["all_originals_restored"]
            or row["restored_count"] != row["installed_hook_count"]
            or (not absent and row["installed_hook_count"] != 3)
        ):
            raise RuntimeError("Layout cleanup receipt failed")
    return {
        "validated_ranks": [0, 1, 2, 3],
        "mode": mode,
        "collection_success_not_inferred_from_cleanup": True,
    }
