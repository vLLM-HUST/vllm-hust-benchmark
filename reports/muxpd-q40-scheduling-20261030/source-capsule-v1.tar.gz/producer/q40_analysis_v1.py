"""Terminal-only validation for the declared q4-to-q40 policy experiment."""

import copy
import json
from pathlib import Path

TARGET = "mmlu-pro-07338"
SEED = "mmlu-pro-07151"


def require(value, message):
    if not value:
        raise ValueError(message)


def validate_schedule(report, history):
    """Bind actual CPU scheduler/worker receipts, prefixes and graph counters."""
    require(report["schema"] == "muxpd-q40-run-v1", "Require explicit q40 run schema")
    cases = report["plan"]["cases"]
    order = [c["case_id"] for c in cases]
    prompts = {c["case_id"]: c["prompt_token_ids"] for c in cases}
    require(
        len(order) == 8 and order[0] == SEED and order[3] == TARGET,
        "Original eight-request order changed",
    )
    admissions = report["admissions"]
    require(
        len(admissions) == 2
        and admissions[0]["after_step"] == 0
        and admissions[1]["after_step"] == 1
        and admissions[1]["seed_output_tokens"] == 1
        and [[b["case_id"] for b in a["bindings"]] for a in admissions]
        == [order[:1], order[1:]],
        "Original first-token admission changed",
    )
    mapping = {b["case_id"]: b["internal"] for a in admissions for b in a["bindings"]}
    ids = [mapping[c] for c in order]
    require(len(set(ids)) == 8, "Request identity is ambiguous")
    prefixes = report["prefixes_before_abort"]
    expected_lengths = {c: 209 if c == SEED else 208 for c in order}
    require(
        set(prefixes) == set(order)
        and {c: len(v["output_token_ids"]) for c, v in prefixes.items()}
        == expected_lengths
        and all(prefixes[c]["prompt_token_ids"] == prompts[c] for c in order)
        and report["engine_steps_to_boundary"] == 209,
        "q40 final seed209/peer208 boundary differs",
    )
    require(
        not report["natural_completions"]
        and all(v["num_preemptions"] == 0 for v in prefixes.values()),
        "Request finished/preempted before fixed boundary",
    )
    # One schedule, successful worker receipt, and host step return per serving turn.
    require(
        len(history) == 629 and report["cancellation"]["maintenance_steps"] == 1,
        "Unexpected/missing serving or cleanup events",
    )
    decode_calls = 0
    for step in range(1, 210):
        scheduled, retired, returned = history[(step - 1) * 3 : step * 3]
        require(
            [x["event"] for x in (scheduled, retired, returned)]
            == ["scheduled", "worker-retirement", "step-return"]
            and all(x["step"] == step for x in (scheduled, retired, returned)),
            "Serving receipt order/step is missing or duplicated",
        )
        pids = ids[:1] if step == 1 else ids[1:] if step == 2 else []
        dids = [] if step == 1 else ids[:1] if step == 2 else ids
        expected_tokens = {
            mapping[c]: len(prompts[c]) for c in order if mapping[c] in pids
        }
        expected_tokens.update(dict.fromkeys(dids, 1))
        require(
            scheduled["num_scheduled_tokens"] == expected_tokens
            and set(scheduled["prefill_ids"]) == set(pids)
            and len(scheduled["prefill_ids"]) == len(pids)
            and set(scheduled["pending_prefill_ids"]) == set(pids)
            and len(scheduled["pending_prefill_ids"]) == len(pids)
            and scheduled["cohort_id"] == (step if step <= 2 else None)
            and not scheduled["finished_ids"]
            and not scheduled["preempted_ids"]
            and scheduled["layers_per_slice"] == 40
            and scheduled["layers_completed_before"] == 0
            and scheduled["layers_total"] == (40 if pids else 0)
            and scheduled["pause_prefill"] is False
            and scheduled["finish_prefill"] is (step == 1)
            and not scheduled["cancel_prefill_ids"],
            "Actual q40 quota/P cohort/one-advance schedule differs",
        )
        sampled = dids + pids
        require(
            retired["cohort_id"] == scheduled["cohort_id"]
            and retired["original_update_returned"] is True
            and retired["cohort_before"]
            == (
                {"cohort_id": step, "pending_ids": sorted(pids), "completed_layers": 0}
                if pids
                else None
            )
            and retired["cohort_after"] is None
            and set(retired["completed_prefill_ids"]) == set(pids)
            and len(retired["completed_prefill_ids"]) == len(pids)
            and not retired["cancelled_prefill_ids"]
            and retired["layers_completed"]
            == retired["layers_total"]
            == (40 if pids else 0)
            and retired["progress_source"] == ("layer_hooks" if pids else "none")
            and len(retired["req_ids"]) == len(set(retired["req_ids"])) == len(sampled)
            and set(retired["req_ids"]) == set(sampled)
            and retired["req_id_to_index"]
            == {rid: i for i, rid in enumerate(retired["req_ids"])}
            and len(retired["sampled_token_ids"]) == len(sampled),
            "Actual completed40-layer/whole-cohort ACK/sample receipt differs",
        )
        expected_cases = order[:1] if step == 1 else order
        require(
            list(returned["requests"]) == expected_cases,
            "Actual serving request order differs",
        )
        for case in expected_cases:
            row = returned["requests"][case]
            count = step if case == SEED else step - 1
            expected_prefix = prefixes[case]["output_token_ids"][:count]
            require(
                row["internal"] == mapping[case]
                and row["status"] == "RUNNING"
                and row["tokens"] == expected_prefix
                and row["num_computed_tokens"] == len(prompts[case]) + count - 1
                and retired["sampled_token_ids"][
                    retired["req_id_to_index"][mapping[case]]
                ]
                == expected_prefix[-1:],
                "Actual input/count/prefix or worker sample differs",
            )
        decode_calls += bool(dids)
    if len(history) == 629:
        cleanup, retired = history[-2:]
        require(
            cleanup["event"] == "scheduled"
            and cleanup["step"] == 209
            and not cleanup["num_scheduled_tokens"]
            and not cleanup["prefill_ids"]
            and not cleanup["pending_prefill_ids"]
            and cleanup["cohort_id"] is None
            and not cleanup["preempted_ids"]
            and set(cleanup["finished_ids"]) == set(ids)
            and cleanup["layers_completed_before"] == cleanup["layers_total"] == 0
            and cleanup["layers_per_slice"] == 40
            and cleanup["pause_prefill"] is False
            and cleanup["finish_prefill"] is False
            and not cleanup["cancel_prefill_ids"]
            and retired
            == {
                "event": "worker-retirement",
                "step": 209,
                "cohort_id": None,
                "completed_prefill_ids": [],
                "cancelled_prefill_ids": [],
                "layers_completed": 0,
                "layers_total": 0,
                "progress_source": "none",
                "req_ids": [],
                "req_id_to_index": {},
                "sampled_token_ids": [],
                "original_update_returned": True,
                "cohort_before": None,
                "cohort_after": None,
            },
            "Unexpected post-boundary serving or cleanup activity",
        )
    before = {r["rank"]: r for r in report["worker_before"]}
    after = {r["rank"]: r for r in report["worker_after"]}
    require(
        len(report["worker_before"]) == len(report["worker_after"]) == 4
        and set(before) == set(after) == set(range(4)),
        "Graph snapshots lack four ranks",
    )
    graph_receipts = []
    for rank in range(4):
        for phase in (before, after):
            require(
                phase[rank]["runtime"]["policy"]
                == report["launch_config"]["batch_admission_policy_config"],
                "Resolved q40 worker policy differs",
            )
        a, b = (
            before[rank]["decode_graph_snapshot"],
            after[rank]["decode_graph_snapshot"],
        )
        required = {
            "enabled": True,
            "attached": True,
            "capture_started": True,
            "captured": True,
            "failed": False,
            "closed": False,
            "compile_full_prefill": False,
            "prefill_compile_profiled": False,
            "includes_startup_warmups": True,
            "captured_graph_entries": 4,
            "capture_attempts": 1,
            "capture_successes": 1,
            "capture_failures": 0,
        }
        require(
            all(a.get(k) == v and b.get(k) == v for k, v in required.items()),
            "Actual graph capture status/entries differ",
        )
        require(
            b["decode_replay_calls"] - a["decode_replay_calls"] == decode_calls == 208,
            "Actual decode graph replay count differs from serving schedule",
        )
        stable = (
            "decode_capture_forward_calls",
            "decode_eager_fallback_calls",
            "decode_uncaptured_full_calls",
            "decode_forward_failures",
            "prefill_compiled_calls",
            "prefill_compile_profile_runs",
            "prefill_compile_profile_failures",
        )
        require(
            all(a[k] == b[k] for k in stable)
            and a["decode_uncaptured_full_calls"] == a["decode_forward_failures"] == 0
            and a["prefill_compiled_calls"]
            == a["prefill_compile_profile_runs"]
            == a["prefill_compile_profile_failures"]
            == 0
            and b["prefill_forced_eager_calls"] - a["prefill_forced_eager_calls"] == 2,
            "Serving introduced eager/uncaptured/failure or extra prefill forward",
        )
        graph_receipts.append(
            {"rank": rank, "before": a, "after": b, "replay_delta": decode_calls}
        )
    return {
        "passed": True,
        "peer_prefill_advancements": 1,
        "peer_completed_layers": 40,
        "complete_prefill_ack_count": 7,
        "serving_steps": 209,
        "decode_replay_delta": decode_calls,
        "seed_only_decode_turns": 1,
        "all_eight_decode_turns": 207,
        "prefix_lengths": expected_lengths,
        "first_target_decode": {
            "step": 3,
            "target_output_position": 2,
            "seed_output_position": 3,
            "target_computed_tokens_before": len(prompts[TARGET]),
        },
        "graph_receipts": graph_receipts,
        "scope": "Actual scheduler quota and worker ACKs plus total graph replay accounting; no individual graph operator identity or new P-state equality claim.",
    }


def compare_prefixes(left, right):
    import window_analysis_core_v1 as core

    require(set(left) == set(right) and len(left) == 8, "Require all eight prefixes")
    result = core.prefix_comparison(left, right)
    for case, row in result.items():
        a, b = left[case]["output_token_ids"], right[case]["output_token_ids"]
        row["common_prefix_tokens"] = next(
            (i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b))
        )
    return result


def prefix_transparency(observed, plain):
    import analyze_early_logits_v1 as old

    result = old.same_role_bridge(observed, plain)
    result["prefixes"] = compare_prefixes(observed["prefixes"], plain["prefixes"])
    return result


def audit_attempt(directory, plan, references, source_manifest, normalized_source):
    controller = json.loads((directory / "controller.json").read_text())
    result = {"directory": str(directory), "collection_valid": False, "errors": []}
    try:
        require(
            controller.get("finished_at")
            and controller.get("terminal_process_proven") is True
            and controller.get("passed") is True
            and controller.get("exit_code") == 0
            and controller.get("owned_members_after_cleanup") == []
            and not controller.get("cleanup_required")
            and not controller.get("forced_termination")
            and controller.get("errors") == []
            and len(controller.get("expected_physical", [])) == 4
            and controller.get("idle_physical_after")
            == controller["expected_physical"],
            "Unclean or missing terminal proof; child/log deliberately not read",
        )
        return _audit_terminal(
            directory,
            controller,
            result,
            plan,
            references,
            source_manifest,
            normalized_source,
        )
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
        return result, None


def bridge_collection(value, schedule):
    """Only adapt the analysis schema after the q40 treatment/schedule gate."""
    import hashlib

    require(
        value["report"]["schema"] == "muxpd-q40-run-v1"
        and schedule.get("passed") is True,
        "q40 schema and actual schedule must pass before old-loader bridge",
    )
    report = dict(value["report"])
    report["schema"] = "muxpd-target-early-logits-run-v1"

    def digest(item):
        return hashlib.sha256(
            json.dumps(item, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()

    return {**value, "report": report}, {
        "input_schema": value["report"]["schema"],
        "output_schema": report["schema"],
        "changed_fields": ["schema"],
        "persisted_report_changed": False,
        "input_report_semantic_sha256": digest(value["report"]),
        "loader_report_semantic_sha256": digest(report),
        "scope": "In-memory report schema only; q40 policy, history, vector bytes and values are never normalized to q4.",
    }


def validate_observed_schedule(value, loaded):
    prefixes = value["prefixes"]
    order = [c["case_id"] for c in value["report"]["plan"]["cases"]]
    for position in range(2, 209):
        record = loaded["target_positions"][position]
        require(
            record["lane"] == "decode"
            and record["row"]["row"] == 3
            and record["batch_descriptor"]
            == {
                "num_tokens": 8,
                "num_reqs": 8,
                "uniform": True,
                "has_lora": False,
                "num_active_loras": 0,
            }
            and [r["case_id"] for r in record["semantic_batch"]] == order,
            "Actual target D descriptor8/row3/co-batch order differs",
        )
        for index, row in enumerate(record["semantic_batch"]):
            case = row["case_id"]
            count = position if case == SEED else position - 1
            prefix = prefixes[case]["output_token_ids"][:count]
            prompt = prefixes[case]["prompt_token_ids"]
            require(
                row["row"] == index
                and row["prompt_token_ids"] == prompt
                and row["output_prefix_token_ids"] == prefix
                and row["input_token_ids"] == prompt + prefix
                and row["scheduled_tokens"] == 1
                and row["num_computed_tokens"] == len(prompt) + count - 1
                and row["num_tokens_no_spec"] == len(prompt) + count,
                "Actual q40 target/seed/co-batch D input history differs",
            )
    return {
        "passed": True,
        "target_decode_positions": list(range(2, 209)),
        "target_row": 3,
        "batch_descriptor_tokens": 8,
        "first_target_output_position": 2,
        "first_seed_output_position": 3,
        "scope": "Actual four-rank-agreed observer inputs, not an inferred graph tensor tap.",
    }


def _audit_terminal(
    directory, controller, result, plan, references, source_manifest, normalized_source
):
    report = json.loads((directory / "results/run.json").read_text())
    require(
        controller.get("schema") == "muxpd-q40-controller-v1"
        and report.get("schema") == "muxpd-q40-run-v1"
        and report["profile"] in ("prefix-observed", "prefix-plain")
        and controller["profile"] == report["profile"],
        "Require explicit q40 controller/run/profile",
    )
    import early_logits_analysis_v1 as extra
    import new_loss_checks_v1 as checks
    import probe_run_v1 as driver
    import q40_treatment_v1 as treatment
    import window_analysis_core_v1 as core

    frozen = json.loads((directory / "producer/freeze-manifest-v1.json").read_text())
    require(
        frozen["status"] == "frozen"
        and frozen["files"] == controller["files"]
        and core.identity(directory / "producer/freeze-manifest-v1.json")["sha256"]
        == controller["freeze_manifest_sha256"],
        "Frozen q40 producer identity differs",
    )
    for name, digest in frozen["files"].items():
        require(
            core.identity(directory / "producer" / name)["sha256"] == digest
            and core.identity(Path(__file__).parent / name)["sha256"] == digest,
            f"Actual q40 producer bytes changed: {name}",
        )
    require(
        report["plan"] == plan and report["sources"] == report["sources_after_startup"],
        "Frozen plan or lifetime source receipt differs",
    )
    plugin = report["sources"]["vllm_muxpd"]
    require(
        plugin["commit"] == controller["source_commit"] == driver.SOURCE
        and plugin["status"] == plugin["diff"] == ""
        and report["source_equivalence"]
        == report["source_equivalence_after_startup"]
        == controller["source_equivalence"],
        "Clean original6c runtime source differs",
    )
    historical = source_manifest["historical_runs"][
        references["primary_by_role"]["prefix"][0]
    ]
    for name in ("vllm", "vllm_ascend"):
        require(
            normalized_source(report["sources"][name])
            == normalized_source(historical["sources"][name]),
            f"Original native source differs: {name}",
        )
    base = json.loads((directory / "producer/raw-engine-args-v1.json").read_text())
    require(
        controller["base_engine_args"] == base
        and controller["launch_engine_args"] == report["launch_config"],
        "Controller/worker q40 launch inputs differ",
    )
    treatment.validate_launch_config(report["profile"], base, report["launch_config"])
    receipt = treatment.treatment_receipt(
        report["profile"], base, report["launch_config"]
    )
    require(
        report["scheduling_treatment"] == controller["scheduling_treatment"] == receipt,
        "Declared q40 treatment does not match actual config",
    )
    expected_historical = copy.deepcopy(historical)
    require(
        expected_historical["engine_args"]["batch_admission_policy_config"][
            "layers_per_slice"
        ]
        == 4,
        "Historical source is not the declared q4 control",
    )
    expected_historical["engine_args"]["batch_admission_policy_config"][
        "layers_per_slice"
    ] = 40
    checks.validate_historical_engine(report, expected_historical)
    observed = report["profile"].endswith("observed")
    driver.validate_workers(report["worker_before"], report["profile"])
    driver.validate_workers(report["worker_after"], report["profile"], observed)
    for worker in report["worker_after"]:
        driver.require_empty_worker(worker)
    driver.require_empty(report["final_state"], report["idle_baseline"])
    require(
        report["stop_kind"]
        == "supervisor_abort_after_target_output208_not_natural_termination"
        and set(report["cancellation"]["aborted_internal_ids"])
        == {b["internal"] for a in report["admissions"] for b in a["bindings"]},
        "Boundary cutoff/cleanup ownership differs",
    )
    log = checks.audit_terminal_log(directory / "process.log")
    require(log["passed"], "Terminal worker traceback or hook ownership failure")
    checks.validate_external_observer_identity(report, directory, frozen["files"])
    layout = checks.validate_layout(report, directory)
    live = checks.validate_live_batch_boundary(report)
    history_path = directory / "results/history.jsonl"
    history = [json.loads(line) for line in history_path.read_text().splitlines()]
    schedule = validate_schedule(report, history)
    require(
        report["model_config_identity"] == plan["model_config_identity"]
        and report["tokenizer_files"]
        == {
            name: {**identity, "observed_sha256": identity["sha256"]}
            for name, identity in plan["tokenizer_files"].items()
        },
        "Pinned model/tokenizer receipts differ",
    )
    require(
        report["producer_sha256"] == frozen["files"]["probe_run_v1.py"]
        and report["plan_file_sha256"] == frozen["files"]["plan-v1.json"]
        and report["config_file_sha256"] == frozen["files"]["raw-engine-args-v1.json"],
        "Actual driver/plan/original config file identity differs",
    )
    value = core.load_attempt(directory)
    require(
        value["public"]["included_in_numerical_comparisons"]
        and value["report"] == report,
        "Actual child/vector collection failed or changed while reading",
    )
    bridged, schema_bridge = bridge_collection(value, schedule)
    profile = extra.validate_profile(bridged["report"], directory)
    loaded = None
    if observed:
        require(
            sum(bool(r["receipt"]) for r in value["decisions"].values()) == 80
            and len(report["observer_installation"]) == 4
            and {r["rank"] for r in report["observer_installation"]} == set(range(4))
            and all(r["installed"] for r in report["observer_installation"]),
            "Missing original80 vectors or four-rank numerical observer",
        )
        loaded = extra.load_extra_vectors(bridged)
        observed_schedule = validate_observed_schedule(value, loaded)
    else:
        require(
            "observer_installation" not in report
            and not value["decisions"]
            and not (directory / "results/worker-observations").exists()
            and not (directory / "results/target-extra-logits").exists()
            and not report["launch_config"].get("worker_extension_cls"),
            "Plain q40 run contains numeric observation",
        )
        observed_schedule = None
    reproduction = checks.reproduction_checks(report, references)
    require(
        report["full_run_reproduction"] == reproduction,
        "Descriptive old-trajectory reproduction receipt was rewritten",
    )
    result.update(
        collection_valid=True,
        terminal_log=log,
        layout=layout,
        live_boundary=live,
        schedule=schedule,
        observed_schedule=observed_schedule,
        schema_bridge={
            **schema_bridge,
            "unchanged_extra_loader": core.identity(Path(extra.__file__)),
        },
        extra_profile=profile,
        scheduling_treatment=receipt,
        child_sha256=core.identity(directory / "results/run.json")["sha256"],
        controller_sha256=core.identity(directory / "controller.json")["sha256"],
        history=core.identity(history_path),
        full_run_reproduction=reproduction,
        reproduction_is_admissibility_gate=False,
        reproduction_scope="Descriptive changed-policy comparison; q4 equality is not required and any original FAIL is retained.",
    )
    value["extra"] = loaded
    return result, value


def select_attempts(runs, arm):
    require(
        arm in (None, "observed"), "Only observed prerequisite or final pair is defined"
    )
    required = {"prefix-q40-observed-v1-01": "prefix-observed"}
    if arm is None:
        required["prefix-q40-plain-v1-01"] = "prefix-plain"
    actual = {p.name for p in runs.iterdir() if p.is_dir()}
    require(
        actual == set(required),
        "Require exactly declared q40 attempts; no missing arm or retry selection",
    )
    return required


def compare_runs(observed, plain, controls):
    import early_logits_analysis_v1 as extra

    transparency = prefix_transparency(observed, plain)
    require(
        transparency["passed"],
        "All-eight q40 observed/plain transparency failed; no numerical attribution",
    )
    result = {"observed_plain_transparency": transparency}
    for label, profile in (("native", "native-observed"), ("q4", "prefix-observed")):
        control = controls[profile]
        result[f"target_vs_{label}"] = extra.compare_target_positions(
            control["extra"], observed["extra"]
        )
        result[f"prefixes_vs_{label}"] = compare_prefixes(
            control["prefixes"], observed["prefixes"]
        )
        co_batches = []
        for position in range(1, 209):
            a = {
                r["case_id"]: r
                for r in control["extra"]["target_positions"][position][
                    "semantic_batch"
                ]
            }
            b = {
                r["case_id"]: r
                for r in observed["extra"]["target_positions"][position][
                    "semantic_batch"
                ]
            }
            co_batches.append(
                {
                    "position_one_based": position,
                    "different_case_ids": sorted(
                        case
                        for case in a.keys() | b.keys()
                        if a.get(case) != b.get(case)
                    ),
                    "left_only_case_ids": sorted(a.keys() - b.keys()),
                    "right_only_case_ids": sorted(b.keys() - a.keys()),
                    "changed_common_case_ids": sorted(
                        case for case in a.keys() & b.keys() if a[case] != b[case]
                    ),
                    "same_case_order": list(a) == list(b),
                    "left_case_order": list(a),
                    "right_case_order": list(b),
                }
            )
        result[f"target_vs_{label}"]["co_batch_differences"] = co_batches
    result["scope"] = (
        "Supported quota scheduling counterfactual; distances only at matched actual target inputs. "
        "Co-batch histories and P/D overlap timing may differ. No new P-state equality, operator cause, complete-answer repair or performance claim."
    )
    return result


def verify_references(bundle):
    import window_analysis_core_v1 as core

    refs = json.loads((bundle / "q40-references-v1.json").read_text())
    require(
        refs["schema"] == "muxpd-q40-references-v1"
        and set(refs["early_runs"]) == {"native", "prefix"},
        "Wrong qualified early reference schema",
    )
    # Terminal proof is read before any referenced child, log or vector file.
    terminals = {}
    for role, directory in refs["early_runs"].items():
        path = Path(directory) / "controller.json"
        controller = json.loads(path.read_text())
        require(
            controller.get("finished_at")
            and controller.get("terminal_process_proven") is True
            and controller.get("passed") is True
            and controller.get("exit_code") == 0
            and controller.get("owned_members_after_cleanup") == []
            and controller.get("errors") == []
            and not controller.get("cleanup_required")
            and not controller.get("forced_termination")
            and len(controller.get("expected_physical", [])) == 4
            and controller.get("idle_physical_after")
            == controller["expected_physical"],
            f"Qualified early {role} not clean terminal; child evidence not read",
        )
        terminals[role] = core.identity(path)
    for path, digest in refs["files"].items():
        require(
            core.identity(Path(path))["sha256"] == digest,
            f"Qualified early reference bytes changed: {path}",
        )
    proof = {}
    for name in ("early_primary", "early_independent", "treatment_profile"):
        entry = refs[name]
        require(
            core.identity(Path(entry["path"]))["sha256"] == entry["sha256"],
            f"{name} bytes changed",
        )
        proof[name] = entry
    primary = json.loads(Path(refs["early_primary"]["path"]).read_text())
    independent = json.loads(Path(refs["early_independent"]["path"]).read_text())
    require(
        primary["passed"] is True
        and primary["localization_allowed"] is True
        and primary["errors"] == []
        and independent["passed"] is True,
        "Both primary and independent early qualification are required",
    )
    attempts = {r["directory"]: r for r in primary["attempts"]}
    old = Path(refs["early_protocol"])
    frozen = json.loads((old / "freeze-manifest-v1.json").read_text())
    require(frozen["status"] == "frozen", "Early control producer was not frozen")
    for name, digest in frozen["files"].items():
        require(
            core.identity(old / name)["sha256"] == digest,
            f"Early producer changed: {name}",
        )
        if name not in ("probe_run_v1.py", "probe_control_v1.py", "run-matrix-v1.json"):
            require(
                core.identity(bundle / name)["sha256"] == digest,
                f"Unchanged old loader/observer/input changed: {name}",
            )
    for role, directory in refs["early_runs"].items():
        path = Path(directory)
        require(
            attempts[directory]["collection_valid"]
            and attempts[directory]["reproduction_passed"]
            and attempts[directory]["child_sha256"]
            == core.identity(path / "results/run.json")["sha256"],
            "Early child no longer matches qualified primary result",
        )
        controller = json.loads((path / "controller.json").read_text())
        require(
            controller["profile"] == f"{role}-observed"
            and controller["files"] == frozen["files"],
            "Qualified early profile/producer differs",
        )
        for name, digest in frozen["files"].items():
            require(
                core.identity(path / "producer" / name)["sha256"] == digest,
                f"Control producer copy changed: {role}/{name}",
            )
    return refs, {
        "passed": True,
        **proof,
        "reference_file": core.identity(bundle / "q40-references-v1.json"),
        "control_terminals": terminals,
        "scope": "Pinned qualified early controls; their values are not q40 admissibility targets.",
    }


def load_controls(refs):
    import early_logits_analysis_v1 as extra
    import window_analysis_core_v1 as core

    controls = {}
    for role, directory in refs["early_runs"].items():
        value = core.load_attempt(Path(directory))
        require(
            value["public"]["included_in_numerical_comparisons"],
            "Qualified control vector collection failed",
        )
        value["extra"] = extra.load_extra_vectors(value)
        controls[f"{role}-observed"] = value
    return controls
