"""CPU-only reproduction and terminal lifecycle gates for the late window."""

import json
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def first_difference(left, right):
    for index, (a, b) in enumerate(zip(left, right)):
        if a != b:
            return {"one_based_position": index + 1, "observed": a, "historical": b}
    if len(left) != len(right):
        return {
            "one_based_position": min(len(left), len(right)) + 1,
            "kind": "length_mismatch",
        }
    return None


def reproduction_checks(report, references):
    role = report["profile"].split("-")[0]
    current = report["prefixes_before_abort"]
    expected_ids = [case["case_id"] for case in report["plan"]["cases"]]
    comparisons = {}
    for label, baseline in references["references"].items():
        cases = {}
        for rid in expected_ids:
            actual = current.get(rid, {}).get("output_token_ids", [])
            old = baseline[rid]["token_ids"]
            cases[rid] = {
                "observed_tokens": len(actual),
                "historical_full_tokens": baseline[rid]["full_output_tokens"],
                "at_least208": len(actual) >= 208,
                "exact_first208": len(actual) >= 208 and actual[:208] == old[:208],
                "entire_retained_prefix_equal": len(actual) <= len(old)
                and actual == old[: len(actual)],
                "first_difference": first_difference(actual, old[: len(actual)]),
            }
        comparisons[label] = {
            "cases": cases,
            "passed": set(current) == set(expected_ids)
            and all(
                row["at_least208"]
                and row["exact_first208"]
                and row["entire_retained_prefix_equal"]
                for row in cases.values()
            ),
        }
    required = references["primary_by_role"][role]
    return {
        "role": role,
        "required_full_run_references": required,
        "comparisons": comparisons,
        "passed": all(comparisons[label]["passed"] for label in required),
        "scope": "All eight full-run trajectories through208 plus full retained seed prefix. Fresh batch7 lacks preceding seven batches; a failure blocks localization, never retargets.",
    }


def audit_terminal_log(path):
    from probe_run_v1 import file_sha

    data = Path(path).read_bytes()
    lines = data.decode(errors="replace").splitlines()
    tracebacks = [index + 1 for index, line in enumerate(lines) if "Traceback" in line]
    ownership = [
        index + 1
        for index, line in enumerate(lines)
        if any(
            value in line
            for value in (
                "MuxPD graph method changed externally",
                "Layout slots changed externally",
                "Layout original method slots were not restored",
            )
        )
    ]
    return {
        "sha256": file_sha(path),
        "bytes": len(data),
        "traceback_line_numbers": tracebacks,
        "ownership_error_line_numbers": ownership,
        "passed": not (tracebacks or ownership),
        "scope": "Terminal worker traceback/ownership gate, separate from reproducibility and process cleanup.",
    }


def validate_layout(report, directory):
    import prefill_collective_layout_v1 as layout

    prefix = report["profile"].startswith("prefix-")
    fields = (
        "layout_installation",
        "layout_final",
        "layout_uninstall",
        "layout_module_sha256",
    )
    if not prefix:
        require(
            all(field not in report for field in fields), "Native run installed layout"
        )
        return {"enabled": False}
    digest = report["layout_module_sha256"]
    require(
        digest == "6431c4c0abdd869ef17e7122f681c457ad2b4d5741f86c6a0653e9fca44e02fc",
        "Not the frozen external prefix module",
    )
    layout.validate_receipts(
        report["layout_installation"],
        digest,
        mode="prefix",
        expected_treated_cohorts=0,
        expected_completed=0,
    )
    layout.validate_receipts(
        report["layout_final"],
        digest,
        mode="prefix",
        expected_treated_cohorts=1,
        expected_completed=2,
    )
    layout.validate_uninstall_receipts(
        report["layout_uninstall"], digest, mode="prefix"
    )
    scheduled = [
        row
        for row in map(
            json.loads,
            (Path(directory) / "results/history.jsonl").read_text().splitlines(),
        )
        if row["event"] == "scheduled" and row["prefill_ids"]
    ]
    require(len(scheduled) == 2, "Expected two actual P admissions")
    for rank in report["layout_final"]:
        seed, peers = rank["cohorts"]
        require(
            seed["d_rows"] == 0
            and seed["zero_d_bypass_calls"] == 81
            and not seed["calls"]
            and peers["d_rows"] > 0
            and len(peers["calls"]) == 81
            and peers["zero_d_bypass_calls"] == 0,
            "Expected exactly81 TP reductions for each original full prefill",
        )
        for record, schedule in zip(rank["cohorts"], scheduled, strict=True):
            counts = schedule["num_scheduled_tokens"]
            p = set(schedule["prefill_ids"])
            require(
                record["admission_p_counts"]
                == {rid: n for rid, n in counts.items() if rid in p}
                and record["admission_d_counts"]
                == {rid: n for rid, n in counts.items() if rid not in p}
                and record["cohort_id"] == schedule["cohort_id"],
                "Frozen D/P counts differ from actual scheduler admission",
            )
    return {"enabled": True, "four_rank_install_final_restore": True}


def validate_historical_engine(report, historical):
    """Compare launch inputs plus actual resolved defaults written by old LLM init."""
    import copy

    actual = copy.deepcopy(report["launch_config"])
    actual.pop("worker_extension_cls", None)
    expected = copy.deepcopy(historical["engine_args"])
    backend = expected["additional_config"]["ascend_compilation_config"]
    resolved = {
        name: backend.pop(name)
        for name in ("fuse_norm_quant", "fuse_qknorm_rope", "fuse_muls_add")
    }
    require(actual == expected, "Original role launch inputs changed")
    for phase in ("worker_before", "worker_after"):
        require(
            all(row["runtime"]["resolved_fusion"] == resolved for row in report[phase]),
            "Actual fusion defaults differ from original full run",
        )


def validate_external_observer_identity(report, directory, frozen_files):
    observed = report["profile"].endswith("observed")
    modules = ("window_numeric_diagnostics_v1", "window_numeric_workers_v1")
    for phase in ("worker_before", "worker_after"):
        for row in report[phase]:
            expected = (
                {
                    name: {
                        "path": str(
                            (Path(directory) / "producer" / (name + ".py")).resolve()
                        ),
                        "sha256": frozen_files[name + ".py"],
                    }
                    for name in modules
                }
                if observed
                else {}
            )
            require(
                row["external_observer_modules"] == expected,
                "Worker imported external observer from an unexpected path or bytes",
            )


def validate_live_batch_boundary(report):
    mapping = {
        entry["case_id"]: entry["internal"]
        for admission in report["admissions"]
        for entry in admission["bindings"]
    }
    require(
        set(report["state_before_abort"]["request_ids"]) == set(mapping.values())
        and len(mapping) == 8
        and report["natural_completions"] == []
        and all(
            row["num_preemptions"] == 0
            for row in report["prefixes_before_abort"].values()
        ),
        "Fresh probe changed the live eight-request boundary before target208",
    )
    return {
        "all_eight_live_before_abort": True,
        "natural_completions": 0,
        "preemptions": 0,
    }
