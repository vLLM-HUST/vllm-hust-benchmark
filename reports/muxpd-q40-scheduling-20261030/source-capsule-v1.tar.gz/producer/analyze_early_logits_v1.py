"""Terminal-only batch7 reproduction and late-window numerical diagnostics."""

import argparse
import json
import re
from pathlib import Path

import analyze_new_loss_v1 as legacy
import early_logits_analysis_v1 as extra
import source_adapter_v2 as adapter
import window_analysis_core_v1 as core
from new_loss_checks_v1 import (
    audit_terminal_log,
    reproduction_checks,
    require,
    validate_external_observer_identity,
    validate_historical_engine,
    validate_layout,
    validate_live_batch_boundary,
)
from probe_run_v1 import (
    PROFILES,
    SOURCE,
    file_sha,
    load_plan,
    require_empty_worker,
    validate_workers,
)


def normalized_source(value):
    return {
        "path": value["path"],
        "commit": value["commit"],
        "status": value["status"].strip(),
        "diff": value.get("diff", value.get("diff_bytes_utf8")),
        "module_sha256": value.get("module_sha256", value.get("sha256")),
    }


def verify_historical_references(bundle):
    manifest = json.loads((bundle / "source-manifest-v1.json").read_text())
    for path, digest in manifest["original_inputs"].items():
        require(file_sha(path) == digest, "Original frozen quality inputs changed")
    context = manifest["context"]
    require(
        file_sha(context["path"]) == context["sha256"], "Original loss context changed"
    )
    references = json.loads((bundle / "historical-prefixes-v1.json").read_text())
    for label, reference in manifest["historical_runs"].items():
        directory = Path(reference["directory"])
        controller = json.loads((directory / "controller.json").read_text())
        require(
            controller.get("finished_at")
            and controller.get("exit_code") == 0
            and controller.get("passed"),
            f"Historical source not terminal: {label}",
        )
        for name, identity in reference["files"].items():
            require(
                file_sha(directory / name) == identity["sha256"]
                and (directory / name).stat().st_size == identity["bytes"],
                f"Frozen historical bytes changed: {label}/{name}",
            )
        report = json.loads((directory / "results/run.json").read_text())
        outputs = {row["case_id"]: row for row in report["outputs"]}
        for case, retained in references["references"][label].items():
            row = outputs[case]
            require(
                row["finished"]
                and retained["token_ids"]
                == row["token_ids"][: references["prefix_limit"]]
                and retained["full_output_tokens"] == len(row["token_ids"])
                and retained["finish_reason"] == row["finish_reason"],
                "Frozen trajectory extraction differs from original terminal output",
            )
    return manifest


def audit_attempt(directory, plan, references, source_manifest):
    controller = json.loads((directory / "controller.json").read_text())
    result = {
        "directory": str(directory),
        "terminal": bool(controller.get("finished_at")),
        "collection_valid": False,
        "errors": [],
        "reproduction_passed": False,
    }
    if not result["terminal"]:
        result["errors"].append("Nonterminal; child/log deliberately not read")
        return result, None
    try:
        require(
            controller.get("passed") is True
            and controller.get("exit_code") == 0
            and controller.get("terminal_process_proven") is True
            and controller.get("owned_members_after_cleanup") == []
            and not controller.get("cleanup_required")
            and not controller.get("forced_termination")
            and controller.get("errors") == [],
            "Controller cleanup/lifecycle failed",
        )
        log = audit_terminal_log(directory / "process.log")
        require(log["passed"], "Worker traceback/ownership gate failed")
        value = core.load_attempt(directory)
        require(
            value["public"]["included_in_numerical_comparisons"],
            "Native sampling/vector/child receipts failed",
        )
        report = value["report"]
        profile = report["profile"]
        require(
            profile in PROFILES and report["plan"] == plan,
            "Wrong profile or frozen plan",
        )
        require(
            report["sources"] == report["sources_after_startup"],
            "Sources changed across startup",
        )
        plugin = report["sources"]["vllm_muxpd"]
        require(
            plugin["commit"] == SOURCE
            and plugin["status"] == ""
            and plugin["diff"] == "",
            "Require clean6c diagnostic source",
        )
        role = profile.split("-")[0]
        historical = source_manifest["historical_runs"][
            references["primary_by_role"][role][0]
        ]
        for name in ("vllm", "vllm_ascend"):
            require(
                normalized_source(report["sources"][name])
                == normalized_source(historical["sources"][name]),
                f"Original native source receipt differs: {name}",
            )
        validate_historical_engine(report, historical)
        observed = profile.endswith("observed")
        validate_workers(report["worker_before"], profile)
        validate_workers(report["worker_after"], profile, observed)
        for worker in report["worker_after"]:
            require_empty_worker(worker)
        extra_profile = extra.validate_profile(report, directory)
        if observed:
            require(
                report["launch_config"].get("worker_extension_cls")
                == "window_numeric_workers_v1.NumericalObserverExtension",
                "Wrong window observer",
            )
            require(
                sum(bool(x["receipt"]) for x in value["decisions"].values()) == 80,
                "Expected exactly80 selected full-vocabulary vectors",
            )
            require(
                {x["rank"] for x in report["observer_installation"]} == set(range(4))
                and len(report["observer_installation"]) == 4
                and all(x["installed"] for x in report["observer_installation"]),
                "Missing four-rank numerical observer installation",
            )
        else:
            require(
                "observer_installation" not in report
                and not value["decisions"]
                and not (directory / "results/worker-observations").exists()
                and not report["launch_config"].get("worker_extension_cls"),
                "Plain run contains observation",
            )
        layout = validate_layout(report, directory)
        live_boundary = validate_live_batch_boundary(report)
        frozen = json.loads(
            (directory / "producer/freeze-manifest-v1.json").read_text()
        )
        require(
            frozen["status"] == "frozen"
            and frozen["files"] == controller["files"]
            and file_sha(directory / "producer/freeze-manifest-v1.json")
            == controller["freeze_manifest_sha256"],
            "Frozen producer identity differs",
        )
        for name, digest in frozen["files"].items():
            require(
                file_sha(directory / "producer" / name) == digest,
                f"Producer changed: {name}",
            )
        validate_external_observer_identity(report, directory, frozen["files"])
        require(
            report["model_config_identity"] == plan["model_config_identity"],
            "Model configuration identity differs",
        )
        require(
            report["tokenizer_files"]
            == {
                name: {**identity, "observed_sha256": identity["sha256"]}
                for name, identity in plan["tokenizer_files"].items()
            },
            "Actual tokenizer input receipts differ from pinned inputs",
        )
        require(
            report["producer_sha256"] == frozen["files"]["probe_run_v1.py"]
            and report["plan_file_sha256"] == frozen["files"]["plan-v1.json"]
            and report["config_file_sha256"]
            == frozen["files"][
                "native-engine-args-v1.json"
                if role == "native"
                else "raw-engine-args-v1.json"
            ],
            "Actual producer/plan/config input identity differs from frozen bytes",
        )
        reproduction = reproduction_checks(report, references)
        require(
            report["full_run_reproduction"] == reproduction,
            "Declared reproduction differs from actual prefixes",
        )
        result.update(
            collection_valid=True,
            reproduction_passed=reproduction["passed"],
            full_run_reproduction=reproduction,
            terminal_log=log,
            layout=layout,
            live_boundary=live_boundary,
            extra_profile=extra_profile,
            child_sha256=file_sha(directory / "results/run.json"),
        )
        return result, value
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
        return result, None


def same_role_bridge(observed, plain):
    a, b = observed["report"], plain["report"]
    prefixes = core.prefix_comparison(observed["prefixes"], plain["prefixes"])
    configs = [
        {
            k: v
            for k, v in report["launch_config"].items()
            if k != "worker_extension_cls"
        }
        for report in (a, b)
    ]
    checks = {
        "same_frozen_plan": a["plan"] == b["plan"],
        "same_role": a["profile"].split("-")[0] == b["profile"].split("-")[0],
        "same_engine_config": configs[0] == configs[1],
        "same_source_receipts": a["sources"] == b["sources"],
        "all_eight_complete_prefixes": len(prefixes) == 8
        and all(x["exact_equal"] for x in prefixes.values()),
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "prefixes": prefixes,
        "scope": "Full retained prefix equality, including seed progress beyond208; not just selected-window tokens.",
    }


def materialized_decision(collection, key):
    """Load the frozen NPY for every captured case, not only core's two caches."""
    decision = collection["decisions"][key]
    receipt = decision["receipt"]
    directory = collection["directory"] / "results/worker-observations"
    filename = receipt["file"]
    require(
        isinstance(filename, str)
        and Path(filename).name == filename
        and filename not in ("", ".", ".."),
        "Logit filename is unsafe",
    )
    path = directory / filename
    require(
        path.resolve().parent == directory.resolve() and not path.is_symlink(),
        "Logit file escapes evidence directory",
    )
    identity = core.identity(path)
    require(
        identity["sha256"] == receipt["sha256"]
        and identity["size_bytes"] == receipt["bytes"],
        "Logit SHA/size differs from actual captured file",
    )
    values = core.np.load(path, allow_pickle=False, mmap_mode="r")
    require(
        list(values.shape)
        == receipt["shape"]
        == [collection["report"]["plan"]["expected_vocabulary_size"]]
        and str(values.dtype) == receipt["dtype"] == "float32",
        "Logit shape/dtype differs from actual captured file",
    )
    return {**decision, "values": values}


def observed_bridge(current, control):
    base = same_role_bridge(current, control)
    expected = {
        (case["case_id"], pos - 1)
        for case in current["report"]["plan"]["cases"]
        for pos in current["report"]["plan"]["capture_token_indices_one_based"]
    }
    vectors = []
    selected = [
        {
            key: decision
            for key, decision in value["decisions"].items()
            if decision["receipt"]
        }
        for value in (current, control)
    ]
    complete = set(selected[0]) == set(selected[1]) == expected and len(expected) == 80
    if complete:
        for cid, step in sorted(expected):
            row = core.vector_comparison(
                materialized_decision(current, (cid, step)),
                materialized_decision(control, (cid, step)),
            )
            vectors.append({"case_id": cid, "position_one_based": step + 1, **row})
    vector_passed = complete and all(
        row["logits_byte_equal"]
        and row["strict_full_context_match"]
        and row["left_sampled_token_ids"] == row["right_sampled_token_ids"]
        for row in vectors
    )
    return {
        **base,
        "passed": base["passed"] and vector_passed,
        "complete_80_vectors": complete,
        "vectors_passed": vector_passed,
        "vectors": vectors,
        "scope": "All80 full vocabulary bytes and contexts plus entire8 retained prefixes against historical same-role observed control. Controls span time/physical allocation; no fresh paired plain claim.",
    }


def terminal_reference(directory):
    controller = json.loads((directory / "controller.json").read_text())
    require(
        controller.get("finished_at")
        and controller.get("passed") is True
        and controller.get("exit_code") == 0
        and controller.get("terminal_process_proven") is True
        and controller.get("owned_members_after_cleanup") == []
        and not controller.get("errors"),
        "Reference not terminal and successful; child/log not read",
    )
    return controller


def load_controls(bundle, plan, references, sources):
    record = json.loads((bundle / "control-references-v1.json").read_text())
    for name, item in record["attempts"].items():
        directory = Path(item["directory"])
        terminal_reference(directory)
        actual_names = sorted(
            str(p.relative_to(directory)) for p in directory.rglob("*") if p.is_file()
        )
        require(
            actual_names == sorted(item["files"]), f"Reference file set changed: {name}"
        )
        for filename, digest in item["files"].items():
            require(
                file_sha(directory / filename) == digest,
                f"Reference evidence changed: {name}/{filename}",
            )
    for path, digest in record["evidence"].items():
        require(file_sha(path) == digest, f"Qualified reference changed: {path}")
    for key in (
        "old_analysis",
        "old_independent",
        "b_plain_analysis",
        "b_plain_independent",
    ):
        result = json.loads(Path(record[key]).read_text())
        require(
            result.get("passed") is True, f"Historical qualification not passed: {key}"
        )
    legacy.normalized_source = normalized_source
    legacy.PROFILES = (
        "native-observed",
        "native-plain",
        "prefix-observed",
        "prefix-plain",
    )
    controls, audits, bridges = {}, {}, {}
    for profile in legacy.PROFILES:
        checked, value = legacy.audit_attempt(
            Path(record["attempts"][profile]["directory"]), plan, references, sources
        )
        require(
            checked["collection_valid"] and checked["reproduction_passed"],
            f"Historical control failed audit: {profile}: {checked['errors']}",
        )
        audits[profile], controls[profile] = checked, value
    for role in ("native", "prefix"):
        bridges[role] = legacy.same_role_bridge(
            controls[role + "-observed"], controls[role + "-plain"]
        )
        require(
            bridges[role]["passed"], f"Original observed/plain bridge failed: {role}"
        )
    b_directory = Path(record["attempts"]["b-plain"]["directory"])
    b_report = json.loads((b_directory / "results/run.json").read_text())
    require(
        b_report.get("passed")
        and b_report.get("collection_complete")
        and b_report.get("shutdown_returned")
        and not b_report.get("errors"),
        "B plain child invalid",
    )
    require(
        b_report["profile"] == "first-mixed-plain-v1"
        and b_report["plan"]["cases"] == plan["cases"]
        and b_report["plan"]["target_generated_tokens"]
        == plan["target_generated_tokens"],
        "B plain frozen cases/boundary differ",
    )
    return (
        controls,
        b_report["prefixes_before_abort"],
        {
            "audits": audits,
            "historical_observed_plain_bridges": bridges,
            "references_sha256": file_sha(bundle / "control-references-v1.json"),
        },
    )


def verify_failure_lineage(bundle):
    lineage = json.loads((bundle / "failure-lineage-v2.json").read_text())
    previous = Path(lineage["previous_attempt"])
    controller = json.loads((previous / "controller.json").read_text())
    require(
        controller.get("finished_at")
        and controller.get("terminal_process_proven") is True
        and controller.get("owned_members_after_cleanup") == [],
        "Previous failed protocol not terminal; child/log not read",
    )
    preflight = Path(lineage["runtime_import_directory"])
    imported = json.loads((preflight / "controller.json").read_text())
    require(
        imported.get("finished_at")
        and imported.get("passed") is True
        and imported.get("exit_code") == 0
        and imported.get("owned_after") == []
        and imported.get("errors") == [],
        "Runtime import preflight not terminal",
    )
    for path, digest in lineage["files"].items():
        require(
            file_sha(path) == digest,
            "Preserved failure/import evidence changed: " + path,
        )
    require(
        controller.get("passed") is False
        and controller.get("exit_code") == -9
        and controller.get("timeout") is True
        and controller.get("forced_termination") is True
        and controller.get("cleanup_required") is True,
        "Previous failure disposition changed",
    )
    saved = json.loads((previous / "results/run.json").read_text())
    require(
        saved.get("admissions") == []
        and saved.get("collection_complete") is False
        and saved.get("shutdown_returned") is False
        and "layer_hook_installation" not in saved,
        "Previous pre-admission failure state changed",
    )
    text = (previous / "process.log").read_text()
    ranks = {
        int(match.group(1))
        for line in text.splitlines()
        if "Survey requires original bound method: forward" in line
        for match in [re.search(r"Worker_TP([0-3])_EP", line)]
        if match
    }
    require(ranks == set(range(4)), "Prior allfour decoder-binding errors not retained")
    require(
        not Path(lineage["previous_prefix_absent"]).exists(),
        "Undeclared v1 prefix attempt exists",
    )
    require(
        json.loads(Path(lineage["previous_analysis"]).read_text()).get("passed")
        is False,
        "Original primary failure was not preserved",
    )
    binding = json.loads((preflight / "bindings.json").read_text())
    require(
        binding.get("passed") is True
        and binding.get("npu_python_initialized_flag") is False
        and binding.get("vllm_version_override") == "0.25.1"
        and binding.get("prior_frozen_decoder_expectation_matches") is False
        and len(binding.get("bindings", {})) == 8
        and all(
            row.get("identity_matches_expected") is True
            for row in binding["bindings"].values()
        ),
        "Actual runtime import-only source qualification differs",
    )
    require(
        binding["bindings"]["decoder_forward"]["module"]
        == "vllm_ascend.patch.worker.patch_qwen3_5"
        and binding["bindings"]["decoder_forward"]["qualname"]
        == "AscendQwen3_5DecoderLayer.forward",
        "Actual Ascend decoder binding differs",
    )
    for row in binding["bindings"].values():
        require(
            file_sha(row["path"]) == row["sha256"],
            "Runtime import method source bytes changed",
        )
    frozen = json.loads(
        (Path(lineage["previous_protocol"]) / "freeze-manifest-v1.json").read_text()
    )
    for name, digest in frozen["files"].items():
        require(
            file_sha(Path(lineage["previous_protocol"]) / name) == digest,
            "Previous frozen producer changed: " + name,
        )
    return {
        "passed": True,
        "lineage_sha256": file_sha(bundle / "failure-lineage-v2.json"),
        "previous_failed_protocol": lineage["previous_protocol"],
        "previous_failed_attempt": str(previous),
        "all_four_source_errors_preserved": True,
        "runtime_import_bindings": binding,
        "scope": lineage["numerical_scope"],
    }


def verify_state_references(bundle):
    refs = json.loads((bundle / "state-references-v1.json").read_text())
    imported_dir = Path(refs["runtime_import_directory"])
    imported = json.loads((imported_dir / "controller.json").read_text())
    require(
        imported.get("finished_at")
        and imported.get("passed") is True
        and imported.get("terminal_process_proven") is True
        and imported.get("exit_code") == 0
        and imported.get("owned_after") == []
        and imported.get("errors") == []
        and imported.get("forced_cleanup") is False,
        "State import evidence is not clean terminal",
    )
    for directory in refs["qualified_moe_attempts"].values():
        terminal_reference(Path(directory))
    for path, sha in refs["files"].items():
        require(
            file_sha(path) == sha, "Qualified state reference bytes changed: " + path
        )
    primary = json.loads(Path(refs["qualified_moe_analysis"]).read_text())
    independent = json.loads(Path(refs["qualified_moe_independent"]).read_text())
    tensors = [
        t for rank in primary["rank_comparisons"] for t in rank["tensors"].values()
    ]
    require(
        primary.get("passed") is True
        and primary.get("localization_allowed") is True
        and primary.get("all_160_target_tensors_numeric_equal") is True
        and len(tensors) == 160
        and all(t["npy_byte_equal"] and t["unequal_entries"] == 0 for t in tensors)
        and independent.get("passed") is True
        and independent.get("all160_numeric_equal") is True
        and len(independent["layer_tensor_pairs"]) == 160
        and all(
            t["unequal_entries"] == 0 and t["left_sha256"] == t["right_sha256"]
            for t in independent["layer_tensor_pairs"]
        ),
        "Prior all40 MoE boundary qualification differs",
    )
    for role, directory in refs["qualified_moe_attempts"].items():
        require(
            file_sha(Path(directory) / "results/run.json")
            == independent["current_children"][role],
            "Prior independent child identity differs",
        )
    previous = Path(refs["qualified_moe_protocol"])
    frozen = json.loads((previous / "freeze-manifest-v1.json").read_text())
    require(frozen.get("status") == "frozen", "Prior MoE producer is not frozen")
    for name, sha in frozen["files"].items():
        require(file_sha(previous / name) == sha, "Prior MoE producer changed: " + name)
    binding = json.loads((imported_dir / "bindings.json").read_text())
    require(
        binding.get("passed") is True
        and binding.get("npu_python_initialized_flag") is False
        and binding.get("vllm_version_override") == "0.25.1"
        and binding.get("release_selector") is True
        and binding.get("patch_release_selector") is True
        and binding.get("build_device_type") == "A2"
        and binding.get("device_operator_is_base_adaptor") is True
        and binding.get("attention_forward_includes_kv_update") is True
        and len(binding.get("bindings", {})) == refs["expected_binding_count"] == 17
        and all(
            v.get("identity_matches_expected") is True
            for v in binding["bindings"].values()
        )
        and binding["slot_mapping_kernel"]["same_upstream_kernel_object"] is True
        and binding["npu_format"]["original_op_is_registered_get_npu_format"] is True
        and binding["npu_format"]["nd_enum_value"] == 2,
        "Actual state runtime import identity differs",
    )
    for path, sha in binding["source_files"].items():
        require(file_sha(path) == sha, "State actual runtime source bytes changed")
    return {
        "passed": True,
        "references_sha256": file_sha(bundle / "state-references-v1.json"),
        "previous_all160_hidden_bytes_equal": True,
        "runtime_import_binding_count": len(binding["bindings"]),
        "runtime_import_bindings_sha256": file_sha(imported_dir / "bindings.json"),
        "scope": refs["scope"],
    }


def verify_early_references(bundle):
    refs = json.loads((bundle / "early-references-v1.json").read_text())
    for directory in refs["attempts"].values():
        terminal_reference(Path(directory))
    for path, digest in refs["files"].items():
        require(file_sha(path) == digest, "Qualified state reference changed: " + path)
    delta = refs["observer_delta"]
    proof = json.loads(Path(delta["proof"]).read_text())
    require(
        proof.get("passed") is True
        and proof["old_module"] == delta["old_module"]
        and proof["new_module"] == delta["new_module"],
        "Current observer adaptation proof differs",
    )
    for key in ("old_module", "new_module"):
        require(
            file_sha(delta[key]["path"]) == delta[key]["sha256"],
            "Observer before/after source changed",
        )
    for path, digest in proof["runtime_source_context_static_only"].items():
        require(file_sha(path) == digest, "Original sampler runtime source changed")
    primary = json.loads(Path(refs["primary"]).read_text())
    independent = json.loads(Path(refs["independent"]).read_text())
    tensors = [
        v for rank in primary["rank_comparisons"] for v in rank["tensors"].values()
    ]
    require(
        primary.get("passed") is True
        and primary.get("localization_allowed") is True
        and primary.get("all_320_target_states_byte_equal") is True
        and primary.get("all_320_target_states_numeric_equal") is True
        and len(tensors) == 320
        and all(
            t["canonical_value_bytes_equal"] and t["unequal_entries"] == 0
            for t in tensors
        )
        and independent.get("passed") is True
        and independent.get("all320_numeric_equal") is True
        and independent.get("all320_canonical_bytes_equal") is True
        and len(independent["logical_state_pairs"]) == 320
        and all(
            t["canonical_value_bytes_equal"] and t["unequal_entries"] == 0
            for t in independent["logical_state_pairs"]
        ),
        "Prior state boundary qualification differs",
    )
    for role, directory in refs["attempts"].items():
        require(
            file_sha(Path(directory) / "results/run.json")
            == independent["current_children"][role],
            "Prior state child identity differs",
        )
    protocol = Path(refs["protocol"])
    frozen = json.loads((protocol / "freeze-manifest-v1.json").read_text())
    require(
        frozen.get("status") == "frozen"
        and file_sha(protocol / "freeze-manifest-v1.json")
        == independent["freeze_manifest_sha256"],
        "Prior state freeze differs",
    )
    for name, digest in frozen["files"].items():
        require(
            file_sha(protocol / name) == digest,
            "Prior frozen state producer changed: " + name,
        )
    return {
        "passed": True,
        "references_sha256": file_sha(bundle / "early-references-v1.json"),
        "prior_all320_states_byte_equal": True,
        "scope": refs["scope"],
    }


def analyze(runs, bundle, output, role=None):
    global normalized_source
    require(not output.exists(), "Refuse to overwrite previous analysis")
    plan = load_plan(bundle / "plan-v1.json")
    result = {
        "schema": "muxpd-target-early-logits-analysis-v1",
        "passed": False,
        "localization_allowed": False,
        "attempts": [],
        "errors": [],
        "analysis_role": role,
        "quality_gate": "NOT_TESTED",
        "scope": "Target07338 complete output logits1..208; only matched target histories permit numerical comparison. No quality repair or performance qualification.",
        "plan_sha256": plan["plan_sha256"],
    }
    try:
        result["previous_failure_and_runtime_import"] = verify_failure_lineage(bundle)
        result["qualified_moe_and_state_import"] = verify_state_references(bundle)
        result["qualified_state_and_lineage"] = verify_early_references(bundle)
        normalized_source, proof = adapter.prepare_adapter()
        result["source_receipt_adapter"] = proof
        references = json.loads((bundle / "historical-prefixes-v1.json").read_text())
        sources = verify_historical_references(bundle)
        controls, b_prefixes, control_audit = load_controls(
            bundle, plan, references, sources
        )
        result["historical_controls"] = control_audit
        required = (role + "-observed",) if role else PROFILES
        declared = {
            f"{r}-target-early-logits-observed-v1-01": r + "-observed"
            for r in ("native", "prefix")
            if role is None or r == role
        }
        candidates = [p for p in sorted(runs.iterdir()) if p.is_dir()]
        if role:
            # A single-role gate never ignores attempts for that role; the other
            # one is allowed only under its exact declared name.
            candidates = [
                p
                for p in candidates
                if p.name
                != ("prefix" if role == "native" else "native")
                + "-target-early-logits-observed-v1-01"
            ]
        require(
            {p.name for p in candidates} == set(declared),
            "Require exactly predeclared attempt names; no retry selection",
        )
        values, audits = {}, {}
        for directory in candidates:
            checked, value = audit_attempt(directory, plan, references, sources)
            result["attempts"].append(checked)
            require(
                checked["collection_valid"]
                and checked["reproduction_passed"]
                and value is not None,
                f"Invalid attempt retained: {directory.name}: {checked['errors']}",
            )
            profile = value["report"]["profile"]
            require(
                profile == declared[directory.name] and profile not in values,
                "Attempt/profile is ambiguous",
            )
            values[profile], audits[profile] = value, checked
        require(set(values) == set(required), "Missing declared role")
        result["historical_observed_bridges"] = {}
        for profile, value in values.items():
            bridge = observed_bridge(value, controls[profile])
            result["historical_observed_bridges"][profile] = bridge
            require(bridge["passed"], f"80-vector/full-prefix bridge failed: {profile}")
        if "prefix-observed" in values:
            compared = core.prefix_comparison(
                values["prefix-observed"]["prefixes"], b_prefixes
            )
            result["b_v2_plain_prefix_bridge"] = {
                "prefixes": compared,
                "passed": len(compared) == 8
                and all(x["exact_equal"] for x in compared.values()),
            }
            require(
                result["b_v2_plain_prefix_bridge"]["passed"],
                "B-v2 plain entire8 prefix bridge failed",
            )
        loaded = {
            profile: extra.load_extra_vectors(value)
            for profile, value in values.items()
        }
        result["extra_receipts"] = {
            profile: {k: v for k, v in value.items() if k != "target_positions"}
            for profile, value in loaded.items()
        }
        result["passed"] = True
        if role is None:
            result["target_comparison"] = extra.compare_target_positions(
                loaded["native-observed"], loaded["prefix-observed"]
            )
            result["localization_allowed"] = True
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["passed"] = False
        result["localization_allowed"] = False
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--role", choices=("native", "prefix"))
    args = parser.parse_args()
    result = analyze(args.runs, args.bundle, args.output, args.role)
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "localization_allowed": result["localization_allowed"],
                "output": str(args.output),
                "errors": result["errors"],
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
