"""Terminal-only batch7 reproduction and late-window numerical diagnostics."""

import argparse
import json
from pathlib import Path

import window_analysis_core_v1 as core
from new_loss_checks_v1 import (
    audit_terminal_log,
    reproduction_checks,
    require,
    validate_external_observer_identity,
    validate_historical_engine,
    validate_layout,
    validate_live_batch_boundary,
)
from probe_run_v1 import (
    PROFILES,
    SOURCE,
    file_sha,
    load_plan,
    require_empty_worker,
    validate_workers,
)


def normalized_source(value):
    return {
        "path": value["path"],
        "commit": value["commit"],
        "status": value["status"].strip(),
        "diff": value.get("diff", value.get("diff_bytes_utf8")),
        "module_sha256": value.get("module_sha256", value.get("sha256")),
    }


def verify_historical_references(bundle):
    manifest = json.loads((bundle / "source-manifest-v1.json").read_text())
    for path, digest in manifest["original_inputs"].items():
        require(file_sha(path) == digest, "Original frozen quality inputs changed")
    context = manifest["context"]
    require(
        file_sha(context["path"]) == context["sha256"], "Original loss context changed"
    )
    references = json.loads((bundle / "historical-prefixes-v1.json").read_text())
    for label, reference in manifest["historical_runs"].items():
        directory = Path(reference["directory"])
        controller = json.loads((directory / "controller.json").read_text())
        require(
            controller.get("finished_at")
            and controller.get("exit_code") == 0
            and controller.get("passed"),
            f"Historical source not terminal: {label}",
        )
        for name, identity in reference["files"].items():
            require(
                file_sha(directory / name) == identity["sha256"]
                and (directory / name).stat().st_size == identity["bytes"],
                f"Frozen historical bytes changed: {label}/{name}",
            )
        report = json.loads((directory / "results/run.json").read_text())
        outputs = {row["case_id"]: row for row in report["outputs"]}
        for case, retained in references["references"][label].items():
            row = outputs[case]
            require(
                row["finished"]
                and retained["token_ids"]
                == row["token_ids"][: references["prefix_limit"]]
                and retained["full_output_tokens"] == len(row["token_ids"])
                and retained["finish_reason"] == row["finish_reason"],
                "Frozen trajectory extraction differs from original terminal output",
            )
    return manifest


def audit_attempt(directory, plan, references, source_manifest):
    controller = json.loads((directory / "controller.json").read_text())
    result = {
        "directory": str(directory),
        "terminal": bool(controller.get("finished_at")),
        "collection_valid": False,
        "errors": [],
        "reproduction_passed": False,
    }
    if not result["terminal"]:
        result["errors"].append("Nonterminal; child/log deliberately not read")
        return result, None
    try:
        require(
            controller.get("passed") is True
            and controller.get("exit_code") == 0
            and controller.get("terminal_process_proven") is True
            and controller.get("owned_members_after_cleanup") == []
            and not controller.get("cleanup_required")
            and not controller.get("forced_termination")
            and controller.get("errors") == [],
            "Controller cleanup/lifecycle failed",
        )
        log = audit_terminal_log(directory / "process.log")
        require(log["passed"], "Worker traceback/ownership gate failed")
        value = core.load_attempt(directory)
        require(
            value["public"]["included_in_numerical_comparisons"],
            "Native sampling/vector/child receipts failed",
        )
        report = value["report"]
        profile = report["profile"]
        require(
            profile in PROFILES and report["plan"] == plan,
            "Wrong profile or frozen plan",
        )
        require(
            report["sources"] == report["sources_after_startup"],
            "Sources changed across startup",
        )
        plugin = report["sources"]["vllm_muxpd"]
        require(
            plugin["commit"] == SOURCE
            and plugin["status"] == ""
            and plugin["diff"] == "",
            "Require clean6c diagnostic source",
        )
        role = profile.split("-")[0]
        historical = source_manifest["historical_runs"][
            references["primary_by_role"][role][0]
        ]
        for name in ("vllm", "vllm_ascend"):
            require(
                normalized_source(report["sources"][name])
                == normalized_source(historical["sources"][name]),
                f"Original native source receipt differs: {name}",
            )
        validate_historical_engine(report, historical)
        observed = profile.endswith("observed")
        validate_workers(report["worker_before"], profile)
        validate_workers(report["worker_after"], profile, observed)
        for worker in report["worker_after"]:
            require_empty_worker(worker)
        require(
            not any(k.startswith("layer_hook_") for k in report)
            and not (directory / "results/layer-observations").exists(),
            "Layer observers forbidden",
        )
        if observed:
            require(
                report["launch_config"].get("worker_extension_cls")
                == "window_numeric_workers_v1.NumericalObserverExtension",
                "Wrong window observer",
            )
            require(
                sum(bool(x["receipt"]) for x in value["decisions"].values()) == 80,
                "Expected exactly80 selected full-vocabulary vectors",
            )
            require(
                {x["rank"] for x in report["observer_installation"]} == set(range(4))
                and len(report["observer_installation"]) == 4
                and all(x["installed"] for x in report["observer_installation"]),
                "Missing four-rank numerical observer installation",
            )
        else:
            require(
                "observer_installation" not in report
                and not value["decisions"]
                and not (directory / "results/worker-observations").exists()
                and not report["launch_config"].get("worker_extension_cls"),
                "Plain run contains observation",
            )
        layout = validate_layout(report, directory)
        live_boundary = validate_live_batch_boundary(report)
        frozen = json.loads(
            (directory / "producer/freeze-manifest-v1.json").read_text()
        )
        require(
            frozen["status"] == "frozen"
            and frozen["files"] == controller["files"]
            and file_sha(directory / "producer/freeze-manifest-v1.json")
            == controller["freeze_manifest_sha256"],
            "Frozen producer identity differs",
        )
        for name, digest in frozen["files"].items():
            require(
                file_sha(directory / "producer" / name) == digest,
                f"Producer changed: {name}",
            )
        validate_external_observer_identity(report, directory, frozen["files"])
        require(
            report["model_config_identity"] == plan["model_config_identity"],
            "Model configuration identity differs",
        )
        require(
            report["tokenizer_files"]
            == {
                name: {**identity, "observed_sha256": identity["sha256"]}
                for name, identity in plan["tokenizer_files"].items()
            },
            "Actual tokenizer input receipts differ from pinned inputs",
        )
        require(
            report["producer_sha256"] == frozen["files"]["probe_run_v1.py"]
            and report["plan_file_sha256"] == frozen["files"]["plan-v1.json"]
            and report["config_file_sha256"]
            == frozen["files"][
                "native-engine-args-v1.json"
                if role == "native"
                else "raw-engine-args-v1.json"
            ],
            "Actual producer/plan/config input identity differs from frozen bytes",
        )
        reproduction = reproduction_checks(report, references)
        require(
            report["full_run_reproduction"] == reproduction,
            "Declared reproduction differs from actual prefixes",
        )
        result.update(
            collection_valid=True,
            reproduction_passed=reproduction["passed"],
            full_run_reproduction=reproduction,
            terminal_log=log,
            layout=layout,
            live_boundary=live_boundary,
            child_sha256=file_sha(directory / "results/run.json"),
        )
        return result, value
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
        return result, None


def same_role_bridge(observed, plain):
    a, b = observed["report"], plain["report"]
    prefixes = core.prefix_comparison(observed["prefixes"], plain["prefixes"])
    configs = [
        {
            k: v
            for k, v in report["launch_config"].items()
            if k != "worker_extension_cls"
        }
        for report in (a, b)
    ]
    checks = {
        "same_frozen_plan": a["plan"] == b["plan"],
        "same_role": a["profile"].split("-")[0] == b["profile"].split("-")[0],
        "same_engine_config": configs[0] == configs[1],
        "same_source_receipts": a["sources"] == b["sources"],
        "all_eight_complete_prefixes": len(prefixes) == 8
        and all(x["exact_equal"] for x in prefixes.values()),
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "prefixes": prefixes,
        "scope": "Full retained prefix equality, including seed progress beyond208; not just selected-window tokens.",
    }


def analyze(runs, bundle, output):
    require(not output.exists(), "Refuse to overwrite previous analysis")
    plan = load_plan(bundle / "plan-v1.json")
    references = json.loads((bundle / "historical-prefixes-v1.json").read_text())
    sources = verify_historical_references(bundle)
    result = {
        "schema": "muxpd-new-loss-late-window-analysis-v1",
        "localization_allowed": False,
        "passed": False,
        "attempts": [],
        "observer_plain_bridges": {},
        "errors": [],
        "plan_sha256": plan["plan_sha256"],
        "selected_one_based_positions": plan["capture_token_indices_one_based"],
        "known_context_divergences": {
            "seed07151_first_divergence": 56,
            "peer07461_first_divergence": 203,
            "target07338_first_divergence": 207,
            "scope": "All eight requests alive and equal current ordering do not imply matched full-batch or historical KV/GDN state. The window includes peer203 and target207, but cannot identify a unique root cause after earlier seed/peer divergence.",
        },
        "scope": "Posterior diagnostic only; fresh batch omits seven prior batches. No exit-causality, quality, universal-equivalence or performance claim.",
    }
    values = {}
    audits = {}
    for directory in sorted(runs.iterdir()):
        if not directory.is_dir() or not (directory / "controller.json").is_file():
            continue
        checked, value = audit_attempt(directory, plan, references, sources)
        result["attempts"].append(checked)
        if not checked["collection_valid"]:
            result["errors"].append(
                f"Invalid/nonterminal attempt retained; no retry selection: {directory.name}"
            )
        if value:
            profile = value["report"]["profile"]
            if profile in values:
                result["errors"].append(f"Ambiguous multiple valid attempts: {profile}")
            else:
                values[profile] = value
                audits[profile] = checked
    for role in ("native", "prefix"):
        observed, plain = values.get(role + "-observed"), values.get(role + "-plain")
        result["observer_plain_bridges"][role] = (
            same_role_bridge(observed, plain)
            if observed and plain
            else {"passed": False, "reason": "Missing terminal valid same-role pair"}
        )
    if len(result["attempts"]) != len(PROFILES):
        result["errors"].append(
            "Require exactly the four predeclared attempts; retain extras as failure evidence"
        )
    allowed = (
        set(values) == set(PROFILES)
        and not result["errors"]
        and all(row["reproduction_passed"] for row in audits.values())
        and all(row["passed"] for row in result["observer_plain_bridges"].values())
    )
    result["localization_allowed"] = result["passed"] = allowed
    if allowed:
        a, b = values["native-observed"], values["prefix-observed"]
        vectors = []
        for position in plan["capture_token_indices_one_based"]:
            key = (plan["target_case_id"], position - 1)
            row = core.vector_comparison(a["decisions"][key], b["decisions"][key])
            row.update(
                output_position_one_based=position,
                target_history_boundary="after known207 divergence; target history differs"
                if position >= 208
                else "target pre-decision history may match; entire semantic batch must be checked separately",
            )
            vectors.append(row)
        result["target_selected_vectors"] = vectors
        result["peer07461_selected_vectors"] = [
            {
                "output_position_one_based": position,
                "scope": "Peer first divergence203 occurs after seed divergence56; no unique root-cause attribution.",
                **core.vector_comparison(
                    a["decisions"][("mmlu-pro-07461", position - 1)],
                    b["decisions"][("mmlu-pro-07461", position - 1)],
                ),
            }
            for position in plan["capture_token_indices_one_based"]
        ]
        result["full_context_limit"] = (
            "Matching visible request tokens/current graph descriptors does not establish identical earlier KV/GDN values. Position208 has different target history after token207; numerical distances are suppressed when histories differ."
        )
    else:
        result["interpretation_blocked_reason"] = (
            "Require each role's all8 full-run trajectory reproduction and same-role observed/plain complete-prefix bridge; do not retarget or interpret logits."
        )
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.runs, args.bundle, args.output)
    print(
        json.dumps(
            {
                "localization_allowed": result["localization_allowed"],
                "output": str(args.output),
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
