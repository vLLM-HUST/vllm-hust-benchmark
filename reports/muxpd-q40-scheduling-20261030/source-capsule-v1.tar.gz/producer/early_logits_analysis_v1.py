"""Terminal target-only extra-logit loading; original old80 core stays unchanged."""

import hashlib
import json
from pathlib import Path

import numpy as np

import window_analysis_core_v1 as core

TARGET_POSITIONS = frozenset(range(2, 200))
VOCAB = 248320
MAX_CLONE_BYTES = 7946240


def digest_json(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def file_in(directory, name):
    if not isinstance(name, str) or Path(name).name != name or name in ("", ".", ".."):
        raise ValueError("Unsafe extra vector filename")
    path = directory / name
    if path.is_symlink() or path.resolve().parent != directory.resolve():
        raise ValueError("Extra vector escapes its directory")
    return path


def load_vector(directory, receipt, clone, position, lane, profile_sha, sampled):
    fields = {
        "file",
        "bytes",
        "sha256",
        "shape",
        "dtype",
        "all_finite",
        "top_token_ids",
        "top_values",
        "cpu_argmax",
        "output_token_index_one_based",
        "profile_sha256",
        "clone_receipt_sha256",
    }
    if (
        set(receipt) != fields
        or receipt["file"] != f"rank-0-{lane}-target-{position:03d}.npy"
        or receipt["output_token_index_one_based"] != position
        or position not in TARGET_POSITIONS
        or receipt["profile_sha256"] != profile_sha
        or receipt["clone_receipt_sha256"] != digest_json(clone)
        or receipt["shape"] != [VOCAB]
        or receipt["dtype"] != "float32"
        or receipt["all_finite"] is not True
    ):
        raise ValueError("Extra target position/profile/shape/clone receipt differs")
    path = file_in(directory, receipt["file"])
    identity = core.identity(path)
    if (
        identity["sha256"] != receipt["sha256"]
        or identity["size_bytes"] != receipt["bytes"]
    ):
        raise ValueError("Extra full vector SHA/size differs")
    values = np.load(path, allow_pickle=False, mmap_mode="r")
    if (
        values.shape != (VOCAB,)
        or values.dtype != np.float32
        or not np.isfinite(values).all()
    ):
        raise ValueError("Extra vector shape/dtype/finite check failed")
    argmax = int(np.argmax(values))
    top = np.argsort(values, kind="stable")[-8:][::-1]
    if (
        receipt["cpu_argmax"] != argmax
        or sampled != [argmax]
        or receipt["top_token_ids"] != top.tolist()
        or receipt["top_values"] != values[top].tolist()
    ):
        raise ValueError(
            "Extra vector argmax/top values differ from actual native sample"
        )
    return {"values": values, "receipt": receipt, "identity": identity}


def own_input(record):
    row = record["row"]
    own = next(
        value for value in record["semantic_batch"] if value["case_id"] == core.TARGET
    )
    return {
        name: row[name]
        for name in (
            "prompt_token_ids",
            "output_prefix_token_ids",
            "input_token_ids",
            "num_tokens_no_spec",
            "num_computed_tokens",
        )
    } | {"scheduled_tokens": own["scheduled_tokens"]}


def compare_target_positions(left, right):
    if set(left["target_positions"]) != set(range(1, 209)) or set(
        right["target_positions"]
    ) != set(range(1, 209)):
        raise ValueError("Require every target position1..208")
    rows = []
    for position in range(1, 209):
        a, b = left["target_positions"][position], right["target_positions"][position]
        same = own_input(a) == own_input(b)
        basic = core.context_comparison(a, b)
        byte_equal = a["values"].tobytes(order="C") == b["values"].tobytes(order="C")
        row = {
            **basic,
            "position_one_based": position,
            "same_actual_target_input": same,
            "canonical_value_bytes_equal": byte_equal,
            "left_sampled_token_ids": a["row"]["sampled_token_ids"],
            "right_sampled_token_ids": b["row"]["sampled_token_ids"],
            "sampled_token_equal": a["row"]["sampled_token_ids"]
            == b["row"]["sampled_token_ids"],
            "left_source_sha256": a["receipt"]["sha256"],
            "right_source_sha256": b["receipt"]["sha256"],
            "logits_distances_computed": False,
            "unequal_entries": None,
            "max_abs_delta": None,
            "rms_delta": None,
        }
        if same:
            x = np.asarray(a["values"], dtype=np.float64)
            y = np.asarray(b["values"], dtype=np.float64)
            if (
                x.shape != y.shape
                or not np.isfinite(x).all()
                or not np.isfinite(y).all()
            ):
                raise ValueError(
                    "Matched-input target vectors have invalid shape/values"
                )
            unequal = np.flatnonzero(x != y)
            delta = x - y
            row.update(
                logits_distances_computed=True,
                unequal_entries=int(unequal.size),
                first_unequal_token_id=int(unequal[0]) if unequal.size else None,
                max_abs_delta=float(np.max(np.abs(delta))),
                rms_delta=float(np.sqrt(np.mean(delta * delta))),
                left_top=core.top_summary(x),
                right_top=core.top_summary(y),
                scope="Matched actual target input/count/history; co-batch/graph mismatch is reported separately and prevents unique operator attribution.",
            )
        else:
            row["scope"] = (
                "Target input/history/count differs; no numerical distance or same-input attribution."
            )
        rows.append(row)
    first_numeric = next(
        (
            r["position_one_based"]
            for r in rows
            if r["logits_distances_computed"] and r["unequal_entries"]
        ),
        None,
    )
    first_byte = next(
        (
            r["position_one_based"]
            for r in rows
            if r["same_actual_target_input"] and not r["canonical_value_bytes_equal"]
        ),
        None,
    )
    return {
        "positions": rows,
        "first_same_input_numeric_difference": first_numeric,
        "first_same_input_byte_difference": first_byte,
        "first_observed_byte_difference_any_history": next(
            (
                r["position_one_based"]
                for r in rows
                if not r["canonical_value_bytes_equal"]
            ),
            None,
        ),
        "first_sampled_token_difference": next(
            (r["position_one_based"] for r in rows if not r["sampled_token_equal"]),
            None,
        ),
        "same_input_numeric_equal_after_first_difference": [
            r["position_one_based"]
            for r in rows
            if first_numeric is not None
            and r["position_one_based"] > first_numeric
            and r["logits_distances_computed"]
            and r["unequal_entries"] == 0
        ],
        "same_input_byte_equal_after_first_difference": [
            r["position_one_based"]
            for r in rows
            if first_byte is not None
            and r["position_one_based"] > first_byte
            and r["same_actual_target_input"]
            and r["canonical_value_bytes_equal"]
        ],
        "scope": "Every208 target decision examined; no monotonic divergence assumption. Original answer regression/full200 remains unresolved.",
    }


def semantic_batch(event, mapping):
    return [
        {
            "case_id": mapping[row["request_id"]],
            "row": row["row"],
            "prompt_token_ids": row["prompt_token_ids"],
            "output_prefix_token_ids": row["output_prefix_token_ids"],
            "num_computed_tokens": row["num_computed_tokens"],
            "num_tokens_no_spec": row["num_tokens_no_spec"],
            "input_token_ids": row["input_token_ids"],
            "scheduled_tokens": event["schedule"]["num_scheduled_tokens"].get(
                row["request_id"]
            ),
        }
        for row in event["rows"]
    ]


def validate_target_context(event, row, prompt, prefix, position):
    index = position - 1
    count = len(prompt) + index
    if (
        row["output_token_index"] != index
        or row["prompt_token_ids"] != prompt
        or row["prompt_sha256"]
        != hashlib.sha256(
            json.dumps(prompt, separators=(",", ":")).encode()
        ).hexdigest()
        or row["output_prefix_token_ids"] != prefix[:index]
        or row["output_prefix_sha256"]
        != hashlib.sha256(
            json.dumps(prefix[:index], separators=(",", ":")).encode()
        ).hexdigest()
        or row["input_token_ids"] != prompt + prefix[:index]
        or row["num_tokens_no_spec"] != count
        or row["num_computed_tokens"] != (0 if position == 1 else count - 1)
        or event["schedule"]["num_scheduled_tokens"].get(row["request_id"])
        != (len(prompt) if position == 1 else 1)
        or row["sampled_token_ids"] != prefix[index : index + 1]
        or row["discarded_by_native"] is not False
        or event["native_greedy_calls"] != 1
        or event["rows"][row["row"]] != row
    ):
        raise ValueError(
            "Extra actual target input/count/prefix/sampled context differs"
        )


def validate_clone(event, selected):
    clone = event.get("clone_receipt")
    if not selected:
        if clone is not None:
            raise ValueError("Unexpected clone on nonselected event/rank")
        return
    shape = [len(event["rows"]), VOCAB]
    if (
        not 1 <= shape[0] <= 8
        or event["shape"] != shape
        or not isinstance(clone, dict)
        or clone
        != {
            "shape": shape,
            "dtype": "torch.float32",
            "numel": shape[0] * VOCAB,
            "element_size": 4,
            "bytes": shape[0] * VOCAB * 4,
            "clone_count": 1,
            "original_greedy_completed": True,
        }
    ):
        raise ValueError("Actual post-greedy single clone shape/dtype/budget differs")
    if clone["bytes"] > MAX_CLONE_BYTES:
        raise ValueError("Actual clone exceeds frozen budget")


def validate_profile(report, run):
    import window_numeric_diagnostics_v1 as observer

    profile, prompt = observer.load_target_profile()
    refs = json.loads(Path(__file__).with_name("early-references-v1.json").read_text())
    current_sha = refs["observer_delta"]["new_module"]["sha256"]
    if (
        core.identity(run / "producer/window_numeric_diagnostics_v1.py")["sha256"]
        != current_sha
    ):
        raise ValueError(
            "Current observer differs from reviewed narrow source adaptation"
        )
    path = run / "producer/target-capture-profile-v1.json"
    identity = core.identity(path)
    if (
        path.read_bytes()
        != Path(observer.__file__)
        .with_name("target-capture-profile-v1.json")
        .read_bytes()
        or json.loads(path.read_text()) != profile
        or report.get("schema") != "muxpd-target-early-logits-run-v1"
        or any(key.startswith("layer_hook_") for key in report)
        or (run / "results/layer-observations").exists()
        or next(
            case["prompt_token_ids"]
            for case in report["plan"]["cases"]
            if case["case_id"] == core.TARGET
        )
        != prompt
        or profile["source_plan"]["plan_sha256"] != report["plan"]["plan_sha256"]
    ):
        raise ValueError(
            "Early target profile/plan/run schema differs or state hooks remain"
        )
    return {
        "profile": profile,
        "profile_sha256": identity["sha256"],
        "prompt": prompt,
        "identity": identity,
    }


def load_extra_vectors(collection):
    report, run = collection["report"], collection["directory"]
    proof = validate_profile(report, run)
    profile, sha, prompt = proof["profile"], proof["profile_sha256"], proof["prompt"]
    directory = run / "results/target-extra-logits"
    regular = run / "results/worker-observations"
    role = report["profile"].split("-")[0]
    lane = "native" if role == "native" else "decode"
    lanes = ("native",) if role == "native" else ("prefill", "decode")
    mapping = {
        b["internal"]: b["case_id"]
        for phase in report["admissions"]
        for b in phase["bindings"]
    }
    if len(mapping) != 8:
        raise ValueError("Extra observer lacks original eight request bindings")
    window = set(report["plan"]["capture_token_indices_one_based"])
    installed = set()
    by_rank = {rank: {} for rank in range(4)}
    positions = {}
    extra_files = set()
    sources = [proof["identity"]]
    for path in sorted(regular.glob("rank-*-*.jsonl")):
        for line in path.read_text().splitlines():
            event = json.loads(line)
            rank = event["rank"]
            if rank not in range(4) or event["lane"] not in lanes:
                raise ValueError("Extra event rank/lane invalid")
            if path.name != f"rank-{rank}-{event['lane']}.jsonl":
                raise ValueError("Extra event differs from its rank/lane file")
            if event["event"] == "observer-installed":
                key = (rank, event["lane"])
                if (
                    key in installed
                    or event.get("target_extra_profile") != profile
                    or event.get("target_extra_profile_sha256") != sha
                ):
                    raise ValueError(
                        "Extra profile missing/duplicated on a worker lane"
                    )
                installed.add(key)
                continue
            if event["event"] != "native-sample-observed":
                continue
            semantic = semantic_batch(event, mapping)
            target_rows = [
                row
                for row in event["rows"]
                if mapping[row["request_id"]] == core.TARGET
            ]
            if len(target_rows) > 1:
                raise ValueError("Repeated target row in native sample")
            selected = rank == 0 and (
                any(row["output_token_index"] + 1 in window for row in event["rows"])
                or any(
                    row["output_token_index"] + 1 in TARGET_POSITIONS
                    for row in target_rows
                )
            )
            validate_clone(event, selected)
            for row in event["rows"]:
                case = mapping[row["request_id"]]
                position = row["output_token_index"] + 1
                receipt = row.get("extra_logits")
                eligible = (
                    rank == 0
                    and case == core.TARGET
                    and position in TARGET_POSITIONS
                    and event["lane"] == lane
                )
                if bool(receipt) != eligible:
                    raise ValueError(
                        "Missing extra or extra on wrong rank/target/position/lane"
                    )
                if case != core.TARGET:
                    continue
                if position not in range(1, 209) or position in by_rank[rank]:
                    raise ValueError("Duplicate/out-of-bound target sampling position")
                validate_target_context(
                    event,
                    row,
                    prompt,
                    collection["prefixes"][core.TARGET]["output_token_ids"],
                    position,
                )
                expected_lane = (
                    "native"
                    if role == "native"
                    else ("prefill" if position == 1 else "decode")
                )
                if event["lane"] != expected_lane:
                    raise ValueError("Target P/D sample lane differs")
                context = {
                    "semantic_batch": semantic,
                    "batch_descriptor": event.get("batch_descriptor"),
                    "sequence": event["sequence"],
                    "lane": event["lane"],
                }
                by_rank[rank][position] = context
                if rank != 0:
                    continue
                original = collection["decisions"][(core.TARGET, position - 1)]
                if original["row"] != row or any(
                    original[key] != context[key] for key in context
                ):
                    raise ValueError(
                        "Extra context differs from actual old-core sampling record"
                    )
                if receipt:
                    loaded = load_vector(
                        directory,
                        receipt,
                        event["clone_receipt"],
                        position,
                        lane,
                        sha,
                        row["sampled_token_ids"],
                    )
                    path_extra = loaded["identity"]["path"]
                    if path_extra in extra_files:
                        raise ValueError("Extra vector filename reused")
                    extra_files.add(path_extra)
                    sources.append(loaded["identity"])
                    positions[position] = {
                        **original,
                        "receipt": receipt,
                        "values": loaded["values"],
                    }
                else:
                    if (
                        position not in window
                        or original["receipt"] is None
                        or "values" not in original
                    ):
                        raise ValueError("Missing ordinary target endpoint vector")
                    if (
                        not np.isfinite(original["values"]).all()
                        or int(np.argmax(original["values"]))
                        != row["sampled_token_ids"][0]
                    ):
                        raise ValueError(
                            "Ordinary target endpoint is nonfinite or differs from native greedy"
                        )
                    positions[position] = original
    if installed != {(rank, value) for rank in range(4) for value in lanes}:
        raise ValueError("Missing extra profile from all four ranks/lanes")
    expected = set(range(1, 209))
    if any(set(values) != expected for values in by_rank.values()) or any(
        values != by_rank[0] for values in by_rank.values()
    ):
        raise ValueError(
            "All four ranks must agree on complete actual target/co-batch/input contexts"
        )
    if len(extra_files) != 198 or set(positions) != expected:
        raise ValueError(
            "Exactly198 extra vectors plus10 ordinary target endpoints required"
        )
    actual = {str(path) for path in directory.rglob("*") if path.is_file()}
    if actual != extra_files:
        raise ValueError("Unreferenced/missing extra vector files")
    if len(list(regular.glob("*.npy"))) != 80:
        raise ValueError("Original ordinary80 directory cardinality changed")
    payload = sum(positions[position]["values"].nbytes for position in TARGET_POSITIONS)
    if payload != profile["extra_vector_payload_bytes"] or payload != 196669440:
        raise ValueError("Extra full vocabulary payload bound differs")
    return {
        "target_positions": positions,
        "profile_sha256": sha,
        "extra_vector_count": 198,
        "complete_target_positions": list(range(1, 209)),
        "four_rank_actual_context_agreement": True,
        "extra_payload_bytes": payload,
        "sources": sources,
        "scope": "198 rank0 target-only extras plus10 original target endpoints; original ordinary80 files remain disjoint.",
    }
