"""Qualify q40 observed/plain attempts before comparing the scheduling change."""

import argparse
import json
from pathlib import Path

import analyze_early_logits_v1 as old
import q40_analysis_v1 as q40
import source_adapter_v2 as adapter
from probe_run_v1 import load_plan


def analyze(runs, bundle, output, arm=None):
    q40.require(not output.exists(), "Refuse to overwrite previous q40 analysis")
    result = {
        "schema": "muxpd-q40-analysis-v1",
        "analysis_arm": arm or "pair",
        "passed": False,
        "localization_allowed": False,
        "attempts": [],
        "errors": [],
        "quality_gate": "NOT_TESTED",
        "scope": "Supported quota4-to40 scheduling counterfactual. Full retained q40 observed/plain prefixes gate numerical attribution. No runtime fix, complete-answer repair or performance acceptance.",
    }
    try:
        declared = q40.select_attempts(runs, arm)
        plan = load_plan(bundle / "plan-v1.json")
        result["plan_sha256"] = plan["plan_sha256"]
        refs, qualification = q40.verify_references(bundle)
        result["qualified_early_controls"] = qualification
        normalize, source_proof = adapter.prepare_adapter()
        result["source_receipt_adapter"] = source_proof
        sources = old.verify_historical_references(bundle)
        historical = json.loads((bundle / "historical-prefixes-v1.json").read_text())
        values = {}
        for name, profile in declared.items():
            checked, value = q40.audit_attempt(
                runs / name, plan, historical, sources, normalize
            )
            result["attempts"].append(checked)
            q40.require(
                checked["collection_valid"] and value is not None,
                f"Invalid attempt retained: {name}: {checked['errors']}",
            )
            q40.require(
                value["report"]["profile"] == profile,
                "Declared attempt/profile differs",
            )
            values[profile] = value
        observed = values["prefix-observed"]
        loaded = observed["extra"]
        observed_audit = result["attempts"][0]
        result["observed_qualification"] = {
            "passed": True,
            "schedule_passed": observed_audit["schedule"]["passed"],
            "extra_vector_count": loaded["extra_vector_count"],
            "complete_target_positions": loaded["complete_target_positions"],
            "four_rank_actual_context_agreement": loaded[
                "four_rank_actual_context_agreement"
            ],
            "extra_payload_bytes": loaded["extra_payload_bytes"],
            "observed_child_sha256": observed_audit["child_sha256"],
            "treatment_profile_sha256": observed_audit["scheduling_treatment"][
                "profile_sha256"
            ],
        }
        result["observed_child_sha256"] = observed_audit["child_sha256"]
        result["treatment_profile_sha256"] = observed_audit["scheduling_treatment"][
            "profile_sha256"
        ]
        result["extra_receipts"] = {
            k: v for k, v in loaded.items() if k != "target_positions"
        }
        if arm is None:
            plain = values["prefix-plain"]
            transparency = q40.prefix_transparency(observed, plain)
            result["observed_plain_transparency"] = transparency
            q40.require(
                transparency["passed"],
                "All-eight q40 observed/plain transparency failed",
            )
            controls = q40.load_controls(refs)
            result.update(q40.compare_runs(observed, plain, controls))
            result["control_vectors"] = {
                name: {
                    k: v for k, v in value["extra"].items() if k != "target_positions"
                }
                for name, value in controls.items()
            }
            result["localization_allowed"] = True
        result["passed"] = True
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exc:
        result["passed"] = False
        result["localization_allowed"] = False
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--arm", choices=("observed",))
    args = parser.parse_args()
    result = analyze(args.runs, args.bundle, args.output, args.arm)
    print(
        json.dumps(
            {
                key: result[key]
                for key in ("passed", "analysis_arm", "localization_allowed", "errors")
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
