"""Read only CPU scheduler transaction receipts with bounded hook lifetime."""

import copy
import json

_MISSING = object()


def schedule_fields(value):
    return {
        "layers_per_slice": value.muxpd_layers_per_slice,
        "layers_completed_before": value.muxpd_prefill_layers_completed_before,
        "layers_total": value.muxpd_prefill_layers_total,
        "pause_prefill": value.muxpd_pause_prefill,
        "finish_prefill": value.muxpd_finish_prefill,
        "cancel_prefill_ids": sorted(value.muxpd_cancel_prefill_request_ids),
    }


def cohort_snapshot(scheduler):
    cohort = scheduler._prefill_cohort
    if cohort is None:
        return None
    return {
        "cohort_id": cohort.sequence,
        "pending_ids": sorted(cohort.pending_ids),
        "completed_layers": cohort.completed_layers,
    }


class HistoryHooks:
    def __init__(self, scheduler, history, step):
        self.scheduler, self.history, self.step = scheduler, history, step
        self.slots = None

    def __enter__(self):
        self.slots = {
            name: self.scheduler.__dict__.get(name, _MISSING)
            for name in ("schedule", "update_from_output")
        }
        original = self.scheduler.update_from_output

        def update(scheduler_output, model_runner_output):
            value = model_runner_output
            row = {
                "event": "worker-retirement",
                "step": self.step(),
                "cohort_id": value.muxpd_prefill_cohort_id,
                "completed_prefill_ids": sorted(value.muxpd_completed_prefill_ids),
                "cancelled_prefill_ids": sorted(value.muxpd_cancelled_prefill_ids),
                "layers_completed": value.muxpd_prefill_layers_completed,
                "layers_total": value.muxpd_prefill_layers_total,
                "progress_source": value.muxpd_prefill_progress_source,
                "req_ids": list(value.req_ids),
                "req_id_to_index": dict(value.req_id_to_index),
                "sampled_token_ids": copy.deepcopy(value.sampled_token_ids),
                "cohort_before": cohort_snapshot(self.scheduler),
            }
            result = original(scheduler_output, model_runner_output)
            row["cohort_after"] = cohort_snapshot(self.scheduler)
            row["original_update_returned"] = True
            self.history.write(json.dumps(row, sort_keys=True) + "\n")
            return result

        self.scheduler.update_from_output = update
        return self

    def restore(self):
        if self.slots is None:
            return
        for name, previous in self.slots.items():
            if previous is _MISSING:
                self.scheduler.__dict__.pop(name, None)
            else:
                setattr(self.scheduler, name, previous)
        self.slots = None

    def __exit__(self, *exception):
        self.restore()
        return False
