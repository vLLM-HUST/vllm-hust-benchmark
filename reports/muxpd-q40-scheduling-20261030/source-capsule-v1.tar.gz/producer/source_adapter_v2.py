"""Analysis-only adapter for two frozen source-receipt producer formats."""

import argparse
import hashlib
import importlib
import json
import subprocess
import sys
from pathlib import Path

CAMPAIGN = Path("/root/workspace/muxpd-quality-layout-20261028")
BUNDLE = CAMPAIGN / "new-loss-probe-v1"
OLD_ANALYSIS = CAMPAIGN / "new-loss-analysis-v1.json"
LEGACY_PRODUCERS = [
    CAMPAIGN / "quality-v1/run_quality.py",
    CAMPAIGN / "quality-v1/quality_run_v1.py",
]


def sha(value):
    return hashlib.sha256(value).hexdigest()


def require(value, reason):
    if not value:
        raise ValueError(reason)


def git(cwd, *args):
    return subprocess.check_output(["git", "-C", str(cwd), *args])


def remove_one_lf(value):
    return value.removesuffix("\n")


def inspect_source(reference):
    """Recreate both known producers; bind current bytes to historical dirty files."""
    origin = Path(reference["path"])
    root = Path(git(origin.parent, "rev-parse", "--show-toplevel").decode().strip())
    raw_diff = git(root, "diff", "--binary", "HEAD")
    names = git(root, "diff", "--name-only", "-z", "HEAD").split(b"\0")
    untracked = git(root, "ls-files", "--others", "--exclude-standard", "-z").split(
        b"\0"
    )
    changed = []
    for raw in sorted(set(names + untracked) - {b""}):
        name = raw.decode()
        path = root / name
        require(
            path.resolve().is_relative_to(root),
            "Changed path escapes source repository",
        )
        changed.append(
            {
                "path": name,
                "exists": path.exists(),
                "sha256": sha(path.read_bytes()) if path.is_file() else None,
            }
        )
    require(
        sha(origin.read_bytes()) == reference["sha256"], "Actual module bytes changed"
    )
    require(
        git(root, "rev-parse", "HEAD").decode().strip() == reference["commit"],
        "Actual source commit changed",
    )
    require(
        changed == reference["changed_files"], "Actual dirty-file paths/content changed"
    )
    require(
        raw_diff.decode() == reference["diff_bytes_utf8"],
        "Actual full binary diff changed",
    )
    require(sha(raw_diff) == reference["diff_sha256"], "Historical diff SHA mismatch")
    # These .strip calls reproduce the recorded producer commands. Captured
    # status strings themselves are never stripped or ignored by this adapter.
    old_status = git(origin.parent, "status", "--short").decode().strip()
    new_status = git(root, "status", "--porcelain").decode().strip()
    require(old_status == reference["status"], "Historical package-cwd status differs")
    return {
        "root": str(root),
        "module_parent_cwd": str(origin.parent),
        "old_status": old_status,
        "new_status": new_status,
        "diff": raw_diff.decode(),
        "changed_files": changed,
    }


def normalize_receipt(value, reference, inspected):
    """Only the frozen legacy and new-loss source schemas are accepted."""
    legacy = {
        "path",
        "sha256",
        "commit",
        "status",
        "diff_sha256",
        "diff_bytes_utf8",
        "changed_files",
    }
    modern = {"path", "module_sha256", "commit", "status", "diff"}
    require(set(value) in (legacy, modern), "Unrecognized source receipt schema")
    require(
        value["path"] == reference["path"] and value["commit"] == reference["commit"],
        "Receipt source path/commit changed",
    )
    require(
        sha(reference["diff_bytes_utf8"].encode()) == reference["diff_sha256"],
        "Reference diff hash mismatch",
    )
    if set(value) == legacy:
        require(value == reference, "Legacy source receipt content changed")
        require(value["status"] == inspected["old_status"], "Legacy cwd status changed")
    else:
        require(
            value["module_sha256"] == reference["sha256"], "Receipt module SHA changed"
        )
        require(
            value["status"] == inspected["new_status"], "Repository-cwd status changed"
        )
        require(
            value["diff"] == remove_one_lf(reference["diff_bytes_utf8"]),
            "Diff differs beyond the single producer terminal LF",
        )
    require(
        inspected["changed_files"] == reference["changed_files"],
        "Dirty-file identity changed",
    )
    require(
        inspected["diff"] == reference["diff_bytes_utf8"], "Actual diff body changed"
    )
    return {
        "path": reference["path"],
        "commit": reference["commit"],
        "module_sha256": reference["sha256"],
        "repository_root": inspected["root"],
        "changed_files": reference["changed_files"],
        "diff_sha256": reference["diff_sha256"],
    }


def prepare_adapter():
    manifest_path = Path(__file__).with_name("manifest-v2.json")
    manifest = json.loads(manifest_path.read_text())
    for path, digest in manifest["immutable_inputs"].items():
        require(
            sha(Path(path).read_bytes()) == digest, f"Immutable input changed: {path}"
        )
    frozen = json.loads((BUNDLE / "freeze-manifest-v1.json").read_text())
    require(frozen["status"] == "frozen", "Original producer bundle is not frozen")
    for name, digest in frozen["files"].items():
        require(
            sha((BUNDLE / name).read_bytes()) == digest,
            f"Frozen v1 file changed: {name}",
        )
    source_manifest = json.loads((BUNDLE / "source-manifest-v1.json").read_text())
    references = {}
    for historical in source_manifest["historical_runs"].values():
        for name in ("vllm", "vllm_ascend"):
            reference = historical["sources"][name]
            previous = references.setdefault(reference["path"], reference)
            require(
                previous == reference, "Historical source receipts are inconsistent"
            )
    inspected = {path: inspect_source(value) for path, value in references.items()}

    def normalized_source(value):
        require(value["path"] in references, "Unrecognized imported source path")
        return normalize_receipt(
            value, references[value["path"]], inspected[value["path"]]
        )

    proof = {
        "source_receipts": references,
        "actual_source_checks": inspected,
        "v1_result_preserved_sha256": sha(OLD_ANALYSIS.read_bytes()),
        "scope": "Only source receipt formatting is adapted; every v1 lifecycle, invalid-attempt, exact four-profile, reproduction and observer/plain gate remains unchanged.",
    }
    return normalized_source, proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--runs", type=Path, default=CAMPAIGN / "new-loss-probe-runs-v1"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Refuse to overwrite existing analysis")
    require(
        args.output.resolve() != OLD_ANALYSIS.resolve(), "Preserve original v1 FAIL"
    )
    normalized, proof = prepare_adapter()
    sys.path.insert(0, str(BUNDLE))
    original = importlib.import_module("analyze_new_loss_v1")
    original.normalized_source = normalized
    result = original.analyze(args.runs, BUNDLE, args.output)
    result["schema"] = "muxpd-new-loss-late-window-analysis-v2"
    result["source_receipt_adapter"] = proof
    result["adapter_sha256"] = sha(Path(__file__).read_bytes())
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"passed": result["passed"], "output": str(args.output)}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
