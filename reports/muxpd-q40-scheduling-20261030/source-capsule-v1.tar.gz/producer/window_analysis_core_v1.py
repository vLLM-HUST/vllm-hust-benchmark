"""Late-window receipt verification and context-aware vector comparisons.

Derived from frozen analysis-v1/localization_core_v1.py; no standalone legacy CLI.
"""

import hashlib
import json
from pathlib import Path

import numpy as np

TARGET = "mmlu-pro-07338"
SEED = "mmlu-pro-07151"
FOCUS_INDEX = 206
FOCUS_TOKENS = (318, 198)


def identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return {
        "path": str(path),
        "size_bytes": path.stat().st_size,
        "sha256": digest.hexdigest(),
    }


def first_difference(left, right):
    for index, (a, b) in enumerate(zip(left, right)):
        if a != b:
            return {
                "zero_based_index": index,
                "one_based_position": index + 1,
                "left": a,
                "right": b,
            }
    if len(left) != len(right):
        index = min(len(left), len(right))
        return {
            "zero_based_index": index,
            "one_based_position": index + 1,
            "left": left[index] if index < len(left) else None,
            "right": right[index] if index < len(right) else None,
            "kind": "length_only_after_common_prefix",
        }
    return None


def top_summary(values, selected=FOCUS_TOKENS, k=8):
    values = np.asarray(values)
    finite = np.isfinite(values)
    finite_ids = np.flatnonzero(finite)
    ordered = finite_ids[np.argsort(-values[finite_ids], kind="stable")][:k]
    top = [{"token_id": int(i), "value": float(values[i])} for i in ordered]
    margin = top[0]["value"] - top[1]["value"] if len(top) >= 2 else None
    selected_values = {
        str(i): float(values[i]) if 0 <= i < len(values) and finite[i] else None
        for i in selected
    }
    a, b = (selected_values[str(i)] for i in selected)
    return {
        "vocabulary_size": int(values.size),
        "finite_count": int(finite.sum()),
        "nan_count": int(np.isnan(values).sum()),
        "positive_inf_count": int(np.isposinf(values).sum()),
        "negative_inf_count": int(np.isneginf(values).sum()),
        "top_k": top,
        "cpu_argmax": int(np.argmax(values))
        if not np.isnan(values).any() and values.size
        else None,
        "top1_top2_margin": margin,
        "top_tie": margin == 0 if margin is not None else None,
        "selected_logits": selected_values,
        "selected_first_minus_second": a - b
        if a is not None and b is not None
        else None,
    }


def context_comparison(left, right):
    a, b = left["row"], right["row"]
    own = (
        a["prompt_token_ids"] == b["prompt_token_ids"]
        and a["output_prefix_token_ids"] == b["output_prefix_token_ids"]
    )
    batch_equal = left["semantic_batch"] == right["semantic_batch"]
    descriptor_equal = (
        left["batch_descriptor"] is not None
        and left["batch_descriptor"] == right["batch_descriptor"]
    )
    return {
        "same_target_prompt_and_prefix": own,
        "same_entire_semantic_batch": batch_equal,
        "same_padded_graph_descriptor": descriptor_equal,
        "strict_full_context_match": own and batch_equal and descriptor_equal,
        "physical_kv_ids_equal": left["physical_kv"] == right["physical_kv"],
        "physical_kv_scope": "Physical block identifiers are recorded separately and are not a semantic equality condition.",
        "left_padded_graph_descriptor": left["batch_descriptor"],
        "right_padded_graph_descriptor": right["batch_descriptor"],
    }


def vector_comparison(left, right):
    result = context_comparison(left, right)
    result.update(
        left_sampled_token_ids=left["row"]["sampled_token_ids"],
        right_sampled_token_ids=right["row"]["sampled_token_ids"],
        logits_byte_equal=left["receipt"]["sha256"] == right["receipt"]["sha256"],
        logits_distances_computed=False,
    )
    if not result["same_target_prompt_and_prefix"]:
        result["scope"] = (
            "Target histories already differ; no cross-vector numerical distances computed."
        )
        return result
    x, y = (
        np.asarray(left["values"], dtype=np.float64),
        np.asarray(right["values"], dtype=np.float64),
    )
    if x.shape != y.shape:
        result["scope"] = (
            "Different vocabulary shapes; no numerical distances computed."
        )
        return result
    finite = np.isfinite(x) & np.isfinite(y)
    delta = x[finite] - y[finite]
    masks_equal = all(
        np.array_equal(fn(x), fn(y)) for fn in (np.isnan, np.isposinf, np.isneginf)
    )
    result.update(
        logits_distances_computed=True,
        shared_finite_entries=int(finite.sum()),
        nonfinite_masks_equal=masks_equal,
        max_abs_delta=float(np.max(np.abs(delta))) if len(delta) else None,
        rms_delta=float(np.sqrt(np.mean(delta * delta))) if len(delta) else None,
        left_top=top_summary(x),
        right_top=top_summary(y),
    )
    result["scope"] = (
        "Matched current target/batch/graph metadata; this does not prove identical past KV/GDN numerical contents."
        if result["strict_full_context_match"]
        else "Conditional localization only: target prefix matches, but co-batch/order/input/count or graph descriptor differs. This is not same-context numerical equivalence."
    )
    return result


def load_attempt(directory):
    controller_path = directory / "controller.json"
    controller = json.loads(controller_path.read_text())
    public = {
        "label": directory.name,
        "profile": controller.get("profile"),
        "controller": identity(controller_path),
        "terminal": bool(controller.get("finished_at")),
        "controller_passed": controller.get("passed"),
        "exit_code": controller.get("exit_code"),
        "controller_errors": controller.get("errors", []),
        "included_in_numerical_comparisons": False,
    }
    if not public["terminal"]:
        public["reason"] = (
            "Nonterminal controller; child artifacts deliberately not read."
        )
        return {"public": public}
    path = directory / "results/run.json"
    if not path.exists():
        public["reason"] = "Terminal attempt has no child run artifact."
        return {"public": public}
    report = json.loads(path.read_text())
    public.update(
        child=identity(path),
        child_passed=report.get("passed"),
        child_errors=report.get("errors", []),
    )
    if not (
        controller.get("passed")
        and controller.get("exit_code") == 0
        and not controller.get("owned_members_after_cleanup", ["unknown"])
        and not controller.get("errors")
        and report.get("passed")
        and report.get("collection_complete")
        and report.get("shutdown_returned")
        and not report.get("errors")
    ):
        public["reason"] = (
            "Retained failed/incomplete attempt; not used as a valid numerical sample."
        )
        return {"public": public}
    if report["profile"] != controller["profile"]:
        raise ValueError(f"Profile mismatch in {directory}")
    plan, prefixes = report["plan"], report["prefixes_before_abort"]
    declared = plan["plan_sha256"]
    computed = hashlib.sha256(
        json.dumps(
            {k: v for k, v in plan.items() if k != "plan_sha256"},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    if (
        declared != computed
        or report["plan_file_sha256"] != identity(directory / "plan-v1.json")["sha256"]
    ):
        raise ValueError("Child plan does not match frozen bytes")
    expected = {case["case_id"]: case["prompt_token_ids"] for case in plan["cases"]}
    if (
        set(prefixes) != set(expected)
        or len(prefixes[TARGET]["output_token_ids"]) != 208
    ):
        raise ValueError("Frozen batch or target observation boundary differs")
    for case, row in prefixes.items():
        if row["prompt_token_ids"] != expected[case] or any(
            type(t) is not int or t < 0 for t in row["output_token_ids"]
        ):
            raise ValueError("Malformed or changed request prefix")
    public.update(
        included_in_numerical_comparisons=True,
        plan_sha256=declared,
        source_commit=controller["source_commit"],
        engine_steps_to_boundary=report["engine_steps_to_boundary"],
        stop_kind=report["stop_kind"],
        prefix_lengths={
            case: len(row["output_token_ids"]) for case, row in prefixes.items()
        },
        seed_minus_target_output_count=len(prefixes[SEED]["output_token_ids"])
        - len(prefixes[TARGET]["output_token_ids"]),
        all_worker_readbacks=report["worker_after"],
        final_state=report["final_state"],
    )
    collection = {
        "public": public,
        "report": report,
        "prefixes": prefixes,
        "directory": directory,
        "observed": report["profile"].endswith("observed"),
        "decisions": {},
        "sources": [],
    }
    if collection["observed"]:
        load_observed(collection)
    return collection


def load_observed(collection):
    report, directory = (
        collection["report"],
        collection["directory"] / "results/worker-observations",
    )
    mapping = {
        entry["internal"]: entry["case_id"]
        for phase in report["admissions"]
        for entry in phase["bindings"]
    }
    if len(mapping) != 8:
        raise ValueError("Internal request mapping does not cover frozen batch")
    ranks, installed, vector_paths = {}, set(), set()
    files = sorted(directory.glob("rank-*-*.jsonl"))
    for path in files:
        collection["sources"].append(identity(path))
        with path.open() as stream:
            for line in stream:
                event = json.loads(line)
                if event["event"] == "observer-installed":
                    key = (event["rank"], event["lane"])
                    if key in installed or (
                        event["capture_token_indices_one_based"]
                        != report["plan"]["capture_token_indices_one_based"]
                        or event["capture_ranks"] != [0]
                    ):
                        raise ValueError(
                            "Wrong or repeated observer window installation"
                        )
                    installed.add(key)
                if event["event"] != "native-sample-observed":
                    continue
                rank = event["rank"]
                rows = ranks.setdefault(rank, {})
                semantic = [
                    {
                        "case_id": mapping[row["request_id"]],
                        "row": row["row"],
                        "prompt_token_ids": row["prompt_token_ids"],
                        "output_prefix_token_ids": row["output_prefix_token_ids"],
                        "num_computed_tokens": row["num_computed_tokens"],
                        "num_tokens_no_spec": row["num_tokens_no_spec"],
                        "input_token_ids": row["input_token_ids"],
                        "scheduled_tokens": event["schedule"][
                            "num_scheduled_tokens"
                        ].get(row["request_id"]),
                    }
                    for row in event["rows"]
                ]
                physical = [
                    {
                        "case_id": mapping[row["request_id"]],
                        "block_ids": row["kv_block_ids"],
                    }
                    for row in event["rows"]
                ]
                for row in event["rows"]:
                    case, index = mapping[row["request_id"]], row["output_token_index"]
                    key = (case, index)
                    if key in rows:
                        raise ValueError("Duplicate per-rank sampling position")
                    expected = collection["prefixes"][case]
                    if (
                        row["prompt_token_ids"] != expected["prompt_token_ids"]
                        or row["output_prefix_token_ids"]
                        != expected["output_token_ids"][:index]
                        or row["sampled_token_ids"]
                        != expected["output_token_ids"][index : index + 1]
                        or row["discarded_by_native"]
                    ):
                        raise ValueError(
                            "Observer decision differs from retained native request prefix"
                        )
                    rows[key] = {
                        "prompt": row["prompt_token_ids"],
                        "prefix": row["output_prefix_token_ids"],
                        "sampled": row["sampled_token_ids"],
                        "computed": row["num_computed_tokens"],
                        "physical_kv": row["kv_block_ids"],
                    }
                    if rank != 0:
                        if row.get("logits"):
                            raise ValueError("Unexpected vector on noncapture rank")
                        continue
                    record = {
                        "row": row,
                        "semantic_batch": semantic,
                        "physical_kv": physical,
                        "batch_descriptor": event.get("batch_descriptor"),
                        "lane": event["lane"],
                        "sequence": event["sequence"],
                        "receipt": row.get("logits"),
                    }
                    if record["receipt"]:
                        receipt = record["receipt"]
                        if Path(receipt["file"]).name != receipt["file"]:
                            raise ValueError("Unsafe logits filename")
                        path = directory / receipt["file"]
                        if path in vector_paths:
                            raise ValueError("Repeated vector filename")
                        vector_paths.add(path)
                        actual = identity(path)
                        if (
                            actual["size_bytes"] != receipt["bytes"]
                            or actual["sha256"] != receipt["sha256"]
                        ):
                            raise ValueError("Logits do not match recorded SHA/size")
                        values = np.load(path, allow_pickle=False, mmap_mode="r")
                        if (
                            list(values.shape) != receipt["shape"]
                            or list(values.shape)
                            != [report["plan"]["expected_vocabulary_size"]]
                            or str(values.dtype) != "float32"
                            or str(values.dtype) != receipt["dtype"]
                        ):
                            raise ValueError("Logit shape/dtype mismatch")
                        collection["sources"].append(actual)
                        if case in (TARGET, "mmlu-pro-07461"):
                            record["values"] = values
                    collection["decisions"][key] = record
    lanes = (
        ("native",)
        if report["profile"].startswith("native-")
        else ("prefill", "decode")
    )
    if installed != {(rank, lane) for rank in range(4) for lane in lanes}:
        raise ValueError("Missing four-rank lane/window installation receipts")
    if vector_paths != set(directory.glob("*.npy")):
        raise ValueError("Unreferenced or missing vector files")
    if set(ranks) != {0, 1, 2, 3} or any(rows != ranks[0] for rows in ranks.values()):
        raise ValueError("All four ranks must agree on sampler request/token metadata")
    for case, prefix in collection["prefixes"].items():
        for index in range(len(prefix["output_token_ids"])):
            if (case, index) not in collection["decisions"]:
                raise ValueError("Missing sampled token receipt")
            if (
                index + 1 in report["plan"]["capture_token_indices_one_based"]
                and not collection["decisions"][(case, index)]["receipt"]
            ):
                raise ValueError("Missing bounded full-vocabulary capture")
            if (
                index + 1 not in report["plan"]["capture_token_indices_one_based"]
                and collection["decisions"][(case, index)]["receipt"]
            ):
                raise ValueError("Unexpected vector outside declared capture window")
    collection["public"]["observer_verification"] = {
        "all_four_ranks_agree": True,
        "rank_zero_sampled_positions": len(ranks[0]),
        "captured_vectors": sum(
            bool(row["receipt"]) for row in collection["decisions"].values()
        ),
        "all_captured_vector_sizes_hashes_verified": True,
        "prefixes_bound_to_native_sampled_tokens": True,
    }
    collection["public"]["target_logit_positions"] = [
        {
            "zero_based_index": index,
            "one_based_position": index + 1,
            "sampled_token_ids": collection["decisions"][(TARGET, index)]["row"][
                "sampled_token_ids"
            ],
            "lane": collection["decisions"][(TARGET, index)]["lane"],
            "logits_sha256": collection["decisions"][(TARGET, index)]["receipt"][
                "sha256"
            ],
            **top_summary(collection["decisions"][(TARGET, index)]["values"]),
        }
        for index in (
            position - 1
            for position in report["plan"]["capture_token_indices_one_based"]
        )
    ]


def prefix_comparison(left, right):
    return {
        case: {
            "exact_equal": a["output_token_ids"] == right[case]["output_token_ids"],
            "left_length": len(a["output_token_ids"]),
            "right_length": len(right[case]["output_token_ids"]),
            "first_difference": first_difference(
                a["output_token_ids"], right[case]["output_token_ids"]
            ),
        }
        for case, a in left.items()
    }
