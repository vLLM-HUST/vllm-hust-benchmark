# One-variable q40 scheduling counterfactual

Root decision: implement a CPU draft now; device freeze/run requires qualified early-logit independent pair first. This is a scheduling experiment, not a runtime fix or full-quality acceptance.

Primary qualified early experiment reports all target07338 complete logits1..182 byte equal, first same-input numeric difference183, first sampled-token difference207. Its primary SHA is eaddafcc254312db1d5d875106f48e132af2e1f14f205ddb40be1a8e522bcc58. Target initial persistent states all320 equal were separately qualified. Equal logits do not prove equality of all intermediate states.

Use only the existing supported layers_per_slice policy4->40 with the prefix layout unchanged. Keep original8prompts/order/seed-first-token admission/then7peers, full model settings, sampling8192 and target208 cutoff, original source commit6c and native/Ascend sources. Preserve decode graph, overlap/isolated P communication and operator math. Both enable_npugraph_ex and enable_static_kernel remain false. No adaptive/work-budget/prefill-first/decode-guard changes, no graph taps or extra collectives.

New isolated bundle: /root/workspace/muxpd-target-q40-20261030. Every previous producer/attempt remains immutable. Root owns NPU and GitHub.

## Two declared attempts

1. prefix-q40-observed-v1-01: profile prefix-observed. Exact existing numeric observer45d949d2, workersb85d3f7d, target sidecar8e1d9af5 and old80 coreddd04348 remain literal. Same80 ordinary files plus198 target extras. A terminal observed analysis verifies source, lifecycle, vector/actual-input completeness and actual q40 schedule before plain starts; it must not demand reproduction of q4 values.
2. prefix-q40-plain-v1-01: profile prefix-plain. Same q40 config and exact original loop, without numeric observer. Require all8 complete retained output prefixes equal observed q40, after both terminal. No selected retry.

Physical3/4/5/6, logical0..3, timeout900. Controller process ownership/terminal-before-child reading and failure retention remain unchanged. Keep all errors. Original scope remains posterior fresh-process batch7, not prior-seven-batch full200 history.

## Changed-policy controls

Expected actual q40 schedule: one seven-request P cohort, one original full40-layer P forward in one quota advancement; complete ACK covering7; no second P/recompute/preemption before boundary. Seed P is the separate earlier one-request cohort. Original prefix81 TP calls on the treated cohort remain required. The target firstD should be row3 of8, output2/computed1340 with seed output3; final target208 implies seed209 and allotherpeers208. These are verified from actual receipts, not inferred as results.

Check actual before/after decode_graph_snapshot: capture success/4entries, no serving eager/uncaptured/failure increase, and expected total208 replay calls after startup (one seed-only D plus207 all8 D); derive against scheduler traces rather than assuming metadata proves graph execution. Existing snapshots only prove total replay accounting, not an individual internal operator identity. Do not add graph hooks for this test.

q4's seed218 and all80 same-role numeric equivalence are deliberately not admissibility gates for q40. Preserve any old reproduction output descriptively and label expected changed-policy mismatch; never rewrite a previous FAIL to PASS. Every unchanged engine field must compare exactly, with only worker/observer constructor setting appropriate to the arm and the declared quota delta40.

All8q40 observed/plain full retained prefixes must match before q40 numerical attribution. Existing native and q4 early-logit roles remain their qualified controls, with exact file hashes and primary/independent references. Compare q40 target1..208 against native and q4 only where own actual input/count/prefix agrees; describe co-batch differences separately. Report first numeric/byte/token differences and per-case first token differences/common prefix lengths; no monotonic assumption or distance attribution after own-prefix mismatch. Do not imply q40 P-state equality from old q4 states.

## Implementation split

- peer_p_harness: driver/controller, exact one-field config adapter, two-attempt matrix, source/diff proofs, freeze file list, host tests and real metadata schedule validator if agreed with helper. Preserve original admission/step/cancellation/shutdown loops mechanically. Keep original frozen plan/config bytes and express q40 through a separate pinned treatment sidecar/explicit adapter.
- peer_p_helper: q40 terminal analyzer and schedule/coverage validation, unchanged existing numeric loader reuse where schema requires narrow explicit bridge, q40 observed/plain comparison and native/q4 pair analysis, tests on already-terminal real metadata. Coordinate exact sidecar and fields with harness. No output changing synthetic history presented as device evidence.
- peer_p_review: final independent contract/source review after current early208 audit, then independent terminal q40 check after root both-terminal declaration.

Use focused RED/GREEN tests for one-field policy override, rejection of other config changes, wrong quota/cohort/ACK/replay/length/inputs, oldsource preservation, missing terminal, and observed/plain mismatch. Reuse tested early extra loader and ordinary core rather than rewriting numerical logic. Do not repeat large unrelated suites or add generic framework. No runtime candidate identity or code change is claimed by this supported configuration test.

## Decision afterward

If q40 improves07338 trajectory, test complete answer in original batch before selecting runtime change. If it does not, preserve result and choose a narrow actual D boundary around measured step183; do not restart a40-layer survey. Ultimately a real effective runtime candidate, original affected batches and freshfull200 per-case results remain required.
