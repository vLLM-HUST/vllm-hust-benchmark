import hashlib,json,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B))
import probe_control_v1 as control
D=Path(__file__).resolve().parent
assert not (B/'freeze-manifest-v1.json').exists()
files,freeze=control.bundle_identity(B,False)
assert freeze is None
npu=subprocess.run(['npu-smi','info'],text=True,capture_output=True,check=True).stdout
physical=control.inventory(npu);assert physical==['3','4','5','6']
(D/'npu-smi.txt').write_text(npu)
record={'schema':'muxpd-target-q40-root-preflight-v2','created_at':datetime.now(timezone.utc).isoformat(),'physical':physical,'idle':True,'files':files,'dry_runs':[],'sources':{},'scope':'Read-only source/device inventory and two dry-runs; no model child or runtime import.'}
for path,commit in [('/root/workspace/vllm-hust','d0f22d2bda562156e4dbf433ce645e1769b4f804'),('/root/workspace/vllm-ascend-hust','03766ac696fde5ab1980d80ca0b8543d3580c989'),('/root/workspace/muxpd-composite-token-logits','6c606f789450a45ef35afee398b0a3e516caa1a1')]:
 head=subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip();assert head==commit
 status=subprocess.check_output(['git','-C',path,'status','--porcelain'],text=True)
 if 'vllm-ascend-hust' not in path:assert not status
 else:assert status==' M csrc/build_aclnn.sh\n' and hashlib.sha256(Path(path,'csrc/build_aclnn.sh').read_bytes()).hexdigest()=='b089d52475c6cb36fffd733bb5be3fbe4158b6845074751268938e98a1d0042c'
 record['sources'][path]={'commit':head,'status':status}
for step in json.loads((B/'run-matrix-v1.json').read_text())['sequence']:
 argv=step['controller_argv'].copy();assert argv[2]=='run';argv[2]='dry-run'
 done=subprocess.run(argv,text=True,capture_output=True,check=True);j=json.loads(done.stdout)
 assert j['eligible_to_run'] is False and j['files']==files and j['expected_physical']==physical
 output=D/(step['arm']+'-dry-run.json');output.write_text(done.stdout)
 record['dry_runs'].append({'role':step['arm'],'argv':argv,'source_commit':j['source_commit'],'sha256':hashlib.sha256(output.read_bytes()).hexdigest()})
assert control.bundle_identity(B,False)[0]==files
(D/'preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'passed':True,'file_count':len(files),'dry_runs':len(record['dry_runs']),'physical':physical,'sha256':hashlib.sha256((D/'preflight.json').read_bytes()).hexdigest()}))
