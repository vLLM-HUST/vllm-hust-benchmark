"""Independent CPU audit; execute only after root authorizes both q40 terminals."""

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

BUNDLE = Path('/root/workspace/muxpd-target-q40-20261030')
OLD = Path('/root/workspace/muxpd-target-early-logits-20261030')
PRIOR = OLD / 'independent-review-v1/check_terminal_pair_v1.py'
PRIOR_SHA = '304950332bd95549383d679205cf63d600d453f92e4de6adad2218a828f0d7c3'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(PRIOR) == PRIOR_SHA
spec = importlib.util.spec_from_file_location('independent_early_raw', PRIOR)
raw = importlib.util.module_from_spec(spec)
spec.loader.exec_module(raw)
core = raw.core


def history_check(directory, report):
    """Independently derive actual serving progress and graph accounting."""
    rows = [json.loads(line) for line in (directory / 'results/history.jsonl').read_text().splitlines()]
    assert len(rows) == 629 and report['cancellation']['maintenance_steps'] == 1
    cases = report['plan']['cases']
    order = [c['case_id'] for c in cases]
    mapping = {b['case_id']: b['internal'] for a in report['admissions'] for b in a['bindings']}
    prefixes = report['prefixes_before_abort']
    assert order[0] == core.SEED and order[3] == core.TARGET
    assert [a['after_step'] for a in report['admissions']] == [0, 1]
    assert report['admissions'][1]['seed_output_tokens'] == 1
    decode_turns = 0
    for step in range(1, 210):
        scheduled, retired, returned = rows[3 * (step - 1):3 * step]
        assert [r['event'] for r in (scheduled, retired, returned)] == ['scheduled', 'worker-retirement', 'step-return']
        assert all(r['step'] == step for r in (scheduled, retired, returned))
        p_cases = order[:1] if step == 1 else order[1:] if step == 2 else []
        d_cases = [] if step == 1 else order[:1] if step == 2 else order
        pids = {mapping[c] for c in p_cases}
        counts = {mapping[c['case_id']]: len(c['prompt_token_ids']) for c in cases if c['case_id'] in p_cases}
        counts.update({mapping[c]: 1 for c in d_cases})
        assert scheduled['num_scheduled_tokens'] == counts
        assert set(scheduled['prefill_ids']) == set(scheduled['pending_prefill_ids']) == pids
        assert scheduled['layers_per_slice'] == 40 and scheduled['layers_completed_before'] == 0
        assert scheduled['layers_total'] == (40 if pids else 0)
        assert scheduled['cohort_id'] == (step if pids else None)
        assert not scheduled['pause_prefill'] and scheduled['finish_prefill'] is (step == 1)
        assert not scheduled['finished_ids'] and not scheduled['preempted_ids'] and not scheduled['cancel_prefill_ids']
        assert retired['original_update_returned'] is True and retired['cohort_after'] is None
        assert retired['cohort_before'] == ({'cohort_id': step, 'pending_ids': sorted(pids), 'completed_layers': 0} if pids else None)
        assert retired['cohort_id'] == scheduled['cohort_id']
        assert set(retired['completed_prefill_ids']) == pids and not retired['cancelled_prefill_ids']
        assert retired['layers_completed'] == retired['layers_total'] == (40 if pids else 0)
        assert retired['progress_source'] == ('layer_hooks' if pids else 'none')
        assert set(retired['req_ids']) == set(counts)
        assert retired['req_id_to_index'] == {rid: i for i, rid in enumerate(retired['req_ids'])}
        assert list(returned['requests']) == (order[:1] if step == 1 else order)
        for case, row in returned['requests'].items():
            count = step if case == core.SEED else step - 1
            expected = prefixes[case]['output_token_ids'][:count]
            assert row['tokens'] == expected and row['internal'] == mapping[case]
            assert row['num_computed_tokens'] == len(prefixes[case]['prompt_token_ids']) + count - 1
            assert row['status'] == 'RUNNING'
            assert retired['sampled_token_ids'][retired['req_id_to_index'][mapping[case]]] == expected[-1:]
        decode_turns += bool(d_cases)
    maintenance, retired = rows[-2:]
    assert maintenance['event'] == 'scheduled' and retired['event'] == 'worker-retirement'
    assert maintenance['step'] == retired['step'] == 209
    assert not maintenance['num_scheduled_tokens'] and set(maintenance['finished_ids']) == set(mapping.values())
    assert not retired['req_ids'] and not retired['sampled_token_ids']
    assert retired['original_update_returned'] and retired['cohort_before'] is retired['cohort_after'] is None
    assert retired['layers_completed'] == retired['layers_total'] == 0 and retired['progress_source'] == 'none'
    assert decode_turns == 208 and report['engine_steps_to_boundary'] == 209
    before = {r['rank']: r for r in report['worker_before']}
    after = {r['rank']: r for r in report['worker_after']}
    assert set(before) == set(after) == set(range(4))
    graphs = []
    for rank in range(4):
        a, b = before[rank]['decode_graph_snapshot'], after[rank]['decode_graph_snapshot']
        assert a['captured_graph_entries'] == b['captured_graph_entries'] == 4
        assert a['capture_successes'] == b['capture_successes'] == 1
        assert a['captured'] and b['captured'] and not a['failed'] and not b['failed']
        assert a['includes_startup_warmups'] and b['includes_startup_warmups']
        assert b['decode_replay_calls'] - a['decode_replay_calls'] == decode_turns
        for field in ('decode_capture_forward_calls', 'decode_eager_fallback_calls', 'decode_uncaptured_full_calls', 'decode_forward_failures', 'prefill_compiled_calls', 'prefill_compile_profile_runs', 'prefill_compile_profile_failures'):
            assert a[field] == b[field]
        assert b['prefill_forced_eager_calls'] - a['prefill_forced_eager_calls'] == 2
        assert before[rank]['runtime']['policy'] == after[rank]['runtime']['policy'] == report['launch_config']['batch_admission_policy_config']
        graphs.append({'rank': rank, 'replay_before': a['decode_replay_calls'], 'replay_after': b['decode_replay_calls'], 'replay_delta': decode_turns})
    return {'history_sha256': sha(directory / 'results/history.jsonl'), 'serving_steps': 209, 'peer_prefill_advances': 1, 'peer_layers_and_ack': [40, 7], 'graph_receipts': graphs}


def raw_vectors(collection, files, changed_schema=False):
    # Only this in-memory schema name changes; persisted reports/config/policy do not.
    value = collection
    if changed_schema:
        assert value['report']['schema'] == 'muxpd-q40-run-v1'
        value = {**value, 'report': {**value['report'], 'schema': 'muxpd-target-early-logits-run-v1'}}
    targets, receipt = raw.load_targets(value, files)
    ordinary = []
    for key, decision in collection['decisions'].items():
        r = decision['receipt']
        if not r:
            continue
        path = collection['directory'] / 'results/worker-observations' / r['file']
        x = raw.array(path, r, [248320])
        assert np.isfinite(x).all() and [int(np.argmax(x))] == decision['row']['sampled_token_ids']
        ordinary.append({'case_id': key[0], 'position_one_based': key[1] + 1, 'sha256': sha(path)})
    assert len(ordinary) == 80
    return targets, {**receipt, 'ordinary_vectors': ordinary, 'schema_bridge_only': changed_schema}


def compare(left, right, primary):
    expected = {r['position_one_based']: r for r in primary['positions']}
    expected_batch = {r['position_one_based']: r for r in primary['co_batch_differences']}
    assert set(expected) == set(range(1, 209))
    rows = []
    for position in range(1, 209):
        a, b = left[position], right[position]
        x, y = a['values'], b['values']
        same = raw.own_input(a) == raw.own_input(b)
        row = {'position_one_based': position, 'same_actual_target_input': same,
               'canonical_value_bytes_equal': x.tobytes() == y.tobytes(),
               'sampled_token_equal': a['row']['sampled_token_ids'] == b['row']['sampled_token_ids'],
               'left_sampled_token_ids': a['row']['sampled_token_ids'], 'right_sampled_token_ids': b['row']['sampled_token_ids'],
               'left_source_sha256': a['receipt']['sha256'], 'right_source_sha256': b['receipt']['sha256'],
               'same_entire_semantic_batch': a['semantic_batch'] == b['semantic_batch'],
               'same_padded_graph_descriptor': a['batch_descriptor'] is not None and a['batch_descriptor'] == b['batch_descriptor'],
               'logits_distances_computed': same, 'unequal_entries': None, 'max_abs_delta': None, 'rms_delta': None}
        if same:
            unequal = np.flatnonzero(x != y)
            delta = x.astype(np.float64) - y.astype(np.float64)
            row.update(unequal_entries=int(unequal.size), first_unequal_token_id=int(unequal[0]) if unequal.size else None,
                       max_abs_delta=float(np.max(np.abs(delta))), rms_delta=float(np.sqrt(np.mean(delta * delta))))
        assert all(expected[position][key] == value for key, value in row.items()), position
        batch_a = {r['case_id']: r for r in a['semantic_batch']}
        batch_b = {r['case_id']: r for r in b['semantic_batch']}
        batch = {'position_one_based': position,
                 'different_case_ids': sorted(c for c in batch_a.keys() | batch_b.keys() if batch_a.get(c) != batch_b.get(c)),
                 'left_only_case_ids': sorted(batch_a.keys() - batch_b.keys()),
                 'right_only_case_ids': sorted(batch_b.keys() - batch_a.keys()),
                 'changed_common_case_ids': sorted(c for c in batch_a.keys() & batch_b.keys() if batch_a[c] != batch_b[c]),
                 'same_case_order': list(batch_a) == list(batch_b),
                 'left_case_order': list(batch_a), 'right_case_order': list(batch_b)}
        assert batch == expected_batch[position]
        row['co_batch'] = batch
        rows.append(row)
    first_numeric = next((r['position_one_based'] for r in rows if r['same_actual_target_input'] and r['unequal_entries']), None)
    first_byte = next((r['position_one_based'] for r in rows if r['same_actual_target_input'] and not r['canonical_value_bytes_equal']), None)
    summary = {'first_same_input_numeric_difference': first_numeric, 'first_same_input_byte_difference': first_byte,
               'first_observed_byte_difference_any_history': next((r['position_one_based'] for r in rows if not r['canonical_value_bytes_equal']), None),
               'first_sampled_token_difference': next((r['position_one_based'] for r in rows if not r['sampled_token_equal']), None),
               'same_input_numeric_equal_after_first_difference': [r['position_one_based'] for r in rows if first_numeric is not None and r['position_one_based'] > first_numeric and r['same_actual_target_input'] and r['unequal_entries'] == 0],
               'same_input_byte_equal_after_first_difference': [r['position_one_based'] for r in rows if first_byte is not None and r['position_one_based'] > first_byte and r['same_actual_target_input'] and r['canonical_value_bytes_equal']]}
    assert all(primary[key] == value for key, value in summary.items())
    return {'summary': summary, 'positions': rows}


def verify(analysis):
    primary = json.loads(analysis.read_text())
    assert primary['schema'] == 'muxpd-q40-analysis-v1' and primary['analysis_arm'] == 'pair'
    assert primary['passed'] and primary['localization_allowed'] and primary['errors'] == []
    assert primary['quality_gate'] == 'NOT_TESTED'
    refs = json.loads((BUNDLE / 'q40-references-v1.json').read_text())
    directories = {'observed': BUNDLE / 'runs-v1/prefix-q40-observed-v1-01', 'plain': BUNDLE / 'runs-v1/prefix-q40-plain-v1-01',
                   **{role: Path(path) for role, path in refs['early_runs'].items()}}
    terminals = {name: raw.terminal(path) for name, path in directories.items()}
    # All four terminal receipts above precede all child/log/NPY reads below.
    for path, digest in refs['files'].items():
        assert sha(Path(path)) == digest
    frozen_path = BUNDLE / 'freeze-manifest-v1.json'
    freeze = json.loads(frozen_path.read_text()); files = freeze['files']
    assert freeze['status'] == 'frozen' and len(files) == 31
    assert all(sha(BUNDLE / name) == digest for name, digest in files.items())
    attempts = {r['directory']: r for r in primary['attempts']}
    collections, schedule = {}, {}
    base = json.loads((BUNDLE / 'raw-engine-args-v1.json').read_text())
    for arm in ('observed', 'plain'):
        path = directories[arm]; control = terminals[arm]
        assert control['files'] == files and control['freeze_manifest_sha256'] == sha(frozen_path)
        assert all(sha(path / 'producer' / name) == digest for name, digest in files.items())
        checked = attempts[str(path)]
        assert checked['collection_valid'] and checked['child_sha256'] == sha(path / 'results/run.json')
        value = core.load_attempt(path); report = value['report']
        assert value['public']['included_in_numerical_comparisons'] and report['schema'] == 'muxpd-q40-run-v1'
        assert report['profile'] == f'prefix-{arm}'
        config = copy.deepcopy(base)
        config['worker_cls'] = 'vllm_muxpd.decoupled_worker.DecoupledMuxPDNPUWorker'
        config['batch_admission_policy_config']['layers_per_slice'] = 40
        if arm == 'observed': config['worker_extension_cls'] = 'window_numeric_workers_v1.NumericalObserverExtension'
        assert config == report['launch_config'] == control['launch_engine_args']
        assert report['full_run_reproduction'] == checked['full_run_reproduction']
        assert checked['reproduction_is_admissibility_gate'] is False
        schedule[arm] = history_check(path, report)
        collections[arm] = value
    observed, plain = collections['observed'], collections['plain']
    assert observed['report']['sources'] == plain['report']['sources']
    lengths = {}
    for case, row in observed['prefixes'].items():
        assert row['prompt_token_ids'] == plain['prefixes'][case]['prompt_token_ids']
        assert row['output_token_ids'] == plain['prefixes'][case]['output_token_ids']
        assert len(row['output_token_ids']) == (209 if case == core.SEED else 208)
        lengths[case] = len(row['output_token_ids'])
    assert len(lengths) == 8 and not plain['decisions']
    assert not (directories['plain'] / 'results/worker-observations').exists()
    assert not (directories['plain'] / 'results/target-extra-logits').exists()
    targets, vector_checks = {}, {}
    targets['q40'], vector_checks['q40'] = raw_vectors(observed, files, changed_schema=True)
    order = [c['case_id'] for c in observed['report']['plan']['cases']]
    for position in range(2, 209):
        record = targets['q40'][position]
        assert record['lane'] == 'decode' and record['row']['row'] == 3
        assert record['batch_descriptor'] == {'num_tokens': 8, 'num_reqs': 8, 'uniform': True, 'has_lora': False, 'num_active_loras': 0}
        assert [row['case_id'] for row in record['semantic_batch']] == order
        for index, row in enumerate(record['semantic_batch']):
            case = row['case_id']; source = observed['prefixes'][case]
            count = position if case == core.SEED else position - 1
            prefix = source['output_token_ids'][:count]; prompt = source['prompt_token_ids']
            assert row['row'] == index and row['prompt_token_ids'] == prompt
            assert row['output_prefix_token_ids'] == prefix and row['input_token_ids'] == prompt + prefix
            assert row['num_computed_tokens'] == len(prompt) + count - 1
            assert row['num_tokens_no_spec'] == len(prompt) + count and row['scheduled_tokens'] == 1
    comparisons, prefixes = {}, {}
    for role, label in (('native', 'native'), ('prefix', 'q4')):
        value = core.load_attempt(directories[role])
        targets[label], vector_checks[label] = raw_vectors(value, terminals[role]['files'])
        comparisons[label] = compare(targets[label], targets['q40'], primary[f'target_vs_{label}'])
        prefixes[label] = {}
        for case, row in value['prefixes'].items():
            left, right = row['output_token_ids'], observed['prefixes'][case]['output_token_ids']
            common = next((i for i, (a, b) in enumerate(zip(left, right)) if a != b), min(len(left), len(right)))
            p = primary[f'prefixes_vs_{label}'][case]
            assert p['exact_equal'] == (left == right) and p['common_prefix_tokens'] == common
            assert p['left_length'] == len(left) and p['right_length'] == len(right)
            assert p['first_difference'] == core.first_difference(left, right)
            prefixes[label][case] = p
    assert all(sha(BUNDLE / name) == digest for name, digest in files.items())
    return {'passed': True, 'script_sha256': sha(Path(__file__)), 'raw_loader_sha256': PRIOR_SHA,
            'primary': {'path': str(analysis), 'sha256': sha(analysis)}, 'freeze_manifest_sha256': sha(frozen_path),
            'current_children': {arm: sha(directories[arm] / 'results/run.json') for arm in ('observed', 'plain')},
            'terminal_times': {arm: value['finished_at'] for arm, value in terminals.items()},
            'observed_plain_complete_prefixes_equal': True, 'prefix_lengths': lengths, 'schedule': schedule,
            'raw_vector_checks': vector_checks, 'comparisons': comparisons, 'per_case_prefix_comparisons': prefixes,
            'scope': 'Independent raw198 extras+10 endpoints and80 ordinary vectors, all8 q40 observed/plain prefixes, actual scheduler/ACK/graph deltas, and native/q4 comparison. No answer-quality or performance qualification.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    result = verify(args.analysis)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({'passed': True, 'output': str(args.output), 'sha256': sha(args.output),
                      'comparisons': {name: row['summary'] for name, row in result['comparisons'].items()}}))
