import pathlib,subprocess,sys,json,os,datetime,shutil,signal,hashlib,shlex,time
run=pathlib.Path(__file__).resolve().parent.parent
repo=pathlib.Path('/root/hust-eval-client-frontierscience')
env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(run/'client_source/src')+os.pathsep+os.environ.get('PYTHONPATH',''))
sys.path.insert(0,str(run/'client_source/src'))
from hust_eval_frontierscience import seal
from hust_eval_frontierscience.hashing import sha256_file
cli=[str(repo/'.venv/bin/python'),'-m','hust_eval_frontierscience']
commands=[]
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def state(stage,**kw):write(run/'STATUS.json',dict(stage=stage,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw))
def step(args):
    args=list(map(str,args));commands.append({'argv':args,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    write(run/'orchestration/full-commands.json',commands)
    print('STEP',shlex.join(args),flush=True)
    p=subprocess.run(args,env=env)
    commands[-1]['returncode']=p.returncode;write(run/'orchestration/full-commands.json',commands)
    if p.returncode:raise RuntimeError('step failed: '+shlex.join(args))
def receipt(role):
    step(cli+['receipt','--run-dir',run/role,'--base-url','http://127.0.0.1:18180','--profile',run/'profile.json','--startup-log',run/'server/receipt/startup.log','--server-argv',run/'server/receipt/argv_actual.json'])
    e=json.loads((run/role/'receipt/effective.json').read_text())
    if not e['ok'] or any(e[k] for k in ('unverified','argv_only','log_only')):raise RuntimeError('receipt not fully corroborated')
def stop():
    pf=run/'server/server.pid'
    if not pf.exists():return
    pid=int(pf.read_text())
    try:os.killpg(pid,signal.SIGTERM)
    except ProcessLookupError:pass
    # Do not seal live server logs. Include all members of this owned process group.
    for _ in range(120):
        lines=subprocess.check_output(['ps','-eo','pgid=,stat='],text=True).splitlines()
        if not any(len(s:=line.split())==2 and s[0]==str(pid) and not s[1].startswith('Z') for line in lines):return
        time.sleep(1)
    raise RuntimeError('owned server group did not stop; sealing deferred')
try:
    gate=json.loads((run/'FULL_AUTHORIZATION.json').read_text())
    if gate['decision']!='USER_AUTHORIZED_FULL_WITH_MMLU_EXTRACTION':raise RuntimeError('full authorization missing')
    if gate['contract_sha256']!=sha256_file(run/'plan/contract.json'):raise RuntimeError('acceptance contract mismatch')
    state('full_solver')
    receipt('full-solver-service')
    shutil.copytree(run/'full-solver-service/receipt',run/'receipt')
    step(cli+['run','--plan',run/'plan','--output',run/'full/solver'])
    state('full_judge')
    receipt('full-judge-service')
    step(cli+['judge','--plan',run/'plan','--responses',run/'full/solver','--output',run/'full/judge'])
    step(cli+['summary','--plan',run/'plan','--responses',run/'full/solver','--grades',run/'full/judge','--output',run/'full/report'])
    report=json.loads((run/'full/report/summary.json').read_text())
    if report['scope']!='full_gold':raise RuntimeError('not a full 160-case result')
    state('bench')
    receipt('bench-service')
    step(cli+['materialize','--plan',run/'plan','--output',run/'full/bench-prompts.jsonl'])
    # Bench imports the same Ascend packages; reproduce the server environment bootstrap.
    for item in json.loads((run/'server/receipt/sourced_env.json').read_text()):env.update(item['set_or_changed'])
    write(run/'full/bench-environment.json',{'sourced_env_sha256':sha256_file(run/'server/receipt/sourced_env.json'),'note':'Bench inherits driver env plus the recorded ATB bootstrap changes; not the solver HTTP request body.'})
    args=cli+['bench','--name','frontierscience','--dataset',run/'full/bench-prompts.jsonl','--base-url','http://127.0.0.1:18180','--served-model','qwen3.5-35b','--tokenizer','/models/Qwen3.5-35B-A3B','--num-prompts','160','--output-len','256','--vllm-bin',shutil.which('vllm')]
    step(args+['--run-dir',run/'full/bench-dry-run','--dry-run'])
    step(args+['--run-dir',run/'full/bench'])
    bench=json.loads((run/'full/bench/outputs/frontierscience.json').read_text())
    if bench.get('completed')!=160 or bench.get('failed',0)!=0:raise RuntimeError('bench did not complete all 160 requests')
    step(cli+['hash-model','--model','/models/Qwen3.5-35B-A3B','--small-only','--out',run/'model_hashes/qwen35-small-after.json'])
    if json.loads((run/'model_hashes/qwen35-small.json').read_text())!=json.loads((run/'model_hashes/qwen35-small-after.json').read_text()):raise RuntimeError('model small-file identity changed')
    state('stopping_server')
    stop()
    origin=json.loads((run/'server/SERVICE_ORIGIN.json').read_text())
    shutil.copyfile(pathlib.Path(origin['run_dir'])/'server/serve.log',run/'server/serve.log')
    (run/'validation/npu-after.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True))
    write(run/'FULL_REVIEW.json',{'note':'Qwen judge, official prompts, single trial; no domain expert validation. First complete VERDICT authoritative under user-selected MMLU-style extraction; invalids count as nonsuccess. Flags do not modify scores. Bench uses server default chat template, max output 256, separate from solver generation config.','tracks':report['tracks'],'bench_completed':bench['completed'],'human_review_required':any(v['judge_audit_flagged'] or v['judge_unresolved'] for v in report['tracks'].values())})
    state('completed',note='all requests finished; result table includes raw scores and review flags')
    for phase in ['smoke','smoke8192','full']:
        p=run.parent/(run.name+'.'+phase+'-driver.log')
        if p.exists():shutil.copyfile(p,run/'orchestration'/(phase+'-driver.log'))
    bundle=seal.seal_evidence(run)
    (run/'results').mkdir()
    table=run/'results/frontierscience-results.md'
    lines=['# FrontierScience Qwen3.5-35B-A3B','',
           'Protocol: official Appendix B prompts; Qwen judge; one trial; mmlu_extract_first local extraction and full denominator. Not official leaderboard replication.',
           'First complete explicit VERDICT is extracted even from truncated output; invalids remain in denominator as nonsuccess. Flagged contradictions require review. Full weights were not hashed.','',
           '| Track | Total | Successes | Success rate | Mean Research score | Solver truncated | Judge truncated | Truncated with grade | Invalid judge | Judge unresolved | Judge audit flagged |',
           '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name,s in report['tracks'].items():
        values=[name,s['total'],s['successes'],s['success_rate'],s['mean_research_score_valid_only'],s['solver_truncated'],s['judge_truncated'],s['judge_truncated_with_grade'],s['judge_invalid'],s['judge_unresolved'],s['judge_audit_flagged']]
        lines.append('| '+' | '.join(map(str,values))+' |')
    lines+=['','Bench: 160 custom chat prompts, output cap 256, request-rate inf, temperature 0, seed 0.','',
            '| Metric | Value |','|---|---:|']
    for k in ['completed','failed','duration','request_throughput','output_throughput','total_token_throughput','mean_ttft_ms','mean_tpot_ms']:
        lines.append('| '+k+' | '+str(bench.get(k))+' |')
    lines+=['','evidence_bundle_sha256: '+bundle['evidence_bundle_sha256'],'contract_sha256: '+sha256_file(run/'plan/contract.json'),'']
    table.write_text('\n'.join(lines))
    final=seal.seal_final(run,table,str(run.parent/'seal-ledger.jsonl'))
    check=seal.seal_check(run,table)
    write(run.parent/(run.name+'.seal-check.json'),check)
    print('SEALED',json.dumps(final),flush=True)
    if not check['ok']:raise RuntimeError('seal verification failed')
except BaseException as e:
    if not (run/'EVIDENCE_BUNDLE.json').exists():
        write(run/'ERROR_FULL.json',{'error':repr(e)});state('failed',error=repr(e))
    else:write(run.parent/(run.name+'.seal-error.json'),{'error':repr(e)})
    stop();raise
