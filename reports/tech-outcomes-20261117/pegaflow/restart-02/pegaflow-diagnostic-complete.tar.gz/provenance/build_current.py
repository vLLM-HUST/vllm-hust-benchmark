import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import urllib.request
import zipfile

ROOT = Path('/workspace/pegaflow-techoutcomes-20261113-02')
SOURCE = ROOT / 'sources/pegaflow-hust-e2cdc2f7b32d8294b54a74545c05d103e5a5ecaf'
PYTHON = ROOT / '.venv/bin/python'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'base-env.json').read_text()))
ENV.update({
    'CARGO_HOME': str(ROOT / 'cargo'),
    'RUSTUP_HOME': str(ROOT / 'rustup'),
    'CARGO_TARGET_DIR': str(SOURCE / 'target'),
    'PIP_CACHE_DIR': str(ROOT / 'cache/pip'),
    'PYO3_PYTHON': str(PYTHON),
    'CARGO_BUILD_JOBS': '6',
    'PATH': str(ROOT / 'cargo/bin') + ':' + str(ROOT / '.venv/bin') + ':' + ENV['PATH'],
})
STATE = {'started_unix': time.time(), 'pid': os.getpid(), 'source_commit': 'e2cdc2f7b32d8294b54a74545c05d103e5a5ecaf', 'features': ['ascend'], 'rdma_enabled': False}
if (ROOT / 'compatibility-patch.json').exists():
    STATE['compatibility_patch'] = json.loads((ROOT / 'compatibility-patch.json').read_text())


def state(phase, **fields):
    STATE.update(phase=phase, updated_unix=time.time(), **fields)
    tmp = ROOT / 'build-status.tmp'
    tmp.write_text(json.dumps(STATE, indent=2))
    tmp.replace(ROOT / 'build-status.json')
    print(json.dumps({'phase': phase, **fields}), flush=True)


def run(args, cwd=ROOT):
    print(json.dumps({'command': [str(x) for x in args], 'cwd': str(cwd)}), flush=True)
    subprocess.run([str(x) for x in args], cwd=cwd, env=ENV, check=True)


try:
    state('download-rustup')
    url = 'https://static.rust-lang.org/rustup/dist/aarch64-unknown-linux-gnu/rustup-init'
    with urllib.request.urlopen(url + '.sha256', timeout=40) as response:
        expected = response.read().decode().split()[0]
    installer = ROOT / 'rustup-init'
    with urllib.request.urlopen(url, timeout=90) as response, installer.open('wb') as stream:
        shutil.copyfileobj(response, stream)
    actual = hashlib.sha256(installer.read_bytes()).hexdigest()
    assert actual == expected, 'Rustup installer digest mismatch'
    installer.chmod(0o755)
    state('install-rust', rustup_sha256=actual)
    run([installer, '-y', '--no-modify-path', '--profile', 'minimal', '--default-toolchain', '1.100.0'])
    rust_version = subprocess.check_output([str(ROOT / 'cargo/bin/rustc'), '--version'], env=ENV, text=True).strip()
    state('install-build-tools', rust_version=rust_version)
    run([PYTHON, '-m', 'pip', 'install', 'maturin', 'ruff'])
    state('install-protoc')
    tools = ROOT / 'protoc'
    if not (tools / 'bin/protoc').is_file():
        request = urllib.request.Request('https://api.github.com/repos/protocolbuffers/protobuf/releases/latest', headers={'User-Agent': 'Codex-build'})
        with urllib.request.urlopen(request, timeout=40) as response:
            release = json.load(response)
        asset = next(x for x in release['assets'] if x['name'].endswith('-linux-aarch_64.zip'))
        archive = ROOT / asset['name']
        with urllib.request.urlopen(asset['browser_download_url'], timeout=90) as response, archive.open('wb') as stream:
            shutil.copyfileobj(response, stream)
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        if asset.get('digest'):
            assert asset['digest'] == 'sha256:' + digest
        with zipfile.ZipFile(archive) as package:
            for name in package.namelist():
                assert (tools / name).resolve().is_relative_to(tools.resolve())
            package.extractall(tools)
        (tools / 'bin/protoc').chmod(0o755)
        (ROOT / 'protoc-receipt.json').write_text(json.dumps({'release': release['tag_name'], 'url': asset['browser_download_url'], 'sha256': digest}, indent=2))
    ENV['PROTOC'] = str(tools / 'bin/protoc')
    ENV['PROTOC_INCLUDE'] = str(tools / 'include')
    if True:
        state('check-numa-regression')
        run([ROOT / 'cargo/bin/rustup', 'component', 'add', 'rustfmt'])
        run([ROOT / 'cargo/bin/rustfmt', '--edition', '2024', '--check', SOURCE / 'pegaflow-common/src/numa.rs'])
        run([ROOT / 'cargo/bin/cargo', 'test', '--release', '-p', 'pegaflow-common', '--lib', 'sparse_device_nodes_preserve_physical_ids_and_ignore_control_nodes'], cwd=SOURCE)
    state('compile-binaries')
    run([ROOT / 'cargo/bin/cargo', 'build', '--release', '--no-default-features', '--features', 'ascend', '-p', 'pegaflow-py', '--bin', 'pegaflow-server-py', '--bin', 'pegaflow-metaserver-py'], cwd=SOURCE)
    for name in ['pegaflow-server-py', 'pegaflow-metaserver-py']:
        destination = SOURCE / 'python/pegaflow' / name
        shutil.copy2(SOURCE / 'target/release' / name, destination)
        destination.chmod(0o755)
    state('compile-ipc-extension')
    run([PYTHON, 'setup.py', 'build_ext', '--inplace'], cwd=SOURCE / 'python/pegaflow/npu_ipc_bindings')
    state('build-wheel')
    run([ROOT / '.venv/bin/maturin', 'build', '--release', '--no-default-features', '--features', 'ascend', '--interpreter', PYTHON, '--out', ROOT / 'wheels'], cwd=SOURCE / 'python')
    wheels = list((ROOT / 'wheels').glob('pegaflow*.whl'))
    assert len(wheels) == 1, wheels
    wheel = wheels[0]
    state('install-current-wheel', wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(), wheel=str(wheel))
    run([PYTHON, '-m', 'pip', 'install', '--no-deps', '--force-reinstall', wheel])
    lock = SOURCE / 'Cargo.lock'
    state('complete', exit_code=0, cargo_lock_sha256=hashlib.sha256(lock.read_bytes()).hexdigest(), completed_unix=time.time())
except BaseException as error:
    traceback.print_exc()
    state('failed', exit_code=1, error=type(error).__name__ + ': ' + str(error))
    sys.exit(1)
