import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path('/workspace/pegaflow-techoutcomes-20261113-02')
PYTHON = str(ROOT / '.venv/bin/python')
SWE = ROOT / 'sources/swe-prefix-reuse-ef43ced21e870e2faa1122f89f831ddf39443bf6'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'base-env.json').read_text()))
ENV.update({'OMP_NUM_THREADS': '2', 'MKL_NUM_THREADS': '2', 'TOKENIZERS_PARALLELISM': 'false', 'VLLM_CACHE_ROOT': str(ROOT / 'cache/vllm'), 'TRITON_CACHE_DIR': str(ROOT / 'cache/triton'), 'TORCHINDUCTOR_CACHE_DIR': str(ROOT / 'cache/torchinductor'), 'ASCEND_CACHE_PATH': str(ROOT / 'cache/ascend'), 'ASCEND_WORK_PATH': str(ROOT / 'logs/ascend')})
(ROOT / 'run-env.json').write_text(json.dumps({k: ENV[k] for k in json.loads((ROOT / 'base-env.json').read_text())} | {k: ENV[k] for k in ['OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'TOKENIZERS_PARALLELISM', 'VLLM_CACHE_ROOT', 'TRITON_CACHE_DIR', 'TORCHINDUCTOR_CACHE_DIR', 'ASCEND_CACHE_PATH', 'ASCEND_WORK_PATH']}, indent=2))
STATE = {'started_unix': time.time(), 'pid': os.getpid()}


def state(phase, **fields):
    STATE.update(phase=phase, updated_unix=time.time(), **fields)
    (ROOT / 'cpu-status.json').write_text(json.dumps(STATE, indent=2))
    (ROOT / 'durable/metadata/cpu-status.json').write_text(json.dumps(STATE, indent=2))
    print(json.dumps({'phase': phase, **fields}), flush=True)


def run(name, command, cwd=ROOT, timeout=600):
    state(name)
    with (ROOT / 'logs' / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=cwd, env=ENV, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f'{name} exited {result.returncode}; see its log')


try:
    os.nice(5)
    run('swe-protocol-tests', [PYTHON, '-m', 'pytest', '-q', str(SWE / 'tests')], cwd=SWE)
    run('prepare-workload', [PYTHON, '-m', 'swe_prefix_reuse.cli', 'prepare', '--source', str(SWE / 'data/open-swe-sample.json.gz'), '--tokenizer', '/data/shared_models/Qwen3.5-35B-A3B', '--max-context', '262144', '--output', str(ROOT / 'prepared-qwen35.json')])
    workload = ROOT / 'prepared-qwen35.json'
    run('vllm-help', [PYTHON, '-m', 'vllm.entrypoints.cli.main', 'serve', '--help=all'], timeout=120)
    state('complete', exit_code=0, workload_sha256=hashlib.sha256(workload.read_bytes()).hexdigest())
except BaseException as error:
    traceback.print_exc()
    state('failed', exit_code=1, error=type(error).__name__ + ': ' + str(error))
    sys.exit(1)
