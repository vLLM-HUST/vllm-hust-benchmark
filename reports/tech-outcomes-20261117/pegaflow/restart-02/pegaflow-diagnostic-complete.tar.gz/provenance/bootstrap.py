"""Rebuild the fixed public PR on the restarted allocation, keeping evidence durable."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path('/workspace/pegaflow-techoutcomes-20261113-02')
PERSIST = Path('/data/shared_upload/cybber695/pegaflow-techoutcomes-20261113-02')
SOURCE = ROOT / 'sources/pegaflow-hust-e2cdc2f7b32d8294b54a74545c05d103e5a5ecaf'
PYTHON = ROOT / '.venv/bin/python'
ENV = os.environ.copy()
STATE = {'pid': os.getpid(), 'started_unix': time.time(), 'phase': 'setup'}


def state(phase, **fields):
    STATE.update(phase=phase, updated_unix=time.time(), **fields)
    raw = json.dumps(STATE, indent=2)
    for path in [ROOT / 'bootstrap-status.json', PERSIST / 'metadata/bootstrap-status.json']:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix('.tmp')
        temporary.write_text(raw)
        temporary.replace(path)
    print(json.dumps({'phase': phase, **fields}), flush=True)


def run(command, **kwargs):
    print(json.dumps({'command': [str(x) for x in command]}), flush=True)
    subprocess.run(command, env=ENV, check=True, **kwargs)


try:
    assert ROOT.is_dir() and PERSIST.is_dir()
    state('unpack-sources')
    for archive in ['pegaflow-hust-e2cdc2f7.tar.gz', 'swe-prefix-reuse-ef43ced2.tar.gz']:
        with tarfile.open(ROOT / archive) as package:
            package.extractall(ROOT / 'sources', filter='data')
    assert hashlib.sha256((SOURCE / 'pegaflow-common/src/numa.rs').read_bytes()).hexdigest() == 'd25457edc6e7486955511fa23953fef8cf2d349ccb78038537d7da20aebc14cb'
    base = {k: ENV[k] for k in ['PATH', 'LD_LIBRARY_PATH', 'ASCEND_HOME_PATH', 'ASCEND_TOOLKIT_HOME'] if k in ENV}
    base['PYTHONPATH'] = '/vllm-workspace/vllm:/vllm-workspace/vllm-ascend:' + ENV.get('PYTHONPATH', '')
    base.update({'TMPDIR': str(ROOT / 'tmp'), 'PIP_CACHE_DIR': str(ROOT / 'cache/pip')})
    (ROOT / 'base-env.json').write_text(json.dumps(base, indent=2))
    ENV.update(base)
    run([sys.executable, '-m', 'venv', '--system-site-packages', str(ROOT / '.venv')])
    state('install-python-tools')
    run([PYTHON, '-m', 'pip', 'install', 'maturin==1.16.0', 'ruff==0.17.5', 'aiohttp==3.14.3', 'pytest'])
    run([PYTHON, '-m', 'pip', 'install', '--no-deps', '-e', ROOT / 'sources/swe-prefix-reuse-ef43ced21e870e2faa1122f89f831ddf39443bf6'])
    state('launch-build-and-protocol-checks')
    processes = {}
    for name in ['build_current.py', 'prepare_cpu.py', 'hash_model.py']:
        log = (ROOT / 'logs' / (name + '.log')).open('ab', buffering=0)
        process = subprocess.Popen([sys.executable, '-u', str(ROOT / name)], cwd=ROOT, env=ENV, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        processes[name] = {'pid': process.pid, 'started_unix': time.time()}
    (ROOT / 'preparation-processes.json').write_text(json.dumps(processes, indent=2))
    shutil.copy2(ROOT / 'preparation-processes.json', PERSIST / 'metadata/preparation-processes.json')
    state('preparation-running', processes=processes)
except BaseException as error:
    traceback.print_exc()
    state('failed', error=type(error).__name__ + ': ' + str(error))
    raise
