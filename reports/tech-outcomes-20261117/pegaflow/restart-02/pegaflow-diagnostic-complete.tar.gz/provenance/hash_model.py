import hashlib
import json
from pathlib import Path
import os
import time

root = Path('/workspace/pegaflow-techoutcomes-20261113-02')
model = Path('/data/shared_models/Qwen3.5-35B-A3B')
expected = json.loads((root / 'model-expected-weights.json').read_text())
record = {'phase': 'running', 'pid': os.getpid(), 'started_unix': time.time(), 'model': str(model), 'expected_revision': '712cf74392b05026a6db2bf213d343747d1f6d45', 'files': []}


def save():
    record['updated_unix'] = time.time()
    temporary = root / 'model-hash-status.tmp'
    temporary.write_text(json.dumps(record, indent=2))
    temporary.replace(root / 'model-hash-status.json')
    (root / 'durable/metadata/model-hash-status.json').write_text(json.dumps(record, indent=2))


save()
for item in expected:
    digest = hashlib.sha256()
    path = model / item['path']
    with path.open('rb') as stream:
        while block := stream.read(8 * 1024 * 1024):
            digest.update(block)
    result = {'path': item['path'], 'bytes': path.stat().st_size, 'sha256': digest.hexdigest(), 'matches_expected': digest.hexdigest() == item['sha256'] and path.stat().st_size == item['bytes']}
    record['files'].append(result)
    save()
    print(json.dumps(result), flush=True)
for name in ['config.json', 'tokenizer.json', 'tokenizer_config.json', 'chat_template.jinja', 'model.safetensors.index.json']:
    path = model / name
    record['files'].append({'path': name, 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
record['phase'] = 'complete'
record['all_weights_match_expected'] = all(item['matches_expected'] for item in record['files'] if 'matches_expected' in item)
save()
