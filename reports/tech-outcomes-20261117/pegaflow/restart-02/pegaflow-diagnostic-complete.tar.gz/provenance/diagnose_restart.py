"""Calibrate Native repeatability and compare local cache reuse with external restore."""
import hashlib
import json
import os
from pathlib import Path
import time
import traceback
import urllib.request

import campaign_support as c

ROOT = c.ROOT
OUT = ROOT / 'diagnostics/repetition-and-restore'
STATUS = {'pid': os.getpid(), 'started_unix': time.time(), 'phase': 'waiting-build', 'arms': []}
REQUEST_NUMBER = 0


def save():
    for path in [ROOT / 'diagnostic-status.json', ROOT / 'durable/metadata/diagnostic-status.json']:
        c.write(path, STATUS)


def post(path, body=None):
    raw = b'' if body is None else json.dumps(body).encode()
    request = urllib.request.Request(f'http://127.0.0.1:{c.PORT}' + path, data=raw, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=300) as response:
        content = response.read()
        return {'http_status': response.status, 'response': json.loads(content) if content else None}


def complete(folder, prompt, salt, *, logprobs=None):
    global REQUEST_NUMBER
    body = {'model': 'pegaflow-techoutcomes-qwen35', 'prompt': prompt, 'max_tokens': 32,
            'temperature': 0, 'seed': 17, 'ignore_eos': True, 'return_token_ids': True,
            'cache_salt': salt, 'stream': False}
    if logprobs is not None:
        body['logprobs'] = logprobs
    REQUEST_NUMBER += 1
    label = f'{REQUEST_NUMBER:04d}'
    response = post('/v1/completions', body)['response']
    c.write(folder / 'responses' / (label + '.json'), {'request': body, 'response': response})
    ids = response['choices'][0]['token_ids']
    assert len(ids) == response['usage']['completion_tokens'] == 32
    assert response['usage']['prompt_tokens'] == len(prompt)
    return {'record': 'responses/' + label + '.json', 'token_ids': ids, 'usage': response['usage']}


def freeze_long_prompts(qualification, workload):
    folder = Path(qualification['folder'])
    records = [json.loads(line) for line in (folder / 'client/requests.jsonl').read_text().splitlines() if line.strip()]
    traces = {session['trajectory_id']: session for session in workload['sessions']}
    lanes = {}
    candidates = []
    for row in sorted(records, key=lambda r: (r['lane'], r['play'], r['turn'])):
        key = (row['lane'], row['play'])
        prompt = lanes.setdefault(key, [])
        prompt.extend(traces[row['trajectory_id']]['turns'][row['turn']]['input_ids'])
        digest = hashlib.sha256(json.dumps(prompt, separators=(',', ':')).encode()).hexdigest()
        assert digest == row['prompt_sha256'] and len(prompt) == row['prompt_tokens']
        if 4096 <= len(prompt) <= 16384:
            candidates.append({'trajectory_id': row['trajectory_id'], 'turn': row['turn'], 'prompt_tokens': len(prompt), 'prompt_sha256': digest, 'input_ids': list(prompt)})
        prompt.extend(row['token_ids'])
    chosen, counts = [], {}
    for item in sorted(candidates, key=lambda item: (item['trajectory_id'], item['turn'])):
        trajectory = item['trajectory_id']
        if counts.get(trajectory, 0) < 2:
            chosen.append(item)
            counts[trajectory] = counts.get(trajectory, 0) + 1
    assert len(chosen) >= 2, 'Qualification did not reach enough real continuation prefixes'
    chosen = chosen[:4]
    c.write(ROOT / 'diagnostic-long-prompts.json', chosen)
    c.write(ROOT / 'durable/provenance/diagnostic-long-prompts.json', chosen)
    return chosen


def run_arm(candidate, workload, long_prompts):
    name = 'pegaflow-diagnostic' if candidate else 'native-diagnostic'
    folder = OUT / name
    folder.mkdir(parents=True, exist_ok=False)
    c.npu(folder / 'npu-admission.txt')
    assert (folder / 'npu-admission.txt').read_text().count('No running processes found in NPU') == 2
    memory = c.memory()
    file_cache = next(int(line.split()[1]) for line in memory['memory.stat'].splitlines() if line.startswith('file '))
    if file_cache > 16 * 1024**3:
        for item in json.loads((ROOT / 'model-expected-weights.json').read_text()):
            descriptor = os.open(Path(c.MODEL) / item['path'], os.O_RDONLY)
            try:
                os.posix_fadvise(descriptor, 0, 0, os.POSIX_FADV_DONTNEED)
            finally:
                os.close(descriptor)
    c.write(folder / 'memory-admission.json', {'before': memory, 'after': c.memory(), 'method': 'POSIX_FADV_DONTNEED only on this task model shards when file cache exceeds 16 GiB; no global drop_caches or deletion.'})
    c.write(folder / 'performance-environment.json', {name: c.ENV.get(name) for name in ['LD_PRELOAD', 'HCCL_DETERMINISTIC', 'LCCL_DETERMINISTIC', 'VLLM_BATCH_INVARIANT', 'ASCEND_RT_VISIBLE_DEVICES', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'VLLM_SERVER_DEV_MODE']})
    server = sidecar = None
    result = {'arm': name, 'warmups': [], 'short_pairs': [], 'long_cases': []}
    try:
        STATUS.update(phase='starting-' + name, arm=name, current_folder=str(folder))
        save()
        if candidate:
            command = [str(ROOT / '.venv/bin/pegaflow-server'), '--addr', '127.0.0.1:33892', '--http-addr', '127.0.0.1:33893', '--pool-size', '30gb', '--devices', '0,1', '--log-level', 'info']
            sidecar = c.start(name + '-sidecar', command, folder / 'sidecar')
            c.health(sidecar, 'http://127.0.0.1:33893/health', maximum=300)
        server = c.start(name + '-vllm', c.server_command(candidate), folder / 'server')
        c.health(server, f'http://127.0.0.1:{c.PORT}/health')
        c.SERVER, c.SIDECAR = server, sidecar
        c.BASE_IDENTITY = c.snapshot_runtime()
        c.write(folder / 'runtime-identity.json', c.BASE_IDENTITY)
        c.metrics(folder, 'before', candidate)
        STATUS['phase'] = 'short-repeatability-' + name
        save()
        for case in range(4):
            prompt = workload['sessions'][case]['turns'][0]['input_ids']
            salt = f'restart02-warmup-{case}'
            cold = complete(folder, prompt, salt)
            time.sleep(1)
            warm = complete(folder, prompt, salt)
            result['warmups'].append({'case': case, 'cold': cold, 'warm': warm, 'equal': cold['token_ids'] == warm['token_ids']})
            c.write(folder / 'result.json', result)
        prompt = workload['sessions'][4]['turns'][0]['input_ids']
        assert len(prompt) == 1637
        for pair in range(10):
            salt = f'restart02-case4-{pair}'
            cold = complete(folder, prompt, salt)
            time.sleep(1)
            warm = complete(folder, prompt, salt)
            c.metrics(folder, f'pair{pair}', candidate)
            result['short_pairs'].append({'pair': pair, 'cold': cold, 'warm': warm, 'equal': cold['token_ids'] == warm['token_ids']})
            c.write(folder / 'result.json', result)
            STATUS.update(pairs_completed=pair + 1, equal_pairs=sum(p['equal'] for p in result['short_pairs']))
            save()
        result['short_unique_sequences'] = len({tuple(response['token_ids']) for pair in result['short_pairs'] for response in [pair['cold'], pair['warm']]})
        result['logprob_probes'] = [complete(folder, prompt, f'restart02-logprob-{i}', logprobs=5) for i in range(3)]
        c.metrics(folder, 'short-after', candidate)
        STATUS['phase'] = 'protocol-qualification-' + name
        save()
        qualification = c.point(name, 2, 60, qualification=True)
        result['qualification'] = qualification
        if not candidate:
            long_prompts = freeze_long_prompts(qualification, workload)
        STATUS['phase'] = 'local-vs-restored-' + name
        save()
        for index, probe in enumerate(long_prompts):
            prompt = probe['input_ids']
            salt = f'restart02-restore-case-{index}'
            cold = complete(folder, prompt, salt)
            time.sleep(1)
            warm = complete(folder, prompt, salt)
            time.sleep(1)
            c.metrics(folder, f'long{index}-before-reset', candidate)
            reset = post('/reset_prefix_cache?reset_external=false')
            replay = complete(folder, prompt, salt)
            c.metrics(folder, f'long{index}-after-reset', candidate)
            before = (folder / f'vllm-metrics-long{index}-before-reset.txt').read_text()
            after = (folder / f'vllm-metrics-long{index}-after-reset.txt').read_text()
            delta = {key: c.counter(after, key) - c.counter(before, key) for key in ['pega_load_success_total', 'pega_save_success_total', 'pega_load_failure_total', 'pega_save_failure_total']}
            result['long_cases'].append({'index': index, 'prompt_sha256': probe['prompt_sha256'], 'prompt_tokens': len(prompt), 'cold': cold, 'local_warm': warm, 'after_local_reset': replay, 'reset': reset, 'cold_equals_warm': cold['token_ids'] == warm['token_ids'], 'warm_equals_replay': warm['token_ids'] == replay['token_ids'], 'mechanism_delta': delta})
            c.write(folder / 'result.json', result)
            STATUS.update(long_cases_completed=index + 1)
            save()
        c.metrics(folder, 'after', candidate)
        result['completed_unix'] = time.time()
        result['external_restore_exercised'] = candidate and all(case['mechanism_delta']['pega_load_success_total'] > 0 for case in result['long_cases'])
        result['local_warm_equals_replay_all'] = all(case['warm_equals_replay'] for case in result['long_cases'])
        c.write(folder / 'result.json', result)
        STATUS['arms'].append({'arm': name, 'short_unique_sequences': result['short_unique_sequences'], 'unequal_short_pairs': sum(not pair['equal'] for pair in result['short_pairs']), 'external_restore_exercised': result['external_restore_exercised'], 'local_warm_equals_replay_all': result['local_warm_equals_replay_all']})
    finally:
        STATUS['phase'] = 'stopping-' + name
        save()
        c.stop(server)
        c.stop(sidecar)
        c.SERVER = c.SIDECAR = None
        c.npu(folder / 'npu-release.txt')
    return long_prompts


try:
    save()
    while True:
        build = json.loads((ROOT / 'build-status.json').read_text())
        if build['phase'] == 'failed':
            raise RuntimeError(build['error'])
        if build['phase'] == 'complete':
            break
        time.sleep(5)
    for name in ['cpu-status.json', 'model-hash-status.json']:
        assert json.loads((ROOT / name).read_text())['phase'] == 'complete'
    assert json.loads((ROOT / 'model-hash-status.json').read_text())['all_weights_match_expected']
    env = json.loads((ROOT / 'run-env.json').read_text())
    env['VLLM_SERVER_DEV_MODE'] = '1'
    c.write(ROOT / 'run-env.json', env)
    c.write(ROOT / 'durable/provenance/run-env.json', env)
    c.ENV.update(env)
    workload = json.loads((ROOT / 'prepared-qwen35.json').read_text())
    assert hashlib.sha256((ROOT / 'prepared-qwen35.json').read_bytes()).hexdigest() == 'c716290e07468920aa27084d423d0c7ff169bf71f8b58e81112bd2ec2e219e64'
    long_prompts = run_arm(False, workload, None)
    run_arm(True, workload, long_prompts)
    STATUS.update(phase='complete', completed_unix=time.time())
    save()
except BaseException as error:
    traceback.print_exc()
    STATUS.update(phase='failed', error=type(error).__name__ + ': ' + str(error), completed_unix=time.time())
    save()
    raise
