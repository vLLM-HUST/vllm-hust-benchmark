#!/usr/bin/env bash
set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export PYTHONPATH=/root/workspace/.pyramidkv-release-work/install:$PYTHONPATH
export MODEL_PATH=/root/workspace/Qwen3.5-35B-A3B
export SERVE_PORT=8012 PYRAMIDKV_ENABLED=1
export VLLM_ASCEND_PYRAMIDKV_BATCHED_METADATA=1
export PYRAMIDKV_CONFIG=/root/workspace/.pyramidkv-release-work/source/scripts/qwen35/pyramidkv-aligned.json
unset VLLMHUST_EXT_ENABLED_BUNDLES VLLM_EXTENSION_MANIFESTS VLLM_EXTENSION_BUNDLES VLLM_ASCEND_KVCOMPRESS_ENABLED VLLM_ASCEND_KVCOMPRESS_CONFIG
python -c 'import vllm_ascend_pyramidkv as p; assert p.__file__.startswith("/root/workspace/.pyramidkv-release-work/install/"); print("Installed plugin:",p.__file__,p.__version__,flush=True)'
exec bash /root/workspace/.pyramidkv-release-work/source/scripts/qwen35/serve.sh
