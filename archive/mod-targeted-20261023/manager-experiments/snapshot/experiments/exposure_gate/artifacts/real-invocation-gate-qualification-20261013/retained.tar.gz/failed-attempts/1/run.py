import os,json,time,subprocess,socket,hashlib,signal,urllib.request,urllib.error,select,shutil,threading
from pathlib import Path
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler,HTTPServer
from experiments.exposure_gate.loopback_traffic import LoopbackTrafficAdapter,frozen_target_set_sha256,read_traffic_journal,observe_gate_transitions
from vllm_hust_ext.exposure_gate import LeaseGrant,GateError
from vllm_hust_ext.plan_artifact import read_plan_artifact
from vllm_hust_ext.host_observer import observe_bound_invocations
from vllm_hust_ext.host_evidence import EntryPointBinding
R=Path(__file__).resolve().parent; M=Path('/root/ecpa-current-audit-adb447'); V=Path('/root/ecpa-exposure-proxy-candidate-venv'); E=R/'events';E.mkdir(mode=0o700);Q=R/'quarantine';Q.mkdir(mode=0o700)
shutil.copyfile(M/'experiments/false_effective/deployment-candidates/h1-kv-materialization-plan.json',R/'plan.json');(R/'plan.json').chmod(0o600)
plan=read_plan_artifact(R/'plan.json').plan
binding=EntryPointBinding('vllm.general_plugins','kv_materialization','vllm_kv_materialization.plugin:register_plugin',plan.plugins[0].id,plan.obligations[0].obligation_id)
launch='launch:real-gate-qualification-20261013-'+str(time.time_ns());controller='controller:qualification-only'
env=dict(os.environ,PYTHONPATH=str(M/'src')+':'+str(M)+':'+os.environ.get('PYTHONPATH',''),VLLM_ECPA_EVIDENCE_SINK='vllm_hust_ext.host_event_sink:append_event',VLLM_ECPA_EVIDENCE_STRICT='1',VLLM_ECPA_PLAN_ID=plan.plan_id,VLLM_ECPA_LAUNCH_ID=launch,ECPA_HOST_EVENT_DIR=str(E),ECPA_HOST_EVENT_DEVICE=str(E.stat().st_dev),ECPA_HOST_EVENT_INODE=str(E.stat().st_ino),ECPA_HOST_EVENT_FSYNC='1',VLLM_PLUGINS='kv_materialization',VLLM_WORKER_MULTIPROC_METHOD='spawn',OMP_NUM_THREADS='1',ASCEND_RT_VISIBLE_DEVICES='3,6',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS='12')
command=[str(V/'bin/ecpa-host-launch'),'serve','/models/Qwen2.5-7B-Instruct','--served-model-name','ecpa-real-gate-qualification','--host','127.0.0.1','--port','18187','--tensor-parallel-size','2','--enforce-eager','--max-model-len','2048','--gpu-memory-utilization','0.7','--shutdown-timeout','20','--disable-ecpa-manager','--enable-entrypoints']
summary={'classification':'QUALIFIED_NONFORMAL','formal_result':False,'performance_result':False,'effectiveness_result':False,'scope':'worker invocation coverage only','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'manager_commit':'adb44738569e54d5132a725cd8f7de6f0e391b45','host_candidate_commit':'379a0ad35e9de6928e3481d375692204b0dee6e4','launch_id':launch,'command':command,'environment':{k:v for k,v in env.items() if k.startswith(('VLLM_','ECPA_','ASCEND_RT_','OMP_','HF_','TRANSFORMERS_','PYTHONPATH'))}}
def save(name,value): (R/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def http(port,path,body=None):
 data=None if body is None else json.dumps(body).encode();req=urllib.request.Request(f'http://127.0.0.1:{port}{path}',data=data,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=30) as response:return {'status':response.status,'body':response.read().decode(),'observed_ns':time.time_ns()}
 except urllib.error.HTTPError as error:return {'status':error.code,'body':error.read().decode(),'observed_ns':time.time_ns()}
class Closed(BaseHTTPRequestHandler):
 def do_GET(self):self.send_error(503,'closed predecessor')
 def do_POST(self):self.send_error(503,'closed predecessor')
 def log_message(self,*args):pass
pre=HTTPServer(('127.0.0.1',28187),Closed);threading.Thread(target=pre.serve_forever,daemon=True).start()
backend=None;proxy=None
save('inputs.json',summary)
try:
 log=open(R/'backend.log','wb');backend=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);summary['backend_pid']=backend.pid
 for _ in range(660):
  if backend.poll() is not None:raise RuntimeError('backend exited '+str(backend.returncode))
  try:
   ready=http(18187,'/health')
   if ready['status']==200:break
  except OSError:pass
  time.sleep(1)
 else:raise RuntimeError('backend not ready')
 save('backend-health-before.json',ready)
 records=[]
 for f in sorted(E.glob('*.jsonl')):
  for raw in f.read_bytes().splitlines():records.append((f,json.loads(raw)))
 required=[];members=[];worker_journal=None
 for f,e in records:
  p=e['process']
  if p['assignment_source']=='host' and e['event']=='invoked' and e['entry_point']['name']=='kv_materialization':
   if p not in members:members.append(p)
   if p['role']=='worker':
    t={k:p[k] for k in ('host','role','ordinal','process_epoch')}
    if t not in required:required.append(t)
    if p['ordinal']==0:worker_journal=f
 required.sort(key=lambda p:(p['host'],p['role'],p['ordinal'],p['process_epoch']))
 assert len(required)==2 and worker_journal
 for p in members:
  d=R/'proc'/str(p['pid']);d.mkdir(parents=True)
  for name in ('stat','cmdline','status'):shutil.copyfile(Path('/proc')/str(p['pid'])/name,d/name)
 save('host-membership.json',members)
 obs=observe_bound_invocations(E,expected_directory_identity=(E.stat().st_dev,E.stat().st_ino),plan=plan,launch_id=launch,controller_instance=controller,bindings=[binding],required_processes=required);assert obs['complete_coverage'];save('complete-observation.json',obs)
 authorization={'schema':'ecpa-loopback-host-authorization/v1','authorization_path':str(R/'authorization.json'),'plan_path':str(R/'plan.json'),'journal_dir':str(E),'journal_device':E.stat().st_dev,'journal_inode':E.stat().st_ino,'launch_id':launch,'controller_instance':controller,'candidate_generation':1,'membership_epoch':1,'target_set_sha256':frozen_target_set_sha256(required),'local_host':socket.gethostname(),'bindings':[asdict(binding)],'required_processes':required}
 save('authorization.json',authorization);(R/'authorization.json').chmod(0o600)
 grant=LeaseGrant('qualification-authority',1,int(time.time())+600)
 pc=[str(V/'bin/python'),str(M/'experiments/exposure_gate/loopback_traffic.py'),'--socket',str(R/'authority.sock'),'--journal',str(R/'authority.jsonl'),'--listen-port','8187','--predecessor-port','28187','--candidate-port','18187','--predecessor-snapshot','{"generation":0,"classification":"closed-503-predecessor"}','--grant-holder',grant.holder,'--grant-token',str(grant.fencing_token),'--grant-expires-at',str(grant.expires_at),'--observer-config',str(R/'authorization.json')]
 save('proxy-command.json',{'argv':pc,'source_sha256':hashlib.sha256((M/'experiments/exposure_gate/loopback_traffic.py').read_bytes()).hexdigest()})
 proxy=subprocess.Popen(pc,env=env,stdout=open(R/'proxy.stdout','wb'),stderr=open(R/'proxy.stderr','wb'),start_new_session=True);summary['proxy_pid']=proxy.pid
 for _ in range(100):
  if proxy.poll() is not None:raise RuntimeError('proxy exited')
  if (R/'authority.sock').exists():break
  time.sleep(.1)
 adapter=LoopbackTrafficAdapter(R/'authority.sock',grant);snapshot={k:authorization[k] for k in ('launch_id','controller_instance','candidate_generation','membership_epoch','target_set_sha256')};snapshot['plan_id']=plan.plan_id
 request={'model':'ecpa-real-gate-qualification','messages':[{'role':'user','content':'Reply exactly ECPA-GATE-OK'}],'temperature':0,'max_tokens':20,'stream':False}
 save('request.json',request)
 raw=worker_journal.read_bytes();dest=Q/worker_journal.name
 phases=[]
 for phase in ('before-open','after-open'):
  if phase=='after-open':
   dest.rename(worker_journal)
   assert worker_journal.read_bytes()==raw
   adapter.open(1,'gate-qualification',snapshot,grant,int(time.time()))
   successful=http(8187,'/v1/chat/completions',request);save('proxy-completion.json',successful);assert successful['status']==200
  beforelog=(R/'backend.log').read_bytes();stamp=time.time_ns();worker_journal.rename(dest)
  save(phase+'-quarantine.json',{'renamed_ns':stamp,'journal':str(worker_journal),'quarantine':str(dest),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_size':len(raw),'backend_log_before_sha256':hashlib.sha256(beforelog).hexdigest()})
  if phase=='before-open':
   try:adapter.open(1,'gate-qualification',snapshot,grant,int(time.time()))
   except GateError as error:save('open-denial.json',{'error':str(error),'observed_ns':time.time_ns()})
   else:raise RuntimeError('partial coverage incorrectly opened')
  blocked=http(8187,'/v1/chat/completions',request);assert blocked['status']==503;save(phase+'-blocked-http.json',blocked)
  afterlog=(R/'backend.log').read_bytes();assert beforelog==afterlog,'blocked request changed backend log'
  direct=http(18187,'/health');assert direct['status']==200;save(phase+'-backend-alive.json',direct)
  save(phase+'-route.json',asdict(adapter.query_route()))
 phases.append(phase)
 save('traffic-observation.json',observe_gate_transitions(R/'authority.jsonl'))
 summary['passed']=True;summary['phases']=phases;summary['partial_invocation_coverage']=0.5
except Exception as error:
 summary['passed']=False;summary['error']=repr(error);raise
finally:
 for child in (proxy,backend):
  if child and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=40)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
 pre.shutdown();pre.server_close()
 summary['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save('result.json',summary)
 subprocess.run(['npu-smi','info'],stdout=open(R/'cleanup-npu.txt','wb'),check=False)
 subprocess.run(['ss','-ltnp'],stdout=open(R/'cleanup-ports.txt','wb'),check=False)
