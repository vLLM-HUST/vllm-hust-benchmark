"""Real source bundles through actual Provider.check and Manager CLI's status_for API."""
from pathlib import Path
import dataclasses,hashlib,importlib.metadata as md,json,sys,time
from vllm_hust_ext.manifest import load_manifest
from vllm_hust_ext.discovery import InstalledBundle
from vllm_hust_ext.config import ExtensionConfig
from vllm_hust_ext.core import status_for,plan_for,plan_dict,reject_conflicting_plans
from vllm_hust_ext.providers.vllm import VllmProvider
from vllm_hust_ext.capabilities import detect_vllm_capabilities
R=Path(__file__).parent;f=json.loads((R/'freeze.json').read_bytes());assert hashlib.sha256((R/'freeze.json').read_bytes()).hexdigest()=='1605caf2dd2ebcd8ace5bba00a85c47588ebe6412799dc7afad6ba67af304e85'
for i in f['sources']:assert hashlib.sha256((R/i['snapshot']).read_bytes()).hexdigest()==i['sha256'];assert hashlib.sha256(Path(i['source_path']).read_bytes()).hexdigest()==i['sha256']
provider=VllmProvider();bundles={};members=[]
for i in f['sources']:
 if not i.get('manifest'):continue
 m=load_manifest(R/i['snapshot']);b=InstalledBundle(bundle_id=m.bundle_id,distribution_name='real-source:'+i['source_commit'],distribution_version=m.bundle_version,manifest_path=R/i['snapshot'],manifest=m,entry_points=());bundles[i['role']]=b
 check=dataclasses.asdict(provider.check(m,{}));status=status_for(b,ExtensionConfig(True,{}),include_external_providers=False).as_dict();members.append({'role':i['role'],'actual_provider_check':check,'actual_Manager_check_status':status})
orders=[]
for order in f['orders']:
 plans=[];errors=[]
 for role in order:
  try:plans.append(plan_for(bundles[role],ExtensionConfig(True,{}),include_external_providers=False))
  except ValueError as e:errors.append({'role':role,'error':str(e)})
 try:reject_conflicting_plans(tuple(plans));composition='no-declared-plan-conflict'
 except ValueError as e:composition=str(e)
 orders.append({'order':order,'plans':[plan_dict(p) for p in plans],'plan_errors':errors,'composition_check':composition,'runtime_installation_order_executed':False})
imports=[]
for name,mod in sorted(sys.modules.items()):
 p=getattr(mod,'__file__',None)
 if p and (name.startswith('vllm_hust_ext') or name.startswith('vllm.plugins')) and Path(p).is_file():imports.append({'module':name,'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()})
versions={name:md.version(name) for name in ['vllm','vllm-ascend','vllm-hust-ext']}
result={'schema':'ecpa-h2-actual-provider-source-pair-observation/v1','freeze_sha256':hashlib.sha256((R/'freeze.json').read_bytes()).hexdigest(),'actual_python':sys.executable,'actual_versions':versions,'actual_capabilities':dataclasses.asdict(detect_vllm_capabilities()),'members':members,'orders':orders,'actual_imports':imports,'completed_wall_ns':time.time_ns(),'completed_monotonic_ns':time.monotonic_ns(),'independent_runtime_oracle':'unknown','score_eligible':False,'formal_result':False,'device_execution':False,'runtime_effective':None,'inter_MOD_conflict_detection':None,'n4_unchanged':True}
(R/'observation.json').write_text(json.dumps(result,indent=2,default=str)+'\n');print(json.dumps(result,indent=2,default=str))
