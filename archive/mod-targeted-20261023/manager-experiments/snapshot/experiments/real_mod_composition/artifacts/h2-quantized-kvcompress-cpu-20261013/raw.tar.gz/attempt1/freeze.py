from pathlib import Path
import hashlib,json,time,subprocess
R=Path(__file__).parent;S=Path('/root/ecpa-h3-worker-real-venv-0a6fdbc/lib/python3.12/site-packages')
h=lambda b:hashlib.sha256(b).hexdigest();items=[]
repos=[('quantized','/root/ecpa-h2-sources/vllm-ascend-quantized-kv-cache-hust','2f0b37b63dc1aba25f035a0dbf620f4abb73b2b3',['src/vllm_ascend_quantized_kv_cache/extension_manager_manifest/vllm-hust-extension-v0.2.json','src/vllm_ascend_quantized_kv_cache/bootstrap.py','src/vllm_ascend_quantized_kv_cache/core/hosts.py','src/vllm_ascend_quantized_kv_cache/adapters/vllm_ascend_hust/backend.py','src/vllm_ascend_quantized_kv_cache/adapters/vllm_ascend_hust/register.py','pyproject.toml']),('kvcompress','/root/ecpa-h2-sources/vllm-ascend-kvcompress-hust','00cc78dc7f3491eecbc79c5068e29aed9f59afc3',['src/vllm_ascend_kvcompress/manifests/vllm-hust-extension-v0.3.json','src/vllm_ascend_kvcompress/plugin.py','src/vllm_ascend_kvcompress/provider.py','pyproject.toml'])]
for role,root,commit,paths in repos:
 assert subprocess.check_output(['git','-C',root,'rev-parse','HEAD'],text=True).strip()==commit
 assert not subprocess.check_output(['git','-C',root,'status','--porcelain'])
 for i,path in enumerate(paths):
  raw=Path(root,path).read_bytes();assert raw==subprocess.check_output(['git','-C',root,'show',f'{commit}:{path}']);dest=f'sources/{role}-{i}.source';(R/dest).parent.mkdir(exist_ok=True);(R/dest).write_bytes(raw);items.append({'role':role,'source_commit':commit,'source_path':str(Path(root,path)),'snapshot':dest,'sha256':h(raw),'manifest':i==0})
for path in sorted((S/'vllm_hust_ext').rglob('*.py')):
 dest='manager-source/'+str(path.relative_to(S));(R/dest).parent.mkdir(parents=True,exist_ok=True);(R/dest).write_bytes(path.read_bytes());items.append({'role':'actual-installed-manager','source_path':str(path),'snapshot':dest,'sha256':h(path.read_bytes())})
for path in [S/'vllm/plugins/extension_capabilities.py',S/'vllm/plugins/capabilities.py']:
 if path.exists():
  dest='sources/'+path.name;(R/dest).write_bytes(path.read_bytes());items.append({'role':'actual-installed-host','source_path':str(path),'snapshot':dest,'sha256':h(path.read_bytes())})
f={'schema':'ecpa-h2-real-source-pair-CPU-qualification/v1','frozen_wall_ns':time.time_ns(),'frozen_monotonic_ns':time.monotonic_ns(),'case_id':'quantized-kvcompress-actual-host379','sources':items,'configuration':{},'orders':[['quantized','kvcompress'],['kvcompress','quantized']],'provider_semantic_oracle':{'decision':'unknown','score_eligible':False,'basis':'Independently reviewed actual source: quantized backend dispatch is cache-dtype-gated and reads packed cache formats; KVCompress changes request/block state and materializes cache blocks. Their combined layout/indexing and install-order behavior has no independently executed runtime oracle. Neither declared resource names nor passing checks establish coexistence.','implementation_paths':['quantized-4','kvcompress-2'],'label_frozen_before_provider_predictions':True},'formal_result':False,'old_score_unchanged':True,'device_execution':False,'python':'/root/ecpa-h3-worker-real-venv-0a6fdbc/bin/python'}
(R/'freeze.json').write_text(json.dumps(f,indent=2)+'\n');print(h((R/'freeze.json').read_bytes()))
