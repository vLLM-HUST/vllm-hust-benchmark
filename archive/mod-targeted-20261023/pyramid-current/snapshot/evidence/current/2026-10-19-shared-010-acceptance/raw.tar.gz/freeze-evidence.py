"""Freeze the candidate receipt after the real smoke, without rewriting failures."""
import gzip,hashlib,json,shutil,subprocess,tarfile,urllib.request
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parent
out=Path('/root/workspace/pyramidkv-shared010/evidence/current/2026-10-19-shared-010-acceptance')
assert not (out/'raw.tar.gz').exists()
summary=json.loads((root/'smoke/summary.json').read_text())
assert summary['passed']
logs=root/'logs/managed-20261019T114712Z'
assert (logs/'ready.json').exists()
raw=root/'evidence-snapshot';raw.mkdir(exist_ok=False)
for p in root.iterdir():
 if p.is_file() and p.suffix in {'.json','.log','.sh','.py','.patch','.diff','.txt'}:
  shutil.copyfile(p,raw/p.name)
for dirname in ['smoke','candidate-wheels','pyramid-candidate-wheels']:
 shutil.copytree(root/dirname,raw/dirname)
for name in ['server.log','ready.json','startup-cache-events.json']:
 shutil.copyfile(logs/name,raw/name)
shutil.copyfile(root/'manager/config/vllm-hust-ext/config.json',raw/'manager-config.json')
shutil.copyfile('/root/workspace/pyramidkv-runtime/env.sh',raw/'base-env.sh')
shutil.copyfile('/root/workspace/vllm-ascend-pyramidkv-hust/scripts/qwen35/smoke.py',raw/'smoke.py')
shutil.copyfile('/root/workspace/pyramidkv-runtime/public-audit-20261019/pypi.json',raw/'public-shared-pypi.json')
(raw/'npu-after.txt').write_text(subprocess.check_output(['npu-smi','info'],text=True))
client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with client.open('http://127.0.0.1:8000/health',timeout=5) as r:status=r.status
receipt={'observed_at_utc':datetime.now(timezone.utc).isoformat(),'health_http_status':status,'candidate_smoke_passed':summary['passed'],'published_shared_wheel_runtime_accepted':False,'candidate_model_calls':len(summary['requests']),'dataset_tasks_executed':0,'scope':'local repaired candidate functional check, not public 0.10.0 acceptance or performance','process_commands':{str(pid):Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode() for pid in [87440,88229,91430,91431]},'memory_events':Path('/sys/fs/cgroup/memory.events').read_text()}
(raw/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(p for p in raw.rglob('*') if p.is_file())
members={str(p.relative_to(raw)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with (out/'raw.tar.gz').open('wb') as stream:
 with gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in files:
    info=tar.gettarinfo(str(p),arcname=str(p.relative_to(raw)));info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
    with p.open('rb') as f:tar.addfile(info,f)
(out/'raw-members.json').write_text(json.dumps(members,indent=2)+'\n')
for src,dst in [('receipt.json','receipt.json'),('artifact-provenance.json','artifact-provenance.json'),('installed-provenance.json','installed-provenance.json'),('smoke/summary.json','candidate-smoke-summary.json')]:shutil.copyfile(raw/src,out/dst)
with tarfile.open(out/'raw.tar.gz') as tar:assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}==members
print(json.dumps({'members':len(members),'bytes':(out/'raw.tar.gz').stat().st_size,'summary':summary},indent=2))
