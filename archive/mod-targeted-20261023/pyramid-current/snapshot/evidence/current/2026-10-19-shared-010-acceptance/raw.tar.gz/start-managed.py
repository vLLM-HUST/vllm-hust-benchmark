"""Start the prepared Manager server and stop cache advice at readiness."""
import fcntl
import json
import os
import subprocess
import time
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parent
lock = (root / 'start-managed.lock').open('w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
client = urllib.request.build_opener(urllib.request.ProxyHandler({}))
pid_file = root / 'server.pid'
if pid_file.exists():
    pid = int(pid_file.read_text())
    proc = Path(f'/proc/{pid}/cmdline')
    if proc.exists() and b'qwen35-pyramidkv' in proc.read_bytes():
        raise SystemExit(f'Server PID {pid} is already running or starting; no new process launched.')
try:
    with client.open('http://127.0.0.1:8000/health', timeout=2):
        raise SystemExit('Port 8000 already serves a healthy endpoint; no new process launched.')
except OSError:
    pass
run = root / 'logs' / time.strftime('managed-%Y%m%dT%H%M%SZ', time.gmtime())
run.mkdir(parents=True, exist_ok=False)
log = (run / 'server.log').open('wb')
process = subprocess.Popen(['bash', str(root / 'serve-managed.sh')], stdout=log,
                           stderr=subprocess.STDOUT, start_new_session=True)
pid_file.write_text(str(process.pid) + '\n')
events = []
print(f'Manager PID {process.pid}; log: {run / "server.log"}', flush=True)
for _ in range(450):
    if process.poll() is not None:
        raise SystemExit(f'Manager exited {process.returncode}; inspect {run / "server.log"}')
    try:
        with client.open('http://127.0.0.1:8000/health', timeout=1) as response:
            if response.status == 200:
                (run / 'ready.json').write_text(json.dumps({'manager_pid': process.pid,
                    'ready_at': time.time(), 'startup_cache_events': len(events)}, indent=2))
                print('Ready; startup cache monitor has stopped.', flush=True)
                break
    except OSError:
        pass
    memory = int(Path('/sys/fs/cgroup/memory.current').read_text())
    if memory > 48 * 1024**3:
        for shard in Path('/root/workspace/Qwen3.5-35B-A3B').glob('*.safetensors'):
            descriptor = os.open(shard, os.O_RDONLY)
            try:
                os.posix_fadvise(descriptor, 0, 0, os.POSIX_FADV_DONTNEED)
            finally:
                os.close(descriptor)
        events.append({'time': time.time(), 'memory_bytes_before': memory})
    (run / 'startup-cache-events.json').write_text(json.dumps(events, indent=2))
    time.sleep(2)
else:
    raise SystemExit(f'Readiness timeout; PID {process.pid} is left for inspection; no more cache advice.')
