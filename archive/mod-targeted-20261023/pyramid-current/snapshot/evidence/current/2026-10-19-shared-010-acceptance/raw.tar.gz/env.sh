#!/usr/bin/env bash
set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export ASCEND_RT_VISIBLE_DEVICES="${PYRAMIDKV_VISIBLE_DEVICES:-0,1}"
export PATH="/root/workspace/pyramidkv-runtime/release-acceptance-20261019/venv/bin:$PATH"
export XDG_CONFIG_HOME=/root/workspace/pyramidkv-runtime/release-acceptance-20261019/manager/config
export XDG_STATE_HOME=/root/workspace/pyramidkv-runtime/release-acceptance-20261019/manager/state
export XDG_CACHE_HOME=/root/workspace/pyramidkv-runtime/release-acceptance-20261019/cache
if [[ "${BASH_SOURCE[0]}" == "$0" && $# -gt 0 ]]; then exec "$@"; fi
