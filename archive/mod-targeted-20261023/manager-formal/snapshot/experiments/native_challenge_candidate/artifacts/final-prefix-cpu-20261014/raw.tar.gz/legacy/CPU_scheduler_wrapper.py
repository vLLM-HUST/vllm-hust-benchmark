import socket,struct,time
from experiments.exposure_gate import native_semantic_collector as m
original=m.Handler.handle
def scheduled(self):
 pid=struct.unpack('3i',self.request.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))[0]
 if pid not in self.server.collector.senders:time.sleep(.15)
 return original(self)
m.Handler.handle=scheduled
m.main()
