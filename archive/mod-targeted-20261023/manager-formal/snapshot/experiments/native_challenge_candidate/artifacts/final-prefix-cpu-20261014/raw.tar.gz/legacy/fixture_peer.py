import json,sys,time
from experiments.exposure_gate.native_semantic_collector import identity,submit_fact
process=identity(__import__('os').getpid())|dict(host="cpu-fixture-only",role=sys.argv[1],ordinal=int(sys.argv[2]),process_epoch=9,assignment_source="host")
print(json.dumps(process),flush=True)
for line in sys.stdin:
 command=json.loads(line)
 fact=command['fact']
 fact.setdefault('process',process)
 fact.setdefault('monotonic_ns',time.monotonic_ns())
 if fact.get('observed_after_barrier_monotonic_ns')=='NOW':
  fact['observed_after_barrier_monotonic_ns']=time.monotonic_ns()
 try:
  if command.get('bootstrap'):
   from experiments.exposure_gate.native_semantic_bootstrap import callback_from_context
   ack=callback_from_context(__import__('pathlib').Path(command['bootstrap']))(fact)
  else:
   ack=submit_fact(__import__('pathlib').Path(command['socket']),fact,expected_collector=command['ready']['collector'],expected_socket_identity=tuple(command['ready']['socket_identity']),expected_collector_source_sha256=command['ready']['collector_source_sha256'],expected_archive_identity=command['ready']['archive_identity'])
  print(json.dumps({'ack':ack}),flush=True)
 except Exception as exc:
  print(json.dumps({'rejected':str(exc)}),flush=True)
