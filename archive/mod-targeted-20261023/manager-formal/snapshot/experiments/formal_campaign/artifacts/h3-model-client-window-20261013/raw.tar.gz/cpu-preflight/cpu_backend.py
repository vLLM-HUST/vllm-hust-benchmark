"""CPU fixture only, for native controller/authority/client path preflight."""
import argparse,json,os,time,uuid
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--port',type=int,required=True);p.add_argument('--journal',type=Path,required=True);args=p.parse_args()
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200);self.end_headers();self.wfile.write(b'CPU_PREFLIGHT_ONLY')
 def do_POST(self):
  request=self.rfile.read(int(self.headers['Content-Length']));value=json.loads(request);response={'id':'cpu-fixture-'+uuid.uuid4().hex,'model':value['model'],'choices':[{'index':0,'text':'CPU-PREFLIGHT-ONLY','finish_reason':'stop'}],'usage':{'completion_tokens':1}}
  with args.journal.open('a') as f:f.write(json.dumps({'classification':'CPU_FIXTURE_ONLY','backend_pid':os.getpid(),'request_sha256':__import__('hashlib').sha256(request).hexdigest(),'response':response,'monotonic_ns':time.monotonic_ns()})+'\n');f.flush();os.fsync(f.fileno())
  body=json.dumps(response).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,*a):pass
ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
