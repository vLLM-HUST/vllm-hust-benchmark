"""Freeze the exact instruct prompt before any model backend launch."""
import hashlib,json,time
from pathlib import Path
from transformers import AutoTokenizer
r=Path(__file__).resolve().parent;model=Path('/models/Qwen2.5-7B-Instruct')
messages=[{'role':'user','content':'Reply exactly ECPA-H3-WINDOW-OK'}]
tokenizer=AutoTokenizer.from_pretrained(model,local_files_only=True)
prompt=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
(r/'model-prompt.txt').write_bytes(prompt.encode())
inputs={'classification':'PRELAUNCH_FROZEN_PROMPT','frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'model_root':str(model),'messages':messages,'apply_chat_template':{'tokenize':False,'add_generation_prompt':True},'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'tokenizer_files':{name:hashlib.sha256((model/name).read_bytes()).hexdigest() for name in ('tokenizer.json','tokenizer_config.json','vocab.json','merges.txt')},'payload':{'model':'ecpa-h3-model-window','prompt':prompt,'max_tokens':24,'temperature':0,'stream':False},'response_expectation':{'text_equals':'ECPA-H3-WINDOW-OK'},'request_url':'http://127.0.0.1:8187/v1/completions'}
(r/'model-request-inputs.json').write_text(json.dumps(inputs,sort_keys=True,indent=2)+'\n')
print(json.dumps({'prompt_sha256':inputs['prompt_sha256'],'prompt_bytes':len(prompt.encode()),'oracle':inputs['response_expectation']}))
