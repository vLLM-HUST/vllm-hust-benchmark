import os,json,time,subprocess,socket,hashlib,signal,urllib.request,urllib.error,shutil
from pathlib import Path
from dataclasses import asdict,replace
from importlib.metadata import version
from experiments.exposure_gate.loopback_traffic import LoopbackTrafficAdapter,frozen_target_set_sha256
from experiments.formal_campaign.h3_phase_barrier import identity,wait_native_prepare
from vllm_hust_ext.exposure_gate import LeaseGrant
from vllm_hust_ext.plan_artifact import read_plan_artifact,plan_artifact_bytes
from vllm_hust_ext.host_observer import observe_bound_invocations
from vllm_hust_ext.host_evidence import EntryPointBinding
os.umask(0o077)
R=Path(__file__).resolve().parent; assert R.stat().st_mode & 0o777 == 0o700; M=Path('/root/ecpa-manager-h3-window-3a55952'); V=Path('/root/ecpa-exposure-proxy-candidate-venv')
def save(name,value):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def http(port,path,body=None):
 req=urllib.request.Request(f'http://127.0.0.1:{port}{path}',data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 ns=time.monotonic_ns()
 try:
  with urllib.request.urlopen(req,timeout=90) as response: status=response.status;raw=response.read().decode()
 except urllib.error.HTTPError as e:status=e.code;raw=e.read().decode()
 return {'status':status,'body':raw,'request':body,'started_monotonic_ns':ns,'finished_monotonic_ns':time.monotonic_ns()}
def wait_file(p,child,timeout=20):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  if child.poll()!=None:raise RuntimeError('child exited '+str(child.returncode))
  if p.exists():return
  time.sleep(.1)
 raise TimeoutError(str(p))
def completion(name,port,tag):
 v=http(port,'/v1/chat/completions',{'model':'ecpa-h3-model-window','messages':[{'role':'user','content':'Reply exactly '+tag}],'temperature':0,'max_tokens':24,'stream':False});save(name,v);assert v['status']==200
 b=json.loads(v['body']);assert b['model']=='ecpa-h3-model-window' and b['usage']['completion_tokens']>0 and b['choices'][0]['message']['content'].strip()==tag,(name,b)
 return v
preflight=json.loads((R/'preflight.json').read_text());assert preflight['passed']
plan=read_plan_artifact(M/'experiments/false_effective/deployment-candidates/h1-kv-materialization-plan.json').plan
plan=replace(plan,host=replace(plan.host,version=version('vllm')),plugins=(replace(plan.plugins[0],artifact_sha256=preflight['wheels']['vllm-kv-materialization']['sha256']),));(R/'plan.json').write_bytes(plan_artifact_bytes(plan))
binding=EntryPointBinding('vllm.general_plugins','kv_materialization','vllm_kv_materialization.plugin:register_plugin',plan.plugins[0].id,plan.obligations[0].obligation_id)
launch='launch:h3-model-qualification-'+str(time.time_ns());controller='controller:h3-model-qualification'
env=dict(os.environ,PYTHONPATH=str(M/'src')+':'+str(M)+':/usr/local/Ascend/cann-9.1.0/python/site-packages:/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe',VLLM_ECPA_EVIDENCE_SINK='vllm_hust_ext.host_event_sink:append_event',VLLM_ECPA_EVIDENCE_STRICT='1',VLLM_ECPA_PLAN_ID=plan.plan_id,ECPA_HOST_EVENT_FSYNC='1',VLLM_PLUGINS='ascend,ascend_kv_connector,ascend_model,ascend_model_loader,kv_materialization',VLLM_WORKER_MULTIPROC_METHOD='spawn',OMP_NUM_THREADS='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS='12');env.pop('ASCEND_RT_VISIBLE_DEVICES',None)
backends=[];configs=[]
for label,port in [('predecessor',28187),('candidate',18187)]:
 (R/label).mkdir(mode=0o700);events=R/label/'events';events.mkdir(mode=0o700);e=env|{'HCCL_NPU_SOCKET_PORT_RANGE':'60000-60099' if label=='predecessor' else '60100-60199','HCCL_HOST_SOCKET_PORT_RANGE':'61000-61099' if label=='predecessor' else '61100-61199','VLLM_ECPA_LAUNCH_ID':launch+':'+label,'ECPA_HOST_EVENT_DIR':str(events),'ECPA_HOST_EVENT_DEVICE':str(events.stat().st_dev),'ECPA_HOST_EVENT_INODE':str(events.stat().st_ino)}
 cmd=[str(V/'bin/ecpa-host-launch'),'serve','/models/Qwen2.5-7B-Instruct','--served-model-name','ecpa-h3-model-window','--host','127.0.0.1','--port',str(port),'--tensor-parallel-size','2','--enforce-eager','--max-model-len','2048','--gpu-memory-utilization','0.25','--shutdown-timeout','20','--disable-ecpa-manager','--enable-entrypoints']
 configs.append({'label':label,'port':port,'argv':cmd,'env':e})
(R/'coordinator').mkdir(mode=0o700)
assert json.loads((R/'cpu-preflight/result.json').read_text())['passed']
for parent in (R,R/'coordinator',R/'candidate/events',R/'predecessor/events'):
 assert parent.stat().st_uid==os.getuid() and parent.stat().st_mode & 0o777==0o700
for name in ('authority.sock','authority.jsonl','coordinator/gate.sqlite','coordinator/prepare-barrier.json'):
 assert not (R/name).exists(), 'not a new path: '+name
spec={'root':str(R/'coordinator'),'authority_socket':str(R/'authority.sock'),'grant':{'holder':'h3-model-nonformal','fencing_token':1,'expires_at':int(time.time())+1800},'launch_id':launch,'candidate':{'generation':1,'label':'candidate','backend_port':18187},'predecessor':{'generation':0,'label':'predecessor','backend_port':28187},'evidence_identity_sha256':'sha256:'+digest(R/'plan.json')};save('spec.json',spec);save('recovery-binding.json',{'launch_id':launch,'registration_sha256':'sha256:'+digest(R/'spec.json')})
inputs={'classification':'QUALIFIED_NONFORMAL','formal_result':False,'matched_three_arm_result':False,'performance_result':False,'scope':'two live TP2 backends, ECPA-only finite client delivery window during native controller prepare crash/recovery','manager_commit':preflight['manager']['commit'],'launch_id':launch,'configs':[{**c,'env':{k:v for k,v in c['env'].items() if k.startswith(('VLLM_','ECPA_','ASCEND_','OMP_','HF_','TRANSFORMERS_','LD_','HCCL_','PYTHONPATH','PATH'))}} for c in configs],'cpu_preflight_sha256':{str(p.relative_to(R)):digest(p) for p in sorted((R/'cpu-preflight').rglob('*')) if p.is_file()},'memory_assessment':{'device_hbm_mb_each':65536,'utilization_each_backend':0.25,'estimated_weight_gb_each_backend_each_device':7.1,'two_backend_allocator_budget_mb_each_device':32768},'frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sha256':{n:digest(R/n) for n in ('preflight.json','device-init-probe.json','plan.json','spec.json','run.py','model-prompt.txt','model-request-inputs.json','freeze_model_prompt.py','cpu-to-model-source-equivalence.json')}};save('inputs.json',inputs)
children=[];result={'classification':'QUALIFICATION_FAILED','passed':False}
try:
 for c in configs:
  p=subprocess.Popen(c['argv'],env=c['env'],stdout=open(R/c['label']/'backend.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(p);backends.append(p);save(c['label']+'/launcher-identity.json',identity(p.pid))
  deadline=time.monotonic()+660
  while time.monotonic()<deadline:
   if p.poll()!=None:raise RuntimeError(c['label']+' backend exited '+str(p.returncode))
   try:
    h=http(c['port'],'/health')
    if h['status']==200:save(c['label']+'/health.json',h);break
   except OSError:pass
   time.sleep(1)
  else:raise TimeoutError('backend readiness '+c['label'])
  subprocess.run(['npu-smi','info'],stdout=open(R/c['label']/'npu-ready.txt','wb'))
  E=R/c['label']/'events';required=[];members=[]
  for f in sorted(E.glob('*.jsonl')):
   for raw in f.read_bytes().splitlines():
    event=json.loads(raw);proc=event['process']
    if proc['assignment_source']=='host' and event['event']=='invoked' and event['entry_point']['name']=='kv_materialization':
     if proc not in members:members.append(proc)
     if proc['role']=='worker':
      target={k:proc[k] for k in ('host','role','ordinal','process_epoch')}
      if target not in required:required.append(target)
  required.sort(key=lambda p:(p['host'],p['role'],p['ordinal'],p['process_epoch']));assert len(required)==2
  save(c['label']+'/membership.json',members)
  obs=observe_bound_invocations(E,expected_directory_identity=(E.stat().st_dev,E.stat().st_ino),plan=plan,launch_id=c['env']['VLLM_ECPA_LAUNCH_ID'],controller_instance=controller,bindings=[binding],required_processes=required);save(c['label']+'/invocation-observation.json',obs);assert obs['complete_coverage']
  for proc in members:
   for name in ('stat','cmdline','status'):
    dest=R/c['label']/'proc'/str(proc['pid'])/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path('/proc')/str(proc['pid'])/name,dest)
  completion(c['label']+'/direct-before.json',c['port'],'ECPA-H3-'+c['label'].upper())
 backend_registration={str(c['port']):{'process_identity':{k:v for k,v in identity(p.pid).items() if k!='session'},'generation':0 if c['label']=='predecessor' else 1,'model':'ecpa-h3-model-window','launch_id':c['env']['VLLM_ECPA_LAUNCH_ID']} for c,p in zip(configs,backends)}
 grant=LeaseGrant(**spec['grant']);pc=[str(V/'bin/python'),str(M/'experiments/exposure_gate/loopback_traffic.py'),'--socket',str(R/'authority.sock'),'--journal',str(R/'authority.jsonl'),'--listen-port','8187','--predecessor-port','28187','--candidate-port','18187','--predecessor-snapshot',json.dumps(spec['predecessor']),'--grant-holder',grant.holder,'--grant-token','1','--grant-expires-at',str(grant.expires_at),'--recovery-binding',str(R/'recovery-binding.json')]
 save('backend-registration.json',backend_registration)
 pc.extend(['--backend-registration',str(R/'backend-registration.json')])
 save('proxy-command.json',{'argv':pc});proxy=subprocess.Popen(pc,env=env,stdout=open(R/'proxy.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(proxy);wait_file(R/'authority.sock',proxy);save('proxy-identity.json',identity(proxy.pid));traffic=LoopbackTrafficAdapter(R/'authority.sock',grant)
 save('route-before.json',asdict(traffic.query_route()));completion('proxy-before.json',8187,'ECPA-H3-PREDECESSOR')
 native=[str(V/'bin/python'),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'launch','--spec',str(R/'spec.json')];launched_ns=time.monotonic_ns();manager=subprocess.Popen(native,env=env,stdout=open(R/'manager-before.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(manager);wait_file(R/'coordinator/prepare-barrier.json',manager)
 target=identity(manager.pid);state=json.loads(subprocess.check_output([str(V/'bin/python'),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'state','--spec',str(R/'spec.json')],env=env));save('state-prepared.json',state)
 proof=wait_native_prepare({'protocol':'ecpa-native-close-prepare-barrier/v1','barrier_path':str(R/'coordinator/prepare-barrier.json'),'journal_path':str(R/'coordinator/gate.sqlite'),'timeout_s':10},target=target,launcher_pid=manager.pid,launch_id=launch,launched_ns=launched_ns,state_before=state);save('prepare-proof.json',proof)
 client_payload=json.loads((R/'model-request-inputs.json').read_text())
 client_spec={'schema':'ecpa-h3-client-window-spec/v1','start_id':launch,'request_url':client_payload['request_url'],'payload':client_payload['payload'],'response_expectation':client_payload['response_expectation'],'request_count':60,'interval_s':.2,'timeout_s':10,'dispatch_slack_s':.5,'concurrency':8,'retry_policy':'single-attempt-no-retry','authority_registration_sha256':'sha256:'+digest(R/'spec.json'),'authority_process_identity':{k:v for k,v in identity(proxy.pid).items() if k!='session'},'backend_registration':backend_registration}
 save('client-spec.json',client_spec)
 save('frozen-client-inputs.json',{'frozen_ns':time.monotonic_ns(),'spec_sha256':digest(R/'client-spec.json'),'request_ids':[launch+f'/request-{i:05d}' for i in range(60)],'request_bytes_sha256':__import__('experiments.formal_campaign.h3_client_trace',fromlist=['sha','canonical']).sha(__import__('experiments.formal_campaign.h3_client_trace',fromlist=['canonical']).canonical(client_spec['payload']))})
 client_cmd=[str(V/'bin/python'),str(M/'experiments/formal_campaign/h3_client_trace.py'),'--spec',str(R/'client-spec.json'),'--trace',str(R/'client.jsonl'),'--ready',str(R/'client-ready.json')]
 client=subprocess.Popen(client_cmd,env=env,stdout=open(R/'client.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(client);wait_file(R/'client-ready.json',client);save('client-identity.json',{k:v for k,v in identity(client.pid).items() if k!='session'});time.sleep(2)
 fault_ns=time.monotonic_ns();os.kill(manager.pid,signal.SIGKILL);manager.wait(timeout=10);save('fault.json',{'target':target,'signal':'SIGKILL','monotonic_ns':fault_ns,'returncode':manager.returncode})
 for c in configs:completion(c['label']+'/during-crash.json',c['port'],'ECPA-H3-'+c['label'].upper())
 time.sleep(3)
 restart_ns=time.monotonic_ns();restart=subprocess.Popen(native,env=env,stdout=open(R/'manager-after.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(restart);wait_file(R/'coordinator/recovery.json',restart);save('restart.json',{'identity':identity(restart.pid),'monotonic_ns':restart_ns});recovery_ns=time.monotonic_ns();save('recovery-marker.json',{'restart_ns':restart_ns,'observed_ns':recovery_ns,'identity':identity(restart.pid)});assert identity(restart.pid)!=target
 save('route-after.json',asdict(traffic.query_route()));assert asdict(traffic.query_route())==asdict(__import__('vllm_hust_ext.exposure_gate',fromlist=['RouteState']).RouteState(0,'fence-0',spec['predecessor']))
 completion('proxy-after.json',8187,'ECPA-H3-PREDECESSOR');completion('candidate/direct-after.json',18187,'ECPA-H3-CANDIDATE')
 client.wait(timeout=30);assert client.returncode==0
 from experiments.formal_campaign.h3_client_trace import verify_window,read_client_trace
 window=verify_window(client_spec,R/'client.jsonl',R/'authority.jsonl',expected_client=json.loads((R/'client-identity.json').read_text()),fault_ns=fault_ns,recovery_ns=recovery_ns);save('verified-window.json',window);assert window['coverage']=='complete-finite-delivery-window',window
 sends=[e['detail']['sent_ns'] for e in read_client_trace(R/'client.jsonl') if e['kind']=='request.start'];assert max(sends)-recovery_ns>=2e9,'less than 2s observed arrivals after recovery'
 state=json.loads(subprocess.check_output([str(V/'bin/python'),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'state','--spec',str(R/'spec.json')],env=env));save('state-recovered.json',state)
 from experiments.formal_campaign.h3_authority_chain import verify_recovery_chain
 first=json.loads((R/'authority.jsonl').read_text().splitlines()[0]);derived=verify_recovery_chain(R/'authority.jsonl',expected_proxy=identity(proxy.pid),registration_sha256='sha256:'+digest(R/'spec.json'),launch_id=launch,prepared_route=first['route'],fault_ns=fault_ns,restart_ns=restart_ns,completion_ns=time.monotonic_ns());save('independent-recovery-chain.json',derived)
 result={'classification':'QUALIFIED_NONFORMAL','passed':True,'formal_result':False,'matched_three_arm_result':False,'performance_result':False,'launch_id':launch,'finished_monotonic_ns':time.monotonic_ns(),'scope':inputs['scope'],'window':window}
except Exception as e:result['error']=repr(e);raise
finally:
 for p in reversed(children):
  if p.poll()==None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=35)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
 save('result.json',result);subprocess.run(['npu-smi','info'],stdout=open(R/'cleanup-npu.txt','wb'));ports={}
 for port in (8187,18187,28187):
  with socket.socket() as s:ports[str(port)]=s.connect_ex(('127.0.0.1',port))
 save('cleanup-ports.json',ports)
