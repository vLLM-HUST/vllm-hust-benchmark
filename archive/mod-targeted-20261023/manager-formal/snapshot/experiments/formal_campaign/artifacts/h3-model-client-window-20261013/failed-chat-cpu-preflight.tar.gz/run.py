import os,json,time,subprocess,signal,hashlib,socket,urllib.request
from pathlib import Path
from dataclasses import asdict
from experiments.formal_campaign.h3_phase_barrier import identity,wait_native_prepare,read_native_recovery
from experiments.formal_campaign.h3_authority_chain import verify_native_recovery,verify_recovery_chain
from experiments.formal_campaign.h3_client_trace import verify_window,canonical
from experiments.exposure_gate.loopback_traffic import LoopbackTrafficAdapter
from vllm_hust_ext.exposure_gate import LeaseGrant
os.umask(0o077)
R=Path(__file__).resolve().parent;M=Path('/root/ecpa-manager-h3-window-394d4dd');V=Path('/root/ecpa-exposure-proxy-candidate-venv/bin/python');(R/'coordinator').mkdir(mode=0o700)
def save(n,v):(R/n).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def pid(p):return {k:v for k,v in identity(p).items() if k!='session'}
def sha(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def wait(p,c):
 for _ in range(200):
  if c.poll()!=None:raise RuntimeError('child exited '+str(c.returncode))
  if p.exists():return
  time.sleep(.05)
 raise TimeoutError(str(p))
env=os.environ|{'PYTHONPATH':str(M/'src')+':'+str(M)};children=[];launch='cpu-native-client-'+str(time.time_ns());model='ecpa-cpu-preflight-only';ports={'predecessor':29187,'candidate':19187}
spec={'root':str(R/'coordinator'),'authority_socket':str(R/'authority.sock'),'grant':{'holder':'cpu-native-client','fencing_token':1,'expires_at':int(time.time())+180},'launch_id':launch,'candidate':{'generation':1,'label':'candidate','backend_port':19187},'predecessor':{'generation':0,'label':'predecessor','backend_port':29187},'evidence_identity_sha256':'sha256:'+'a'*64};save('spec.json',spec);registration=sha(R/'spec.json');save('recovery-binding.json',{'launch_id':launch,'registration_sha256':registration});save('protocol.json',{'classification':'CPU_PREFLIGHT_ONLY','source_commit':subprocess.check_output(['git','-C',str(M),'rev-parse','HEAD'],text=True).strip(),'count':60,'interval_s':.2,'timeout_s':10,'concurrency':8,'dispatch_slack_s':.5,'retry':'single-attempt-no-retry','oracle':'CPU-PREFLIGHT-ONLY','run_sha256':sha(R/'run.py'),'fixture_sha256':sha(R/'cpu_backend.py')})
result={'passed':False,'classification':'CPU_PREFLIGHT_FAILED'}
try:
 backend={}
 for label,port in ports.items():
  cmd=[str(V),str(R/'cpu_backend.py'),'--port',str(port),'--journal',str(R/(label+'-requests.jsonl'))];p=subprocess.Popen(cmd,env=env,stdout=open(R/(label+'.log'),'wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(p)
  for _ in range(100):
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as h:assert h.status==200;break
   except OSError:time.sleep(.05)
  else:raise TimeoutError('CPU fixture not ready')
  backend[str(port)]={'process_identity':pid(p.pid),'generation':0 if label=='predecessor' else 1,'model':model,'launch_id':launch+':'+label}
 save('backend-registration.json',backend)
 grant=LeaseGrant(**spec['grant']);pc=[str(V),str(M/'experiments/exposure_gate/loopback_traffic.py'),'--socket',str(R/'authority.sock'),'--journal',str(R/'authority.jsonl'),'--listen-port','9187','--predecessor-port','29187','--candidate-port','19187','--predecessor-snapshot',json.dumps(spec['predecessor']),'--grant-holder',grant.holder,'--grant-token','1','--grant-expires-at',str(grant.expires_at),'--recovery-binding',str(R/'recovery-binding.json'),'--backend-registration',str(R/'backend-registration.json')];proxy=subprocess.Popen(pc,env=env,stdout=open(R/'authority.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(proxy);wait(R/'authority.sock',proxy);save('authority-identity.json',pid(proxy.pid));traffic=LoopbackTrafficAdapter(R/'authority.sock',grant)
 native=[str(V),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'launch','--spec',str(R/'spec.json')];launched=time.monotonic_ns();manager=subprocess.Popen(native,env=env,stdout=open(R/'manager-before.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(manager);wait(R/'coordinator/prepare-barrier.json',manager);state=json.loads(subprocess.check_output([str(V),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'state','--spec',str(R/'spec.json')],env=env));proof=wait_native_prepare({'protocol':'ecpa-native-close-prepare-barrier/v1','barrier_path':str(R/'coordinator/prepare-barrier.json'),'journal_path':str(R/'coordinator/gate.sqlite'),'timeout_s':10},target=identity(manager.pid),launcher_pid=manager.pid,launch_id=launch,launched_ns=launched,state_before=state);save('prepare-proof.json',proof)
 client_spec={'schema':'ecpa-h3-client-window-spec/v1','start_id':launch,'request_url':'http://127.0.0.1:9187/v1/chat/completions','payload':{'model':model,'messages':[{'role':'user','content':'CPU-PREFLIGHT-ONLY'}],'max_tokens':1,'temperature':0,'stream':False},'response_expectation':{'text_equals':'CPU-PREFLIGHT-ONLY'},'request_count':60,'interval_s':.2,'timeout_s':10,'dispatch_slack_s':.5,'concurrency':8,'retry_policy':'single-attempt-no-retry','authority_registration_sha256':registration,'authority_process_identity':pid(proxy.pid),'backend_registration':backend};save('client-spec.json',client_spec);save('frozen-client-inputs.json',{'frozen_ns':time.monotonic_ns(),'spec_sha256':sha(R/'client-spec.json'),'request_bytes_sha256':'sha256:'+hashlib.sha256(canonical(client_spec['payload'])).hexdigest(),'request_ids':[launch+f'/request-{i:05d}' for i in range(60)]})
 cc=[str(V),str(M/'experiments/formal_campaign/h3_client_trace.py'),'--spec',str(R/'client-spec.json'),'--trace',str(R/'client.jsonl'),'--ready',str(R/'client-ready.json')];client=subprocess.Popen(cc,env=env,stdout=open(R/'client.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(client);wait(R/'client-ready.json',client);save('client-identity.json',pid(client.pid));time.sleep(2);fault=time.monotonic_ns();target=identity(manager.pid);os.kill(manager.pid,signal.SIGKILL);manager.wait(timeout=10);save('fault.json',{'target':target,'monotonic_ns':fault,'returncode':manager.returncode});time.sleep(3);restart_ns=time.monotonic_ns();restart=subprocess.Popen(native,env=env,stdout=open(R/'manager-after.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(restart);wait(R/'coordinator/recovery.json',restart);recovery=time.monotonic_ns();save('recovery-marker.json',{'restart_ns':restart_ns,'observed_ns':recovery,'identity':pid(restart.pid)});client.wait(timeout=30);assert client.returncode==0
 window=verify_window(client_spec,R/'client.jsonl',R/'authority.jsonl',expected_client=json.loads((R/'client-identity.json').read_text()),fault_ns=fault,recovery_ns=recovery);save('verified-window.json',window);assert window['coverage_complete'],window
 verify_native_recovery(proof,read_native_recovery(R/'coordinator/gate.sqlite'));first=json.loads((R/'authority.jsonl').read_text().splitlines()[0]);chain=verify_recovery_chain(R/'authority.jsonl',expected_proxy=pid(proxy.pid),registration_sha256=registration,launch_id=launch,prepared_route=first['route'],fault_ns=fault,restart_ns=restart_ns,completion_ns=time.monotonic_ns());save('verified-recovery-chain.json',chain);result={'passed':True,'classification':'CPU_PREFLIGHT_ONLY','model_result':False,'formal_result':False,'window':window}
except Exception as e:result['error']=repr(e);raise
finally:
 for p in reversed(children):
  if p.poll()==None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
 save('result.json',result)
 ports_result={}
 for port in (9187,19187,29187):
  with socket.socket() as sock:ports_result[str(port)]=sock.connect_ex(('127.0.0.1',port))
 save('cleanup-ports.json',ports_result)
