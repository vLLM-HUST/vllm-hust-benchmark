"""Preregistered overall watchdog; exact owned identities only, never restart."""
import argparse,hashlib,json,os,pathlib,signal,subprocess,time
from experiments.formal_campaign import h3_worker_relaunch as lifecycle

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def store(p,v):p.write_text(json.dumps(v,indent=2));p.chmod(0o600)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('config',type=pathlib.Path);parser.add_argument('--expected-sha256',required=True);args=parser.parse_args()
 assert sha(args.config)==args.expected_sha256
 cfg=json.loads(args.config.read_bytes());root=args.config.parent
 assert sha(__file__)==cfg['outer_launcher_source_sha256']
 cpu_only=cfg.get('schema')=='CPU_ACTUAL_PROCESS_OVERALL_WATCHDOG_FIXTURE/v1'
 assert (cpu_only and cfg.get('GPU_started') is False and 0<cfg['overall_watchdog_s']<=2) or (not cpu_only and cfg['overall_watchdog_s']==1200)
 argv=[cfg['python'],cfg['owner_execution_path'],str(args.config),'--expected-sha256',args.expected_sha256]
 with (root/'preflight.stdout').open('wb') as out,(root/'preflight.stderr').open('wb') as err:p=subprocess.run(argv+['--preflight-only'],env=cfg['env'],stdout=out,stderr=err,timeout=120)
 store(root/'CPU-preflight-exit.json',{'exitcode':p.returncode,'GPU_started':False,'formal_result':False})
 if p.returncode:return p.returncode
 started=time.monotonic_ns()
 with (root/'owner-cli.stdout').open('wb') as out,(root/'owner-cli.stderr').open('wb') as err:actor=subprocess.Popen(argv,env=cfg['env'],stdout=out,stderr=err,start_new_session=True)
 expected=lifecycle.identity(actor.pid);store(root/'actual-owner-kernel.json',{'kernel':expected,'argv':argv,'cmdline_sha256':sha('/proc/'+str(actor.pid)+'/cmdline'),'started_monotonic_ns':started,'formal_result':False})
 deadline=started+int(cfg['overall_watchdog_s']*1_000_000_000);fired=False;stops=[];captured={expected['pid']:expected};errors=[]
 while actor.poll() is None:
  try:
   new,_=lifecycle.owned_sessions(expected,captured)
   captured.update({x['pid']:x for x in new})
  except ValueError:
   if lifecycle.live(expected):raise
  if time.monotonic_ns()>=deadline:
   fired=True
   # Capture every live descendant session before killing a supervisor. The
   # independent cleanup owns Manager/API/collector sessions even if owner
   # finally never executes.
   try:lifecycle.cleanup(actor,expected,.5 if cpu_only else 10,list(captured.values()))
   except Exception as exc:errors.append(str(exc))
   break
  time.sleep(.05 if cpu_only else .5)
 if not fired and any(lifecycle.members(x) for x in captured.values()):
  errors.append('unexpected owner exit left independently owned sessions; forced cleanup')
  try:lifecycle.cleanup(actor,expected,.5 if cpu_only else 10,list(captured.values()))
  except Exception as exc:errors.append(str(exc))
 terminal={'captured_sessions':list(captured.values()),'remaining_sessions':[{'owner':x,'members':lifecycle.members(x)} for x in captured.values()],'owner_identity_still_live':lifecycle.live(expected),'formal_result':False,'wall_ns':time.time_ns(),'cleanup_errors':errors}
 store(root/'outer-independent-terminal-audit.json',terminal)
 if any(x['members'] for x in terminal['remaining_sessions']) or terminal['owner_identity_still_live']:errors.append('actual independently captured session remains live')
 store(root/'outer-watchdog-result.json',{'overall_watchdog_s':cfg['overall_watchdog_s'],'started_monotonic_ns':started,'completed_monotonic_ns':time.monotonic_ns(),'fired':fired,'owned_stops':stops,'independently_captured_sessions':list(captured.values()),'cleanup_errors':errors,'original_owner_exit':actor.returncode,'formal_result':False,'no_restart':True})
 print(json.dumps({'owner_exit':actor.returncode,'outer_watchdog_fired':fired,'formal_result':False}))
 return actor.returncode if not fired and not errors else 124
if __name__=='__main__':raise SystemExit(main())
