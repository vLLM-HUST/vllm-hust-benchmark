"""Private executable owner preparation; no GPU until an exact tuple is frozen."""
import argparse
import hashlib
import json
import os
import selectors
import socket
import signal
import subprocess
import time
import traceback
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

from experiments.formal_campaign import h3_worker_relaunch as lifecycle
from experiments.native_challenge_candidate import collector_client, request_runner
from experiments.exposure_gate import native_semantic_bootstrap as bootstrap
from experiments.exposure_gate import native_semantic_collector as collector
from vllm_hust_ext.runtime_phase_handoff import bind_receiver, accept_native_binding


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(8*1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    raw = request_runner.canonical(value)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return hashlib.sha256(raw).hexdigest()


def require(value, text):
    if not value:
        raise ValueError(text)


def preflight(config):
    require(config['schema'] == 'ecpa-native-KV-owner/v2', 'owner schema')
    require(config['formal_result'] is False, 'formal promotion')
    require(config['scope'] == 'KV-host-metadata-to-later-upload-only', 'scope changed')
    require(set(config['wheel_artifacts']) == {'host', 'ascend', 'mod', 'manager',
        'torch', 'torch_npu', 'triton'}, 'exact seven wheels required')
    for item in config['wheel_artifacts'].values():
        require(digest(item['path']) == item['sha256'], 'wheel bytes changed')
    require(config['wheel_artifacts']['host']['revision'] ==
        'b1f0f3e3adbf0ef6e95c666285354930a0a1cb4c', 'final Host source required')
    require(config['wheel_artifacts']['ascend']['revision'] == 'fcbb827af84f793939bf03d01a1dfe0338a0164c',
        'old Ascend wheel cannot substitute native observer source')
    require(config['wheel_artifacts']['ascend']['sha256'] ==
        'be5a69b8dc2dd9a77144657a6d394aa7079e95054aef54dda41f260b0af6eb86',
        'exact native Ascend wheel required')
    require(config['wheel_artifacts']['host']['sha256'] ==
        'b16aa2412c7de8799462565609589bb8fd5c2a2e94c5f7313d57a431ebccf677',
        'exact registered Host wheel required')
    require(config['physical_devices'] == [3, 6] and config['runtime_devices'] == [0, 1],
        'device allocation changed')
    require(len(config['model_files']) == 14, 'complete fourteen-file model freeze')
    for item in config['sources'] + config['model_files']:
        require(Path(item['path']).is_absolute() and digest(item['path']) == item['sha256'],
            'source/model bytes changed')
    require(digest(__file__) == config['owner_source_sha256'], 'owner bytes changed')
    required_roles = {'request-runner', 'collector-client', 'collector', 'bootstrap',
        'host-input-processor', 'host-request-base', 'host-request-protocol', 'host-chat-serving',
        'host-native-observer', 'ascend-gpu-model-runner', 'mod-plugin',
        'manager-cli', 'manager-handoff', 'manager-evidence', 'manager-supervisor',
        'host-process-evidence', 'host-native-materialized-producer','host-gpu-input-batch','host-block-table','host-base-model-runner','mod-provider'}
    require(required_roles <= {x['role'] for x in config['sources']},
        'native source closure incomplete')
    collector.source_digests(config['native_source_files'])
    source_map = {x['path']: x['sha256'] for x in config['sources']}
    require(all(source_map.get(x['path']) == x['sha256'] for x in config['native_source_files']),
        'native source registrations differ from prelaunch bytes')
    require(Path(config['npu_smi_path']).is_file() and os.access(config['npu_smi_path'], os.X_OK), 'actual diagnostic executable absent')
    require(digest(config['calibration_artifact']['path']) == config['calibration_artifact']['sha256'], 'validated calibration input changed')
    env = config['env']
    require(not any(k in env for k in ('VLLM_ECPA_PLAN_ID', 'VLLM_ECPA_LAUNCH_ID',
        'VLLM_HUST_EXT_EVIDENCE_PATH', 'ASCEND_RT_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES',
        'NPU_VISIBLE_DEVICES', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY')), 'reserved env')
    require(env['HOME'] == env['TRITON_HOME'] == '/root', 'cache resolver closure')
    require(env['ECPA_NATIVE_SEMANTIC_BOOTSTRAP'] == config['bootstrap_context'],
        'prelaunch context path not frozen')
    require(not Path(config['bootstrap_context']).exists(), 'context is not fresh')
    cache = Path(env['TRITON_CACHE_DIR'])
    m = cache.stat()
    require(m.st_uid == os.getuid() and m.st_mode & 0o777 == 0o700 and
        [m.st_dev, m.st_ino] == config['cache_identity'] and not list(cache.iterdir()),
        'cold private cache policy changed')
    recipe_raw = Path(config['recipe']).read_bytes()
    require(hashlib.sha256(recipe_raw).hexdigest() == config['recipe_sha256'],
        'recipe differs from preregistered bytes')
    recipe = json.loads(recipe_raw)
    request_runner.validate(recipe)
    require(recipe['schema'] == 'ecpa-native-kv-challenge-campaign/v2', 'exact materialized-row recipe schema')
    require(config['oracle_tokenization']['sample_policy'] == 'one-fresh-sample-cpu-reject-if-short-no-runtime-retuning' and config['oracle_tokenization']['count'] >= 32, 'preregistered oracle token budget')
    require(config['oracle_tokenization']['expected'] == recipe['phases'][0]['response_oracle']['expected'], 'oracle input binding')
    require(digest(Path(config['recipe']).parent/'oracle-tokenization.json') == config['oracle_tokenization_sha256'], 'actual frozen oracle token input bytes')
    require(config['oracle_tokenization']['token_ids_sha256'] == hashlib.sha256(request_runner.canonical(config['oracle_tokenization']['token_ids'])).hexdigest() and config['oracle_tokenization']['count'] == len(config['oracle_tokenization']['token_ids']), 'oracle token IDs digest/count')
    require(recipe['frozen_monotonic_ns'] < config['frozen_monotonic_ns'],
        'request preregistration did not precede owner freeze')
    require(len(recipe['phases']) == 1, 'one bounded interface phase only')
    target = urlsplit(recipe['phases'][0]['url'])
    health = urlsplit(config['health_url'])
    require(health.scheme == target.scheme and health.hostname == target.hostname and
        health.port == target.port and health.path == '/health', 'health/phase target mismatch')
    try:
        with socket.create_connection((health.hostname, health.port), timeout=0.2):
            raise ValueError('frozen backend port is already occupied')
    except OSError:
        pass
    require('@native_phase_socket@' in config['argv'], 'native mint handoff required')
    return recipe


def selected_peers(path, native_env, owner, captured, source_files):
    sessions, descendants = lifecycle.owned_sessions(owner)
    captured[:] = list({p['pid']: p for p in captured + sessions}.values())
    selected = {}
    if not path.exists():
        return None
    raw = path.read_bytes()
    # A concurrent append may end with an incomplete frame. Retain raw bytes
    # in the native journal and retry that suffix next poll; corrupt complete
    # frames remain fatal.
    complete = raw[:raw.rfind(b'\n') + 1]
    for line in complete.splitlines():
        row = json.loads(line)
        p = row.get('process', {})
        key = (p.get('role'), p.get('ordinal'))
        if key not in {('api-server', 0), ('worker', 0), ('worker', 1)}:
            continue
        if row.get('event') != 'invoked' or row.get('entry_point', {}).get('name') != 'ascend_kvcompress':
            continue
        require(row['plan_id'] == native_env['VLLM_ECPA_PLAN_ID'] and
            row['launch_id'] == native_env['VLLM_ECPA_LAUNCH_ID'] and
            p['assignment_source'] == 'host', 'foreign Host evidence')
        kernel = collector_client.identity(p['pid'])
        require(p['start_identity'] == kernel['start_identity'] and
            p['pid'] in descendants, 'non-owned Host worker/API identity')
        actual = {**p, **kernel}
        candidate = {'process': actual, 'peer_uid': os.getuid(), 'peer_gid': os.getgid(),
            'cmdline_sha256': digest(f"/proc/{p['pid']}/cmdline"), 'source_files': source_files}
        require(key not in selected or selected[key] == candidate, 'ambiguous Host identity')
        selected[key] = candidate
    if set(selected) != {('api-server', 0), ('worker', 0), ('worker', 1)}:
        return None
    require(len({p['process']['pid'] for p in selected.values()}) == 3,
        'distinct actual API/two-rank processes required')
    return [selected[k] for k in (('api-server', 0), ('worker', 0), ('worker', 1))]


def run(config, recipe):
    out = Path(config['output'])
    require(out.is_absolute() and not out.exists(), 'fresh absolute output')
    out.mkdir(mode=0o700)
    out.chmod(0o700)  # mkdir inherits setgid from the container workspace.
    out_meta = out.stat()
    require(out_meta.st_uid == os.getuid() and out_meta.st_mode & 0o7777 == 0o700,
        'collector output directory must actually be owned mode0700')
    write(out/'owner-config.json', config)
    write(out/'collector-directory-identity.json', {'path':str(out),
        'uid':out_meta.st_uid, 'device':out_meta.st_dev, 'inode':out_meta.st_ino,
        'actual_mode':out_meta.st_mode & 0o7777, 'formal_result':False})
    result = {'scope': config['scope'], 'formal_result': False, 'passed': False,
        'producer_registration_classification':'CPU_REVIEW_CANDIDATE_ONLY',
        'runtime_evidence_classification':'REAL_RUNTIME_ATTEMPT_UNQUALIFIED',
        'actual_hardware_transport_observed':False,
        'KV_MOD_semantic_obligation_satisfied': None, 'GPU_semantic_qualification': None,
        'lost_requests': None, 'duplicate_requests': None, 'full_objective_satisfied': None}
    process = authority = listener = None
    authority_owner = None
    captured, peers = [], []
    try:
        # Gate immediately before the first possible GPU-producing child.
        preflight(config)
        phase_socket = Path(config['phase_socket'])
        listener = bind_receiver(phase_socket, 30)
        argv = [str(phase_socket) if v == '@native_phase_socket@' else v for v in config['argv']]
        write(out/'launch-argv.json', argv)
        launched = time.time_ns()
        with (out/'backend.stdout').open('wb') as stdout, (out/'backend.stderr').open('wb') as stderr:
            process = subprocess.Popen(argv, env=config['env'], cwd=config['cwd'],
                start_new_session=True, stdout=stdout, stderr=stderr)
        owner = lifecycle.identity(process.pid)
        captured.append(owner)
        write(out/'launcher-kernel-identity.json', owner)
        receipt = accept_native_binding(listener, phase_socket, owner, launched,
            config['manager_source_sha256'], out/'handoff-raw.json')
        write(out/'native-binding.json', receipt)
        native_env = receipt['environment']
        journal = Path(native_env['VLLM_HUST_EXT_EVIDENCE_PATH'])
        deadline = time.monotonic() + config['startup_timeout_s']
        while time.monotonic() < deadline:
            require(process.poll() is None, 'backend terminated before source registration')
            peers = selected_peers(journal, native_env, owner, captured, config['native_source_files'])
            if peers:
                try:
                    with urllib.request.urlopen(config['health_url'], timeout=2) as response:
                        if response.status == 200:
                            break
                except OSError:
                    pass
            time.sleep(0.2)
        else:
            raise ValueError('startup observation deadline; preserve attempt, do not restart')
        write(out/'actual-owned-source-peers.json', peers)
        phase = recipe['phases'][0]
        spec = {'schema':'ecpa-native-kv-semantic-collector-prereg/v2',
            'classification':'CPU_REVIEW_CANDIDATE_ONLY', 'formal_producer_registration':False,
            'native_plan_id':native_env['VLLM_ECPA_PLAN_ID'],
            'native_launch_id':native_env['VLLM_ECPA_LAUNCH_ID'],
            'frozen_monotonic_ns':time.monotonic_ns(), 'max_event_age_ns':5_000_000_000,
            'max_uploads_per_rank':256, 'senders':peers,
            'phases':[{k:phase[k] for k in ('phase_id','client_request_id','challenge_nonce',
                'external_request_id','expected_ranks')}]}
        spec['kv_requirements'] = {phase['phase_id']:phase['kv_requirements']}
        spec_path = out/'collector-spec.json'
        write(spec_path, spec)
        socket_path, raw = out/'collector.sock', out/'native-raw.jsonl'
        actual_parent = raw.parent.stat()
        require(raw.parent == out and actual_parent.st_uid == os.getuid() and
            actual_parent.st_mode & 0o7777 == 0o700 and
            (actual_parent.st_dev, actual_parent.st_ino) == (out_meta.st_dev, out_meta.st_ino),
            'actual collector journal parent is not the frozen private output directory')
        collector_argv = [config['python'], '-m', 'experiments.exposure_gate.native_semantic_collector',
            '--spec', str(spec_path), '--socket', str(socket_path), '--journal', str(raw)]
        write(out/'collector-launch-argv.json', collector_argv)
        authority = subprocess.Popen(collector_argv, env=config['env'], cwd=config['cwd'],
            start_new_session=True, stdout=subprocess.PIPE, stderr=(out/'collector.stderr').open('wb'))
        authority_owner = lifecycle.identity(authority.pid)
        sel = selectors.DefaultSelector()
        sel.register(authority.stdout, selectors.EVENT_READ)
        require(sel.select(10), 'collector startup deadline')
        ready_raw = authority.stdout.readline(65537)
        (out/'collector-ready.bin').write_bytes(ready_raw)
        require(ready_raw.endswith(b'\n') and len(ready_raw) <= 65536,
            'collector failed before ready; preserve collector.stderr as primary cause')
        ready = json.loads(ready_raw)
        descriptor = {**ready, 'launcher_observed_identity':collector_client.identity(authority.pid),
            'launcher_observed_cmdline_sha256':digest(f'/proc/{authority.pid}/cmdline')}
        write(out/'collector-launcher-descriptor.json', descriptor)
        collector_client.authenticate(socket_path, descriptor, spec_path, Path(config['collector_source']))
        bootstrap.write_context(Path(config['bootstrap_context']), spec_path=spec_path,
            ready=ready, source_files=config['native_source_files'])
        rpc = request_runner.execute_with_collector(recipe, phase['phase_id'], out/'probe',
            socket_path=socket_path, descriptor=descriptor, spec_path=spec_path,
            collector_source_path=Path(config['collector_source']), journal_path=raw)
        result['probe'] = rpc
        result['passed'] = rpc.get('KV_MOD_metadata_upload_binding_observed') is True
        if result['passed']:
            result['actual_hardware_transport_observed'] = True
            result['runtime_evidence_classification'] = 'REAL_NATIVE_KV_METADATA_UPLOAD_BINDING_NONFORMAL'
    except Exception as exc:
        result['failure'] = str(exc)
        (out/'failure-trace.txt').write_text(traceback.format_exc())
    finally:
        errors = []
        if authority is not None:
            try:
                lifecycle.cleanup(authority, authority_owner, 10)
            except Exception as exc:
                errors.append('collector cleanup: '+str(exc))
        if process is not None:
            try:
                lifecycle.cleanup(process, owner, 10, captured)
            except Exception as exc:
                errors.append('backend cleanup: '+str(exc))
        if listener is not None:
            listener.close()
        result['cleanup_errors'] = errors
        if errors:
            result['passed'] = False
        peer_audits = []
        for p in peers or []:
            expected = {k:p['process'][k] for k in ('pid','start_ticks','boot_id','session')}
            try:
                current = lifecycle.identity(expected['pid'])
            except (FileNotFoundError, ProcessLookupError, ValueError):
                current = None
            peer_audits.append({'source_process':p['process'], 'expected_kernel':expected,
                'observed_kernel':current, 'same_identity_live':current == expected,
                'different_live_identity':current is not None and current != expected})
        audit = {'wall_ns':time.time_ns(), 'captured_sessions':captured,
            'remaining_sessions':[{'owner':p, 'members':lifecycle.members(p)} for p in captured],
            'source_peers':peer_audits, 'formal_result':False}
        if any(x['members'] for x in audit['remaining_sessions']) or any(
                x['same_identity_live'] for x in peer_audits):
            result['passed'] = False
            errors.append('terminal observer found actual live owned identities')
        if 'health_url' in config:
            target = urlsplit(config['health_url'])
            opened = False
            try:
                with socket.create_connection((target.hostname, target.port), timeout=0.2):
                    opened = True
            except OSError:
                pass
            audit['backend_port'] = {'host':target.hostname,'port':target.port,'open':opened}
            if opened:
                errors.append('frozen backend port remains open')
                result['passed'] = False
        write(out/'terminal-process-audit.json', audit)
        with (out/'terminal-npu-smi.txt').open('wb') as stream:
            subprocess.run([config['npu_smi_path'],'info'], stdout=stream, stderr=subprocess.STDOUT, check=False)
        write(out/'result.json', result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('config', type=Path)
    p.add_argument('--expected-sha256', required=True)
    p.add_argument('--preflight-only', action='store_true')
    args = p.parse_args()
    require(digest(args.config) == args.expected_sha256, 'owner freeze differs')
    config = json.loads(args.config.read_bytes())
    recipe = preflight(config)
    if args.preflight_only:
        print(json.dumps({'source_preflight_passed':True,'gpu_started':False,'formal_result':False}))
        return 0
    result = run(config, recipe)
    print(json.dumps(result, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
