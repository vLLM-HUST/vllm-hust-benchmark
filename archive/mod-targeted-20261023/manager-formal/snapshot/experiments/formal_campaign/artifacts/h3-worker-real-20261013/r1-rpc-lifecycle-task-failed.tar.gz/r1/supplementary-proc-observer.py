import os,json,time,datetime,hashlib
from pathlib import Path
R=Path('/root/ecpa-h3-worker-real-qualification-20261013-r1')
c=json.loads((R/'campaign.json').read_text());a=next(a for a in c['arms'] if a['id']=='ecpa')
rows=[]
for i in range(2):
 p=R/'ecpa'/f'phase{i}.native-binding.json'
 if not p.exists():continue
 b=json.loads(p.read_text());pid=b['publisher']['pid'];pdir=Path(f'/proc/{pid}')
 try:
  rawenv=pdir.joinpath('environ').read_bytes();cmd=pdir.joinpath('cmdline').read_bytes();stat=pdir.joinpath('stat').read_text();values=dict(s.split(b'=',1) for s in rawenv.split(b'\0') if b'=' in s)
 except (FileNotFoundError,ProcessLookupError):continue
 frozen={k:values.get(k.encode(),b'').decode() for k in a['env']}
 fields=stat.rsplit(')',1)[1].split();assert int(fields[19])==b['publisher']['start_ticks']
 rows.append({'phase':i,'pid':pid,'identity':b['publisher'],'cmdline':cmd.decode().rstrip('\0').split('\0'),'frozen_env_observed':frozen,'frozen_env_matches':frozen==a['env'],'environment_keys':sorted(k.decode() for k in values),'native_reserved_env_present':sorted(k.decode() for k in values if k.startswith((b'VLLM_ECPA_PLAN_ID',b'VLLM_ECPA_LAUNCH_ID',b'VLLM_HUST_EXT_EVIDENCE_PATH'))),'source_receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_ns':time.time_ns(),'classification':'supplementary_late_read_only_observer_not_preregistered','formal_result':False,'observer_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
p=R/f'supplementary-proc-observer-{time.time_ns()}.json';p.write_text(json.dumps(out,indent=2)+'\n');print(str(p),[(r['phase'],r['pid'],r['frozen_env_matches']) for r in rows])
