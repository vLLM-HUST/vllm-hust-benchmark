import torch,torch_npu,json,os,time
from pathlib import Path
r=Path(__file__).resolve().parent
v={'schema':'ecpa-real-npu-init-probe/v1','utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'environment':{k:v for k,v in os.environ.items() if k.startswith(('ASCEND_','NPU_','HCCL_'))},'device_nodes':[str(p) for p in Path('/dev').glob('davinci*')],'device_count':torch.npu.device_count(),'probes':[]}
assert 'ASCEND_RT_VISIBLE_DEVICES' not in os.environ
assert v['device_count']==2
for ordinal in range(2):
 torch.npu.set_device(ordinal);x=torch.ones(1,device='npu:'+str(ordinal));torch.npu.synchronize();assert x.cpu().item()==1
 v['probes'].append({'logical_device':ordinal,'name':torch.npu.get_device_name(ordinal),'allocation_cpu_value':1})
v['passed']=True;(r/'device-init-probe.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
