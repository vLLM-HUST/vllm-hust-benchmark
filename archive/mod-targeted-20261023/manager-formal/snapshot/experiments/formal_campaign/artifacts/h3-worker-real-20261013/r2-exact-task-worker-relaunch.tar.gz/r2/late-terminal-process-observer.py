from pathlib import Path
import sys,json,hashlib,time,datetime
R=Path(sys.argv[1]);boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();c=json.loads((R/'campaign.json').read_text());expected={};sessions={};journal_hashes={}
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for arm in c['arms']:
 name=arm['id'];result=json.loads((R/name/'result.json').read_text());assert result['passed']
 for phase in range(2):
  if name=='ecpa':
   receipt=json.loads((R/name/f'phase{phase}.native-binding.json').read_text());journal=Path(receipt['environment']['VLLM_HUST_EXT_EVIDENCE_PATH']);manager=receipt['publisher'];expected[(manager['pid'],manager['start_ticks'])]={'pid':manager['pid'],'start_ticks':manager['start_ticks'],'roles':['manager'],'source':str((R/name/f'phase{phase}.native-binding.json').relative_to(R))}
  else:journal=Path(arm['phases'][phase]['evidence_path'])
  journal_hashes[str(journal.relative_to(R))]=h(journal)
  for row in map(json.loads,journal.read_text().splitlines()):
   proc=row['process'];key=(proc['pid'],int(proc['start_identity'].rsplit(':',1)[1]));item=expected.setdefault(key,{'pid':key[0],'start_ticks':key[1],'roles':[],'source':str(journal.relative_to(R))})
   if proc['role'] not in item['roles']:item['roles'].append(proc['role'])
  for event in result['events']:
   for owner in event.get('ownership_sessions',[]):sessions[owner['pid']]=owner
rows=[]
for item in expected.values():
 try:
  fields=Path(f"/proc/{item['pid']}/stat").read_text().rsplit(')',1)[1].split();observed={'state':fields[0],'start_ticks':int(fields[19]),'session':int(fields[3])};alive=observed['state']!='Z' and observed['start_ticks']==item['start_ticks']
 except (FileNotFoundError,ProcessLookupError):observed=None;alive=False
 assert not alive,item
 rows.append({**item,'observed_proc':observed,'expected_identity_alive':alive})
residual=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:fields=(p/'stat').read_text().rsplit(')',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):continue
 if fields[0]!='Z' and int(fields[3]) in sessions:residual.append({'pid':int(p.name),'start_ticks':int(fields[19]),'session':int(fields[3])})
assert not residual,residual
out={'schema':'ecpa-worker-late-terminal-observer/v1','classification':'late-read-only-observer-not-preregistered','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_ns':time.time_ns(),'boot_id':boot,'journal_sha256':journal_hashes,'rows':rows,'captured_ownership_sessions':list(sessions.values()),'live_members_of_captured_sessions':residual,'observer_source_sha256':h(Path(__file__)),'formal_result':False}
(R/'late-terminal-process-audit.json').write_text(json.dumps(out,indent=2)+'\n');(R/'late-terminal-process-observer.py').write_bytes(Path(__file__).read_bytes());print('terminal source identities',len(rows),'captured sessions',len(sessions),'no expected live identities/session members')
