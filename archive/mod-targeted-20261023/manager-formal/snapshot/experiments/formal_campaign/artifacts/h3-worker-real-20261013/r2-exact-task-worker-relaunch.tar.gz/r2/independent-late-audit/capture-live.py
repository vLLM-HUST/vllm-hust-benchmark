import pathlib,json,time,hashlib,os
r=pathlib.Path('/root/ecpa-h3-worker-real-qualification-20261013-r2');out=pathlib.Path('/root/ecpa-h3-worker-independent-audit-20261013/r2');c=json.loads((r/'campaign.json').read_text());rows=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:
  raw=(p/'environ').read_bytes();cmd=(p/'cmdline').read_bytes()
  if str(r).encode() not in raw:continue
  env={k.decode():v.decode() for k,v in [x.split(b'=',1) for x in raw.split(b'\0') if b'=' in x]}
  launch=env.get('VLLM_ECPA_LAUNCH_ID');contract=env.get('ECPA_ACTIVATION_CONTRACT');a=next((a for a in c['arms'] if a['activation_contract']==contract),None)
  if not a:continue
  if not launch and b'--phase-binding-socket' not in cmd:continue
  stat=(p/'stat').read_text(); fields=stat.rsplit(')',1)[1].split();identity={'pid':int(p.name),'start_ticks':int(fields[19]),'session':int(fields[3]),'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
  rows.append({'arm':a['id'],'identity':identity,'cmdline':[x.decode() for x in cmd.split(b'\0') if x],'frozen_env':{k:env.get(k) for k in a['env']},'frozen_env_matches':all(env.get(k)==v for k,v in a['env'].items()),'additional_env_names':sorted(set(env)-set(a['env'])),'native_or_phase_keys':{k:env.get(k) for k in ['VLLM_ECPA_PLAN_ID','VLLM_ECPA_LAUNCH_ID','VLLM_HUST_EXT_EVIDENCE_PATH','VLLM_ECPA_PROCESS_ROLE','VLLM_ECPA_PROCESS_ORDINAL']},'ASCEND_RT_VISIBLE_DEVICES_present':'ASCEND_RT_VISIBLE_DEVICES' in env})
 except (OSError,ValueError,UnicodeError):continue
snapshot={'schema':'ecpa-independent-late-live-environment/v1','classification':'QUALIFIED_NONFORMAL','formal_result':False,'capture_wall_ns':time.time_ns(),'capture_monotonic_ns':time.monotonic_ns(),'campaign_sha256':hashlib.sha256((r/'campaign.json').read_bytes()).hexdigest(),'not_preregistered_observer':True,'owned_processes':rows}
f=out/f'live-{snapshot["capture_wall_ns"]}.json';f.write_text(json.dumps(snapshot,indent=2)+'\n');print(json.dumps({'raw':str(f),'processes':[(x['arm'],x['identity']['pid'],x['frozen_env_matches'],x['native_or_phase_keys']['VLLM_ECPA_LAUNCH_ID']) for x in rows]}))
