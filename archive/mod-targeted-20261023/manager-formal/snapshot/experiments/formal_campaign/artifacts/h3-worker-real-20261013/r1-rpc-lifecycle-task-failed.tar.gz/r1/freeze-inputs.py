from pathlib import Path
import json,hashlib,os,datetime,subprocess,socket,sys
from vllm_hust_ext.runtime_phase_handoff import PROTOCOL,manager_source_digests
from experiments.formal_campaign.h3_worker_relaunch import validate
R=Path('/root/ecpa-h3-worker-real-qualification-20261013-r1');M=Path('/root/ecpa-manager-h3-worker-real');V=Path('/root/ecpa-h3-worker-real-venv-0a6fdbc');site=V/'lib/python3.12/site-packages'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((R/'preflight.json').read_text())['passed'];cpu=Path('/root/ecpa-h3-worker-real-cpu-20261013-r1');assert json.loads((cpu/'summary.json').read_text())['passed']
(R/'cpu-preflight').mkdir(exist_ok=False)
for f in ('summary.json','campaign.json','manager-config.json'):(R/'cpu-preflight'/f).write_bytes((cpu/f).read_bytes())
config=R/'manager-config.json';config.write_text(json.dumps({'schema_version':2,'extensions':{'org.vllm-hust.kv-materialization-arrival-control':{'enabled':True,'configuration':{}}}},indent=2)+'\n')
r4=json.loads(Path('/root/ecpa-h3-model-qualification-20261013-r4/inputs.json').read_text())
base={k:v for k,v in r4['configs'][0]['env'].items() if not k.startswith(('VLLM_ECPA_','ECPA_HOST_','ECPA_CONTROLLER'))}
base.update(PYTHONPATH=str(M)+':/usr/local/Ascend/cann-9.1.0/python/site-packages:/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe',VLLM_HUST_EXT_CONFIG=str(config),HCCL_NPU_SOCKET_PORT_RANGE='62000-62099',HCCL_HOST_SOCKET_PORT_RANGE='62100-62199')
base.pop('ASCEND_RT_VISIBLE_DEVICES',None);base.pop('VLLM_HUST_EXT_EVIDENCE_PATH',None);base.pop('VLLMHUST_EXT_ENABLED_BUNDLES',None)
contracts={'vanilla-vllm-entry-points':'entry-points-unmanaged','manual-integration':'explicit-manual-hooks','ecpa':'manager-controlled-activation'}
c={'schema':'ecpa-h3-worker-relaunch-qualification/v1','classification':'QUALIFIED_NONFORMAL','formal_result':False,'original_manager_cell_completed':False,'recovery_action':'common-external-full-relaunch','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'policy':{'signal':'SIGKILL','relaunches':1,'ready_timeout_s':300,'exit_timeout_s':20,'cleanup_timeout_s':10,'probe_poll_s':.2,'request_timeout_s':5},'arms':[]}
for n,(name,contract) in enumerate(contracts.items()):
 port=29181+n;native=name=='ecpa';env=dict(base);env['ECPA_ACTIVATION_CONTRACT']=contract
 target=[str(V/'bin/python'),str(V/'bin/ecpa-host-launch'),'serve','/models/Qwen2.5-7B-Instruct','--served-model-name','ecpa-worker-relaunch','--host','127.0.0.1','--port',str(port),'--tensor-parallel-size','2','--enforce-eager','--max-model-len','2048','--gpu-memory-utilization','0.35','--shutdown-timeout','20']
 if not native:target+=['--disable-ecpa-manager','--manual-hooks' if name=='manual-integration' else '--enable-entrypoints'];env['VLLM_ECPA_EVIDENCE_SINK']='vllm_hust_ext.runtime_evidence:record_event';env['VLLM_ECPA_EVIDENCE_STRICT']='1'
 cmd=target if not native else [str(V/'bin/python'),str(V/'bin/vllm-hust-ext'),'run','--phase-binding-socket','@native_phase_socket@','--shutdown-grace-seconds','2','--',*target]
 arm={'id':name,'activation_contract':contract,'cwd':str(R),'argv':cmd,'env':env,'evidence_protocol':'vllm-host-worker-event/v1','target_ordinal':0,'probe':{'url':f'http://127.0.0.1:{port}/v1/chat/completions','payload':{'model':'ecpa-worker-relaunch','messages':[{'role':'user','content':'Reply exactly ECPA-WORKER-READY'}],'temperature':0,'max_tokens':24,'stream':False}},'sources':[{'role':'launcher','path':cmd[1],'sha256':h(Path(cmd[1])),'revision':'0a6fdbc7784a0db0a92fc50615f5ca3efbf5f966'},{'role':'host','path':str(site/'vllm/v1/executor/multiproc_executor.py'),'sha256':h(site/'vllm/v1/executor/multiproc_executor.py'),'revision':'379a0ad35e9de6928e3481d375692204b0dee6e4'},{'role':'mod','path':str(site/'vllm_kv_materialization/plugin.py'),'sha256':h(site/'vllm_kv_materialization/plugin.py'),'revision':'e343fc5ce6b4c64611a79df5d797b3db12cd6dac'}]}
 if native:arm.update(binding_protocol=PROTOCOL,manager_source_sha256=manager_source_digests(),phases=[{'handoff_path':str(R/f'native{i}.sock')} for i in range(2)])
 else:arm.update(plan_id='worker-qualification-fixed-plan',phases=[{'launch_id':f'worker-qual-r1-{name}-phase{i}','evidence_path':str(R/f'{name}-phase{i}.jsonl')} for i in range(2)])
 c['arms'].append(arm)
validate(c)
probe=R/'device-probe.py';probe.write_bytes(Path('/root/ecpa-h3-model-qualification-20261013-r4/device_probe.py').read_bytes())
(R/'runner.source').write_bytes((M/'experiments/formal_campaign/h3_worker_relaunch.py').read_bytes())
(R/'input-audit.py').write_bytes(Path('/tmp/ecpa-worker-real-audit.py').read_bytes())
(R/'freeze-inputs.py').write_bytes(Path('/tmp/ecpa-worker-real-freeze.py').read_bytes())
p=R/'campaign.json';p.write_text(json.dumps(c,indent=2)+'\n');digest=h(p)
freeze={'classification':'QUALIFIED_NONFORMAL','formal_result':False,'performance_result':False,'three_arm_native_transactional_result':False,'manager_source_commit':'0a6fdbc7784a0db0a92fc50615f5ca3efbf5f966','campaign_sha256':digest,'first_gpu_not_started':True,'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'device_policy':{'physical':[3,6],'runtime_ordinals':[0,1],'ASCEND_RT_VISIBLE_DEVICES':'unset'},'files_sha256':{f:h(R/f) for f in ('preflight.json','manager-config.json','runner.source','device-probe.py','input-audit.py','freeze-inputs.py','cpu-preflight/summary.json','cpu-preflight/campaign.json','cpu-preflight/manager-config.json')},'lost_requests':None,'duplicate_requests':None,'full_objective_satisfied':None}
(R/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps({'campaign_sha256':digest,'freeze_sha256':h(R/'freeze.json'),'arms':3,'planned_backend_starts':6,'planned_worker_faults':3,'first_gpu_not_started':True}))
