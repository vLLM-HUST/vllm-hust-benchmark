from pathlib import Path
import hashlib,json,zipfile,importlib.metadata as md,urllib.parse,subprocess,sys,os,socket,datetime
R=Path('/root/ecpa-h3-worker-real-qualification-20261013-r1');R.mkdir(mode=0o700,exist_ok=True)
M=Path('/root/ecpa-manager-h3-worker-real');V=Path('/root/ecpa-h3-worker-real-venv-0a6fdbc')
def h(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):d.update(b)
 return d.hexdigest()
report={'classification':'QUALIFICATION_INPUT_AUDIT','audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'installed':{},'wheels':{}}
assert Path(sys.prefix)==V
for name in ('vllm','vllm-ascend','vllm-kv-materialization','torch','torch-npu','triton-ascend','vllm-hust-ext'):
 d=md.distribution(name);direct=json.loads(d.read_text('direct_url.json'));p=Path(urllib.parse.unquote(urllib.parse.urlparse(direct['url']).path));assert p.is_file()
 mismatch=[];checks=0
 with zipfile.ZipFile(p) as z:
  for f in z.namelist():
   if f.endswith('.py') and '.data/' not in f:
    checks+=1;local=Path(d.locate_file(f))
    if not local.is_file() or local.read_bytes()!=z.read(f):mismatch.append(f)
 report['installed'][name]={'version':d.version,'metadata_sha256':hashlib.sha256(d.read_text('METADATA').encode()).hexdigest(),'direct_url':direct}
 report['wheels'][name]={'path':str(p),'sha256':h(p),'python_files_checked':checks,'mismatches':mismatch};assert not mismatch,(name,mismatch)
assert report['wheels']['vllm']['sha256']=='a850a238b7ac0b6fdb9fd0ceb833dd843c0242570977b0f14fae482fe8d3d551'
assert report['wheels']['vllm-ascend']['sha256']=='16438dc60e86c7bc4741a3520d80d5f9de54676daabe2035ebff0d6b2dceefcf'
assert report['wheels']['vllm-kv-materialization']['sha256']=='581caaff07a610bfc3ce9280c315e9548b532fb119731d14fff002aea6825b1c'
assert report['wheels']['vllm-hust-ext']['sha256']=='0498efa84fa0739abc924f9680764ec3ba88c0ab9eaf5574906038cb0a1f2358'
report['manager']={'commit':subprocess.check_output(['git','-C',str(M),'rev-parse','HEAD'],text=True).strip(),'dirty':subprocess.check_output(['git','-C',str(M),'status','--porcelain'],text=True)};assert report['manager']['commit']=='0a6fdbc7784a0db0a92fc50615f5ca3efbf5f966' and not report['manager']['dirty']
report['manager']['source_sha256']={str(p.relative_to(M)):h(p) for p in (M/'src').rglob('*.py')}
report['model']={'root':'/models/Qwen2.5-7B-Instruct','files':{p.name:h(p) for p in sorted(Path('/models/Qwen2.5-7B-Instruct').iterdir()) if p.is_file()}}
report['venv']={'path':str(V),'prefix':sys.prefix,'sys_path':sys.path,'shared_source':'/root/ecpa-exposure-proxy-candidate-venv','clone':'cp -a --reflink=auto, independent file inodes; only clone scripts rewritten'}
a=V/'lib/python3.12/site-packages/torch/__init__.py';b=Path('/root/ecpa-exposure-proxy-candidate-venv/lib/python3.12/site-packages/torch/__init__.py');assert a.stat().st_ino!=b.stat().st_ino
report['env']={k:v for k,v in os.environ.items() if k.startswith(('ASCEND','LD_','PYTHONPATH','OMP','HCCL'))};assert 'ASCEND_RT_VISIBLE_DEVICES' not in os.environ
report['cann']={'toolkit_path':os.environ.get('ASCEND_HOME_PATH'),'version_info':Path('/usr/local/Ascend/cann-9.1.0/version.info').read_text()}
report['ports']={}
for port in (29181,29182,29183):
 with socket.socket() as probe:report['ports'][str(port)]=probe.connect_ex(('127.0.0.1',port));assert report['ports'][str(port)]!=0
report['passed']=True;(R/'preflight.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(R),'passed':True,'manager_wheel_sha256':report['wheels']['vllm-hust-ext']['sha256'],'model_files':len(report['model']['files'])}))
