# SPDX-License-Identifier: Apache-2.0
"""Opt-in ``vllm.general_plugins`` registration for current vLLM Ascend."""

from __future__ import annotations

import os
import sys
from contextlib import nullcontext
from contextvars import ContextVar
from importlib import import_module
from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec, PathFinder
from types import ModuleType
from typing import Any

from vllm.logger import logger

from .config import extension_enabled, load_runtime_selection
from .provider import (
    ATTENTION_QUERY_PROVIDER_ATTRIBUTE,
    RUNNER_PROVIDER_ATTRIBUTE,
    AscendKVCompressionProvider,
    _supports_mtp2,
)

_PATCH_MARKER = "_ascend_kvcompress_patch_v3"
_RUNNER_MODULE = "vllm_ascend.worker.model_runner_v1"
_runner_patch_finder: _RunnerPatchFinder | None = None
_TRITON_GLUON_MODULES = (
    "triton.experimental",
    "triton.experimental.gluon",
    "triton.experimental.gluon.language",
    "triton.experimental.gluon.nvidia",
)
_MESSAGE_QUEUE_MODULE = "vllm.distributed.device_communicators.shm_broadcast"
_MESSAGE_QUEUE_PATCH_MARKER = "_ascend_kvcompress_env_chunk_default"
_METADATA_PROVIDER: ContextVar[AscendKVCompressionProvider | None] = ContextVar(
    "ascend_kvcompress_metadata_provider", default=None
)


def register() -> None:
    """Install hooks only when direct or Extension Manager activation is explicit."""
    if not extension_enabled():
        return
    selection = load_runtime_selection()
    logger.info(
        "Ascend KV compression plugin activated provider=%s method=%s",
        selection.provider_name,
        selection.method,
    )
    _prepare_current_triton_runtime()
    _configure_message_queue_defaults()

    from vllm.v1.core.kv_cache_manager import KVCacheManager
    from vllm.v1.core.sched.scheduler import Scheduler

    _install_lazy_runner_hook(selection)

    from .stateful import install_stateful_compression_hooks

    install_stateful_compression_hooks(Scheduler, KVCacheManager, selection)


class _RunnerPatchLoader(Loader):
    def __init__(self, wrapped: Loader, selection: Any) -> None:
        self.wrapped = wrapped
        self.selection = selection

    def create_module(self, spec: ModuleSpec) -> ModuleType | None:
        create = getattr(self.wrapped, "create_module", None)
        return create(spec) if create is not None else None

    def exec_module(self, module: ModuleType) -> None:
        from .host_compat import install_removed_routed_experts_types

        install_removed_routed_experts_types()
        self.wrapped.exec_module(module)
        _install_runner_hooks(module.NPUModelRunner, self.selection)


class _RunnerPatchFinder(MetaPathFinder):
    """Wrap only the Ascend runner loader without importing it in API processes."""

    def __init__(self, selection: Any) -> None:
        self.selection = selection

    def find_spec(
        self,
        fullname: str,
        path: Any = None,
        target: ModuleType | None = None,
    ) -> ModuleSpec | None:
        del target
        if fullname != _RUNNER_MODULE:
            return None
        spec = PathFinder.find_spec(fullname, path)
        if spec is None or spec.loader is None:
            return spec
        spec.loader = _RunnerPatchLoader(spec.loader, self.selection)
        return spec


def _install_lazy_runner_hook(selection: Any) -> None:
    global _runner_patch_finder
    loaded = sys.modules.get(_RUNNER_MODULE)
    if loaded is not None and hasattr(loaded, "NPUModelRunner"):
        _install_runner_hooks(loaded.NPUModelRunner, selection)
        return
    if _runner_patch_finder is None:
        _runner_patch_finder = _RunnerPatchFinder(selection)
        sys.meta_path.insert(0, _runner_patch_finder)


def _install_runner_hooks(runner_cls: type[Any], selection: Any) -> None:
    if runner_cls.__dict__.get(_PATCH_MARKER, False):
        return
    if (
        runner_cls.__module__ == _RUNNER_MODULE
        and runner_cls.__name__ == "NPUModelRunner"
    ):
        from .host_compat import (
            install_dcp_length_alias,
            install_removed_async_output_routing_field,
            install_removed_output_routing_field,
            install_step3p5_fp32_linear_alias,
        )

        install_step3p5_fp32_linear_alias()
        install_dcp_length_alias()
        install_removed_output_routing_field()
        install_removed_async_output_routing_field()
        _install_gdn_metadata_hook()
    # Current vLLM folded the legacy ``xdrope_section`` check into
    # ``uses_mrope`` while the aligned Ascend runner still reads this old
    # attribute in three paths.  Supply the neutral legacy value only when the
    # host no longer defines it; models using xdrope are already represented by
    # ``uses_mrope`` on this validated vLLM line.
    if not hasattr(runner_cls, "uses_xdrope_dim"):
        runner_cls.uses_xdrope_dim = 0
    # The current Ascend runner reads this flag even when routed-expert
    # capture is disabled. Its initializer only sets the flag in the enabled
    # branch, while this plugin explicitly rejects that optional output.
    if not hasattr(runner_cls, "routed_experts_initialized"):
        runner_cls.routed_experts_initialized = False
    original_initialize = runner_cls.initialize_kv_cache
    original_load_model = runner_cls.load_model
    original_update = runner_cls._update_states
    original_metadata = runner_cls._build_attention_metadata
    original_sample = runner_cls.sample_tokens
    from .host_compat import qwen_gdn_list_compat_enabled

    gdn_list_compat = qwen_gdn_list_compat_enabled()
    original_execute_model = getattr(runner_cls, "execute_model", None)
    if gdn_list_compat and original_execute_model is None:
        raise RuntimeError("Qwen GDN list compatibility requires execute_model")

    def load_model(runner: Any) -> Any:
        from .calibration import ensure_calibration_for_runner
        from .host_compat import (
            install_grouped_topk_router_compat,
            install_layer_aware_fia_graph_replay,
            install_qwen_gdn_list_compat,
        )
        from .methods import create_method
        from .model import model_shape_from_config

        runner_config = getattr(runner, "vllm_config", None)
        if runner_config is not None:
            method_probe = create_method(
                selection.method,
                selection.method_config,
                runner_config,
                model_shape_from_config(runner_config.model_config),
            )
            if method_probe.requires_per_layer_physical_state:
                install_layer_aware_fia_graph_replay(runner_config)
            if method_probe.query_window_tokens:
                _install_attention_query_hook()

        install_qwen_gdn_list_compat(
            mtp2_reference_fallback=_supports_mtp2(getattr(runner, "vllm_config", None))
        )
        model_config = getattr(
            getattr(runner, "vllm_config", None), "model_config", None
        )
        hf_config = getattr(model_config, "hf_config", None)
        model_type = str(getattr(hf_config, "model_type", ""))
        if model_type.startswith("qwen3_5"):
            # Load the host's native registrations first. Only fill the
            # missing GDN output op; never shadow a newer Ascend binary.
            import_module("vllm_ascend.vllm_ascend_C")
            from .qwen_gdn_ops import install_missing_chunk_output_op

            if install_missing_chunk_output_op():
                logger.info("Using plugin-owned Triton Qwen GDN output operator")
        install_grouped_topk_router_compat()
        generated = ensure_calibration_for_runner(runner, selection)
        if generated:
            logger.info(
                "Generated model-matched TriAttention calibration artifact "
                "before loading serving weights"
            )
        return original_load_model(runner)

    def initialize_kv_cache(
        runner: Any, kv_cache_config: Any, *args: Any, **kwargs: Any
    ) -> Any:
        provider = AscendKVCompressionProvider(runner.vllm_config, selection)
        provider.validate_host(runner)
        setattr(runner, RUNNER_PROVIDER_ATTRIBUTE, provider)
        from .host_compat import (
            install_removed_model_routing_flag,
            qwen_mtp2_cache_binding_bridge,
        )

        install_removed_model_routing_flag(runner.vllm_config)
        bridge = (
            qwen_mtp2_cache_binding_bridge()
            if _supports_mtp2(runner.vllm_config)
            else nullcontext()
        )
        with bridge:
            result = original_initialize(runner, kv_cache_config, *args, **kwargs)
        # Ascend deep-copies and normalizes the incoming plan before storing
        # the cache config that actually owns the allocated tensors.
        provider.bind_model_runner(runner, runner.kv_cache_config)
        _install_runtime_slot_mapping_hooks(
            runner, getattr(provider, "attention_group_index", 0)
        )
        return result

    def update_states(runner: Any, scheduler_output: Any) -> Any:
        provider = getattr(runner, RUNNER_PROVIDER_ATTRIBUTE, None)
        if provider is not None:
            provider.before_update_states(scheduler_output)
        result = original_update(runner, scheduler_output)
        if provider is not None:
            provider.after_update_states(scheduler_output)
        return result

    def build_attention_metadata(runner: Any, *args: Any, **kwargs: Any) -> Any:
        provider = getattr(runner, RUNNER_PROVIDER_ATTRIBUTE, None)
        if provider is not None:
            provider.apply_physical_attention_lengths()
        token = _METADATA_PROVIDER.set(provider)
        try:
            result = original_metadata(runner, *args, **kwargs)
        finally:
            _METADATA_PROVIDER.reset(token)
        if provider is not None and (
            getattr(provider, "requires_per_layer_physical_state", False)
            or getattr(provider, "_has_per_layer_rows", False)
        ):
            num_tokens = args[0] if args else kwargs["num_tokens"]
            num_reqs = args[1] if len(args) > 1 else kwargs["num_reqs"]
            return provider.per_layer_attention_metadata(result, num_tokens, num_reqs)
        return result

    def sample_tokens(runner: Any, grammar_output: Any) -> Any:
        state = runner.execute_model_state
        scheduler_output = state[0] if state is not None else None
        provider = getattr(runner, RUNNER_PROVIDER_ATTRIBUTE, None)
        try:
            output = original_sample(runner, grammar_output)
            if provider is not None and scheduler_output is not None:
                provider.compress_scheduled_requests(scheduler_output)
            return output
        except Exception:
            if (
                provider is not None
                and scheduler_output is not None
                and getattr(provider, "query_window_tokens", 0)
            ):
                provider.abort_query_step(scheduler_output)
            raise

    def execute_model(runner: Any, *args: Any, **kwargs: Any) -> Any:
        assert original_execute_model is not None
        if gdn_list_compat:
            from .host_compat import clear_qwen_gdn_list_compat_cache

            clear_qwen_gdn_list_compat_cache()
        provider = getattr(runner, RUNNER_PROVIDER_ATTRIBUTE, None)
        output = args[0] if args else kwargs.get("scheduler_output")
        observes = provider is not None and getattr(provider, "query_window_tokens", 0)
        has_per_layer_metadata = provider is not None and (
            getattr(provider, "requires_per_layer_physical_state", False)
            or getattr(provider, "_has_per_layer_rows", False)
        )
        if has_per_layer_metadata:
            provider.begin_per_layer_step(output)
        if observes:
            provider.begin_query_step(output)
        try:
            result = original_execute_model(runner, *args, **kwargs)
            if has_per_layer_metadata:
                provider.finish_per_layer_step()
            if observes:
                provider.finish_query_step()
            return result
        except Exception:
            if observes:
                provider.abort_query_step(output)
            raise

    setattr(runner_cls, f"{_PATCH_MARKER}_original_initialize", original_initialize)
    setattr(runner_cls, f"{_PATCH_MARKER}_original_load_model", original_load_model)
    setattr(runner_cls, f"{_PATCH_MARKER}_original_update", original_update)
    setattr(runner_cls, f"{_PATCH_MARKER}_original_metadata", original_metadata)
    setattr(runner_cls, f"{_PATCH_MARKER}_original_sample", original_sample)
    if original_execute_model is not None:
        setattr(
            runner_cls,
            f"{_PATCH_MARKER}_original_execute_model",
            original_execute_model,
        )
    runner_cls.load_model = load_model
    runner_cls.initialize_kv_cache = initialize_kv_cache
    runner_cls._update_states = update_states
    runner_cls._build_attention_metadata = build_attention_metadata
    runner_cls.sample_tokens = sample_tokens
    if original_execute_model is not None:
        runner_cls.execute_model = execute_model
    setattr(runner_cls, _PATCH_MARKER, True)


def _install_attention_query_hook() -> None:
    """Observe queries at the graph-splitting attention custom-op boundary."""
    from vllm_ascend.attention.attention_v1 import AscendAttentionBackendImpl

    marker = "_ascend_kvcompress_query_observer_v1"
    if AscendAttentionBackendImpl.__dict__.get(marker, False):
        return
    original = AscendAttentionBackendImpl.forward

    def forward(
        backend: Any,
        layer: Any,
        query: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        provider = getattr(layer, ATTENTION_QUERY_PROVIDER_ATTRIBUTE, None)
        if provider is not None:
            provider.capture_attention_query(layer.layer_name, query)
        return original(backend, layer, query, *args, **kwargs)

    AscendAttentionBackendImpl.forward = forward
    setattr(AscendAttentionBackendImpl, f"{marker}_original", original)
    setattr(AscendAttentionBackendImpl, marker, True)


def _install_gdn_metadata_hook() -> None:
    """Keep recurrent GDN metadata in semantic space during hybrid builds."""
    from vllm_ascend.ops.gdn_attn_builder import AscendGDNAttentionMetadataBuilder

    marker = "_ascend_kvcompress_semantic_lengths_v4"
    if AscendGDNAttentionMetadataBuilder.__dict__.get(marker, False):
        return
    original = AscendGDNAttentionMetadataBuilder.build

    def build(
        builder: Any,
        common_prefix_len: int,
        common_attn_metadata: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        provider = _METADATA_PROVIDER.get()
        if provider is not None:
            common_attn_metadata = provider.semantic_gdn_metadata(common_attn_metadata)
        return original(
            builder, common_prefix_len, common_attn_metadata, *args, **kwargs
        )

    AscendGDNAttentionMetadataBuilder.build = build
    setattr(AscendGDNAttentionMetadataBuilder, marker, True)


def _prepare_current_triton_runtime() -> None:
    """Preload a module required by the current Ascend JIT specializer.

    Triton Ascend 3.6 resolves Gluon descriptor types from its native argument
    specializer.  Its first RoPE launch fails unless the NVIDIA descriptor
    namespace has already been materialized, even though the package is present
    in the wheel.  Keep the workaround local to enabled plugin processes and
    fail with a useful installation error if the expected module is absent.
    """
    # Triton Ascend 3.2 does not ship the Gluon API and does not use its
    # descriptor specializer.  The Frontier host still carries that runtime,
    # so leave it on the ordinary JIT path instead of importing a namespace
    # that belongs only to 3.6 and newer.
    triton_module = sys.modules.get("triton")
    triton_version = str(getattr(triton_module, "__version__", ""))
    if triton_version.startswith("3.2."):
        return

    # vLLM-Ascend's legacy compatibility path creates parent modules with an
    # empty ``__path__``.  Triton Ascend is distributed as ``triton-ascend``,
    # so a host check for distribution ``triton`` can select that path even on
    # 3.6.  Remove only those unmistakable empty stubs before importing the
    # real packages from the wheel.
    legacy_stub_present = any(
        getattr(sys.modules.get(name), "__path__", None) == []
        for name in _TRITON_GLUON_MODULES[:-1]
    )
    if legacy_stub_present:
        for name in reversed(_TRITON_GLUON_MODULES):
            sys.modules.pop(name, None)

    try:
        for name in _TRITON_GLUON_MODULES:
            import_module(name)
    except ImportError as error:
        raise RuntimeError(
            f"the validated Triton Ascend runtime is incomplete: cannot import {name}"
        ) from error


def _configure_message_queue_defaults() -> None:
    """Apply vLLM's explicit MQ chunk-size override to every local queue.

    Current vLLM applies ``VLLM_MQ_MAX_CHUNK_BYTES_MB`` to the scheduler
    broadcast queue, but its per-worker response queue still constructs
    ``MessageQueue(1, 1)`` with the 24 MiB Python default.  Ten chunks therefore
    require 240 MiB of ``/dev/shm`` even when the operator has deliberately
    selected a smaller chunk for a low-concurrency container.  Align the omitted
    default with the same opt-in environment variable.  Messages larger than a
    chunk already use MessageQueue's socket fallback, so this changes only the
    shared-memory fast-path capacity, not the accepted message size.
    """
    configured = os.getenv("VLLM_MQ_MAX_CHUNK_BYTES_MB")
    if configured is None:
        return
    try:
        chunk_mebibytes = int(configured)
    except ValueError as error:
        raise RuntimeError("VLLM_MQ_MAX_CHUNK_BYTES_MB must be an integer") from error
    if chunk_mebibytes <= 0:
        raise RuntimeError("VLLM_MQ_MAX_CHUNK_BYTES_MB must be positive")

    queue_cls = import_module(_MESSAGE_QUEUE_MODULE).MessageQueue
    if queue_cls.__dict__.get(_MESSAGE_QUEUE_PATCH_MARKER, False):
        return
    initializer = queue_cls.__init__
    defaults = initializer.__defaults__
    # Current MessageQueue defaults are, in order: local_reader_ranks,
    # max_chunk_bytes, max_chunks, connect_ip. Fail closed if the host seam
    # changes instead of silently patching the wrong parameter.
    if defaults is None or len(defaults) != 4 or defaults[2] != 10:
        raise RuntimeError("unsupported vLLM MessageQueue constructor defaults")
    updated = list(defaults)
    updated[1] = chunk_mebibytes * 1024 * 1024
    initializer.__defaults__ = tuple(updated)
    setattr(queue_cls, _MESSAGE_QUEUE_PATCH_MARKER, True)
    logger.info(
        "Applied VLLM_MQ_MAX_CHUNK_BYTES_MB=%d to worker response queues",
        chunk_mebibytes,
    )


def _install_runtime_slot_mapping_hooks(
    runner: Any, attention_group_index: int = 0
) -> None:
    """Patch the concrete tables allocated by the current Ascend runner.

    vLLM-Ascend owns a device-specific BlockTable implementation.  Patching
    vLLM's generic table is therefore neither sufficient nor a stable way to
    locate the active slot-mapping seam.  Resolve it from the initialized
    runner and fail closed if the expected single-group structure changes.
    """
    group_table = getattr(getattr(runner, "input_batch", None), "block_table", None)
    block_tables = getattr(group_table, "block_tables", None)
    if (
        not isinstance(block_tables, list)
        or attention_group_index < 0
        or attention_group_index >= len(block_tables)
    ):
        raise RuntimeError("Ascend full-attention block table is unavailable")
    block_table = block_tables[attention_group_index]
    if not callable(getattr(block_table, "compute_slot_mapping", None)):
        raise RuntimeError("Ascend block table does not expose compute_slot_mapping")
    _install_slot_mapping_hook(type(block_table))


def _install_slot_mapping_hook(block_table_cls: type[Any]) -> None:
    marker = f"{_PATCH_MARKER}_slot_mapping"
    if block_table_cls.__dict__.get(marker, False):
        return
    original = block_table_cls.compute_slot_mapping

    def compute_slot_mapping(
        block_table: Any,
        num_reqs: int,
        query_start_loc: Any,
        positions: Any,
    ) -> None:
        provider = getattr(block_table, RUNNER_PROVIDER_ATTRIBUTE, None)
        if provider is not None:
            positions = provider.physical_positions_for_slot_mapping(positions)
        return original(block_table, num_reqs, query_start_loc, positions)

    setattr(block_table_cls, f"{marker}_original", original)
    block_table_cls.compute_slot_mapping = compute_slot_mapping
    setattr(block_table_cls, marker, True)
