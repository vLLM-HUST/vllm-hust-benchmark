import pathlib,json,hashlib,sys,sysconfig,importlib.metadata as md,urllib.parse,zipfile,time,shutil,os
from transformers import AutoConfig,AutoTokenizer
from vllm_ascend_kvcompress.calibration import CalibrationRequest,_load_calibration_text,_model_source_fingerprint,_model_shape_from_hf_config
R=pathlib.Path('/root/ecpa-native-7b-calibration-20261013-r1');R.mkdir(mode=0o700);R.chmod(0o700)
V=pathlib.Path('/root/ecpa-native-kv-candidate-venv-20261013');assert pathlib.Path(sys.prefix)==V
S=pathlib.Path(sysconfig.get_path('purelib'))
def h(p):
 d=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):d.update(b)
 return d.hexdigest()
def save(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2));p.chmod(0o600)
mods={'host':'vllm','ascend':'vllm-ascend','kvcompress':'vllm-ascend-kvcompress-hust','manager':'vllm-hust-ext','torch':'torch','torch_npu':'torch-npu','triton':'triton-ascend','accelerate':'accelerate'}
wheels={}
for role,name in mods.items():
 d=md.distribution(name);direct=json.loads(d.read_text('direct_url.json'));p=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(direct['url']).path));checks=0
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():
   if '.data/' in n or not n.endswith(('.py','.so')):continue
   a,b=hashlib.sha256(),hashlib.sha256()
   with z.open(n) as f:
    for c in iter(lambda:f.read(8*1024*1024),b''):a.update(c)
   with pathlib.Path(d.locate_file(n)).open('rb') as f:
    for c in iter(lambda:f.read(8*1024*1024),b''):b.update(c)
   assert a.digest()==b.digest(),(role,n);checks+=1
 wheels[role]={'name':name,'version':d.version,'path':str(p),'sha256':h(p),'python_elf_exact':checks,'direct_url':direct}
assert wheels['accelerate']['sha256']=='97eacca0b73e45cb867dbf8c5d5d4dc32219544300e0c8992c7334dc2ef33cec'
assert wheels['host']['sha256']=='f575fac91bf30059210b185bd6bcbfab32f42bb757c29a605fd3a57a06937aa3'
assert wheels['kvcompress']['sha256']=='8f53c169e641b1f5569584ab862d3dfc47f18693272b63ca55f7d5c53b11abca'
try:md.distribution('vllm-kv-materialization')
except md.PackageNotFoundError:pass
else:raise AssertionError('old KVmat still installed')
model='/models/Qwen2.5-7B-Instruct';mf=[]
old=json.loads(pathlib.Path('/root/ecpa-native-upload-interface-20261013-r2/owner-config.json').read_bytes())['model_files'];oldhash={x['path']:x['sha256'] for x in old}
for p in sorted(pathlib.Path(model).iterdir()):
 if p.is_file():
  digest=h(p);assert digest==oldhash[str(p)];mf.append({'path':str(p),'sha256':digest,'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns})
assert len(mf)==14
out=R/'qwen2.5-7b-genuine-global-head-stats.pt';assert not out.exists()
text,original_source=_load_calibration_text(CalibrationRequest(model=model,output=out,max_length=4096))
input_path=R/'builtin-multilingual-input.txt';input_path.write_text(text);input_path.chmod(0o600)
tok=AutoTokenizer.from_pretrained(model,local_files_only=True);encoded=tok(text,return_tensors='pt',truncation=True,max_length=4096,add_special_tokens=True)
ids=encoded['input_ids'].tolist();save(R/'actual-tokenizer-input-ids.json',{'tokenizer_class':type(tok).__name__,'input_ids':ids,'actual_length':len(ids[0]),'max_length':4096,'text_sha256':h(input_path),'CPU_tokenization_only':True,'formal_result':False})
config=AutoConfig.from_pretrained(model,local_files_only=True);shape=_model_shape_from_hf_config(config)
owner=pathlib.Path('/root/ecpa-native-kv-owner-preparation-20261013/calibration-owner.py');shutil.copyfile(owner,R/'owner.source.py');(R/'owner.source.py').chmod(0o600)
sourcepaths=[S/'vllm_ascend_kvcompress'/n for n in ('calibration.py','artifacts.py','model.py','config.py','__init__.py','methods/triattention/config.py')]
sourcepaths += [S/'transformers'/n for n in ('modeling_utils.py','integrations/accelerate.py','models/qwen2/modeling_qwen2.py','models/qwen2/configuration_qwen2.py','models/qwen2/tokenization_qwen2.py')]
sourcepaths += [S/'accelerate'/n for n in ('__init__.py','big_modeling.py','hooks.py','utils/imports.py')]
sources=[{'path':str(p),'sha256':h(p)} for p in sourcepaths]
for i,x in enumerate(sources):q=R/(f'source-{i:02d}.py');shutil.copyfile(x['path'],q);q.chmod(0o600);x['snapshot']=str(q)
base=json.loads(pathlib.Path('/root/ecpa-native-upload-interface-20261013-r2/owner-config.json').read_bytes())['env']
for k in ('VLLM_HUST_EXT_CONFIG','ECPA_NATIVE_SEMANTIC_BOOTSTRAP','ECPA_ACTIVATION_CONTRACT'):
 base.pop(k,None)
base['VLLM_PLUGINS']='ascend_kv_connector,ascend_model,ascend_model_loader';base['PATH']=str(V/'bin')+':/usr/local/Ascend/cann-9.1.0/bin:/usr/local/python3.12.13/bin:/usr/local/bin:/usr/bin:/bin';base['PYTHONPATH']='/root/ecpa-manager-native-challenge-runner:/usr/local/Ascend/cann-9.1.0/python/site-packages:/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe'
cache=R/'triton-cache';cache.mkdir(mode=0o700);cache.chmod(0o700);base['TRITON_CACHE_DIR']=str(cache);base['PYTHONNOUSERSITE']='1'
deps=[{'name':d.metadata['Name'],'version':d.version,'metadata_sha256':hashlib.sha256(d.read_text('METADATA').encode()).hexdigest()} for d in md.distributions()]
argv=[str(V/'bin/python'),'-m','vllm_ascend_kvcompress.calibration','--model',model,'--tokenizer',model,'--output',str(out),'--input',str(input_path),'--max-length','4096','--device','npu:0','--dtype','bfloat16','--attn-implementation','eager','--local-files-only']
recipe={'schema':'ecpa-real-7b-calibration-preparation/v1','classification':'REAL_HF_MODEL_FORWARD_CALIBRATION_PREPARATION','formal_result':False,'owner_source_sha256':h(owner),'owner_execution_path':str(R/'owner.source.py'),'sources':sources,'model_files':mf,'wheels':wheels,'dependencies':deps,'input':{'path':str(input_path),'sha256':h(input_path),'origin':original_source},'tokenizer_ids_sha256':h(R/'actual-tokenizer-input-ids.json'),'actual_token_count':len(ids[0]),'model_source_fingerprint':_model_source_fingerprint(model,None),'fingerprint_semantics':'source names/size/mtime only; fourteen full file SHAs separately bound','shape':shape.__dict__,'env':base,'stats_output':str(out),'argv':argv,'cwd':str(R),'output':str(R/'run'),'timeout_s':900,'frozen_monotonic_ns':time.monotonic_ns(),'physical_allocated_devices':[3,6],'calibration_runtime_device':'npu:0','TP2_calibration':False,'KV_MOD_semantic_obligation_satisfied':None,'full_generation_quality':None,'full_objective_satisfied':None}
save(R/'recipe.json',recipe);save(R/'entrypoints-before-calibration.json',[{'group':e.group,'name':e.name,'value':e.value} for d in md.distributions() for e in d.entry_points if e.group=='vllm.general_plugins'])
print(json.dumps({'root':str(R),'recipe_sha256':h(R/'recipe.json'),'owner_sha256':h(R/'owner.source.py'),'input_sha256':h(input_path),'actual_tokens':len(ids[0]),'model_files':len(mf),'dependencies':len(deps),'shape':shape.__dict__,'GPU_model_forward_started':False,'formal_result':False}))
