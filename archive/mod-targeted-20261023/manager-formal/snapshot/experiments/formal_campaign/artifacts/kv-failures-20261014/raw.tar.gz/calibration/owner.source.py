"""Execute one frozen real HF calibration preparation, never an effect result."""
import argparse,hashlib,json,os,pathlib,subprocess,time,traceback
from experiments.formal_campaign import h3_worker_relaunch as lifecycle

def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(path,value):
 raw=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
 fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('recipe',type=pathlib.Path);p.add_argument('--expected-sha256',required=True);args=p.parse_args()
 assert sha(args.recipe)==args.expected_sha256
 r=json.loads(args.recipe.read_bytes());assert r['schema']=='ecpa-real-7b-calibration-preparation/v1' and r['formal_result'] is False
 assert sha(__file__)==r['owner_source_sha256'] and str(pathlib.Path(__file__))==r['owner_execution_path']
 for x in r['sources']+r['model_files']+[r['input']]+list(r['wheels'].values()):assert sha(x['path'])==x['sha256'],x['path']
 assert sha(args.recipe.parent/'actual-tokenizer-input-ids.json')==r['tokenizer_ids_sha256']
 from importlib import metadata as md
 actual={d.metadata['Name']:(d.version,hashlib.sha256(d.read_text('METADATA').encode()).hexdigest()) for d in md.distributions()}
 assert actual=={d['name']:(d['version'],d['metadata_sha256']) for d in r['dependencies']}
 assert len(r['model_files'])==14 and not pathlib.Path(r['stats_output']).exists()
 assert not any(k in r['env'] for k in ('ASCEND_RT_VISIBLE_DEVICES','CUDA_VISIBLE_DEVICES','NPU_VISIBLE_DEVICES','VLLM_ECPA_PLAN_ID','VLLM_ECPA_LAUNCH_ID','ECPA_NATIVE_SEMANTIC_BOOTSTRAP','VLLM_ASCEND_KVCOMPRESS_CONFIG','VLLM_HUST_EXT_CONFIG'))
 out=pathlib.Path(r['output']);out.mkdir(mode=0o700);out.chmod(0o700)
 write(out/'frozen-recipe.json',r)
 result={'classification':'REAL_HF_7B_CALIBRATION_PREPARATION','formal_result':False,'passed':False,'KV_MOD_semantic_obligation_satisfied':None,'full_generation_quality':None,'full_objective_satisfied':None}
 proc=None;captured=[]
 try:
  with (out/'stdout').open('wb') as a,(out/'stderr').open('wb') as b:
   proc=subprocess.Popen(r['argv'],env=r['env'],cwd=r['cwd'],stdout=a,stderr=b,start_new_session=True)
  owner=lifecycle.identity(proc.pid);captured.append(owner)
  write(out/'actual-owned-process.json',{'kernel':owner,'cmdline_sha256':sha(f'/proc/{proc.pid}/cmdline'),'argv':r['argv'],'wall_ns':time.time_ns(),'formal_result':False})
  deadline=time.monotonic()+r['timeout_s']
  while proc.poll() is None and time.monotonic()<deadline:
   new,_=lifecycle.owned_sessions(owner)
   captured=list({x['pid']:x for x in captured+new}.values())
   time.sleep(.2)
  if proc.poll() is None:raise ValueError('calibration deadline; preserve this actual attempt')
  result['returncode']=proc.returncode
  if proc.returncode==0 and pathlib.Path(r['stats_output']).is_file():
   result['artifact_sha256']=sha(r['stats_output']);result['artifact_size']=pathlib.Path(r['stats_output']).stat().st_size;result['artifact_generated_stdout']=b'generated calibration artifact:' in (out/'stdout').read_bytes()
   result['passed']=result['artifact_generated_stdout']
 except Exception as e:result['failure']=str(e);(out/'failure-trace.txt').write_text(traceback.format_exc())
 finally:
  errors=[]
  if proc is not None:
   try:lifecycle.cleanup(proc,owner,10,captured)
   except Exception as e:errors.append(str(e))
  terminal={'wall_ns':time.time_ns(),'captured_sessions':captured,'remaining_sessions':[{'owner':x,'members':lifecycle.members(x)} for x in captured],'formal_result':False}
  if any(x['members'] for x in terminal['remaining_sessions']):errors.append('owned process remains live')
  result['cleanup_errors']=errors
  if errors:result['passed']=False
  write(out/'terminal-process-audit.json',terminal)
  with (out/'terminal-npu-smi.txt').open('wb') as f:subprocess.run(['npu-smi','info'],stdout=f,stderr=subprocess.STDOUT,check=False)
  write(out/'result.json',result)
 print(json.dumps(result));return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
