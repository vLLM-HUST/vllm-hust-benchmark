"""Late independent owned-peer snapshot. Read-only; values limited to frozen env keys."""
import argparse, hashlib, json, os, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('config',type=Path);p.add_argument('peers',type=Path);a=p.parse_args()
c=json.loads(a.config.read_bytes());peers=json.loads(a.peers.read_bytes())
rows=[];boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for peer in peers:
 identity=peer['process'];pid=identity['pid'];base=Path('/proc')/str(pid)
 try:
  stat=(base/'stat').read_text();fields=stat[stat.rfind(')')+2:].split();ticks=int(fields[19]);session=int(fields[3])
  argv=(base/'cmdline').read_bytes();env=dict(x.split(b'=',1) for x in (base/'environ').read_bytes().split(b'\0') if b'=' in x)
  allowed={k:env.get(k.encode(),b'').decode(errors='replace') for k in c['env']}
  reserved={k:env.get(k.encode(),b'').decode(errors='replace') for k in ['VLLM_ECPA_PLAN_ID','VLLM_ECPA_LAUNCH_ID','ASCEND_RT_VISIBLE_DEVICES','CUDA_VISIBLE_DEVICES','NPU_VISIBLE_DEVICES']}
  fds=[]
  for fd in (base/'fd').iterdir():
   try:
    target=os.readlink(fd)
    if target.startswith('socket:'): fds.append({'fd':fd.name,'target':target})
   except OSError:pass
  rows.append({'expected_native':identity,'actual_kernel':{'pid':pid,'start_ticks':ticks,'boot_id':boot,'session':session},'kernel_match':ticks==identity['start_ticks'] and boot==identity['boot_id'] and session==identity['session'],'argv':argv.decode(errors='replace').split('\0'),'cmdline_sha256':hashlib.sha256(argv).hexdigest(),'frozen_key_actual_environment':allowed,'native_and_visible_environment':reserved,'socket_fds':fds})
 except (OSError,ValueError) as e: rows.append({'expected_native':identity,'snapshot_unavailable':type(e).__name__})
out={'classification':'LATE_READ_ONLY_INDEPENDENT_KERNEL_SNAPSHOT','capture_wall_ns':time.time_ns(),'capture_monotonic_ns':time.monotonic_ns(),'preregistered_observer':False,'config_sha256':hashlib.sha256(a.config.read_bytes()).hexdigest(),'peer_source_sha256':hashlib.sha256(a.peers.read_bytes()).hexdigest(),'rows':rows}
path=Path(__file__).parent/f"kernel-{out['capture_wall_ns']}.json";path.write_text(json.dumps(out,indent=2)+'\n');print(path)
