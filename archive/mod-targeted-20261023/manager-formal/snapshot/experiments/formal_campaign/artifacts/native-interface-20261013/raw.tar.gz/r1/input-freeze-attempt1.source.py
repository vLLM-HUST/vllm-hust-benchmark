"""Freeze a fresh installed-source tuple before any hardware-producing child."""
import pathlib,json,hashlib,sys,sysconfig,importlib.metadata as md,urllib.parse,zipfile,time,shutil
from experiments.native_challenge_candidate import request_runner
from vllm_hust_ext.runtime_phase_handoff import manager_source_digests
R=pathlib.Path('/root/ecpa-native-upload-interface-20261013-r1');R.mkdir(mode=0o700)
V=pathlib.Path('/root/ecpa-native-upload-candidate-venv-20261013');assert pathlib.Path(sys.prefix)==V
S=pathlib.Path(sysconfig.get_path('purelib'));M=pathlib.Path('/root/ecpa-manager-native-challenge-runner');H=S/'vllm'
def h(p):
 d=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):d.update(b)
 return d.hexdigest()
def w(p,x):p.write_bytes(request_runner.canonical(x));p.chmod(0o600)
roles={'host':'vllm','ascend':'vllm-ascend','mod':'vllm-kv-materialization','manager':'vllm-hust-ext','torch':'torch','torch_npu':'torch-npu','triton':'triton-ascend'}
revisions={'host':'a4bdbe74c1bdc1228e3cc19c61887225d35f16f8','ascend':'fcbb827af84f793939bf03d01a1dfe0338a0164c','mod':'e343fc5ce6b4c64611a79df5d797b3db12cd6dac','manager':'3be1eac03479bcae03239748b30fc85fe208f3d6'}
artifacts={};installed={}
for role,name in roles.items():
 d=md.distribution(name);direct=json.loads(d.read_text('direct_url.json'));p=pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(direct['url']).path));assert p.is_file()
 checks=0
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():
   if '.data/' in n or not n.endswith(('.py','.so')):continue
   actual=pathlib.Path(d.locate_file(n));assert actual.is_file(),(role,n)
   a,b=hashlib.sha256(),hashlib.sha256()
   with z.open(n) as f:
    for chunk in iter(lambda:f.read(8*1024*1024),b''):a.update(chunk)
   with actual.open('rb') as f:
    for chunk in iter(lambda:f.read(8*1024*1024),b''):b.update(chunk)
   assert a.digest()==b.digest(),(role,n)
   checks+=1
 artifacts[role]={'path':str(p),'sha256':h(p),'revision':revisions.get(role),'version':d.version}
 installed[role]={'package':name,'version':d.version,'python_elf_files_exact':checks,'metadata_sha256':hashlib.sha256(d.read_text('METADATA').encode()).hexdigest(),'direct_url':direct}
 assert role!='ascend' or checks==757,checks
sources=[]
paths={
 'request-runner':M/'experiments/native_challenge_candidate/request_runner.py',
 'collector-client':M/'experiments/native_challenge_candidate/collector_client.py',
 'collector':M/'experiments/exposure_gate/native_semantic_collector.py',
 'bootstrap':M/'experiments/exposure_gate/native_semantic_bootstrap.py',
 'host-input-processor':H/'v1/engine/input_processor.py',
 'host-request-base':H/'entrypoints/serve/engine/serving.py',
 'host-request-protocol':H/'entrypoints/openai/chat_completion/protocol.py',
 'host-chat-serving':H/'entrypoints/openai/chat_completion/serving.py',
 'host-native-observer':H/'plugins/native_block_table_observer.py',
 'host-native-collector':H/'plugins/native_semantic_collector.py',
 'host-native-bootstrap':H/'plugins/native_semantic_bootstrap.py',
 'host-process-evidence':H/'plugins/evidence.py',
 'ascend-gpu-model-runner':S/'vllm_ascend/worker/model_runner_v1.py',
 'mod-plugin':S/'vllm_kv_materialization/plugin.py',
 'host-launcher':V/'bin/ecpa-host-launch'}
for name in ('cli','runtime_phase_handoff','runtime_evidence','process_supervisor'):
 role={'cli':'manager-cli','runtime_phase_handoff':'manager-handoff','runtime_evidence':'manager-evidence','process_supervisor':'manager-supervisor'}[name]
 paths[role]=S/'vllm_hust_ext'/(name+'.py')
for role,p in paths.items():assert p.is_file(),p;sources.append({'role':role,'path':str(p),'sha256':h(p)})
assert h(paths['collector'])==h(paths['host-native-collector'])=='ee62c51444acde7b813c33ea4c2b20ab07248ea050753199cbfc79d73f1c5075'
assert h(paths['bootstrap'])==h(paths['host-native-bootstrap'])=='b34666ebcbb56703c7dfe7374a6988ee2ba09e2057e6bc3e6013bc4eddf2c06f'
assert 'native_block_table_observer.observe_block_table_upload(self, scheduler_output)' in paths['ascend-gpu-model-runner'].read_text()
model=[];prior=json.loads(pathlib.Path('/root/ecpa-h3-worker-real-qualification-20261013-r2/preflight.json').read_bytes())['model']['files']
for p in sorted(pathlib.Path('/models/Qwen2.5-7B-Instruct').iterdir()):
 if p.is_file():
  d=h(p);assert d==prior[p.name],p;model.append({'path':str(p),'sha256':d})
assert len(model)==14
shutil.copyfile('/root/ecpa-h3-worker-real-qualification-20261013-r2/manager-config.json',R/'manager-config.json');(R/'manager-config.json').chmod(0o600)
sources.append({'role':'manager-config','path':str(R/'manager-config.json'),'sha256':h(R/'manager-config.json')})
cache=R/'triton-cache';cache.mkdir(mode=0o700);ci=cache.stat()
recipe=request_runner.freeze_file({'phase_targets':[{'phase_id':'native-interface-phase0','url':'http://127.0.0.1:29493/v1/chat/completions','model':'ecpa-native-interface'}],'sources':sources},R/'recipe.json')
env=json.loads(pathlib.Path('/root/ecpa-h3-worker-real-qualification-20261013-r2/campaign.json').read_bytes())['arms'][2]['env']
env['PATH']=str(V/'bin')+':/usr/local/Ascend/cann-9.1.0/bin:/usr/local/Ascend/cann-9.1.0/tools/ccec_compiler/bin:/usr/local/python3.12.13/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
env['PYTHONPATH']=str(M)+':/usr/local/Ascend/cann-9.1.0/python/site-packages:/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe'
env['TRITON_CACHE_DIR']=str(cache);env['VLLM_HUST_EXT_CONFIG']=str(R/'manager-config.json')
env['ECPA_NATIVE_SEMANTIC_BOOTSTRAP']=str(R/'bootstrap-context.json')
owner=pathlib.Path('/root/ecpa-native-upload-owner-preparation-20261013/owner.py');shutil.copyfile(owner,R/'owner.source.py')
config={'schema':'ecpa-native-interface-owner/v1','formal_result':False,'scope':'native-request-upload-transport-only',
 'wheel_artifacts':artifacts,'model_files':model,'sources':sources,'env':env,'physical_devices':[3,6],'runtime_devices':[0,1],
 'owner_source_sha256':h(owner),'bootstrap_context':env['ECPA_NATIVE_SEMANTIC_BOOTSTRAP'],'cache_identity':[ci.st_dev,ci.st_ino],
 'recipe':recipe['path'],'recipe_sha256':recipe['sha256'],'frozen_monotonic_ns':time.monotonic_ns(),
 'python':str(V/'bin/python'),'cwd':str(R),'output':str(R/'run'),'phase_socket':str(R/'manager.sock'),
 'collector_source':str(paths['collector']),'startup_timeout_s':900,'health_url':'http://127.0.0.1:29493/health',
 'manager_source_sha256':manager_source_digests(),
 'native_source_files':[{'path':x['path'],'sha256':x['sha256']} for x in sources if x['role'] in {'host-input-processor','host-native-observer','host-native-collector','host-native-bootstrap','host-process-evidence','ascend-gpu-model-runner'}],
 'argv':[str(V/'bin/python'),str(V/'bin/vllm-hust-ext'),'run','--phase-binding-socket','@native_phase_socket@','--shutdown-grace-seconds','2','--',str(V/'bin/python'),str(V/'bin/ecpa-host-launch'),'serve','/models/Qwen2.5-7B-Instruct','--served-model-name','ecpa-native-interface','--host','127.0.0.1','--port','29493','--tensor-parallel-size','2','--enforce-eager','--max-model-len','2048','--gpu-memory-utilization','0.35','--shutdown-timeout','20'],
 'cache_policy':'initial-private-empty-0700-only-no-relaunch','manager_wheel_hash_not_unique_to_commit':True,
 'formal_H3_starts':0,'formal_H4_starts':0,'lost_requests':None,'duplicate_requests':None,'full_objective_satisfied':None}
w(R/'installed-source-audit.json',{'installed':installed,'artifacts':artifacts,'model_files_freshly_hashed':14,'formal_result':False})
w(R/'owner-config.json',config);w(R/'freeze-summary.json',{'owner_config_sha256':h(R/'owner-config.json'),'recipe':recipe,'owner_source_sha256':h(owner),'source_files':len(sources),'formal_result':False})
print(json.dumps({'root':str(R),'config_sha256':h(R/'owner-config.json'),'recipe_sha256':recipe['sha256'],'owner_sha256':h(owner),'installed':{k:v['python_elf_files_exact'] for k,v in installed.items()},'formal_result':False}))
