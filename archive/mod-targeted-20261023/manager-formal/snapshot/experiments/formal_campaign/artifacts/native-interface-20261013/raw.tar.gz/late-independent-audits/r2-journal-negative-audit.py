"""Independent rehashed semantic corruption probes of exact frozen ee62 replay."""
import base64,copy,hashlib,json,tempfile
from pathlib import Path
from experiments.exposure_gate import native_semantic_collector as n
r=Path('/root/ecpa-native-upload-interface-20261013-r2/run');rows=[json.loads(l) for l in (r/'native-raw.jsonl').read_bytes().splitlines()]
assert hashlib.sha256(Path(n.__file__).read_bytes()).hexdigest()=='ee62c51444acde7b813c33ea4c2b20ab07248ea050753199cbfc79d73f1c5075'
def factmutate(events,seq,key,value):
 e=events[seq];f=json.loads(base64.b64decode(e['raw_base64']));f[key]=value;b=n.canonical(f);e['raw_base64']=base64.b64encode(b).decode();e['raw_sha256']=n.sha(b)
def run(name,mutate,ack=True):
 events=copy.deepcopy(rows);mutate(events);prev='0'*64
 for seq,e in enumerate(events):
  e['sequence']=seq;e['previous_sha256']=prev;e.pop('event_sha256',None);e['event_sha256']=n.sha(n.canonical(e));prev=e['event_sha256']
 with tempfile.TemporaryDirectory(prefix='ecpa-negative-') as d:
  p=Path(d)/'raw.jsonl';p.write_bytes(b'\n'.join(n.canonical(e) for e in events)+b'\n')
  try:
   a=n.verify_journal(r/'collector-spec.json',p,acknowledged_prefix={'next_sequence':len(events),'last_event_sha256':prev} if ack else None)
   if a['complete_two_rank_transport_phases']!=1 or a['durable_ACK_status']!='verified-authenticated-prefix':return {'case':name,'rejected_qualification':True,'reason':'incomplete/unknown proof','facts':a}
   return {'case':name,'rejected_qualification':False,'facts':a}
  except (ValueError,KeyError) as e:return {'case':name,'rejected_qualification':True,'reason':str(e)}
def role(events):
 f=json.loads(base64.b64decode(events[2]['raw_base64']));f['process']['role']='api-server';factmutate(events,2,'process',f['process'])
def barrier(events):factmutate(events,2,'observed_after_barrier_monotonic_ns',1)
def premap(events):factmutate(events,2,'monotonic_ns',json.loads(base64.b64decode(events[1]['raw_base64']))['monotonic_ns']-1)
def missingrank(events):events[:]=[e for e in events if 'raw_base64' not in e or json.loads(base64.b64decode(e['raw_base64']))['process']['role']!='worker' or json.loads(base64.b64decode(e['raw_base64']))['process']['ordinal']==0]
cases=[('foreign-external',lambda e:factmutate(e,1,'external_request_id','chatcmpl-other')),('wrong-runtime-one-upload',lambda e:factmutate(e,2,'runtime_request_id','unknown')),('wrong-worker-role',role),('barrier-before-producer',barrier),('upload-before-mapping',premap),('cpu-device-as-NPU',lambda e:factmutate(e,2,'device','cpu')),('prefix-digest-diverges',lambda e:factmutate(e,2,'uploaded_rows_sha256','0'*64)),('semantic-promotion',lambda e:factmutate(e,2,'kv_tensor_equivalence',True)),('one-rank-only',missingrank),('source-snapshot-substitution',lambda e:e[0].__setitem__('collector_source_sha256','0'*64)),('missing-accept-clock',lambda e:e[2].pop('accepted_monotonic_ns'))]
results=[run(name,fn) for name,fn in cases];results.append(run('missing-ACK-prefix',lambda e:None,False));assert all(x['rejected_qualification'] for x in results),results
out={'schema':'ecpa-independent-r2-rehashed-negative-audit/v1','analysis_source_sha256':n.sha(Path(n.__file__).read_bytes()),'fully_rehashed_chain_and_matching_ACK_except_explicit_missing_case':True,'scope':'native-request-upload-transport-only','results':results,'formal_result':False}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'negative_cases':len(results),'all_rejected_qualification':True}))
