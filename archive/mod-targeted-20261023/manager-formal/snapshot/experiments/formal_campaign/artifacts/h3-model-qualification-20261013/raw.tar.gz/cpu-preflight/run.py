import os,json,time,subprocess,signal,hashlib
from pathlib import Path
from dataclasses import asdict
from experiments.exposure_gate.loopback_traffic import LoopbackTrafficAdapter
from experiments.formal_campaign.h3_phase_barrier import identity,wait_native_prepare
from experiments.formal_campaign.h3_authority_chain import verify_recovery_chain
from vllm_hust_ext.exposure_gate import LeaseGrant
R=Path(__file__).resolve().parent;M=Path('/root/ecpa-manager-h3-model-qualification');V=Path('/root/ecpa-exposure-proxy-candidate-venv/bin/python');(R/'coordinator').mkdir(mode=0o700)
def save(n,v):(R/n).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def wait(p,c):
 for _ in range(200):
  if c.poll()!=None:raise RuntimeError('child failed')
  if p.exists():return
  time.sleep(.05)
 raise TimeoutError(str(p))
env=os.environ|{'PYTHONPATH':str(M/'src')+':'+str(M)}
spec={'root':str(R/'coordinator'),'authority_socket':str(R/'authority.sock'),'grant':{'holder':'cpu-preflight','fencing_token':1,'expires_at':int(time.time())+180},'launch_id':'cpu-preflight-'+str(time.time_ns()),'candidate':{'generation':1,'label':'candidate','backend_port':18187},'predecessor':{'generation':0,'label':'predecessor','backend_port':28187},'evidence_identity_sha256':'sha256:'+'a'*64};save('spec.json',spec);sha='sha256:'+hashlib.sha256((R/'spec.json').read_bytes()).hexdigest();save('binding.json',{'launch_id':spec['launch_id'],'registration_sha256':sha})
pc=[str(V),str(M/'experiments/exposure_gate/loopback_traffic.py'),'--socket',str(R/'authority.sock'),'--journal',str(R/'authority.jsonl'),'--listen-port','0','--predecessor-port','28187','--candidate-port','18187','--predecessor-snapshot',json.dumps(spec['predecessor']),'--grant-holder','cpu-preflight','--grant-token','1','--grant-expires-at',str(spec['grant']['expires_at']),'--recovery-binding',str(R/'binding.json')];nc=[str(V),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'launch','--spec',str(R/'spec.json')];save('inputs.json',{'classification':'CPU_PREFLIGHT_ONLY','scope':'no model/no NPU/no formal H3','argv':[pc,nc],'root_mode':oct(R.stat().st_mode & 0o777),'coordinator_mode':oct((R/'coordinator').stat().st_mode & 0o777)})
children=[]
try:
 proxy=subprocess.Popen(pc,env=env,stdout=open(R/'proxy.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(proxy);wait(R/'authority.sock',proxy);a=LoopbackTrafficAdapter(R/'authority.sock',LeaseGrant(**spec['grant']));save('proxy-identity.json',identity(proxy.pid));save('route-before.json',asdict(a.query_route()))
 launched=time.monotonic_ns();p=subprocess.Popen(nc,env=env,stdout=open(R/'manager-before.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(p);wait(R/'coordinator/prepare-barrier.json',p);state=json.loads(subprocess.check_output([str(V),str(M/'experiments/formal_campaign/h3_native_prepare.py'),'state','--spec',str(R/'spec.json')],env=env));proof=wait_native_prepare({'protocol':'ecpa-native-close-prepare-barrier/v1','barrier_path':str(R/'coordinator/prepare-barrier.json'),'journal_path':str(R/'coordinator/gate.sqlite'),'timeout_s':10},target=identity(p.pid),launcher_pid=p.pid,launch_id=spec['launch_id'],launched_ns=launched,state_before=state);save('prepare-proof.json',proof)
 fault=time.monotonic_ns();os.kill(p.pid,signal.SIGKILL);p.wait(timeout=10);restart_ns=time.monotonic_ns();p=subprocess.Popen(nc,env=env,stdout=open(R/'manager-after.log','wb'),stderr=subprocess.STDOUT,start_new_session=True);children.append(p);wait(R/'coordinator/recovery.json',p);save('route-after.json',asdict(a.query_route()));first=json.loads((R/'authority.jsonl').read_text().splitlines()[0]);result=verify_recovery_chain(R/'authority.jsonl',expected_proxy=identity(proxy.pid),registration_sha256=sha,launch_id=spec['launch_id'],prepared_route=first['route'],fault_ns=fault,restart_ns=restart_ns,completion_ns=time.monotonic_ns());save('result.json',{'passed':True,'classification':'CPU_PREFLIGHT_ONLY','authority':result})
finally:
 for p in reversed(children):
  if p.poll()==None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
