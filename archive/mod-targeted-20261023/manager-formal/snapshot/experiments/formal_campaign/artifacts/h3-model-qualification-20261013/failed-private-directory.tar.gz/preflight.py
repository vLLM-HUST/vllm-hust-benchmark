from pathlib import Path
import hashlib,json,zipfile,importlib.metadata as md,urllib.parse,subprocess,socket
R=Path(__file__).resolve().parent;M=Path('/root/ecpa-manager-h3-model-qualification');V=Path('/root/ecpa-exposure-proxy-candidate-venv'); report={'utc':__import__('time').strftime('%Y-%m-%dT%H:%M:%SZ',__import__('time').gmtime()),'classification':'qualification-input-audit','wheels':{},'installed':{}}
def h(path):
 digest=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):digest.update(block)
 return digest.hexdigest()
for name in ('vllm','vllm-ascend','vllm-kv-materialization','torch','torch-npu','triton-ascend','vllm-hust-ext'):
 try:
  d=md.distribution(name);direct=d.read_text('direct_url.json'); row={'version':d.version,'metadata_sha256':hashlib.sha256(d.read_text('METADATA').encode()).hexdigest(),'direct_url':json.loads(direct) if direct else None};report['installed'][name]=row
  if direct:
   u=urllib.parse.urlparse(json.loads(direct)['url']);p=Path(urllib.parse.unquote(u.path))
   if u.scheme=='file' and p.is_file() and p.suffix=='.whl':
    mismatch=[];checks=0
    with zipfile.ZipFile(p) as z:
     for f in z.namelist():
      if f.endswith('.py') and '.data/' not in f:
       checks+=1;local=Path(d.locate_file(f))
       if not local.is_file() or local.read_bytes()!=z.read(f):mismatch.append(f)
    report['wheels'][name]={'path':str(p),'sha256':h(p),'python_files_checked':checks,'mismatches':mismatch};assert not mismatch,(name,mismatch)
 except md.PackageNotFoundError:report['installed'][name]={'absent':True}
assert report['installed']['vllm']['version']=='0.31.1.post1.dev164+g379a0ad35.empty'
assert report['wheels']['vllm']['sha256']=='a850a238b7ac0b6fdb9fd0ceb833dd843c0242570977b0f14fae482fe8d3d551'
report['manager']={'commit':subprocess.check_output(['git','-C',str(M),'rev-parse','HEAD'],text=True).strip(),'dirty':subprocess.check_output(['git','-C',str(M),'status','--porcelain'],text=True)}
report['manager']['source_files']={str(p.relative_to(M)):h(p) for p in (M/'src').rglob('*.py')}
report['entry_points']=[{'name':e.name,'group':e.group,'value':e.value} for e in md.entry_points() if False] if False else [{'name':e.name,'group':e.group,'value':e.value} for group in ('vllm.general_plugins','vllm.platform_plugins') for e in md.entry_points(group=group)]
report['model']={'root':'/models/Qwen2.5-7B-Instruct','files':{p.name:h(p) for p in sorted(Path('/models/Qwen2.5-7B-Instruct').iterdir()) if p.is_file()}}
report['ports']={}
for port in (8187,18187,28187):
 with socket.socket() as probe:report['ports'][str(port)]=probe.connect_ex(('127.0.0.1',port));assert report['ports'][str(port)]!=0
report['passed']=True;(R/'preflight.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
