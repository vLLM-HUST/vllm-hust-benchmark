"""Verify the attachment and recompute numerical evidence offline."""
import bisect
import hashlib
import json
import math
import statistics
from decimal import Decimal, getcontext
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROLES = ("B0", "B1")
getcontext().prec = 45


def require(condition, label):
    if not condition:
        raise ValueError(label)


def verify(value, expected, label):
    if isinstance(expected, dict):
        for name, item in expected.items():
            verify(value[name], item, f"{label}.{name}")
    elif isinstance(expected, list):
        require(len(value) == len(expected), f"{label}: wrong length")
        for index, item in enumerate(expected):
            verify(value[index], item, f"{label}[{index}]")
    elif isinstance(expected, bool) or expected is None:
        require(value is expected, f"{label}: unexpected flag")
    elif isinstance(expected, (float, Decimal)) or isinstance(value, Decimal):
        require(math.isclose(float(value), float(expected), rel_tol=2e-9, abs_tol=5e-7),
                f"{label}: {value} differs from {expected}")
    else:
        require(value == expected, f"{label}: {value} differs from {expected}")


def ratio(a, b):
    return Decimal(str(a)) / Decimal(str(b))


def percentile(values, p, nearest=False):
    if not values:
        return None
    ordered = sorted(values)
    if nearest:
        return ordered[(p * len(ordered) + 99) // 100 - 1]
    position = (len(ordered) - 1) * (p / 100)
    low, high = math.floor(position), math.ceil(position)
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def latency(rows):
    ttft = [1000 * (r["first_token"] - r["start"]) for r in rows]
    tpot = [1000 * (r["end"] - r["first_token"]) / (r["output_tokens"] - 1)
            for r in rows if r["output_tokens"] > 1]
    return ttft, tpot


def dataset_metrics(stage):
    rows = stage["requests"]
    require(len(rows) == stage["record_count"], "Published stage lost requests")
    complete = [r for r in rows if r["status"] in ("ok", "invalid_judge")]
    successful = [r for r in complete if r["status"] == "ok"]
    elapsed = max(r["end"] for r in rows) - min(r["start"] for r in rows)
    tokens = sum(r["output_tokens"] for r in complete)
    ttft, tpot = latency(complete)
    content = [1000 * (r["last_token"] - r["first_token"]) / (r["output_tokens"] - 1)
               for r in complete if r["output_tokens"] > 1]
    return dict(
        planned=stage["record_count"], recorded=len(rows), successful=len(successful),
        transport_completed=len(complete), failed=len(rows) - len(complete),
        unreturned=stage["record_count"] - len(rows), unresolved_grades=len(complete) - len(successful),
        length_stops=sum(r["finish"] == "length" for r in complete),
        successful_output_tokens=tokens, duration_seconds=elapsed, output_tokens_per_second=tokens / elapsed,
        mean_ttft_ms=statistics.mean(ttft), mean_tpot_ms=statistics.mean(tpot),
        mean_content_span_per_token_ms=statistics.mean(content),
        ttft_p95_ms=percentile(ttft, 95), ttft_p99_ms=percentile(ttft, 99),
        tpot_p95_ms=percentile(tpot, 95), tpot_p99_ms=percentile(tpot, 99),
        actual_context_16k_cases=sum(r["input_tokens"] + r["output_tokens"] >= 16384 for r in complete),
    )


def quality_track(rows):
    total = len(rows)
    successes = sum(r["correct"] is True for r in rows)
    graded = sum(r["correct"] is not None for r in rows)
    accuracy = successes / total
    return dict(total=total, graded=graded, successes=successes, accuracy=accuracy,
                unresolved=total - graded, wald_95_half_width=1.96 * math.sqrt(accuracy * (1 - accuracy) / total),
                judge_invalid=sum(r["status"] == "invalid_judge" for r in rows),
                judge_transport_failures=sum(r["http_status"] != 200 for r in rows),
                judge_truncated=sum(r["finish"] == "length" for r in rows))


def phase_metrics(rows, start, end, nearest=False):
    successful = [r for r in rows if r["success"]]
    ttft, tpot = latency(successful)
    tokens = sum(r["output_tokens"] for r in successful)

    def describe(values):
        return dict(mean=statistics.fmean(values), p95=percentile(values, 95, nearest),
                    p99=percentile(values, 99, nearest))

    return dict(requests=len(rows), successful=len(successful), failed=len(rows) - len(successful),
                duration_seconds=end - start, output_tokens=tokens,
                output_tokens_per_second=tokens / (end - start),
                ttft_ms=describe(ttft), tpot_ms=describe(tpot))


def utilization(samples, end):
    times = [row[0] for row in samples]
    require(len(times) == len(set(times)) and times == sorted(times), "Invalid sampler clock order")
    cuts = [0] + [t for t in times if 0 < t < end] + [end]
    totals = [0., 0.]
    covered = missing = max_hold = 0.
    for left, right in zip(cuts, cuts[1:]):
        index = bisect.bisect_right(times, left) - 1
        duration = right - left
        if index < 0:
            missing += duration
            continue
        covered += duration
        max_hold = max(max_hold, right - times[index])
        for slot in range(2):
            totals[slot] += samples[index][slot + 1] * duration
    per_slot = [total / covered for total in totals]
    return dict(per_slot_percent=per_slot, mean_percent=sum(per_slot) / 2,
                covered_seconds=covered, missing_seconds=missing, max_hold_age_seconds=max_hold)


def replay_context(data):
    phases = {}
    for role, arm in data.items():
        phases[role] = {}
        for name, phase in arm["phases"].items():
            rows = phase["requests"]
            end = phase["end"]
            deadline = phase["submission_seconds"]
            descriptive = phase_metrics(rows, 0, end)
            verify(descriptive, phase["expected"], f"context.{role}.{name}")
            summary = phase_metrics(rows, 0, end, nearest=True)
            for tenant, original in phase["expected_per_tenant"].items():
                group = [r for r in rows if r["tenant"] == tenant]
                verify(phase_metrics(group, 0, end), original, f"context.{role}.{name}.{tenant}")
            summary["per_tenant_counts"] = {
                tenant: sum(r["tenant"] == tenant and r["success"] for r in rows)
                for tenant in phase["expected_per_tenant"]
            }
            summary["mean_ai_core"] = utilization(phase["samples"], end)
            verify(summary["mean_ai_core"], phase["expected_utilization"], f"utilization.{role}.{name}")
            summary["windows"] = []
            for index, expected in enumerate(phase["expected_windows"]):
                low, high = 60 * index, min(60 * (index + 1), deadline)
                group = [r for r in rows if low <= r["start"] < high]
                drained = max([high] + [r["end"] for r in group])
                verify(phase_metrics(group, low, drained), expected, f"context.{role}.{name}.window{index}")
                summary["windows"].append(phase_metrics(group, low, drained, nearest=True))
            summary["complete"] = (phase["status"] == "completed" and len(rows) > 0 and
                                   summary["failed"] == 0 and end >= deadline)
            phases[role][name] = summary
    return phases


def context_gate(phases, clean):
    b1 = phases["B1"]
    labels = ("throughput", "ttft_p95", "ttft_p99", "tpot_p95", "tpot_p99")

    def values(phase):
        return [phase["output_tokens_per_second"], phase["ttft_ms"]["p95"], phase["ttft_ms"]["p99"],
                phase["tpot_ms"]["p95"], phase["tpot_ms"]["p99"]]

    ratios = dict(zip(labels, [ratio(high, low) for low, high in
                               zip(values(b1["4096-formal"]), values(b1["16384-formal"]))]))
    windows = b1["32768-formal"]["windows"]
    spread = dict(zip(labels, [ratio(max(col), min(col)) for col in zip(*(values(row) for row in windows))]))
    milestone = (clean and all(phases[r][k]["complete"] for r in ROLES for k in ("4096-formal", "16384-formal"))
                 and ratios["throughput"] >= Decimal(".5") and
                 all(ratios[k] <= limit for k, limit in zip(labels[1:], (3, 3, 2, 2))))
    final = (clean and all(phases[r]["32768-formal"]["complete"] for r in ROLES) and len(windows) == 5
             and all(w["requests"] and w["failed"] == 0 for w in windows)
             and all(spread[k] <= limit for k, limit in zip(labels, map(Decimal, ("1.50", "2", "2", "1.25", "1.25")))))
    return dict(milestone=milestone, final=final, measured_ratios=ratios, measured_window_ratios=spread)


def compute_result(data):
    result = {}
    scale = Decimal(data["occupied_cards"] * 10**12)
    for role, arm in data["arms"].items():
        require(len(arm["current"]) == len(arm["reference"]) == 3, "Expected three measured repetitions")
        work = [sum(row["F_interval"][bound] for row in arm["current"]) for bound in (0, 1)]
        seconds = sum(Decimal(row["T_seconds"]) for row in arm["current"])
        achieved = [Decimal(w) / (scale * seconds) for w in work]
        ref_work = [sum(row["F_interval"][bound] for row in arm["reference"]) for bound in (0, 1)]
        ref_seconds = sum(Decimal(row["Tref_lower_seconds"]) for row in arm["reference"])
        ref_upper = Decimal(ref_work[1]) / (scale * ref_seconds)
        efficiency = 100 * achieved[0] / ref_upper
        result[role] = dict(F_interval=work, T_seconds=seconds, achieved_tflops_per_card_interval=achieved,
                            reference_F_interval=ref_work, reference_seconds_lower=ref_seconds,
                            reference_tflops_per_card_upper=ref_upper, efficiency_lower_percent=efficiency)
        verify(result[role], arm["expected"], f"compute.{role}")
    a0, a1 = [result[role]["achieved_tflops_per_card_interval"] for role in ROLES]
    gain = [100 * (a1[0] / a0[1] - 1), 100 * (a1[1] / a0[0] - 1)]
    efficiency = result["B1"]["efficiency_lower_percent"]
    verify(gain, data["expected_gain_interval"], "compute.gain")
    verify(efficiency, data["expected_efficiency_lower_percent"], "compute.efficiency")
    qualified = all(data[k] for k in ("reference_qualified", "native_clock_qualified", "full_model_certificate"))
    return dict(arms=result, gain_percent_interval=gain, milestone=qualified and efficiency >= 50,
                final=qualified and efficiency >= 90)


def cost_result(data, phases):
    card_monthly = Decimal(data["server_monthly_cny"]) / data["server_cards"]
    billing_seconds = Decimal(data["billing_days"] * 86400)
    result = {}
    for measure in ("mmlu", "four_tenant"):
        charge = {}
        for role, row in data[measure].items():
            if measure == "four_tenant":
                phase = phases[role]["multi-tenant-formal"]
                verify(phase["duration_seconds"], float(row["window_seconds"]), f"cost.{role}.seconds")
                verify(phase["output_tokens"], row["successful_output_tokens"], f"cost.{role}.tokens")
                verify(phase["mean_ai_core"], row["utilization"], f"cost.{role}.utilization")
            charge[role] = (Decimal(10**6) * card_monthly * row["occupied_cards"] *
                            Decimal(row["window_seconds"]) / (billing_seconds * row["successful_output_tokens"]))
        result[measure] = dict(cny_per_million_output_tokens=charge,
                               cost_reduction_percent=100 * (1 - charge["B1"] / charge["B0"]))
    mmlu = data["mmlu"]
    uplift = Decimal(str(mmlu["B1"]["utilization"]["mean_percent"])) - Decimal(str(mmlu["B0"]["utilization"]["mean_percent"]))
    four_ai = Decimal(str(phases["B1"]["multi-tenant-formal"]["mean_ai_core"]["mean_percent"]))
    coverage = all(phase["multi-tenant-formal"]["mean_ai_core"]["missing_seconds"] == 0 for phase in phases.values())
    complete = all(arm["multi-tenant-formal"]["complete"] and
                   list(arm["multi-tenant-formal"]["per_tenant_counts"]) == [f"tenant-{i}" for i in range(4)] and
                   min(arm["multi-tenant-formal"]["per_tenant_counts"].values()) > 0
                   for arm in phases.values())
    mmlu_coverage = all(row["utilization"]["missing_seconds"] == 0 and
                        row["utilization"]["covered_seconds"] > 0 for row in mmlu.values())
    return dict(basis=data["basis"], contractual_actual_expense=data["contractual_actual_expense"],
                monthly_cny_per_card=card_monthly, mmlu_uplift_pp=uplift, four_tenant_b1_ai_core=four_ai,
                milestone=all((data["mmlu_complete"], data["mmlu_quality"], mmlu_coverage, uplift >= 10,
                               result["mmlu"]["cost_reduction_percent"] >= 10)),
                final=coverage and complete and four_ai >= 80 and result["four_tenant"]["cost_reduction_percent"] >= 30,
                **result)


def dataset_comparisons(data, stages, quality):
    prior = data["previous_attachment"]["reused_measurements"]
    pairs = {}
    quality_met = {}
    for name, role_rows in prior.items():
        a, b = (role_rows[r]["quality"] for r in ROLES)
        pairs[name] = {r: role_rows[r]["performance"] for r in ROLES}
        if name == "mmlu":
            quality_met[name] = (a["correct"] - b["correct"]) / 2 <= 5
        else:
            quality_met[name] = all((a[t]["successes"] - b[t]["successes"]) * 100 / a[t]["total"] <= 5 for t in a)
    quality_met["hle"] = (quality["B0"]["successes"] - quality["B1"]["successes"]) / 2 <= 5
    quality_met["swe"] = quality_met["terminal"] = True
    for name, variant in (("hle", "solver"), ("swe", "trace"), ("terminal", "trace")):
        pairs[name] = {r: stages[f"{name}-{variant}-{r}"] for r in ROLES}
    result = {}
    for name, rows in pairs.items():
        a, b = (rows[r] for r in ROLES)
        expected = {"mmlu": 200, "frontier": 160, "hle": 200, "swe": 64, "terminal": 48}[name]
        complete = all(row["recorded"] == row["successful"] == expected and row["failed"] == 0
                       for row in (a, b))
        out, first, token = (ratio(b[k], a[k]) for k in
                             ("output_tokens_per_second", "mean_ttft_ms", "mean_tpot_ms"))
        eligible = complete and quality_met[name]
        result[name] = dict(execution_complete=complete, quality_met=quality_met[name],
                            throughput_ratio=out, ttft_ratio=first, tpot_ratio=token,
                            milestone=eligible and out >= Decimal("1.10") and max(first, token) <= Decimal(".95"),
                            final=eligible and out >= 2 and max(first, token) <= Decimal(".80"))
        if name in prior:
            verify(result[name], data["previous_attachment"]["workload_ratios"][name], name)
    return dict(datasets=result, milestone=any(r["milestone"] for r in result.values()),
                final=any(r["final"] for r in result.values()))


def main():
    manifest = json.loads((HERE / "manifest.json").read_bytes())
    required = {"README.md", "projection.json", "recompute.py"}
    require(set(manifest["files"]) == required, "Unexpected manifest member")
    for name, expected in manifest["files"].items():
        raw = (HERE / name).read_bytes()
        verify(dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()), expected, name)
    data = json.loads((HERE / "projection.json").read_bytes())
    stages = {}
    for name, stage in data["stages"].items():
        stages[name] = dataset_metrics(stage)
        verify(stages[name], stage["expected"], name)
    quality = {}
    for role in ROLES:
        rows = data["stages"][f"hle-judge-{role}"]["requests"]
        tracks = {}
        for name, expected in data["hle_quality"][role]["tracks"].items():
            tracks[name] = quality_track([r for r in rows if r["track"] == name])
            verify(tracks[name], {k: v for k, v in expected.items() if k in tracks[name]}, f"hle.{role}.{name}")
        quality[role] = dict(tracks=tracks, **{key: sum(row[key] for row in tracks.values())
                             for key in ("total", "graded", "successes", "unresolved")})
    phases = replay_context(data["context"])
    context = context_gate(phases, all(v["clean_measured_interval"] for v in data["context"].values()))
    verify(context, data["context_targets"], "context.acceptance")
    targets = {"4.1": compute_result(data["compute"]),
               "4.2": dataset_comparisons(data, stages, quality),
               "4.3": context,
               "4.4": cost_result(data["cost"], phases)}
    startup = data["hle_startup"]
    require(startup["formal_client_started"] and not startup["original_allocator_error_observed"]
            and startup["raw_headroom_before_warmup_bytes"] >= startup["raw_headroom_required_before_warmup_bytes"]
            and stages["hle-solver-B1"]["successful"] == startup["formal_expected"],
            "HLE measured startup evidence differs")
    print(json.dumps(dict(acceptance=targets, dataset_metrics=stages, hle_quality=quality,
                          hle_startup=startup, context=phases), indent=2, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
