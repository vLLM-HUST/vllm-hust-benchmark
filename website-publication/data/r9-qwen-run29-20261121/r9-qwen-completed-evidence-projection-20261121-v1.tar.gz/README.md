# R9 completed evidence projection

This capsule contains numerical records from the sealed R9 run-29 composition. It includes the HLE solver and common judge, SWE-bench Pro and Terminal-Bench 2.1 trace performance, context and four-tenant measures, native and full-model reference repetition terms, and the published-rate rental calculation.

Extract the four files into one directory and run `python -B recompute.py` with Python 3.10 or newer. It verifies the manifest, reconstructs workload and context metrics, reproduces effective-compute and rental calculations, checks them against the sealed report projections, and prints JSON. It runs offline using the Python standard library. It does not start a model, import the benchmark corpus, or execute a workload.

Request clocks are elapsed seconds within each original measurement. Context utilization replays the sampler midpoint, left-hold time weighting and formal phase clipping. The paired context summary uses linear interpolation for descriptive percentiles. The 4.3 acceptance calculations use nearest rank. HLE accuracy uses all 200 selected cases as the denominator and reports unresolved grades separately. SWE-bench Pro and Terminal-Bench use inference over request snapshots and report performance only.

Four-tenant costs use the measured context windows. MMLU costs use the sealed 200-request window and output-token totals from the reused MMLU pair. Cost figures use the cited public rental estimate and a 30-day billing month.

`manifest.json` lists exclusions. Original file hashes identify sealed inputs. Each stage also has the count and SHA-256 of its excluded seal entries, calculated by sorting original file hashes and joining them with a newline after each hash, without filenames. The effective-compute calculation starts at the sealed per-repetition work intervals and clocks. The existing MMLU, FrontierScience and C8 attachment is linked by URL and SHA-256 in `projection.json`.
