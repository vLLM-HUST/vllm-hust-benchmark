# HLE-Verified performance: Qwen3.5-35B-A3B

Four separate vLLM bench serve groups. Raw original user question; image groups retain original images. Server template once, thinking=false, temperature=0, request/dataset seed=0, max_completion_tokens=256, ignore_eos=false. request-rate=inf, no client max-concurrency; server max_num_seqs=16. One vLLM initial test request per group outside measurement; extra warmups=0.

This is a performance workload, not an accuracy replay. All per-request input lengths match same-server /tokenize including images. No separate visual-token count is claimed.

| Group | Successful/selected | Failed | Output token/s | Mean TTFT ms | Mean TPOT ms | Duration s |
|---|---:|---:|---:|---:|---:|---:|
| gold-text | 200/200 | 0 | 381.323 | 57848.609 | 38.784 | 127.839 |
| revision-text | 200/200 | 0 | 422.899 | 52608.901 | 36.822 | 118.671 |
| gold-image | 93/93 | 0 | 314.484 | 28900.694 | 52.213 | 71.148 |
| revision-image | 118/118 | 0 | 330.824 | 34361.778 | 42.605 | 89.241 |

## Accuracy context (separate sealed runs)

| Subset | Correct/all selected | Unresolved judge | Solver length | Judge length |
|---|---:|---:|---:|---:|
| gold | 156/668 (23.35%) | 32 | 383 | 32 |
| revision | 313/1143 (27.38%) | 40 | 688 | 40 |

Unresolved grades remain in the full denominator; they are not confirmed wrong. Solver length is not automatically incorrect. Qwen substituted for official judge; not official leaderboard replication.

## Evidence binding

evidence_bundle_sha256: 6a63587a6e5817c3532ced106dbab1f56832cf770c413ffcf720934d47f65193
summary_sha256: cf34154b6e71b6e09ddf872eeddf25f85b5a4b2bd10f71474551d2cec7b84a7e
effective_json_sha256: a8e9f014d3a089298e618acea723482b55d46747d8f11f76db97b118935bf3f6
client_git_commit: 6d0358cba5f7f136123efae90c3ffe6072183113
Weights are inventoried, not hashed. Model small files are hashed; container image digest is unavailable.
See MANIFEST.json for table SHA-256; manifest SHA-256 is anchored outside this directory in manifest-ledger.jsonl.
