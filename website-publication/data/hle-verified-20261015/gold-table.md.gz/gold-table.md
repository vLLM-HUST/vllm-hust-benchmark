# HLE-Verified evaluation

Protocol: HLE original evaluation prompts/schema on HLE-Verified; Qwen substitute; single trial; not official leaderboard replication

Scope: complete_selected_plan

Solver: qwen3.5-35b; Judge: qwen3.5-35b

Scoring policy: strict_json

| Subset | Selected | Graded | Correct | Accuracy | Unresolved | Solver length | Judge length |
|---|---:|---:|---:|---:|---:|---:|---:|
| gold | 668 | 636 | 156 | 23.35% | 32 | 383 | 32 |

Gold and Revision are reported separately. This is not an official leaderboard replication.
Unresolved cases stay in the denominator; their correctness is unknown. A smoke result is not a full score.

evidence_bundle_sha256: bcfe373bfd9abc7923fd78120abaf0147ed52585355efde1179661054e572b93
summary_sha256: 6fcaa0f0377b6871fe68b9f02f6f3ab4dfab88303ff24b3b2b25fd609085e7b0
contract_sha256: ddef00f50918ced8ba6fcd85ed2e45374c6ae632e2a50e7a6d0fef91869035f3

See MANIFEST.json for the table SHA-256. Anchor the manifest hash outside this directory.
