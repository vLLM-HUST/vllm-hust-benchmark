# HLE-Verified evaluation

Protocol: HLE original evaluation prompts/schema on HLE-Verified; Qwen substitute; single trial; not official leaderboard replication

Scope: complete_selected_plan

Solver: qwen3.5-35b; Judge: qwen3.5-35b

Scoring policy: strict_json

| Subset | Selected | Graded | Correct | Accuracy | Unresolved | Solver length | Judge length |
|---|---:|---:|---:|---:|---:|---:|---:|
| revision | 1143 | 1103 | 313 | 27.38% | 40 | 688 | 40 |

Gold and Revision are reported separately. This is not an official leaderboard replication.
Unresolved cases stay in the denominator; their correctness is unknown. A smoke result is not a full score.

evidence_bundle_sha256: 8b75c7d3dd9355cab6484e0cec82a779f0b4b905ff52db6a8cbfee641eacf1e6
summary_sha256: c2afc87716cbe5f3a150f8664f5d243ed27a27584a588c438297c71f143040ed
contract_sha256: dde61103b4b064db6cd26e4bbff377682c1e4e5c2414e82926251fa7bb072a89

See MANIFEST.json for the table SHA-256. Anchor the manifest hash outside this directory.
