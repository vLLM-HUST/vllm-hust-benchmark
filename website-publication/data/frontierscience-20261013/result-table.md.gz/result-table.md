# FrontierScience Qwen3.5-35B-A3B

Protocol: official Appendix B prompts; Qwen judge; one trial; mmlu_extract_first local extraction and full denominator. Not official leaderboard replication.
First complete explicit VERDICT is extracted even from truncated output; invalids remain in denominator as nonsuccess. Flagged contradictions require review. Full weights were not hashed.

| Track | Total | Successes | Success rate | Mean Research score | Solver truncated | Judge truncated | Truncated with grade | Invalid judge | Judge unresolved | Judge audit flagged |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| olympiad | 100 | 57 | 0.57 | None | 33 | 4 | 2 | 3 | 3 | 2 |
| research | 60 | 5 | 0.08333333333333333 | 2.530877192982456 | 6 | 7 | 4 | 3 | 3 | 5 |

Bench: 160 custom chat prompts, output cap 256, request-rate inf, temperature 0, seed 0.

| Metric | Value |
|---|---:|
| completed | 160 |
| failed | 0 |
| duration | 73.71363537106663 |
| request_throughput | 2.170561785408859 |
| output_throughput | 555.6638170646679 |
| total_token_throughput | 1404.5027012822786 |
| mean_ttft_ms | 33954.69977196772 |
| mean_tpot_ms | 26.662729527052566 |

evidence_bundle_sha256: a4148b1b8e26553e69717bb3365c666529ca1205bdbf819cf5383a0e695898b1
contract_sha256: 6aeed92ee39e6661e8862581f93711ed748aea997aa43b287e3308c786e627e0
